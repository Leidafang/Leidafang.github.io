<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6f9d6c97-eca0-4be1-97ce-5322da3c7cb5">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">17.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66946679668386 139.73881872180135 0 35.66962359878885 139.73877181173015 0 35.66961192509631 139.73871328088455 0 35.669561258869265 139.7384726451449 0 35.669419144987586 139.73851412579327 0 35.66946746895233 139.73875653127715 0 35.66945512301393 139.7387601910633 0 35.66946679668386 139.73881872180135 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66946679668386 139.73881872180135 17.02 35.66945512301393 139.7387601910633 17.02 35.66946746895233 139.73875653127715 17.02 35.669419144987586 139.73851412579327 17.02 35.669561258869265 139.7384726451449 17.02 35.66961192509631 139.73871328088455 17.02 35.66962359878885 139.73877181173015 17.02 35.66946679668386 139.73881872180135 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66946679668386 139.73881872180135 17.02 35.66962359878885 139.73877181173015 17.02 35.66962359878885 139.73877181173015 34.35 35.66946679668386 139.73881872180135 34.35 35.66946679668386 139.73881872180135 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66962359878885 139.73877181173015 17.02 35.66961192509631 139.73871328088455 17.02 35.66961192509631 139.73871328088455 34.35 35.66962359878885 139.73877181173015 34.35 35.66962359878885 139.73877181173015 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66961192509631 139.73871328088455 17.02 35.669561258869265 139.7384726451449 17.02 35.669561258869265 139.7384726451449 34.35 35.66961192509631 139.73871328088455 34.35 35.66961192509631 139.73871328088455 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669561258869265 139.7384726451449 17.02 35.669419144987586 139.73851412579327 17.02 35.669419144987586 139.73851412579327 34.35 35.669561258869265 139.7384726451449 34.35 35.669561258869265 139.7384726451449 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669419144987586 139.73851412579327 17.02 35.66946746895233 139.73875653127715 17.02 35.66946746895233 139.73875653127715 34.35 35.669419144987586 139.73851412579327 34.35 35.669419144987586 139.73851412579327 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66946746895233 139.73875653127715 17.02 35.66945512301393 139.7387601910633 17.02 35.66945512301393 139.7387601910633 34.35 35.66946746895233 139.73875653127715 34.35 35.66946746895233 139.73875653127715 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66945512301393 139.7387601910633 17.02 35.66946679668386 139.73881872180135 17.02 35.66946679668386 139.73881872180135 34.35 35.66945512301393 139.7387601910633 34.35 35.66945512301393 139.7387601910633 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66946679668386 139.73881872180135 34.35 35.66962359878885 139.73877181173015 34.35 35.66961192509631 139.73871328088455 34.35 35.669561258869265 139.7384726451449 34.35 35.669419144987586 139.73851412579327 34.35 35.66946746895233 139.73875653127715 34.35 35.66945512301393 139.7387601910633 34.35 35.66946679668386 139.73881872180135 34.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b9bab47b-1199-4379-ad86-a2192f369ccd"/>
							<gml:surfaceMember xlink:href="#poly-2d75597d-17d3-4dc5-9f2b-35feb554c208"/>
							<gml:surfaceMember xlink:href="#poly-496165f2-fffd-4ee5-8ee0-2eaabbf2e51a"/>
							<gml:surfaceMember xlink:href="#poly-73fbee72-39a6-4feb-8f0c-1b5f112614c6"/>
							<gml:surfaceMember xlink:href="#poly-40c89b68-74ec-4440-96ee-96dbe70e2bee"/>
							<gml:surfaceMember xlink:href="#poly-b7bf3f70-9583-4497-9b3f-7ff278b24f42"/>
							<gml:surfaceMember xlink:href="#poly-7a5cadb4-7ab1-4ed2-9bdc-0109141babe2"/>
							<gml:surfaceMember xlink:href="#poly-1b8030db-57be-461a-91f1-4f12de2dfea4"/>
							<gml:surfaceMember xlink:href="#poly-472debb2-c0bd-493f-8466-ce1a808e8d1f"/>
							<gml:surfaceMember xlink:href="#poly-18a6b666-1f2e-4326-b3b5-577669d879be"/>
							<gml:surfaceMember xlink:href="#poly-ba79e884-a5b5-4631-bb71-ec573a804651"/>
							<gml:surfaceMember xlink:href="#poly-857ab913-6841-4782-9fc7-e43ea2b3a815"/>
							<gml:surfaceMember xlink:href="#poly-3864758e-eae3-4826-a4df-9f7164967246"/>
							<gml:surfaceMember xlink:href="#poly-ac5e7288-7960-41bc-a7f0-31e628a53387"/>
							<gml:surfaceMember xlink:href="#poly-49dd2067-3da9-4c72-946e-8e04ab578cae"/>
							<gml:surfaceMember xlink:href="#poly-d68173a0-d8de-4b4e-92b8-4d66446b6575"/>
							<gml:surfaceMember xlink:href="#poly-3cad65c8-186e-416e-b4bc-6ab8cd4addb3"/>
							<gml:surfaceMember xlink:href="#poly-c039de48-da57-4a1e-b925-62d2c96e3c6f"/>
							<gml:surfaceMember xlink:href="#poly-6ed45421-1672-42ee-b04c-1079faa727eb"/>
							<gml:surfaceMember xlink:href="#poly-c9052343-4fa0-418f-a733-f07116911161"/>
							<gml:surfaceMember xlink:href="#poly-41c81bb6-344a-493f-999d-8b390341a03f"/>
							<gml:surfaceMember xlink:href="#poly-38e41567-1f34-4095-8544-123a3037c116"/>
							<gml:surfaceMember xlink:href="#poly-dfcdb87a-2f58-4e41-ac98-f0ebc4853440"/>
							<gml:surfaceMember xlink:href="#poly-36976c63-662a-443e-967e-a537580f76c6"/>
							<gml:surfaceMember xlink:href="#poly-7bec945c-ad6c-45c0-b08e-d6d6b222da66"/>
							<gml:surfaceMember xlink:href="#poly-cf652d55-0bcc-48c5-bfad-d4076a759ba8"/>
							<gml:surfaceMember xlink:href="#poly-d7fb1332-3d92-436d-80fa-7c4d26197b00"/>
							<gml:surfaceMember xlink:href="#poly-20b442a5-a686-4a37-9566-f39727102278"/>
							<gml:surfaceMember xlink:href="#poly-be7f9908-3594-4a18-a91a-ae0085b60530"/>
							<gml:surfaceMember xlink:href="#poly-cd6cf247-ebbc-4edd-af0c-37eb373996c9"/>
							<gml:surfaceMember xlink:href="#poly-2e3ccf2a-f50f-45dc-bc96-261da9267606"/>
							<gml:surfaceMember xlink:href="#poly-4d00bff0-ad5b-4ba8-9d25-ae13a23b1c87"/>
							<gml:surfaceMember xlink:href="#poly-2367261a-0e90-4f6e-8e6a-ab6d740047d5"/>
							<gml:surfaceMember xlink:href="#poly-c410f041-b0ec-439d-8ca6-c1559cb4490b"/>
							<gml:surfaceMember xlink:href="#poly-a2f7e7c5-f2f8-4122-8b6d-c8787837c194"/>
							<gml:surfaceMember xlink:href="#poly-9c5de15a-b56d-400c-acdf-6652a5be411d"/>
							<gml:surfaceMember xlink:href="#poly-8c38685b-3b59-4574-b2bf-3c037bfcf626"/>
							<gml:surfaceMember xlink:href="#poly-bbffee1f-fcfa-4153-8e00-1dc1e4b32b9b"/>
							<gml:surfaceMember xlink:href="#poly-bd8bf1e2-dd49-4ff4-a53f-2163f240b3b8"/>
							<gml:surfaceMember xlink:href="#poly-72e3b0fe-52b6-4693-871a-8631b6ed9a85"/>
							<gml:surfaceMember xlink:href="#poly-7734083a-0f81-468c-a93d-78155dd2ddd4"/>
							<gml:surfaceMember xlink:href="#poly-05f153b4-cba3-437f-ae76-6632665fecda"/>
							<gml:surfaceMember xlink:href="#poly-4f53bf2b-075e-415c-8028-2d397ae9535c"/>
							<gml:surfaceMember xlink:href="#poly-41816da0-8981-4eed-9745-e4f930e4eba2"/>
							<gml:surfaceMember xlink:href="#poly-87d617f8-54ad-4a85-bb1f-6a7096371518"/>
							<gml:surfaceMember xlink:href="#poly-83534728-54ee-4c59-9174-3b962b71b0a1"/>
							<gml:surfaceMember xlink:href="#poly-593c1047-0aa2-4bac-bc8d-f059ce64f0b9"/>
							<gml:surfaceMember xlink:href="#poly-531242a9-3044-4451-b0b0-fd64233a5dc0"/>
							<gml:surfaceMember xlink:href="#poly-090ef6c5-b102-4789-9576-5c3d1f2d5c67"/>
							<gml:surfaceMember xlink:href="#poly-afb21c79-8b89-4168-9c5d-1797f4300fe8"/>
							<gml:surfaceMember xlink:href="#poly-20f4303d-67f3-4e25-ac9d-e1bc5e26fb24"/>
							<gml:surfaceMember xlink:href="#poly-028cba29-0dfc-4095-8036-4a1f8d74a749"/>
							<gml:surfaceMember xlink:href="#poly-d1ab5b91-1475-43b4-b6e4-5ab53243f20c"/>
							<gml:surfaceMember xlink:href="#poly-e1a112d2-14b0-43a8-8f42-ba6f02605a02"/>
							<gml:surfaceMember xlink:href="#poly-b371a688-980b-428b-a3af-8edb8d796b95"/>
							<gml:surfaceMember xlink:href="#poly-7b4723d2-06f3-424c-8412-6b9b68c5fc08"/>
							<gml:surfaceMember xlink:href="#poly-c0977b37-958b-4935-a537-cffe4af8afc5"/>
							<gml:surfaceMember xlink:href="#poly-bc97b1c3-0a7d-4963-9c71-181cf1faae97"/>
							<gml:surfaceMember xlink:href="#poly-9b90508b-4ab3-468f-8721-411eb1e3e7c4"/>
							<gml:surfaceMember xlink:href="#poly-7bb36660-f719-40b8-b812-d215371dd84f"/>
							<gml:surfaceMember xlink:href="#poly-fbb9544d-60c2-49a2-bc54-e291130c98fb"/>
							<gml:surfaceMember xlink:href="#poly-e70e44d7-8fb2-4161-85ff-ec3177dd89d7"/>
							<gml:surfaceMember xlink:href="#poly-3e894d2f-08ad-4e9a-a101-8882c1d0b9f2"/>
							<gml:surfaceMember xlink:href="#poly-c648048c-8f54-4ac0-a2b4-1019f4ca0129"/>
							<gml:surfaceMember xlink:href="#poly-d713a1b2-0ec9-4c54-ab66-b2175b17e567"/>
							<gml:surfaceMember xlink:href="#poly-758ef88c-a429-4a31-b968-64b33acd2b8a"/>
							<gml:surfaceMember xlink:href="#poly-c927ae85-969b-441d-8014-b94ac71555d8"/>
							<gml:surfaceMember xlink:href="#poly-2c045198-eace-424f-ae37-cd5cf00649cd"/>
							<gml:surfaceMember xlink:href="#poly-3b12bfd4-bbce-4669-8028-84e2616c0840"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6f9d6c97-eca0-4be1-97ce-5322da3c7cb5_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d04378e-261e-4709-b16b-f07225ce3d54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66955868258488 139.73866944633133 34.355 35.66955324397153 139.73864227923488 34.355 35.6695742319907 139.73863596919006 34.355 35.66957967060546 139.73866313629318 34.355 35.66955868258488 139.73866944633133 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d504a91-7e51-4b8b-940e-70ea382dbc3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d504a91-7e51-4b8b-940e-70ea382dbc3e_0">
											<gml:posList>35.66955324397153 139.73864227923488 34.355 35.66955324397153 139.73864227923488 37.584 35.6695742319907 139.73863596919006 37.584 35.6695742319907 139.73863596919006 34.355 35.66955324397153 139.73864227923488 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6cdd09c-95b5-4cb5-833b-6118b6db12b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6cdd09c-95b5-4cb5-833b-6118b6db12b8_0">
											<gml:posList>35.6695742319907 139.73863596919006 34.355 35.6695742319907 139.73863596919006 37.584 35.66957967060546 139.73866313629318 37.584 35.66957967060546 139.73866313629318 34.355 35.6695742319907 139.73863596919006 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98639005-496e-453e-bfbd-a17c77137f22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98639005-496e-453e-bfbd-a17c77137f22_0">
											<gml:posList>35.6695742319907 139.73863596919006 37.584 35.66955324397153 139.73864227923488 37.584 35.66955868258488 139.73866944633133 37.584 35.66957967060546 139.73866313629318 37.584 35.6695742319907 139.73863596919006 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97118c68-1a70-4df2-8ef3-0981f47f74ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97118c68-1a70-4df2-8ef3-0981f47f74ac_0">
											<gml:posList>35.66955868258488 139.73866944633133 34.355 35.66955868258488 139.73866944633133 37.584 35.66955324397153 139.73864227923488 37.584 35.66955324397153 139.73864227923488 34.355 35.66955868258488 139.73866944633133 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62175a18-638a-4b17-9b81-c92f9d72f6ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62175a18-638a-4b17-9b81-c92f9d72f6ef_0">
											<gml:posList>35.66957967060546 139.73866313629318 34.355 35.66957967060546 139.73866313629318 37.584 35.66955868258488 139.73866944633133 37.584 35.66955868258488 139.73866944633133 34.355 35.66957967060546 139.73866313629318 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6f9d6c97-eca0-4be1-97ce-5322da3c7cb5_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd9e721d-2699-432f-90cf-e71beef822cc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669528802228136 139.7385665205201 34.355 35.66952157973957 139.7385290053157 34.355 35.66953246584759 139.73852585533962 34.355 35.66954255742299 139.73857827945184 34.355 35.66951424271843 139.7385864649648 34.355 35.66951137364227 139.73857156711287 34.355 35.669528802228136 139.7385665205201 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c7c2133-9651-452c-8746-464e4bc8e970">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c7c2133-9651-452c-8746-464e4bc8e970_0">
											<gml:posList>35.66951424271843 139.7385864649648 34.355 35.66951424271843 139.7385864649648 35.503 35.66951137364227 139.73857156711287 35.503 35.66951137364227 139.73857156711287 34.355 35.66951424271843 139.7385864649648 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e418b74-b3dc-4abe-a402-a1a28aab5d62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e418b74-b3dc-4abe-a402-a1a28aab5d62_0">
											<gml:posList>35.66951137364227 139.73857156711287 34.355 35.66951137364227 139.73857156711287 35.503 35.669528802228136 139.7385665205201 35.503 35.669528802228136 139.7385665205201 34.355 35.66951137364227 139.73857156711287 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2192ba4-73fe-4cf2-8e0b-5bd88c28136b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2192ba4-73fe-4cf2-8e0b-5bd88c28136b_0">
											<gml:posList>35.669528802228136 139.7385665205201 34.355 35.669528802228136 139.7385665205201 35.503 35.66952157973957 139.7385290053157 35.503 35.66952157973957 139.7385290053157 34.355 35.669528802228136 139.7385665205201 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4198d5dc-b22a-4ab1-87a1-0b7c88734678">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4198d5dc-b22a-4ab1-87a1-0b7c88734678_0">
											<gml:posList>35.66951424271843 139.7385864649648 35.503 35.66954255742299 139.73857827945184 35.503 35.66953246584759 139.73852585533962 35.503 35.66952157973957 139.7385290053157 35.503 35.669528802228136 139.7385665205201 35.503 35.66951137364227 139.73857156711287 35.503 35.66951424271843 139.7385864649648 35.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79f90911-b5cc-43d7-917c-70b2dfa8fddd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79f90911-b5cc-43d7-917c-70b2dfa8fddd_0">
											<gml:posList>35.66952157973957 139.7385290053157 34.355 35.66952157973957 139.7385290053157 35.503 35.66953246584759 139.73852585533962 35.503 35.66953246584759 139.73852585533962 34.355 35.66952157973957 139.7385290053157 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d4393f3-5193-4005-87a9-3cd45203f2d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d4393f3-5193-4005-87a9-3cd45203f2d2_0">
											<gml:posList>35.66954255742299 139.73857827945184 34.355 35.66954255742299 139.73857827945184 35.503 35.66951424271843 139.7385864649648 35.503 35.66951424271843 139.7385864649648 34.355 35.66954255742299 139.73857827945184 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d78c9fb-d1a6-477e-8693-ae87b2b8c3a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d78c9fb-d1a6-477e-8693-ae87b2b8c3a1_0">
											<gml:posList>35.66953246584759 139.73852585533962 34.355 35.66953246584759 139.73852585533962 35.503 35.66954255742299 139.73857827945184 35.503 35.66954255742299 139.73857827945184 34.355 35.66953246584759 139.73852585533962 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6f9d6c97-eca0-4be1-97ce-5322da3c7cb5_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b521369-d92c-4519-bf98-741a66060ba4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669512238848206 139.7385027265479 34.355 35.66952209746937 139.73849967719912 34.355 35.669523671877066 139.73850731926672 34.355 35.66951382226944 139.73851036860395 34.355 35.669512238848206 139.7385027265479 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e740aa5d-33bc-4855-a87b-e0296e0b2e85">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669506828681214 139.7385117245037 34.355 35.6695004214808 139.7385137093396 34.355 35.669497842731275 139.73850121920748 34.355 35.66950424993148 139.73849923437064 34.355 35.669506828681214 139.7385117245037 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6773f581-a557-406f-9d94-61e7fae64331">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6695004214808 139.7385137093396 34.355 35.6695004214808 139.7385137093396 36.558 35.669497842731275 139.73850121920748 36.558 35.669497842731275 139.73850121920748 34.355 35.6695004214808 139.7385137093396 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26dcdeca-2006-4090-b72c-6269ca55a274">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669498483999945 139.7385143081223 34.355 35.66949590525048 139.7385018179904 34.355 35.66949590525048 139.7385018179904 36.558 35.669498483999945 139.7385143081223 36.558 35.669498483999945 139.7385143081223 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fa68681-8769-4e55-b51a-b0354735abb6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66951382226944 139.73851036860395 34.355 35.669523671877066 139.73850731926672 34.355 35.669523671877066 139.73850731926672 36.558 35.66951382226944 139.73851036860395 36.558 35.66951382226944 139.73851036860395 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dacfc1e1-b8cb-4b89-8d32-51717ea81b06">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669498483999945 139.7385143081223 34.355 35.669492094818224 139.73851628189033 34.355 35.66948951607766 139.73850380280552 34.355 35.66949590525048 139.7385018179904 34.355 35.669498483999945 139.7385143081223 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fc89948-c382-4e07-9ad1-ae30440e2444">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669492094818224 139.73851628189033 34.355 35.669492094818224 139.73851628189033 36.558 35.66948951607766 139.73850380280552 36.558 35.66948951607766 139.73850380280552 34.355 35.669492094818224 139.73851628189033 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5883f86-0cf5-4052-b784-fde6f2aa5a62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66951433805231 139.73851290860617 34.355 35.66951433805231 139.73851290860617 36.558 35.669524007429025 139.73850991471306 36.558 35.669524007429025 139.73850991471306 34.355 35.66951433805231 139.73851290860617 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e430a56a-97d3-4229-9e8f-4534c713d98a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669484389963344 139.73851867696703 34.355 35.66948181121433 139.73850618683724 34.355 35.669487407379606 139.73850445702152 34.355 35.66948997711507 139.73851694716282 34.355 35.669484389963344 139.73851867696703 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ace8880b-c409-4a08-a950-88e8de427ed6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66952546419669 139.73851697147467 34.355 35.66951579481979 139.73851996536698 34.355 35.66951433805231 139.73851290860617 34.355 35.669524007429025 139.73850991471306 34.355 35.66952546419669 139.73851697147467 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ec6da37-7105-4924-a069-3409a944304f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66950713660913 139.73851357989088 34.355 35.66950971537476 139.73852609211713 34.355 35.66950351543756 139.73852801043006 34.355 35.66950093668083 139.73851550925085 34.355 35.66950713660913 139.73851357989088 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56dc3a95-dc24-4b14-8144-fee3d22f16ee">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66950093668083 139.73851550925085 34.355 35.66950351543756 139.73852801043006 34.355 35.66950351543756 139.73852801043006 36.558 35.66950093668083 139.73851550925085 36.558 35.66950093668083 139.73851550925085 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d663dc37-c136-45cd-a2ac-b46044d73c26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66950146981805 139.73852864247868 34.355 35.66949889106138 139.73851614129978 34.355 35.66949889106138 139.73851614129978 36.558 35.66950146981805 139.73852864247868 36.558 35.66950146981805 139.73852864247868 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1c3c76d-abb7-41ac-a66d-f6fd09d1640f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66949889106138 139.73851614129978 34.355 35.66950146981805 139.73852864247868 34.355 35.669495053612316 139.7385306383699 34.355 35.669492474847154 139.73851812614578 34.355 35.66949889106138 139.73851614129978 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d108fcf2-ddfd-4d32-8648-2f85fddd131a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669492474847154 139.73851812614578 34.355 35.669495053612316 139.7385306383699 34.355 35.669495053612316 139.7385306383699 36.558 35.669492474847154 139.73851812614578 36.558 35.669492474847154 139.73851812614578 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-694a1237-0b93-40b7-9e68-974e43eabc34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669492935900394 139.7385312925959 34.355 35.669490357135295 139.7385187803721 34.355 35.669490357135295 139.7385187803721 36.558 35.669492935900394 139.7385312925959 36.558 35.669492935900394 139.7385312925959 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e40831ac-05c6-42ca-9abb-08d1c814ee1a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669490357135295 139.7385187803721 34.355 35.669492935900394 139.7385312925959 34.355 35.66948734874846 139.7385330223992 34.355 35.66948476998354 139.73852051017622 34.355 35.669490357135295 139.7385187803721 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67c9af00-9aa1-4fa2-873a-5aa28d7a6c18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66950675471655 139.73854371420944 34.355 35.66950401312305 139.73853046208433 34.355 35.669510222074 139.73852854376094 34.355 35.669512954645306 139.73854178485152 34.355 35.66950675471655 139.73854371420944 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1726f1ae-2e49-4f3f-b13f-539fcf32f75c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66950401312305 139.73853046208433 34.355 35.66950675471655 139.73854371420944 34.355 35.66950675471655 139.73854371420944 36.558 35.66950401312305 139.73853046208433 36.558 35.66950401312305 139.73853046208433 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa834551-3442-4b4e-b460-3cdacdcb03a9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669504600958355 139.73854437952397 34.355 35.669501868378646 139.7385311273885 34.355 35.669501868378646 139.7385311273885 36.558 35.669504600958355 139.73854437952397 36.558 35.669504600958355 139.73854437952397 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3958efcc-45d0-48e7-aaac-bb32168d5cc0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669504600958355 139.73854437952397 34.355 35.6694979774802 139.73854643088973 34.355 35.669495244900716 139.7385331787553 34.355 35.669501868378646 139.7385311273885 34.355 35.669504600958355 139.73854437952397 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b664b19-fdfb-4b56-b81d-b4285af03ac9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669495244900716 139.7385331787553 34.355 35.6694979774802 139.73854643088973 34.355 35.6694979774802 139.73854643088973 36.558 35.669495244900716 139.7385331787553 36.558 35.669495244900716 139.7385331787553 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac528c37-99ae-4a45-97a7-bfaf28e0a53c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66949618418398 139.7385469853166 34.355 35.66949345160456 139.73853373318244 34.355 35.66949345160456 139.73853373318244 36.558 35.66949618418398 139.7385469853166 36.558 35.66949618418398 139.7385469853166 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d52d3d9d-4a99-49fe-83f1-0eb351c1a40e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669487693235325 139.7385355184187 34.355 35.66949345160456 139.73853373318244 34.355 35.66949618418398 139.7385469853166 34.355 35.66949042581455 139.73854877055194 34.355 35.669487693235325 139.7385355184187 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7336bee8-2895-4dff-bd2b-4fba03955875">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669565823263774 139.7385456989614 38.364 35.66956699144236 139.73855256828395 38.364 35.66955951155608 139.73855448810917 38.364 35.6695583433689 139.7385476077411 38.364 35.669565823263774 139.7385456989614 38.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f48a157b-590a-497f-89ed-08a034112eec">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66950139735292 139.73856254316243 34.355 35.66949878238837 139.73854984319476 34.355 35.66950551400517 139.73854775856302 34.355 35.66950813798367 139.73856045852105 34.355 35.66950139735292 139.73856254316243 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90b12990-cbca-41a7-ba59-6d4ce26732c0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6694995229592 139.73856313082325 34.355 35.6694937555758 139.73856491606816 34.355 35.66949114061149 139.73855221610162 34.355 35.66949689898098 139.7385504308665 34.355 35.6694995229592 139.73856313082325 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba43291f-7362-408e-8316-2207f96ce941">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba43291f-7362-408e-8316-2207f96ce941_0">
											<gml:posList>35.66948997711507 139.73851694716282 34.355 35.669487407379606 139.73850445702152 34.355 35.669487407379606 139.73850445702152 36.558 35.66948997711507 139.73851694716282 36.558 35.66948997711507 139.73851694716282 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1644e91-f25a-42c0-ba4b-869bc8d8cd1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1644e91-f25a-42c0-ba4b-869bc8d8cd1b_0">
											<gml:posList>35.66950713660913 139.73851357989088 34.355 35.66950093668083 139.73851550925085 34.355 35.66950093668083 139.73851550925085 36.558 35.66950713660913 139.73851357989088 36.558 35.66950713660913 139.73851357989088 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ba2e0d7-2c07-465f-92fd-9901f122926f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ba2e0d7-2c07-465f-92fd-9901f122926f_0">
											<gml:posList>35.66950351543756 139.73852801043006 34.355 35.66950971537476 139.73852609211713 34.355 35.66950971537476 139.73852609211713 36.558 35.66950351543756 139.73852801043006 36.558 35.66950351543756 139.73852801043006 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-066dae57-43d1-4b82-88e3-6b6fdc4dc51b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-066dae57-43d1-4b82-88e3-6b6fdc4dc51b_0">
											<gml:posList>35.669495053612316 139.7385306383699 34.355 35.66950146981805 139.73852864247868 34.355 35.66950146981805 139.73852864247868 36.558 35.669495053612316 139.7385306383699 36.558 35.669495053612316 139.7385306383699 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25fccb42-39e1-4447-bb56-e6477565b31b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25fccb42-39e1-4447-bb56-e6477565b31b_0">
											<gml:posList>35.66948734874846 139.7385330223992 34.355 35.669492935900394 139.7385312925959 34.355 35.669492935900394 139.7385312925959 36.558 35.66948734874846 139.7385330223992 36.558 35.66948734874846 139.7385330223992 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-887ee546-2fb5-44af-9020-f9d19938b596">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-887ee546-2fb5-44af-9020-f9d19938b596_0">
											<gml:posList>35.66950139735292 139.73856254316243 34.355 35.66950139735292 139.73856254316243 36.558 35.66949878238837 139.73854984319476 36.558 35.66949878238837 139.73854984319476 34.355 35.66950139735292 139.73856254316243 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7173817-bffe-4b40-8491-0cc386d78b85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7173817-bffe-4b40-8491-0cc386d78b85_0">
											<gml:posList>35.66952209746937 139.73849967719912 34.355 35.669512238848206 139.7385027265479 34.355 35.669512238848206 139.7385027265479 36.558 35.66952209746937 139.73849967719912 36.558 35.66952209746937 139.73849967719912 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83b53589-e95f-4c3a-a7a5-abe81b54ad6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83b53589-e95f-4c3a-a7a5-abe81b54ad6f_0">
											<gml:posList>35.669523671877066 139.73850731926672 34.355 35.66952209746937 139.73849967719912 34.355 35.66952209746937 139.73849967719912 36.558 35.669523671877066 139.73850731926672 36.558 35.669523671877066 139.73850731926672 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee5f61c7-f1c0-4272-820f-c3b2397ef322">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee5f61c7-f1c0-4272-820f-c3b2397ef322_0">
											<gml:posList>35.66950424993148 139.73849923437064 34.355 35.669497842731275 139.73850121920748 34.355 35.669497842731275 139.73850121920748 36.558 35.66950424993148 139.73849923437064 36.558 35.66950424993148 139.73849923437064 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bdbab52-fe2a-4b05-a47f-95c00d15d0da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5bdbab52-fe2a-4b05-a47f-95c00d15d0da_0">
											<gml:posList>35.66949590525048 139.7385018179904 34.355 35.66948951607766 139.73850380280552 34.355 35.66948951607766 139.73850380280552 36.558 35.66949590525048 139.7385018179904 36.558 35.66949590525048 139.7385018179904 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5022346b-2e1e-4964-bb7b-ac0d7d8a4f34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5022346b-2e1e-4964-bb7b-ac0d7d8a4f34_0">
											<gml:posList>35.669487407379606 139.73850445702152 34.355 35.66948181121433 139.73850618683724 34.355 35.66948181121433 139.73850618683724 36.558 35.669487407379606 139.73850445702152 36.558 35.669487407379606 139.73850445702152 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bdf5fa1-6652-42b3-90ec-3d5e57b747b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bdf5fa1-6652-42b3-90ec-3d5e57b747b4_0">
											<gml:posList>35.669506828681214 139.7385117245037 34.355 35.66950424993148 139.73849923437064 34.355 35.66950424993148 139.73849923437064 36.558 35.669506828681214 139.7385117245037 36.558 35.669506828681214 139.7385117245037 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81f8ae55-2cd1-4c59-aa25-298b3e33d66e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81f8ae55-2cd1-4c59-aa25-298b3e33d66e_0">
											<gml:posList>35.669497842731275 139.73850121920748 36.558 35.6695004214808 139.7385137093396 36.558 35.669506828681214 139.7385117245037 36.558 35.66950424993148 139.73849923437064 36.558 35.669497842731275 139.73850121920748 36.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f81258f-3809-4206-b4c4-a0b383832318">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f81258f-3809-4206-b4c4-a0b383832318_0">
											<gml:posList>35.66948951607766 139.73850380280552 36.558 35.669492094818224 139.73851628189033 36.558 35.669498483999945 139.7385143081223 36.558 35.66949590525048 139.7385018179904 36.558 35.66948951607766 139.73850380280552 36.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8db220fd-bb9d-4460-b857-f18c61303860">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8db220fd-bb9d-4460-b857-f18c61303860_0">
											<gml:posList>35.669484389963344 139.73851867696703 36.558 35.66948997711507 139.73851694716282 36.558 35.669487407379606 139.73850445702152 36.558 35.66948181121433 139.73850618683724 36.558 35.669484389963344 139.73851867696703 36.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc461019-9eed-4085-b7b0-3dd0c31d0771">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc461019-9eed-4085-b7b0-3dd0c31d0771_0">
											<gml:posList>35.669484389963344 139.73851867696703 34.355 35.669484389963344 139.73851867696703 36.558 35.66948181121433 139.73850618683724 36.558 35.66948181121433 139.73850618683724 34.355 35.669484389963344 139.73851867696703 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f031149f-51a8-468e-9355-0c09d2ae98a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f031149f-51a8-468e-9355-0c09d2ae98a6_0">
											<gml:posList>35.6695004214808 139.7385137093396 34.355 35.669506828681214 139.7385117245037 34.355 35.669506828681214 139.7385117245037 36.558 35.6695004214808 139.7385137093396 36.558 35.6695004214808 139.7385137093396 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c524fdb-d99c-4cd2-8827-86f432653178">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c524fdb-d99c-4cd2-8827-86f432653178_0">
											<gml:posList>35.669492094818224 139.73851628189033 34.355 35.669498483999945 139.7385143081223 34.355 35.669498483999945 139.7385143081223 36.558 35.669492094818224 139.73851628189033 36.558 35.669492094818224 139.73851628189033 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be224a3e-1a63-4030-9fb7-b8025da824d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be224a3e-1a63-4030-9fb7-b8025da824d3_0">
											<gml:posList>35.66949889106138 139.73851614129978 34.355 35.669492474847154 139.73851812614578 34.355 35.669492474847154 139.73851812614578 36.558 35.66949889106138 139.73851614129978 36.558 35.66949889106138 139.73851614129978 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d010602c-6a9a-4def-b206-360a8e8d5a75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d010602c-6a9a-4def-b206-360a8e8d5a75_0">
											<gml:posList>35.669484389963344 139.73851867696703 34.355 35.66948997711507 139.73851694716282 34.355 35.66948997711507 139.73851694716282 36.558 35.669484389963344 139.73851867696703 36.558 35.669484389963344 139.73851867696703 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7eb5b80-5907-432f-818d-55b45dc7e086">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7eb5b80-5907-432f-818d-55b45dc7e086_0">
											<gml:posList>35.669490357135295 139.7385187803721 34.355 35.66948476998354 139.73852051017622 34.355 35.66948476998354 139.73852051017622 36.558 35.669490357135295 139.7385187803721 36.558 35.669490357135295 139.7385187803721 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28901e22-4a01-4324-97f6-37a068fd5e7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28901e22-4a01-4324-97f6-37a068fd5e7a_0">
											<gml:posList>35.66950351543756 139.73852801043006 36.558 35.66950971537476 139.73852609211713 36.558 35.66950713660913 139.73851357989088 36.558 35.66950093668083 139.73851550925085 36.558 35.66950351543756 139.73852801043006 36.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1887b10b-af02-48f2-a4d6-906c601b757f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1887b10b-af02-48f2-a4d6-906c601b757f_0">
											<gml:posList>35.669495053612316 139.7385306383699 36.558 35.66950146981805 139.73852864247868 36.558 35.66949889106138 139.73851614129978 36.558 35.669492474847154 139.73851812614578 36.558 35.669495053612316 139.7385306383699 36.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06cc7714-7154-4e21-b219-7cfe6cdeeb3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06cc7714-7154-4e21-b219-7cfe6cdeeb3f_0">
											<gml:posList>35.66948734874846 139.7385330223992 36.558 35.669492935900394 139.7385312925959 36.558 35.669490357135295 139.7385187803721 36.558 35.66948476998354 139.73852051017622 36.558 35.66948734874846 139.7385330223992 36.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e73adaac-c722-45cf-8826-225d8a06d780">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e73adaac-c722-45cf-8826-225d8a06d780_0">
											<gml:posList>35.66948476998354 139.73852051017622 34.355 35.66948734874846 139.7385330223992 34.355 35.66948734874846 139.7385330223992 36.558 35.66948476998354 139.73852051017622 36.558 35.66948476998354 139.73852051017622 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c0b828e-2180-42d7-9ed5-b9d0446d5bde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c0b828e-2180-42d7-9ed5-b9d0446d5bde_0">
											<gml:posList>35.669510222074 139.73852854376094 34.355 35.66950401312305 139.73853046208433 34.355 35.66950401312305 139.73853046208433 36.558 35.669510222074 139.73852854376094 36.558 35.669510222074 139.73852854376094 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cbe5a07-05d3-48a1-bf6c-a414a6202527">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cbe5a07-05d3-48a1-bf6c-a414a6202527_0">
											<gml:posList>35.669501868378646 139.7385311273885 34.355 35.669495244900716 139.7385331787553 34.355 35.669495244900716 139.7385331787553 36.558 35.669501868378646 139.7385311273885 36.558 35.669501868378646 139.7385311273885 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70f2228d-bfcb-4818-b4d9-25abeda429c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70f2228d-bfcb-4818-b4d9-25abeda429c4_0">
											<gml:posList>35.66949345160456 139.73853373318244 34.355 35.669487693235325 139.7385355184187 34.355 35.669487693235325 139.7385355184187 36.558 35.66949345160456 139.73853373318244 36.558 35.66949345160456 139.73853373318244 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c4c083b-bb24-4e23-891a-26da04daa81c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c4c083b-bb24-4e23-891a-26da04daa81c_0">
											<gml:posList>35.669495244900716 139.7385331787553 36.558 35.6694979774802 139.73854643088973 36.558 35.669504600958355 139.73854437952397 36.558 35.669501868378646 139.7385311273885 36.558 35.669495244900716 139.7385331787553 36.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-925049ad-6d0f-4a8f-b16f-5d38ea4294ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-925049ad-6d0f-4a8f-b16f-5d38ea4294ac_0">
											<gml:posList>35.669487693235325 139.7385355184187 36.558 35.66949042581455 139.73854877055194 36.558 35.66949618418398 139.7385469853166 36.558 35.66949345160456 139.73853373318244 36.558 35.669487693235325 139.7385355184187 36.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1652e30-14bb-47c1-a2ec-607281f1049e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1652e30-14bb-47c1-a2ec-607281f1049e_0">
											<gml:posList>35.66949042581455 139.73854877055194 34.355 35.66949042581455 139.73854877055194 36.558 35.669487693235325 139.7385355184187 36.558 35.669487693235325 139.7385355184187 34.355 35.66949042581455 139.73854877055194 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21d3d3ef-6548-41f9-95ac-e525047edcf7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21d3d3ef-6548-41f9-95ac-e525047edcf7_0">
											<gml:posList>35.6694979774802 139.73854643088973 34.355 35.669504600958355 139.73854437952397 34.355 35.669504600958355 139.73854437952397 36.558 35.6694979774802 139.73854643088973 36.558 35.6694979774802 139.73854643088973 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-555e4039-887b-44b0-961c-c0ee67baca2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-555e4039-887b-44b0-961c-c0ee67baca2a_0">
											<gml:posList>35.66949042581455 139.73854877055194 34.355 35.66949618418398 139.7385469853166 34.355 35.66949618418398 139.7385469853166 36.558 35.66949042581455 139.73854877055194 36.558 35.66949042581455 139.73854877055194 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dafc4cbd-63cb-4d55-b77b-1d64ac28ab8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dafc4cbd-63cb-4d55-b77b-1d64ac28ab8a_0">
											<gml:posList>35.66949878238837 139.73854984319476 34.355 35.66949878238837 139.73854984319476 36.558 35.66950551400517 139.73854775856302 36.558 35.66950551400517 139.73854775856302 34.355 35.66949878238837 139.73854984319476 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fbd6df8-88be-43d0-993b-b928d460e07c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fbd6df8-88be-43d0-993b-b928d460e07c_0">
											<gml:posList>35.66949114061149 139.73855221610162 34.355 35.66949114061149 139.73855221610162 36.558 35.66949689898098 139.7385504308665 36.558 35.66949689898098 139.7385504308665 34.355 35.66949114061149 139.73855221610162 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cdd7e49-f0f2-4432-a025-5dc2034b9dd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cdd7e49-f0f2-4432-a025-5dc2034b9dd4_0">
											<gml:posList>35.66950813798367 139.73856045852105 34.355 35.66950551400517 139.73854775856302 34.355 35.66950551400517 139.73854775856302 36.558 35.66950813798367 139.73856045852105 36.558 35.66950813798367 139.73856045852105 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5db3aa1c-5343-4e48-ba2d-8c19a582761c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5db3aa1c-5343-4e48-ba2d-8c19a582761c_0">
											<gml:posList>35.66950139735292 139.73856254316243 36.558 35.66950813798367 139.73856045852105 36.558 35.66950551400517 139.73854775856302 36.558 35.66949878238837 139.73854984319476 36.558 35.66950139735292 139.73856254316243 36.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4158848f-eda4-47ec-b112-525254b48ffb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4158848f-eda4-47ec-b112-525254b48ffb_0">
											<gml:posList>35.6694995229592 139.73856313082325 34.355 35.66949689898098 139.7385504308665 34.355 35.66949689898098 139.7385504308665 36.558 35.6694995229592 139.73856313082325 36.558 35.6694995229592 139.73856313082325 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c0435a3-5dc6-4f12-8362-bed5dd4b71a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c0435a3-5dc6-4f12-8362-bed5dd4b71a9_0">
											<gml:posList>35.6694995229592 139.73856313082325 36.558 35.66949689898098 139.7385504308665 36.558 35.66949114061149 139.73855221610162 36.558 35.6694937555758 139.73856491606816 36.558 35.6694995229592 139.73856313082325 36.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e20a3c5-fcf4-4885-a844-b7a1057610fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e20a3c5-fcf4-4885-a844-b7a1057610fd_0">
											<gml:posList>35.66949114061149 139.73855221610162 34.355 35.6694937555758 139.73856491606816 34.355 35.6694937555758 139.73856491606816 36.558 35.66949114061149 139.73855221610162 36.558 35.66949114061149 139.73855221610162 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39ef4e85-c7f2-4a36-a077-63be2d90bb6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39ef4e85-c7f2-4a36-a077-63be2d90bb6f_0">
											<gml:posList>35.66950139735292 139.73856254316243 34.355 35.66950813798367 139.73856045852105 34.355 35.66950813798367 139.73856045852105 36.558 35.66950139735292 139.73856254316243 36.558 35.66950139735292 139.73856254316243 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-299db14e-46f7-4bf4-9594-8f3103c6d488">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-299db14e-46f7-4bf4-9594-8f3103c6d488_0">
											<gml:posList>35.6694937555758 139.73856491606816 34.355 35.6694995229592 139.73856313082325 34.355 35.6694995229592 139.73856313082325 36.558 35.6694937555758 139.73856491606816 36.558 35.6694937555758 139.73856491606816 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f718169f-0a1b-4f5e-ac06-001fe0960d9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f718169f-0a1b-4f5e-ac06-001fe0960d9f_0">
											<gml:posList>35.669523671877066 139.73850731926672 36.558 35.66952209746937 139.73849967719912 36.558 35.669512238848206 139.7385027265479 36.558 35.66951382226944 139.73851036860395 36.558 35.669523671877066 139.73850731926672 36.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb074d4a-b3ba-4e94-a244-8608b35a007b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb074d4a-b3ba-4e94-a244-8608b35a007b_0">
											<gml:posList>35.669512238848206 139.7385027265479 34.355 35.66951382226944 139.73851036860395 34.355 35.66951382226944 139.73851036860395 36.558 35.669512238848206 139.7385027265479 36.558 35.669512238848206 139.7385027265479 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fd2a7f6-957d-4379-81e2-4adb1ee58238">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fd2a7f6-957d-4379-81e2-4adb1ee58238_0">
											<gml:posList>35.66952546419669 139.73851697147467 34.355 35.669524007429025 139.73850991471306 34.355 35.669524007429025 139.73850991471306 36.558 35.66952546419669 139.73851697147467 36.558 35.66952546419669 139.73851697147467 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eafe3666-e64c-4de5-af85-a0265cf3ca0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eafe3666-e64c-4de5-af85-a0265cf3ca0e_0">
											<gml:posList>35.66952546419669 139.73851697147467 36.558 35.669524007429025 139.73850991471306 36.558 35.66951433805231 139.73851290860617 36.558 35.66951579481979 139.73851996536698 36.558 35.66952546419669 139.73851697147467 36.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-713e58a6-5106-4822-9928-94b9db0f84f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-713e58a6-5106-4822-9928-94b9db0f84f8_0">
											<gml:posList>35.66951433805231 139.73851290860617 34.355 35.66951579481979 139.73851996536698 34.355 35.66951579481979 139.73851996536698 36.558 35.66951433805231 139.73851290860617 36.558 35.66951433805231 139.73851290860617 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f4bf95e-5c2a-4766-abfc-a892672f3f7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f4bf95e-5c2a-4766-abfc-a892672f3f7d_0">
											<gml:posList>35.66951579481979 139.73851996536698 34.355 35.66952546419669 139.73851697147467 34.355 35.66952546419669 139.73851697147467 36.558 35.66951579481979 139.73851996536698 36.558 35.66951579481979 139.73851996536698 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3092889f-caba-4ab3-9151-1f1a39bbf246">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3092889f-caba-4ab3-9151-1f1a39bbf246_0">
											<gml:posList>35.66950971537476 139.73852609211713 34.355 35.66950713660913 139.73851357989088 34.355 35.66950713660913 139.73851357989088 36.558 35.66950971537476 139.73852609211713 36.558 35.66950971537476 139.73852609211713 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0428bd6-ffea-47f0-b43b-9c8e827ddcca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0428bd6-ffea-47f0-b43b-9c8e827ddcca_0">
											<gml:posList>35.669512954645306 139.73854178485152 34.355 35.669510222074 139.73852854376094 34.355 35.669510222074 139.73852854376094 36.558 35.669512954645306 139.73854178485152 36.558 35.669512954645306 139.73854178485152 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b100901-26e2-4f9a-b64d-136b446fb016">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b100901-26e2-4f9a-b64d-136b446fb016_0">
											<gml:posList>35.66950675471655 139.73854371420944 36.558 35.669512954645306 139.73854178485152 36.558 35.669510222074 139.73852854376094 36.558 35.66950401312305 139.73853046208433 36.558 35.66950675471655 139.73854371420944 36.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7502747-3bb8-4c95-90a4-36b6761810f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7502747-3bb8-4c95-90a4-36b6761810f2_0">
											<gml:posList>35.66950675471655 139.73854371420944 34.355 35.669512954645306 139.73854178485152 34.355 35.669512954645306 139.73854178485152 36.558 35.66950675471655 139.73854371420944 36.558 35.66950675471655 139.73854371420944 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1983e8ca-04d3-4839-81b5-75cc70d3c0f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1983e8ca-04d3-4839-81b5-75cc70d3c0f2_0">
											<gml:posList>35.669565823263774 139.7385456989614 38.364 35.6695583433689 139.7385476077411 38.364 35.6695583433689 139.7385476077411 40.611 35.669565823263774 139.7385456989614 40.611 35.669565823263774 139.7385456989614 38.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-487151bd-351c-47ea-92dc-331811de6ca7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-487151bd-351c-47ea-92dc-331811de6ca7_0">
											<gml:posList>35.66956699144236 139.73855256828395 38.364 35.669565823263774 139.7385456989614 38.364 35.669565823263774 139.7385456989614 40.611 35.66956699144236 139.73855256828395 40.611 35.66956699144236 139.73855256828395 38.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3600b52-68f1-4e89-9be1-46f71d57a951">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3600b52-68f1-4e89-9be1-46f71d57a951_0">
											<gml:posList>35.66955951155608 139.73855448810917 40.611 35.66956699144236 139.73855256828395 40.611 35.669565823263774 139.7385456989614 40.611 35.6695583433689 139.7385476077411 40.611 35.66955951155608 139.73855448810917 40.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5de81e85-7996-47b3-b025-0603d8b15115">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5de81e85-7996-47b3-b025-0603d8b15115_0">
											<gml:posList>35.6695583433689 139.7385476077411 38.364 35.66955951155608 139.73855448810917 38.364 35.66955951155608 139.73855448810917 40.611 35.6695583433689 139.7385476077411 40.611 35.6695583433689 139.7385476077411 38.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac7c9d7e-2753-4b3b-8969-5710d26a554e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac7c9d7e-2753-4b3b-8969-5710d26a554e_0">
											<gml:posList>35.66955951155608 139.73855448810917 38.364 35.66956699144236 139.73855256828395 38.364 35.66956699144236 139.73855256828395 40.611 35.66955951155608 139.73855448810917 40.611 35.66955951155608 139.73855448810917 38.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b9bab47b-1199-4379-ad86-a2192f369ccd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9bab47b-1199-4379-ad86-a2192f369ccd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9bab47b-1199-4379-ad86-a2192f369ccd">
											<gml:posList>35.66946746895231 139.73875653127715 17.02 35.66941914498758 139.73851412579324 17.02 35.669561258869265 139.7384726451449 17.02 35.669611925096284 139.73871328088453 17.02 35.66962359878885 139.73877181173012 17.02 35.66946679668382 139.73881872180135 17.02 35.66945512301392 139.7387601910633 17.02 35.66946746895231 139.73875653127715 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d75597d-17d3-4dc5-9f2b-35feb554c208">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d75597d-17d3-4dc5-9f2b-35feb554c208">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d75597d-17d3-4dc5-9f2b-35feb554c208">
											<gml:posList>35.669490754982775 139.7387495889284 31.783 35.66948770903832 139.73875047621246 31.418 35.66945512301392 139.7387601910633 27.521 35.669490754982775 139.7387495889284 31.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-496165f2-fffd-4ee5-8ee0-2eaabbf2e51a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-496165f2-fffd-4ee5-8ee0-2eaabbf2e51a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-496165f2-fffd-4ee5-8ee0-2eaabbf2e51a">
											<gml:posList>35.6694573183786 139.73850297928757 35.082 35.6694633701537 139.73850750104458 35.082 35.66955765013537 139.73847997300913 35.082 35.669561258869265 139.7384726451449 35.082 35.6694573183786 139.73850297928757 35.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-73fbee72-39a6-4feb-8f0c-1b5f112614c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73fbee72-39a6-4feb-8f0c-1b5f112614c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73fbee72-39a6-4feb-8f0c-1b5f112614c6">
											<gml:posList>35.6694573183786 139.73850297928757 31.778 35.66944055669767 139.73850788150122 31.778 35.66944496701807 139.73851119012448 31.772 35.66945814187218 139.73850709852096 31.778 35.6694573183786 139.73850297928757 31.778</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-40c89b68-74ec-4440-96ee-96dbe70e2bee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40c89b68-74ec-4440-96ee-96dbe70e2bee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40c89b68-74ec-4440-96ee-96dbe70e2bee">
											<gml:posList>35.669529750614835 139.7385117415806 39.261 35.669535595013 139.73851618626455 39.261 35.66956078265522 139.73850889916062 39.261 35.66956427436036 139.73850175922036 39.261 35.669529750614835 139.7385117415806 39.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b7bf3f70-9583-4497-9b3f-7ff278b24f42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7bf3f70-9583-4497-9b3f-7ff278b24f42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7bf3f70-9583-4497-9b3f-7ff278b24f42">
											<gml:posList>35.66944055669767 139.73850788150122 28.145 35.66941914498758 139.73851412579324 28.145 35.669424051358355 139.7385178093977 28.145 35.66944149793487 139.73851271859297 28.145 35.66944055669767 139.73850788150122 28.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a5cadb4-7ab1-4ed2-9bdc-0109141babe2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a5cadb4-7ab1-4ed2-9bdc-0109141babe2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a5cadb4-7ab1-4ed2-9bdc-0109141babe2">
											<gml:posList>35.66956427436036 139.73850175922036 39.261 35.66956078265522 139.73850889916062 39.261 35.66957857707848 139.73859073007884 39.261 35.66958456564983 139.73859511937013 39.261 35.66956427436036 139.73850175922036 39.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b8030db-57be-461a-91f1-4f12de2dfea4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b8030db-57be-461a-91f1-4f12de2dfea4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b8030db-57be-461a-91f1-4f12de2dfea4">
											<gml:posList>35.669551460929064 139.73859857174452 38.364 35.66957857707848 139.73859073007884 38.364 35.66956078265522 139.73850889916062 38.364 35.669535595013 139.73851618626455 38.364 35.669551460929064 139.73859857174452 38.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-472debb2-c0bd-493f-8466-ce1a808e8d1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-472debb2-c0bd-493f-8466-ce1a808e8d1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-472debb2-c0bd-493f-8466-ce1a808e8d1f">
											<gml:posList>35.669547852065826 139.7386057449563 39.261 35.669551460929064 139.73859857174452 39.261 35.669535595013 139.73851618626455 39.261 35.669529750614835 139.7385117415806 39.261 35.669547852065826 139.7386057449563 39.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18a6b666-1f2e-4326-b3b5-577669d879be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18a6b666-1f2e-4326-b3b5-577669d879be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18a6b666-1f2e-4326-b3b5-577669d879be">
											<gml:posList>35.66958456564983 139.73859511937013 35.082 35.66958170894262 139.7385959401606 35.082 35.669605331160156 139.73870704758986 35.082 35.669611925096284 139.73871328088453 35.082 35.669561258869265 139.7384726451449 35.082 35.66955765013537 139.73847997300913 35.082 35.66956224673366 139.73850234706424 35.082 35.66956427436036 139.73850175922036 35.082 35.66958456564983 139.73859511937013 35.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba79e884-a5b5-4631-bb71-ec573a804651">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba79e884-a5b5-4631-bb71-ec573a804651">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba79e884-a5b5-4631-bb71-ec573a804651">
											<gml:posList>35.66958456564983 139.73859511937013 39.261 35.66957857707848 139.73859073007884 39.261 35.669551460929064 139.73859857174452 39.261 35.669547852065826 139.7386057449563 39.261 35.66958456564983 139.73859511937013 39.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-857ab913-6841-4782-9fc7-e43ea2b3a815">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-857ab913-6841-4782-9fc7-e43ea2b3a815">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-857ab913-6841-4782-9fc7-e43ea2b3a815">
											<gml:posList>35.669529750614835 139.7385117415806 34.355 35.66956224673366 139.73850234706424 34.355 35.66955765013537 139.73847997300913 34.355 35.6694633701537 139.73850750104458 34.355 35.66950926887417 139.73873771458122 34.355 35.669605331160156 139.73870704758986 34.355 35.669547852065826 139.7386057449563 34.355 35.669529750614835 139.7385117415806 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3864758e-eae3-4826-a4df-9f7164967246">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3864758e-eae3-4826-a4df-9f7164967246">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3864758e-eae3-4826-a4df-9f7164967246">
											<gml:posList>35.66950559708876 139.73874511982615 35.082 35.66950926887417 139.73873771458122 35.082 35.6694633701537 139.73850750104458 35.082 35.6694573183786 139.73850297928757 35.082 35.66950559708876 139.73874511982615 35.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ac5e7288-7960-41bc-a7f0-31e628a53387">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac5e7288-7960-41bc-a7f0-31e628a53387">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac5e7288-7960-41bc-a7f0-31e628a53387">
											<gml:posList>35.66950473735754 139.7387407576156 31.406 35.6694581508859 139.7385070985103 31.406 35.66944497603181 139.73851119011383 31.401 35.669490417926205 139.73874507145612 31.401 35.66950473735754 139.7387407576156 31.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-49dd2067-3da9-4c72-946e-8e04ab578cae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49dd2067-3da9-4c72-946e-8e04ab578cae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49dd2067-3da9-4c72-946e-8e04ab578cae">
											<gml:posList>35.66948770903832 139.73875047621246 31.778 35.66949040891248 139.73874507146675 31.772 35.66944496701807 139.73851119012448 31.772 35.66944055669767 139.73850788150122 31.778 35.66948770903832 139.73875047621246 31.778</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d68173a0-d8de-4b4e-92b8-4d66446b6575">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d68173a0-d8de-4b4e-92b8-4d66446b6575">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d68173a0-d8de-4b4e-92b8-4d66446b6575">
											<gml:posList>35.66948677685043 139.73874567224283 27.627 35.66944149793487 139.73851271859297 27.627 35.669424051358355 139.7385178093977 27.627 35.66947043876992 139.73875052972335 27.627 35.66948677685043 139.73874567224283 27.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3cad65c8-186e-416e-b4bc-6ab8cd4addb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cad65c8-186e-416e-b4bc-6ab8cd4addb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cad65c8-186e-416e-b4bc-6ab8cd4addb3">
											<gml:posList>35.66946746895231 139.73875653127715 28.145 35.66947043876992 139.73875052972335 28.145 35.669424051358355 139.7385178093977 28.145 35.66941914498758 139.73851412579324 28.145 35.66946746895231 139.73875653127715 28.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c039de48-da57-4a1e-b925-62d2c96e3c6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c039de48-da57-4a1e-b925-62d2c96e3c6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c039de48-da57-4a1e-b925-62d2c96e3c6f">
											<gml:posList>35.66958170894262 139.7385959401606 34.355 35.669547852065826 139.7386057449563 34.355 35.669605331160156 139.73870704758986 34.355 35.66958170894262 139.7385959401606 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ed45421-1672-42ee-b04c-1079faa727eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ed45421-1672-42ee-b04c-1079faa727eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ed45421-1672-42ee-b04c-1079faa727eb">
											<gml:posList>35.669611925096284 139.73871328088453 35.082 35.669605331160156 139.73870704758986 35.082 35.66950926887417 139.73873771458122 35.082 35.66950559708876 139.73874511982615 35.082 35.669611925096284 139.73871328088453 35.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9052343-4fa0-418f-a733-f07116911161">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9052343-4fa0-418f-a733-f07116911161">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9052343-4fa0-418f-a733-f07116911161">
											<gml:posList>35.66950731830215 139.73874459862708 34.777 35.66951074552147 139.73874714624222 34.777 35.6696098462158 139.73871746982985 34.777 35.669611925096284 139.73871328088453 34.777 35.66950731830215 139.73874459862708 34.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41c81bb6-344a-493f-999d-8b390341a03f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41c81bb6-344a-493f-999d-8b390341a03f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41c81bb6-344a-493f-999d-8b390341a03f">
											<gml:posList>35.669611925096284 139.73871328088453 34.777 35.6696098462158 139.73871746982985 34.777 35.669620180575144 139.7387692530536 34.777 35.66962359878885 139.73877181173012 34.777 35.669611925096284 139.73871328088453 34.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38e41567-1f34-4095-8544-123a3037c116">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38e41567-1f34-4095-8544-123a3037c116">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38e41567-1f34-4095-8544-123a3037c116">
											<gml:posList>35.66950559708876 139.73874511982615 31.778 35.66950472834382 139.73874075762623 31.778 35.66949040891248 139.73874507146675 31.772 35.66950559708876 139.73874511982615 31.778</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dfcdb87a-2f58-4e41-ac98-f0ebc4853440">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfcdb87a-2f58-4e41-ac98-f0ebc4853440">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfcdb87a-2f58-4e41-ac98-f0ebc4853440">
											<gml:posList>35.66949040891248 139.73874507146675 31.772 35.669490754982775 139.7387495889284 31.783 35.66950559708876 139.73874511982615 31.778 35.66949040891248 139.73874507146675 31.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36976c63-662a-443e-967e-a537580f76c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36976c63-662a-443e-967e-a537580f76c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36976c63-662a-443e-967e-a537580f76c6">
											<gml:posList>35.66948770903832 139.73875047621246 31.778 35.669490754982775 139.7387495889284 31.783 35.66949040891248 139.73874507146675 31.772 35.66948770903832 139.73875047621246 31.778</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7bec945c-ad6c-45c0-b08e-d6d6b222da66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bec945c-ad6c-45c0-b08e-d6d6b222da66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bec945c-ad6c-45c0-b08e-d6d6b222da66">
											<gml:posList>35.66948770903832 139.73875047621246 28.145 35.66948677685043 139.73874567224283 28.145 35.66947043876992 139.73875052972335 28.145 35.66946746895231 139.73875653127715 28.145 35.66948770903832 139.73875047621246 28.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf652d55-0bcc-48c5-bfad-d4076a759ba8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf652d55-0bcc-48c5-bfad-d4076a759ba8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf652d55-0bcc-48c5-bfad-d4076a759ba8">
											<gml:posList>35.669620180575144 139.7387692530536 34.438 35.6696098462158 139.73871746982985 34.438 35.66951074552147 139.73874714624222 34.438 35.669521061823346 139.73879890733483 34.438 35.669620180575144 139.7387692530536 34.438</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d7fb1332-3d92-436d-80fa-7c4d26197b00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7fb1332-3d92-436d-80fa-7c4d26197b00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7fb1332-3d92-436d-80fa-7c4d26197b00">
											<gml:posList>35.66951897393479 139.73880310732991 34.777 35.669521061823346 139.73879890733483 34.777 35.66951074552147 139.73874714624222 34.777 35.66950731830215 139.73874459862708 34.777 35.66951897393479 139.73880310732991 34.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20b442a5-a686-4a37-9566-f39727102278">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20b442a5-a686-4a37-9566-f39727102278">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20b442a5-a686-4a37-9566-f39727102278">
											<gml:posList>35.66951897393479 139.73880310732991 32.227 35.66950731830215 139.73874459862708 32.227 35.66950559708876 139.73874511982615 32.227 35.66949435960455 139.73874848006253 32.227 35.669506015235314 139.7388069887565 32.227 35.66951897393479 139.73880310732991 32.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-be7f9908-3594-4a18-a91a-ae0085b60530">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be7f9908-3594-4a18-a91a-ae0085b60530">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be7f9908-3594-4a18-a91a-ae0085b60530">
											<gml:posList>35.669490754982775 139.7387495889284 31.783 35.669506015235314 139.7388069887565 32.227 35.66949435960455 139.73874848006253 32.227 35.669490754982775 139.7387495889284 31.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd6cf247-ebbc-4edd-af0c-37eb373996c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd6cf247-ebbc-4edd-af0c-37eb373996c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd6cf247-ebbc-4edd-af0c-37eb373996c9">
											<gml:posList>35.669490754982775 139.7387495889284 31.783 35.66945512301392 139.7387601910633 27.521 35.669506015235314 139.7388069887565 32.227 35.669490754982775 139.7387495889284 31.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2e3ccf2a-f50f-45dc-bc96-261da9267606">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e3ccf2a-f50f-45dc-bc96-261da9267606">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e3ccf2a-f50f-45dc-bc96-261da9267606">
											<gml:posList>35.66962359878885 139.73877181173012 34.777 35.669620180575144 139.7387692530536 34.777 35.669521061823346 139.73879890733483 34.777 35.66951897393479 139.73880310732991 34.777 35.66962359878885 139.73877181173012 34.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d00bff0-ad5b-4ba8-9d25-ae13a23b1c87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d00bff0-ad5b-4ba8-9d25-ae13a23b1c87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d00bff0-ad5b-4ba8-9d25-ae13a23b1c87">
											<gml:posList>35.66945512301392 139.7387601910633 27.521 35.66946679668382 139.73881872180135 27.521 35.669506015235314 139.7388069887565 32.227 35.66945512301392 139.7387601910633 27.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2367261a-0e90-4f6e-8e6a-ab6d740047d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2367261a-0e90-4f6e-8e6a-ab6d740047d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2367261a-0e90-4f6e-8e6a-ab6d740047d5">
											<gml:posList>35.66955765013537 139.73847997300913 35.082 35.66955765013537 139.73847997300913 34.355 35.66956224673366 139.73850234706424 34.355 35.66956224673366 139.73850234706424 35.082 35.66955765013537 139.73847997300913 35.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c410f041-b0ec-439d-8ca6-c1559cb4490b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c410f041-b0ec-439d-8ca6-c1559cb4490b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c410f041-b0ec-439d-8ca6-c1559cb4490b">
											<gml:posList>35.669561258869265 139.7384726451449 35.082 35.669561258869265 139.7384726451449 17.02 35.66941914498758 139.73851412579324 17.02 35.66941914498758 139.73851412579324 28.145 35.66944055669767 139.73850788150122 28.145 35.66944055669767 139.73850788150122 31.778 35.6694573183786 139.73850297928757 31.778 35.6694573183786 139.73850297928757 35.082 35.669561258869265 139.7384726451449 35.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2f7e7c5-f2f8-4122-8b6d-c8787837c194">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2f7e7c5-f2f8-4122-8b6d-c8787837c194">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2f7e7c5-f2f8-4122-8b6d-c8787837c194">
											<gml:posList>35.6694633701537 139.73850750104458 35.082 35.6694633701537 139.73850750104458 34.355 35.66955765013537 139.73847997300913 34.355 35.66955765013537 139.73847997300913 35.082 35.6694633701537 139.73850750104458 35.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c5de15a-b56d-400c-acdf-6652a5be411d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c5de15a-b56d-400c-acdf-6652a5be411d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c5de15a-b56d-400c-acdf-6652a5be411d">
											<gml:posList>35.669529750614835 139.7385117415806 34.355 35.669529750614835 139.7385117415806 39.261 35.66956427436036 139.73850175922036 39.261 35.66956427436036 139.73850175922036 35.082 35.66956224673366 139.73850234706424 35.082 35.66956224673366 139.73850234706424 34.355 35.669529750614835 139.7385117415806 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c38685b-3b59-4574-b2bf-3c037bfcf626">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c38685b-3b59-4574-b2bf-3c037bfcf626">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c38685b-3b59-4574-b2bf-3c037bfcf626">
											<gml:posList>35.66944496701807 139.73851119012448 31.772 35.66944497603181 139.73851119011383 31.401 35.6694581508859 139.7385070985103 31.406 35.66945814187218 139.73850709852096 31.778 35.66944496701807 139.73851119012448 31.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bbffee1f-fcfa-4153-8e00-1dc1e4b32b9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbffee1f-fcfa-4153-8e00-1dc1e4b32b9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbffee1f-fcfa-4153-8e00-1dc1e4b32b9b">
											<gml:posList>35.669535595013 139.73851618626455 39.261 35.669535595013 139.73851618626455 38.364 35.66956078265522 139.73850889916062 38.364 35.66956078265522 139.73850889916062 39.261 35.669535595013 139.73851618626455 39.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd8bf1e2-dd49-4ff4-a53f-2163f240b3b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd8bf1e2-dd49-4ff4-a53f-2163f240b3b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd8bf1e2-dd49-4ff4-a53f-2163f240b3b8">
											<gml:posList>35.669424051358355 139.7385178093977 28.145 35.669424051358355 139.7385178093977 27.627 35.66944149793487 139.73851271859297 27.627 35.66944149793487 139.73851271859297 28.145 35.669424051358355 139.7385178093977 28.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72e3b0fe-52b6-4693-871a-8631b6ed9a85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72e3b0fe-52b6-4693-871a-8631b6ed9a85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72e3b0fe-52b6-4693-871a-8631b6ed9a85">
											<gml:posList>35.66956427436036 139.73850175922036 39.261 35.66958456564983 139.73859511937013 39.261 35.66958456564983 139.73859511937013 35.082 35.66956427436036 139.73850175922036 35.082 35.66956427436036 139.73850175922036 39.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7734083a-0f81-468c-a93d-78155dd2ddd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7734083a-0f81-468c-a93d-78155dd2ddd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7734083a-0f81-468c-a93d-78155dd2ddd4">
											<gml:posList>35.66956078265522 139.73850889916062 39.261 35.66956078265522 139.73850889916062 38.364 35.66957857707848 139.73859073007884 38.364 35.66957857707848 139.73859073007884 39.261 35.66956078265522 139.73850889916062 39.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05f153b4-cba3-437f-ae76-6632665fecda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05f153b4-cba3-437f-ae76-6632665fecda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05f153b4-cba3-437f-ae76-6632665fecda">
											<gml:posList>35.669551460929064 139.73859857174452 39.261 35.669551460929064 139.73859857174452 38.364 35.669535595013 139.73851618626455 38.364 35.669535595013 139.73851618626455 39.261 35.669551460929064 139.73859857174452 39.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f53bf2b-075e-415c-8028-2d397ae9535c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f53bf2b-075e-415c-8028-2d397ae9535c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f53bf2b-075e-415c-8028-2d397ae9535c">
											<gml:posList>35.669529750614835 139.7385117415806 34.355 35.669547852065826 139.7386057449563 34.355 35.669547852065826 139.7386057449563 39.261 35.669529750614835 139.7385117415806 39.261 35.669529750614835 139.7385117415806 34.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41816da0-8981-4eed-9745-e4f930e4eba2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41816da0-8981-4eed-9745-e4f930e4eba2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41816da0-8981-4eed-9745-e4f930e4eba2">
											<gml:posList>35.669561258869265 139.7384726451449 35.082 35.669611925096284 139.73871328088453 35.082 35.669611925096284 139.73871328088453 34.777 35.669611925096284 139.73871328088453 17.02 35.669561258869265 139.7384726451449 17.02 35.669561258869265 139.7384726451449 35.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87d617f8-54ad-4a85-bb1f-6a7096371518">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87d617f8-54ad-4a85-bb1f-6a7096371518">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87d617f8-54ad-4a85-bb1f-6a7096371518">
											<gml:posList>35.66957857707848 139.73859073007884 39.261 35.66957857707848 139.73859073007884 38.364 35.669551460929064 139.73859857174452 38.364 35.669551460929064 139.73859857174452 39.261 35.66957857707848 139.73859073007884 39.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83534728-54ee-4c59-9174-3b962b71b0a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83534728-54ee-4c59-9174-3b962b71b0a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83534728-54ee-4c59-9174-3b962b71b0a1">
											<gml:posList>35.66958456564983 139.73859511937013 39.261 35.669547852065826 139.7386057449563 39.261 35.669547852065826 139.7386057449563 34.355 35.66958170894262 139.7385959401606 34.355 35.66958170894262 139.7385959401606 35.082 35.66958456564983 139.73859511937013 35.082 35.66958456564983 139.73859511937013 39.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-593c1047-0aa2-4bac-bc8d-f059ce64f0b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-593c1047-0aa2-4bac-bc8d-f059ce64f0b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-593c1047-0aa2-4bac-bc8d-f059ce64f0b9">
											<gml:posList>35.66950926887417 139.73873771458122 35.082 35.66950926887417 139.73873771458122 34.355 35.6694633701537 139.73850750104458 34.355 35.6694633701537 139.73850750104458 35.082 35.66950926887417 139.73873771458122 35.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-531242a9-3044-4451-b0b0-fd64233a5dc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-531242a9-3044-4451-b0b0-fd64233a5dc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-531242a9-3044-4451-b0b0-fd64233a5dc0">
											<gml:posList>35.66945814187218 139.73850709852096 31.778 35.6694581508859 139.7385070985103 31.406 35.66950473735754 139.7387407576156 31.406 35.66950472834382 139.73874075762623 31.778 35.66950559708876 139.73874511982615 31.778 35.66950559708876 139.73874511982615 32.227 35.66950559708876 139.73874511982615 35.082 35.6694573183786 139.73850297928757 35.082 35.6694573183786 139.73850297928757 31.778 35.66945814187218 139.73850709852096 31.778</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-090ef6c5-b102-4789-9576-5c3d1f2d5c67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-090ef6c5-b102-4789-9576-5c3d1f2d5c67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-090ef6c5-b102-4789-9576-5c3d1f2d5c67">
											<gml:posList>35.66949040891248 139.73874507146675 31.772 35.669490417926205 139.73874507145612 31.401 35.66944497603181 139.73851119011383 31.401 35.66944496701807 139.73851119012448 31.772 35.66949040891248 139.73874507146675 31.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afb21c79-8b89-4168-9c5d-1797f4300fe8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afb21c79-8b89-4168-9c5d-1797f4300fe8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afb21c79-8b89-4168-9c5d-1797f4300fe8">
											<gml:posList>35.66944149793487 139.73851271859297 28.145 35.66944149793487 139.73851271859297 27.627 35.66948677685043 139.73874567224283 27.627 35.66948677685043 139.73874567224283 28.145 35.66948770903832 139.73875047621246 28.145 35.66948770903832 139.73875047621246 31.418 35.66948770903832 139.73875047621246 31.778 35.66944055669767 139.73850788150122 31.778 35.66944055669767 139.73850788150122 28.145 35.66944149793487 139.73851271859297 28.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20f4303d-67f3-4e25-ac9d-e1bc5e26fb24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20f4303d-67f3-4e25-ac9d-e1bc5e26fb24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20f4303d-67f3-4e25-ac9d-e1bc5e26fb24">
											<gml:posList>35.66947043876992 139.73875052972335 28.145 35.66947043876992 139.73875052972335 27.627 35.669424051358355 139.7385178093977 27.627 35.669424051358355 139.7385178093977 28.145 35.66947043876992 139.73875052972335 28.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-028cba29-0dfc-4095-8036-4a1f8d74a749">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-028cba29-0dfc-4095-8036-4a1f8d74a749">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-028cba29-0dfc-4095-8036-4a1f8d74a749">
											<gml:posList>35.66941914498758 139.73851412579324 28.145 35.66941914498758 139.73851412579324 17.02 35.66946746895231 139.73875653127715 17.02 35.66946746895231 139.73875653127715 27.521 35.66946746895231 139.73875653127715 28.145 35.66941914498758 139.73851412579324 28.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1ab5b91-1475-43b4-b6e4-5ab53243f20c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1ab5b91-1475-43b4-b6e4-5ab53243f20c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1ab5b91-1475-43b4-b6e4-5ab53243f20c">
											<gml:posList>35.66958170894262 139.7385959401606 35.082 35.66958170894262 139.7385959401606 34.355 35.669605331160156 139.73870704758986 34.355 35.669605331160156 139.73870704758986 35.082 35.66958170894262 139.7385959401606 35.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1a112d2-14b0-43a8-8f42-ba6f02605a02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1a112d2-14b0-43a8-8f42-ba6f02605a02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1a112d2-14b0-43a8-8f42-ba6f02605a02">
											<gml:posList>35.669605331160156 139.73870704758986 35.082 35.669605331160156 139.73870704758986 34.355 35.66950926887417 139.73873771458122 34.355 35.66950926887417 139.73873771458122 35.082 35.669605331160156 139.73870704758986 35.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b371a688-980b-428b-a3af-8edb8d796b95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b371a688-980b-428b-a3af-8edb8d796b95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b371a688-980b-428b-a3af-8edb8d796b95">
											<gml:posList>35.66950731830215 139.73874459862708 34.777 35.669611925096284 139.73871328088453 34.777 35.669611925096284 139.73871328088453 35.082 35.66950559708876 139.73874511982615 35.082 35.66950559708876 139.73874511982615 32.227 35.66950731830215 139.73874459862708 32.227 35.66950731830215 139.73874459862708 34.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b4723d2-06f3-424c-8412-6b9b68c5fc08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b4723d2-06f3-424c-8412-6b9b68c5fc08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b4723d2-06f3-424c-8412-6b9b68c5fc08">
											<gml:posList>35.66951074552147 139.73874714624222 34.777 35.66951074552147 139.73874714624222 34.438 35.6696098462158 139.73871746982985 34.438 35.6696098462158 139.73871746982985 34.777 35.66951074552147 139.73874714624222 34.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0977b37-958b-4935-a537-cffe4af8afc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0977b37-958b-4935-a537-cffe4af8afc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0977b37-958b-4935-a537-cffe4af8afc5">
											<gml:posList>35.66962359878885 139.73877181173012 17.02 35.669611925096284 139.73871328088453 17.02 35.669611925096284 139.73871328088453 34.777 35.66962359878885 139.73877181173012 34.777 35.66962359878885 139.73877181173012 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc97b1c3-0a7d-4963-9c71-181cf1faae97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc97b1c3-0a7d-4963-9c71-181cf1faae97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc97b1c3-0a7d-4963-9c71-181cf1faae97">
											<gml:posList>35.66950472834382 139.73874075762623 31.778 35.66950473735754 139.7387407576156 31.406 35.669490417926205 139.73874507145612 31.401 35.66949040891248 139.73874507146675 31.772 35.66950472834382 139.73874075762623 31.778</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b90508b-4ab3-468f-8721-411eb1e3e7c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b90508b-4ab3-468f-8721-411eb1e3e7c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b90508b-4ab3-468f-8721-411eb1e3e7c4">
											<gml:posList>35.6696098462158 139.73871746982985 34.777 35.6696098462158 139.73871746982985 34.438 35.669620180575144 139.7387692530536 34.438 35.669620180575144 139.7387692530536 34.777 35.6696098462158 139.73871746982985 34.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7bb36660-f719-40b8-b812-d215371dd84f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bb36660-f719-40b8-b812-d215371dd84f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bb36660-f719-40b8-b812-d215371dd84f">
											<gml:posList>35.66949435960455 139.73874848006253 32.227 35.66950559708876 139.73874511982615 32.227 35.66950559708876 139.73874511982615 31.778 35.669490754982775 139.7387495889284 31.783 35.66949435960455 139.73874848006253 32.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fbb9544d-60c2-49a2-bc54-e291130c98fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbb9544d-60c2-49a2-bc54-e291130c98fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbb9544d-60c2-49a2-bc54-e291130c98fb">
											<gml:posList>35.66948677685043 139.73874567224283 28.145 35.66948677685043 139.73874567224283 27.627 35.66947043876992 139.73875052972335 27.627 35.66947043876992 139.73875052972335 28.145 35.66948677685043 139.73874567224283 28.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e70e44d7-8fb2-4161-85ff-ec3177dd89d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e70e44d7-8fb2-4161-85ff-ec3177dd89d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e70e44d7-8fb2-4161-85ff-ec3177dd89d7">
											<gml:posList>35.669490754982775 139.7387495889284 31.783 35.66948770903832 139.73875047621246 31.778 35.66948770903832 139.73875047621246 31.418 35.669490754982775 139.7387495889284 31.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e894d2f-08ad-4e9a-a101-8882c1d0b9f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e894d2f-08ad-4e9a-a101-8882c1d0b9f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e894d2f-08ad-4e9a-a101-8882c1d0b9f2">
											<gml:posList>35.66946746895231 139.73875653127715 28.145 35.66946746895231 139.73875653127715 27.521 35.66945512301392 139.7387601910633 27.521 35.66948770903832 139.73875047621246 31.418 35.66948770903832 139.73875047621246 28.145 35.66946746895231 139.73875653127715 28.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c648048c-8f54-4ac0-a2b4-1019f4ca0129">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c648048c-8f54-4ac0-a2b4-1019f4ca0129">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c648048c-8f54-4ac0-a2b4-1019f4ca0129">
											<gml:posList>35.66946746895231 139.73875653127715 17.02 35.66945512301392 139.7387601910633 17.02 35.66945512301392 139.7387601910633 27.521 35.66946746895231 139.73875653127715 27.521 35.66946746895231 139.73875653127715 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d713a1b2-0ec9-4c54-ab66-b2175b17e567">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d713a1b2-0ec9-4c54-ab66-b2175b17e567">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d713a1b2-0ec9-4c54-ab66-b2175b17e567">
											<gml:posList>35.669521061823346 139.73879890733483 34.777 35.669521061823346 139.73879890733483 34.438 35.66951074552147 139.73874714624222 34.438 35.66951074552147 139.73874714624222 34.777 35.669521061823346 139.73879890733483 34.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-758ef88c-a429-4a31-b968-64b33acd2b8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-758ef88c-a429-4a31-b968-64b33acd2b8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-758ef88c-a429-4a31-b968-64b33acd2b8a">
											<gml:posList>35.66951897393479 139.73880310732991 34.777 35.66950731830215 139.73874459862708 34.777 35.66950731830215 139.73874459862708 32.227 35.66951897393479 139.73880310732991 32.227 35.66951897393479 139.73880310732991 34.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c927ae85-969b-441d-8014-b94ac71555d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c927ae85-969b-441d-8014-b94ac71555d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c927ae85-969b-441d-8014-b94ac71555d8">
											<gml:posList>35.669620180575144 139.7387692530536 34.777 35.669620180575144 139.7387692530536 34.438 35.669521061823346 139.73879890733483 34.438 35.669521061823346 139.73879890733483 34.777 35.669620180575144 139.7387692530536 34.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c045198-eace-424f-ae37-cd5cf00649cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c045198-eace-424f-ae37-cd5cf00649cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c045198-eace-424f-ae37-cd5cf00649cd">
											<gml:posList>35.66945512301392 139.7387601910633 17.02 35.66946679668382 139.73881872180135 17.02 35.66946679668382 139.73881872180135 27.521 35.66945512301392 139.7387601910633 27.521 35.66945512301392 139.7387601910633 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b12bfd4-bbce-4669-8028-84e2616c0840">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b12bfd4-bbce-4669-8028-84e2616c0840">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b12bfd4-bbce-4669-8028-84e2616c0840">
											<gml:posList>35.66962359878885 139.73877181173012 17.02 35.66962359878885 139.73877181173012 34.777 35.66951897393479 139.73880310732991 34.777 35.66951897393479 139.73880310732991 32.227 35.669506015235314 139.7388069887565 32.227 35.66946679668382 139.73881872180135 27.521 35.66946679668382 139.73881872180135 17.02 35.66962359878885 139.73877181173012 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8780</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">368.2605</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>