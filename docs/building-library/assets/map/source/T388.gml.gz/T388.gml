<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_70497ad4-a9cf-4e98-9cf5-e8462ada4330">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3003</bldg:class>
			<bldg:measuredHeight uom="m">3.9</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67497620128866 139.7417789800626 0 35.67497856593511 139.74180670506382 0 35.67500722678123 139.74180302686443 0 35.6750025876174 139.74174757674103 0 35.67497383663582 139.74175125506298 0 35.67497620128866 139.7417789800626 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67497620128866 139.7417789800626 9.867 35.67497383663582 139.74175125506298 9.867 35.6750025876174 139.74174757674103 9.867 35.67500722678123 139.74180302686443 9.867 35.67497856593511 139.74180670506382 9.867 35.67497620128866 139.7417789800626 9.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67497620128866 139.7417789800626 9.867 35.67497856593511 139.74180670506382 9.867 35.67497856593511 139.74180670506382 13.73 35.67497620128866 139.7417789800626 13.73 35.67497620128866 139.7417789800626 9.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67497856593511 139.74180670506382 9.867 35.67500722678123 139.74180302686443 9.867 35.67500722678123 139.74180302686443 13.73 35.67497856593511 139.74180670506382 13.73 35.67497856593511 139.74180670506382 9.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67500722678123 139.74180302686443 9.867 35.6750025876174 139.74174757674103 9.867 35.6750025876174 139.74174757674103 13.73 35.67500722678123 139.74180302686443 13.73 35.67500722678123 139.74180302686443 9.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6750025876174 139.74174757674103 9.867 35.67497383663582 139.74175125506298 9.867 35.67497383663582 139.74175125506298 13.73 35.6750025876174 139.74174757674103 13.73 35.6750025876174 139.74174757674103 9.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67497383663582 139.74175125506298 9.867 35.67497620128866 139.7417789800626 9.867 35.67497620128866 139.7417789800626 13.73 35.67497383663582 139.74175125506298 13.73 35.67497383663582 139.74175125506298 9.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67497620128866 139.7417789800626 13.73 35.67497856593511 139.74180670506382 13.73 35.67500722678123 139.74180302686443 13.73 35.6750025876174 139.74174757674103 13.73 35.67497383663582 139.74175125506298 13.73 35.67497620128866 139.7417789800626 13.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-425fa4bc-c620-4ee7-a69f-74ee944b0424"/>
							<gml:surfaceMember xlink:href="#poly-6ce07ede-050f-4d9a-9969-96223c5a2798"/>
							<gml:surfaceMember xlink:href="#poly-73a9b2a1-0a5d-4b62-8441-436ad98f295f"/>
							<gml:surfaceMember xlink:href="#poly-4a17c37a-fb7f-41f1-ad8b-0d294304eb63"/>
							<gml:surfaceMember xlink:href="#poly-a914096e-4f0c-4fe6-acc8-9c9cbff87d40"/>
							<gml:surfaceMember xlink:href="#poly-865f145f-e410-4179-977d-df4e1870e303"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-425fa4bc-c620-4ee7-a69f-74ee944b0424">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-425fa4bc-c620-4ee7-a69f-74ee944b0424">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-425fa4bc-c620-4ee7-a69f-74ee944b0424">
											<gml:posList>35.67497383663581 139.74175125506298 9.867 35.67500258761738 139.741747576741 9.867 35.67500722678121 139.74180302686443 9.867 35.674978565935106 139.74180670506382 9.867 35.67497383663581 139.74175125506298 9.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ce07ede-050f-4d9a-9969-96223c5a2798">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ce07ede-050f-4d9a-9969-96223c5a2798">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ce07ede-050f-4d9a-9969-96223c5a2798">
											<gml:posList>35.67500722678121 139.74180302686443 13.4 35.67500258761738 139.741747576741 13.4 35.67497383663581 139.74175125506298 13.4 35.674978565935106 139.74180670506382 13.4 35.67500722678121 139.74180302686443 13.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73a9b2a1-0a5d-4b62-8441-436ad98f295f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73a9b2a1-0a5d-4b62-8441-436ad98f295f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73a9b2a1-0a5d-4b62-8441-436ad98f295f">
											<gml:posList>35.67497383663581 139.74175125506298 9.867 35.674978565935106 139.74180670506382 9.867 35.674978565935106 139.74180670506382 13.4 35.67497383663581 139.74175125506298 13.4 35.67497383663581 139.74175125506298 9.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a17c37a-fb7f-41f1-ad8b-0d294304eb63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a17c37a-fb7f-41f1-ad8b-0d294304eb63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a17c37a-fb7f-41f1-ad8b-0d294304eb63">
											<gml:posList>35.67500258761738 139.741747576741 9.867 35.67497383663581 139.74175125506298 9.867 35.67497383663581 139.74175125506298 13.4 35.67500258761738 139.741747576741 13.4 35.67500258761738 139.741747576741 9.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a914096e-4f0c-4fe6-acc8-9c9cbff87d40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a914096e-4f0c-4fe6-acc8-9c9cbff87d40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a914096e-4f0c-4fe6-acc8-9c9cbff87d40">
											<gml:posList>35.67500722678121 139.74180302686443 9.867 35.67500258761738 139.741747576741 9.867 35.67500258761738 139.741747576741 13.4 35.67500722678121 139.74180302686443 13.4 35.67500722678121 139.74180302686443 9.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-865f145f-e410-4179-977d-df4e1870e303">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-865f145f-e410-4179-977d-df4e1870e303">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-865f145f-e410-4179-977d-df4e1870e303">
											<gml:posList>35.674978565935106 139.74180670506382 9.867 35.67500722678121 139.74180302686443 9.867 35.67500722678121 139.74180302686443 13.4 35.674978565935106 139.74180670506382 13.4 35.674978565935106 139.74180670506382 9.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4633</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>