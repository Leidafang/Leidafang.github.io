<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_70944f63-7339-4acd-a8a7-1b2f7561fe93">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">30.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670855516189754 139.74064050159888 0 35.670965815051204 139.74048561485498 0 35.67089563043715 139.74041069154845 0 35.67078524127823 139.74056524697454 0 35.670855516189754 139.74064050159888 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670855516189754 139.74064050159888 10.85 35.67078524127823 139.74056524697454 10.85 35.67089563043715 139.74041069154845 10.85 35.670965815051204 139.74048561485498 10.85 35.670855516189754 139.74064050159888 10.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670855516189754 139.74064050159888 10.85 35.670965815051204 139.74048561485498 10.85 35.670965815051204 139.74048561485498 41.27 35.670855516189754 139.74064050159888 41.27 35.670855516189754 139.74064050159888 10.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670965815051204 139.74048561485498 10.85 35.67089563043715 139.74041069154845 10.85 35.67089563043715 139.74041069154845 41.27 35.670965815051204 139.74048561485498 41.27 35.670965815051204 139.74048561485498 10.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67089563043715 139.74041069154845 10.85 35.67078524127823 139.74056524697454 10.85 35.67078524127823 139.74056524697454 41.27 35.67089563043715 139.74041069154845 41.27 35.67089563043715 139.74041069154845 10.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67078524127823 139.74056524697454 10.85 35.670855516189754 139.74064050159888 10.85 35.670855516189754 139.74064050159888 41.27 35.67078524127823 139.74056524697454 41.27 35.67078524127823 139.74056524697454 10.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670855516189754 139.74064050159888 41.27 35.670965815051204 139.74048561485498 41.27 35.67089563043715 139.74041069154845 41.27 35.67078524127823 139.74056524697454 41.27 35.670855516189754 139.74064050159888 41.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-92edc680-e89a-4f35-b8bd-f3d6db17d1b7"/>
							<gml:surfaceMember xlink:href="#poly-8e0dd2a2-5967-40cd-a9ee-ddd8ace0c393"/>
							<gml:surfaceMember xlink:href="#poly-4612326b-8c0e-4090-961e-7a5dfadc74d2"/>
							<gml:surfaceMember xlink:href="#poly-f4d1bdb2-9931-4a9f-bf5b-898ed311fe50"/>
							<gml:surfaceMember xlink:href="#poly-acc10695-fe30-4e81-98c7-f120ee44fd4b"/>
							<gml:surfaceMember xlink:href="#poly-6b6b1fe6-79eb-4f73-a15c-c9b1340d75f5"/>
							<gml:surfaceMember xlink:href="#poly-3469550d-250f-4fdf-80e2-f1d7fb3e8539"/>
							<gml:surfaceMember xlink:href="#poly-44b3d40f-8d04-46f9-a5ac-795a4052ae37"/>
							<gml:surfaceMember xlink:href="#poly-c5a82785-df70-4c71-84b3-0331c3a58b46"/>
							<gml:surfaceMember xlink:href="#poly-3464427f-8661-4381-802e-c1c829365c41"/>
							<gml:surfaceMember xlink:href="#poly-5436e48d-0d41-4e49-aa38-8e6018694cae"/>
							<gml:surfaceMember xlink:href="#poly-1b5b1e65-a1a0-4de2-b674-d39228591bf6"/>
							<gml:surfaceMember xlink:href="#poly-a3369d29-c552-4806-9adf-5c1597b586fe"/>
							<gml:surfaceMember xlink:href="#poly-3b6e527b-f0e7-4317-85c8-d8de7837d58d"/>
							<gml:surfaceMember xlink:href="#poly-a5691abd-bac8-420a-a7c1-d313e14a9fbf"/>
							<gml:surfaceMember xlink:href="#poly-faa8b48c-f795-4bc5-b5d7-29715922624c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_70944f63-7339-4acd-a8a7-1b2f7561fe93_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5edaa5fa-919d-4df5-a832-a6f24cca6864">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67086288914593 139.74060502332222 41.974 35.67085389464705 139.74059488215244 41.974 35.67086301619702 139.74058273168941 41.974 35.670872010696904 139.74059287285897 41.974 35.67086288914593 139.74060502332222 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eeb60732-f4e9-4310-b03c-d89c69644041">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67089808168112 139.7405386273108 41.974 35.67090666174072 139.74054901197871 41.974 35.670895963660996 139.74056229100213 41.974 35.670887392616244 139.7405519063237 41.974 35.67089808168112 139.7405386273108 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ef7b7b6-24f3-4640-8a7a-1ae295d81bc6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67093445194202 139.740515056521 41.974 35.67092656411253 139.74052569222658 41.974 35.67091729905916 139.74051537462958 41.974 35.67092518688776 139.7405047389242 41.974 35.67093445194202 139.740515056521 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad0f5408-3ac2-4923-8216-182d7dc89f90">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67095334762343 139.7404954384414 41.974 35.670944541716 139.74050778739667 41.974 35.67094425303846 139.74050747843344 41.974 35.67095305893734 139.74049511843188 41.974 35.67095334762343 139.7404954384414 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cde21bcb-f952-4deb-b436-55715b3930e6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67095334762343 139.7404954384414 42.403 35.67095645992096 139.74049875978557 42.403 35.670947654021695 139.7405111197873 42.403 35.670944541716 139.74050778739667 42.403 35.67095334762343 139.7404954384414 42.403</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7cbf700-7fe0-41e5-b305-ca45e5952728">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7cbf700-7fe0-41e5-b305-ca45e5952728_0">
											<gml:posList>35.67095305893734 139.74049511843188 41.974 35.67095305893734 139.74049511843188 43.635 35.67095645992096 139.74049875978557 43.635 35.67095645992096 139.74049875978557 42.403 35.67095334762343 139.7404954384414 42.403 35.67095334762343 139.7404954384414 41.974 35.67095305893734 139.74049511843188 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67ace6b1-2278-455d-a475-01c1e4bf8dcb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67ace6b1-2278-455d-a475-01c1e4bf8dcb_0">
											<gml:posList>35.67095305893734 139.74049511843188 41.974 35.67094425303846 139.74050747843344 41.974 35.67094425303846 139.74050747843344 43.635 35.67095305893734 139.74049511843188 43.635 35.67095305893734 139.74049511843188 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-489ab657-d06a-4720-8099-eeae2f772521">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-489ab657-d06a-4720-8099-eeae2f772521_0">
											<gml:posList>35.67095334762343 139.7404954384414 42.403 35.670944541716 139.74050778739667 42.403 35.670944541716 139.74050778739667 41.974 35.67095334762343 139.7404954384414 41.974 35.67095334762343 139.7404954384414 42.403</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4803fc1a-5662-4268-9946-5ac4eb4e0be5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4803fc1a-5662-4268-9946-5ac4eb4e0be5_0">
											<gml:posList>35.67095645992096 139.74049875978557 43.635 35.67095305893734 139.74049511843188 43.635 35.67094425303846 139.74050747843344 43.635 35.670947654021695 139.7405111197873 43.635 35.67095645992096 139.74049875978557 43.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44eb8451-2ca7-49e7-b262-c7bb84284943">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44eb8451-2ca7-49e7-b262-c7bb84284943_0">
											<gml:posList>35.670947654021695 139.7405111197873 42.403 35.67095645992096 139.74049875978557 42.403 35.67095645992096 139.74049875978557 43.635 35.670947654021695 139.7405111197873 43.635 35.670947654021695 139.7405111197873 42.403</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8a170d3-1c7d-448d-8549-c6cb7ae9cca1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8a170d3-1c7d-448d-8549-c6cb7ae9cca1_0">
											<gml:posList>35.670944541716 139.74050778739667 42.403 35.670947654021695 139.7405111197873 42.403 35.670947654021695 139.7405111197873 43.635 35.67094425303846 139.74050747843344 43.635 35.67094425303846 139.74050747843344 41.974 35.670944541716 139.74050778739667 41.974 35.670944541716 139.74050778739667 42.403</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c58b0b52-7be1-4e6a-ade8-554d3a550acb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c58b0b52-7be1-4e6a-ade8-554d3a550acb_0">
											<gml:posList>35.67093445194202 139.740515056521 41.974 35.67092518688776 139.7405047389242 41.974 35.67092518688776 139.7405047389242 43.635 35.67093445194202 139.740515056521 43.635 35.67093445194202 139.740515056521 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a73fb80a-3505-411e-81bc-4a0c2cc865a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a73fb80a-3505-411e-81bc-4a0c2cc865a6_0">
											<gml:posList>35.67092518688776 139.7405047389242 41.974 35.67091729905916 139.74051537462958 41.974 35.67091729905916 139.74051537462958 43.635 35.67092518688776 139.7405047389242 43.635 35.67092518688776 139.7405047389242 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f468f85d-b6b3-4886-aadf-0a3fa8d4cd0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f468f85d-b6b3-4886-aadf-0a3fa8d4cd0e_0">
											<gml:posList>35.67091729905916 139.74051537462958 43.635 35.67092656411253 139.74052569222658 43.635 35.67093445194202 139.740515056521 43.635 35.67092518688776 139.7405047389242 43.635 35.67091729905916 139.74051537462958 43.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84938116-379c-448a-81d7-214a37cee147">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84938116-379c-448a-81d7-214a37cee147_0">
											<gml:posList>35.67092656411253 139.74052569222658 41.974 35.67093445194202 139.740515056521 41.974 35.67093445194202 139.740515056521 43.635 35.67092656411253 139.74052569222658 43.635 35.67092656411253 139.74052569222658 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bfef188-b57e-4945-972d-c3f497244d8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1bfef188-b57e-4945-972d-c3f497244d8b_0">
											<gml:posList>35.67091729905916 139.74051537462958 41.974 35.67092656411253 139.74052569222658 41.974 35.67092656411253 139.74052569222658 43.635 35.67091729905916 139.74051537462958 43.635 35.67091729905916 139.74051537462958 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51f8a931-bb2e-48b7-b030-dee43496d091">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51f8a931-bb2e-48b7-b030-dee43496d091_0">
											<gml:posList>35.67090666174072 139.74054901197871 41.974 35.67089808168112 139.7405386273108 41.974 35.67089808168112 139.7405386273108 43.635 35.67090666174072 139.74054901197871 43.635 35.67090666174072 139.74054901197871 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e56c1d3-7414-4690-9efa-92733d17b0fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e56c1d3-7414-4690-9efa-92733d17b0fa_0">
											<gml:posList>35.670887392616244 139.7405519063237 41.974 35.670887392616244 139.7405519063237 43.635 35.67089808168112 139.7405386273108 43.635 35.67089808168112 139.7405386273108 41.974 35.670887392616244 139.7405519063237 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e94b62c4-cadb-462c-865b-5cd9ba3adba2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e94b62c4-cadb-462c-865b-5cd9ba3adba2_0">
											<gml:posList>35.67089808168112 139.7405386273108 43.635 35.670887392616244 139.7405519063237 43.635 35.670895963660996 139.74056229100213 43.635 35.67090666174072 139.74054901197871 43.635 35.67089808168112 139.7405386273108 43.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c77daaf-1208-41d3-b1be-7f90f674daa9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c77daaf-1208-41d3-b1be-7f90f674daa9_0">
											<gml:posList>35.670895963660996 139.74056229100213 41.974 35.67090666174072 139.74054901197871 41.974 35.67090666174072 139.74054901197871 43.635 35.670895963660996 139.74056229100213 43.635 35.670895963660996 139.74056229100213 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59c808c3-e7c7-49d9-9b31-fb62863467b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59c808c3-e7c7-49d9-9b31-fb62863467b7_0">
											<gml:posList>35.670887392616244 139.7405519063237 41.974 35.670895963660996 139.74056229100213 41.974 35.670895963660996 139.74056229100213 43.635 35.670887392616244 139.7405519063237 43.635 35.670887392616244 139.7405519063237 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7ed76ee-8be8-47cd-8c81-fa381a9be774">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7ed76ee-8be8-47cd-8c81-fa381a9be774_0">
											<gml:posList>35.67086301619702 139.74058273168941 41.974 35.67086301619702 139.74058273168941 43.635 35.670872010696904 139.74059287285897 43.635 35.670872010696904 139.74059287285897 41.974 35.67086301619702 139.74058273168941 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78bb5ca6-ee90-47ea-b64b-797a523fa6f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78bb5ca6-ee90-47ea-b64b-797a523fa6f5_0">
											<gml:posList>35.67086301619702 139.74058273168941 41.974 35.67085389464705 139.74059488215244 41.974 35.67085389464705 139.74059488215244 43.635 35.67086301619702 139.74058273168941 43.635 35.67086301619702 139.74058273168941 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-015a2152-365c-4665-b650-e395d419ef8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-015a2152-365c-4665-b650-e395d419ef8e_0">
											<gml:posList>35.67086301619702 139.74058273168941 43.635 35.67085389464705 139.74059488215244 43.635 35.67086288914593 139.74060502332222 43.635 35.670872010696904 139.74059287285897 43.635 35.67086301619702 139.74058273168941 43.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4017a9fa-3628-439f-af35-61fcdf12491c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4017a9fa-3628-439f-af35-61fcdf12491c_0">
											<gml:posList>35.67086288914593 139.74060502332222 41.974 35.670872010696904 139.74059287285897 41.974 35.670872010696904 139.74059287285897 43.635 35.67086288914593 139.74060502332222 43.635 35.67086288914593 139.74060502332222 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b1e5058-7821-4036-ad82-255ab30d04e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b1e5058-7821-4036-ad82-255ab30d04e4_0">
											<gml:posList>35.67085389464705 139.74059488215244 41.974 35.67086288914593 139.74060502332222 41.974 35.67086288914593 139.74060502332222 43.635 35.67085389464705 139.74059488215244 43.635 35.67085389464705 139.74059488215244 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-92edc680-e89a-4f35-b8bd-f3d6db17d1b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92edc680-e89a-4f35-b8bd-f3d6db17d1b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92edc680-e89a-4f35-b8bd-f3d6db17d1b7">
											<gml:posList>35.67085551618977 139.74064050159888 10.85 35.670785241278224 139.7405652469745 10.85 35.67089563043716 139.74041069154845 10.85 35.670965815051204 139.74048561485498 10.85 35.67085551618977 139.74064050159888 10.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e0dd2a2-5967-40cd-a9ee-ddd8ace0c393">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e0dd2a2-5967-40cd-a9ee-ddd8ace0c393">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e0dd2a2-5967-40cd-a9ee-ddd8ace0c393">
											<gml:posList>35.670928521586944 139.74044580286605 42.403 35.67092872523998 139.74045273972848 42.403 35.67095998355647 139.7404861186934 42.403 35.670965815051204 139.74048561485498 42.403 35.670928521586944 139.74044580286605 42.403</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4612326b-8c0e-4090-961e-7a5dfadc74d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4612326b-8c0e-4090-961e-7a5dfadc74d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4612326b-8c0e-4090-961e-7a5dfadc74d2">
											<gml:posList>35.67081047348907 139.7405922591678 42.403 35.670928521586944 139.74044580286605 42.403 35.67089563043716 139.74041069154845 37.149 35.67081047348907 139.7405922591678 42.403</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4d1bdb2-9931-4a9f-bf5b-898ed311fe50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4d1bdb2-9931-4a9f-bf5b-898ed311fe50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4d1bdb2-9931-4a9f-bf5b-898ed311fe50">
											<gml:posList>35.67089563043716 139.74041069154845 37.149 35.670785241278224 139.7405652469745 37.149 35.67081047348907 139.7405922591678 42.403 35.67089563043716 139.74041069154845 37.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-acc10695-fe30-4e81-98c7-f120ee44fd4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-acc10695-fe30-4e81-98c7-f120ee44fd4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-acc10695-fe30-4e81-98c7-f120ee44fd4b">
											<gml:posList>35.67081047348907 139.7405922591678 42.403 35.67081648543751 139.74059198710202 42.403 35.67092872523998 139.74045273972848 42.403 35.670928521586944 139.74044580286605 42.403 35.67081047348907 139.7405922591678 42.403</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6b6b1fe6-79eb-4f73-a15c-c9b1340d75f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b6b1fe6-79eb-4f73-a15c-c9b1340d75f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b6b1fe6-79eb-4f73-a15c-c9b1340d75f5">
											<gml:posList>35.67085511408409 139.74063335509152 41.974 35.67095998355647 139.7404861186934 41.974 35.67092872523998 139.74045273972848 41.974 35.67081648543751 139.74059198710202 41.974 35.67085511408409 139.74063335509152 41.974</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3469550d-250f-4fdf-80e2-f1d7fb3e8539">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3469550d-250f-4fdf-80e2-f1d7fb3e8539">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3469550d-250f-4fdf-80e2-f1d7fb3e8539">
											<gml:posList>35.670965815051204 139.74048561485498 42.403 35.67095998355647 139.7404861186934 42.403 35.67085511408409 139.74063335509152 42.403 35.67085551618977 139.74064050159888 42.403 35.670965815051204 139.74048561485498 42.403</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44b3d40f-8d04-46f9-a5ac-795a4052ae37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44b3d40f-8d04-46f9-a5ac-795a4052ae37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44b3d40f-8d04-46f9-a5ac-795a4052ae37">
											<gml:posList>35.67085551618977 139.74064050159888 42.403 35.67085511408409 139.74063335509152 42.403 35.67081648543751 139.74059198710202 42.403 35.67081047348907 139.7405922591678 42.403 35.67085551618977 139.74064050159888 42.403</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5a82785-df70-4c71-84b3-0331c3a58b46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5a82785-df70-4c71-84b3-0331c3a58b46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5a82785-df70-4c71-84b3-0331c3a58b46">
											<gml:posList>35.67081648543751 139.74059198710202 42.403 35.67081648543751 139.74059198710202 41.974 35.67092872523998 139.74045273972848 41.974 35.67092872523998 139.74045273972848 42.403 35.67081648543751 139.74059198710202 42.403</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3464427f-8661-4381-802e-c1c829365c41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3464427f-8661-4381-802e-c1c829365c41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3464427f-8661-4381-802e-c1c829365c41">
											<gml:posList>35.67085551618977 139.74064050159888 42.403 35.67081047348907 139.7405922591678 42.403 35.670785241278224 139.7405652469745 37.149 35.670785241278224 139.7405652469745 10.85 35.67085551618977 139.74064050159888 10.85 35.67085551618977 139.74064050159888 42.403</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5436e48d-0d41-4e49-aa38-8e6018694cae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5436e48d-0d41-4e49-aa38-8e6018694cae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5436e48d-0d41-4e49-aa38-8e6018694cae">
											<gml:posList>35.67085511408409 139.74063335509152 42.403 35.67085511408409 139.74063335509152 41.974 35.67081648543751 139.74059198710202 41.974 35.67081648543751 139.74059198710202 42.403 35.67085511408409 139.74063335509152 42.403</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b5b1e65-a1a0-4de2-b674-d39228591bf6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b5b1e65-a1a0-4de2-b674-d39228591bf6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b5b1e65-a1a0-4de2-b674-d39228591bf6">
											<gml:posList>35.67089563043716 139.74041069154845 10.85 35.670785241278224 139.7405652469745 10.85 35.670785241278224 139.7405652469745 37.149 35.67089563043716 139.74041069154845 37.149 35.67089563043716 139.74041069154845 10.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3369d29-c552-4806-9adf-5c1597b586fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3369d29-c552-4806-9adf-5c1597b586fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3369d29-c552-4806-9adf-5c1597b586fe">
											<gml:posList>35.67095998355647 139.7404861186934 42.403 35.67095998355647 139.7404861186934 41.974 35.67085511408409 139.74063335509152 41.974 35.67085511408409 139.74063335509152 42.403 35.67095998355647 139.7404861186934 42.403</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b6e527b-f0e7-4317-85c8-d8de7837d58d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b6e527b-f0e7-4317-85c8-d8de7837d58d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b6e527b-f0e7-4317-85c8-d8de7837d58d">
											<gml:posList>35.67085551618977 139.74064050159888 10.85 35.670965815051204 139.74048561485498 10.85 35.670965815051204 139.74048561485498 42.403 35.67085551618977 139.74064050159888 42.403 35.67085551618977 139.74064050159888 10.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5691abd-bac8-420a-a7c1-d313e14a9fbf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5691abd-bac8-420a-a7c1-d313e14a9fbf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5691abd-bac8-420a-a7c1-d313e14a9fbf">
											<gml:posList>35.670928521586944 139.74044580286605 42.403 35.670965815051204 139.74048561485498 42.403 35.670965815051204 139.74048561485498 10.85 35.67089563043716 139.74041069154845 10.85 35.67089563043716 139.74041069154845 37.149 35.670928521586944 139.74044580286605 42.403</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-faa8b48c-f795-4bc5-b5d7-29715922624c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-faa8b48c-f795-4bc5-b5d7-29715922624c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-faa8b48c-f795-4bc5-b5d7-29715922624c">
											<gml:posList>35.67092872523998 139.74045273972848 42.403 35.67092872523998 139.74045273972848 41.974 35.67095998355647 139.7404861186934 41.974 35.67095998355647 139.7404861186934 42.403 35.67092872523998 139.74045273972848 42.403</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2482</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">192.34635</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.66</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>