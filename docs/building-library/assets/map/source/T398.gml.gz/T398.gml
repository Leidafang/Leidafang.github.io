<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_72ea6dd0-99c5-4de4-b24c-07163c679820">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">29.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>11</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67058995017702 139.7419092539216 0 35.67054981027881 139.74187133361772 0 35.6705411236728 139.74188666471977 0 35.67052423431107 139.7419135264421 0 35.670508177043395 139.74189663290056 0 35.670510256118106 139.74189255445307 0 35.67050105415128 139.74188207098538 0 35.670421110378165 139.74201140347344 0 35.67048767771497 139.74207208216248 0 35.67058995017702 139.7419092539216 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058995017702 139.7419092539216 7.87 35.67048767771497 139.74207208216248 7.87 35.670421110378165 139.74201140347344 7.87 35.67050105415128 139.74188207098538 7.87 35.670510256118106 139.74189255445307 7.87 35.670508177043395 139.74189663290056 7.87 35.67052423431107 139.7419135264421 7.87 35.6705411236728 139.74188666471977 7.87 35.67054981027881 139.74187133361772 7.87 35.67058995017702 139.7419092539216 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058995017702 139.7419092539216 7.87 35.67054981027881 139.74187133361772 7.87 35.67054981027881 139.74187133361772 37.12 35.67058995017702 139.7419092539216 37.12 35.67058995017702 139.7419092539216 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67054981027881 139.74187133361772 7.87 35.6705411236728 139.74188666471977 7.87 35.6705411236728 139.74188666471977 37.12 35.67054981027881 139.74187133361772 37.12 35.67054981027881 139.74187133361772 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705411236728 139.74188666471977 7.87 35.67052423431107 139.7419135264421 7.87 35.67052423431107 139.7419135264421 37.12 35.6705411236728 139.74188666471977 37.12 35.6705411236728 139.74188666471977 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052423431107 139.7419135264421 7.87 35.670508177043395 139.74189663290056 7.87 35.670508177043395 139.74189663290056 37.12 35.67052423431107 139.7419135264421 37.12 35.67052423431107 139.7419135264421 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670508177043395 139.74189663290056 7.87 35.670510256118106 139.74189255445307 7.87 35.670510256118106 139.74189255445307 37.12 35.670508177043395 139.74189663290056 37.12 35.670508177043395 139.74189663290056 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670510256118106 139.74189255445307 7.87 35.67050105415128 139.74188207098538 7.87 35.67050105415128 139.74188207098538 37.12 35.670510256118106 139.74189255445307 37.12 35.670510256118106 139.74189255445307 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67050105415128 139.74188207098538 7.87 35.670421110378165 139.74201140347344 7.87 35.670421110378165 139.74201140347344 37.12 35.67050105415128 139.74188207098538 37.12 35.67050105415128 139.74188207098538 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670421110378165 139.74201140347344 7.87 35.67048767771497 139.74207208216248 7.87 35.67048767771497 139.74207208216248 37.12 35.670421110378165 139.74201140347344 37.12 35.670421110378165 139.74201140347344 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67048767771497 139.74207208216248 7.87 35.67058995017702 139.7419092539216 7.87 35.67058995017702 139.7419092539216 37.12 35.67048767771497 139.74207208216248 37.12 35.67048767771497 139.74207208216248 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67058995017702 139.7419092539216 37.12 35.67054981027881 139.74187133361772 37.12 35.6705411236728 139.74188666471977 37.12 35.67052423431107 139.7419135264421 37.12 35.670508177043395 139.74189663290056 37.12 35.670510256118106 139.74189255445307 37.12 35.67050105415128 139.74188207098538 37.12 35.670421110378165 139.74201140347344 37.12 35.67048767771497 139.74207208216248 37.12 35.67058995017702 139.7419092539216 37.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ee56c860-58ac-4415-89de-8b1ebbf5d093"/>
							<gml:surfaceMember xlink:href="#poly-10a94007-05ee-4061-9051-ce03cf08ef51"/>
							<gml:surfaceMember xlink:href="#poly-f0c1c4b1-a4ae-49c2-8d0f-ceceff74319e"/>
							<gml:surfaceMember xlink:href="#poly-562e792d-ca18-49be-91cf-d8b6fd9c85fe"/>
							<gml:surfaceMember xlink:href="#poly-b8e5a5bc-5888-4d4a-9391-60ecb9dc28f7"/>
							<gml:surfaceMember xlink:href="#poly-e1ee5190-7b0d-4499-bed3-cea0ba71a792"/>
							<gml:surfaceMember xlink:href="#poly-c08fe5d6-8c62-4a10-816d-3d1c7a08dd72"/>
							<gml:surfaceMember xlink:href="#poly-cb79a64a-827b-4076-a057-149060de34d0"/>
							<gml:surfaceMember xlink:href="#poly-bbfc4660-a40d-4740-b9f8-865b1085f9a6"/>
							<gml:surfaceMember xlink:href="#poly-0280403d-d2ee-44a0-a590-208dd48c2454"/>
							<gml:surfaceMember xlink:href="#poly-3c8a600c-510a-4140-8315-546362320fda"/>
							<gml:surfaceMember xlink:href="#poly-39fb7ec7-2800-4099-924a-bc85d28c7152"/>
							<gml:surfaceMember xlink:href="#poly-20172063-5b64-44fc-ba57-c7626ab3bc28"/>
							<gml:surfaceMember xlink:href="#poly-46084cf2-d431-486b-9fa5-62d8ff725e8f"/>
							<gml:surfaceMember xlink:href="#poly-c00dd557-d095-4beb-8959-e0fa6c6fb6a8"/>
							<gml:surfaceMember xlink:href="#poly-58503375-b0a9-4082-b291-fb6673ee6f36"/>
							<gml:surfaceMember xlink:href="#poly-c4873603-b6ce-490d-a6b7-afc3f1889545"/>
							<gml:surfaceMember xlink:href="#poly-7b0b0e40-bd67-4d74-91a5-e05261523b88"/>
							<gml:surfaceMember xlink:href="#poly-44e0ebe8-eed4-4624-bb42-81507ef14331"/>
							<gml:surfaceMember xlink:href="#poly-1abd4414-528c-4a09-93d4-8eec5f9b3845"/>
							<gml:surfaceMember xlink:href="#poly-63a4b3b5-3685-47d2-8f3a-d9ebfc0874f9"/>
							<gml:surfaceMember xlink:href="#poly-aa4551d8-de91-484c-949e-30d152fc2b60"/>
							<gml:surfaceMember xlink:href="#poly-5b2b9c06-216a-427c-bf03-d1b81df16621"/>
							<gml:surfaceMember xlink:href="#poly-a51f9796-38e8-4ae2-8daf-79a215d546be"/>
							<gml:surfaceMember xlink:href="#poly-61c6c802-bb16-4c17-b784-7c49d3d88a2d"/>
							<gml:surfaceMember xlink:href="#poly-1999085c-44b7-4dae-84f7-3a8fb25cd904"/>
							<gml:surfaceMember xlink:href="#poly-bf232a49-a46b-44b7-841a-bf873cf8dc2d"/>
							<gml:surfaceMember xlink:href="#poly-37f5496f-0fb5-493b-b5e4-027e8b3b5359"/>
							<gml:surfaceMember xlink:href="#poly-3be902a8-3afe-4492-9bf4-ebbbe401064e"/>
							<gml:surfaceMember xlink:href="#poly-ca89881c-7091-4e5c-b5fe-2b2e08156c55"/>
							<gml:surfaceMember xlink:href="#poly-1c9f9e6c-3b18-4fcf-b670-0048e14f7744"/>
							<gml:surfaceMember xlink:href="#poly-98a230af-460e-41f7-8a6d-5bf694e3c467"/>
							<gml:surfaceMember xlink:href="#poly-358028bb-16d2-4674-b9bd-ea49041e3f13"/>
							<gml:surfaceMember xlink:href="#poly-f6ae34e3-64b6-4c86-9d70-825763fac8a0"/>
							<gml:surfaceMember xlink:href="#poly-82d9c995-7303-442b-a039-53d371d82efe"/>
							<gml:surfaceMember xlink:href="#poly-83c504a9-3fb0-4841-a08b-d9ba19981e84"/>
							<gml:surfaceMember xlink:href="#poly-a8c55c2b-8d0b-41ff-a27d-d006c0a37bda"/>
							<gml:surfaceMember xlink:href="#poly-ef0f811c-7fba-4825-9fd7-ccccee1c5e71"/>
							<gml:surfaceMember xlink:href="#poly-84f53497-434d-4934-88c4-1bc06b8ca3d3"/>
							<gml:surfaceMember xlink:href="#poly-e512cf01-d880-4914-84b0-d2eb2e0993b9"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_72ea6dd0-99c5-4de4-b24c-07163c679820_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fdf6522-16ce-4fe2-8ed6-d566bd37a73c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fdf6522-16ce-4fe2-8ed6-d566bd37a73c_0">
											<gml:posList>35.670526569209486 139.74186649976687 37.075 35.670510256118106 139.7418925544531 37.075 35.670510256118106 139.7418925544531 37.928 35.670526569209486 139.74186649976687 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5683eeaa-96d2-4abf-a1c1-cb777719f7b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5683eeaa-96d2-4abf-a1c1-cb777719f7b8_0">
											<gml:posList>35.67051623273965 139.74190510725532 37.075 35.67053474201074 139.74187487457044 37.075 35.67051623273965 139.74190510725532 38.039 35.67051623273965 139.74190510725532 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4aab32ab-5b0d-43b3-a39d-c85216c01e97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4aab32ab-5b0d-43b3-a39d-c85216c01e97_0">
											<gml:posList>35.67054980126506 139.741871333628 7.87 35.67053330330938 139.74185574405345 37.075 35.67054980126506 139.741871333628 37.075 35.67054980126506 139.741871333628 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e173951-0a9c-475d-9505-955235e916bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e173951-0a9c-475d-9505-955235e916bd_0">
											<gml:posList>35.67054980126506 139.741871333628 7.87 35.67053330330938 139.74185574405345 7.87 35.67053330330938 139.74185574405345 37.075 35.67054980126506 139.741871333628 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7084900b-fc3d-4ca6-bdef-eb63b731c75e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7084900b-fc3d-4ca6-bdef-eb63b731c75e_0">
											<gml:posList>35.670526569209486 139.74186649976687 37.075 35.67053474201074 139.74187487457044 37.075 35.67053330330938 139.74185574405345 37.075 35.670526569209486 139.74186649976687 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-852c4be7-8f35-462e-a1da-0916bb54118a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-852c4be7-8f35-462e-a1da-0916bb54118a_0">
											<gml:posList>35.67053474201074 139.74187487457044 37.075 35.67054300501572 139.74188333764312 37.075 35.67054980126506 139.741871333628 37.075 35.67053474201074 139.74187487457044 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fe890a0-765b-4c00-9b69-22cb6a21e2d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1fe890a0-765b-4c00-9b69-22cb6a21e2d0_0">
											<gml:posList>35.67053330330938 139.74185574405345 37.075 35.67053474201074 139.74187487457044 37.075 35.67054980126506 139.741871333628 37.075 35.67053330330938 139.74185574405345 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56d3d369-46dd-48f6-bbdf-7f66e942b863">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56d3d369-46dd-48f6-bbdf-7f66e942b863_0">
											<gml:posList>35.67053330330938 139.74185574405345 37.075 35.67053330330938 139.74185574405345 7.87 35.670526569209486 139.74186649976687 37.075 35.67053330330938 139.74185574405345 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8360d473-951d-4bfe-a591-8066b58d8299">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8360d473-951d-4bfe-a591-8066b58d8299_0">
											<gml:posList>35.670526569209486 139.74186649976687 37.075 35.670510256118106 139.7418925544531 7.87 35.670510256118106 139.7418925544531 37.075 35.670526569209486 139.74186649976687 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd222277-4f78-4722-881c-f451537fc037">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd222277-4f78-4722-881c-f451537fc037_0">
											<gml:posList>35.670526569209486 139.74186649976687 37.075 35.67053330330938 139.74185574405345 7.87 35.670510256118106 139.7418925544531 7.87 35.670526569209486 139.74186649976687 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eac7db0c-ad1e-4202-875e-c15267babff4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eac7db0c-ad1e-4202-875e-c15267babff4_0">
											<gml:posList>35.67054300501572 139.74188333764312 7.87 35.67054980126506 139.741871333628 37.075 35.67054300501572 139.74188333764312 37.075 35.67054300501572 139.74188333764312 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19e922a3-52b1-4c62-b529-0d7aa62e2cf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19e922a3-52b1-4c62-b529-0d7aa62e2cf4_0">
											<gml:posList>35.67054300501572 139.74188333764312 7.87 35.67054980126506 139.741871333628 7.87 35.67054980126506 139.741871333628 37.075 35.67054300501572 139.74188333764312 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4444bcd-2f4c-47c2-ba20-3a859c21443d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4444bcd-2f4c-47c2-ba20-3a859c21443d_0">
											<gml:posList>35.67054300501572 139.74188333764312 37.075 35.67054112367279 139.74188666471977 7.87 35.67054300501572 139.74188333764312 7.87 35.67054300501572 139.74188333764312 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-291498a1-b40c-4e85-93dd-521970df4122">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-291498a1-b40c-4e85-93dd-521970df4122_0">
											<gml:posList>35.67054300501572 139.74188333764312 37.075 35.67054112367279 139.74188666471977 37.075 35.67054112367279 139.74188666471977 7.87 35.67054300501572 139.74188333764312 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62126ae1-6b5e-4931-9b1b-547da1874008">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62126ae1-6b5e-4931-9b1b-547da1874008_0">
											<gml:posList>35.67050817704339 139.74189663290053 38.039 35.67051623273965 139.74190510725532 38.039 35.670510256118106 139.7418925544531 37.928 35.67050817704339 139.74189663290053 38.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b6655aa-3cb1-4aff-99d4-a4f6e7a9d537">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b6655aa-3cb1-4aff-99d4-a4f6e7a9d537_0">
											<gml:posList>35.67051623273965 139.74190510725532 38.039 35.67053474201074 139.74187487457044 37.075 35.670510256118106 139.7418925544531 37.928 35.67051623273965 139.74190510725532 38.039</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60e1be9f-3105-4026-98ad-e57012a452b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60e1be9f-3105-4026-98ad-e57012a452b0_0">
											<gml:posList>35.67053474201074 139.74187487457044 37.075 35.670526569209486 139.74186649976687 37.075 35.670510256118106 139.7418925544531 37.928 35.67053474201074 139.74187487457044 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed29fac1-1068-4979-b6d8-f4a5ae17f971">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed29fac1-1068-4979-b6d8-f4a5ae17f971_0">
											<gml:posList>35.67054112367279 139.74188666471977 7.87 35.6705354248565 139.74189571812371 37.075 35.6705354248565 139.74189571812371 7.87 35.67054112367279 139.74188666471977 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad48f84b-bbde-4f5d-acc2-f954834ae48f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad48f84b-bbde-4f5d-acc2-f954834ae48f_0">
											<gml:posList>35.67054112367279 139.74188666471977 7.87 35.67054112367279 139.74188666471977 37.075 35.6705354248565 139.74189571812371 37.075 35.67054112367279 139.74188666471977 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba38292d-47e6-4106-9639-f7ab937e3d8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba38292d-47e6-4106-9639-f7ab937e3d8a_0">
											<gml:posList>35.670524234311046 139.7419135264421 37.075 35.6705354248565 139.74189571812371 37.075 35.67051623273965 139.74190510725532 37.075 35.670524234311046 139.7419135264421 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cc7858c-8d3e-44ea-9571-4b178812f6cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cc7858c-8d3e-44ea-9571-4b178812f6cb_0">
											<gml:posList>35.67051623273965 139.74190510725532 37.075 35.6705354248565 139.74189571812371 37.075 35.67053474201074 139.74187487457044 37.075 35.67051623273965 139.74190510725532 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a873c427-c0c7-40e0-a39e-3d79f7b7dc83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a873c427-c0c7-40e0-a39e-3d79f7b7dc83_0">
											<gml:posList>35.67053474201074 139.74187487457044 37.075 35.67054112367279 139.74188666471977 37.075 35.67054300501572 139.74188333764312 37.075 35.67053474201074 139.74187487457044 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-964a67ff-8347-4b73-8ed0-10a5828618c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-964a67ff-8347-4b73-8ed0-10a5828618c5_0">
											<gml:posList>35.67053474201074 139.74187487457044 37.075 35.6705354248565 139.74189571812371 37.075 35.67054112367279 139.74188666471977 37.075 35.67053474201074 139.74187487457044 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdf85b22-eaf0-4dbb-9b84-9357ef22ad2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdf85b22-eaf0-4dbb-9b84-9357ef22ad2c_0">
											<gml:posList>35.67050817704339 139.74189663290053 37.075 35.670510256118106 139.7418925544531 7.87 35.67050817704339 139.74189663290053 7.87 35.67050817704339 139.74189663290053 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e818799d-f553-40e1-b72f-e555cb08dd5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e818799d-f553-40e1-b72f-e555cb08dd5a_0">
											<gml:posList>35.67050817704339 139.74189663290053 37.075 35.670510256118106 139.7418925544531 37.075 35.670510256118106 139.7418925544531 7.87 35.67050817704339 139.74189663290053 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd9e0a68-22f2-408d-8799-030d1b436009">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd9e0a68-22f2-408d-8799-030d1b436009_0">
											<gml:posList>35.67050817704339 139.74189663290053 37.075 35.67050817704339 139.74189663290053 38.039 35.670510256118106 139.7418925544531 37.928 35.67050817704339 139.74189663290053 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76fa9373-d79f-4846-892b-f47bb9b0e888">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76fa9373-d79f-4846-892b-f47bb9b0e888_0">
											<gml:posList>35.670510256118106 139.7418925544531 37.075 35.67050817704339 139.74189663290053 37.075 35.670510256118106 139.7418925544531 37.928 35.670510256118106 139.7418925544531 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2d066d9-2db3-417c-a305-7d6d614c55f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2d066d9-2db3-417c-a305-7d6d614c55f8_0">
											<gml:posList>35.67050817704339 139.74189663290053 37.075 35.67051623273965 139.74190510725532 38.039 35.67050817704339 139.74189663290053 38.039 35.67050817704339 139.74189663290053 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbda3192-cfeb-48c5-aa30-07659e830b7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbda3192-cfeb-48c5-aa30-07659e830b7e_0">
											<gml:posList>35.67050817704339 139.74189663290053 37.075 35.67051623273965 139.74190510725532 37.075 35.67051623273965 139.74190510725532 38.039 35.67050817704339 139.74189663290053 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efe1b7d2-f765-4e87-b6ac-7d3848b70482">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efe1b7d2-f765-4e87-b6ac-7d3848b70482_0">
											<gml:posList>35.670521861806556 139.7419110326882 37.075 35.67050817704339 139.74189663290053 7.87 35.670521861806556 139.7419110326882 7.87 35.670521861806556 139.7419110326882 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4f77d4c-ca67-4e6f-917f-4693ea0019c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4f77d4c-ca67-4e6f-917f-4693ea0019c7_0">
											<gml:posList>35.670521861806556 139.7419110326882 37.075 35.67050817704339 139.74189663290053 37.075 35.67050817704339 139.74189663290053 7.87 35.670521861806556 139.7419110326882 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ae3c5fc-af8b-49a6-8bfd-5fd61d7e8cbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ae3c5fc-af8b-49a6-8bfd-5fd61d7e8cbf_0">
											<gml:posList>35.6705354248565 139.74189571812371 37.075 35.670524234311046 139.7419135264421 7.87 35.6705354248565 139.74189571812371 7.87 35.6705354248565 139.74189571812371 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41110440-7488-4637-99e1-36a6df080d8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41110440-7488-4637-99e1-36a6df080d8e_0">
											<gml:posList>35.6705354248565 139.74189571812371 37.075 35.670524234311046 139.7419135264421 37.075 35.670524234311046 139.7419135264421 7.87 35.6705354248565 139.74189571812371 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33b7456b-d1e3-47ee-803c-7293fe124efa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33b7456b-d1e3-47ee-803c-7293fe124efa_0">
											<gml:posList>35.67050817704339 139.74189663290053 37.075 35.670521861806556 139.7419110326882 37.075 35.67051623273965 139.74190510725532 37.075 35.67050817704339 139.74189663290053 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b13109b-37d4-4d22-8eb7-6cca456bd3fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b13109b-37d4-4d22-8eb7-6cca456bd3fa_0">
											<gml:posList>35.67051623273965 139.74190510725532 37.075 35.670521861806556 139.7419110326882 37.075 35.670524234311046 139.7419135264421 37.075 35.67051623273965 139.74190510725532 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3012f4c3-c3ea-4996-a639-bad1910b0acd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3012f4c3-c3ea-4996-a639-bad1910b0acd_0">
											<gml:posList>35.670524234311046 139.7419135264421 37.075 35.670521861806556 139.7419110326882 37.075 35.670524234311046 139.7419135264421 7.87 35.670524234311046 139.7419135264421 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f187c7c-c7f1-4bba-a7cd-518348927611">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f187c7c-c7f1-4bba-a7cd-518348927611_0">
											<gml:posList>35.670521861806556 139.7419110326882 37.075 35.670521861806556 139.7419110326882 7.87 35.670524234311046 139.7419135264421 7.87 35.670521861806556 139.7419110326882 37.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d0a5716-a523-4e3d-9557-736431f36021">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d0a5716-a523-4e3d-9557-736431f36021_0">
											<gml:posList>35.67056756311728 139.7419132671581 37.584 35.67057467103806 139.74191998624187 38.919 35.67057467103806 139.74191998624187 37.584 35.67056756311728 139.7419132671581 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a95c5c8-ef14-4cb6-982b-459e54e82287">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a95c5c8-ef14-4cb6-982b-459e54e82287_0">
											<gml:posList>35.67056756311728 139.7419132671581 37.584 35.67056756311728 139.7419132671581 38.919 35.67057467103806 139.74191998624187 38.919 35.67056756311728 139.7419132671581 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74437340-eddc-4bc0-ae36-df0f8f67d609">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74437340-eddc-4bc0-ae36-df0f8f67d609_0">
											<gml:posList>35.6705554992779 139.74193244621594 37.584 35.67056756311728 139.7419132671581 38.919 35.67056756311728 139.7419132671581 37.584 35.6705554992779 139.74193244621594 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bb01c7a-4c52-4097-9077-12701dd5b52e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bb01c7a-4c52-4097-9077-12701dd5b52e_0">
											<gml:posList>35.6705554992779 139.74193244621594 37.584 35.6705554992779 139.74193244621594 38.919 35.67056756311728 139.7419132671581 38.919 35.6705554992779 139.74193244621594 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53839df9-98c3-43b3-86be-aca95e6b3a8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53839df9-98c3-43b3-86be-aca95e6b3a8c_0">
											<gml:posList>35.67056756311728 139.7419132671581 38.919 35.6705554992779 139.74193244621594 38.919 35.67057467103806 139.74191998624187 38.919 35.67056756311728 139.7419132671581 38.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9596e88-968d-4de0-a9d4-610f7a102303">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9596e88-968d-4de0-a9d4-610f7a102303_0">
											<gml:posList>35.6705554992779 139.74193244621594 38.919 35.670551209564884 139.7419572831507 38.919 35.67057467103806 139.74191998624187 38.919 35.6705554992779 139.74193244621594 38.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a70bb30-dba1-41c5-bd4f-72bbf2b33b2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a70bb30-dba1-41c5-bd4f-72bbf2b33b2e_0">
											<gml:posList>35.67054980046656 139.74194151066453 38.919 35.67054410164616 139.74195056406558 38.919 35.670551209564884 139.7419572831507 38.919 35.67054980046656 139.74194151066453 38.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ed68f75-79e1-4690-a573-da695088604b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ed68f75-79e1-4690-a573-da695088604b_0">
											<gml:posList>35.6705554992779 139.74193244621594 38.919 35.67054980046656 139.74194151066453 38.919 35.670551209564884 139.7419572831507 38.919 35.6705554992779 139.74193244621594 38.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bd71b34-7e13-4515-a389-b426df1149ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bd71b34-7e13-4515-a389-b426df1149ec_0">
											<gml:posList>35.67054980046656 139.74194151066453 37.584 35.6705554992779 139.74193244621594 38.919 35.6705554992779 139.74193244621594 37.584 35.67054980046656 139.74194151066453 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72fbd1a9-3241-4f22-b77b-66d330f7a8a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72fbd1a9-3241-4f22-b77b-66d330f7a8a5_0">
											<gml:posList>35.67054980046656 139.74194151066453 37.584 35.67054980046656 139.74194151066453 38.919 35.6705554992779 139.74193244621594 38.919 35.67054980046656 139.74194151066453 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fae4272f-342e-4370-9da6-eb68d5bea7f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fae4272f-342e-4370-9da6-eb68d5bea7f2_0">
											<gml:posList>35.670551209564884 139.7419572831507 37.584 35.67057467103806 139.74191998624187 38.919 35.670551209564884 139.7419572831507 38.919 35.670551209564884 139.7419572831507 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59a30ece-bec2-4e65-8f02-993d27e0cd62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59a30ece-bec2-4e65-8f02-993d27e0cd62_0">
											<gml:posList>35.670551209564884 139.7419572831507 37.584 35.67057467103806 139.74191998624187 37.584 35.67057467103806 139.74191998624187 38.919 35.670551209564884 139.7419572831507 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b590dd2a-e6a3-4664-b751-21042d4a1563">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b590dd2a-e6a3-4664-b751-21042d4a1563_0">
											<gml:posList>35.67054980046656 139.74194151066453 37.584 35.67054410164616 139.74195056406558 38.919 35.67054980046656 139.74194151066453 38.919 35.67054980046656 139.74194151066453 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9ea9cfc-fa3c-44e0-8b38-0cd5c54dc0ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9ea9cfc-fa3c-44e0-8b38-0cd5c54dc0ba_0">
											<gml:posList>35.67054980046656 139.74194151066453 37.584 35.67054410164616 139.74195056406558 37.584 35.67054410164616 139.74195056406558 38.919 35.67054980046656 139.74194151066453 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5291d1e0-d999-462f-9f01-e9085727ad9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5291d1e0-d999-462f-9f01-e9085727ad9f_0">
											<gml:posList>35.670551209564884 139.7419572831507 37.584 35.67054410164616 139.74195056406558 38.919 35.67054410164616 139.74195056406558 37.584 35.670551209564884 139.7419572831507 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6dcd7265-25a8-4298-b7de-6e251ef23cf1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6dcd7265-25a8-4298-b7de-6e251ef23cf1_0">
											<gml:posList>35.670551209564884 139.7419572831507 37.584 35.670551209564884 139.7419572831507 38.919 35.67054410164616 139.74195056406558 38.919 35.670551209564884 139.7419572831507 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-265f2946-c848-41ed-b469-f047f1bb4a94">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670510256118106 139.7418925544531 7.87 35.67053330330938 139.74185574405345 7.87 35.67054112367279 139.74188666471977 7.87 35.670510256118106 139.7418925544531 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9da7918-2f78-447f-80a0-5fbd73b3af94">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670510256118106 139.7418925544531 7.87 35.670521861806556 139.7419110326882 7.87 35.67050817704339 139.74189663290053 7.87 35.670510256118106 139.7418925544531 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b177b862-15a6-4a24-8cb0-dbdc424dc0c4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67054980126506 139.741871333628 7.87 35.67054300501572 139.74188333764312 7.87 35.67053330330938 139.74185574405345 7.87 35.67054980126506 139.741871333628 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b12ccdc3-b346-4697-a3fa-ab8f5882bbd4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670521861806556 139.7419110326882 7.87 35.6705354248565 139.74189571812371 7.87 35.670524234311046 139.7419135264421 7.87 35.670521861806556 139.7419110326882 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cc2c931-f919-4547-8f05-3ba1e33d3af9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67053330330938 139.74185574405345 7.87 35.67054300501572 139.74188333764312 7.87 35.67054112367279 139.74188666471977 7.87 35.67053330330938 139.74185574405345 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-328200e8-32de-4286-8ad5-5a2ddc07c726">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705354248565 139.74189571812371 7.87 35.670510256118106 139.7418925544531 7.87 35.67054112367279 139.74188666471977 7.87 35.6705354248565 139.74189571812371 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52a189b6-c233-44c8-b2a2-5706f37cd322">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705354248565 139.74189571812371 7.87 35.670521861806556 139.7419110326882 7.87 35.670510256118106 139.7418925544531 7.87 35.6705354248565 139.74189571812371 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae338a60-f70d-49e4-b950-ded56a328c31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67054410164616 139.74195056406558 37.584 35.67054980046656 139.74194151066453 38.919 35.670551209564884 139.7419572831507 37.584 35.67054410164616 139.74195056406558 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b37f2ef-7816-4b41-8c8f-43141dbe4373">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67057467103806 139.74191998624187 37.584 35.670551209564884 139.7419572831507 37.584 35.6705554992779 139.74193244621594 37.584 35.67057467103806 139.74191998624187 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f34c29c-06ee-4bdf-a742-9a61fd1e8144">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67057467103806 139.74191998624187 37.584 35.6705554992779 139.74193244621594 37.584 35.67056756311728 139.7419132671581 37.584 35.67057467103806 139.74191998624187 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cf0f7b4-5fa8-4974-b7b4-01a4923f0938">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670551209564884 139.7419572831507 37.584 35.67054980046656 139.74194151066453 38.919 35.6705554992779 139.74193244621594 37.584 35.670551209564884 139.7419572831507 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_72ea6dd0-99c5-4de4-b24c-07163c679820_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-405dfeca-6671-454f-89cc-d300bff9ae26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670506783665715 139.7419015721754 37.584 35.67043740107422 139.7420152069269 37.584 35.67048633458303 139.7420600763912 37.584 35.67054866822315 139.7419579819628 37.584 35.67055014749635 139.74195932792344 37.584 35.67048667053569 139.74206330152086 37.584 35.67043475141662 139.74201570702672 37.584 35.67050534033772 139.74190008257398 37.584 35.670506783665715 139.7419015721754 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2acc3aa8-283b-4f28-856f-d395f7023fae">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67050821506107 139.74189921768607 38.085 35.670506783665715 139.7419015721754 38.085 35.67050534033772 139.74190008257398 38.085 35.670506708712466 139.741897827573 38.085 35.67050821506107 139.74189921768607 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d05adcf1-3016-48a8-ab4d-1bf51ae1c836">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d05adcf1-3016-48a8-ab4d-1bf51ae1c836_0">
											<gml:posList>35.67048633458303 139.7420600763912 39.134 35.67054866822315 139.7419579819628 39.134 35.67054866822315 139.7419579819628 37.584 35.67048633458303 139.7420600763912 37.584 35.67048633458303 139.7420600763912 39.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81dc7f2f-bec0-439b-b7f4-3acd2af6acd5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81dc7f2f-bec0-439b-b7f4-3acd2af6acd5_0">
											<gml:posList>35.670506708712466 139.741897827573 38.085 35.670506708712466 139.741897827573 39.134 35.67050821506107 139.74189921768607 39.134 35.67050821506107 139.74189921768607 38.085 35.670506708712466 139.741897827573 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-385257db-fc23-4efb-ae4e-da74cc1d561d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-385257db-fc23-4efb-ae4e-da74cc1d561d_0">
											<gml:posList>35.67050534033772 139.74190008257398 38.085 35.670506783665715 139.7419015721754 38.085 35.670506783665715 139.7419015721754 37.584 35.67050534033772 139.74190008257398 37.584 35.67050534033772 139.74190008257398 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfbf85ee-362e-4898-8260-7640de5a588e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfbf85ee-362e-4898-8260-7640de5a588e_0">
											<gml:posList>35.67050534033772 139.74190008257398 38.085 35.67050534033772 139.74190008257398 37.584 35.67043475141662 139.74201570702672 37.584 35.67043475141662 139.74201570702672 39.134 35.670506708712466 139.741897827573 39.134 35.670506708712466 139.741897827573 38.085 35.67050534033772 139.74190008257398 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ceb1c923-ed71-4541-9a57-d5a6e9642806">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ceb1c923-ed71-4541-9a57-d5a6e9642806_0">
											<gml:posList>35.67050821506107 139.74189921768607 39.134 35.67043740107422 139.7420152069269 39.134 35.67043740107422 139.7420152069269 37.584 35.670506783665715 139.7419015721754 37.584 35.670506783665715 139.7419015721754 38.085 35.67050821506107 139.74189921768607 38.085 35.67050821506107 139.74189921768607 39.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abb2faa2-1cc1-4661-98a3-c2c0ec20fb20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abb2faa2-1cc1-4661-98a3-c2c0ec20fb20_0">
											<gml:posList>35.67054866822315 139.7419579819628 37.584 35.67054866822315 139.7419579819628 39.134 35.67055014749635 139.74195932792344 39.134 35.67055014749635 139.74195932792344 37.584 35.67054866822315 139.7419579819628 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4d2e51a-caa7-4260-b46c-d8019e08f2a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4d2e51a-caa7-4260-b46c-d8019e08f2a5_0">
											<gml:posList>35.67054866822315 139.7419579819628 39.134 35.67048633458303 139.7420600763912 39.134 35.67043740107422 139.7420152069269 39.134 35.67050821506107 139.74189921768607 39.134 35.670506708712466 139.741897827573 39.134 35.67043475141662 139.74201570702672 39.134 35.67048667053569 139.74206330152086 39.134 35.67055014749635 139.74195932792344 39.134 35.67054866822315 139.7419579819628 39.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d955acf-1bd5-4c22-bbe4-b6edea66623e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d955acf-1bd5-4c22-bbe4-b6edea66623e_0">
											<gml:posList>35.67055014749635 139.74195932792344 37.584 35.67055014749635 139.74195932792344 39.134 35.67048667053569 139.74206330152086 39.134 35.67048667053569 139.74206330152086 37.584 35.67055014749635 139.74195932792344 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43c1fae1-22e6-43ff-8910-424801ca3805">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43c1fae1-22e6-43ff-8910-424801ca3805_0">
											<gml:posList>35.67043740107422 139.7420152069269 37.584 35.67043740107422 139.7420152069269 39.134 35.67048633458303 139.7420600763912 39.134 35.67048633458303 139.7420600763912 37.584 35.67043740107422 139.7420152069269 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6964d68f-bfee-4b72-8f22-b49737e289a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6964d68f-bfee-4b72-8f22-b49737e289a2_0">
											<gml:posList>35.67048667053569 139.74206330152086 37.584 35.67048667053569 139.74206330152086 39.134 35.67043475141662 139.74201570702672 39.134 35.67043475141662 139.74201570702672 37.584 35.67048667053569 139.74206330152086 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_72ea6dd0-99c5-4de4-b24c-07163c679820_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffe7a9cb-b19b-4a7c-b96e-e0869d654da9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67053584576093 139.7419633540225 37.584 35.67052777246047 139.74195543199386 37.584 35.67053484904786 139.74194462066595 37.584 35.67054291333532 139.74195254270444 37.584 35.67053584576093 139.7419633540225 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bef22171-f9c9-4616-a031-e599e4e03924">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67051638065815 139.74198123803706 37.584 35.670509313081155 139.741992049349 37.584 35.670501239782546 139.74198412732008 37.584 35.67050831637255 139.74197331599828 37.584 35.67051638065815 139.74198123803706 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81ac9b4d-52d5-44d7-8992-175e9cbbdc4b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67048165436581 139.74200976594298 37.584 35.67048972767114 139.74201769901882 37.584 35.670482660090826 139.74202851032393 37.584 35.670474586794576 139.74202058829397 37.584 35.67048165436581 139.74200976594298 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8762134-04a2-4c98-ad14-4bfb5be9c092">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8762134-04a2-4c98-ad14-4bfb5be9c092_0">
											<gml:posList>35.67054291333532 139.74195254270444 37.584 35.67053484904786 139.74194462066595 37.584 35.67053484904786 139.74194462066595 38.284 35.67054291333532 139.74195254270444 38.284 35.67054291333532 139.74195254270444 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5367833-101f-447c-973f-a29a9350a047">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5367833-101f-447c-973f-a29a9350a047_0">
											<gml:posList>35.67053484904786 139.74194462066595 37.584 35.67052777246047 139.74195543199386 37.584 35.67052777246047 139.74195543199386 38.284 35.67053484904786 139.74194462066595 38.284 35.67053484904786 139.74194462066595 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc41020d-abe3-49ab-8bc8-ec79a8c839c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc41020d-abe3-49ab-8bc8-ec79a8c839c6_0">
											<gml:posList>35.67053484904786 139.74194462066595 38.284 35.67052777246047 139.74195543199386 38.284 35.67053584576093 139.7419633540225 38.284 35.67054291333532 139.74195254270444 38.284 35.67053484904786 139.74194462066595 38.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7db709bf-33a2-4837-b4e5-543f0b16148d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7db709bf-33a2-4837-b4e5-543f0b16148d_0">
											<gml:posList>35.67053584576093 139.7419633540225 37.584 35.67054291333532 139.74195254270444 37.584 35.67054291333532 139.74195254270444 38.284 35.67053584576093 139.7419633540225 38.284 35.67053584576093 139.7419633540225 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abf9d3c1-573f-4e6b-a8eb-2f8f074b08a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abf9d3c1-573f-4e6b-a8eb-2f8f074b08a2_0">
											<gml:posList>35.67052777246047 139.74195543199386 37.584 35.67053584576093 139.7419633540225 37.584 35.67053584576093 139.7419633540225 38.284 35.67052777246047 139.74195543199386 38.284 35.67052777246047 139.74195543199386 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d3e1ceb-81d3-4078-a582-faed557c2279">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d3e1ceb-81d3-4078-a582-faed557c2279_0">
											<gml:posList>35.67050831637255 139.74197331599828 37.584 35.67050831637255 139.74197331599828 38.284 35.67051638065815 139.74198123803706 38.284 35.67051638065815 139.74198123803706 37.584 35.67050831637255 139.74197331599828 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d69db5d2-10a0-4856-878c-45c19a383a74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d69db5d2-10a0-4856-878c-45c19a383a74_0">
											<gml:posList>35.67050831637255 139.74197331599828 37.584 35.670501239782546 139.74198412732008 37.584 35.670501239782546 139.74198412732008 38.284 35.67050831637255 139.74197331599828 38.284 35.67050831637255 139.74197331599828 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a13678a9-cc3c-4779-a897-e5001e30e162">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a13678a9-cc3c-4779-a897-e5001e30e162_0">
											<gml:posList>35.670501239782546 139.74198412732008 38.284 35.670509313081155 139.741992049349 38.284 35.67051638065815 139.74198123803706 38.284 35.67050831637255 139.74197331599828 38.284 35.670501239782546 139.74198412732008 38.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-288e9ae4-46be-4e2a-a222-4dc9642ee66e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-288e9ae4-46be-4e2a-a222-4dc9642ee66e_0">
											<gml:posList>35.670509313081155 139.741992049349 37.584 35.67051638065815 139.74198123803706 37.584 35.67051638065815 139.74198123803706 38.284 35.670509313081155 139.741992049349 38.284 35.670509313081155 139.741992049349 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64147b2a-e127-473a-9b9c-c1cbd7191fc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64147b2a-e127-473a-9b9c-c1cbd7191fc4_0">
											<gml:posList>35.670501239782546 139.74198412732008 37.584 35.670509313081155 139.741992049349 37.584 35.670509313081155 139.741992049349 38.284 35.670501239782546 139.74198412732008 38.284 35.670501239782546 139.74198412732008 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3343603c-e08e-458d-8e66-228849c9351e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3343603c-e08e-458d-8e66-228849c9351e_0">
											<gml:posList>35.67048972767114 139.74201769901882 37.584 35.67048165436581 139.74200976594298 37.584 35.67048165436581 139.74200976594298 38.284 35.67048972767114 139.74201769901882 38.284 35.67048972767114 139.74201769901882 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f571d471-f11e-4163-ba3d-48102e44b57e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f571d471-f11e-4163-ba3d-48102e44b57e_0">
											<gml:posList>35.67048165436581 139.74200976594298 37.584 35.670474586794576 139.74202058829397 37.584 35.670474586794576 139.74202058829397 38.284 35.67048165436581 139.74200976594298 38.284 35.67048165436581 139.74200976594298 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26db721a-fa16-4b47-872a-b46686f312c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26db721a-fa16-4b47-872a-b46686f312c7_0">
											<gml:posList>35.67048165436581 139.74200976594298 38.284 35.670474586794576 139.74202058829397 38.284 35.670482660090826 139.74202851032393 38.284 35.67048972767114 139.74201769901882 38.284 35.67048165436581 139.74200976594298 38.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b59b04f4-e755-4479-b074-7448987f2cc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b59b04f4-e755-4479-b074-7448987f2cc3_0">
											<gml:posList>35.670482660090826 139.74202851032393 37.584 35.67048972767114 139.74201769901882 37.584 35.67048972767114 139.74201769901882 38.284 35.670482660090826 139.74202851032393 38.284 35.670482660090826 139.74202851032393 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a125a45d-7126-4e9c-a917-a890a5856f82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a125a45d-7126-4e9c-a917-a890a5856f82_0">
											<gml:posList>35.670474586794576 139.74202058829397 37.584 35.670482660090826 139.74202851032393 37.584 35.670482660090826 139.74202851032393 38.284 35.670474586794576 139.74202058829397 38.284 35.670474586794576 139.74202058829397 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ee56c860-58ac-4415-89de-8b1ebbf5d093">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee56c860-58ac-4415-89de-8b1ebbf5d093">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee56c860-58ac-4415-89de-8b1ebbf5d093">
											<gml:posList>35.67054112367279 139.74188666471977 7.87 35.67054981027878 139.74187133361772 7.87 35.67058995017702 139.7419092539216 7.87 35.67048767771497 139.74207208216248 7.87 35.67042111037815 139.74201140347344 7.87 35.67050105415127 139.74188207098538 7.87 35.670510256118106 139.7418925544531 7.87 35.67050817704339 139.74189663290053 7.87 35.670524234311046 139.7419135264421 7.87 35.67054112367279 139.74188666471977 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-10a94007-05ee-4061-9051-ce03cf08ef51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10a94007-05ee-4061-9051-ce03cf08ef51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10a94007-05ee-4061-9051-ce03cf08ef51">
											<gml:posList>35.67055069898488 139.74187839117883 38.085 35.67054981027878 139.74187133361772 38.085 35.67054112367279 139.74188666471977 38.085 35.67054414544266 139.74188952226035 38.085 35.67055069898488 139.74187839117883 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0c1c4b1-a4ae-49c2-8d0f-ceceff74319e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0c1c4b1-a4ae-49c2-8d0f-ceceff74319e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0c1c4b1-a4ae-49c2-8d0f-ceceff74319e">
											<gml:posList>35.670510256118106 139.7418925544531 38.085 35.67050105415127 139.74188207098538 38.085 35.670501582500776 139.74188938301762 38.085 35.670505109919866 139.74189339983928 38.085 35.670510256118106 139.7418925544531 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-562e792d-ca18-49be-91cf-d8b6fd9c85fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-562e792d-ca18-49be-91cf-d8b6fd9c85fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-562e792d-ca18-49be-91cf-d8b6fd9c85fe">
											<gml:posList>35.67054981027878 139.74187133361772 38.085 35.67055069898488 139.74187839117883 38.085 35.67058432629335 139.7419101550837 38.085 35.67058995017702 139.7419092539216 38.085 35.67054981027878 139.74187133361772 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8e5a5bc-5888-4d4a-9391-60ecb9dc28f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8e5a5bc-5888-4d4a-9391-60ecb9dc28f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8e5a5bc-5888-4d4a-9391-60ecb9dc28f7">
											<gml:posList>35.67050817704339 139.74189663290053 38.085 35.670510256118106 139.7418925544531 38.085 35.670505109919866 139.74189339983928 38.085 35.670502958844374 139.74189762197017 38.085 35.67050817704339 139.74189663290053 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e1ee5190-7b0d-4499-bed3-cea0ba71a792">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1ee5190-7b0d-4499-bed3-cea0ba71a792">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1ee5190-7b0d-4499-bed3-cea0ba71a792">
											<gml:posList>35.67054112367279 139.74188666471977 42.32 35.670541623051506 139.74189143614396 42.32 35.67056430885305 139.74191286215617 42.32 35.67056820231164 139.74191223912473 42.32 35.67054112367279 139.74188666471977 42.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c08fe5d6-8c62-4a10-816d-3d1c7a08dd72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c08fe5d6-8c62-4a10-816d-3d1c7a08dd72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c08fe5d6-8c62-4a10-816d-3d1c7a08dd72">
											<gml:posList>35.67052272182546 139.74191592520927 42.32 35.670526615292474 139.74191531322458 42.32 35.670541623051506 139.74189143614396 42.32 35.67054112367279 139.74188666471977 42.32 35.67052272182546 139.74191592520927 42.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb79a64a-827b-4076-a057-149060de34d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb79a64a-827b-4076-a057-149060de34d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb79a64a-827b-4076-a057-149060de34d0">
											<gml:posList>35.670502958844374 139.74189762197017 38.085 35.6705219115716 139.74191721854777 38.085 35.67052272182546 139.74191592520927 38.085 35.670524234311046 139.7419135264421 38.085 35.67050817704339 139.74189663290053 38.085 35.670502958844374 139.74189762197017 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bbfc4660-a40d-4740-b9f8-865b1085f9a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbfc4660-a40d-4740-b9f8-865b1085f9a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbfc4660-a40d-4740-b9f8-865b1085f9a6">
											<gml:posList>35.67056430885305 139.74191286215617 42.104 35.670541623051506 139.74189143614396 42.104 35.670526615292474 139.74191531322458 42.104 35.67054930109822 139.74193675028584 42.104 35.67056430885305 139.74191286215617 42.104</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0280403d-d2ee-44a0-a590-208dd48c2454">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0280403d-d2ee-44a0-a590-208dd48c2454">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0280403d-d2ee-44a0-a590-208dd48c2454">
											<gml:posList>35.67056820231164 139.74191223912473 42.32 35.67056430885305 139.74191286215617 42.32 35.67054930109822 139.74193675028584 42.32 35.67054980046656 139.74194151066453 42.32 35.67056820231164 139.74191223912473 42.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3c8a600c-510a-4140-8315-546362320fda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c8a600c-510a-4140-8315-546362320fda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c8a600c-510a-4140-8315-546362320fda">
											<gml:posList>35.67054980046656 139.74194151066453 42.32 35.67054930109822 139.74193675028584 42.32 35.670526615292474 139.74191531322458 42.32 35.67052272182546 139.74191592520927 42.32 35.67054980046656 139.74194151066453 42.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-39fb7ec7-2800-4099-924a-bc85d28c7152">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39fb7ec7-2800-4099-924a-bc85d28c7152">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39fb7ec7-2800-4099-924a-bc85d28c7152">
											<gml:posList>35.67042111037815 139.74201140347344 38.085 35.67042676124526 139.74201042496568 38.085 35.670501582500776 139.74188938301762 38.085 35.67050105415127 139.74188207098538 38.085 35.67042111037815 139.74201140347344 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20172063-5b64-44fc-ba57-c7626ab3bc28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20172063-5b64-44fc-ba57-c7626ab3bc28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20172063-5b64-44fc-ba57-c7626ab3bc28">
											<gml:posList>35.670501582500776 139.74188938301762 37.584 35.67042676124526 139.74201042496568 37.584 35.670486915388175 139.74206525643265 37.584 35.67058432629335 139.7419101550837 37.584 35.67055069898488 139.74187839117883 37.584 35.67054414544266 139.74188952226035 37.584 35.67056820231164 139.74191223912473 37.584 35.67054980046656 139.74194151066453 37.584 35.67052272182546 139.74191592520927 37.584 35.6705219115716 139.74191721854777 37.584 35.670502958844374 139.74189762197017 37.584 35.670505109919866 139.74189339983928 37.584 35.670501582500776 139.74188938301762 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46084cf2-d431-486b-9fa5-62d8ff725e8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46084cf2-d431-486b-9fa5-62d8ff725e8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46084cf2-d431-486b-9fa5-62d8ff725e8f">
											<gml:posList>35.67058995017702 139.7419092539216 38.085 35.67058432629335 139.7419101550837 38.085 35.670486915388175 139.74206525643265 38.085 35.67048767771497 139.74207208216248 38.085 35.67058995017702 139.7419092539216 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c00dd557-d095-4beb-8959-e0fa6c6fb6a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c00dd557-d095-4beb-8959-e0fa6c6fb6a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c00dd557-d095-4beb-8959-e0fa6c6fb6a8">
											<gml:posList>35.67048767771497 139.74207208216248 38.085 35.670486915388175 139.74206525643265 38.085 35.67042676124526 139.74201042496568 38.085 35.67042111037815 139.74201140347344 38.085 35.67048767771497 139.74207208216248 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58503375-b0a9-4082-b291-fb6673ee6f36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58503375-b0a9-4082-b291-fb6673ee6f36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58503375-b0a9-4082-b291-fb6673ee6f36">
											<gml:posList>35.670501582500776 139.74188938301762 38.085 35.670501582500776 139.74188938301762 37.584 35.670505109919866 139.74189339983928 37.584 35.670505109919866 139.74189339983928 38.085 35.670501582500776 139.74188938301762 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4873603-b6ce-490d-a6b7-afc3f1889545">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4873603-b6ce-490d-a6b7-afc3f1889545">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4873603-b6ce-490d-a6b7-afc3f1889545">
											<gml:posList>35.670505109919866 139.74189339983928 38.085 35.670505109919866 139.74189339983928 37.584 35.670502958844374 139.74189762197017 37.584 35.670502958844374 139.74189762197017 38.085 35.670505109919866 139.74189339983928 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b0b0e40-bd67-4d74-91a5-e05261523b88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b0b0e40-bd67-4d74-91a5-e05261523b88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b0b0e40-bd67-4d74-91a5-e05261523b88">
											<gml:posList>35.670541623051506 139.74189143614396 42.32 35.670541623051506 139.74189143614396 42.104 35.67056430885305 139.74191286215617 42.104 35.67056430885305 139.74191286215617 42.32 35.670541623051506 139.74189143614396 42.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44e0ebe8-eed4-4624-bb42-81507ef14331">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44e0ebe8-eed4-4624-bb42-81507ef14331">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44e0ebe8-eed4-4624-bb42-81507ef14331">
											<gml:posList>35.67054930109822 139.74193675028584 42.32 35.67054930109822 139.74193675028584 42.104 35.670526615292474 139.74191531322458 42.104 35.670526615292474 139.74191531322458 42.32 35.67054930109822 139.74193675028584 42.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1abd4414-528c-4a09-93d4-8eec5f9b3845">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1abd4414-528c-4a09-93d4-8eec5f9b3845">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1abd4414-528c-4a09-93d4-8eec5f9b3845">
											<gml:posList>35.67048767771497 139.74207208216248 7.87 35.67058995017702 139.7419092539216 7.87 35.67058995017702 139.7419092539216 38.085 35.67048767771497 139.74207208216248 38.085 35.67048767771497 139.74207208216248 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63a4b3b5-3685-47d2-8f3a-d9ebfc0874f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63a4b3b5-3685-47d2-8f3a-d9ebfc0874f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63a4b3b5-3685-47d2-8f3a-d9ebfc0874f9">
											<gml:posList>35.67042111037815 139.74201140347344 7.87 35.67048767771497 139.74207208216248 7.87 35.67048767771497 139.74207208216248 38.085 35.67042111037815 139.74201140347344 38.085 35.67042111037815 139.74201140347344 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa4551d8-de91-484c-949e-30d152fc2b60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa4551d8-de91-484c-949e-30d152fc2b60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa4551d8-de91-484c-949e-30d152fc2b60">
											<gml:posList>35.670486915388175 139.74206525643265 38.085 35.670486915388175 139.74206525643265 37.584 35.67042676124526 139.74201042496568 37.584 35.67042676124526 139.74201042496568 38.085 35.670486915388175 139.74206525643265 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b2b9c06-216a-427c-bf03-d1b81df16621">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b2b9c06-216a-427c-bf03-d1b81df16621">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b2b9c06-216a-427c-bf03-d1b81df16621">
											<gml:posList>35.67050105415127 139.74188207098538 7.87 35.67042111037815 139.74201140347344 7.87 35.67042111037815 139.74201140347344 38.085 35.67050105415127 139.74188207098538 38.085 35.67050105415127 139.74188207098538 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a51f9796-38e8-4ae2-8daf-79a215d546be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a51f9796-38e8-4ae2-8daf-79a215d546be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a51f9796-38e8-4ae2-8daf-79a215d546be">
											<gml:posList>35.670510256118106 139.7418925544531 7.87 35.67050105415127 139.74188207098538 7.87 35.67050105415127 139.74188207098538 38.085 35.670510256118106 139.7418925544531 38.085 35.670510256118106 139.7418925544531 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61c6c802-bb16-4c17-b784-7c49d3d88a2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61c6c802-bb16-4c17-b784-7c49d3d88a2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61c6c802-bb16-4c17-b784-7c49d3d88a2d">
											<gml:posList>35.67050817704339 139.74189663290053 7.87 35.670510256118106 139.7418925544531 7.87 35.670510256118106 139.7418925544531 38.085 35.67050817704339 139.74189663290053 38.085 35.67050817704339 139.74189663290053 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1999085c-44b7-4dae-84f7-3a8fb25cd904">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1999085c-44b7-4dae-84f7-3a8fb25cd904">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1999085c-44b7-4dae-84f7-3a8fb25cd904">
											<gml:posList>35.670502958844374 139.74189762197017 38.085 35.670502958844374 139.74189762197017 37.584 35.6705219115716 139.74191721854777 37.584 35.6705219115716 139.74191721854777 38.085 35.670502958844374 139.74189762197017 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf232a49-a46b-44b7-841a-bf873cf8dc2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf232a49-a46b-44b7-841a-bf873cf8dc2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf232a49-a46b-44b7-841a-bf873cf8dc2d">
											<gml:posList>35.670524234311046 139.7419135264421 7.87 35.67050817704339 139.74189663290053 7.87 35.67050817704339 139.74189663290053 38.085 35.670524234311046 139.7419135264421 38.085 35.670524234311046 139.7419135264421 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37f5496f-0fb5-493b-b5e4-027e8b3b5359">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37f5496f-0fb5-493b-b5e4-027e8b3b5359">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37f5496f-0fb5-493b-b5e4-027e8b3b5359">
											<gml:posList>35.67052272182546 139.74191592520927 42.32 35.67054112367279 139.74188666471977 42.32 35.67054112367279 139.74188666471977 38.085 35.67054112367279 139.74188666471977 7.87 35.670524234311046 139.7419135264421 7.87 35.670524234311046 139.7419135264421 38.085 35.67052272182546 139.74191592520927 38.085 35.67052272182546 139.74191592520927 42.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3be902a8-3afe-4492-9bf4-ebbbe401064e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3be902a8-3afe-4492-9bf4-ebbbe401064e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3be902a8-3afe-4492-9bf4-ebbbe401064e">
											<gml:posList>35.670526615292474 139.74191531322458 42.32 35.670526615292474 139.74191531322458 42.104 35.670541623051506 139.74189143614396 42.104 35.670541623051506 139.74189143614396 42.32 35.670526615292474 139.74191531322458 42.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca89881c-7091-4e5c-b5fe-2b2e08156c55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca89881c-7091-4e5c-b5fe-2b2e08156c55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca89881c-7091-4e5c-b5fe-2b2e08156c55">
											<gml:posList>35.67058432629335 139.7419101550837 38.085 35.67058432629335 139.7419101550837 37.584 35.670486915388175 139.74206525643265 37.584 35.670486915388175 139.74206525643265 38.085 35.67058432629335 139.7419101550837 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c9f9e6c-3b18-4fcf-b670-0048e14f7744">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c9f9e6c-3b18-4fcf-b670-0048e14f7744">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c9f9e6c-3b18-4fcf-b670-0048e14f7744">
											<gml:posList>35.67054980046656 139.74194151066453 37.584 35.67054980046656 139.74194151066453 42.32 35.67052272182546 139.74191592520927 42.32 35.67052272182546 139.74191592520927 38.085 35.67052272182546 139.74191592520927 37.584 35.67054980046656 139.74194151066453 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98a230af-460e-41f7-8a6d-5bf694e3c467">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98a230af-460e-41f7-8a6d-5bf694e3c467">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98a230af-460e-41f7-8a6d-5bf694e3c467">
											<gml:posList>35.67054981027878 139.74187133361772 7.87 35.67054112367279 139.74188666471977 7.87 35.67054112367279 139.74188666471977 38.085 35.67054981027878 139.74187133361772 38.085 35.67054981027878 139.74187133361772 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-358028bb-16d2-4674-b9bd-ea49041e3f13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-358028bb-16d2-4674-b9bd-ea49041e3f13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-358028bb-16d2-4674-b9bd-ea49041e3f13">
											<gml:posList>35.67054414544266 139.74188952226035 38.085 35.67054414544266 139.74188952226035 37.584 35.67055069898488 139.74187839117883 37.584 35.67055069898488 139.74187839117883 38.085 35.67054414544266 139.74188952226035 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6ae34e3-64b6-4c86-9d70-825763fac8a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6ae34e3-64b6-4c86-9d70-825763fac8a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6ae34e3-64b6-4c86-9d70-825763fac8a0">
											<gml:posList>35.67054414544266 139.74188952226035 38.085 35.67054112367279 139.74188666471977 38.085 35.67054112367279 139.74188666471977 42.32 35.67056820231164 139.74191223912473 42.32 35.67056820231164 139.74191223912473 37.584 35.67054414544266 139.74188952226035 37.584 35.67054414544266 139.74188952226035 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82d9c995-7303-442b-a039-53d371d82efe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82d9c995-7303-442b-a039-53d371d82efe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82d9c995-7303-442b-a039-53d371d82efe">
											<gml:posList>35.67056430885305 139.74191286215617 42.32 35.67056430885305 139.74191286215617 42.104 35.67054930109822 139.74193675028584 42.104 35.67054930109822 139.74193675028584 42.32 35.67056430885305 139.74191286215617 42.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83c504a9-3fb0-4841-a08b-d9ba19981e84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83c504a9-3fb0-4841-a08b-d9ba19981e84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83c504a9-3fb0-4841-a08b-d9ba19981e84">
											<gml:posList>35.67054980046656 139.74194151066453 37.584 35.67056820231164 139.74191223912473 37.584 35.67056820231164 139.74191223912473 42.32 35.67054980046656 139.74194151066453 42.32 35.67054980046656 139.74194151066453 37.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8c55c2b-8d0b-41ff-a27d-d006c0a37bda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8c55c2b-8d0b-41ff-a27d-d006c0a37bda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8c55c2b-8d0b-41ff-a27d-d006c0a37bda">
											<gml:posList>35.67055069898488 139.74187839117883 38.085 35.67055069898488 139.74187839117883 37.584 35.67058432629335 139.7419101550837 37.584 35.67058432629335 139.7419101550837 38.085 35.67055069898488 139.74187839117883 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef0f811c-7fba-4825-9fd7-ccccee1c5e71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef0f811c-7fba-4825-9fd7-ccccee1c5e71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef0f811c-7fba-4825-9fd7-ccccee1c5e71">
											<gml:posList>35.67058995017702 139.7419092539216 7.87 35.67054981027878 139.74187133361772 7.87 35.67054981027878 139.74187133361772 38.085 35.67058995017702 139.7419092539216 38.085 35.67058995017702 139.7419092539216 7.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84f53497-434d-4934-88c4-1bc06b8ca3d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84f53497-434d-4934-88c4-1bc06b8ca3d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84f53497-434d-4934-88c4-1bc06b8ca3d3">
											<gml:posList>35.6705219115716 139.74191721854777 38.085 35.6705219115716 139.74191721854777 37.584 35.67052272182546 139.74191592520927 37.584 35.67052272182546 139.74191592520927 38.085 35.6705219115716 139.74191721854777 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e512cf01-d880-4914-84b0-d2eb2e0993b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e512cf01-d880-4914-84b0-d2eb2e0993b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e512cf01-d880-4914-84b0-d2eb2e0993b9">
											<gml:posList>35.67042676124526 139.74201042496568 38.085 35.67042676124526 139.74201042496568 37.584 35.670501582500776 139.74188938301762 37.584 35.670501582500776 139.74188938301762 38.085 35.67042676124526 139.74201042496568 38.085</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5751</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">167.4819</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>