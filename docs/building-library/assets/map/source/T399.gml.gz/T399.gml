<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_72eb1250-0baa-4d7f-8707-e66af49e7fdf">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">13.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669171606590425 139.7388309995423 0 35.66922283475295 139.73875461061434 0 35.66918833093082 139.7387211374614 0 35.66916339730205 139.7386961033007 0 35.669112700491404 139.73877186195583 0 35.669171606590425 139.7388309995423 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669171606590425 139.7388309995423 15.276 35.669112700491404 139.73877186195583 15.276 35.66916339730205 139.7386961033007 15.276 35.66918833093082 139.7387211374614 15.276 35.66922283475295 139.73875461061434 15.276 35.669171606590425 139.7388309995423 15.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669171606590425 139.7388309995423 15.276 35.66922283475295 139.73875461061434 15.276 35.66922283475295 139.73875461061434 28.34 35.669171606590425 139.7388309995423 28.34 35.669171606590425 139.7388309995423 15.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922283475295 139.73875461061434 15.276 35.66918833093082 139.7387211374614 15.276 35.66918833093082 139.7387211374614 28.34 35.66922283475295 139.73875461061434 28.34 35.66922283475295 139.73875461061434 15.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66918833093082 139.7387211374614 15.276 35.66916339730205 139.7386961033007 15.276 35.66916339730205 139.7386961033007 28.34 35.66918833093082 139.7387211374614 28.34 35.66918833093082 139.7387211374614 15.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66916339730205 139.7386961033007 15.276 35.669112700491404 139.73877186195583 15.276 35.669112700491404 139.73877186195583 28.34 35.66916339730205 139.7386961033007 28.34 35.66916339730205 139.7386961033007 15.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669112700491404 139.73877186195583 15.276 35.669171606590425 139.7388309995423 15.276 35.669171606590425 139.7388309995423 28.34 35.669112700491404 139.73877186195583 28.34 35.669112700491404 139.73877186195583 15.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669171606590425 139.7388309995423 28.34 35.66922283475295 139.73875461061434 28.34 35.66918833093082 139.7387211374614 28.34 35.66916339730205 139.7386961033007 28.34 35.669112700491404 139.73877186195583 28.34 35.669171606590425 139.7388309995423 28.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-04000afd-7205-41b4-b2ec-5ba800f0e9fc"/>
							<gml:surfaceMember xlink:href="#poly-77988be9-df6e-4305-b546-e1920bd770aa"/>
							<gml:surfaceMember xlink:href="#poly-597be127-2415-4428-b3f4-328c3dfd4013"/>
							<gml:surfaceMember xlink:href="#poly-c8764ef6-e89b-43bb-9321-bb0e8a284194"/>
							<gml:surfaceMember xlink:href="#poly-eaabed29-71f3-40ce-a91d-f1f5bb6e16d2"/>
							<gml:surfaceMember xlink:href="#poly-9a76c557-2c59-48ee-80d7-a2dad140d2e4"/>
							<gml:surfaceMember xlink:href="#poly-901bee24-fc36-4b5f-9263-ab723aefa8dd"/>
							<gml:surfaceMember xlink:href="#poly-6e3efc10-f18f-4f89-847f-9d21b41af125"/>
							<gml:surfaceMember xlink:href="#poly-6dcb0e2d-d7d9-4fbb-a710-f2c16b840a71"/>
							<gml:surfaceMember xlink:href="#poly-1ee5c0b8-1e3d-4ac9-ada4-c32d22b19e00"/>
							<gml:surfaceMember xlink:href="#poly-6108526a-ffa8-45bf-a2f8-9e6fa35e2c4e"/>
							<gml:surfaceMember xlink:href="#poly-9ee14f41-626b-4124-b5aa-40d9ee70979e"/>
							<gml:surfaceMember xlink:href="#poly-33261871-95a5-4b46-a147-7b4a286fc45a"/>
							<gml:surfaceMember xlink:href="#poly-87c489e7-c668-49da-a0a4-2a9f8acce54c"/>
							<gml:surfaceMember xlink:href="#poly-230349d9-b85f-4890-b576-864ceaa0207b"/>
							<gml:surfaceMember xlink:href="#poly-3bf3bf70-1bb3-4044-9b76-89caa9142298"/>
							<gml:surfaceMember xlink:href="#poly-27d3de25-dc54-404b-95a1-45c7e01afd6f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_72eb1250-0baa-4d7f-8707-e66af49e7fdf_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-619ccd27-b88f-44db-bee5-d5fe96a751ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66917491233689 139.73867889094245 15.276 35.6692285864425 139.73873284301163 15.276 35.66921754862414 139.738749414137 15.276 35.669163424334506 139.73869609222268 15.276 35.66917491233689 139.73867889094245 15.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29507dfd-b33d-4e7a-9582-ec5ced59ddf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29507dfd-b33d-4e7a-9582-ec5ced59ddf4_0">
											<gml:posList>35.669163424334506 139.73869609222268 15.276 35.669163424334506 139.73869609222268 29.653 35.66917491233689 139.73867889094245 29.653 35.66917491233689 139.73867889094245 15.276 35.669163424334506 139.73869609222268 15.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e24ffa7-976f-4ffc-b4d8-435dbeffae78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e24ffa7-976f-4ffc-b4d8-435dbeffae78_0">
											<gml:posList>35.669187261892816 139.73869130322046 29.653 35.66917491233689 139.73867889094245 29.653 35.669163424334506 139.73869609222268 29.653 35.669175881914484 139.7387083276366 29.653 35.669187261892816 139.73869130322046 29.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9034cfff-5db9-4344-8d40-d27aca549ce3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9034cfff-5db9-4344-8d40-d27aca549ce3_0">
											<gml:posList>35.6692176026284 139.7387493146584 24.702 35.669175881914484 139.7387083276366 29.653 35.669163424334506 139.73869609222268 29.653 35.669163424334506 139.73869609222268 15.276 35.66921754862414 139.738749414137 15.276 35.6692176026284 139.7387493146584 24.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33929f64-1217-4b16-a3e8-1924686ac79a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33929f64-1217-4b16-a3e8-1924686ac79a_0">
											<gml:posList>35.6692285864425 139.73873284301163 15.276 35.66917491233689 139.73867889094245 15.276 35.66917491233689 139.73867889094245 29.653 35.669187261892816 139.73869130322046 29.653 35.6692285864425 139.73873284301163 24.702 35.6692285864425 139.73873284301163 15.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19bd2fd2-1f04-44f8-8c16-5ed933311060">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19bd2fd2-1f04-44f8-8c16-5ed933311060_0">
											<gml:posList>35.6692176026284 139.7387493146584 24.702 35.6692285864425 139.73873284301163 24.702 35.669187261892816 139.73869130322046 29.653 35.669175881914484 139.7387083276366 29.653 35.6692176026284 139.7387493146584 24.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94f0b34a-bb7b-4818-8855-9e68479f49bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94f0b34a-bb7b-4818-8855-9e68479f49bd_0">
											<gml:posList>35.66921754862414 139.738749414137 15.276 35.6692285864425 139.73873284301163 15.276 35.6692285864425 139.73873284301163 24.702 35.6692176026284 139.7387493146584 24.702 35.66921754862414 139.738749414137 15.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-04000afd-7205-41b4-b2ec-5ba800f0e9fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04000afd-7205-41b4-b2ec-5ba800f0e9fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04000afd-7205-41b4-b2ec-5ba800f0e9fc">
											<gml:posList>35.66911270049136 139.7387718619558 15.276 35.669163397302015 139.7386961033007 15.276 35.6691883309308 139.7387211374614 15.276 35.66922283475294 139.73875461061434 15.276 35.669171606590425 139.73883099954227 15.276 35.66911270049136 139.7387718619558 15.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-77988be9-df6e-4305-b546-e1920bd770aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77988be9-df6e-4305-b546-e1920bd770aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77988be9-df6e-4305-b546-e1920bd770aa">
											<gml:posList>35.669163397302015 139.7386961033007 31.837 35.66916365216045 139.738699251136 31.837 35.669185780307274 139.73872147185392 31.837 35.6691883309308 139.7387211374614 31.837 35.669163397302015 139.7386961033007 31.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-597be127-2415-4428-b3f4-328c3dfd4013">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-597be127-2415-4428-b3f4-328c3dfd4013">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-597be127-2415-4428-b3f4-328c3dfd4013">
											<gml:posList>35.66911270049136 139.7387718619558 31.837 35.66911526915986 139.73877154963606 31.837 35.66916365216045 139.738699251136 31.837 35.669163397302015 139.7386961033007 31.837 35.66911270049136 139.7387718619558 31.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8764ef6-e89b-43bb-9321-bb0e8a284194">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8764ef6-e89b-43bb-9321-bb0e8a284194">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8764ef6-e89b-43bb-9321-bb0e8a284194">
											<gml:posList>35.669185780307274 139.73872147185392 31.463 35.66916365216045 139.738699251136 31.463 35.66911526915986 139.73877154963606 31.463 35.66913789343862 139.73879426684957 31.463 35.669185780307274 139.73872147185392 31.463</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eaabed29-71f3-40ce-a91d-f1f5bb6e16d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eaabed29-71f3-40ce-a91d-f1f5bb6e16d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eaabed29-71f3-40ce-a91d-f1f5bb6e16d2">
											<gml:posList>35.6691883309308 139.7387211374614 31.837 35.669185780307274 139.73872147185392 31.837 35.66913789343862 139.73879426684957 31.837 35.669138148294486 139.7387974146842 31.837 35.6691883309308 139.7387211374614 31.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a76c557-2c59-48ee-80d7-a2dad140d2e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a76c557-2c59-48ee-80d7-a2dad140d2e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a76c557-2c59-48ee-80d7-a2dad140d2e4">
											<gml:posList>35.669138148294486 139.7387974146842 31.837 35.66922283475294 139.73875461061434 24.702 35.6691883309308 139.7387211374614 31.837 35.669138148294486 139.7387974146842 31.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-901bee24-fc36-4b5f-9263-ab723aefa8dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-901bee24-fc36-4b5f-9263-ab723aefa8dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-901bee24-fc36-4b5f-9263-ab723aefa8dd">
											<gml:posList>35.669138148294486 139.7387974146842 31.837 35.66913789343862 139.73879426684957 31.837 35.66911526915986 139.73877154963606 31.837 35.66911270049136 139.7387718619558 31.837 35.669138148294486 139.7387974146842 31.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6e3efc10-f18f-4f89-847f-9d21b41af125">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e3efc10-f18f-4f89-847f-9d21b41af125">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e3efc10-f18f-4f89-847f-9d21b41af125">
											<gml:posList>35.669138148294486 139.7387974146842 31.837 35.669171606590425 139.73883099954227 24.702 35.66922283475294 139.73875461061434 24.702 35.669138148294486 139.7387974146842 31.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6dcb0e2d-d7d9-4fbb-a710-f2c16b840a71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dcb0e2d-d7d9-4fbb-a710-f2c16b840a71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dcb0e2d-d7d9-4fbb-a710-f2c16b840a71">
											<gml:posList>35.669185780307274 139.73872147185392 31.837 35.669185780307274 139.73872147185392 31.463 35.66913789343862 139.73879426684957 31.463 35.66913789343862 139.73879426684957 31.837 35.669185780307274 139.73872147185392 31.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ee5c0b8-1e3d-4ac9-ada4-c32d22b19e00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ee5c0b8-1e3d-4ac9-ada4-c32d22b19e00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ee5c0b8-1e3d-4ac9-ada4-c32d22b19e00">
											<gml:posList>35.6691883309308 139.7387211374614 31.837 35.6691883309308 139.7387211374614 15.276 35.669163397302015 139.7386961033007 15.276 35.669163397302015 139.7386961033007 31.837 35.6691883309308 139.7387211374614 31.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6108526a-ffa8-45bf-a2f8-9e6fa35e2c4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6108526a-ffa8-45bf-a2f8-9e6fa35e2c4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6108526a-ffa8-45bf-a2f8-9e6fa35e2c4e">
											<gml:posList>35.66916365216045 139.738699251136 31.837 35.66916365216045 139.738699251136 31.463 35.669185780307274 139.73872147185392 31.463 35.669185780307274 139.73872147185392 31.837 35.66916365216045 139.738699251136 31.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ee14f41-626b-4124-b5aa-40d9ee70979e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ee14f41-626b-4124-b5aa-40d9ee70979e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ee14f41-626b-4124-b5aa-40d9ee70979e">
											<gml:posList>35.66911270049136 139.7387718619558 31.837 35.669163397302015 139.7386961033007 31.837 35.669163397302015 139.7386961033007 15.276 35.66911270049136 139.7387718619558 15.276 35.66911270049136 139.7387718619558 31.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33261871-95a5-4b46-a147-7b4a286fc45a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33261871-95a5-4b46-a147-7b4a286fc45a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33261871-95a5-4b46-a147-7b4a286fc45a">
											<gml:posList>35.66911526915986 139.73877154963606 31.837 35.66911526915986 139.73877154963606 31.463 35.66916365216045 139.738699251136 31.463 35.66916365216045 139.738699251136 31.837 35.66911526915986 139.73877154963606 31.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87c489e7-c668-49da-a0a4-2a9f8acce54c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87c489e7-c668-49da-a0a4-2a9f8acce54c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87c489e7-c668-49da-a0a4-2a9f8acce54c">
											<gml:posList>35.6691883309308 139.7387211374614 15.276 35.6691883309308 139.7387211374614 31.837 35.66922283475294 139.73875461061434 24.702 35.66922283475294 139.73875461061434 15.276 35.6691883309308 139.7387211374614 15.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-230349d9-b85f-4890-b576-864ceaa0207b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-230349d9-b85f-4890-b576-864ceaa0207b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-230349d9-b85f-4890-b576-864ceaa0207b">
											<gml:posList>35.66913789343862 139.73879426684957 31.837 35.66913789343862 139.73879426684957 31.463 35.66911526915986 139.73877154963606 31.463 35.66911526915986 139.73877154963606 31.837 35.66913789343862 139.73879426684957 31.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3bf3bf70-1bb3-4044-9b76-89caa9142298">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bf3bf70-1bb3-4044-9b76-89caa9142298">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bf3bf70-1bb3-4044-9b76-89caa9142298">
											<gml:posList>35.669171606590425 139.73883099954227 15.276 35.66922283475294 139.73875461061434 15.276 35.66922283475294 139.73875461061434 24.702 35.669171606590425 139.73883099954227 24.702 35.669171606590425 139.73883099954227 15.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27d3de25-dc54-404b-95a1-45c7e01afd6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27d3de25-dc54-404b-95a1-45c7e01afd6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27d3de25-dc54-404b-95a1-45c7e01afd6f">
											<gml:posList>35.669171606590425 139.73883099954227 24.702 35.669138148294486 139.7387974146842 31.837 35.66911270049136 139.7387718619558 31.837 35.66911270049136 139.7387718619558 15.276 35.669171606590425 139.73883099954227 15.276 35.669171606590425 139.73883099954227 24.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5068</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">90.38886</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>