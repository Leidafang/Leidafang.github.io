<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_730de946-39af-4a63-b577-d2e17f33b378">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67386474723852 139.73799437712512 0 35.67389335681463 139.73798300914254 0 35.6738882396182 139.73796352877508 0 35.67385959394529 139.73797484157313 0 35.67386474723852 139.73799437712512 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67386474723852 139.73799437712512 9.049 35.67385959394529 139.73797484157313 9.049 35.6738882396182 139.73796352877508 9.049 35.67389335681463 139.73798300914254 9.049 35.67386474723852 139.73799437712512 9.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67386474723852 139.73799437712512 9.049 35.67389335681463 139.73798300914254 9.049 35.67389335681463 139.73798300914254 12.049 35.67386474723852 139.73799437712512 12.049 35.67386474723852 139.73799437712512 9.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67389335681463 139.73798300914254 9.049 35.6738882396182 139.73796352877508 9.049 35.6738882396182 139.73796352877508 12.049 35.67389335681463 139.73798300914254 12.049 35.67389335681463 139.73798300914254 9.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6738882396182 139.73796352877508 9.049 35.67385959394529 139.73797484157313 9.049 35.67385959394529 139.73797484157313 12.049 35.6738882396182 139.73796352877508 12.049 35.6738882396182 139.73796352877508 9.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67385959394529 139.73797484157313 9.049 35.67386474723852 139.73799437712512 9.049 35.67386474723852 139.73799437712512 12.049 35.67385959394529 139.73797484157313 12.049 35.67385959394529 139.73797484157313 9.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67386474723852 139.73799437712512 12.049 35.67389335681463 139.73798300914254 12.049 35.6738882396182 139.73796352877508 12.049 35.67385959394529 139.73797484157313 12.049 35.67386474723852 139.73799437712512 12.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-726ccba6-4b38-45b7-b54e-4706a1c9ab2f"/>
							<gml:surfaceMember xlink:href="#poly-a4a37778-f15b-4e93-aa3e-14e6b89b7490"/>
							<gml:surfaceMember xlink:href="#poly-021212c7-b8f8-4f86-bcd8-94776fbc2364"/>
							<gml:surfaceMember xlink:href="#poly-d38bdfe3-a355-43c0-b20a-0d36fff26eff"/>
							<gml:surfaceMember xlink:href="#poly-ddd12315-cb58-4bf4-b689-1d276c7ea587"/>
							<gml:surfaceMember xlink:href="#poly-81a7f12f-928d-48aa-afc9-be5604ab732e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-726ccba6-4b38-45b7-b54e-4706a1c9ab2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-726ccba6-4b38-45b7-b54e-4706a1c9ab2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-726ccba6-4b38-45b7-b54e-4706a1c9ab2f">
											<gml:posList>35.6738647472385 139.73799437712512 9.049 35.67385959394529 139.7379748415731 9.049 35.6738882396182 139.73796352877505 9.049 35.67389335681464 139.73798300914254 9.049 35.6738647472385 139.73799437712512 9.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4a37778-f15b-4e93-aa3e-14e6b89b7490">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4a37778-f15b-4e93-aa3e-14e6b89b7490">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4a37778-f15b-4e93-aa3e-14e6b89b7490">
											<gml:posList>35.6738882396182 139.73796352877505 12.125 35.67385959394529 139.7379748415731 12.125 35.6738647472385 139.73799437712512 12.125 35.67389335681464 139.73798300914254 12.125 35.6738882396182 139.73796352877505 12.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-021212c7-b8f8-4f86-bcd8-94776fbc2364">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-021212c7-b8f8-4f86-bcd8-94776fbc2364">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-021212c7-b8f8-4f86-bcd8-94776fbc2364">
											<gml:posList>35.6738882396182 139.73796352877505 9.049 35.67385959394529 139.7379748415731 9.049 35.67385959394529 139.7379748415731 12.125 35.6738882396182 139.73796352877505 12.125 35.6738882396182 139.73796352877505 9.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d38bdfe3-a355-43c0-b20a-0d36fff26eff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d38bdfe3-a355-43c0-b20a-0d36fff26eff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d38bdfe3-a355-43c0-b20a-0d36fff26eff">
											<gml:posList>35.67389335681464 139.73798300914254 9.049 35.6738882396182 139.73796352877505 9.049 35.6738882396182 139.73796352877505 12.125 35.67389335681464 139.73798300914254 12.125 35.67389335681464 139.73798300914254 9.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ddd12315-cb58-4bf4-b689-1d276c7ea587">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ddd12315-cb58-4bf4-b689-1d276c7ea587">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ddd12315-cb58-4bf4-b689-1d276c7ea587">
											<gml:posList>35.67385959394529 139.7379748415731 9.049 35.6738647472385 139.73799437712512 9.049 35.6738647472385 139.73799437712512 12.125 35.67385959394529 139.7379748415731 12.125 35.67385959394529 139.7379748415731 9.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81a7f12f-928d-48aa-afc9-be5604ab732e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81a7f12f-928d-48aa-afc9-be5604ab732e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81a7f12f-928d-48aa-afc9-be5604ab732e">
											<gml:posList>35.6738647472385 139.73799437712512 9.049 35.67389335681464 139.73798300914254 9.049 35.67389335681464 139.73798300914254 12.125 35.6738647472385 139.73799437712512 12.125 35.6738647472385 139.73799437712512 9.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3398</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>