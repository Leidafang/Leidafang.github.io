<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_74d04b90-c71a-4e50-ab82-fd55f4ca0b2b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">36.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67444846947695 139.7383167361198 0 35.67439334489225 139.73813839543985 0 35.674256926209026 139.7382005299443 0 35.67431223245784 139.73838074810482 0 35.67444846947695 139.7383167361198 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67444846947695 139.7383167361198 7.9 35.67431223245784 139.73838074810482 7.9 35.674256926209026 139.7382005299443 7.9 35.67439334489225 139.73813839543985 7.9 35.67444846947695 139.7383167361198 7.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67444846947695 139.7383167361198 7.9 35.67439334489225 139.73813839543985 7.9 35.67439334489225 139.73813839543985 44.74 35.67444846947695 139.7383167361198 44.74 35.67444846947695 139.7383167361198 7.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67439334489225 139.73813839543985 7.9 35.674256926209026 139.7382005299443 7.9 35.674256926209026 139.7382005299443 44.74 35.67439334489225 139.73813839543985 44.74 35.67439334489225 139.73813839543985 7.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674256926209026 139.7382005299443 7.9 35.67431223245784 139.73838074810482 7.9 35.67431223245784 139.73838074810482 44.74 35.674256926209026 139.7382005299443 44.74 35.674256926209026 139.7382005299443 7.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67431223245784 139.73838074810482 7.9 35.67444846947695 139.7383167361198 7.9 35.67444846947695 139.7383167361198 44.74 35.67431223245784 139.73838074810482 44.74 35.67431223245784 139.73838074810482 7.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67444846947695 139.7383167361198 44.74 35.67439334489225 139.73813839543985 44.74 35.674256926209026 139.7382005299443 44.74 35.67431223245784 139.73838074810482 44.74 35.67444846947695 139.7383167361198 44.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-157b1d66-b41d-4f61-9639-31b455748f68"/>
							<gml:surfaceMember xlink:href="#poly-fa70abad-ee53-4d54-ac1e-716787822d00"/>
							<gml:surfaceMember xlink:href="#poly-689e2298-a06b-4fc3-a4a6-c99c0df1a5fd"/>
							<gml:surfaceMember xlink:href="#poly-e76905ff-73d3-44e0-a9e6-a57dd7e940e7"/>
							<gml:surfaceMember xlink:href="#poly-f4e83a35-ec59-46e5-82ec-123e87e4c2f1"/>
							<gml:surfaceMember xlink:href="#poly-a4c27afc-7046-4c1d-b3a0-8f7ed0299939"/>
							<gml:surfaceMember xlink:href="#poly-ad92dc8c-6f01-4af7-9580-b1c3eb905fb6"/>
							<gml:surfaceMember xlink:href="#poly-483971da-1bd3-4cbc-a079-b7e7e15c586b"/>
							<gml:surfaceMember xlink:href="#poly-207fa151-3e9f-46ca-b54d-ae5e1516f9d4"/>
							<gml:surfaceMember xlink:href="#poly-7f807c01-66b2-4bf3-bfa2-54fa9c85e231"/>
							<gml:surfaceMember xlink:href="#poly-467592cb-aeec-4984-a082-d9e3f42cae0b"/>
							<gml:surfaceMember xlink:href="#poly-21e6ddd1-dda0-4eb7-b995-27c6649c5b17"/>
							<gml:surfaceMember xlink:href="#poly-9c25b1a5-4a9d-41bb-ba78-fd6ebac62527"/>
							<gml:surfaceMember xlink:href="#poly-ac5918fe-af11-4741-bff9-02657e0de312"/>
							<gml:surfaceMember xlink:href="#poly-25b60ba7-8f93-481e-82e0-bb3f563767b2"/>
							<gml:surfaceMember xlink:href="#poly-badc1c37-91fa-4fef-8f6c-d9ae0d1c85e3"/>
							<gml:surfaceMember xlink:href="#poly-15c8499d-3f89-4614-b3ba-90d4be9d49f8"/>
							<gml:surfaceMember xlink:href="#poly-56587586-1838-44ff-b197-b638edde3a12"/>
							<gml:surfaceMember xlink:href="#poly-a2f7b0ad-057a-42fa-a97f-fc09efc048c2"/>
							<gml:surfaceMember xlink:href="#poly-f06f8542-bcef-41ba-8a6c-e3bbf6ba339b"/>
							<gml:surfaceMember xlink:href="#poly-d31d7140-1c00-4fee-b16f-238d7d92c308"/>
							<gml:surfaceMember xlink:href="#poly-50c18f6d-f94c-481d-98bc-8e6e2c25c45f"/>
							<gml:surfaceMember xlink:href="#poly-a468d673-2860-4119-9a79-6f690e3a710b"/>
							<gml:surfaceMember xlink:href="#poly-d327046b-dbe6-41d9-b0e9-7d8042c9c492"/>
							<gml:surfaceMember xlink:href="#poly-3c56fb6f-bec8-4ee6-b52e-e7eec8cc8bf7"/>
							<gml:surfaceMember xlink:href="#poly-47c359d2-3786-4326-82c6-ed4e1812454b"/>
							<gml:surfaceMember xlink:href="#poly-378031c9-f55c-44cb-8dc9-628994d50d8f"/>
							<gml:surfaceMember xlink:href="#poly-42b97f5c-650a-4db5-b444-23d92edae934"/>
							<gml:surfaceMember xlink:href="#poly-6a472bc0-f8ec-4281-85e6-6a9f8ed818f3"/>
							<gml:surfaceMember xlink:href="#poly-5303eb75-bd78-4097-a692-0f337b8d17d7"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_74d04b90-c71a-4e50-ab82-fd55f4ca0b2b_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a33ae4c-4a57-4d0d-a23a-f850f277adff">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67431823036925 139.73824847764223 49.592 35.67430960881747 139.73822004235663 49.592 35.674371817189055 139.73819171081107 49.592 35.67438044775245 139.73822013505819 49.592 35.67431823036925 139.73824847764223 49.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5055b1c6-4774-4340-a0b2-98d17effcebb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5055b1c6-4774-4340-a0b2-98d17effcebb_0">
											<gml:posList>35.67430960881747 139.73822004235663 51.19 35.67430960881747 139.73822004235663 49.592 35.67431823036925 139.73824847764223 49.592 35.67431823036925 139.73824847764223 51.19 35.67430960881747 139.73822004235663 51.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e2b21d4-4761-4b3c-9efe-8f5578d52130">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e2b21d4-4761-4b3c-9efe-8f5578d52130_0">
											<gml:posList>35.674371817189055 139.73819171081107 51.19 35.674371817189055 139.73819171081107 49.592 35.67430960881747 139.73822004235663 49.592 35.67430960881747 139.73822004235663 51.19 35.674371817189055 139.73819171081107 51.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-961b6d7c-7e68-4daa-adc5-539148b84068">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-961b6d7c-7e68-4daa-adc5-539148b84068_0">
											<gml:posList>35.674371817189055 139.73819171081107 51.19 35.67430960881747 139.73822004235663 51.19 35.67431823036925 139.73824847764223 51.19 35.67438044775245 139.73822013505819 51.19 35.674371817189055 139.73819171081107 51.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d26bcab9-69d2-4460-a1c8-296512e7e3b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d26bcab9-69d2-4460-a1c8-296512e7e3b0_0">
											<gml:posList>35.67431823036925 139.73824847764223 51.19 35.67431823036925 139.73824847764223 49.592 35.67438044775245 139.73822013505819 49.592 35.67438044775245 139.73822013505819 51.19 35.67431823036925 139.73824847764223 51.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fe6bbad-3f2d-4246-96a3-45b38a4d9c25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fe6bbad-3f2d-4246-96a3-45b38a4d9c25_0">
											<gml:posList>35.67438044775245 139.73822013505819 51.19 35.67438044775245 139.73822013505819 49.592 35.674371817189055 139.73819171081107 49.592 35.674371817189055 139.73819171081107 51.19 35.67438044775245 139.73822013505819 51.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_74d04b90-c71a-4e50-ab82-fd55f4ca0b2b_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b404213-f4e9-44ba-a237-f6232e52d2d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b404213-f4e9-44ba-a237-f6232e52d2d5_0">
											<gml:posList>35.67431391450045 139.73830772675632 45.913 35.67430936914469 139.7382932166482 44.534 35.67431391450045 139.73830772675632 44.534 35.67431391450045 139.73830772675632 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-944e0695-d91e-40c2-848c-d8cec4d9a7eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-944e0695-d91e-40c2-848c-d8cec4d9a7eb_0">
											<gml:posList>35.67431391450045 139.73830772675632 45.913 35.67430936914469 139.7382932166482 45.913 35.67430936914469 139.7382932166482 44.534 35.67431391450045 139.73830772675632 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87f266ec-cdba-42af-ab3c-860a0db5e42e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87f266ec-cdba-42af-ab3c-860a0db5e42e_0">
											<gml:posList>35.67430936914469 139.7382932166482 45.913 35.674315946716064 139.73829011574577 44.534 35.67430936914469 139.7382932166482 44.534 35.67430936914469 139.7382932166482 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f988e2a7-9201-4f08-b428-a31cbd6c464b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f988e2a7-9201-4f08-b428-a31cbd6c464b_0">
											<gml:posList>35.67430936914469 139.7382932166482 45.913 35.674315946716064 139.73829011574577 45.913 35.674315946716064 139.73829011574577 44.534 35.67430936914469 139.7382932166482 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ace42a68-6415-4b1d-9d6a-0d97338876de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ace42a68-6415-4b1d-9d6a-0d97338876de_0">
											<gml:posList>35.67430936914469 139.7382932166482 45.913 35.67431391450045 139.73830772675632 45.913 35.6743204920809 139.7383046369017 45.913 35.67430936914469 139.7382932166482 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a54b397-e8f5-4ff2-a5ef-e76f21b29f3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a54b397-e8f5-4ff2-a5ef-e76f21b29f3a_0">
											<gml:posList>35.674315946716064 139.73829011574577 45.913 35.67430936914469 139.7382932166482 45.913 35.6743204920809 139.7383046369017 45.913 35.674315946716064 139.73829011574577 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e20a9b1-a805-48aa-bf01-7e977ef8b3e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e20a9b1-a805-48aa-bf01-7e977ef8b3e0_0">
											<gml:posList>35.67431391450045 139.73830772675632 45.913 35.6743204920809 139.7383046369017 44.534 35.6743204920809 139.7383046369017 45.913 35.67431391450045 139.73830772675632 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1206cf4-1e90-4da2-beb6-53fd24359834">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1206cf4-1e90-4da2-beb6-53fd24359834_0">
											<gml:posList>35.67431391450045 139.73830772675632 45.913 35.67431391450045 139.73830772675632 44.534 35.6743204920809 139.7383046369017 44.534 35.67431391450045 139.73830772675632 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16d90845-7b10-4c82-a031-93ab4f68be65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16d90845-7b10-4c82-a031-93ab4f68be65_0">
											<gml:posList>35.674315946716064 139.73829011574577 45.913 35.6743204920809 139.7383046369017 44.534 35.674315946716064 139.73829011574577 44.534 35.674315946716064 139.73829011574577 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b888d8e7-6854-461c-a6cc-030b881801ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b888d8e7-6854-461c-a6cc-030b881801ff_0">
											<gml:posList>35.674315946716064 139.73829011574577 45.913 35.6743204920809 139.7383046369017 45.913 35.6743204920809 139.7383046369017 44.534 35.674315946716064 139.73829011574577 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-291643b1-2682-4101-80f1-783b5ba3a6de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-291643b1-2682-4101-80f1-783b5ba3a6de_0">
											<gml:posList>35.674315416504925 139.73831498272443 45.913 35.67432266084775 139.73831157172276 44.534 35.674315416504925 139.73831498272443 44.534 35.674315416504925 139.73831498272443 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa063d92-e281-4426-bc98-ce9d86d749e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa063d92-e281-4426-bc98-ce9d86d749e2_0">
											<gml:posList>35.674315416504925 139.73831498272443 45.913 35.67432266084775 139.73831157172276 45.913 35.67432266084775 139.73831157172276 44.534 35.674315416504925 139.73831498272443 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c6d5c1b-456e-4bec-8585-1713d3f4b436">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c6d5c1b-456e-4bec-8585-1713d3f4b436_0">
											<gml:posList>35.674324344579084 139.73834351708035 45.913 35.674315416504925 139.73831498272443 44.534 35.674324344579084 139.73834351708035 44.534 35.674324344579084 139.73834351708035 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94c47504-a878-408e-acce-3133889d1e80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94c47504-a878-408e-acce-3133889d1e80_0">
											<gml:posList>35.674324344579084 139.73834351708035 45.913 35.674315416504925 139.73831498272443 45.913 35.674315416504925 139.73831498272443 44.534 35.674324344579084 139.73834351708035 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c280ede5-7c16-4695-8ce1-fcd0c675b1a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c280ede5-7c16-4695-8ce1-fcd0c675b1a4_0">
											<gml:posList>35.67433158893142 139.73834011712768 45.913 35.67432266084775 139.73831157172276 45.913 35.674315416504925 139.73831498272443 45.913 35.67433158893142 139.73834011712768 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1e83062-a459-4bb6-b270-c5c3d769fd45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1e83062-a459-4bb6-b270-c5c3d769fd45_0">
											<gml:posList>35.674324344579084 139.73834351708035 45.913 35.67433158893142 139.73834011712768 45.913 35.674315416504925 139.73831498272443 45.913 35.674324344579084 139.73834351708035 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04a97efc-77b4-4f44-8268-166d151d6b33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04a97efc-77b4-4f44-8268-166d151d6b33_0">
											<gml:posList>35.6743221893288 139.73827375907715 45.913 35.67432848759655 139.73827081315906 44.534 35.6743221893288 139.73827375907715 44.534 35.6743221893288 139.73827375907715 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9681915-4d2f-41a3-bf77-00a060b33777">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9681915-4d2f-41a3-bf77-00a060b33777_0">
											<gml:posList>35.6743221893288 139.73827375907715 45.913 35.67432848759655 139.73827081315906 45.913 35.67432848759655 139.73827081315906 44.534 35.6743221893288 139.73827375907715 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d898c2c9-ab25-4026-8b25-e8fd5d814e47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d898c2c9-ab25-4026-8b25-e8fd5d814e47_0">
											<gml:posList>35.67432753625502 139.73836740753364 44.534 35.67432753625502 139.73836740753364 45.956 35.67432234921594 139.73835072195985 44.534 35.67432753625502 139.73836740753364 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-262e1e16-32fc-4f47-b640-09da491b921e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-262e1e16-32fc-4f47-b640-09da491b921e_0">
											<gml:posList>35.67432234921594 139.73835072195985 44.534 35.67432753625502 139.73836740753364 45.956 35.67432234921594 139.73835072195985 48.578 35.67432234921594 139.73835072195985 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9136f95c-fd98-431e-81de-005677298575">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9136f95c-fd98-431e-81de-005677298575_0">
											<gml:posList>35.67432234921594 139.73835072195985 48.578 35.67432753625502 139.73836740753364 45.956 35.67432888269659 139.7383717141919 48.578 35.67432234921594 139.73835072195985 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1237709f-359f-4d4e-9552-4381fb8ff1dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1237709f-359f-4d4e-9552-4381fb8ff1dc_0">
											<gml:posList>35.67432753625502 139.73836740753364 45.956 35.67432888269659 139.7383717141919 45.956 35.67432888269659 139.7383717141919 48.578 35.67432753625502 139.73836740753364 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30a6bb4b-bee9-4829-bb65-08c54caa016b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30a6bb4b-bee9-4829-bb65-08c54caa016b_0">
											<gml:posList>35.67433158893142 139.73834011712768 45.913 35.67432266084775 139.73831157172276 44.534 35.67432266084775 139.73831157172276 45.913 35.67433158893142 139.73834011712768 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0002da7-8a85-4ce2-8b10-984d19255f01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0002da7-8a85-4ce2-8b10-984d19255f01_0">
											<gml:posList>35.67433158893142 139.73834011712768 45.913 35.67433158893142 139.73834011712768 44.534 35.67432266084775 139.73831157172276 44.534 35.67433158893142 139.73834011712768 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df86109f-c946-4232-a25f-619fad7c78a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df86109f-c946-4232-a25f-619fad7c78a4_0">
											<gml:posList>35.67432234921594 139.73835072195985 48.578 35.67433329682896 139.73834557222503 44.534 35.67432234921594 139.73835072195985 44.534 35.67432234921594 139.73835072195985 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-755984f6-5a9c-4aa1-8dc8-625f5c899404">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-755984f6-5a9c-4aa1-8dc8-625f5c899404_0">
											<gml:posList>35.67432234921594 139.73835072195985 48.578 35.67433329682896 139.73834557222503 48.578 35.67433329682896 139.73834557222503 44.534 35.67432234921594 139.73835072195985 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc653e72-4c58-4c54-8bf0-f8e4e79a3533">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc653e72-4c58-4c54-8bf0-f8e4e79a3533_0">
											<gml:posList>35.67433158893142 139.73834011712768 45.913 35.674324344579084 139.73834351708035 44.534 35.67433158893142 139.73834011712768 44.534 35.67433158893142 139.73834011712768 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3c8dfe0-9d47-4558-bbf5-2f914592ef40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3c8dfe0-9d47-4558-bbf5-2f914592ef40_0">
											<gml:posList>35.67433158893142 139.73834011712768 45.913 35.674324344579084 139.73834351708035 45.913 35.674324344579084 139.73834351708035 44.534 35.67433158893142 139.73834011712768 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c53b3a6e-97fa-43bd-b4eb-0b304c938cb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c53b3a6e-97fa-43bd-b4eb-0b304c938cb8_0">
											<gml:posList>35.67433512962436 139.73831511401428 45.913 35.6743221893288 139.73827375907715 44.534 35.67433512962436 139.73831511401428 44.534 35.67433512962436 139.73831511401428 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-448d655d-3376-461c-8366-05896b328e6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-448d655d-3376-461c-8366-05896b328e6e_0">
											<gml:posList>35.67433512962436 139.73831511401428 45.913 35.6743221893288 139.73827375907715 45.913 35.6743221893288 139.73827375907715 44.534 35.67433512962436 139.73831511401428 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7471df31-b4ab-4940-920e-3d1d09e5bb6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7471df31-b4ab-4940-920e-3d1d09e5bb6f_0">
											<gml:posList>35.67432234921594 139.73835072195985 48.578 35.67433983031921 139.7383665755063 48.578 35.67433329682896 139.73834557222503 48.578 35.67432234921594 139.73835072195985 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b27b09d-cee7-499d-bb9b-299329158532">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b27b09d-cee7-499d-bb9b-299329158532_0">
											<gml:posList>35.67432234921594 139.73835072195985 48.578 35.67432888269659 139.7383717141919 48.578 35.67433983031921 139.7383665755063 48.578 35.67432234921594 139.73835072195985 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34f2faf0-cb3d-4e05-838c-c35abf8a6457">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34f2faf0-cb3d-4e05-838c-c35abf8a6457_0">
											<gml:posList>35.67432848759655 139.73827081315906 45.913 35.6743221893288 139.73827375907715 45.913 35.67433512962436 139.73831511401428 45.913 35.67432848759655 139.73827081315906 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e827b3d-be91-4188-8688-f325e20a8c3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e827b3d-be91-4188-8688-f325e20a8c3a_0">
											<gml:posList>35.67434141886194 139.73831214601609 45.913 35.67432848759655 139.73827081315906 45.913 35.67433512962436 139.73831511401428 45.913 35.67434141886194 139.73831214601609 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92f501f9-abdb-4c31-8c3f-2d0b99b49c31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92f501f9-abdb-4c31-8c3f-2d0b99b49c31_0">
											<gml:posList>35.67432753625502 139.73836740753364 44.534 35.67433849288246 139.73836225779007 45.956 35.67432753625502 139.73836740753364 45.956 35.67432753625502 139.73836740753364 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d10bad7-64c2-4bd5-90bb-79ddd0dee8af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d10bad7-64c2-4bd5-90bb-79ddd0dee8af_0">
											<gml:posList>35.67432753625502 139.73836740753364 44.534 35.67433849288246 139.73836225779007 44.534 35.67433849288246 139.73836225779007 45.956 35.67432753625502 139.73836740753364 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5affde80-526b-4ece-bc27-f5c4008ce03b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5affde80-526b-4ece-bc27-f5c4008ce03b_0">
											<gml:posList>35.67433983031921 139.7383665755063 48.578 35.67432888269659 139.7383717141919 45.956 35.67433983031921 139.7383665755063 45.956 35.67433983031921 139.7383665755063 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d878e1c4-bf8d-4f65-8656-02ad8123b33d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d878e1c4-bf8d-4f65-8656-02ad8123b33d_0">
											<gml:posList>35.67433983031921 139.7383665755063 48.578 35.67432888269659 139.7383717141919 48.578 35.67432888269659 139.7383717141919 45.956 35.67433983031921 139.7383665755063 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43351a41-d997-470b-98be-f66571cd7db7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43351a41-d997-470b-98be-f66571cd7db7_0">
											<gml:posList>35.674333501697504 139.7383310454351 45.913 35.67433627590699 139.7383399127313 44.534 35.67433627590699 139.7383399127313 45.913 35.674333501697504 139.7383310454351 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e0782c4-d66d-4adc-a438-6c41730a5b2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e0782c4-d66d-4adc-a438-6c41730a5b2d_0">
											<gml:posList>35.674333501697504 139.7383310454351 45.913 35.674333501697504 139.7383310454351 44.534 35.67433627590699 139.7383399127313 44.534 35.674333501697504 139.7383310454351 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ff855c5-72c9-403a-b98f-e04def8f9005">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ff855c5-72c9-403a-b98f-e04def8f9005_0">
											<gml:posList>35.67434141886194 139.73831214601609 45.913 35.67432848759655 139.73827081315906 44.534 35.67432848759655 139.73827081315906 45.913 35.67434141886194 139.73831214601609 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e158f2ba-6052-410a-b0ee-ba4c165e2ff7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e158f2ba-6052-410a-b0ee-ba4c165e2ff7_0">
											<gml:posList>35.67434141886194 139.73831214601609 45.913 35.67434141886194 139.73831214601609 44.534 35.67432848759655 139.73827081315906 44.534 35.67434141886194 139.73831214601609 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a65c08db-214a-40b2-b731-07932203f3f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a65c08db-214a-40b2-b731-07932203f3f9_0">
											<gml:posList>35.67433983031921 139.7383665755063 45.956 35.67433849288246 139.73836225779007 45.956 35.67433983031921 139.7383665755063 48.578 35.67433983031921 139.7383665755063 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1e47082-bf93-4905-9b05-247c45bbae54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1e47082-bf93-4905-9b05-247c45bbae54_0">
											<gml:posList>35.67433983031921 139.7383665755063 48.578 35.67433849288246 139.73836225779007 45.956 35.67433329682896 139.73834557222503 48.578 35.67433983031921 139.7383665755063 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73cec74f-289b-4fb9-8952-3e5b1b49d05d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73cec74f-289b-4fb9-8952-3e5b1b49d05d_0">
											<gml:posList>35.67433329682896 139.73834557222503 48.578 35.67433849288246 139.73836225779007 45.956 35.67433329682896 139.73834557222503 44.534 35.67433329682896 139.73834557222503 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad02f8c9-1be4-44b4-ba88-4c0d490a224d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad02f8c9-1be4-44b4-ba88-4c0d490a224d_0">
											<gml:posList>35.67433849288246 139.73836225779007 45.956 35.67433849288246 139.73836225779007 44.534 35.67433329682896 139.73834557222503 44.534 35.67433849288246 139.73836225779007 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93a31a0a-55bd-4d6b-91a3-897599930832">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93a31a0a-55bd-4d6b-91a3-897599930832_0">
											<gml:posList>35.67434141886194 139.73831214601609 45.913 35.67433512962436 139.73831511401428 44.534 35.67434141886194 139.73831214601609 44.534 35.67434141886194 139.73831214601609 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1515331-1166-43f3-adf5-d2bbe6a19502">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1515331-1166-43f3-adf5-d2bbe6a19502_0">
											<gml:posList>35.67434141886194 139.73831214601609 45.913 35.67433512962436 139.73831511401428 45.913 35.67433512962436 139.73831511401428 44.534 35.67434141886194 139.73831214601609 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73c8ca16-dd88-41cd-82cf-3b235ae31df6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73c8ca16-dd88-41cd-82cf-3b235ae31df6_0">
											<gml:posList>35.674333501697504 139.7383310454351 45.913 35.674345242220305 139.73832551916576 44.534 35.674333501697504 139.7383310454351 44.534 35.674333501697504 139.7383310454351 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-584bf275-1e6d-4539-9f99-f124f51d9489">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-584bf275-1e6d-4539-9f99-f124f51d9489_0">
											<gml:posList>35.674333501697504 139.7383310454351 45.913 35.674345242220305 139.73832551916576 45.913 35.674345242220305 139.73832551916576 44.534 35.674333501697504 139.7383310454351 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1130cb8b-8137-411d-ba98-9933914e3056">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1130cb8b-8137-411d-ba98-9933914e3056_0">
											<gml:posList>35.67433627590699 139.7383399127313 45.913 35.67434802545264 139.7383343974992 45.913 35.674345242220305 139.73832551916576 45.913 35.67433627590699 139.7383399127313 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8be425a0-5f87-4338-ba12-d8cea5b9a6b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8be425a0-5f87-4338-ba12-d8cea5b9a6b5_0">
											<gml:posList>35.674333501697504 139.7383310454351 45.913 35.67433627590699 139.7383399127313 45.913 35.674345242220305 139.73832551916576 45.913 35.674333501697504 139.7383310454351 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86df5fff-20ac-4d21-8e46-c2586097e53d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86df5fff-20ac-4d21-8e46-c2586097e53d_0">
											<gml:posList>35.67434802545264 139.7383343974992 45.913 35.67433627590699 139.7383399127313 44.534 35.67434802545264 139.7383343974992 44.534 35.67434802545264 139.7383343974992 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f2adb72-4c1b-4845-972f-63e68fd36db5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f2adb72-4c1b-4845-972f-63e68fd36db5_0">
											<gml:posList>35.67434802545264 139.7383343974992 45.913 35.67433627590699 139.7383399127313 45.913 35.67433627590699 139.7383399127313 44.534 35.67434802545264 139.7383343974992 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aec92825-144f-4bb4-85eb-575f06dcc461">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aec92825-144f-4bb4-85eb-575f06dcc461_0">
											<gml:posList>35.674345242220305 139.73832551916576 45.913 35.67434802545264 139.7383343974992 44.534 35.674345242220305 139.73832551916576 44.534 35.674345242220305 139.73832551916576 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3eac7d51-534e-41e9-bc21-dba6220c3626">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3eac7d51-534e-41e9-bc21-dba6220c3626_0">
											<gml:posList>35.674345242220305 139.73832551916576 45.913 35.67434802545264 139.7383343974992 45.913 35.67434802545264 139.7383343974992 44.534 35.674345242220305 139.73832551916576 45.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52fc30a2-4925-49b6-9ea4-f248e1213311">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52fc30a2-4925-49b6-9ea4-f248e1213311_0">
											<gml:posList>35.67435004418837 139.73835682012356 44.534 35.67435004418837 139.73835682012356 45.956 35.67434494753773 139.73834045479606 44.534 35.67435004418837 139.73835682012356 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c50bf69-3e93-4477-a243-c2bed5685792">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c50bf69-3e93-4477-a243-c2bed5685792_0">
											<gml:posList>35.67434494753773 139.73834045479606 44.534 35.67435004418837 139.73835682012356 45.956 35.67434494753773 139.73834045479606 48.578 35.67434494753773 139.73834045479606 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47946e6b-d20c-4fa9-bcf7-7776b2045be5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47946e6b-d20c-4fa9-bcf7-7776b2045be5_0">
											<gml:posList>35.67434494753773 139.73834045479606 48.578 35.67435004418837 139.73835682012356 45.956 35.67435139063903 139.73836113782966 48.578 35.67434494753773 139.73834045479606 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abf4cdc2-d312-424e-8884-a5afe9ee2910">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abf4cdc2-d312-424e-8884-a5afe9ee2910_0">
											<gml:posList>35.67435004418837 139.73835682012356 45.956 35.67435139063903 139.73836113782966 45.956 35.67435139063903 139.73836113782966 48.578 35.67435004418837 139.73835682012356 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cb3c820-ce15-4288-862c-8956460bb1b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4cb3c820-ce15-4288-862c-8956460bb1b7_0">
											<gml:posList>35.67434494753773 139.73834045479606 48.578 35.6743559221827 139.7383352939795 44.534 35.67434494753773 139.73834045479606 44.534 35.67434494753773 139.73834045479606 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41bc1f85-d1e2-4690-8799-0eeb585f5b26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41bc1f85-d1e2-4690-8799-0eeb585f5b26_0">
											<gml:posList>35.67434494753773 139.73834045479606 48.578 35.6743559221827 139.7383352939795 48.578 35.6743559221827 139.7383352939795 44.534 35.67434494753773 139.73834045479606 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2d38ba3-fcc4-4f9a-a378-5639bca72283">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2d38ba3-fcc4-4f9a-a378-5639bca72283_0">
											<gml:posList>35.67434494753773 139.73834045479606 48.578 35.67436236529358 139.73835598806232 48.578 35.6743559221827 139.7383352939795 48.578 35.67434494753773 139.73834045479606 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51b12adb-4d6a-4c64-a8d4-bec00af139c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51b12adb-4d6a-4c64-a8d4-bec00af139c0_0">
											<gml:posList>35.67434494753773 139.73834045479606 48.578 35.67435139063903 139.73836113782966 48.578 35.67436236529358 139.73835598806232 48.578 35.67434494753773 139.73834045479606 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04b51977-0c88-42a6-ae71-8e28594ba49f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04b51977-0c88-42a6-ae71-8e28594ba49f_0">
											<gml:posList>35.674361018842745 139.7383516703557 44.534 35.67435004418837 139.73835682012356 45.956 35.67435004418837 139.73835682012356 44.534 35.674361018842745 139.7383516703557 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47c62329-5b1f-4540-8520-9ce5016dec57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47c62329-5b1f-4540-8520-9ce5016dec57_0">
											<gml:posList>35.674361018842745 139.7383516703557 44.534 35.674361018842745 139.7383516703557 45.956 35.67435004418837 139.73835682012356 45.956 35.674361018842745 139.7383516703557 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42df3293-5576-42f2-b0a2-de2d3814443c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42df3293-5576-42f2-b0a2-de2d3814443c_0">
											<gml:posList>35.67436236529358 139.73835598806232 48.578 35.67435139063903 139.73836113782966 45.956 35.67436236529358 139.73835598806232 45.956 35.67436236529358 139.73835598806232 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c71d6276-a366-41d7-9457-d760ddbd7546">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c71d6276-a366-41d7-9457-d760ddbd7546_0">
											<gml:posList>35.67436236529358 139.73835598806232 48.578 35.67435139063903 139.73836113782966 48.578 35.67435139063903 139.73836113782966 45.956 35.67436236529358 139.73835598806232 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-255ed0e9-2b87-41e7-b13d-2f79fdb7b241">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-255ed0e9-2b87-41e7-b13d-2f79fdb7b241_0">
											<gml:posList>35.67436236529358 139.73835598806232 45.956 35.674361018842745 139.7383516703557 45.956 35.67436236529358 139.73835598806232 48.578 35.67436236529358 139.73835598806232 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7119134-591c-4c34-9732-d1ad85dd1c8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7119134-591c-4c34-9732-d1ad85dd1c8a_0">
											<gml:posList>35.67436236529358 139.73835598806232 48.578 35.674361018842745 139.7383516703557 45.956 35.6743559221827 139.7383352939795 48.578 35.67436236529358 139.73835598806232 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e54d4857-68eb-4bde-ab7e-fb2c4eee8ed1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e54d4857-68eb-4bde-ab7e-fb2c4eee8ed1_0">
											<gml:posList>35.6743559221827 139.7383352939795 48.578 35.674361018842745 139.7383516703557 45.956 35.6743559221827 139.7383352939795 44.534 35.6743559221827 139.7383352939795 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a1d9dee-823e-4dae-844b-a09cef5e4197">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a1d9dee-823e-4dae-844b-a09cef5e4197_0">
											<gml:posList>35.674361018842745 139.7383516703557 45.956 35.674361018842745 139.7383516703557 44.534 35.6743559221827 139.7383352939795 44.534 35.674361018842745 139.7383516703557 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95845550-435c-4abe-adc2-614d3997a992">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95845550-435c-4abe-adc2-614d3997a992_0">
											<gml:posList>35.674397754176965 139.73833440484992 44.534 35.674397754176965 139.73833440484992 45.956 35.67439315453296 139.73831962966597 44.534 35.674397754176965 139.73833440484992 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c340351-3089-4202-8ca2-73a73d0b10cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c340351-3089-4202-8ca2-73a73d0b10cc_0">
											<gml:posList>35.67439315453296 139.73831962966597 44.534 35.674397754176965 139.73833440484992 45.956 35.67439315453296 139.73831962966597 48.578 35.67439315453296 139.73831962966597 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63358d20-d113-45c3-8405-9f4c669ef053">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63358d20-d113-45c3-8405-9f4c669ef053_0">
											<gml:posList>35.67439315453296 139.73831962966597 48.578 35.674397754176965 139.73833440484992 45.956 35.67439910062842 139.7383387225582 48.578 35.67439315453296 139.73831962966597 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b87fd8dc-3572-464b-8724-b36dc80a1cf2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b87fd8dc-3572-464b-8724-b36dc80a1cf2_0">
											<gml:posList>35.674397754176965 139.73833440484992 45.956 35.67439910062842 139.7383387225582 45.956 35.67439910062842 139.7383387225582 48.578 35.674397754176965 139.73833440484992 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd809b83-7458-4517-ac46-daf8e7453947">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd809b83-7458-4517-ac46-daf8e7453947_0">
											<gml:posList>35.67439315453296 139.73831962966597 48.578 35.67440298486215 139.73831501149368 44.534 35.67439315453296 139.73831962966597 44.534 35.67439315453296 139.73831962966597 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8621482-dd17-4d23-9983-99f55eef91d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8621482-dd17-4d23-9983-99f55eef91d2_0">
											<gml:posList>35.67439315453296 139.73831962966597 48.578 35.67440298486215 139.73831501149368 48.578 35.67440298486215 139.73831501149368 44.534 35.67439315453296 139.73831962966597 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9edb2350-6fc8-488c-b99f-af5ae3df3a4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9edb2350-6fc8-488c-b99f-af5ae3df3a4d_0">
											<gml:posList>35.67439315453296 139.73831962966597 48.578 35.674408930958336 139.7383341043879 48.578 35.67440298486215 139.73831501149368 48.578 35.67439315453296 139.73831962966597 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f002928-1ed0-45fc-aa1a-64b21769b526">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f002928-1ed0-45fc-aa1a-64b21769b526_0">
											<gml:posList>35.67439315453296 139.73831962966597 48.578 35.67439910062842 139.7383387225582 48.578 35.674408930958336 139.7383341043879 48.578 35.67439315453296 139.73831962966597 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7a512e5-2a02-447d-a37c-04ac3fdc1361">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7a512e5-2a02-447d-a37c-04ac3fdc1361_0">
											<gml:posList>35.67440723261633 139.7382265767121 44.534 35.6743965505729 139.7381913610996 47.352 35.6743965505729 139.7381913610996 44.534 35.67440723261633 139.7382265767121 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e895ea8-fb2b-42bb-96ca-c0a259363ea0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e895ea8-fb2b-42bb-96ca-c0a259363ea0_0">
											<gml:posList>35.67440723261633 139.7382265767121 44.534 35.67440723261633 139.7382265767121 47.352 35.6743965505729 139.7381913610996 47.352 35.67440723261633 139.7382265767121 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-687a1a57-5789-4757-b3cb-61b3c8c97102">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-687a1a57-5789-4757-b3cb-61b3c8c97102_0">
											<gml:posList>35.67440746241213 139.73818657592554 47.352 35.67440746241213 139.73818657592554 45.956 35.67440372301188 139.73818821529218 45.956 35.67440746241213 139.73818657592554 47.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c5eae5f-3521-461c-949d-b6cf72fc39d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c5eae5f-3521-461c-949d-b6cf72fc39d5_0">
											<gml:posList>35.67440746241213 139.73818657592554 47.352 35.67440372301188 139.73818821529218 45.956 35.6743965505729 139.7381913610996 47.352 35.67440746241213 139.73818657592554 47.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa8fae58-9504-40d4-b733-0ea8e6807e1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa8fae58-9504-40d4-b733-0ea8e6807e1e_0">
											<gml:posList>35.67440372301188 139.73818821529218 45.956 35.6743965505729 139.7381913610996 44.534 35.6743965505729 139.7381913610996 47.352 35.67440372301188 139.73818821529218 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26c22f78-40b3-4217-89b1-8b58a8ca9b96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26c22f78-40b3-4217-89b1-8b58a8ca9b96_0">
											<gml:posList>35.67440372301188 139.73818821529218 45.956 35.67440372301188 139.73818821529218 44.534 35.6743965505729 139.7381913610996 44.534 35.67440372301188 139.73818821529218 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01cc3ab3-1456-4a6b-ae78-1f03f3564766">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01cc3ab3-1456-4a6b-ae78-1f03f3564766_0">
											<gml:posList>35.67440758450671 139.73832978667915 44.534 35.674397754176965 139.73833440484992 45.956 35.674397754176965 139.73833440484992 44.534 35.67440758450671 139.73832978667915 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1b51bad-31f8-4c40-a148-0a00d2fbd4b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1b51bad-31f8-4c40-a148-0a00d2fbd4b3_0">
											<gml:posList>35.67440758450671 139.73832978667915 44.534 35.67440758450671 139.73832978667915 45.956 35.674397754176965 139.73833440484992 45.956 35.67440758450671 139.73832978667915 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c26ebe15-9134-44c4-9278-964322a694e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c26ebe15-9134-44c4-9278-964322a694e1_0">
											<gml:posList>35.674408930958336 139.7383341043879 48.578 35.67439910062842 139.7383387225582 45.956 35.674408930958336 139.7383341043879 45.956 35.674408930958336 139.7383341043879 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd97c1e6-0773-4b32-b497-2719e61dfe56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd97c1e6-0773-4b32-b497-2719e61dfe56_0">
											<gml:posList>35.674408930958336 139.7383341043879 48.578 35.67439910062842 139.7383387225582 48.578 35.67439910062842 139.7383387225582 45.956 35.674408930958336 139.7383341043879 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f89a5f8-908b-401d-9ef7-82c1ff63c243">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f89a5f8-908b-401d-9ef7-82c1ff63c243_0">
											<gml:posList>35.674408930958336 139.7383341043879 45.956 35.67440758450671 139.73832978667915 45.956 35.674408930958336 139.7383341043879 48.578 35.674408930958336 139.7383341043879 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4845a15a-02a7-4b18-a5a6-6fbae389165f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4845a15a-02a7-4b18-a5a6-6fbae389165f_0">
											<gml:posList>35.674408930958336 139.7383341043879 48.578 35.67440758450671 139.73832978667915 45.956 35.67440298486215 139.73831501149368 48.578 35.674408930958336 139.7383341043879 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50763409-493c-4c86-a275-b91d09d29ac3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50763409-493c-4c86-a275-b91d09d29ac3_0">
											<gml:posList>35.67440298486215 139.73831501149368 48.578 35.67440758450671 139.73832978667915 45.956 35.67440298486215 139.73831501149368 44.534 35.67440298486215 139.73831501149368 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd951673-c7c4-44b9-8d62-2e39ea554c7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd951673-c7c4-44b9-8d62-2e39ea554c7d_0">
											<gml:posList>35.67440758450671 139.73832978667915 45.956 35.67440758450671 139.73832978667915 44.534 35.67440298486215 139.73831501149368 44.534 35.67440758450671 139.73832978667915 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-267c0563-7180-46f4-a918-ab6460eda815">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-267c0563-7180-46f4-a918-ab6460eda815_0">
											<gml:posList>35.67440770254242 139.73822811166175 44.534 35.67440723261633 139.7382265767121 47.352 35.67440723261633 139.7382265767121 44.534 35.67440770254242 139.73822811166175 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6aa0cad-8cd7-4a51-b40b-1d39380d72bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6aa0cad-8cd7-4a51-b40b-1d39380d72bd_0">
											<gml:posList>35.67440770254242 139.73822811166175 44.534 35.67440770254242 139.73822811166175 47.352 35.67440723261633 139.7382265767121 47.352 35.67440770254242 139.73822811166175 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44202710-fdd1-4505-bdf6-8b7b092e1c9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44202710-fdd1-4505-bdf6-8b7b092e1c9b_0">
											<gml:posList>35.67440372301188 139.73818821529218 45.956 35.6744150099874 139.73822471162023 44.534 35.67440372301188 139.73818821529218 44.534 35.67440372301188 139.73818821529218 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-083d3a43-1e00-4587-8888-e66db367ebf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-083d3a43-1e00-4587-8888-e66db367ebf4_0">
											<gml:posList>35.67440372301188 139.73818821529218 45.956 35.6744150099874 139.73822471162023 45.956 35.6744150099874 139.73822471162023 44.534 35.67440372301188 139.73818821529218 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d8f5d8d-6098-4153-b838-b55ff2800ee3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d8f5d8d-6098-4153-b838-b55ff2800ee3_0">
											<gml:posList>35.67440746241213 139.73818657592554 47.352 35.674418713272196 139.73822299497022 45.956 35.67440746241213 139.73818657592554 45.956 35.67440746241213 139.73818657592554 47.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-857689f5-4360-43cb-8059-1f88ba285ad5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-857689f5-4360-43cb-8059-1f88ba285ad5_0">
											<gml:posList>35.67440746241213 139.73818657592554 47.352 35.674418713272196 139.73822299497022 47.352 35.674418713272196 139.73822299497022 45.956 35.67440746241213 139.73818657592554 47.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-977841c0-d024-4585-be2d-dce0c8a2539e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-977841c0-d024-4585-be2d-dce0c8a2539e_0">
											<gml:posList>35.6744150099874 139.73822471162023 45.956 35.67440770254242 139.73822811166175 47.352 35.67440770254242 139.73822811166175 44.534 35.6744150099874 139.73822471162023 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95810bb9-43f2-4fb2-9fcd-acf4052b7fac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95810bb9-43f2-4fb2-9fcd-acf4052b7fac_0">
											<gml:posList>35.67440770254242 139.73822811166175 44.534 35.6744150099874 139.73822471162023 44.534 35.6744150099874 139.73822471162023 45.956 35.67440770254242 139.73822811166175 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-320be027-83c4-4190-8093-8b48f6206158">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-320be027-83c4-4190-8093-8b48f6206158_0">
											<gml:posList>35.674418713272196 139.73822299497022 47.352 35.67440770254242 139.73822811166175 47.352 35.6744150099874 139.73822471162023 45.956 35.674418713272196 139.73822299497022 47.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7fa4ccb-8817-463a-b346-7bd13f37b2b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7fa4ccb-8817-463a-b346-7bd13f37b2b4_0">
											<gml:posList>35.674418713272196 139.73822299497022 45.956 35.674418713272196 139.73822299497022 47.352 35.6744150099874 139.73822471162023 45.956 35.674418713272196 139.73822299497022 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1feb5e8e-5314-42bb-9ece-f7e5b7ec5bfd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1feb5e8e-5314-42bb-9ece-f7e5b7ec5bfd_0">
											<gml:posList>35.674420379250556 139.73832377309515 44.534 35.674420379250556 139.73832377309515 45.956 35.674415662104394 139.73830858931478 44.534 35.674420379250556 139.73832377309515 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b361edc-a720-4f06-9cca-30b867e14a04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b361edc-a720-4f06-9cca-30b867e14a04_0">
											<gml:posList>35.674415662104394 139.73830858931478 44.534 35.674420379250556 139.73832377309515 45.956 35.674415662104394 139.73830858931478 48.578 35.674415662104394 139.73830858931478 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f479214-bdca-457d-95a2-72523e6c1aed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f479214-bdca-457d-95a2-72523e6c1aed_0">
											<gml:posList>35.674415662104394 139.73830858931478 48.578 35.674420379250556 139.73832377309515 45.956 35.6744217257024 139.7383280908045 48.578 35.674415662104394 139.73830858931478 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-938dda1e-a8f8-4d5e-a226-1192c5235842">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-938dda1e-a8f8-4d5e-a226-1192c5235842_0">
											<gml:posList>35.674420379250556 139.73832377309515 45.956 35.6744217257024 139.7383280908045 45.956 35.6744217257024 139.7383280908045 48.578 35.674420379250556 139.73832377309515 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9961740e-cee6-474b-a2d0-163553f10b77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9961740e-cee6-474b-a2d0-163553f10b77_0">
											<gml:posList>35.674415662104394 139.73830858931478 48.578 35.67442593393954 139.73830376072695 44.534 35.674415662104394 139.73830858931478 44.534 35.674415662104394 139.73830858931478 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb5290bb-e811-4e05-97c5-b473e0f83c99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb5290bb-e811-4e05-97c5-b473e0f83c99_0">
											<gml:posList>35.674415662104394 139.73830858931478 48.578 35.67442593393954 139.73830376072695 48.578 35.67442593393954 139.73830376072695 44.534 35.674415662104394 139.73830858931478 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a178259e-6aad-4a64-8d30-19efdb0137a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a178259e-6aad-4a64-8d30-19efdb0137a0_0">
											<gml:posList>35.674415662104394 139.73830858931478 48.578 35.674431997538335 139.73832326221876 48.578 35.67442593393954 139.73830376072695 48.578 35.674415662104394 139.73830858931478 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8fb9649-af1e-47df-90bc-89c7359508be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8fb9649-af1e-47df-90bc-89c7359508be_0">
											<gml:posList>35.674415662104394 139.73830858931478 48.578 35.6744217257024 139.7383280908045 48.578 35.674431997538335 139.73832326221876 48.578 35.674415662104394 139.73830858931478 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04c1ac67-335f-46cd-9c0f-a82ac4635986">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04c1ac67-335f-46cd-9c0f-a82ac4635986_0">
											<gml:posList>35.674420379250556 139.73832377309515 44.534 35.674430651086325 139.73831894450896 45.956 35.674420379250556 139.73832377309515 45.956 35.674420379250556 139.73832377309515 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-912f606b-a00a-4ee3-bbd0-fbbc922a613a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-912f606b-a00a-4ee3-bbd0-fbbc922a613a_0">
											<gml:posList>35.674420379250556 139.73832377309515 44.534 35.674430651086325 139.73831894450896 44.534 35.674430651086325 139.73831894450896 45.956 35.674420379250556 139.73832377309515 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4364714e-c54a-42ec-8e0b-ae8eb0715e91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4364714e-c54a-42ec-8e0b-ae8eb0715e91_0">
											<gml:posList>35.674431997538335 139.73832326221876 48.578 35.6744217257024 139.7383280908045 45.956 35.674431997538335 139.73832326221876 45.956 35.674431997538335 139.73832326221876 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e55c581-e7c9-4741-b8bb-3106b2fd3809">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e55c581-e7c9-4741-b8bb-3106b2fd3809_0">
											<gml:posList>35.674431997538335 139.73832326221876 48.578 35.6744217257024 139.7383280908045 48.578 35.6744217257024 139.7383280908045 45.956 35.674431997538335 139.73832326221876 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f921bbbd-9c44-4e3c-8fcc-e40a9c861d2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f921bbbd-9c44-4e3c-8fcc-e40a9c861d2e_0">
											<gml:posList>35.674431997538335 139.73832326221876 45.956 35.674430651086325 139.73831894450896 45.956 35.674431997538335 139.73832326221876 48.578 35.674431997538335 139.73832326221876 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e2de27a-553f-42a1-8bd0-9b60df97da98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e2de27a-553f-42a1-8bd0-9b60df97da98_0">
											<gml:posList>35.674431997538335 139.73832326221876 48.578 35.674430651086325 139.73831894450896 45.956 35.67442593393954 139.73830376072695 48.578 35.674431997538335 139.73832326221876 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca7e9b02-d20a-436f-bda9-51eefd8c12b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca7e9b02-d20a-436f-bda9-51eefd8c12b1_0">
											<gml:posList>35.67442593393954 139.73830376072695 48.578 35.674430651086325 139.73831894450896 45.956 35.67442593393954 139.73830376072695 44.534 35.67442593393954 139.73830376072695 48.578</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b1498f1-27d7-4ca0-99a6-b51e9ecd80a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b1498f1-27d7-4ca0-99a6-b51e9ecd80a9_0">
											<gml:posList>35.674430651086325 139.73831894450896 45.956 35.674430651086325 139.73831894450896 44.534 35.67442593393954 139.73830376072695 44.534 35.674430651086325 139.73831894450896 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aba0ab26-de91-4e19-8a7c-20a77d86438f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aba0ab26-de91-4e19-8a7c-20a77d86438f_0">
											<gml:posList>35.6743965505729 139.7381913610996 47.352 35.67440723261633 139.7382265767121 47.352 35.67440746241213 139.73818657592554 47.352 35.6743965505729 139.7381913610996 47.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19c489db-2dfe-46ad-8b37-154be123b71a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19c489db-2dfe-46ad-8b37-154be123b71a_0">
											<gml:posList>35.67440723261633 139.7382265767121 47.352 35.67440770254242 139.73822811166175 47.352 35.674418713272196 139.73822299497022 47.352 35.67440723261633 139.7382265767121 47.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5c1f0ce-224a-4880-89f9-8f5ac029113c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5c1f0ce-224a-4880-89f9-8f5ac029113c_0">
											<gml:posList>35.67440723261633 139.7382265767121 47.352 35.674418713272196 139.73822299497022 47.352 35.67440746241213 139.73818657592554 47.352 35.67440723261633 139.7382265767121 47.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-337700cf-d80c-4fd6-ab66-d3f71583baea">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67430936914469 139.7382932166482 44.534 35.674315946716064 139.73829011574577 44.534 35.6743204920809 139.7383046369017 44.534 35.67430936914469 139.7382932166482 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b37d7e1-94ab-4639-8618-a4d2838ae1ef">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67431391450045 139.73830772675632 44.534 35.67430936914469 139.7382932166482 44.534 35.6743204920809 139.7383046369017 44.534 35.67431391450045 139.73830772675632 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9ce8a7e-2227-4c5d-8727-af647988ec42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674315416504925 139.73831498272443 44.534 35.67432266084775 139.73831157172276 44.534 35.67433158893142 139.73834011712768 44.534 35.674315416504925 139.73831498272443 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d50ab72-f710-42bf-912c-56bab76ed70e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674324344579084 139.73834351708035 44.534 35.674315416504925 139.73831498272443 44.534 35.67433158893142 139.73834011712768 44.534 35.674324344579084 139.73834351708035 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3a59b2a-a23d-4ef5-9512-25c74c270286">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67433849288246 139.73836225779007 44.534 35.67432234921594 139.73835072195985 44.534 35.67433329682896 139.73834557222503 44.534 35.67433849288246 139.73836225779007 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b72e164-bbd2-42bc-8a27-8b1ae6d0c1a9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67433849288246 139.73836225779007 44.534 35.67432753625502 139.73836740753364 44.534 35.67432234921594 139.73835072195985 44.534 35.67433849288246 139.73836225779007 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6443da63-cbbc-49f1-aa37-9ac036f38e33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67432848759655 139.73827081315906 44.534 35.67434141886194 139.73831214601609 44.534 35.67433512962436 139.73831511401428 44.534 35.67432848759655 139.73827081315906 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca02be2a-753a-4588-ad25-3d8d28a68f0c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6743221893288 139.73827375907715 44.534 35.67432848759655 139.73827081315906 44.534 35.67433512962436 139.73831511401428 44.534 35.6743221893288 139.73827375907715 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3364b58-81e5-4df6-adcf-17bd286326ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67433983031921 139.7383665755063 45.956 35.67432753625502 139.73836740753364 45.956 35.67433849288246 139.73836225779007 45.956 35.67433983031921 139.7383665755063 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b9e23df-5b75-49b8-b233-6ec97b88e733">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67433983031921 139.7383665755063 45.956 35.67432888269659 139.7383717141919 45.956 35.67432753625502 139.73836740753364 45.956 35.67433983031921 139.7383665755063 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe44889c-c61b-41f3-9a2b-2b09a0abd9ac">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67433627590699 139.7383399127313 44.534 35.674333501697504 139.7383310454351 44.534 35.674345242220305 139.73832551916576 44.534 35.67433627590699 139.7383399127313 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3962a947-c8ff-4a42-9a34-9f3e6bc54c15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67434802545264 139.7383343974992 44.534 35.67433627590699 139.7383399127313 44.534 35.674345242220305 139.73832551916576 44.534 35.67434802545264 139.7383343974992 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26c206cb-1f09-450e-89ec-eb68f012ec0e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674361018842745 139.7383516703557 44.534 35.67434494753773 139.73834045479606 44.534 35.6743559221827 139.7383352939795 44.534 35.674361018842745 139.7383516703557 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9734dcb4-de27-4cd3-9431-f069c0dc4b31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674361018842745 139.7383516703557 44.534 35.67435004418837 139.73835682012356 44.534 35.67434494753773 139.73834045479606 44.534 35.674361018842745 139.7383516703557 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1244a48-11d0-4db0-a0aa-b06eaf0e260a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67436236529358 139.73835598806232 45.956 35.67435004418837 139.73835682012356 45.956 35.674361018842745 139.7383516703557 45.956 35.67436236529358 139.73835598806232 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2daa9aa4-4814-460b-bb5a-f76854b807d9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67436236529358 139.73835598806232 45.956 35.67435139063903 139.73836113782966 45.956 35.67435004418837 139.73835682012356 45.956 35.67436236529358 139.73835598806232 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-132d81f0-16f8-4ab7-960a-30ee7dd03c11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67439315453296 139.73831962966597 44.534 35.67440758450671 139.73832978667915 44.534 35.674397754176965 139.73833440484992 44.534 35.67439315453296 139.73831962966597 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b00c680b-0630-40ba-9e58-ec985998ad80">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67439315453296 139.73831962966597 44.534 35.67440298486215 139.73831501149368 44.534 35.67440758450671 139.73832978667915 44.534 35.67439315453296 139.73831962966597 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57877daf-39b2-41dc-9f7f-194a8006a8fa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674408930958336 139.7383341043879 45.956 35.674397754176965 139.73833440484992 45.956 35.67440758450671 139.73832978667915 45.956 35.674408930958336 139.7383341043879 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45483f59-da04-4a80-85ca-c9de62b9ed71">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674408930958336 139.7383341043879 45.956 35.67439910062842 139.7383387225582 45.956 35.674397754176965 139.73833440484992 45.956 35.674408930958336 139.7383341043879 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b84257fa-c4fa-423f-bd76-d92745bce16d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6743965505729 139.7381913610996 44.534 35.67440372301188 139.73818821529218 44.534 35.67440723261633 139.7382265767121 44.534 35.6743965505729 139.7381913610996 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f96d7cbf-8c99-4838-b8d6-2c96f0ef0216">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67440372301188 139.73818821529218 44.534 35.6744150099874 139.73822471162023 44.534 35.67440723261633 139.7382265767121 44.534 35.67440372301188 139.73818821529218 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57d3b683-5fca-4092-9f4e-472882856a62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6744150099874 139.73822471162023 44.534 35.67440770254242 139.73822811166175 44.534 35.67440723261633 139.7382265767121 44.534 35.6744150099874 139.73822471162023 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-159f3375-4647-4b24-945d-8dc874037610">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67440746241213 139.73818657592554 45.956 35.6744150099874 139.73822471162023 45.956 35.67440372301188 139.73818821529218 45.956 35.67440746241213 139.73818657592554 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-290dcece-2745-457a-b526-a2043163a346">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67440746241213 139.73818657592554 45.956 35.674418713272196 139.73822299497022 45.956 35.6744150099874 139.73822471162023 45.956 35.67440746241213 139.73818657592554 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c16fd7b-4643-4b58-9a2a-786dcfc47cd1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674430651086325 139.73831894450896 44.534 35.674415662104394 139.73830858931478 44.534 35.67442593393954 139.73830376072695 44.534 35.674430651086325 139.73831894450896 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbf60a29-bbad-4e83-ab66-458a70697bd0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674430651086325 139.73831894450896 44.534 35.674420379250556 139.73832377309515 44.534 35.674415662104394 139.73830858931478 44.534 35.674430651086325 139.73831894450896 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bca59bd-71fe-4f68-9ba3-b205b1c07111">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674431997538335 139.73832326221876 45.956 35.674420379250556 139.73832377309515 45.956 35.674430651086325 139.73831894450896 45.956 35.674431997538335 139.73832326221876 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ff40c46-dc65-4320-8bd2-a7769379cd90">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674431997538335 139.73832326221876 45.956 35.6744217257024 139.7383280908045 45.956 35.674420379250556 139.73832377309515 45.956 35.674431997538335 139.73832326221876 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-157b1d66-b41d-4f61-9639-31b455748f68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-157b1d66-b41d-4f61-9639-31b455748f68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-157b1d66-b41d-4f61-9639-31b455748f68">
											<gml:posList>35.67444846947694 139.7383167361198 7.9 35.67431223245783 139.73838074810482 7.9 35.67425692620904 139.73820052994427 7.9 35.67439334489226 139.73813839543982 7.9 35.67444846947694 139.7383167361198 7.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa70abad-ee53-4d54-ac1e-716787822d00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa70abad-ee53-4d54-ac1e-716787822d00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa70abad-ee53-4d54-ac1e-716787822d00">
											<gml:posList>35.6743820457446 139.73814353457743 45.956 35.67438807861044 139.73814692983183 45.956 35.674390610565176 139.73814578900388 45.956 35.67439334489226 139.73813839543982 45.956 35.6743820457446 139.73814353457743 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-689e2298-a06b-4fc3-a4a6-c99c0df1a5fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-689e2298-a06b-4fc3-a4a6-c99c0df1a5fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-689e2298-a06b-4fc3-a4a6-c99c0df1a5fd">
											<gml:posList>35.67438807861044 139.73814692983183 45.956 35.6743820457446 139.73814353457743 45.956 35.67438368149762 139.7381489345256 45.956 35.67438807861044 139.73814692983183 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e76905ff-73d3-44e0-a9e6-a57dd7e940e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e76905ff-73d3-44e0-a9e6-a57dd7e940e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e76905ff-73d3-44e0-a9e6-a57dd7e940e7">
											<gml:posList>35.67427762328748 139.73819110455952 52.316 35.67428272732034 139.7381939706692 52.316 35.67437971613496 139.73814978983825 52.316 35.6743820457446 139.73814353457743 52.316 35.67427762328748 139.73819110455952 52.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4e83a35-ec59-46e5-82ec-123e87e4c2f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4e83a35-ec59-46e5-82ec-123e87e4c2f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4e83a35-ec59-46e5-82ec-123e87e4c2f1">
											<gml:posList>35.6743820457446 139.73814353457743 52.316 35.67437971613496 139.73814978983825 52.316 35.6744021376068 139.73822372163204 52.316 35.67440723261633 139.7382265767121 52.316 35.6743820457446 139.73814353457743 52.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4c27afc-7046-4c1d-b3a0-8f7ed0299939">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4c27afc-7046-4c1d-b3a0-8f7ed0299939">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4c27afc-7046-4c1d-b3a0-8f7ed0299939">
											<gml:posList>35.67426298610581 139.73820391411886 45.956 35.674279259038386 139.73819650450164 45.956 35.67427762328748 139.73819110455952 45.956 35.67425692620904 139.73820052994427 45.956 35.67426298610581 139.73820391411886 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad92dc8c-6f01-4af7-9580-b1c3eb905fb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad92dc8c-6f01-4af7-9580-b1c3eb905fb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad92dc8c-6f01-4af7-9580-b1c3eb905fb6">
											<gml:posList>35.6744021376068 139.73822372163204 49.592 35.67437971613496 139.73814978983825 49.592 35.67428272732034 139.7381939706692 49.592 35.67430513975157 139.73826790239667 49.592 35.6744021376068 139.73822372163204 49.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-483971da-1bd3-4cbc-a079-b7e7e15c586b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-483971da-1bd3-4cbc-a079-b7e7e15c586b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-483971da-1bd3-4cbc-a079-b7e7e15c586b">
											<gml:posList>35.67439334489226 139.73813839543982 45.956 35.674390610565176 139.73814578900388 45.956 35.67444242765452 139.7383134071416 45.956 35.67444846947694 139.7383167361198 45.956 35.67439334489226 139.73813839543982 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-207fa151-3e9f-46ca-b54d-ae5e1516f9d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-207fa151-3e9f-46ca-b54d-ae5e1516f9d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-207fa151-3e9f-46ca-b54d-ae5e1516f9d4">
											<gml:posList>35.67430280111299 139.7382741466118 52.316 35.67430513975157 139.73826790239667 52.316 35.67428272732034 139.7381939706692 52.316 35.67427762328748 139.73819110455952 52.316 35.67430280111299 139.7382741466118 52.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f807c01-66b2-4bf3-bfa2-54fa9c85e231">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f807c01-66b2-4bf3-bfa2-54fa9c85e231">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f807c01-66b2-4bf3-bfa2-54fa9c85e231">
											<gml:posList>35.67440723261633 139.7382265767121 52.316 35.6744021376068 139.73822372163204 52.316 35.67430513975157 139.73826790239667 52.316 35.67430280111299 139.7382741466118 52.316 35.67440723261633 139.7382265767121 52.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-467592cb-aeec-4984-a082-d9e3f42cae0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-467592cb-aeec-4984-a082-d9e3f42cae0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-467592cb-aeec-4984-a082-d9e3f42cae0b">
											<gml:posList>35.67431223245783 139.73838074810482 45.956 35.674314966764555 139.73837331036881 45.956 35.67426298610581 139.73820391411886 45.956 35.67425692620904 139.73820052994427 45.956 35.67431223245783 139.73838074810482 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21e6ddd1-dda0-4eb7-b995-27c6649c5b17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21e6ddd1-dda0-4eb7-b995-27c6649c5b17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21e6ddd1-dda0-4eb7-b995-27c6649c5b17">
											<gml:posList>35.67430280111299 139.7382741466118 44.534 35.674279259038386 139.73819650450164 44.534 35.67426298610581 139.73820391411886 44.534 35.674314966764555 139.73837331036881 44.534 35.67444242765452 139.7383134071416 44.534 35.674390610565176 139.73814578900388 44.534 35.67438807861044 139.73814692983183 44.534 35.67438368149762 139.7381489345256 44.534 35.67440723261633 139.7382265767121 44.534 35.67430280111299 139.7382741466118 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c25b1a5-4a9d-41bb-ba78-fd6ebac62527">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c25b1a5-4a9d-41bb-ba78-fd6ebac62527">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c25b1a5-4a9d-41bb-ba78-fd6ebac62527">
											<gml:posList>35.67444846947694 139.7383167361198 45.956 35.67444242765452 139.7383134071416 45.956 35.674314966764555 139.73837331036881 45.956 35.67431223245783 139.73838074810482 45.956 35.67444846947694 139.7383167361198 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac5918fe-af11-4741-bff9-02657e0de312">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac5918fe-af11-4741-bff9-02657e0de312">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac5918fe-af11-4741-bff9-02657e0de312">
											<gml:posList>35.67438807861044 139.73814692983183 45.956 35.67438807861044 139.73814692983183 44.534 35.674390610565176 139.73814578900388 44.534 35.674390610565176 139.73814578900388 45.956 35.67438807861044 139.73814692983183 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25b60ba7-8f93-481e-82e0-bb3f563767b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25b60ba7-8f93-481e-82e0-bb3f563767b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25b60ba7-8f93-481e-82e0-bb3f563767b2">
											<gml:posList>35.67438368149762 139.7381489345256 45.956 35.67438368149762 139.7381489345256 44.534 35.67438807861044 139.73814692983183 44.534 35.67438807861044 139.73814692983183 45.956 35.67438368149762 139.7381489345256 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-badc1c37-91fa-4fef-8f6c-d9ae0d1c85e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-badc1c37-91fa-4fef-8f6c-d9ae0d1c85e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-badc1c37-91fa-4fef-8f6c-d9ae0d1c85e3">
											<gml:posList>35.67427762328748 139.73819110455952 45.956 35.67427762328748 139.73819110455952 52.316 35.6743820457446 139.73814353457743 52.316 35.6743820457446 139.73814353457743 45.956 35.67439334489226 139.73813839543982 45.956 35.67439334489226 139.73813839543982 7.9 35.67425692620904 139.73820052994427 7.9 35.67425692620904 139.73820052994427 45.956 35.67427762328748 139.73819110455952 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15c8499d-3f89-4614-b3ba-90d4be9d49f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15c8499d-3f89-4614-b3ba-90d4be9d49f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15c8499d-3f89-4614-b3ba-90d4be9d49f8">
											<gml:posList>35.67428272732034 139.7381939706692 52.316 35.67428272732034 139.7381939706692 49.592 35.67437971613496 139.73814978983825 49.592 35.67437971613496 139.73814978983825 52.316 35.67428272732034 139.7381939706692 52.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56587586-1838-44ff-b197-b638edde3a12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56587586-1838-44ff-b197-b638edde3a12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56587586-1838-44ff-b197-b638edde3a12">
											<gml:posList>35.67438368149762 139.7381489345256 45.956 35.6743820457446 139.73814353457743 45.956 35.6743820457446 139.73814353457743 52.316 35.67440723261633 139.7382265767121 52.316 35.67440723261633 139.7382265767121 44.534 35.67438368149762 139.7381489345256 44.534 35.67438368149762 139.7381489345256 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2f7b0ad-057a-42fa-a97f-fc09efc048c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2f7b0ad-057a-42fa-a97f-fc09efc048c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2f7b0ad-057a-42fa-a97f-fc09efc048c2">
											<gml:posList>35.67437971613496 139.73814978983825 52.316 35.67437971613496 139.73814978983825 49.592 35.6744021376068 139.73822372163204 49.592 35.6744021376068 139.73822372163204 52.316 35.67437971613496 139.73814978983825 52.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f06f8542-bcef-41ba-8a6c-e3bbf6ba339b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f06f8542-bcef-41ba-8a6c-e3bbf6ba339b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f06f8542-bcef-41ba-8a6c-e3bbf6ba339b">
											<gml:posList>35.67426298610581 139.73820391411886 45.956 35.67426298610581 139.73820391411886 44.534 35.674279259038386 139.73819650450164 44.534 35.674279259038386 139.73819650450164 45.956 35.67426298610581 139.73820391411886 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d31d7140-1c00-4fee-b16f-238d7d92c308">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d31d7140-1c00-4fee-b16f-238d7d92c308">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d31d7140-1c00-4fee-b16f-238d7d92c308">
											<gml:posList>35.67444846947694 139.7383167361198 7.9 35.67439334489226 139.73813839543982 7.9 35.67439334489226 139.73813839543982 45.956 35.67444846947694 139.7383167361198 45.956 35.67444846947694 139.7383167361198 7.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50c18f6d-f94c-481d-98bc-8e6e2c25c45f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50c18f6d-f94c-481d-98bc-8e6e2c25c45f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50c18f6d-f94c-481d-98bc-8e6e2c25c45f">
											<gml:posList>35.674390610565176 139.73814578900388 45.956 35.674390610565176 139.73814578900388 44.534 35.67444242765452 139.7383134071416 44.534 35.67444242765452 139.7383134071416 45.956 35.674390610565176 139.73814578900388 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a468d673-2860-4119-9a79-6f690e3a710b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a468d673-2860-4119-9a79-6f690e3a710b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a468d673-2860-4119-9a79-6f690e3a710b">
											<gml:posList>35.67430513975157 139.73826790239667 52.316 35.67430513975157 139.73826790239667 49.592 35.67428272732034 139.7381939706692 49.592 35.67428272732034 139.7381939706692 52.316 35.67430513975157 139.73826790239667 52.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d327046b-dbe6-41d9-b0e9-7d8042c9c492">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d327046b-dbe6-41d9-b0e9-7d8042c9c492">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d327046b-dbe6-41d9-b0e9-7d8042c9c492">
											<gml:posList>35.67430280111299 139.7382741466118 44.534 35.67430280111299 139.7382741466118 52.316 35.67427762328748 139.73819110455952 52.316 35.67427762328748 139.73819110455952 45.956 35.674279259038386 139.73819650450164 45.956 35.674279259038386 139.73819650450164 44.534 35.67430280111299 139.7382741466118 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c56fb6f-bec8-4ee6-b52e-e7eec8cc8bf7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c56fb6f-bec8-4ee6-b52e-e7eec8cc8bf7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c56fb6f-bec8-4ee6-b52e-e7eec8cc8bf7">
											<gml:posList>35.6744021376068 139.73822372163204 52.316 35.6744021376068 139.73822372163204 49.592 35.67430513975157 139.73826790239667 49.592 35.67430513975157 139.73826790239667 52.316 35.6744021376068 139.73822372163204 52.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47c359d2-3786-4326-82c6-ed4e1812454b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47c359d2-3786-4326-82c6-ed4e1812454b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47c359d2-3786-4326-82c6-ed4e1812454b">
											<gml:posList>35.67430280111299 139.7382741466118 44.534 35.67440723261633 139.7382265767121 44.534 35.67440723261633 139.7382265767121 52.316 35.67430280111299 139.7382741466118 52.316 35.67430280111299 139.7382741466118 44.534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-378031c9-f55c-44cb-8dc9-628994d50d8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-378031c9-f55c-44cb-8dc9-628994d50d8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-378031c9-f55c-44cb-8dc9-628994d50d8f">
											<gml:posList>35.674314966764555 139.73837331036881 45.956 35.674314966764555 139.73837331036881 44.534 35.67426298610581 139.73820391411886 44.534 35.67426298610581 139.73820391411886 45.956 35.674314966764555 139.73837331036881 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-42b97f5c-650a-4db5-b444-23d92edae934">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42b97f5c-650a-4db5-b444-23d92edae934">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42b97f5c-650a-4db5-b444-23d92edae934">
											<gml:posList>35.67425692620904 139.73820052994427 7.9 35.67431223245783 139.73838074810482 7.9 35.67431223245783 139.73838074810482 45.956 35.67425692620904 139.73820052994427 45.956 35.67425692620904 139.73820052994427 7.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a472bc0-f8ec-4281-85e6-6a9f8ed818f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a472bc0-f8ec-4281-85e6-6a9f8ed818f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a472bc0-f8ec-4281-85e6-6a9f8ed818f3">
											<gml:posList>35.67444242765452 139.7383134071416 45.956 35.67444242765452 139.7383134071416 44.534 35.674314966764555 139.73837331036881 44.534 35.674314966764555 139.73837331036881 45.956 35.67444242765452 139.7383134071416 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5303eb75-bd78-4097-a692-0f337b8d17d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5303eb75-bd78-4097-a692-0f337b8d17d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5303eb75-bd78-4097-a692-0f337b8d17d7">
											<gml:posList>35.67444846947694 139.7383167361198 45.956 35.67431223245783 139.73838074810482 45.956 35.67431223245783 139.73838074810482 7.9 35.67444846947694 139.7383167361198 7.9 35.67444846947694 139.7383167361198 45.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4016</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">280.432</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.46</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>