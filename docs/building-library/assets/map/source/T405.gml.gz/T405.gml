<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_753ab546-5ec6-4c11-9f4b-9f2745ed5058">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">43</bldg:measuredHeight>
			<bldg:storeysAboveGround>15</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671500126788004 139.73975836299226 0 35.67140623033329 139.73990870363298 0 35.67145926494445 139.73995238560937 0 35.67154299182044 139.73982249266027 0 35.671528650653116 139.73981046879186 0 35.671552461574755 139.73977134773295 0 35.67156933079286 139.73978878139548 0 35.67162870509524 139.73969712615664 0 35.67153217964227 139.73959616416445 0 35.67152533480387 139.73960335233835 0 35.67149601595907 139.7395722357295 0 35.6714413646641 139.73965194422638 0 35.671441913565445 139.73966232720633 0 35.671516152151064 139.7397338212451 0 35.671500126788004 139.73975836299226 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671500126788004 139.73975836299226 9.55 35.671516152151064 139.7397338212451 9.55 35.671441913565445 139.73966232720633 9.55 35.6714413646641 139.73965194422638 9.55 35.67149601595907 139.7395722357295 9.55 35.67152533480387 139.73960335233835 9.55 35.67153217964227 139.73959616416445 9.55 35.67162870509524 139.73969712615664 9.55 35.67156933079286 139.73978878139548 9.55 35.671552461574755 139.73977134773295 9.55 35.671528650653116 139.73981046879186 9.55 35.67154299182044 139.73982249266027 9.55 35.67145926494445 139.73995238560937 9.55 35.67140623033329 139.73990870363298 9.55 35.671500126788004 139.73975836299226 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671500126788004 139.73975836299226 9.55 35.67140623033329 139.73990870363298 9.55 35.67140623033329 139.73990870363298 45.22 35.671500126788004 139.73975836299226 45.22 35.671500126788004 139.73975836299226 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67140623033329 139.73990870363298 9.55 35.67145926494445 139.73995238560937 9.55 35.67145926494445 139.73995238560937 45.22 35.67140623033329 139.73990870363298 45.22 35.67140623033329 139.73990870363298 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67145926494445 139.73995238560937 9.55 35.67154299182044 139.73982249266027 9.55 35.67154299182044 139.73982249266027 45.22 35.67145926494445 139.73995238560937 45.22 35.67145926494445 139.73995238560937 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67154299182044 139.73982249266027 9.55 35.671528650653116 139.73981046879186 9.55 35.671528650653116 139.73981046879186 45.22 35.67154299182044 139.73982249266027 45.22 35.67154299182044 139.73982249266027 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671528650653116 139.73981046879186 9.55 35.671552461574755 139.73977134773295 9.55 35.671552461574755 139.73977134773295 45.22 35.671528650653116 139.73981046879186 45.22 35.671528650653116 139.73981046879186 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671552461574755 139.73977134773295 9.55 35.67156933079286 139.73978878139548 9.55 35.67156933079286 139.73978878139548 45.22 35.671552461574755 139.73977134773295 45.22 35.671552461574755 139.73977134773295 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156933079286 139.73978878139548 9.55 35.67162870509524 139.73969712615664 9.55 35.67162870509524 139.73969712615664 45.22 35.67156933079286 139.73978878139548 45.22 35.67156933079286 139.73978878139548 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67162870509524 139.73969712615664 9.55 35.67153217964227 139.73959616416445 9.55 35.67153217964227 139.73959616416445 45.22 35.67162870509524 139.73969712615664 45.22 35.67162870509524 139.73969712615664 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67153217964227 139.73959616416445 9.55 35.67152533480387 139.73960335233835 9.55 35.67152533480387 139.73960335233835 45.22 35.67153217964227 139.73959616416445 45.22 35.67153217964227 139.73959616416445 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67152533480387 139.73960335233835 9.55 35.67149601595907 139.7395722357295 9.55 35.67149601595907 139.7395722357295 45.22 35.67152533480387 139.73960335233835 45.22 35.67152533480387 139.73960335233835 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67149601595907 139.7395722357295 9.55 35.6714413646641 139.73965194422638 9.55 35.6714413646641 139.73965194422638 45.22 35.67149601595907 139.7395722357295 45.22 35.67149601595907 139.7395722357295 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6714413646641 139.73965194422638 9.55 35.671441913565445 139.73966232720633 9.55 35.671441913565445 139.73966232720633 45.22 35.6714413646641 139.73965194422638 45.22 35.6714413646641 139.73965194422638 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671441913565445 139.73966232720633 9.55 35.671516152151064 139.7397338212451 9.55 35.671516152151064 139.7397338212451 45.22 35.671441913565445 139.73966232720633 45.22 35.671441913565445 139.73966232720633 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671516152151064 139.7397338212451 9.55 35.671500126788004 139.73975836299226 9.55 35.671500126788004 139.73975836299226 45.22 35.671516152151064 139.7397338212451 45.22 35.671516152151064 139.7397338212451 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671500126788004 139.73975836299226 45.22 35.67140623033329 139.73990870363298 45.22 35.67145926494445 139.73995238560937 45.22 35.67154299182044 139.73982249266027 45.22 35.671528650653116 139.73981046879186 45.22 35.671552461574755 139.73977134773295 45.22 35.67156933079286 139.73978878139548 45.22 35.67162870509524 139.73969712615664 45.22 35.67153217964227 139.73959616416445 45.22 35.67152533480387 139.73960335233835 45.22 35.67149601595907 139.7395722357295 45.22 35.6714413646641 139.73965194422638 45.22 35.671441913565445 139.73966232720633 45.22 35.671516152151064 139.7397338212451 45.22 35.671500126788004 139.73975836299226 45.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2beea0ad-397f-4b1f-b67e-49870a9527f6"/>
							<gml:surfaceMember xlink:href="#poly-518c2723-a6fd-4821-bfa2-6a01763651b0"/>
							<gml:surfaceMember xlink:href="#poly-44b0f3d3-0aa3-41f2-9a69-204a3a3b3112"/>
							<gml:surfaceMember xlink:href="#poly-686947b2-0852-412f-b885-a2ad7ce411bb"/>
							<gml:surfaceMember xlink:href="#poly-21051869-357f-470a-9909-95ecfa692a3c"/>
							<gml:surfaceMember xlink:href="#poly-3f97e95e-c210-4808-98c4-f2ec6882ea55"/>
							<gml:surfaceMember xlink:href="#poly-f2e9b64c-dd2d-4678-9d4f-94ce2b1477d2"/>
							<gml:surfaceMember xlink:href="#poly-21d68377-cd0e-48bd-98d4-f1a77967b78c"/>
							<gml:surfaceMember xlink:href="#poly-9b8fb645-cbb3-41ba-8449-e1684c371c37"/>
							<gml:surfaceMember xlink:href="#poly-09d4cdd1-d08a-4163-871a-7afb8dd46f7e"/>
							<gml:surfaceMember xlink:href="#poly-5b82da2e-02a4-49f2-85ff-f2737dca62a7"/>
							<gml:surfaceMember xlink:href="#poly-04ea5e14-8f64-4cf1-b27c-0955eaa99642"/>
							<gml:surfaceMember xlink:href="#poly-903a1866-369b-40cf-bf13-301111eddf99"/>
							<gml:surfaceMember xlink:href="#poly-15691152-2131-48d0-9060-afdb12bd7310"/>
							<gml:surfaceMember xlink:href="#poly-d010c764-ba74-4fe6-9610-aaca95d9aee1"/>
							<gml:surfaceMember xlink:href="#poly-6bd582fa-81a8-4d9f-b48f-c4587acd6d7d"/>
							<gml:surfaceMember xlink:href="#poly-08779652-b1ec-4ef9-ad24-1667797a4a0e"/>
							<gml:surfaceMember xlink:href="#poly-63a1911a-27df-4a32-8988-5a2abf2be581"/>
							<gml:surfaceMember xlink:href="#poly-be606f14-79bc-45ec-a677-9ed2898e1e9c"/>
							<gml:surfaceMember xlink:href="#poly-8b0f5e05-42a6-4164-a43d-858ba0460366"/>
							<gml:surfaceMember xlink:href="#poly-6265316a-e353-4198-858e-13c47a7c915a"/>
							<gml:surfaceMember xlink:href="#poly-d9dd85fb-253c-4ad1-89cf-ef796603f8c4"/>
							<gml:surfaceMember xlink:href="#poly-4faac561-f891-4e0f-8b18-ae24250f26d8"/>
							<gml:surfaceMember xlink:href="#poly-e1330c77-8b73-457a-bab5-46d6cca4a901"/>
							<gml:surfaceMember xlink:href="#poly-c1a77808-3d18-4a47-aaaa-0b18a2d146aa"/>
							<gml:surfaceMember xlink:href="#poly-98b84e39-0105-4ebf-8f18-a9be667278bf"/>
							<gml:surfaceMember xlink:href="#poly-173bbb22-2e74-4802-8a22-c276105f9e32"/>
							<gml:surfaceMember xlink:href="#poly-847d8006-5809-447c-8225-9e6d0f0e571f"/>
							<gml:surfaceMember xlink:href="#poly-d4e4cd21-5518-4e61-819e-76b9433d0f59"/>
							<gml:surfaceMember xlink:href="#poly-4b08836c-56ca-4ae8-885a-0a703f0eb13e"/>
							<gml:surfaceMember xlink:href="#poly-8ea64fec-47f2-435f-b93c-f4f2dc5c60e1"/>
							<gml:surfaceMember xlink:href="#poly-0ce38583-e028-4a2b-a11e-2f550b070d49"/>
							<gml:surfaceMember xlink:href="#poly-1657f3b1-3bf8-4ff8-9b27-e6112cf76559"/>
							<gml:surfaceMember xlink:href="#poly-4d5688ff-24e6-4c00-9914-29b143f5981a"/>
							<gml:surfaceMember xlink:href="#poly-0673f549-7439-4a07-8887-a4e112e2a46f"/>
							<gml:surfaceMember xlink:href="#poly-cead2dbd-feb3-46df-b897-58368bb112b1"/>
							<gml:surfaceMember xlink:href="#poly-c57946ae-3c28-4a77-9346-e2f9ce618689"/>
							<gml:surfaceMember xlink:href="#poly-6d1f6ba3-04bd-4963-83ca-fca4dd0b865b"/>
							<gml:surfaceMember xlink:href="#poly-76262ac8-2d96-4d40-b4d3-77f1e8c91fcf"/>
							<gml:surfaceMember xlink:href="#poly-3a70c6a5-5e5e-4d12-899a-892a3d7c4739"/>
							<gml:surfaceMember xlink:href="#poly-7af0531e-6a36-42ef-8769-a807cd802df3"/>
							<gml:surfaceMember xlink:href="#poly-d1fb0093-7c86-4a39-aed3-7258c581073f"/>
							<gml:surfaceMember xlink:href="#poly-14bd2758-482e-46a7-8121-f1dc2b3725cd"/>
							<gml:surfaceMember xlink:href="#poly-31418db5-5e57-4ac6-b935-b9e93a6ed706"/>
							<gml:surfaceMember xlink:href="#poly-a1a54f18-29e1-4c0e-986a-5eb776b8316a"/>
							<gml:surfaceMember xlink:href="#poly-0c009b9c-178b-4fe8-a620-9378baeebe68"/>
							<gml:surfaceMember xlink:href="#poly-ea5213a8-c83d-4c74-b06d-adafa5c515de"/>
							<gml:surfaceMember xlink:href="#poly-2e02a466-36fc-49eb-aa22-8cb7f0e084ef"/>
							<gml:surfaceMember xlink:href="#poly-0156f2a9-bdc5-40c6-8d24-8dbc68eca7f4"/>
							<gml:surfaceMember xlink:href="#poly-e22c3455-d0e6-416a-8051-31efcee6529a"/>
							<gml:surfaceMember xlink:href="#poly-e4fdc9d2-7d36-456d-949a-3a6426a4f463"/>
							<gml:surfaceMember xlink:href="#poly-13acda27-e51a-4d41-8008-4cd72911f079"/>
							<gml:surfaceMember xlink:href="#poly-a5e95740-387f-4e04-88ff-c7b664e60582"/>
							<gml:surfaceMember xlink:href="#poly-c4f28bb6-7247-4c31-b6c2-d686f27de3f6"/>
							<gml:surfaceMember xlink:href="#poly-6d65bbcf-ab84-4add-8edc-904d53737b95"/>
							<gml:surfaceMember xlink:href="#poly-e26d4e78-5f67-4f60-baf1-c76fcc33f83a"/>
							<gml:surfaceMember xlink:href="#poly-48c80df4-c222-4a40-8107-d52db0bed8d8"/>
							<gml:surfaceMember xlink:href="#poly-8a574f29-f5bb-48a3-8f76-55f1ac9c126f"/>
							<gml:surfaceMember xlink:href="#poly-b6dd9ed0-241d-460e-a977-e4756ae78752"/>
							<gml:surfaceMember xlink:href="#poly-10245ef1-c78e-4f07-8810-1e10ac287d7c"/>
							<gml:surfaceMember xlink:href="#poly-ff5a22ad-21e7-48f0-b1b9-bc17c7869777"/>
							<gml:surfaceMember xlink:href="#poly-f282f9c8-4831-4a00-bf65-6940990802e6"/>
							<gml:surfaceMember xlink:href="#poly-9f621825-03d0-43f5-8e86-a4b5c5d94975"/>
							<gml:surfaceMember xlink:href="#poly-04278a87-5c6e-43b8-a852-ba05333a5030"/>
							<gml:surfaceMember xlink:href="#poly-94f70121-4742-4e32-924e-9678bc8da072"/>
							<gml:surfaceMember xlink:href="#poly-e60c96a2-3c6b-465e-9ee8-dd41adaeafe8"/>
							<gml:surfaceMember xlink:href="#poly-4da6c238-29d3-40c5-b941-f0dc43ac1a56"/>
							<gml:surfaceMember xlink:href="#poly-f38711cb-faae-4b4d-9758-9fe6ea098965"/>
							<gml:surfaceMember xlink:href="#poly-460fe29a-536c-4c56-967e-252907decafd"/>
							<gml:surfaceMember xlink:href="#poly-a13d2696-51b3-47da-8a2b-0144f00ee094"/>
							<gml:surfaceMember xlink:href="#poly-94fb0e2d-cc4c-492a-8705-d6240b0de627"/>
							<gml:surfaceMember xlink:href="#poly-9a62fdec-359c-4d3e-9550-212dbf54a3f4"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_753ab546-5ec6-4c11-9f4b-9f2745ed5058_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e22a15fe-c349-4114-93e4-3ae17df7736c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67150317711054 139.73965876496266 58.776 35.67150604856871 139.7396537244427 58.776 35.67151186630302 139.73965871062464 58.776 35.67150900385838 139.7396637511343 58.776 35.67150317711054 139.73965876496266 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-258937ed-fb5d-49bb-bf6f-9af213bdbb2d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67152061014455 139.73968256066806 58.776 35.67151196752512 139.7396729603821 58.776 35.67151972918931 139.7396624572193 58.776 35.671528380823275 139.73967205749452 58.776 35.67152061014455 139.73968256066806 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1956ae92-1409-4830-a78e-ca6420351ec4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67154414086265 139.73967725299335 58.776 35.67156249639676 139.73964709691126 58.776 35.67157498027256 139.73965850432577 58.776 35.671556624744234 139.7396886714564 58.776 35.67154414086265 139.73967725299335 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f1cbae7-5d23-44fd-9c60-cbbdd2e8a57c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f1cbae7-5d23-44fd-9c60-cbbdd2e8a57c_0">
											<gml:posList>35.67150604856871 139.7396537244427 58.776 35.67150317711054 139.73965876496266 58.776 35.67150317711054 139.73965876496266 62.134 35.67150604856871 139.7396537244427 62.134 35.67150604856871 139.7396537244427 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfcbdbc7-cd9a-46fc-bceb-05596ca8c4d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfcbdbc7-cd9a-46fc-bceb-05596ca8c4d2_0">
											<gml:posList>35.67150317711054 139.73965876496266 58.776 35.67150900385838 139.7396637511343 58.776 35.67150900385838 139.7396637511343 62.134 35.67150317711054 139.73965876496266 62.134 35.67150317711054 139.73965876496266 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef0c6748-e7a4-414f-a92c-1656793b09d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef0c6748-e7a4-414f-a92c-1656793b09d4_0">
											<gml:posList>35.67150317711054 139.73965876496266 62.134 35.67150900385838 139.7396637511343 62.134 35.67151186630302 139.73965871062464 62.134 35.67150604856871 139.7396537244427 62.134 35.67150317711054 139.73965876496266 62.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19919386-1ee4-4e23-bcd0-a6dad34e7e2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19919386-1ee4-4e23-bcd0-a6dad34e7e2c_0">
											<gml:posList>35.67151186630302 139.73965871062464 58.776 35.67150604856871 139.7396537244427 58.776 35.67150604856871 139.7396537244427 62.134 35.67151186630302 139.73965871062464 62.134 35.67151186630302 139.73965871062464 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a20b605f-de5f-43df-8df5-eab982ee7c7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a20b605f-de5f-43df-8df5-eab982ee7c7d_0">
											<gml:posList>35.67150900385838 139.7396637511343 58.776 35.67151186630302 139.73965871062464 58.776 35.67151186630302 139.73965871062464 62.134 35.67150900385838 139.7396637511343 62.134 35.67150900385838 139.7396637511343 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68a1fe31-baea-4ed2-80c9-4da3a9b6193c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68a1fe31-baea-4ed2-80c9-4da3a9b6193c_0">
											<gml:posList>35.67151972918931 139.7396624572193 58.776 35.67151196752512 139.7396729603821 58.776 35.67151196752512 139.7396729603821 61.294 35.67151972918931 139.7396624572193 61.294 35.67151972918931 139.7396624572193 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6a20c90-d15f-4f62-92ee-e13c7da1cb40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6a20c90-d15f-4f62-92ee-e13c7da1cb40_0">
											<gml:posList>35.67151196752512 139.7396729603821 58.776 35.67152061014455 139.73968256066806 58.776 35.67152061014455 139.73968256066806 61.294 35.67151196752512 139.7396729603821 61.294 35.67151196752512 139.7396729603821 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0834d83-e2b1-4740-a8f0-0a016dce4ca8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0834d83-e2b1-4740-a8f0-0a016dce4ca8_0">
											<gml:posList>35.67151972918931 139.7396624572193 61.294 35.67151196752512 139.7396729603821 61.294 35.67152061014455 139.73968256066806 61.294 35.671528380823275 139.73967205749452 61.294 35.67151972918931 139.7396624572193 61.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ac30d2f-3053-4dd2-ba8c-10f7ce249263">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ac30d2f-3053-4dd2-ba8c-10f7ce249263_0">
											<gml:posList>35.671528380823275 139.73967205749452 58.776 35.67151972918931 139.7396624572193 58.776 35.67151972918931 139.7396624572193 61.294 35.671528380823275 139.73967205749452 61.294 35.671528380823275 139.73967205749452 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-911174e8-ed07-4b9f-8e9b-0ccc7a4a3518">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-911174e8-ed07-4b9f-8e9b-0ccc7a4a3518_0">
											<gml:posList>35.671528380823275 139.73967205749452 58.776 35.671528380823275 139.73967205749452 61.294 35.67152061014455 139.73968256066806 61.294 35.67152061014455 139.73968256066806 58.776 35.671528380823275 139.73967205749452 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74524627-3a10-45d5-a0e6-38523d770e55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74524627-3a10-45d5-a0e6-38523d770e55_0">
											<gml:posList>35.67154414086265 139.73967725299335 58.776 35.671556624744234 139.7396886714564 58.776 35.671556624744234 139.7396886714564 60.349 35.67154414086265 139.73967725299335 60.349 35.67154414086265 139.73967725299335 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfec624e-4d57-4a45-8e73-277030b05206">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfec624e-4d57-4a45-8e73-277030b05206_0">
											<gml:posList>35.67154414086265 139.73967725299335 58.776 35.67154414086265 139.73967725299335 60.349 35.67156249639676 139.73964709691126 60.349 35.67156249639676 139.73964709691126 58.776 35.67154414086265 139.73967725299335 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10f346da-6e68-46f8-acbb-ae6cb1778e5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10f346da-6e68-46f8-acbb-ae6cb1778e5b_0">
											<gml:posList>35.67157498027256 139.73965850432577 60.349 35.67156249639676 139.73964709691126 60.349 35.67154414086265 139.73967725299335 60.349 35.671556624744234 139.7396886714564 60.349 35.67157498027256 139.73965850432577 60.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cdf60fa-4989-4555-a201-1c5ad809c16c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0cdf60fa-4989-4555-a201-1c5ad809c16c_0">
											<gml:posList>35.671556624744234 139.7396886714564 58.776 35.67157498027256 139.73965850432577 58.776 35.67157498027256 139.73965850432577 60.349 35.671556624744234 139.7396886714564 60.349 35.671556624744234 139.7396886714564 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2450490-5b31-4c9f-991f-069051584b59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2450490-5b31-4c9f-991f-069051584b59_0">
											<gml:posList>35.67157498027256 139.73965850432577 58.776 35.67156249639676 139.73964709691126 58.776 35.67156249639676 139.73964709691126 60.349 35.67157498027256 139.73965850432577 60.349 35.67157498027256 139.73965850432577 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_753ab546-5ec6-4c11-9f4b-9f2745ed5058_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a8f8b29-6e4e-4bc0-9990-7cfacc104b4f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67152722879461 139.73973223972234 58.776 35.671521780428385 139.73972699903524 58.776 35.67152611972606 139.73972015623667 58.776 35.6715337600068 139.73972742690538 58.776 35.67152933068314 139.73973441341272 58.776 35.67152722879461 139.73973223972234 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1669c6ff-9c29-43f7-82d4-3424eac98a9d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67152722879461 139.73973223972234 59.571 35.67152933068314 139.73973441341272 59.571 35.671528124321455 139.7397363148049 59.571 35.671520484041224 139.73972904413588 59.571 35.671521780428385 139.73972699903524 59.571 35.67152722879461 139.73973223972234 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07780385-b6ce-4d6c-959a-0232c9ae4db9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07780385-b6ce-4d6c-959a-0232c9ae4db9_0">
											<gml:posList>35.67152611972606 139.73972015623667 58.776 35.67152611972606 139.73972015623667 59.894 35.6715337600068 139.73972742690538 59.894 35.6715337600068 139.73972742690538 58.776 35.67152611972606 139.73972015623667 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-456a0571-4d43-4510-afdc-1aded2524e0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-456a0571-4d43-4510-afdc-1aded2524e0f_0">
											<gml:posList>35.671520484041224 139.73972904413588 59.894 35.67152611972606 139.73972015623667 59.894 35.67152611972606 139.73972015623667 58.776 35.671521780428385 139.73972699903524 58.776 35.671521780428385 139.73972699903524 59.571 35.671520484041224 139.73972904413588 59.571 35.671520484041224 139.73972904413588 59.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d517a936-b320-475b-a1d3-1a0e5da00ede">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d517a936-b320-475b-a1d3-1a0e5da00ede_0">
											<gml:posList>35.671520484041224 139.73972904413588 59.894 35.671528124321455 139.7397363148049 59.894 35.6715337600068 139.73972742690538 59.894 35.67152611972606 139.73972015623667 59.894 35.671520484041224 139.73972904413588 59.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1eef356d-a125-4566-8abe-d43677963d99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1eef356d-a125-4566-8abe-d43677963d99_0">
											<gml:posList>35.67152722879461 139.73973223972234 59.571 35.671521780428385 139.73972699903524 59.571 35.671521780428385 139.73972699903524 58.776 35.67152722879461 139.73973223972234 58.776 35.67152722879461 139.73973223972234 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c81f8c20-2dbc-4504-88ec-73ecdec6604f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c81f8c20-2dbc-4504-88ec-73ecdec6604f_0">
											<gml:posList>35.67152933068314 139.73973441341272 59.571 35.67152933068314 139.73973441341272 58.776 35.6715337600068 139.73972742690538 58.776 35.6715337600068 139.73972742690538 59.894 35.671528124321455 139.7397363148049 59.894 35.671528124321455 139.7397363148049 59.571 35.67152933068314 139.73973441341272 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b23e59b8-0bd6-43a8-8274-1e2955c41a9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b23e59b8-0bd6-43a8-8274-1e2955c41a9f_0">
											<gml:posList>35.671528124321455 139.7397363148049 59.571 35.671528124321455 139.7397363148049 59.894 35.671520484041224 139.73972904413588 59.894 35.671520484041224 139.73972904413588 59.571 35.671528124321455 139.7397363148049 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9da01997-979c-4c89-ae34-ac41158ee311">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9da01997-979c-4c89-ae34-ac41158ee311_0">
											<gml:posList>35.67152933068314 139.73973441341272 58.776 35.67152933068314 139.73973441341272 59.571 35.67152722879461 139.73973223972234 59.571 35.67152722879461 139.73973223972234 58.776 35.67152933068314 139.73973441341272 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2beea0ad-397f-4b1f-b67e-49870a9527f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2beea0ad-397f-4b1f-b67e-49870a9527f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2beea0ad-397f-4b1f-b67e-49870a9527f6">
											<gml:posList>35.671441364664076 139.73965194422638 9.55 35.67149601595905 139.7395722357295 9.55 35.671525334803846 139.73960335233835 9.55 35.67153217964226 139.73959616416445 9.55 35.67162870509522 139.73969712615664 9.55 35.671569330792856 139.73978878139548 9.55 35.671552461574755 139.73977134773293 9.55 35.6715286506531 139.73981046879186 9.55 35.67154299182041 139.73982249266027 9.55 35.67145926494446 139.73995238560934 9.55 35.67140623033329 139.73990870363298 9.55 35.67150012678798 139.73975836299226 9.55 35.67151615215107 139.73973382124507 9.55 35.67144191356543 139.73966232720633 9.55 35.671441364664076 139.73965194422638 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-518c2723-a6fd-4821-bfa2-6a01763651b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-518c2723-a6fd-4821-bfa2-6a01763651b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-518c2723-a6fd-4821-bfa2-6a01763651b0">
											<gml:posList>35.67144631295675 139.73994171881998 33.12 35.67144548786728 139.73993547856162 33.12 35.67141163771739 139.73990760373817 33.12 35.67140623033329 139.73990870363298 33.12 35.67144631295675 139.73994171881998 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44b0f3d3-0aa3-41f2-9a69-204a3a3b3112">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44b0f3d3-0aa3-41f2-9a69-204a3a3b3112">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44b0f3d3-0aa3-41f2-9a69-204a3a3b3112">
											<gml:posList>35.671441364664076 139.73965194422638 59.571 35.67144191356543 139.73966232720633 59.571 35.67144952635268 139.73965742475383 59.571 35.671449407421164 139.73965517142582 59.571 35.671441364664076 139.73965194422638 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-686947b2-0852-412f-b885-a2ad7ce411bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-686947b2-0852-412f-b885-a2ad7ce411bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-686947b2-0852-412f-b885-a2ad7ce411bb">
											<gml:posList>35.67144631295675 139.73994171881998 30.482 35.67145926494446 139.73995238560934 30.482 35.67145874798407 139.7399482879941 30.482 35.67144791541138 139.73993915418703 30.482 35.67144631295675 139.73994171881998 30.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21051869-357f-470a-9909-95ecfa692a3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21051869-357f-470a-9909-95ecfa692a3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21051869-357f-470a-9909-95ecfa692a3c">
											<gml:posList>35.67140623033329 139.73990870363298 33.12 35.67141163771739 139.73990760373817 33.12 35.67150084385073 139.73976476907535 33.12 35.67150012678798 139.73975836299226 33.12 35.67140623033329 139.73990870363298 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f97e95e-c210-4808-98c4-f2ec6882ea55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f97e95e-c210-4808-98c4-f2ec6882ea55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f97e95e-c210-4808-98c4-f2ec6882ea55">
											<gml:posList>35.67149906050602 139.739778137317 32.797 35.67150501115972 139.73976858627117 32.797 35.67150084385073 139.73976476907535 32.797 35.67141163771739 139.73990760373817 32.797 35.67144548786728 139.73993547856162 32.797 35.67150216787508 139.73984472147436 32.797 35.67147841743855 139.7398224575122 32.797 35.67150349850084 139.73978230768284 32.797 35.67149906050602 139.739778137317 32.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f2e9b64c-dd2d-4678-9d4f-94ce2b1477d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2e9b64c-dd2d-4678-9d4f-94ce2b1477d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2e9b64c-dd2d-4678-9d4f-94ce2b1477d2">
											<gml:posList>35.671441364664076 139.73965194422638 59.571 35.671449407421164 139.73965517142582 59.571 35.6714969099344 139.73958588805075 59.571 35.67149601595905 139.7395722357295 59.571 35.671441364664076 139.73965194422638 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21d68377-cd0e-48bd-98d4-f1a77967b78c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21d68377-cd0e-48bd-98d4-f1a77967b78c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21d68377-cd0e-48bd-98d4-f1a77967b78c">
											<gml:posList>35.671507422222525 139.7398438758199 33.12 35.67150216787508 139.73984472147436 33.12 35.67144548786728 139.73993547856162 33.12 35.67144631295675 139.73994171881998 33.12 35.671507422222525 139.7398438758199 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b8fb645-cbb3-41ba-8449-e1684c371c37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b8fb645-cbb3-41ba-8449-e1684c371c37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b8fb645-cbb3-41ba-8449-e1684c371c37">
											<gml:posList>35.67151615215107 139.73973382124507 59.571 35.67152722879461 139.73973223972234 59.571 35.67144952635268 139.73965742475383 59.571 35.67144191356543 139.73966232720633 59.571 35.67151615215107 139.73973382124507 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09d4cdd1-d08a-4163-871a-7afb8dd46f7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09d4cdd1-d08a-4163-871a-7afb8dd46f7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09d4cdd1-d08a-4163-871a-7afb8dd46f7e">
											<gml:posList>35.67148368079099 139.73982160079964 33.12 35.67147841743855 139.7398224575122 33.12 35.67150216787508 139.73984472147436 33.12 35.671507422222525 139.7398438758199 33.12 35.67148368079099 139.73982160079964 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b82da2e-02a4-49f2-85ff-f2737dca62a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b82da2e-02a4-49f2-85ff-f2737dca62a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b82da2e-02a4-49f2-85ff-f2737dca62a7">
											<gml:posList>35.67148368079099 139.73982160079964 33.12 35.67150875283925 139.7397814509779 33.12 35.67150349850084 139.73978230768284 33.12 35.67147841743855 139.7398224575122 33.12 35.67148368079099 139.73982160079964 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-04ea5e14-8f64-4cf1-b27c-0955eaa99642">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04ea5e14-8f64-4cf1-b27c-0955eaa99642">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04ea5e14-8f64-4cf1-b27c-0955eaa99642">
											<gml:posList>35.67152719235215 139.73981294489045 30.093 35.67150306324775 139.73979057090844 30.093 35.67148368079099 139.73982160079964 30.093 35.671507422222525 139.7398438758199 30.093 35.67144791541138 139.73993915418703 30.093 35.67145874798407 139.7399482879941 30.093 35.67153939586053 139.73982315963954 30.093 35.67152719235215 139.73981294489045 30.093</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-903a1866-369b-40cf-bf13-301111eddf99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-903a1866-369b-40cf-bf13-301111eddf99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-903a1866-369b-40cf-bf13-301111eddf99">
											<gml:posList>35.67154299182041 139.73982249266027 30.482 35.67153939586053 139.73982315963954 30.482 35.67145874798407 139.7399482879941 30.482 35.67145926494446 139.73995238560934 30.482 35.67154299182041 139.73982249266027 30.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-15691152-2131-48d0-9060-afdb12bd7310">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15691152-2131-48d0-9060-afdb12bd7310">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15691152-2131-48d0-9060-afdb12bd7310">
											<gml:posList>35.6715043148444 139.7397772806118 33.12 35.67149906050602 139.739778137317 33.12 35.67150349850084 139.73978230768284 33.12 35.67150875283925 139.7397814509779 33.12 35.6715043148444 139.7397772806118 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d010c764-ba74-4fe6-9610-aaca95d9aee1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d010c764-ba74-4fe6-9610-aaca95d9aee1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d010c764-ba74-4fe6-9610-aaca95d9aee1">
											<gml:posList>35.6715043148444 139.7397772806118 33.12 35.671510292504855 139.73976768534814 33.12 35.67150501115972 139.73976858627117 33.12 35.67149906050602 139.739778137317 33.12 35.6715043148444 139.7397772806118 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6bd582fa-81a8-4d9f-b48f-c4587acd6d7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bd582fa-81a8-4d9f-b48f-c4587acd6d7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bd582fa-81a8-4d9f-b48f-c4587acd6d7d">
											<gml:posList>35.67150012678798 139.73975836299226 33.12 35.67150084385073 139.73976476907535 33.12 35.67150501115972 139.73976858627117 33.12 35.671510292504855 139.73976768534814 33.12 35.67150012678798 139.73975836299226 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08779652-b1ec-4ef9-ad24-1667797a4a0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08779652-b1ec-4ef9-ad24-1667797a4a0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08779652-b1ec-4ef9-ad24-1667797a4a0e">
											<gml:posList>35.671525334803846 139.73960335233835 59.571 35.67149601595905 139.7395722357295 59.571 35.6714969099344 139.73958588805075 59.571 35.67152530862817 139.73961604470222 59.571 35.671525334803846 139.73960335233835 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63a1911a-27df-4a32-8988-5a2abf2be581">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63a1911a-27df-4a32-8988-5a2abf2be581">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63a1911a-27df-4a32-8988-5a2abf2be581">
											<gml:posList>35.67151615215107 139.73973382124507 59.349 35.67150012678798 139.73975836299226 59.349 35.67151394567115 139.73977103919512 59.349 35.67152982795054 139.73974795574037 59.349 35.67151615215107 139.73973382124507 59.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-be606f14-79bc-45ec-a677-9ed2898e1e9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be606f14-79bc-45ec-a677-9ed2898e1e9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be606f14-79bc-45ec-a677-9ed2898e1e9c">
											<gml:posList>35.67150467469569 139.73978798416735 30.482 35.67150306324775 139.73979057090844 30.482 35.67152719235215 139.73981294489045 30.482 35.6715286506531 139.73981046879186 30.482 35.67150467469569 139.73978798416735 30.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b0f5e05-42a6-4164-a43d-858ba0460366">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b0f5e05-42a6-4164-a43d-858ba0460366">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b0f5e05-42a6-4164-a43d-858ba0460366">
											<gml:posList>35.67153873306393 139.73979377693806 14.604 35.671510292504855 139.73976768534814 14.604 35.6715043148444 139.7397772806118 14.604 35.67150875283925 139.7397814509779 14.604 35.67150467469569 139.73978798416735 14.604 35.6715286506531 139.73981046879186 14.604 35.67153873306393 139.73979377693806 14.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6265316a-e353-4198-858e-13c47a7c915a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6265316a-e353-4198-858e-13c47a7c915a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6265316a-e353-4198-858e-13c47a7c915a">
											<gml:posList>35.671525334803846 139.73960335233835 59.571 35.67152530862817 139.73961604470222 59.571 35.671532189487834 139.73960881230164 59.571 35.67153217964226 139.73959616416445 59.571 35.671525334803846 139.73960335233835 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d9dd85fb-253c-4ad1-89cf-ef796603f8c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9dd85fb-253c-4ad1-89cf-ef796603f8c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9dd85fb-253c-4ad1-89cf-ef796603f8c4">
											<gml:posList>35.67152982795054 139.73974795574037 59.349 35.67151394567115 139.73977103919512 59.349 35.6715319228476 139.73978753261096 57.757 35.67154696779829 139.73976566523774 57.757 35.67152982795054 139.73974795574037 59.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4faac561-f891-4e0f-8b18-ae24250f26d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4faac561-f891-4e0f-8b18-ae24250f26d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4faac561-f891-4e0f-8b18-ae24250f26d8">
											<gml:posList>35.671449407421164 139.73965517142582 58.776 35.67144952635268 139.73965742475383 58.776 35.67152722879461 139.73973223972234 58.776 35.671551296762416 139.73975712130238 58.776 35.67156839150583 139.73977478667337 58.776 35.67161785355484 139.7396983981233 58.776 35.671532189487834 139.73960881230164 58.776 35.67152530862817 139.73961604470222 58.776 35.6714969099344 139.73958588805075 58.776 35.671449407421164 139.73965517142582 58.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e1330c77-8b73-457a-bab5-46d6cca4a901">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1330c77-8b73-457a-bab5-46d6cca4a901">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1330c77-8b73-457a-bab5-46d6cca4a901">
											<gml:posList>35.671551296762416 139.73975712130238 59.571 35.67152722879461 139.73973223972234 59.571 35.67151615215107 139.73973382124507 59.571 35.671552461574755 139.73977134773293 59.571 35.671551296762416 139.73975712130238 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c1a77808-3d18-4a47-aaaa-0b18a2d146aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1a77808-3d18-4a47-aaaa-0b18a2d146aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1a77808-3d18-4a47-aaaa-0b18a2d146aa">
											<gml:posList>35.6715286506531 139.73981046879186 30.482 35.67152719235215 139.73981294489045 30.482 35.67153939586053 139.73982315963954 30.482 35.67154299182041 139.73982249266027 30.482 35.6715286506531 139.73981046879186 30.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98b84e39-0105-4ebf-8f18-a9be667278bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98b84e39-0105-4ebf-8f18-a9be667278bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98b84e39-0105-4ebf-8f18-a9be667278bf">
											<gml:posList>35.67153873306393 139.73979377693806 57.757 35.671552461574755 139.73977134773293 57.757 35.67154696779829 139.73976566523774 57.757 35.6715319228476 139.73978753261096 57.757 35.67153873306393 139.73979377693806 57.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-173bbb22-2e74-4802-8a22-c276105f9e32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-173bbb22-2e74-4802-8a22-c276105f9e32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-173bbb22-2e74-4802-8a22-c276105f9e32">
											<gml:posList>35.671552461574755 139.73977134773293 59.571 35.671569330792856 139.73978878139548 59.571 35.67156839150583 139.73977478667337 59.571 35.671551296762416 139.73975712130238 59.571 35.671552461574755 139.73977134773293 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-847d8006-5809-447c-8225-9e6d0f0e571f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-847d8006-5809-447c-8225-9e6d0f0e571f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-847d8006-5809-447c-8225-9e6d0f0e571f">
											<gml:posList>35.67153217964226 139.73959616416445 59.571 35.671532189487834 139.73960881230164 59.571 35.67161785355484 139.7396983981233 59.571 35.67162870509522 139.73969712615664 59.571 35.67153217964226 139.73959616416445 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d4e4cd21-5518-4e61-819e-76b9433d0f59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4e4cd21-5518-4e61-819e-76b9433d0f59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4e4cd21-5518-4e61-819e-76b9433d0f59">
											<gml:posList>35.67162870509522 139.73969712615664 59.571 35.67161785355484 139.7396983981233 59.571 35.67156839150583 139.73977478667337 59.571 35.671569330792856 139.73978878139548 59.571 35.67162870509522 139.73969712615664 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b08836c-56ca-4ae8-885a-0a703f0eb13e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b08836c-56ca-4ae8-885a-0a703f0eb13e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b08836c-56ca-4ae8-885a-0a703f0eb13e">
											<gml:posList>35.67150501115972 139.73976858627117 33.12 35.67150501115972 139.73976858627117 32.797 35.67149906050602 139.739778137317 32.797 35.67149906050602 139.739778137317 33.12 35.67150501115972 139.73976858627117 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ea64fec-47f2-435f-b93c-f4f2dc5c60e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ea64fec-47f2-435f-b93c-f4f2dc5c60e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ea64fec-47f2-435f-b93c-f4f2dc5c60e1">
											<gml:posList>35.67150349850084 139.73978230768284 33.12 35.67150349850084 139.73978230768284 32.797 35.67147841743855 139.7398224575122 32.797 35.67147841743855 139.7398224575122 33.12 35.67150349850084 139.73978230768284 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ce38583-e028-4a2b-a11e-2f550b070d49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ce38583-e028-4a2b-a11e-2f550b070d49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ce38583-e028-4a2b-a11e-2f550b070d49">
											<gml:posList>35.67141163771739 139.73990760373817 33.12 35.67141163771739 139.73990760373817 32.797 35.67150084385073 139.73976476907535 32.797 35.67150084385073 139.73976476907535 33.12 35.67141163771739 139.73990760373817 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1657f3b1-3bf8-4ff8-9b27-e6112cf76559">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1657f3b1-3bf8-4ff8-9b27-e6112cf76559">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1657f3b1-3bf8-4ff8-9b27-e6112cf76559">
											<gml:posList>35.67153939586053 139.73982315963954 30.482 35.67153939586053 139.73982315963954 30.093 35.67145874798407 139.7399482879941 30.093 35.67145874798407 139.7399482879941 30.482 35.67153939586053 139.73982315963954 30.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d5688ff-24e6-4c00-9914-29b143f5981a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d5688ff-24e6-4c00-9914-29b143f5981a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d5688ff-24e6-4c00-9914-29b143f5981a">
											<gml:posList>35.67150216787508 139.73984472147436 33.12 35.67150216787508 139.73984472147436 32.797 35.67144548786728 139.73993547856162 32.797 35.67144548786728 139.73993547856162 33.12 35.67150216787508 139.73984472147436 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0673f549-7439-4a07-8887-a4e112e2a46f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0673f549-7439-4a07-8887-a4e112e2a46f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0673f549-7439-4a07-8887-a4e112e2a46f">
											<gml:posList>35.67144548786728 139.73993547856162 33.12 35.67144548786728 139.73993547856162 32.797 35.67141163771739 139.73990760373817 32.797 35.67141163771739 139.73990760373817 33.12 35.67144548786728 139.73993547856162 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cead2dbd-feb3-46df-b897-58368bb112b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cead2dbd-feb3-46df-b897-58368bb112b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cead2dbd-feb3-46df-b897-58368bb112b1">
											<gml:posList>35.67145926494446 139.73995238560934 9.55 35.67145926494446 139.73995238560934 30.482 35.67144631295675 139.73994171881998 30.482 35.67144631295675 139.73994171881998 33.12 35.67140623033329 139.73990870363298 33.12 35.67140623033329 139.73990870363298 9.55 35.67145926494446 139.73995238560934 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c57946ae-3c28-4a77-9346-e2f9ce618689">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c57946ae-3c28-4a77-9346-e2f9ce618689">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c57946ae-3c28-4a77-9346-e2f9ce618689">
											<gml:posList>35.671441364664076 139.73965194422638 9.55 35.67144191356543 139.73966232720633 9.55 35.67144191356543 139.73966232720633 59.571 35.671441364664076 139.73965194422638 59.571 35.671441364664076 139.73965194422638 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d1f6ba3-04bd-4963-83ca-fca4dd0b865b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d1f6ba3-04bd-4963-83ca-fca4dd0b865b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d1f6ba3-04bd-4963-83ca-fca4dd0b865b">
											<gml:posList>35.67144952635268 139.73965742475383 59.571 35.67144952635268 139.73965742475383 58.776 35.671449407421164 139.73965517142582 58.776 35.671449407421164 139.73965517142582 59.571 35.67144952635268 139.73965742475383 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76262ac8-2d96-4d40-b4d3-77f1e8c91fcf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76262ac8-2d96-4d40-b4d3-77f1e8c91fcf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76262ac8-2d96-4d40-b4d3-77f1e8c91fcf">
											<gml:posList>35.67150012678798 139.73975836299226 33.12 35.67150012678798 139.73975836299226 9.55 35.67140623033329 139.73990870363298 9.55 35.67140623033329 139.73990870363298 33.12 35.67150012678798 139.73975836299226 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a70c6a5-5e5e-4d12-899a-892a3d7c4739">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a70c6a5-5e5e-4d12-899a-892a3d7c4739">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a70c6a5-5e5e-4d12-899a-892a3d7c4739">
											<gml:posList>35.67145874798407 139.7399482879941 30.482 35.67145874798407 139.7399482879941 30.093 35.67144791541138 139.73993915418703 30.093 35.67144791541138 139.73993915418703 30.482 35.67145874798407 139.7399482879941 30.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7af0531e-6a36-42ef-8769-a807cd802df3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7af0531e-6a36-42ef-8769-a807cd802df3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7af0531e-6a36-42ef-8769-a807cd802df3">
											<gml:posList>35.67149601595905 139.7395722357295 9.55 35.671441364664076 139.73965194422638 9.55 35.671441364664076 139.73965194422638 59.571 35.67149601595905 139.7395722357295 59.571 35.67149601595905 139.7395722357295 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1fb0093-7c86-4a39-aed3-7258c581073f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1fb0093-7c86-4a39-aed3-7258c581073f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1fb0093-7c86-4a39-aed3-7258c581073f">
											<gml:posList>35.671449407421164 139.73965517142582 59.571 35.671449407421164 139.73965517142582 58.776 35.6714969099344 139.73958588805075 58.776 35.6714969099344 139.73958588805075 59.571 35.671449407421164 139.73965517142582 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14bd2758-482e-46a7-8121-f1dc2b3725cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14bd2758-482e-46a7-8121-f1dc2b3725cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14bd2758-482e-46a7-8121-f1dc2b3725cd">
											<gml:posList>35.67144631295675 139.73994171881998 33.12 35.67144631295675 139.73994171881998 30.482 35.67144791541138 139.73993915418703 30.482 35.67144791541138 139.73993915418703 30.093 35.671507422222525 139.7398438758199 30.093 35.671507422222525 139.7398438758199 33.12 35.67144631295675 139.73994171881998 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31418db5-5e57-4ac6-b935-b9e93a6ed706">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31418db5-5e57-4ac6-b935-b9e93a6ed706">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31418db5-5e57-4ac6-b935-b9e93a6ed706">
											<gml:posList>35.67144191356543 139.73966232720633 59.571 35.67144191356543 139.73966232720633 9.55 35.67151615215107 139.73973382124507 9.55 35.67151615215107 139.73973382124507 59.349 35.67151615215107 139.73973382124507 59.571 35.67144191356543 139.73966232720633 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1a54f18-29e1-4c0e-986a-5eb776b8316a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1a54f18-29e1-4c0e-986a-5eb776b8316a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1a54f18-29e1-4c0e-986a-5eb776b8316a">
											<gml:posList>35.67152722879461 139.73973223972234 59.571 35.67152722879461 139.73973223972234 58.776 35.67144952635268 139.73965742475383 58.776 35.67144952635268 139.73965742475383 59.571 35.67152722879461 139.73973223972234 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c009b9c-178b-4fe8-a620-9378baeebe68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c009b9c-178b-4fe8-a620-9378baeebe68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c009b9c-178b-4fe8-a620-9378baeebe68">
											<gml:posList>35.67147841743855 139.7398224575122 33.12 35.67147841743855 139.7398224575122 32.797 35.67150216787508 139.73984472147436 32.797 35.67150216787508 139.73984472147436 33.12 35.67147841743855 139.7398224575122 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea5213a8-c83d-4c74-b06d-adafa5c515de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea5213a8-c83d-4c74-b06d-adafa5c515de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea5213a8-c83d-4c74-b06d-adafa5c515de">
											<gml:posList>35.67148368079099 139.73982160079964 33.12 35.671507422222525 139.7398438758199 33.12 35.671507422222525 139.7398438758199 30.093 35.67148368079099 139.73982160079964 30.093 35.67148368079099 139.73982160079964 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e02a466-36fc-49eb-aa22-8cb7f0e084ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e02a466-36fc-49eb-aa22-8cb7f0e084ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e02a466-36fc-49eb-aa22-8cb7f0e084ef">
											<gml:posList>35.67148368079099 139.73982160079964 30.093 35.67150306324775 139.73979057090844 30.093 35.67150306324775 139.73979057090844 30.482 35.67150467469569 139.73978798416735 30.482 35.67150467469569 139.73978798416735 14.604 35.67150875283925 139.7397814509779 14.604 35.67150875283925 139.7397814509779 33.12 35.67148368079099 139.73982160079964 33.12 35.67148368079099 139.73982160079964 30.093</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0156f2a9-bdc5-40c6-8d24-8dbc68eca7f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0156f2a9-bdc5-40c6-8d24-8dbc68eca7f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0156f2a9-bdc5-40c6-8d24-8dbc68eca7f4">
											<gml:posList>35.67145926494446 139.73995238560934 9.55 35.67154299182041 139.73982249266027 9.55 35.67154299182041 139.73982249266027 30.482 35.67145926494446 139.73995238560934 30.482 35.67145926494446 139.73995238560934 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e22c3455-d0e6-416a-8051-31efcee6529a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e22c3455-d0e6-416a-8051-31efcee6529a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e22c3455-d0e6-416a-8051-31efcee6529a">
											<gml:posList>35.67149906050602 139.739778137317 33.12 35.67149906050602 139.739778137317 32.797 35.67150349850084 139.73978230768284 32.797 35.67150349850084 139.73978230768284 33.12 35.67149906050602 139.739778137317 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4fdc9d2-7d36-456d-949a-3a6426a4f463">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4fdc9d2-7d36-456d-949a-3a6426a4f463">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4fdc9d2-7d36-456d-949a-3a6426a4f463">
											<gml:posList>35.67150084385073 139.73976476907535 33.12 35.67150084385073 139.73976476907535 32.797 35.67150501115972 139.73976858627117 32.797 35.67150501115972 139.73976858627117 33.12 35.67150084385073 139.73976476907535 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13acda27-e51a-4d41-8008-4cd72911f079">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13acda27-e51a-4d41-8008-4cd72911f079">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13acda27-e51a-4d41-8008-4cd72911f079">
											<gml:posList>35.6715043148444 139.7397772806118 33.12 35.67150875283925 139.7397814509779 33.12 35.67150875283925 139.7397814509779 14.604 35.6715043148444 139.7397772806118 14.604 35.6715043148444 139.7397772806118 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5e95740-387f-4e04-88ff-c7b664e60582">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5e95740-387f-4e04-88ff-c7b664e60582">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5e95740-387f-4e04-88ff-c7b664e60582">
											<gml:posList>35.671510292504855 139.73976768534814 33.12 35.6715043148444 139.7397772806118 33.12 35.6715043148444 139.7397772806118 14.604 35.671510292504855 139.73976768534814 14.604 35.671510292504855 139.73976768534814 33.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4f28bb6-7247-4c31-b6c2-d686f27de3f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4f28bb6-7247-4c31-b6c2-d686f27de3f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4f28bb6-7247-4c31-b6c2-d686f27de3f6">
											<gml:posList>35.67151615215107 139.73973382124507 59.349 35.67151615215107 139.73973382124507 9.55 35.67150012678798 139.73975836299226 9.55 35.67150012678798 139.73975836299226 33.12 35.67150012678798 139.73975836299226 59.349 35.67151615215107 139.73973382124507 59.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d65bbcf-ab84-4add-8edc-904d53737b95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d65bbcf-ab84-4add-8edc-904d53737b95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d65bbcf-ab84-4add-8edc-904d53737b95">
											<gml:posList>35.671525334803846 139.73960335233835 9.55 35.67149601595905 139.7395722357295 9.55 35.67149601595905 139.7395722357295 59.571 35.671525334803846 139.73960335233835 59.571 35.671525334803846 139.73960335233835 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e26d4e78-5f67-4f60-baf1-c76fcc33f83a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e26d4e78-5f67-4f60-baf1-c76fcc33f83a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e26d4e78-5f67-4f60-baf1-c76fcc33f83a">
											<gml:posList>35.6714969099344 139.73958588805075 59.571 35.6714969099344 139.73958588805075 58.776 35.67152530862817 139.73961604470222 58.776 35.67152530862817 139.73961604470222 59.571 35.6714969099344 139.73958588805075 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48c80df4-c222-4a40-8107-d52db0bed8d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48c80df4-c222-4a40-8107-d52db0bed8d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48c80df4-c222-4a40-8107-d52db0bed8d8">
											<gml:posList>35.67150306324775 139.73979057090844 30.482 35.67150306324775 139.73979057090844 30.093 35.67152719235215 139.73981294489045 30.093 35.67152719235215 139.73981294489045 30.482 35.67150306324775 139.73979057090844 30.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a574f29-f5bb-48a3-8f76-55f1ac9c126f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a574f29-f5bb-48a3-8f76-55f1ac9c126f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a574f29-f5bb-48a3-8f76-55f1ac9c126f">
											<gml:posList>35.67150467469569 139.73978798416735 30.482 35.6715286506531 139.73981046879186 30.482 35.6715286506531 139.73981046879186 14.604 35.67150467469569 139.73978798416735 14.604 35.67150467469569 139.73978798416735 30.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6dd9ed0-241d-460e-a977-e4756ae78752">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6dd9ed0-241d-460e-a977-e4756ae78752">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6dd9ed0-241d-460e-a977-e4756ae78752">
											<gml:posList>35.67150012678798 139.73975836299226 59.349 35.67150012678798 139.73975836299226 33.12 35.671510292504855 139.73976768534814 33.12 35.671510292504855 139.73976768534814 14.604 35.67153873306393 139.73979377693806 14.604 35.67153873306393 139.73979377693806 57.757 35.6715319228476 139.73978753261096 57.757 35.67151394567115 139.73977103919512 59.349 35.67150012678798 139.73975836299226 59.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10245ef1-c78e-4f07-8810-1e10ac287d7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10245ef1-c78e-4f07-8810-1e10ac287d7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10245ef1-c78e-4f07-8810-1e10ac287d7c">
											<gml:posList>35.67152530862817 139.73961604470222 59.571 35.67152530862817 139.73961604470222 58.776 35.671532189487834 139.73960881230164 58.776 35.671532189487834 139.73960881230164 59.571 35.67152530862817 139.73961604470222 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff5a22ad-21e7-48f0-b1b9-bc17c7869777">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff5a22ad-21e7-48f0-b1b9-bc17c7869777">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff5a22ad-21e7-48f0-b1b9-bc17c7869777">
											<gml:posList>35.67153217964226 139.73959616416445 9.55 35.671525334803846 139.73960335233835 9.55 35.671525334803846 139.73960335233835 59.571 35.67153217964226 139.73959616416445 59.571 35.67153217964226 139.73959616416445 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f282f9c8-4831-4a00-bf65-6940990802e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f282f9c8-4831-4a00-bf65-6940990802e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f282f9c8-4831-4a00-bf65-6940990802e6">
											<gml:posList>35.67152719235215 139.73981294489045 30.482 35.67152719235215 139.73981294489045 30.093 35.67153939586053 139.73982315963954 30.093 35.67153939586053 139.73982315963954 30.482 35.67152719235215 139.73981294489045 30.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f621825-03d0-43f5-8e86-a4b5c5d94975">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f621825-03d0-43f5-8e86-a4b5c5d94975">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f621825-03d0-43f5-8e86-a4b5c5d94975">
											<gml:posList>35.671552461574755 139.73977134773293 59.571 35.67151615215107 139.73973382124507 59.571 35.67151615215107 139.73973382124507 59.349 35.67152982795054 139.73974795574037 59.349 35.67154696779829 139.73976566523774 57.757 35.671552461574755 139.73977134773293 57.757 35.671552461574755 139.73977134773293 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04278a87-5c6e-43b8-a852-ba05333a5030">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04278a87-5c6e-43b8-a852-ba05333a5030">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04278a87-5c6e-43b8-a852-ba05333a5030">
											<gml:posList>35.67154299182041 139.73982249266027 9.55 35.6715286506531 139.73981046879186 9.55 35.6715286506531 139.73981046879186 14.604 35.6715286506531 139.73981046879186 30.482 35.67154299182041 139.73982249266027 30.482 35.67154299182041 139.73982249266027 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94f70121-4742-4e32-924e-9678bc8da072">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94f70121-4742-4e32-924e-9678bc8da072">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94f70121-4742-4e32-924e-9678bc8da072">
											<gml:posList>35.671551296762416 139.73975712130238 59.571 35.671551296762416 139.73975712130238 58.776 35.67152722879461 139.73973223972234 58.776 35.67152722879461 139.73973223972234 59.571 35.671551296762416 139.73975712130238 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e60c96a2-3c6b-465e-9ee8-dd41adaeafe8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e60c96a2-3c6b-465e-9ee8-dd41adaeafe8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e60c96a2-3c6b-465e-9ee8-dd41adaeafe8">
											<gml:posList>35.67153873306393 139.73979377693806 14.604 35.6715286506531 139.73981046879186 14.604 35.6715286506531 139.73981046879186 9.55 35.671552461574755 139.73977134773293 9.55 35.671552461574755 139.73977134773293 57.757 35.67153873306393 139.73979377693806 57.757 35.67153873306393 139.73979377693806 14.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4da6c238-29d3-40c5-b941-f0dc43ac1a56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4da6c238-29d3-40c5-b941-f0dc43ac1a56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4da6c238-29d3-40c5-b941-f0dc43ac1a56">
											<gml:posList>35.67156839150583 139.73977478667337 59.571 35.67156839150583 139.73977478667337 58.776 35.671551296762416 139.73975712130238 58.776 35.671551296762416 139.73975712130238 59.571 35.67156839150583 139.73977478667337 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f38711cb-faae-4b4d-9758-9fe6ea098965">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f38711cb-faae-4b4d-9758-9fe6ea098965">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f38711cb-faae-4b4d-9758-9fe6ea098965">
											<gml:posList>35.671569330792856 139.73978878139548 9.55 35.671569330792856 139.73978878139548 59.571 35.671552461574755 139.73977134773293 59.571 35.671552461574755 139.73977134773293 57.757 35.671552461574755 139.73977134773293 9.55 35.671569330792856 139.73978878139548 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-460fe29a-536c-4c56-967e-252907decafd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-460fe29a-536c-4c56-967e-252907decafd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-460fe29a-536c-4c56-967e-252907decafd">
											<gml:posList>35.671532189487834 139.73960881230164 59.571 35.671532189487834 139.73960881230164 58.776 35.67161785355484 139.7396983981233 58.776 35.67161785355484 139.7396983981233 59.571 35.671532189487834 139.73960881230164 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a13d2696-51b3-47da-8a2b-0144f00ee094">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a13d2696-51b3-47da-8a2b-0144f00ee094">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a13d2696-51b3-47da-8a2b-0144f00ee094">
											<gml:posList>35.67162870509522 139.73969712615664 9.55 35.67153217964226 139.73959616416445 9.55 35.67153217964226 139.73959616416445 59.571 35.67162870509522 139.73969712615664 59.571 35.67162870509522 139.73969712615664 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94fb0e2d-cc4c-492a-8705-d6240b0de627">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94fb0e2d-cc4c-492a-8705-d6240b0de627">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94fb0e2d-cc4c-492a-8705-d6240b0de627">
											<gml:posList>35.67161785355484 139.7396983981233 59.571 35.67161785355484 139.7396983981233 58.776 35.67156839150583 139.73977478667337 58.776 35.67156839150583 139.73977478667337 59.571 35.67161785355484 139.7396983981233 59.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a62fdec-359c-4d3e-9550-212dbf54a3f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a62fdec-359c-4d3e-9550-212dbf54a3f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a62fdec-359c-4d3e-9550-212dbf54a3f4">
											<gml:posList>35.67162870509522 139.73969712615664 9.55 35.67162870509522 139.73969712615664 59.571 35.671569330792856 139.73978878139548 59.571 35.671569330792856 139.73978878139548 9.55 35.67162870509522 139.73969712615664 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6636</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">211.50915</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>