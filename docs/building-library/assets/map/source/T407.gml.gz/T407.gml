<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_7582f44d-8f46-4c12-a459-e9ab42fc0889">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>環状第二号線新橋・虎ノ門地区</gen:value>
			</gen:stringAttribute>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668523957054475 139.7477965561029 0 35.6685418402947 139.74778385620968 0 35.668530854059235 139.7477606050439 0 35.66851297082146 139.74777330494052 0 35.668523957054475 139.7477965561029 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668523957054475 139.7477965561029 5.365 35.66851297082146 139.74777330494052 5.365 35.668530854059235 139.7477606050439 5.365 35.6685418402947 139.74778385620968 5.365 35.668523957054475 139.7477965561029 5.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668523957054475 139.7477965561029 5.365 35.6685418402947 139.74778385620968 5.365 35.6685418402947 139.74778385620968 8.365 35.668523957054475 139.7477965561029 8.365 35.668523957054475 139.7477965561029 5.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6685418402947 139.74778385620968 5.365 35.668530854059235 139.7477606050439 5.365 35.668530854059235 139.7477606050439 8.365 35.6685418402947 139.74778385620968 8.365 35.6685418402947 139.74778385620968 5.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668530854059235 139.7477606050439 5.365 35.66851297082146 139.74777330494052 5.365 35.66851297082146 139.74777330494052 8.365 35.668530854059235 139.7477606050439 8.365 35.668530854059235 139.7477606050439 5.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66851297082146 139.74777330494052 5.365 35.668523957054475 139.7477965561029 5.365 35.668523957054475 139.7477965561029 8.365 35.66851297082146 139.74777330494052 8.365 35.66851297082146 139.74777330494052 5.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668523957054475 139.7477965561029 8.365 35.6685418402947 139.74778385620968 8.365 35.668530854059235 139.7477606050439 8.365 35.66851297082146 139.74777330494052 8.365 35.668523957054475 139.7477965561029 8.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f6a3283f-8d59-4023-9983-3c8bebe83352"/>
							<gml:surfaceMember xlink:href="#poly-0be2cb92-f6cc-43a8-8c70-f1f3fa813226"/>
							<gml:surfaceMember xlink:href="#poly-bae43dae-bf09-4957-8935-2f413a978447"/>
							<gml:surfaceMember xlink:href="#poly-90839309-79a1-4ff6-816b-af6576c23a16"/>
							<gml:surfaceMember xlink:href="#poly-44b06ce4-2264-4065-8d4c-91ade4da5ee3"/>
							<gml:surfaceMember xlink:href="#poly-5be080e5-a7d4-4a72-8ea3-4d5992a0b6c2"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f6a3283f-8d59-4023-9983-3c8bebe83352">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6a3283f-8d59-4023-9983-3c8bebe83352">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6a3283f-8d59-4023-9983-3c8bebe83352">
											<gml:posList>35.66852395705446 139.74779655610288 5.365 35.668512970821446 139.74777330494052 5.365 35.668530854059235 139.74776060504388 5.365 35.66854184029467 139.74778385620968 5.365 35.66852395705446 139.74779655610288 5.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0be2cb92-f6cc-43a8-8c70-f1f3fa813226">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0be2cb92-f6cc-43a8-8c70-f1f3fa813226">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0be2cb92-f6cc-43a8-8c70-f1f3fa813226">
											<gml:posList>35.668512970821446 139.74777330494052 7.755 35.66852395705446 139.74779655610288 7.755 35.66854184029467 139.74778385620968 7.755 35.668530854059235 139.74776060504388 7.755 35.668512970821446 139.74777330494052 7.755</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bae43dae-bf09-4957-8935-2f413a978447">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bae43dae-bf09-4957-8935-2f413a978447">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bae43dae-bf09-4957-8935-2f413a978447">
											<gml:posList>35.668530854059235 139.74776060504388 5.365 35.668512970821446 139.74777330494052 5.365 35.668512970821446 139.74777330494052 7.755 35.668530854059235 139.74776060504388 7.755 35.668530854059235 139.74776060504388 5.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90839309-79a1-4ff6-816b-af6576c23a16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90839309-79a1-4ff6-816b-af6576c23a16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90839309-79a1-4ff6-816b-af6576c23a16">
											<gml:posList>35.66854184029467 139.74778385620968 5.365 35.668530854059235 139.74776060504388 5.365 35.668530854059235 139.74776060504388 7.755 35.66854184029467 139.74778385620968 7.755 35.66854184029467 139.74778385620968 5.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44b06ce4-2264-4065-8d4c-91ade4da5ee3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44b06ce4-2264-4065-8d4c-91ade4da5ee3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44b06ce4-2264-4065-8d4c-91ade4da5ee3">
											<gml:posList>35.668512970821446 139.74777330494052 5.365 35.66852395705446 139.74779655610288 5.365 35.66852395705446 139.74779655610288 7.755 35.668512970821446 139.74777330494052 7.755 35.668512970821446 139.74777330494052 5.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5be080e5-a7d4-4a72-8ea3-4d5992a0b6c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5be080e5-a7d4-4a72-8ea3-4d5992a0b6c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5be080e5-a7d4-4a72-8ea3-4d5992a0b6c2">
											<gml:posList>35.66852395705446 139.74779655610288 5.365 35.66854184029467 139.74778385620968 5.365 35.66854184029467 139.74778385620968 7.755 35.66852395705446 139.74779655610288 7.755 35.66852395705446 139.74779655610288 5.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5090</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.43</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>