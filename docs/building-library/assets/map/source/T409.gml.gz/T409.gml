<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_761d4090-cd2e-4074-b3b9-211197a1d110">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">4.1</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669236643715436 139.73976985258616 0 35.669232414201666 139.73976718436512 0 35.66923883811214 139.73975187801736 0 35.669198391717195 139.7397263976943 0 35.669200209114784 139.73972205445656 0 35.6691844093151 139.7397120982794 0 35.66922430223787 139.73961701105404 0 35.66921613178886 139.7396118620755 0 35.66915034528904 139.7397686277572 0 35.66916013899142 139.7397747910938 0 35.669175254055524 139.73973875214645 0 35.669190639015696 139.73974844370568 0 35.66917584782495 139.73978368696152 0 35.6691902858771 139.73979278314496 0 35.66919609799045 139.73977893560584 0 35.6692282566948 139.7397991897703 0 35.66923733474909 139.73977756195893 0 35.669238007608946 139.73978508356933 0 35.66925350960987 139.73978299986143 0 35.66925150000791 139.7397603908315 0 35.66929951116356 139.7397539611955 0 35.669297819895725 139.73973503013644 0 35.66924359892901 139.73974229548975 0 35.66924529023863 139.73976128176668 0 35.66923599805029 139.73976252977417 0 35.669236643715436 139.73976985258616 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669236643715436 139.73976985258616 10.45 35.66923599805029 139.73976252977417 10.45 35.66924529023863 139.73976128176668 10.45 35.66924359892901 139.73974229548975 10.45 35.669297819895725 139.73973503013644 10.45 35.66929951116356 139.7397539611955 10.45 35.66925150000791 139.7397603908315 10.45 35.66925350960987 139.73978299986143 10.45 35.669238007608946 139.73978508356933 10.45 35.66923733474909 139.73977756195893 10.45 35.6692282566948 139.7397991897703 10.45 35.66919609799045 139.73977893560584 10.45 35.6691902858771 139.73979278314496 10.45 35.66917584782495 139.73978368696152 10.45 35.669190639015696 139.73974844370568 10.45 35.669175254055524 139.73973875214645 10.45 35.66916013899142 139.7397747910938 10.45 35.66915034528904 139.7397686277572 10.45 35.66921613178886 139.7396118620755 10.45 35.66922430223787 139.73961701105404 10.45 35.6691844093151 139.7397120982794 10.45 35.669200209114784 139.73972205445656 10.45 35.669198391717195 139.7397263976943 10.45 35.66923883811214 139.73975187801736 10.45 35.669232414201666 139.73976718436512 10.45 35.669236643715436 139.73976985258616 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669236643715436 139.73976985258616 10.45 35.669232414201666 139.73976718436512 10.45 35.669232414201666 139.73976718436512 14.5 35.669236643715436 139.73976985258616 14.5 35.669236643715436 139.73976985258616 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669232414201666 139.73976718436512 10.45 35.66923883811214 139.73975187801736 10.45 35.66923883811214 139.73975187801736 14.5 35.669232414201666 139.73976718436512 14.5 35.669232414201666 139.73976718436512 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923883811214 139.73975187801736 10.45 35.669198391717195 139.7397263976943 10.45 35.669198391717195 139.7397263976943 14.5 35.66923883811214 139.73975187801736 14.5 35.66923883811214 139.73975187801736 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669198391717195 139.7397263976943 10.45 35.669200209114784 139.73972205445656 10.45 35.669200209114784 139.73972205445656 14.5 35.669198391717195 139.7397263976943 14.5 35.669198391717195 139.7397263976943 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669200209114784 139.73972205445656 10.45 35.6691844093151 139.7397120982794 10.45 35.6691844093151 139.7397120982794 14.5 35.669200209114784 139.73972205445656 14.5 35.669200209114784 139.73972205445656 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6691844093151 139.7397120982794 10.45 35.66922430223787 139.73961701105404 10.45 35.66922430223787 139.73961701105404 14.5 35.6691844093151 139.7397120982794 14.5 35.6691844093151 139.7397120982794 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922430223787 139.73961701105404 10.45 35.66921613178886 139.7396118620755 10.45 35.66921613178886 139.7396118620755 14.5 35.66922430223787 139.73961701105404 14.5 35.66922430223787 139.73961701105404 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66921613178886 139.7396118620755 10.45 35.66915034528904 139.7397686277572 10.45 35.66915034528904 139.7397686277572 14.5 35.66921613178886 139.7396118620755 14.5 35.66921613178886 139.7396118620755 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66915034528904 139.7397686277572 10.45 35.66916013899142 139.7397747910938 10.45 35.66916013899142 139.7397747910938 14.5 35.66915034528904 139.7397686277572 14.5 35.66915034528904 139.7397686277572 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66916013899142 139.7397747910938 10.45 35.669175254055524 139.73973875214645 10.45 35.669175254055524 139.73973875214645 14.5 35.66916013899142 139.7397747910938 14.5 35.66916013899142 139.7397747910938 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669175254055524 139.73973875214645 10.45 35.669190639015696 139.73974844370568 10.45 35.669190639015696 139.73974844370568 14.5 35.669175254055524 139.73973875214645 14.5 35.669175254055524 139.73973875214645 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669190639015696 139.73974844370568 10.45 35.66917584782495 139.73978368696152 10.45 35.66917584782495 139.73978368696152 14.5 35.669190639015696 139.73974844370568 14.5 35.669190639015696 139.73974844370568 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66917584782495 139.73978368696152 10.45 35.6691902858771 139.73979278314496 10.45 35.6691902858771 139.73979278314496 14.5 35.66917584782495 139.73978368696152 14.5 35.66917584782495 139.73978368696152 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6691902858771 139.73979278314496 10.45 35.66919609799045 139.73977893560584 10.45 35.66919609799045 139.73977893560584 14.5 35.6691902858771 139.73979278314496 14.5 35.6691902858771 139.73979278314496 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66919609799045 139.73977893560584 10.45 35.6692282566948 139.7397991897703 10.45 35.6692282566948 139.7397991897703 14.5 35.66919609799045 139.73977893560584 14.5 35.66919609799045 139.73977893560584 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6692282566948 139.7397991897703 10.45 35.66923733474909 139.73977756195893 10.45 35.66923733474909 139.73977756195893 14.5 35.6692282566948 139.7397991897703 14.5 35.6692282566948 139.7397991897703 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923733474909 139.73977756195893 10.45 35.669238007608946 139.73978508356933 10.45 35.669238007608946 139.73978508356933 14.5 35.66923733474909 139.73977756195893 14.5 35.66923733474909 139.73977756195893 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669238007608946 139.73978508356933 10.45 35.66925350960987 139.73978299986143 10.45 35.66925350960987 139.73978299986143 14.5 35.669238007608946 139.73978508356933 14.5 35.669238007608946 139.73978508356933 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925350960987 139.73978299986143 10.45 35.66925150000791 139.7397603908315 10.45 35.66925150000791 139.7397603908315 14.5 35.66925350960987 139.73978299986143 14.5 35.66925350960987 139.73978299986143 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925150000791 139.7397603908315 10.45 35.66929951116356 139.7397539611955 10.45 35.66929951116356 139.7397539611955 14.5 35.66925150000791 139.7397603908315 14.5 35.66925150000791 139.7397603908315 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66929951116356 139.7397539611955 10.45 35.669297819895725 139.73973503013644 10.45 35.669297819895725 139.73973503013644 14.5 35.66929951116356 139.7397539611955 14.5 35.66929951116356 139.7397539611955 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669297819895725 139.73973503013644 10.45 35.66924359892901 139.73974229548975 10.45 35.66924359892901 139.73974229548975 14.5 35.669297819895725 139.73973503013644 14.5 35.669297819895725 139.73973503013644 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924359892901 139.73974229548975 10.45 35.66924529023863 139.73976128176668 10.45 35.66924529023863 139.73976128176668 14.5 35.66924359892901 139.73974229548975 14.5 35.66924359892901 139.73974229548975 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924529023863 139.73976128176668 10.45 35.66923599805029 139.73976252977417 10.45 35.66923599805029 139.73976252977417 14.5 35.66924529023863 139.73976128176668 14.5 35.66924529023863 139.73976128176668 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923599805029 139.73976252977417 10.45 35.669236643715436 139.73976985258616 10.45 35.669236643715436 139.73976985258616 14.5 35.66923599805029 139.73976252977417 14.5 35.66923599805029 139.73976252977417 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669236643715436 139.73976985258616 14.5 35.669232414201666 139.73976718436512 14.5 35.66923883811214 139.73975187801736 14.5 35.669198391717195 139.7397263976943 14.5 35.669200209114784 139.73972205445656 14.5 35.6691844093151 139.7397120982794 14.5 35.66922430223787 139.73961701105404 14.5 35.66921613178886 139.7396118620755 14.5 35.66915034528904 139.7397686277572 14.5 35.66916013899142 139.7397747910938 14.5 35.669175254055524 139.73973875214645 14.5 35.669190639015696 139.73974844370568 14.5 35.66917584782495 139.73978368696152 14.5 35.6691902858771 139.73979278314496 14.5 35.66919609799045 139.73977893560584 14.5 35.6692282566948 139.7397991897703 14.5 35.66923733474909 139.73977756195893 14.5 35.669238007608946 139.73978508356933 14.5 35.66925350960987 139.73978299986143 14.5 35.66925150000791 139.7397603908315 14.5 35.66929951116356 139.7397539611955 14.5 35.669297819895725 139.73973503013644 14.5 35.66924359892901 139.73974229548975 14.5 35.66924529023863 139.73976128176668 14.5 35.66923599805029 139.73976252977417 14.5 35.669236643715436 139.73976985258616 14.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6ec31883-289c-4518-9203-f69e78f5f626"/>
							<gml:surfaceMember xlink:href="#poly-03ba96d1-66be-427d-8aad-5ef9999f6440"/>
							<gml:surfaceMember xlink:href="#poly-277c7070-cb43-471c-a351-0f83c639f362"/>
							<gml:surfaceMember xlink:href="#poly-48683c10-01b7-46cd-b98a-b98d19fe99b2"/>
							<gml:surfaceMember xlink:href="#poly-825966c6-7210-4ae3-a6c7-cb9e62288f3e"/>
							<gml:surfaceMember xlink:href="#poly-97e08292-866f-4bdd-987b-db7bc9f563a7"/>
							<gml:surfaceMember xlink:href="#poly-afa38683-4d44-4ce0-8b42-a97185cb6caa"/>
							<gml:surfaceMember xlink:href="#poly-da08cff9-ba0f-4acf-a5fc-1463e3c9c989"/>
							<gml:surfaceMember xlink:href="#poly-de696ec1-a9aa-4aa7-910a-058c12f02b22"/>
							<gml:surfaceMember xlink:href="#poly-d5ccbc53-fe63-487d-ac59-45355390141c"/>
							<gml:surfaceMember xlink:href="#poly-2187a7f8-1faa-4e9f-81bb-1423c2e3a629"/>
							<gml:surfaceMember xlink:href="#poly-94f545ad-fcdd-46d9-9504-c7b271eb881f"/>
							<gml:surfaceMember xlink:href="#poly-31782399-0499-4377-88f5-f154d60e2a03"/>
							<gml:surfaceMember xlink:href="#poly-65c7168c-7d03-4717-a470-6d36ed3d7529"/>
							<gml:surfaceMember xlink:href="#poly-2491f467-e546-43c0-965d-4158cf366269"/>
							<gml:surfaceMember xlink:href="#poly-28c04f81-c756-4a7e-abf3-15c4c1e9f9b1"/>
							<gml:surfaceMember xlink:href="#poly-2bfeffb8-29be-41ad-b409-f662bea9212d"/>
							<gml:surfaceMember xlink:href="#poly-4fbbc83e-5511-48a0-909a-b53e1a62d0b8"/>
							<gml:surfaceMember xlink:href="#poly-fe0ce823-a4c9-4285-a111-a3450ab8a8cc"/>
							<gml:surfaceMember xlink:href="#poly-b4864035-62c2-49d1-ae9c-b1ad68202ee8"/>
							<gml:surfaceMember xlink:href="#poly-32600b7d-fc11-4cc8-88f0-4cc354fdeee1"/>
							<gml:surfaceMember xlink:href="#poly-bcbdf8bf-910e-4f8b-b03a-99d4306e9713"/>
							<gml:surfaceMember xlink:href="#poly-3df8352b-ad6b-4349-b61d-a2970f6c7fcb"/>
							<gml:surfaceMember xlink:href="#poly-96774702-d0e2-439c-9e34-363e7edb01ad"/>
							<gml:surfaceMember xlink:href="#poly-9ef419e8-1991-44e7-8172-cae7c6246fa9"/>
							<gml:surfaceMember xlink:href="#poly-009282de-45c5-4f29-a03d-9bd7f7600523"/>
							<gml:surfaceMember xlink:href="#poly-38ea246f-72c8-47da-b137-cb645fd3aac4"/>
							<gml:surfaceMember xlink:href="#poly-a99a6702-213b-4e59-a609-951ef08b7bba"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6ec31883-289c-4518-9203-f69e78f5f626">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ec31883-289c-4518-9203-f69e78f5f626">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ec31883-289c-4518-9203-f69e78f5f626">
											<gml:posList>35.66925150000789 139.73976039083146 10.45 35.669253509609845 139.73978299986143 10.45 35.66923800760894 139.73978508356933 10.45 35.66923733474909 139.73977756195893 10.45 35.669228256694794 139.7397991897703 10.45 35.66919609799044 139.73977893560584 10.45 35.66919028587708 139.73979278314496 10.45 35.66917584782494 139.73978368696152 10.45 35.6691906390157 139.73974844370568 10.45 35.66917525405553 139.73973875214645 10.45 35.66916013899142 139.7397747910938 10.45 35.66915034528903 139.7397686277572 10.45 35.66921613178886 139.7396118620755 10.45 35.669224302237886 139.73961701105404 10.45 35.66918440931506 139.73971209827937 10.45 35.669200209114756 139.73972205445656 10.45 35.66919839171718 139.7397263976943 10.45 35.66923883811209 139.73975187801736 10.45 35.66923241420166 139.7397671843651 10.45 35.66923664371542 139.73976985258616 10.45 35.66923599805029 139.73976252977414 10.45 35.66924529023861 139.73976128176668 10.45 35.66924359892901 139.73974229548975 10.45 35.66929781989571 139.73973503013642 10.45 35.669299511163544 139.73975396119553 10.45 35.66925150000789 139.73976039083146 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03ba96d1-66be-427d-8aad-5ef9999f6440">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03ba96d1-66be-427d-8aad-5ef9999f6440">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03ba96d1-66be-427d-8aad-5ef9999f6440">
											<gml:posList>35.66919839171718 139.7397263976943 14.589 35.669200209114756 139.73972205445656 14.589 35.66918440931506 139.73971209827937 14.589 35.669224302237886 139.73961701105404 14.589 35.66921613178886 139.7396118620755 14.589 35.66915034528903 139.7397686277572 14.589 35.66916013899142 139.7397747910938 14.589 35.66917525405553 139.73973875214645 14.589 35.6691906390157 139.73974844370568 14.589 35.66917584782494 139.73978368696152 14.589 35.66919028587708 139.73979278314496 14.589 35.66919609799044 139.73977893560584 14.589 35.669228256694794 139.7397991897703 14.589 35.66923974595572 139.73977180412626 14.589 35.66923241420166 139.7397671843651 14.589 35.66923883811209 139.73975187801736 14.589 35.66919839171718 139.7397263976943 14.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-277c7070-cb43-471c-a351-0f83c639f362">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-277c7070-cb43-471c-a351-0f83c639f362">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-277c7070-cb43-471c-a351-0f83c639f362">
											<gml:posList>35.66924529023861 139.73976128176668 13.825 35.66923599805029 139.73976252977414 13.825 35.66923664371542 139.73976985258616 13.825 35.66923974595572 139.73977180412626 13.825 35.66923733474909 139.73977756195893 13.825 35.66923800760894 139.73978508356933 13.825 35.669253509609845 139.73978299986143 13.825 35.66925150000789 139.73976039083146 13.825 35.669299511163544 139.73975396119553 13.825 35.66929781989571 139.73973503013642 13.825 35.66924359892901 139.73974229548975 13.825 35.66924529023861 139.73976128176668 13.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48683c10-01b7-46cd-b98a-b98d19fe99b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48683c10-01b7-46cd-b98a-b98d19fe99b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48683c10-01b7-46cd-b98a-b98d19fe99b2">
											<gml:posList>35.66917584782494 139.73978368696152 10.45 35.66919028587708 139.73979278314496 10.45 35.66919028587708 139.73979278314496 14.589 35.66917584782494 139.73978368696152 14.589 35.66917584782494 139.73978368696152 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-825966c6-7210-4ae3-a6c7-cb9e62288f3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-825966c6-7210-4ae3-a6c7-cb9e62288f3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-825966c6-7210-4ae3-a6c7-cb9e62288f3e">
											<gml:posList>35.6691906390157 139.73974844370568 10.45 35.66917584782494 139.73978368696152 10.45 35.66917584782494 139.73978368696152 14.589 35.6691906390157 139.73974844370568 14.589 35.6691906390157 139.73974844370568 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97e08292-866f-4bdd-987b-db7bc9f563a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97e08292-866f-4bdd-987b-db7bc9f563a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97e08292-866f-4bdd-987b-db7bc9f563a7">
											<gml:posList>35.66923599805029 139.73976252977414 10.45 35.66923664371542 139.73976985258616 10.45 35.66923664371542 139.73976985258616 13.825 35.66923599805029 139.73976252977414 13.825 35.66923599805029 139.73976252977414 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afa38683-4d44-4ce0-8b42-a97185cb6caa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afa38683-4d44-4ce0-8b42-a97185cb6caa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afa38683-4d44-4ce0-8b42-a97185cb6caa">
											<gml:posList>35.669224302237886 139.73961701105404 10.45 35.66921613178886 139.7396118620755 10.45 35.66921613178886 139.7396118620755 14.589 35.669224302237886 139.73961701105404 14.589 35.669224302237886 139.73961701105404 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da08cff9-ba0f-4acf-a5fc-1463e3c9c989">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da08cff9-ba0f-4acf-a5fc-1463e3c9c989">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da08cff9-ba0f-4acf-a5fc-1463e3c9c989">
											<gml:posList>35.66918440931506 139.73971209827937 10.45 35.669224302237886 139.73961701105404 10.45 35.669224302237886 139.73961701105404 14.589 35.66918440931506 139.73971209827937 14.589 35.66918440931506 139.73971209827937 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de696ec1-a9aa-4aa7-910a-058c12f02b22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de696ec1-a9aa-4aa7-910a-058c12f02b22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de696ec1-a9aa-4aa7-910a-058c12f02b22">
											<gml:posList>35.66921613178886 139.7396118620755 10.45 35.66915034528903 139.7397686277572 10.45 35.66915034528903 139.7397686277572 14.589 35.66921613178886 139.7396118620755 14.589 35.66921613178886 139.7396118620755 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5ccbc53-fe63-487d-ac59-45355390141c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5ccbc53-fe63-487d-ac59-45355390141c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5ccbc53-fe63-487d-ac59-45355390141c">
											<gml:posList>35.669200209114756 139.73972205445656 10.45 35.66918440931506 139.73971209827937 10.45 35.66918440931506 139.73971209827937 14.589 35.669200209114756 139.73972205445656 14.589 35.669200209114756 139.73972205445656 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2187a7f8-1faa-4e9f-81bb-1423c2e3a629">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2187a7f8-1faa-4e9f-81bb-1423c2e3a629">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2187a7f8-1faa-4e9f-81bb-1423c2e3a629">
											<gml:posList>35.66919839171718 139.7397263976943 10.45 35.669200209114756 139.73972205445656 10.45 35.669200209114756 139.73972205445656 14.589 35.66919839171718 139.7397263976943 14.589 35.66919839171718 139.7397263976943 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94f545ad-fcdd-46d9-9504-c7b271eb881f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94f545ad-fcdd-46d9-9504-c7b271eb881f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94f545ad-fcdd-46d9-9504-c7b271eb881f">
											<gml:posList>35.66929781989571 139.73973503013642 10.45 35.66924359892901 139.73974229548975 10.45 35.66924359892901 139.73974229548975 13.825 35.66929781989571 139.73973503013642 13.825 35.66929781989571 139.73973503013642 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31782399-0499-4377-88f5-f154d60e2a03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31782399-0499-4377-88f5-f154d60e2a03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31782399-0499-4377-88f5-f154d60e2a03">
											<gml:posList>35.66923883811209 139.73975187801736 10.45 35.66919839171718 139.7397263976943 10.45 35.66919839171718 139.7397263976943 14.589 35.66923883811209 139.73975187801736 14.589 35.66923883811209 139.73975187801736 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65c7168c-7d03-4717-a470-6d36ed3d7529">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65c7168c-7d03-4717-a470-6d36ed3d7529">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65c7168c-7d03-4717-a470-6d36ed3d7529">
											<gml:posList>35.66917525405553 139.73973875214645 10.45 35.6691906390157 139.73974844370568 10.45 35.6691906390157 139.73974844370568 14.589 35.66917525405553 139.73973875214645 14.589 35.66917525405553 139.73973875214645 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2491f467-e546-43c0-965d-4158cf366269">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2491f467-e546-43c0-965d-4158cf366269">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2491f467-e546-43c0-965d-4158cf366269">
											<gml:posList>35.669299511163544 139.73975396119553 10.45 35.66929781989571 139.73973503013642 10.45 35.66929781989571 139.73973503013642 13.825 35.669299511163544 139.73975396119553 13.825 35.669299511163544 139.73975396119553 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28c04f81-c756-4a7e-abf3-15c4c1e9f9b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28c04f81-c756-4a7e-abf3-15c4c1e9f9b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28c04f81-c756-4a7e-abf3-15c4c1e9f9b1">
											<gml:posList>35.66924359892901 139.73974229548975 10.45 35.66924529023861 139.73976128176668 10.45 35.66924529023861 139.73976128176668 13.825 35.66924359892901 139.73974229548975 13.825 35.66924359892901 139.73974229548975 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2bfeffb8-29be-41ad-b409-f662bea9212d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bfeffb8-29be-41ad-b409-f662bea9212d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bfeffb8-29be-41ad-b409-f662bea9212d">
											<gml:posList>35.66916013899142 139.7397747910938 10.45 35.66917525405553 139.73973875214645 10.45 35.66917525405553 139.73973875214645 14.589 35.66916013899142 139.7397747910938 14.589 35.66916013899142 139.7397747910938 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fbbc83e-5511-48a0-909a-b53e1a62d0b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fbbc83e-5511-48a0-909a-b53e1a62d0b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fbbc83e-5511-48a0-909a-b53e1a62d0b8">
											<gml:posList>35.66925150000789 139.73976039083146 10.45 35.669299511163544 139.73975396119553 10.45 35.669299511163544 139.73975396119553 13.825 35.66925150000789 139.73976039083146 13.825 35.66925150000789 139.73976039083146 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe0ce823-a4c9-4285-a111-a3450ab8a8cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe0ce823-a4c9-4285-a111-a3450ab8a8cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe0ce823-a4c9-4285-a111-a3450ab8a8cc">
											<gml:posList>35.66923241420166 139.7397671843651 10.45 35.66923883811209 139.73975187801736 10.45 35.66923883811209 139.73975187801736 14.589 35.66923241420166 139.7397671843651 14.589 35.66923241420166 139.7397671843651 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4864035-62c2-49d1-ae9c-b1ad68202ee8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4864035-62c2-49d1-ae9c-b1ad68202ee8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4864035-62c2-49d1-ae9c-b1ad68202ee8">
											<gml:posList>35.66924529023861 139.73976128176668 10.45 35.66923599805029 139.73976252977414 10.45 35.66923599805029 139.73976252977414 13.825 35.66924529023861 139.73976128176668 13.825 35.66924529023861 139.73976128176668 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32600b7d-fc11-4cc8-88f0-4cc354fdeee1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32600b7d-fc11-4cc8-88f0-4cc354fdeee1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32600b7d-fc11-4cc8-88f0-4cc354fdeee1">
											<gml:posList>35.66923664371542 139.73976985258616 13.825 35.66923664371542 139.73976985258616 10.45 35.66923241420166 139.7397671843651 10.45 35.66923241420166 139.7397671843651 14.589 35.66923974595572 139.73977180412626 14.589 35.66923974595572 139.73977180412626 13.825 35.66923664371542 139.73976985258616 13.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bcbdf8bf-910e-4f8b-b03a-99d4306e9713">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcbdf8bf-910e-4f8b-b03a-99d4306e9713">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcbdf8bf-910e-4f8b-b03a-99d4306e9713">
											<gml:posList>35.66915034528903 139.7397686277572 10.45 35.66916013899142 139.7397747910938 10.45 35.66916013899142 139.7397747910938 14.589 35.66915034528903 139.7397686277572 14.589 35.66915034528903 139.7397686277572 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3df8352b-ad6b-4349-b61d-a2970f6c7fcb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3df8352b-ad6b-4349-b61d-a2970f6c7fcb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3df8352b-ad6b-4349-b61d-a2970f6c7fcb">
											<gml:posList>35.669253509609845 139.73978299986143 10.45 35.66925150000789 139.73976039083146 10.45 35.66925150000789 139.73976039083146 13.825 35.669253509609845 139.73978299986143 13.825 35.669253509609845 139.73978299986143 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96774702-d0e2-439c-9e34-363e7edb01ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96774702-d0e2-439c-9e34-363e7edb01ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96774702-d0e2-439c-9e34-363e7edb01ad">
											<gml:posList>35.66923733474909 139.73977756195893 10.45 35.66923800760894 139.73978508356933 10.45 35.66923800760894 139.73978508356933 13.825 35.66923733474909 139.73977756195893 13.825 35.66923733474909 139.73977756195893 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ef419e8-1991-44e7-8172-cae7c6246fa9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ef419e8-1991-44e7-8172-cae7c6246fa9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ef419e8-1991-44e7-8172-cae7c6246fa9">
											<gml:posList>35.66923800760894 139.73978508356933 10.45 35.669253509609845 139.73978299986143 10.45 35.669253509609845 139.73978299986143 13.825 35.66923800760894 139.73978508356933 13.825 35.66923800760894 139.73978508356933 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-009282de-45c5-4f29-a03d-9bd7f7600523">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-009282de-45c5-4f29-a03d-9bd7f7600523">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-009282de-45c5-4f29-a03d-9bd7f7600523">
											<gml:posList>35.669228256694794 139.7397991897703 14.589 35.669228256694794 139.7397991897703 10.45 35.66923733474909 139.73977756195893 10.45 35.66923733474909 139.73977756195893 13.825 35.66923974595572 139.73977180412626 13.825 35.66923974595572 139.73977180412626 14.589 35.669228256694794 139.7397991897703 14.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38ea246f-72c8-47da-b137-cb645fd3aac4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38ea246f-72c8-47da-b137-cb645fd3aac4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38ea246f-72c8-47da-b137-cb645fd3aac4">
											<gml:posList>35.66919028587708 139.73979278314496 10.45 35.66919609799044 139.73977893560584 10.45 35.66919609799044 139.73977893560584 14.589 35.66919028587708 139.73979278314496 14.589 35.66919028587708 139.73979278314496 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a99a6702-213b-4e59-a609-951ef08b7bba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a99a6702-213b-4e59-a609-951ef08b7bba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a99a6702-213b-4e59-a609-951ef08b7bba">
											<gml:posList>35.66919609799044 139.73977893560584 10.45 35.669228256694794 139.7397991897703 10.45 35.669228256694794 139.7397991897703 14.589 35.66919609799044 139.73977893560584 14.589 35.66919609799044 139.73977893560584 10.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2946</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.85</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>