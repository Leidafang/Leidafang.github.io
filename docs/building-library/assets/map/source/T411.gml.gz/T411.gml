<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_76a433f5-3d66-42a7-a296-77cda9559723">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">27.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67272515903796 139.7398092829124 0 35.67274220208246 139.73978361286066 0 35.672660415555555 139.73969603164167 0 35.67258838530595 139.73979840695 0 35.67270479528996 139.73992316376467 0 35.672773875627215 139.73981753311642 0 35.67276998747132 139.7398133620413 0 35.67275497206132 139.73983845530853 0 35.67272515903796 139.7398092829124 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67272515903796 139.7398092829124 7.73 35.67275497206132 139.73983845530853 7.73 35.67276998747132 139.7398133620413 7.73 35.672773875627215 139.73981753311642 7.73 35.67270479528996 139.73992316376467 7.73 35.67258838530595 139.73979840695 7.73 35.672660415555555 139.73969603164167 7.73 35.67274220208246 139.73978361286066 7.73 35.67272515903796 139.7398092829124 7.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67272515903796 139.7398092829124 7.73 35.67274220208246 139.73978361286066 7.73 35.67274220208246 139.73978361286066 34.92 35.67272515903796 139.7398092829124 34.92 35.67272515903796 139.7398092829124 7.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67274220208246 139.73978361286066 7.73 35.672660415555555 139.73969603164167 7.73 35.672660415555555 139.73969603164167 34.92 35.67274220208246 139.73978361286066 34.92 35.67274220208246 139.73978361286066 7.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672660415555555 139.73969603164167 7.73 35.67258838530595 139.73979840695 7.73 35.67258838530595 139.73979840695 34.92 35.672660415555555 139.73969603164167 34.92 35.672660415555555 139.73969603164167 7.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67258838530595 139.73979840695 7.73 35.67270479528996 139.73992316376467 7.73 35.67270479528996 139.73992316376467 34.92 35.67258838530595 139.73979840695 34.92 35.67258838530595 139.73979840695 7.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67270479528996 139.73992316376467 7.73 35.672773875627215 139.73981753311642 7.73 35.672773875627215 139.73981753311642 34.92 35.67270479528996 139.73992316376467 34.92 35.67270479528996 139.73992316376467 7.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672773875627215 139.73981753311642 7.73 35.67276998747132 139.7398133620413 7.73 35.67276998747132 139.7398133620413 34.92 35.672773875627215 139.73981753311642 34.92 35.672773875627215 139.73981753311642 7.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67276998747132 139.7398133620413 7.73 35.67275497206132 139.73983845530853 7.73 35.67275497206132 139.73983845530853 34.92 35.67276998747132 139.7398133620413 34.92 35.67276998747132 139.7398133620413 7.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67275497206132 139.73983845530853 7.73 35.67272515903796 139.7398092829124 7.73 35.67272515903796 139.7398092829124 34.92 35.67275497206132 139.73983845530853 34.92 35.67275497206132 139.73983845530853 7.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67272515903796 139.7398092829124 34.92 35.67274220208246 139.73978361286066 34.92 35.672660415555555 139.73969603164167 34.92 35.67258838530595 139.73979840695 34.92 35.67270479528996 139.73992316376467 34.92 35.672773875627215 139.73981753311642 34.92 35.67276998747132 139.7398133620413 34.92 35.67275497206132 139.73983845530853 34.92 35.67272515903796 139.7398092829124 34.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c568a33f-8847-46f7-8681-7143f27ba710"/>
							<gml:surfaceMember xlink:href="#poly-79b30a53-1652-4f75-bff2-e644d3e013dc"/>
							<gml:surfaceMember xlink:href="#poly-440479c3-c906-49a0-9fe6-2e72e9c2a0bc"/>
							<gml:surfaceMember xlink:href="#poly-f3167d3a-3081-4a53-bcfa-0421a45ddcbb"/>
							<gml:surfaceMember xlink:href="#poly-076a9b0f-cdfc-4e64-8c8e-eba99d88009e"/>
							<gml:surfaceMember xlink:href="#poly-0a9d6e4f-72ff-400c-af69-93a3dfe15d5d"/>
							<gml:surfaceMember xlink:href="#poly-6f05c5ac-59c5-4447-b329-a8e5c00a64bc"/>
							<gml:surfaceMember xlink:href="#poly-2fafdcb7-95dd-4b42-9f73-6a498e4732f0"/>
							<gml:surfaceMember xlink:href="#poly-fc741058-ea84-4273-94ba-d90723213df3"/>
							<gml:surfaceMember xlink:href="#poly-62f796dc-b541-4b38-889c-ad2d5c14e6d3"/>
							<gml:surfaceMember xlink:href="#poly-98e25125-f4b5-4be9-a204-b6ba6f585c23"/>
							<gml:surfaceMember xlink:href="#poly-34575587-9d3a-45d7-89c3-f2ef539c65b6"/>
							<gml:surfaceMember xlink:href="#poly-d45ee5be-4466-4470-8af9-8577e1570adb"/>
							<gml:surfaceMember xlink:href="#poly-5870f712-f97d-4e0c-b4d1-c343a50ade13"/>
							<gml:surfaceMember xlink:href="#poly-364eb804-c42a-411f-9749-5d6dab73e737"/>
							<gml:surfaceMember xlink:href="#poly-5bbbe82c-7e71-4de8-8881-4b7db256b6d4"/>
							<gml:surfaceMember xlink:href="#poly-72d8571d-7b78-4d2a-8800-5b4a3c1971cb"/>
							<gml:surfaceMember xlink:href="#poly-4c7c8c48-4932-40fe-b168-70c41f5a686c"/>
							<gml:surfaceMember xlink:href="#poly-f5a863b4-a153-4bc5-91ce-9d47bca845bf"/>
							<gml:surfaceMember xlink:href="#poly-c4daa17d-8121-426e-bd9d-b06d26c643c9"/>
							<gml:surfaceMember xlink:href="#poly-a7b92989-722f-4fc3-83ae-c4bcd1330e83"/>
							<gml:surfaceMember xlink:href="#poly-4047f168-92a2-4bc9-8640-27c988c21010"/>
							<gml:surfaceMember xlink:href="#poly-1cbac366-21ff-43ce-b4e0-f461d97340e5"/>
							<gml:surfaceMember xlink:href="#poly-c367a68a-c89c-4909-9522-03d02b65ee4e"/>
							<gml:surfaceMember xlink:href="#poly-072a2714-b7c0-41fd-a53b-0552e7f5ccb9"/>
							<gml:surfaceMember xlink:href="#poly-38fdc706-1ee3-4110-ab42-9d5d620358db"/>
							<gml:surfaceMember xlink:href="#poly-b08bc32f-4260-4bfe-94f9-5653e1949017"/>
							<gml:surfaceMember xlink:href="#poly-b046f38e-1473-4532-826d-bfe9d5189e27"/>
							<gml:surfaceMember xlink:href="#poly-afb69681-0a14-4c36-b340-c90d818d27bb"/>
							<gml:surfaceMember xlink:href="#poly-77079396-b11a-47a9-b209-88f70d253144"/>
							<gml:surfaceMember xlink:href="#poly-849e98e0-21c1-4f67-9a04-b7d02900690f"/>
							<gml:surfaceMember xlink:href="#poly-0e95b4eb-8166-4890-b0da-be4c3b4ad4a8"/>
							<gml:surfaceMember xlink:href="#poly-27748790-6397-4025-a046-0386de698598"/>
							<gml:surfaceMember xlink:href="#poly-f8869491-f427-4745-8f11-77fe58fd92ac"/>
							<gml:surfaceMember xlink:href="#poly-b8e14621-2a0c-4f36-a8d1-76939c54c166"/>
							<gml:surfaceMember xlink:href="#poly-f114c2b9-d412-4bf5-bea3-e895e3e101ca"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_76a433f5-3d66-42a7-a296-77cda9559723_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e467c9b0-e69e-4008-aa18-8955213d276d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e467c9b0-e69e-4008-aa18-8955213d276d_0">
											<gml:posList>35.672688508587356 139.73977365626894 34.971 35.67267973864024 139.73978578459761 35.283 35.672688508587356 139.73977365626894 35.283 35.672688508587356 139.73977365626894 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a124a6b-7c6e-4657-a58e-187a41e41344">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a124a6b-7c6e-4657-a58e-187a41e41344_0">
											<gml:posList>35.672688508587356 139.73977365626894 34.971 35.67267973864024 139.73978578459761 34.971 35.67267973864024 139.73978578459761 35.283 35.672688508587356 139.73977365626894 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-325d86ab-6914-49ff-9e4f-3cf3bbad3efb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-325d86ab-6914-49ff-9e4f-3cf3bbad3efb_0">
											<gml:posList>35.67271203622564 139.73979919059968 34.971 35.672688508587356 139.73977365626894 35.283 35.67271203622564 139.73979919059968 35.283 35.67271203622564 139.73979919059968 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b82b804e-35b0-44b6-a0b5-e84a98d5ec90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b82b804e-35b0-44b6-a0b5-e84a98d5ec90_0">
											<gml:posList>35.67271203622564 139.73979919059968 34.971 35.672688508587356 139.73977365626894 34.971 35.672688508587356 139.73977365626894 35.283 35.67271203622564 139.73979919059968 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24a7a04e-b01a-4326-872c-3d8f39f9ef45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24a7a04e-b01a-4326-872c-3d8f39f9ef45_0">
											<gml:posList>35.672703266275995 139.73981131892913 35.283 35.672688508587356 139.73977365626894 35.283 35.67267973864024 139.73978578459761 35.283 35.672703266275995 139.73981131892913 35.283</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b963bc5-f4a3-43b7-b009-2ee3d5c056ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b963bc5-f4a3-43b7-b009-2ee3d5c056ea_0">
											<gml:posList>35.672703266275995 139.73981131892913 35.283 35.67271203622564 139.73979919059968 35.283 35.672688508587356 139.73977365626894 35.283 35.672703266275995 139.73981131892913 35.283</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08cdac49-4227-4fb5-86bd-43e0011aec60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08cdac49-4227-4fb5-86bd-43e0011aec60_0">
											<gml:posList>35.67274002331139 139.73978689623863 34.971 35.67274220208245 139.73978361286066 7.82 35.67272515903796 139.7398092829124 7.82 35.67274002331139 139.73978689623863 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14f0299d-66c3-4310-a8aa-fd2cb02c12d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14f0299d-66c3-4310-a8aa-fd2cb02c12d6_0">
											<gml:posList>35.67272515903796 139.7398092829124 7.82 35.67272515903796 139.7398092829124 34.971 35.67274002331139 139.73978689623863 34.971 35.67272515903796 139.7398092829124 7.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d661f05-61ea-4b79-b1ed-5c4fb235205a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d661f05-61ea-4b79-b1ed-5c4fb235205a_0">
											<gml:posList>35.67274220208245 139.73978361286066 35.55 35.67274220208245 139.73978361286066 7.82 35.67274002331139 139.73978689623863 34.971 35.67274220208245 139.73978361286066 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95fc4f00-7270-43c7-b6fc-36a5f585b877">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95fc4f00-7270-43c7-b6fc-36a5f585b877_0">
											<gml:posList>35.67274002331139 139.73978689623863 35.55 35.67274220208245 139.73978361286066 35.55 35.67274002331139 139.73978689623863 34.971 35.67274002331139 139.73978689623863 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78522f95-92e1-4c49-83a7-f8feb7f4cb8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78522f95-92e1-4c49-83a7-f8feb7f4cb8f_0">
											<gml:posList>35.672703266275995 139.73981131892913 34.971 35.67267973864024 139.73978578459761 35.283 35.67267973864024 139.73978578459761 34.971 35.672703266275995 139.73981131892913 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49304953-c754-460a-b522-f2368e3dc6e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49304953-c754-460a-b522-f2368e3dc6e1_0">
											<gml:posList>35.672703266275995 139.73981131892913 34.971 35.672703266275995 139.73981131892913 35.283 35.67267973864024 139.73978578459761 35.283 35.672703266275995 139.73981131892913 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d42ac83-e246-4c98-a401-27f4f7fa1650">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d42ac83-e246-4c98-a401-27f4f7fa1650_0">
											<gml:posList>35.67276998747131 139.7398133620413 7.82 35.67274220208245 139.73978361286066 35.796 35.67276998747131 139.7398133620413 35.796 35.67276998747131 139.7398133620413 7.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39aa1515-a8c0-462e-9a3e-f10234313453">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39aa1515-a8c0-462e-9a3e-f10234313453_0">
											<gml:posList>35.67276998747131 139.7398133620413 7.82 35.67274220208245 139.73978361286066 7.82 35.67274220208245 139.73978361286066 35.796 35.67276998747131 139.7398133620413 7.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9fa3227-f9c2-467a-9fbb-b8afcc09e616">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9fa3227-f9c2-467a-9fbb-b8afcc09e616_0">
											<gml:posList>35.67271203622564 139.73979919059968 34.971 35.672703266275995 139.73981131892913 35.283 35.672703266275995 139.73981131892913 34.971 35.67271203622564 139.73979919059968 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68a4c60b-7ffe-499a-b62d-e874a14da9e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68a4c60b-7ffe-499a-b62d-e874a14da9e3_0">
											<gml:posList>35.67271203622564 139.73979919059968 34.971 35.67271203622564 139.73979919059968 35.283 35.672703266275995 139.73981131892913 35.283 35.67271203622564 139.73979919059968 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0025bd6-9141-48dc-839c-77256455a8eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0025bd6-9141-48dc-839c-77256455a8eb_0">
											<gml:posList>35.67272515903796 139.7398092829124 35.796 35.67276998747131 139.7398133620413 35.796 35.67274220208245 139.73978361286066 35.796 35.67272515903796 139.7398092829124 35.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-579c99c6-7c85-4fa6-be4e-47abaa60985d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-579c99c6-7c85-4fa6-be4e-47abaa60985d_0">
											<gml:posList>35.67272515903796 139.7398092829124 35.796 35.672754972061306 139.73983845530853 35.796 35.67276998747131 139.7398133620413 35.796 35.67272515903796 139.7398092829124 35.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70b2d110-1e8b-49ba-b46b-3daff3208a8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70b2d110-1e8b-49ba-b46b-3daff3208a8b_0">
											<gml:posList>35.67275213057831 139.73983567488253 34.971 35.67272515903796 139.7398092829124 7.82 35.67275213057831 139.73983567488253 7.82 35.67275213057831 139.73983567488253 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a2c044d-4fc3-4772-9f9b-3cfd832a87b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a2c044d-4fc3-4772-9f9b-3cfd832a87b2_0">
											<gml:posList>35.67275213057831 139.73983567488253 34.971 35.67272515903796 139.7398092829124 34.971 35.67272515903796 139.7398092829124 7.82 35.67275213057831 139.73983567488253 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da467438-96fd-494e-a31d-0d6d13901d96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da467438-96fd-494e-a31d-0d6d13901d96_0">
											<gml:posList>35.67272515903796 139.7398092829124 34.971 35.67275213057831 139.73983567488253 34.971 35.67272515903796 139.7398092829124 35.796 35.67272515903796 139.7398092829124 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ebae4fd-c725-40bb-b887-42d57a8289c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ebae4fd-c725-40bb-b887-42d57a8289c2_0">
											<gml:posList>35.67272515903796 139.7398092829124 35.796 35.67275213057831 139.73983567488253 34.971 35.672754972061306 139.73983845530853 35.796 35.67272515903796 139.7398092829124 35.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76e99884-6616-4cbb-990f-5d0c545c8934">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76e99884-6616-4cbb-990f-5d0c545c8934_0">
											<gml:posList>35.672754972061306 139.73983845530853 35.796 35.67275213057831 139.73983567488253 34.971 35.672754972061306 139.73983845530853 7.82 35.672754972061306 139.73983845530853 35.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4693bb42-cb20-4bc0-beb6-142f2d1ba695">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4693bb42-cb20-4bc0-beb6-142f2d1ba695_0">
											<gml:posList>35.67275213057831 139.73983567488253 34.971 35.67275213057831 139.73983567488253 7.82 35.672754972061306 139.73983845530853 7.82 35.67275213057831 139.73983567488253 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11a2d21d-f77b-4846-8f50-e40c009fc7f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11a2d21d-f77b-4846-8f50-e40c009fc7f3_0">
											<gml:posList>35.672754972061306 139.73983845530853 35.796 35.67276998747131 139.7398133620413 7.82 35.67276998747131 139.7398133620413 35.796 35.672754972061306 139.73983845530853 35.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcdc1a93-6b6e-44f6-87a3-f120fbf1fb3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcdc1a93-6b6e-44f6-87a3-f120fbf1fb3f_0">
											<gml:posList>35.672754972061306 139.73983845530853 35.796 35.672754972061306 139.73983845530853 7.82 35.67276998747131 139.7398133620413 7.82 35.672754972061306 139.73983845530853 35.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f941b1ce-ec43-4d55-b875-1544b7ff11b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f941b1ce-ec43-4d55-b875-1544b7ff11b1_0">
											<gml:posList>35.67274220208245 139.73978361286066 35.55 35.67274002331139 139.73978689623863 35.55 35.67274220208245 139.73978361286066 35.796 35.67274220208245 139.73978361286066 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70a0d4c5-e86a-4b56-b919-49b8100d143f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70a0d4c5-e86a-4b56-b919-49b8100d143f_0">
											<gml:posList>35.67274220208245 139.73978361286066 35.796 35.67274002331139 139.73978689623863 35.55 35.67272515903796 139.7398092829124 35.796 35.67274220208245 139.73978361286066 35.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66edbdf7-f275-4653-9d96-28136a36581e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66edbdf7-f275-4653-9d96-28136a36581e_0">
											<gml:posList>35.67274002331139 139.73978689623863 34.971 35.67272515903796 139.7398092829124 34.971 35.67274002331139 139.73978689623863 35.55 35.67274002331139 139.73978689623863 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb9d8ddd-23c4-4979-9300-e0cfef8fce29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb9d8ddd-23c4-4979-9300-e0cfef8fce29_0">
											<gml:posList>35.67274002331139 139.73978689623863 35.55 35.67272515903796 139.7398092829124 34.971 35.67272515903796 139.7398092829124 35.796 35.67274002331139 139.73978689623863 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fee0693-e478-4884-9c29-b2d9c37bde5a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672703266275995 139.73981131892913 34.971 35.672688508587356 139.73977365626894 34.971 35.67271203622564 139.73979919059968 34.971 35.672703266275995 139.73981131892913 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fecef5f5-1de5-4ccd-9df2-18dd3468c04d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672703266275995 139.73981131892913 34.971 35.67267973864024 139.73978578459761 34.971 35.672688508587356 139.73977365626894 34.971 35.672703266275995 139.73981131892913 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84361018-9cb0-4576-8144-0ba5b3d926ff">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67272515903796 139.7398092829124 7.82 35.67274220208245 139.73978361286066 7.82 35.67275213057831 139.73983567488253 7.82 35.67272515903796 139.7398092829124 7.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd4bde58-e139-4264-b395-0fb1404199c2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67274220208245 139.73978361286066 7.82 35.67276998747131 139.7398133620413 7.82 35.67275213057831 139.73983567488253 7.82 35.67274220208245 139.73978361286066 7.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0367f53-7978-497b-a074-4a3e7bcd2ef6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67276998747131 139.7398133620413 7.82 35.672754972061306 139.73983845530853 7.82 35.67275213057831 139.73983567488253 7.82 35.67276998747131 139.7398133620413 7.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_76a433f5-3d66-42a7-a296-77cda9559723_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65ae447f-1ddc-4cf4-88e3-b33798121e78">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67262238430817 139.73979740623213 34.971 35.672625625660075 139.7397927849847 34.971 35.6726417914763 139.73980979993541 34.971 35.67263468751929 139.73981993792725 34.971 35.672616708453894 139.73980100298863 34.971 35.67262057105749 139.73979548624482 34.971 35.67262238430817 139.73979740623213 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a61041b5-6979-46b8-b0ac-00489cc316a6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67269784823433 139.7397522923329 34.971 35.67266812292246 139.73972002684627 34.971 35.67260727357829 139.73980421750014 34.971 35.67266729250186 139.7398693775031 34.971 35.672665761798754 139.73987147813673 34.971 35.67260373111801 139.73980413326032 34.971 35.67266767786638 139.7397156750156 34.971 35.672699405924995 139.73975012538517 34.971 35.67269784823433 139.7397522923329 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2eda5c6-586b-431b-aa12-57b907ef0349">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67263660311949 139.73977956047852 34.971 35.67265028920875 139.7397605444037 34.971 35.67267258988562 139.73978466618848 34.971 35.67265889477889 139.73980368227504 34.971 35.67263660311949 139.73977956047852 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f58663d-4674-42b1-99c4-0d0e7440e001">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672672320127 139.73973911042722 34.971 35.67266544151897 139.73974924816613 34.971 35.67265884725296 139.73974251745395 34.971 35.67266572586044 139.7397323797153 34.971 35.672672320127 139.73973911042722 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-138bc876-702e-4649-b424-d89e77b32cf2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67265769772797 139.73982917916243 34.971 35.672684004675915 139.73985869807325 34.971 35.67267940345043 139.7398648674275 34.971 35.672653096495395 139.7398353374698 34.971 35.67265769772797 139.73982917916243 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4961830-c816-492e-8826-ec8ad482c807">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67267105188199 139.73982378390528 34.971 35.6726933253592 139.7398477179538 34.971 35.6726883101464 139.73985471628544 34.971 35.67266604568428 139.73983078222594 34.971 35.67267105188199 139.73982378390528 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3b6a31c-e4c3-42f9-81ec-e3cad019b2ad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67268089168642 139.739761668576 34.971 35.67267347652022 139.73975409927996 34.971 35.672682083787876 139.7397414188098 34.971 35.67268949895488 139.7397489881055 34.971 35.67268089168642 139.739761668576 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84419bc4-07ef-4495-b936-968326cc54eb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67273697341455 139.7398523397616 34.971 35.67273249823572 139.73985832118143 34.971 35.672717928343715 139.73984193399573 34.971 35.67272240352175 139.73983595257604 34.971 35.67273697341455 139.7398523397616 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4d8220b-d810-4d61-9418-5c189023ff36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4d8220b-d810-4d61-9418-5c189023ff36_0">
											<gml:posList>35.67266572586044 139.7397323797153 34.971 35.67265884725296 139.73974251745395 34.971 35.67265884725296 139.73974251745395 36.161 35.67266572586044 139.7397323797153 36.161 35.67266572586044 139.7397323797153 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0c39d10-1838-4e7f-a999-772bf642d240">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0c39d10-1838-4e7f-a999-772bf642d240_0">
											<gml:posList>35.672672320127 139.73973911042722 34.971 35.67266572586044 139.7397323797153 34.971 35.67266572586044 139.7397323797153 36.161 35.672672320127 139.73973911042722 36.161 35.672672320127 139.73973911042722 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e487e12-effe-41eb-ae44-4172f4d04471">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e487e12-effe-41eb-ae44-4172f4d04471_0">
											<gml:posList>35.67260373111801 139.73980413326032 34.971 35.67260373111801 139.73980413326032 36.672 35.67266767786638 139.7397156750156 36.672 35.67266767786638 139.7397156750156 34.971 35.67260373111801 139.73980413326032 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88f42ef8-8869-41e5-ac23-26acfdef2299">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88f42ef8-8869-41e5-ac23-26acfdef2299_0">
											<gml:posList>35.67266812292246 139.73972002684627 36.672 35.67260727357829 139.73980421750014 36.672 35.67260727357829 139.73980421750014 34.971 35.67266812292246 139.73972002684627 34.971 35.67266812292246 139.73972002684627 36.672</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6e0af22-f44a-447f-975e-172e67be56f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6e0af22-f44a-447f-975e-172e67be56f0_0">
											<gml:posList>35.67263660311949 139.73977956047852 37.341 35.67265028920875 139.7397605444037 37.341 35.67265028920875 139.7397605444037 34.971 35.67263660311949 139.73977956047852 34.971 35.67263660311949 139.73977956047852 37.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ef381c8-4ce2-4722-8d51-3df5055ff45b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ef381c8-4ce2-4722-8d51-3df5055ff45b_0">
											<gml:posList>35.67263660311949 139.73977956047852 37.341 35.67265889477889 139.73980368227504 37.341 35.67267258988562 139.73978466618848 37.341 35.67265028920875 139.7397605444037 37.341 35.67263660311949 139.73977956047852 37.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-778b67fe-53c1-4b85-b838-3902a128fba2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-778b67fe-53c1-4b85-b838-3902a128fba2_0">
											<gml:posList>35.67265028920875 139.7397605444037 34.971 35.67265028920875 139.7397605444037 37.341 35.67267258988562 139.73978466618848 37.341 35.67267258988562 139.73978466618848 34.971 35.67265028920875 139.7397605444037 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d55e6fba-f39e-4179-884e-07bee0a16307">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d55e6fba-f39e-4179-884e-07bee0a16307_0">
											<gml:posList>35.67265884725296 139.73974251745395 34.971 35.67266544151897 139.73974924816613 34.971 35.67266544151897 139.73974924816613 36.161 35.67265884725296 139.73974251745395 36.161 35.67265884725296 139.73974251745395 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c8238a8-64b3-44f0-ad15-2516c2ffa141">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c8238a8-64b3-44f0-ad15-2516c2ffa141_0">
											<gml:posList>35.67265884725296 139.73974251745395 36.161 35.67266544151897 139.73974924816613 36.161 35.672672320127 139.73973911042722 36.161 35.67266572586044 139.7397323797153 36.161 35.67265884725296 139.73974251745395 36.161</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-682e8a94-feec-4005-93e9-a9b5c0b468b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-682e8a94-feec-4005-93e9-a9b5c0b468b4_0">
											<gml:posList>35.67266544151897 139.73974924816613 34.971 35.672672320127 139.73973911042722 34.971 35.672672320127 139.73973911042722 36.161 35.67266544151897 139.73974924816613 36.161 35.67266544151897 139.73974924816613 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-966adb7c-ef67-47b0-8f38-c3f15a485f37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-966adb7c-ef67-47b0-8f38-c3f15a485f37_0">
											<gml:posList>35.67268089168642 139.739761668576 34.971 35.67268089168642 139.739761668576 36.761 35.67267347652022 139.73975409927996 36.761 35.67267347652022 139.73975409927996 34.971 35.67268089168642 139.739761668576 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f02f934c-4163-4b86-8111-e8b44a71966f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f02f934c-4163-4b86-8111-e8b44a71966f_0">
											<gml:posList>35.672682083787876 139.7397414188098 34.971 35.67267347652022 139.73975409927996 34.971 35.67267347652022 139.73975409927996 36.761 35.672682083787876 139.7397414188098 36.761 35.672682083787876 139.7397414188098 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ffda737-6909-44f1-a4aa-f04e23561548">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ffda737-6909-44f1-a4aa-f04e23561548_0">
											<gml:posList>35.672682083787876 139.7397414188098 36.761 35.67267347652022 139.73975409927996 36.761 35.67268089168642 139.739761668576 36.761 35.67268949895488 139.7397489881055 36.761 35.672682083787876 139.7397414188098 36.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e67098df-8360-48ed-96df-f3d9ac2349bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e67098df-8360-48ed-96df-f3d9ac2349bb_0">
											<gml:posList>35.67269784823433 139.7397522923329 34.971 35.67269784823433 139.7397522923329 36.672 35.67266812292246 139.73972002684627 36.672 35.67266812292246 139.73972002684627 34.971 35.67269784823433 139.7397522923329 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-782ae6b5-0c86-4695-bad7-5fcf57c38161">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-782ae6b5-0c86-4695-bad7-5fcf57c38161_0">
											<gml:posList>35.672699405924995 139.73975012538517 34.971 35.67266767786638 139.7397156750156 34.971 35.67266767786638 139.7397156750156 36.672 35.672699405924995 139.73975012538517 36.672 35.672699405924995 139.73975012538517 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d61a38e-3108-4d57-b110-5fc3ae5b2a36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d61a38e-3108-4d57-b110-5fc3ae5b2a36_0">
											<gml:posList>35.67268089168642 139.739761668576 34.971 35.67268949895488 139.7397489881055 34.971 35.67268949895488 139.7397489881055 36.761 35.67268089168642 139.739761668576 36.761 35.67268089168642 139.739761668576 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b44f9335-5940-4622-a07d-35bcd908e5c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b44f9335-5940-4622-a07d-35bcd908e5c1_0">
											<gml:posList>35.67268949895488 139.7397489881055 34.971 35.672682083787876 139.7397414188098 34.971 35.672682083787876 139.7397414188098 36.761 35.67268949895488 139.7397489881055 36.761 35.67268949895488 139.7397489881055 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d35ca46-3808-49f0-8a3b-75a5f756a5e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d35ca46-3808-49f0-8a3b-75a5f756a5e5_0">
											<gml:posList>35.67269784823433 139.7397522923329 34.971 35.672699405924995 139.73975012538517 34.971 35.672699405924995 139.73975012538517 36.672 35.67269784823433 139.7397522923329 36.672 35.67269784823433 139.7397522923329 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27a58933-c1a4-48b5-a6f7-ff95b8af6e1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27a58933-c1a4-48b5-a6f7-ff95b8af6e1e_0">
											<gml:posList>35.67265889477889 139.73980368227504 34.971 35.67265889477889 139.73980368227504 37.341 35.67263660311949 139.73977956047852 37.341 35.67263660311949 139.73977956047852 34.971 35.67265889477889 139.73980368227504 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-626203bb-0fb0-4fde-8033-989ef673e1fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-626203bb-0fb0-4fde-8033-989ef673e1fe_0">
											<gml:posList>35.67266767786638 139.7397156750156 36.672 35.67260373111801 139.73980413326032 36.672 35.672665761798754 139.73987147813673 36.672 35.67266729250186 139.7398693775031 36.672 35.67260727357829 139.73980421750014 36.672 35.67266812292246 139.73972002684627 36.672 35.67269784823433 139.7397522923329 36.672 35.672699405924995 139.73975012538517 36.672 35.67266767786638 139.7397156750156 36.672</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c74cba5-ad86-4fb1-a393-b3eadb121c21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c74cba5-ad86-4fb1-a393-b3eadb121c21_0">
											<gml:posList>35.67267258988562 139.73978466618848 34.971 35.67267258988562 139.73978466618848 37.341 35.67265889477889 139.73980368227504 37.341 35.67265889477889 139.73980368227504 34.971 35.67267258988562 139.73978466618848 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-089967a4-8513-449b-b0e3-8c094e084520">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-089967a4-8513-449b-b0e3-8c094e084520_0">
											<gml:posList>35.672625625660075 139.7397927849847 34.971 35.67262238430817 139.73979740623213 34.971 35.67262238430817 139.73979740623213 37.306 35.672625625660075 139.7397927849847 37.306 35.672625625660075 139.7397927849847 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9915c4ac-62f8-4898-9146-5d57959ac945">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9915c4ac-62f8-4898-9146-5d57959ac945_0">
											<gml:posList>35.67262238430817 139.73979740623213 34.971 35.67262057105749 139.73979548624482 34.971 35.67262057105749 139.73979548624482 37.306 35.67262238430817 139.73979740623213 37.306 35.67262238430817 139.73979740623213 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e308285-4afa-482e-afe9-2a8c09396741">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e308285-4afa-482e-afe9-2a8c09396741_0">
											<gml:posList>35.672616708453894 139.73980100298863 34.971 35.672616708453894 139.73980100298863 37.306 35.67262057105749 139.73979548624482 37.306 35.67262057105749 139.73979548624482 34.971 35.672616708453894 139.73980100298863 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91cba9ab-6e6c-4d72-90ae-aec595241120">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91cba9ab-6e6c-4d72-90ae-aec595241120_0">
											<gml:posList>35.672625625660075 139.7397927849847 34.971 35.672625625660075 139.7397927849847 37.306 35.6726417914763 139.73980979993541 37.306 35.6726417914763 139.73980979993541 34.971 35.672625625660075 139.7397927849847 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcc59027-744c-49e6-bce5-409219825b8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcc59027-744c-49e6-bce5-409219825b8b_0">
											<gml:posList>35.672616708453894 139.73980100298863 37.306 35.67263468751929 139.73981993792725 37.306 35.6726417914763 139.73980979993541 37.306 35.672625625660075 139.7397927849847 37.306 35.67262238430817 139.73979740623213 37.306 35.67262057105749 139.73979548624482 37.306 35.672616708453894 139.73980100298863 37.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3d4b3fe-50bc-4515-b98e-fbf802ab00e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3d4b3fe-50bc-4515-b98e-fbf802ab00e5_0">
											<gml:posList>35.672616708453894 139.73980100298863 34.971 35.67263468751929 139.73981993792725 34.971 35.67263468751929 139.73981993792725 37.306 35.672616708453894 139.73980100298863 37.306 35.672616708453894 139.73980100298863 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88f0eed1-492a-4381-b654-0e3f6b1e80ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88f0eed1-492a-4381-b654-0e3f6b1e80ec_0">
											<gml:posList>35.6726417914763 139.73980979993541 34.971 35.6726417914763 139.73980979993541 37.306 35.67263468751929 139.73981993792725 37.306 35.67263468751929 139.73981993792725 34.971 35.6726417914763 139.73980979993541 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21c9c245-78da-41b0-b356-b47ba547d8f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21c9c245-78da-41b0-b356-b47ba547d8f8_0">
											<gml:posList>35.67267105188199 139.73982378390528 34.971 35.67266604568428 139.73983078222594 34.971 35.67266604568428 139.73983078222594 37.345 35.67267105188199 139.73982378390528 37.345 35.67267105188199 139.73982378390528 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6da33556-838c-4cca-9fac-0c28d1ec5cd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6da33556-838c-4cca-9fac-0c28d1ec5cd1_0">
											<gml:posList>35.67265769772797 139.73982917916243 34.971 35.672653096495395 139.7398353374698 34.971 35.672653096495395 139.7398353374698 37.401 35.67265769772797 139.73982917916243 37.401 35.67265769772797 139.73982917916243 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-375c2728-55f5-43ca-aa17-681718ec9e28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-375c2728-55f5-43ca-aa17-681718ec9e28_0">
											<gml:posList>35.67267105188199 139.73982378390528 34.971 35.67267105188199 139.73982378390528 37.345 35.6726933253592 139.7398477179538 37.345 35.6726933253592 139.7398477179538 34.971 35.67267105188199 139.73982378390528 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7db131a8-beaf-42d0-be01-d66b84f10bf7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7db131a8-beaf-42d0-be01-d66b84f10bf7_0">
											<gml:posList>35.67260727357829 139.73980421750014 34.971 35.67260727357829 139.73980421750014 36.672 35.67266729250186 139.7398693775031 36.672 35.67266729250186 139.7398693775031 34.971 35.67260727357829 139.73980421750014 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c676fd98-6019-408f-980d-55e77ce756da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c676fd98-6019-408f-980d-55e77ce756da_0">
											<gml:posList>35.672665761798754 139.73987147813673 34.971 35.672665761798754 139.73987147813673 36.672 35.67260373111801 139.73980413326032 36.672 35.67260373111801 139.73980413326032 34.971 35.672665761798754 139.73987147813673 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13fa0641-73cb-4b9b-985e-5374950a44b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13fa0641-73cb-4b9b-985e-5374950a44b8_0">
											<gml:posList>35.67272240352175 139.73983595257604 34.971 35.672717928343715 139.73984193399573 34.971 35.672717928343715 139.73984193399573 36.507 35.67272240352175 139.73983595257604 36.507 35.67272240352175 139.73983595257604 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3983bb75-f9c2-446d-b83d-86f92a5b939b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3983bb75-f9c2-446d-b83d-86f92a5b939b_0">
											<gml:posList>35.6726883101464 139.73985471628544 37.345 35.6726933253592 139.7398477179538 37.345 35.67267105188199 139.73982378390528 37.345 35.67266604568428 139.73983078222594 37.345 35.6726883101464 139.73985471628544 37.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78e80042-2507-41cd-8848-986845bf33cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78e80042-2507-41cd-8848-986845bf33cf_0">
											<gml:posList>35.67266604568428 139.73983078222594 34.971 35.6726883101464 139.73985471628544 34.971 35.6726883101464 139.73985471628544 37.345 35.67266604568428 139.73983078222594 37.345 35.67266604568428 139.73983078222594 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-104e3270-c7b5-4e36-b0b0-5455b116d7e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-104e3270-c7b5-4e36-b0b0-5455b116d7e3_0">
											<gml:posList>35.672684004675915 139.73985869807325 34.971 35.67265769772797 139.73982917916243 34.971 35.67265769772797 139.73982917916243 37.401 35.672684004675915 139.73985869807325 37.401 35.672684004675915 139.73985869807325 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30dbd99c-d98e-42ab-8d86-7aef13f66a0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30dbd99c-d98e-42ab-8d86-7aef13f66a0f_0">
											<gml:posList>35.67272240352175 139.73983595257604 34.971 35.67272240352175 139.73983595257604 36.507 35.67273697341455 139.7398523397616 36.507 35.67273697341455 139.7398523397616 34.971 35.67272240352175 139.73983595257604 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5110f929-4736-4572-83fd-24bb68036aca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5110f929-4736-4572-83fd-24bb68036aca_0">
											<gml:posList>35.67267940345043 139.7398648674275 37.401 35.672684004675915 139.73985869807325 37.401 35.67265769772797 139.73982917916243 37.401 35.672653096495395 139.7398353374698 37.401 35.67267940345043 139.7398648674275 37.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87303496-0fcb-4326-a18f-3b140e7f98e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87303496-0fcb-4326-a18f-3b140e7f98e4_0">
											<gml:posList>35.672717928343715 139.73984193399573 36.507 35.67273249823572 139.73985832118143 36.507 35.67273697341455 139.7398523397616 36.507 35.67272240352175 139.73983595257604 36.507 35.672717928343715 139.73984193399573 36.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1fe02c8-9a5c-4138-8cb8-f7437b3c0838">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1fe02c8-9a5c-4138-8cb8-f7437b3c0838_0">
											<gml:posList>35.672653096495395 139.7398353374698 34.971 35.67267940345043 139.7398648674275 34.971 35.67267940345043 139.7398648674275 37.401 35.672653096495395 139.7398353374698 37.401 35.672653096495395 139.7398353374698 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4ba764c-11a4-4e8d-8011-befe97bc8960">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4ba764c-11a4-4e8d-8011-befe97bc8960_0">
											<gml:posList>35.672717928343715 139.73984193399573 34.971 35.67273249823572 139.73985832118143 34.971 35.67273249823572 139.73985832118143 36.507 35.672717928343715 139.73984193399573 36.507 35.672717928343715 139.73984193399573 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a3c3dfb-ee85-4d46-997b-83968f81c77b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a3c3dfb-ee85-4d46-997b-83968f81c77b_0">
											<gml:posList>35.6726883101464 139.73985471628544 34.971 35.6726933253592 139.7398477179538 34.971 35.6726933253592 139.7398477179538 37.345 35.6726883101464 139.73985471628544 37.345 35.6726883101464 139.73985471628544 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f02c51a-0167-42bd-9c67-20c805346b50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f02c51a-0167-42bd-9c67-20c805346b50_0">
											<gml:posList>35.67273249823572 139.73985832118143 34.971 35.67273697341455 139.7398523397616 34.971 35.67273697341455 139.7398523397616 36.507 35.67273249823572 139.73985832118143 36.507 35.67273249823572 139.73985832118143 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f62c75b-2ee2-4e86-aca3-265aded5a4d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f62c75b-2ee2-4e86-aca3-265aded5a4d4_0">
											<gml:posList>35.67267940345043 139.7398648674275 34.971 35.672684004675915 139.73985869807325 34.971 35.672684004675915 139.73985869807325 37.401 35.67267940345043 139.7398648674275 37.401 35.67267940345043 139.7398648674275 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0293d548-1406-4e6d-8021-cf6ca2bfdc94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0293d548-1406-4e6d-8021-cf6ca2bfdc94_0">
											<gml:posList>35.672665761798754 139.73987147813673 34.971 35.67266729250186 139.7398693775031 34.971 35.67266729250186 139.7398693775031 36.672 35.672665761798754 139.73987147813673 36.672 35.672665761798754 139.73987147813673 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c568a33f-8847-46f7-8681-7143f27ba710">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c568a33f-8847-46f7-8681-7143f27ba710">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c568a33f-8847-46f7-8681-7143f27ba710">
											<gml:posList>35.67266041555551 139.73969603164167 7.73 35.67274220208245 139.73978361286066 7.73 35.67272515903796 139.7398092829124 7.73 35.672754972061306 139.73983845530853 7.73 35.67276998747131 139.7398133620413 7.73 35.672773875627215 139.7398175331164 7.73 35.67270479528996 139.73992316376464 7.73 35.67258838530594 139.73979840695 7.73 35.67266041555551 139.73969603164167 7.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79b30a53-1652-4f75-bff2-e644d3e013dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79b30a53-1652-4f75-bff2-e644d3e013dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79b30a53-1652-4f75-bff2-e644d3e013dc">
											<gml:posList>35.67274002331139 139.73978689623863 34.971 35.67266077190962 139.73970222835325 34.971 35.67270176499521 139.73974687493714 34.971 35.67273189626901 139.7397795928834 34.971 35.67274002331139 139.73978689623863 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-440479c3-c906-49a0-9fe6-2e72e9c2a0bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-440479c3-c906-49a0-9fe6-2e72e9c2a0bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-440479c3-c906-49a0-9fe6-2e72e9c2a0bc">
											<gml:posList>35.672593405612886 139.73979797027684 35.55 35.67266077190962 139.73970222835325 35.55 35.67266041555551 139.73969603164167 35.55 35.67258838530594 139.73979840695 35.55 35.672593405612886 139.73979797027684 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f3167d3a-3081-4a53-bcfa-0421a45ddcbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3167d3a-3081-4a53-bcfa-0421a45ddcbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3167d3a-3081-4a53-bcfa-0421a45ddcbb">
											<gml:posList>35.67270433971061 139.7399168566985 35.55 35.672593405612886 139.73979797027684 35.55 35.67258838530594 139.73979840695 35.55 35.67270479528996 139.73992316376464 35.55 35.67270433971061 139.7399168566985 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-076a9b0f-cdfc-4e64-8c8e-eba99d88009e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-076a9b0f-cdfc-4e64-8c8e-eba99d88009e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-076a9b0f-cdfc-4e64-8c8e-eba99d88009e">
											<gml:posList>35.672593405612886 139.73979797027684 34.971 35.6726850894952 139.7397699375626 34.971 35.67270176499521 139.73974687493714 34.971 35.67266077190962 139.73970222835325 34.971 35.672593405612886 139.73979797027684 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a9d6e4f-72ff-400c-af69-93a3dfe15d5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a9d6e4f-72ff-400c-af69-93a3dfe15d5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a9d6e4f-72ff-400c-af69-93a3dfe15d5d">
											<gml:posList>35.67270433971061 139.7399168566985 34.971 35.67271522977655 139.73980265550028 34.971 35.6726850894952 139.7397699375626 34.971 35.672593405612886 139.73979797027684 34.971 35.67270433971061 139.7399168566985 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6f05c5ac-59c5-4447-b329-a8e5c00a64bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f05c5ac-59c5-4447-b329-a8e5c00a64bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f05c5ac-59c5-4447-b329-a8e5c00a64bc">
											<gml:posList>35.67269017294949 139.73976956709288 39.115 35.67270207631244 139.739753115891 39.115 35.67270176499521 139.73974687493714 39.115 35.6726850894952 139.7397699375626 39.115 35.67269017294949 139.73976956709288 39.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2fafdcb7-95dd-4b42-9f73-6a498e4732f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fafdcb7-95dd-4b42-9f73-6a498e4732f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fafdcb7-95dd-4b42-9f73-6a498e4732f0">
											<gml:posList>35.6726850894952 139.7397699375626 39.115 35.67271522977655 139.73980265550028 39.115 35.67271490945675 139.73979642560226 39.115 35.67269017294949 139.73976956709288 39.115 35.6726850894952 139.7397699375626 39.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fc741058-ea84-4273-94ba-d90723213df3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc741058-ea84-4273-94ba-d90723213df3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc741058-ea84-4273-94ba-d90723213df3">
											<gml:posList>35.67266077190962 139.73970222835325 35.55 35.67274002331139 139.73978689623863 35.55 35.67274220208245 139.73978361286066 35.55 35.67266041555551 139.73969603164167 35.55 35.67266077190962 139.73970222835325 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-62f796dc-b541-4b38-889c-ad2d5c14e6d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62f796dc-b541-4b38-889c-ad2d5c14e6d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62f796dc-b541-4b38-889c-ad2d5c14e6d3">
											<gml:posList>35.67270207631244 139.739753115891 38.919 35.67269017294949 139.73976956709288 38.919 35.67271490945675 139.73979642560226 38.919 35.6727268038096 139.73977997440977 38.919 35.67270207631244 139.739753115891 38.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98e25125-f4b5-4be9-a204-b6ba6f585c23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98e25125-f4b5-4be9-a204-b6ba6f585c23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98e25125-f4b5-4be9-a204-b6ba6f585c23">
											<gml:posList>35.67270176499521 139.73974687493714 39.115 35.67270207631244 139.739753115891 39.115 35.6727268038096 139.73977997440977 39.115 35.67273189626901 139.7397795928834 39.115 35.67270176499521 139.73974687493714 39.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-34575587-9d3a-45d7-89c3-f2ef539c65b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34575587-9d3a-45d7-89c3-f2ef539c65b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34575587-9d3a-45d7-89c3-f2ef539c65b6">
											<gml:posList>35.67273189626901 139.7397795928834 39.115 35.6727268038096 139.73977997440977 39.115 35.67271490945675 139.73979642560226 39.115 35.67271522977655 139.73980265550028 39.115 35.67273189626901 139.7397795928834 39.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d45ee5be-4466-4470-8af9-8577e1570adb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d45ee5be-4466-4470-8af9-8577e1570adb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d45ee5be-4466-4470-8af9-8577e1570adb">
											<gml:posList>35.67273189626901 139.7397795928834 34.971 35.67271522977655 139.73980265550028 34.971 35.67272515903796 139.7398092829124 34.971 35.67274002331139 139.73978689623863 34.971 35.67273189626901 139.7397795928834 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5870f712-f97d-4e0c-b4d1-c343a50ade13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5870f712-f97d-4e0c-b4d1-c343a50ade13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5870f712-f97d-4e0c-b4d1-c343a50ade13">
											<gml:posList>35.672753127190894 139.7398422464391 34.971 35.672754972061306 139.73983845530853 34.971 35.67272515903796 139.7398092829124 34.971 35.67271522977655 139.73980265550028 34.971 35.67270433971061 139.7399168566985 34.971 35.672753127190894 139.7398422464391 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-364eb804-c42a-411f-9749-5d6dab73e737">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-364eb804-c42a-411f-9749-5d6dab73e737">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-364eb804-c42a-411f-9749-5d6dab73e737">
											<gml:posList>35.672773875627215 139.7398175331164 35.55 35.67276998747131 139.7398133620413 35.55 35.672754972061306 139.73983845530853 35.55 35.672753127190894 139.7398422464391 35.55 35.67270433971061 139.7399168566985 35.55 35.67270479528996 139.73992316376464 35.55 35.672773875627215 139.7398175331164 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5bbbe82c-7e71-4de8-8881-4b7db256b6d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bbbe82c-7e71-4de8-8881-4b7db256b6d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bbbe82c-7e71-4de8-8881-4b7db256b6d4">
											<gml:posList>35.67266041555551 139.73969603164167 7.73 35.67266041555551 139.73969603164167 35.55 35.67274220208245 139.73978361286066 35.55 35.67274220208245 139.73978361286066 7.73 35.67266041555551 139.73969603164167 7.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72d8571d-7b78-4d2a-8800-5b4a3c1971cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72d8571d-7b78-4d2a-8800-5b4a3c1971cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72d8571d-7b78-4d2a-8800-5b4a3c1971cb">
											<gml:posList>35.67270207631244 139.739753115891 38.919 35.6727268038096 139.73977997440977 38.919 35.6727268038096 139.73977997440977 39.115 35.67270207631244 139.739753115891 39.115 35.67270207631244 139.739753115891 38.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c7c8c48-4932-40fe-b168-70c41f5a686c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c7c8c48-4932-40fe-b168-70c41f5a686c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c7c8c48-4932-40fe-b168-70c41f5a686c">
											<gml:posList>35.67271490945675 139.73979642560226 38.919 35.67269017294949 139.73976956709288 38.919 35.67269017294949 139.73976956709288 39.115 35.67271490945675 139.73979642560226 39.115 35.67271490945675 139.73979642560226 38.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5a863b4-a153-4bc5-91ce-9d47bca845bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5a863b4-a153-4bc5-91ce-9d47bca845bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5a863b4-a153-4bc5-91ce-9d47bca845bf">
											<gml:posList>35.67266077190962 139.73970222835325 34.971 35.67274002331139 139.73978689623863 34.971 35.67274002331139 139.73978689623863 35.55 35.67266077190962 139.73970222835325 35.55 35.67266077190962 139.73970222835325 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4daa17d-8121-426e-bd9d-b06d26c643c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4daa17d-8121-426e-bd9d-b06d26c643c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4daa17d-8121-426e-bd9d-b06d26c643c9">
											<gml:posList>35.67258838530594 139.73979840695 35.55 35.67266041555551 139.73969603164167 35.55 35.67266041555551 139.73969603164167 7.73 35.67258838530594 139.73979840695 7.73 35.67258838530594 139.73979840695 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7b92989-722f-4fc3-83ae-c4bcd1330e83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7b92989-722f-4fc3-83ae-c4bcd1330e83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7b92989-722f-4fc3-83ae-c4bcd1330e83">
											<gml:posList>35.672593405612886 139.73979797027684 34.971 35.67266077190962 139.73970222835325 34.971 35.67266077190962 139.73970222835325 35.55 35.672593405612886 139.73979797027684 35.55 35.672593405612886 139.73979797027684 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4047f168-92a2-4bc9-8640-27c988c21010">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4047f168-92a2-4bc9-8640-27c988c21010">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4047f168-92a2-4bc9-8640-27c988c21010">
											<gml:posList>35.6726850894952 139.7397699375626 39.115 35.67270176499521 139.73974687493714 39.115 35.67270176499521 139.73974687493714 34.971 35.6726850894952 139.7397699375626 34.971 35.6726850894952 139.7397699375626 39.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1cbac366-21ff-43ce-b4e0-f461d97340e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cbac366-21ff-43ce-b4e0-f461d97340e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cbac366-21ff-43ce-b4e0-f461d97340e5">
											<gml:posList>35.67269017294949 139.73976956709288 38.919 35.67270207631244 139.739753115891 38.919 35.67270207631244 139.739753115891 39.115 35.67269017294949 139.73976956709288 39.115 35.67269017294949 139.73976956709288 38.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c367a68a-c89c-4909-9522-03d02b65ee4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c367a68a-c89c-4909-9522-03d02b65ee4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c367a68a-c89c-4909-9522-03d02b65ee4e">
											<gml:posList>35.67270176499521 139.73974687493714 39.115 35.67273189626901 139.7397795928834 39.115 35.67273189626901 139.7397795928834 34.971 35.67270176499521 139.73974687493714 34.971 35.67270176499521 139.73974687493714 39.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-072a2714-b7c0-41fd-a53b-0552e7f5ccb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-072a2714-b7c0-41fd-a53b-0552e7f5ccb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-072a2714-b7c0-41fd-a53b-0552e7f5ccb9">
											<gml:posList>35.67271522977655 139.73980265550028 39.115 35.6726850894952 139.7397699375626 39.115 35.6726850894952 139.7397699375626 34.971 35.67271522977655 139.73980265550028 34.971 35.67271522977655 139.73980265550028 39.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38fdc706-1ee3-4110-ab42-9d5d620358db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38fdc706-1ee3-4110-ab42-9d5d620358db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38fdc706-1ee3-4110-ab42-9d5d620358db">
											<gml:posList>35.6727268038096 139.73977997440977 38.919 35.67271490945675 139.73979642560226 38.919 35.67271490945675 139.73979642560226 39.115 35.6727268038096 139.73977997440977 39.115 35.6727268038096 139.73977997440977 38.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b08bc32f-4260-4bfe-94f9-5653e1949017">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b08bc32f-4260-4bfe-94f9-5653e1949017">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b08bc32f-4260-4bfe-94f9-5653e1949017">
											<gml:posList>35.67273189626901 139.7397795928834 39.115 35.67271522977655 139.73980265550028 39.115 35.67271522977655 139.73980265550028 34.971 35.67273189626901 139.7397795928834 34.971 35.67273189626901 139.7397795928834 39.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b046f38e-1473-4532-826d-bfe9d5189e27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b046f38e-1473-4532-826d-bfe9d5189e27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b046f38e-1473-4532-826d-bfe9d5189e27">
											<gml:posList>35.67274002331139 139.73978689623863 34.971 35.67272515903796 139.7398092829124 34.971 35.67272515903796 139.7398092829124 7.73 35.67274220208245 139.73978361286066 7.73 35.67274220208245 139.73978361286066 35.55 35.67274002331139 139.73978689623863 35.55 35.67274002331139 139.73978689623863 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afb69681-0a14-4c36-b340-c90d818d27bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afb69681-0a14-4c36-b340-c90d818d27bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afb69681-0a14-4c36-b340-c90d818d27bb">
											<gml:posList>35.672773875627215 139.7398175331164 35.55 35.672773875627215 139.7398175331164 7.73 35.67276998747131 139.7398133620413 7.73 35.67276998747131 139.7398133620413 35.55 35.672773875627215 139.7398175331164 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77079396-b11a-47a9-b209-88f70d253144">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77079396-b11a-47a9-b209-88f70d253144">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77079396-b11a-47a9-b209-88f70d253144">
											<gml:posList>35.672754972061306 139.73983845530853 34.971 35.672754972061306 139.73983845530853 7.73 35.67272515903796 139.7398092829124 7.73 35.67272515903796 139.7398092829124 34.971 35.672754972061306 139.73983845530853 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-849e98e0-21c1-4f67-9a04-b7d02900690f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-849e98e0-21c1-4f67-9a04-b7d02900690f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-849e98e0-21c1-4f67-9a04-b7d02900690f">
											<gml:posList>35.67276998747131 139.7398133620413 35.55 35.67276998747131 139.7398133620413 7.73 35.672754972061306 139.73983845530853 7.73 35.672754972061306 139.73983845530853 34.971 35.672754972061306 139.73983845530853 35.55 35.67276998747131 139.7398133620413 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e95b4eb-8166-4890-b0da-be4c3b4ad4a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e95b4eb-8166-4890-b0da-be4c3b4ad4a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e95b4eb-8166-4890-b0da-be4c3b4ad4a8">
											<gml:posList>35.672754972061306 139.73983845530853 34.971 35.672753127190894 139.7398422464391 34.971 35.672753127190894 139.7398422464391 35.55 35.672754972061306 139.73983845530853 35.55 35.672754972061306 139.73983845530853 34.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27748790-6397-4025-a046-0386de698598">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27748790-6397-4025-a046-0386de698598">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27748790-6397-4025-a046-0386de698598">
											<gml:posList>35.672593405612886 139.73979797027684 35.55 35.67270433971061 139.7399168566985 35.55 35.67270433971061 139.7399168566985 34.971 35.672593405612886 139.73979797027684 34.971 35.672593405612886 139.73979797027684 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8869491-f427-4745-8f11-77fe58fd92ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8869491-f427-4745-8f11-77fe58fd92ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8869491-f427-4745-8f11-77fe58fd92ac">
											<gml:posList>35.67270479528996 139.73992316376464 7.73 35.67270479528996 139.73992316376464 35.55 35.67258838530594 139.73979840695 35.55 35.67258838530594 139.73979840695 7.73 35.67270479528996 139.73992316376464 7.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8e14621-2a0c-4f36-a8d1-76939c54c166">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8e14621-2a0c-4f36-a8d1-76939c54c166">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8e14621-2a0c-4f36-a8d1-76939c54c166">
											<gml:posList>35.67270479528996 139.73992316376464 35.55 35.67270479528996 139.73992316376464 7.73 35.672773875627215 139.7398175331164 7.73 35.672773875627215 139.7398175331164 35.55 35.67270479528996 139.73992316376464 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f114c2b9-d412-4bf5-bea3-e895e3e101ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f114c2b9-d412-4bf5-bea3-e895e3e101ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f114c2b9-d412-4bf5-bea3-e895e3e101ca">
											<gml:posList>35.67270433971061 139.7399168566985 35.55 35.672753127190894 139.7398422464391 35.55 35.672753127190894 139.7398422464391 34.971 35.67270433971061 139.7399168566985 34.971 35.67270433971061 139.7399168566985 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-43</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">183.45325</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.09</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>