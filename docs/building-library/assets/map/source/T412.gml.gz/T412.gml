<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_77fe66cf-eaa1-43b2-ab48-0d1eb34b83da">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>8</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101008003</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>霞が関三丁目南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">17.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67214105628249 139.74757688162452 0 35.67214816870412 139.7475650542577 0 35.671899500611204 139.7473412978806 0 35.67174509110125 139.74758802021992 0 35.67179513582188 139.74761403633116 0 35.67179189756572 139.74762342927988 0 35.67209541092675 139.74777985458917 0 35.672161434767226 139.74758735400692 0 35.67214105628249 139.74757688162452 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67214105628249 139.74757688162452 7.4 35.672161434767226 139.74758735400692 7.4 35.67209541092675 139.74777985458917 7.4 35.67179189756572 139.74762342927988 7.4 35.67179513582188 139.74761403633116 7.4 35.67174509110125 139.74758802021992 7.4 35.671899500611204 139.7473412978806 7.4 35.67214816870412 139.7475650542577 7.4 35.67214105628249 139.74757688162452 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67214105628249 139.74757688162452 7.4 35.67214816870412 139.7475650542577 7.4 35.67214816870412 139.7475650542577 25.189999999999998 35.67214105628249 139.74757688162452 25.189999999999998 35.67214105628249 139.74757688162452 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67214816870412 139.7475650542577 7.4 35.671899500611204 139.7473412978806 7.4 35.671899500611204 139.7473412978806 25.189999999999998 35.67214816870412 139.7475650542577 25.189999999999998 35.67214816870412 139.7475650542577 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671899500611204 139.7473412978806 7.4 35.67174509110125 139.74758802021992 7.4 35.67174509110125 139.74758802021992 25.189999999999998 35.671899500611204 139.7473412978806 25.189999999999998 35.671899500611204 139.7473412978806 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67174509110125 139.74758802021992 7.4 35.67179513582188 139.74761403633116 7.4 35.67179513582188 139.74761403633116 25.189999999999998 35.67174509110125 139.74758802021992 25.189999999999998 35.67174509110125 139.74758802021992 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179513582188 139.74761403633116 7.4 35.67179189756572 139.74762342927988 7.4 35.67179189756572 139.74762342927988 25.189999999999998 35.67179513582188 139.74761403633116 25.189999999999998 35.67179513582188 139.74761403633116 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179189756572 139.74762342927988 7.4 35.67209541092675 139.74777985458917 7.4 35.67209541092675 139.74777985458917 25.189999999999998 35.67179189756572 139.74762342927988 25.189999999999998 35.67179189756572 139.74762342927988 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67209541092675 139.74777985458917 7.4 35.672161434767226 139.74758735400692 7.4 35.672161434767226 139.74758735400692 25.189999999999998 35.67209541092675 139.74777985458917 25.189999999999998 35.67209541092675 139.74777985458917 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672161434767226 139.74758735400692 7.4 35.67214105628249 139.74757688162452 7.4 35.67214105628249 139.74757688162452 25.189999999999998 35.672161434767226 139.74758735400692 25.189999999999998 35.672161434767226 139.74758735400692 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67214105628249 139.74757688162452 25.189999999999998 35.67214816870412 139.7475650542577 25.189999999999998 35.671899500611204 139.7473412978806 25.189999999999998 35.67174509110125 139.74758802021992 25.189999999999998 35.67179513582188 139.74761403633116 25.189999999999998 35.67179189756572 139.74762342927988 25.189999999999998 35.67209541092675 139.74777985458917 25.189999999999998 35.672161434767226 139.74758735400692 25.189999999999998 35.67214105628249 139.74757688162452 25.189999999999998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f2b0c0f3-d2a7-4308-830e-8bcfc56428ac"/>
							<gml:surfaceMember xlink:href="#poly-9a58c1ff-4958-4bb1-9b3e-b49b8bb14602"/>
							<gml:surfaceMember xlink:href="#poly-b027fece-cffc-4cb8-bb06-dfa78f034315"/>
							<gml:surfaceMember xlink:href="#poly-64320ad8-feec-45fb-aa44-8134d292b4dd"/>
							<gml:surfaceMember xlink:href="#poly-dd4ab558-f057-443b-805d-deb1de503195"/>
							<gml:surfaceMember xlink:href="#poly-904a647d-0c86-4e21-8775-ac5d4ccc5325"/>
							<gml:surfaceMember xlink:href="#poly-1f935ffb-ba5a-493d-a833-0d6871dc07e2"/>
							<gml:surfaceMember xlink:href="#poly-a95f23ea-42bc-4db6-b9e5-0a19fc91d4a5"/>
							<gml:surfaceMember xlink:href="#poly-28dae203-566e-4b63-bb82-1dd59bed2233"/>
							<gml:surfaceMember xlink:href="#poly-1a6cb7fc-6919-4a4f-ad1b-e71031bf48e4"/>
							<gml:surfaceMember xlink:href="#poly-3a47a3da-2e79-4c8a-93bc-fafe2b79db46"/>
							<gml:surfaceMember xlink:href="#poly-53ecf4d4-41fc-4126-9c42-ff0dd6bfef1a"/>
							<gml:surfaceMember xlink:href="#poly-7d8bb0b2-18c4-4130-93bb-99911e51b02f"/>
							<gml:surfaceMember xlink:href="#poly-288a59fb-3124-43f7-ac12-71716c5f9389"/>
							<gml:surfaceMember xlink:href="#poly-d5de7a63-0722-496e-81c9-386f8a0c7814"/>
							<gml:surfaceMember xlink:href="#poly-f5d4b2fd-7191-4d0b-bb64-041017dc62a5"/>
							<gml:surfaceMember xlink:href="#poly-1c235c08-3b87-468e-b472-1f391d041f48"/>
							<gml:surfaceMember xlink:href="#poly-067dfc5e-30af-4eb8-aea2-1443f02a3efd"/>
							<gml:surfaceMember xlink:href="#poly-2bde59eb-4c6c-4741-86de-ce484536a427"/>
							<gml:surfaceMember xlink:href="#poly-d58fe445-0443-4707-951c-a88c06ac60b2"/>
							<gml:surfaceMember xlink:href="#poly-b05f138a-0a2d-49cd-85f2-ff5802a76c6b"/>
							<gml:surfaceMember xlink:href="#poly-ff5544b2-49ba-46e6-8086-93d13d62a445"/>
							<gml:surfaceMember xlink:href="#poly-9810fb52-168f-4907-b30d-f84bb39c55a3"/>
							<gml:surfaceMember xlink:href="#poly-9bf29e21-d0d9-4272-b9f1-20b720760da0"/>
							<gml:surfaceMember xlink:href="#poly-0088eb39-09a4-4f2c-aae1-22ea9ee26954"/>
							<gml:surfaceMember xlink:href="#poly-3923d60a-464b-46b5-a5dc-cef401ddf727"/>
							<gml:surfaceMember xlink:href="#poly-be0d5d40-fe4b-4057-a5bb-6fe68820db5b"/>
							<gml:surfaceMember xlink:href="#poly-c34821fd-fbc2-479d-b61b-9d601d22f3ab"/>
							<gml:surfaceMember xlink:href="#poly-6a1ffd5d-dbda-4516-9b03-dc2099adaab6"/>
							<gml:surfaceMember xlink:href="#poly-7f80cece-ee04-48df-a626-33c42171e677"/>
							<gml:surfaceMember xlink:href="#poly-51e97eb4-209e-4d49-8531-50bccf6063fe"/>
							<gml:surfaceMember xlink:href="#poly-11dd1932-921a-4578-bdd4-f83e5747d793"/>
							<gml:surfaceMember xlink:href="#poly-ffb6f9e7-c4e4-4e73-9cda-022b9c085cca"/>
							<gml:surfaceMember xlink:href="#poly-68538651-ca5f-4b0a-b25d-47310f861f9d"/>
							<gml:surfaceMember xlink:href="#poly-b00a5028-4ce6-4eb2-b7b2-607fb8b3d35f"/>
							<gml:surfaceMember xlink:href="#poly-0529895a-fde1-4c30-8cf1-bd05ece4152d"/>
							<gml:surfaceMember xlink:href="#poly-143e84dd-8ba8-4d09-b74a-51c5498b00d2"/>
							<gml:surfaceMember xlink:href="#poly-67ca3e61-73ed-48ed-a685-ed2ec472bc07"/>
							<gml:surfaceMember xlink:href="#poly-e2040bc3-cefe-4c48-9bc6-b2bd31fe049c"/>
							<gml:surfaceMember xlink:href="#poly-4fcfc505-e211-4cfe-99bd-bc1649a5aa74"/>
							<gml:surfaceMember xlink:href="#poly-96410c62-7d4b-4db3-b0c4-62edf55f1d67"/>
							<gml:surfaceMember xlink:href="#poly-a357590b-629a-497a-970f-80ab7d9db2b6"/>
							<gml:surfaceMember xlink:href="#poly-774cc937-baed-4217-9ee1-c0f335a3fd56"/>
							<gml:surfaceMember xlink:href="#poly-eea350c6-afd5-4485-9647-0277a92cfff2"/>
							<gml:surfaceMember xlink:href="#poly-66df2721-8b6b-462d-9336-23e5211c3b45"/>
							<gml:surfaceMember xlink:href="#poly-5b1801a9-b300-42af-ad28-f5cd36b6c7d1"/>
							<gml:surfaceMember xlink:href="#poly-31eb1b08-1ee8-4656-8255-ec3d77989ed0"/>
							<gml:surfaceMember xlink:href="#poly-07bb8b6a-1deb-46de-a935-a10579ebfd00"/>
							<gml:surfaceMember xlink:href="#poly-cee7b6b2-39d3-467e-ba5d-9efb045cebaa"/>
							<gml:surfaceMember xlink:href="#poly-745e011a-70d4-40d2-a44e-412c256c7104"/>
							<gml:surfaceMember xlink:href="#poly-2647c16b-304c-4f37-ba33-496d324f9688"/>
							<gml:surfaceMember xlink:href="#poly-5cee1ba8-b5ec-44e2-92c8-772ea8d3c062"/>
							<gml:surfaceMember xlink:href="#poly-21b153eb-eed3-4f64-81a6-990cd7731eb1"/>
							<gml:surfaceMember xlink:href="#poly-78df1595-0964-471c-a0b2-fc09c046af34"/>
							<gml:surfaceMember xlink:href="#poly-a08ec06b-f443-4907-a907-fb2d2debe24e"/>
							<gml:surfaceMember xlink:href="#poly-18cf3d13-84cc-4636-9d84-1dd066bd22d4"/>
							<gml:surfaceMember xlink:href="#poly-c91da311-4099-437e-a3a2-702ab0f5f0fd"/>
							<gml:surfaceMember xlink:href="#poly-4c23ee4b-a1fc-4760-b8d8-38f25412a0ef"/>
							<gml:surfaceMember xlink:href="#poly-6475a86e-f61f-48c3-bb50-9902598def88"/>
							<gml:surfaceMember xlink:href="#poly-7e4ce829-1247-44b2-b53c-de6135761139"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_77fe66cf-eaa1-43b2-ab48-0d1eb34b83da_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe8315e8-eb7b-43ef-a02e-925acb79a505">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe8315e8-eb7b-43ef-a02e-925acb79a505_0">
											<gml:posList>35.67187674537504 139.74756235103192 25.7 35.67187674537504 139.74756235103192 25.019 35.67184899996897 139.74754808659205 25.019 35.67184899996897 139.74754808659205 25.7 35.67187674537504 139.74756235103192 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be0a411e-8792-4704-8c28-0a9531beea02">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be0a411e-8792-4704-8c28-0a9531beea02_0">
											<gml:posList>35.67187037621786 139.74759264725404 25.019 35.67190233178968 139.74760797871886 25.019 35.67190233178968 139.74760797871886 25.7 35.67187037621786 139.74759264725404 25.7 35.67187037621786 139.74759264725404 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94d85678-0ca3-4875-9297-1ef210e8cbbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94d85678-0ca3-4875-9297-1ef210e8cbbe_0">
											<gml:posList>35.67190502991336 139.7475995584236 25.019 35.671873074332616 139.74758421591514 25.019 35.671873074332616 139.74758421591514 25.7 35.67190502991336 139.7475995584236 25.7 35.67190502991336 139.7475995584236 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c34363bc-a75f-4d88-961d-5a3a36daf87f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c34363bc-a75f-4d88-961d-5a3a36daf87f_0">
											<gml:posList>35.67198954790879 139.74750573864466 25.019 35.67196219445088 139.74758615314852 25.019 35.67196219445088 139.74758615314852 25.7 35.67198954790879 139.74750573864466 25.7 35.67198954790879 139.74750573864466 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-313a2836-4047-477f-b470-bc80000d355f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-313a2836-4047-477f-b470-bc80000d355f_0">
											<gml:posList>35.6719086517728 139.7473949186805 27.628 35.67189563085693 139.7473877855724 27.628 35.67189563085693 139.7473877855724 28.971 35.6719086517728 139.7473949186805 28.971 35.6719086517728 139.7473949186805 27.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d97f7bac-cb1a-48fa-9f76-4c6676e00f80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d97f7bac-cb1a-48fa-9f76-4c6676e00f80_0">
											<gml:posList>35.67189563085693 139.7473877855724 27.628 35.67189008026229 139.74740302460222 27.628 35.67189008026229 139.74740302460222 28.971 35.67189563085693 139.7473877855724 28.971 35.67189563085693 139.7473877855724 27.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2fc9756-3b83-43b6-9200-6c21ac67cf7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2fc9756-3b83-43b6-9200-6c21ac67cf7e_0">
											<gml:posList>35.67189008026229 139.74740302460222 28.971 35.67190310116938 139.74741014666586 28.971 35.6719086517728 139.7473949186805 28.971 35.67189563085693 139.7473877855724 28.971 35.67189008026229 139.74740302460222 28.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a381e3b0-345e-4acc-a7a8-60eeed677a86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a381e3b0-345e-4acc-a7a8-60eeed677a86_0">
											<gml:posList>35.67190310116938 139.74741014666586 27.628 35.6719086517728 139.7473949186805 27.628 35.6719086517728 139.7473949186805 28.971 35.67190310116938 139.74741014666586 28.971 35.67190310116938 139.74741014666586 27.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29556f83-c20f-4c7f-9aab-d9fe83aee27b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29556f83-c20f-4c7f-9aab-d9fe83aee27b_0">
											<gml:posList>35.671912938580704 139.7474023262677 27.628 35.671910186412155 139.74741077976776 27.628 35.671910186412155 139.74741077976776 28.596 35.671912938580704 139.7474023262677 28.596 35.671912938580704 139.7474023262677 27.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20c5ec45-4a24-4698-95c4-355c79ffa5c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20c5ec45-4a24-4698-95c4-355c79ffa5c6_0">
											<gml:posList>35.67189008026229 139.74740302460222 27.628 35.67190310116938 139.74741014666586 27.628 35.67190310116938 139.74741014666586 28.971 35.67189008026229 139.74740302460222 28.971 35.67189008026229 139.74740302460222 27.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-766e8b04-d69d-420f-bcaa-f9dbe4f76812">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-766e8b04-d69d-420f-bcaa-f9dbe4f76812_0">
											<gml:posList>35.67194123353333 139.74741615926692 27.628 35.671912938580704 139.7474023262677 27.628 35.671912938580704 139.7474023262677 28.596 35.67194123353333 139.74741615926692 28.596 35.67194123353333 139.74741615926692 27.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18e433d9-02e0-4f21-9334-6202dbf83eb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18e433d9-02e0-4f21-9334-6202dbf83eb4_0">
											<gml:posList>35.671910186412155 139.74741077976776 28.596 35.671938481371704 139.747424623816 28.596 35.67194123353333 139.74741615926692 28.596 35.671912938580704 139.7474023262677 28.596 35.671910186412155 139.74741077976776 28.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3b6664e-d023-4e59-8d77-4819a4f62b2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3b6664e-d023-4e59-8d77-4819a4f62b2e_0">
											<gml:posList>35.671910186412155 139.74741077976776 27.628 35.671938481371704 139.747424623816 27.628 35.671938481371704 139.747424623816 28.596 35.671910186412155 139.74741077976776 28.596 35.671910186412155 139.74741077976776 27.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0eac4ec-4ee7-4f0a-b939-e2a0b94356f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0eac4ec-4ee7-4f0a-b939-e2a0b94356f5_0">
											<gml:posList>35.671938481371704 139.747424623816 27.628 35.67194123353333 139.74741615926692 27.628 35.67194123353333 139.74741615926692 28.596 35.671938481371704 139.747424623816 28.596 35.671938481371704 139.747424623816 27.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-307947ac-0e8e-4652-a5cb-7224c01a5aa8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-307947ac-0e8e-4652-a5cb-7224c01a5aa8_0">
											<gml:posList>35.67186163331773 139.74744146364804 25.019 35.67186163331773 139.74744146364804 29.337 35.67198593168187 139.74750332333653 29.337 35.67198593168187 139.74750332333653 25.019 35.67186163331773 139.74744146364804 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29fdb3bb-45bd-4497-a09a-86097a809764">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29fdb3bb-45bd-4497-a09a-86097a809764_0">
											<gml:posList>35.67186163331773 139.74744146364804 25.019 35.671830575072654 139.74753426509236 25.019 35.671830575072654 139.74753426509236 29.337 35.67186163331773 139.74744146364804 29.337 35.67186163331773 139.74744146364804 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b11f359b-cce9-4f80-95ef-a64417713b9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b11f359b-cce9-4f80-95ef-a64417713b9c_0">
											<gml:posList>35.67186163331773 139.74744146364804 29.337 35.671830575072654 139.74753426509236 29.337 35.67195539694088 139.74759718480288 29.337 35.67198593168187 139.74750332333653 29.337 35.67186163331773 139.74744146364804 29.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50a73835-17fa-42fa-8124-a0b08b7536d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50a73835-17fa-42fa-8124-a0b08b7536d0_0">
											<gml:posList>35.67213337988782 139.7475815183198 25.019 35.67198954790879 139.74750573864466 25.019 35.67198954790879 139.74750573864466 25.7 35.67213337988782 139.7475815183198 25.7 35.67213337988782 139.7475815183198 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2dcdd7d-31ec-4475-9d40-5b5726c48e72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2dcdd7d-31ec-4475-9d40-5b5726c48e72_0">
											<gml:posList>35.67195539694088 139.74759718480288 25.019 35.67198593168187 139.74750332333653 25.019 35.67198593168187 139.74750332333653 29.337 35.67195539694088 139.74759718480288 29.337 35.67195539694088 139.74759718480288 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4106e8f-1088-4983-9c3e-30b5f67172a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4106e8f-1088-4983-9c3e-30b5f67172a6_0">
											<gml:posList>35.67184899996897 139.74754808659205 25.7 35.67184899996897 139.74754808659205 25.019 35.671846364433435 139.7475557887962 25.019 35.671846364433435 139.7475557887962 25.7 35.67184899996897 139.74754808659205 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76bda9a8-666f-4f77-b775-3bad6b4bbda0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76bda9a8-666f-4f77-b775-3bad6b4bbda0_0">
											<gml:posList>35.67184899996897 139.74754808659205 25.7 35.671846364433435 139.7475557887962 25.7 35.67187410983859 139.74757005323826 25.7 35.67187674537504 139.74756235103192 25.7 35.67184899996897 139.74754808659205 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dae399f7-adc6-4466-8be1-761f43ebf752">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dae399f7-adc6-4466-8be1-761f43ebf752_0">
											<gml:posList>35.671846364433435 139.7475557887962 25.7 35.671846364433435 139.7475557887962 25.019 35.67187410983859 139.74757005323826 25.019 35.67187410983859 139.74757005323826 25.7 35.671846364433435 139.7475557887962 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06281945-b93a-4938-b219-7320a6bb3039">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06281945-b93a-4938-b219-7320a6bb3039_0">
											<gml:posList>35.671830575072654 139.74753426509236 29.337 35.671830575072654 139.74753426509236 25.019 35.67195539694088 139.74759718480288 25.019 35.67195539694088 139.74759718480288 29.337 35.671830575072654 139.74753426509236 29.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d19a7425-a0a7-4011-b0d2-09084dde2cef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d19a7425-a0a7-4011-b0d2-09084dde2cef_0">
											<gml:posList>35.67187410983859 139.74757005323826 25.7 35.67187410983859 139.74757005323826 25.019 35.67187674537504 139.74756235103192 25.019 35.67187674537504 139.74756235103192 25.7 35.67187410983859 139.74757005323826 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4913dfc3-1b46-41ae-b5f8-f22715abb49d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4913dfc3-1b46-41ae-b5f8-f22715abb49d_0">
											<gml:posList>35.67187872156763 139.74756541983547 25.7 35.67187872156763 139.74756541983547 25.019 35.6718762753585 139.7475731770717 25.019 35.6718762753585 139.7475731770717 25.7 35.67187872156763 139.74756541983547 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c251dcb6-4f37-4083-b668-82e3681d8c88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c251dcb6-4f37-4083-b668-82e3681d8c88_0">
											<gml:posList>35.67191152456648 139.74758093817462 25.7 35.67191152456648 139.74758093817462 25.019 35.67187872156763 139.74756541983547 25.019 35.67187872156763 139.74756541983547 25.7 35.67191152456648 139.74758093817462 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-415908d0-1b22-4123-8856-ce8c46f8d280">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-415908d0-1b22-4123-8856-ce8c46f8d280_0">
											<gml:posList>35.67184542752931 139.74756917811055 25.019 35.671842522477604 139.74757813989856 25.019 35.671842522477604 139.74757813989856 25.7 35.67184542752931 139.74756917811055 25.7 35.67184542752931 139.74756917811055 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-784c5ed1-0ca3-48ef-a0b0-259473ac2831">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-784c5ed1-0ca3-48ef-a0b0-259473ac2831_0">
											<gml:posList>35.6718675188353 139.74757994687502 25.019 35.67184542752931 139.74756917811055 25.019 35.67184542752931 139.74756917811055 25.7 35.6718675188353 139.74757994687502 25.7 35.6718675188353 139.74757994687502 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa2a0ab1-2ccc-4ba1-941b-dfefb949921e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa2a0ab1-2ccc-4ba1-941b-dfefb949921e_0">
											<gml:posList>35.67187872156763 139.74756541983547 25.7 35.6718762753585 139.7475731770717 25.7 35.67190908737008 139.74758869540392 25.7 35.67191152456648 139.74758093817462 25.7 35.67187872156763 139.74756541983547 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ca575ab-d419-46bf-8697-800397f46fcd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ca575ab-d419-46bf-8697-800397f46fcd_0">
											<gml:posList>35.671842522477604 139.74757813989856 25.7 35.671864604776935 139.7475889197212 25.7 35.6718675188353 139.74757994687502 25.7 35.67184542752931 139.74756917811055 25.7 35.671842522477604 139.74757813989856 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4c49fe3-f67a-40da-a7f1-8362e1b06e45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4c49fe3-f67a-40da-a7f1-8362e1b06e45_0">
											<gml:posList>35.6718762753585 139.7475731770717 25.7 35.6718762753585 139.7475731770717 25.019 35.67190908737008 139.74758869540392 25.019 35.67190908737008 139.74758869540392 25.7 35.6718762753585 139.7475731770717 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4a5bc26-52bc-4655-9174-0b22f84003fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4a5bc26-52bc-4655-9174-0b22f84003fa_0">
											<gml:posList>35.671842522477604 139.74757813989856 25.019 35.671864604776935 139.7475889197212 25.019 35.671864604776935 139.7475889197212 25.7 35.671842522477604 139.74757813989856 25.7 35.671842522477604 139.74757813989856 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a1c478e-3f56-4386-b047-f3dd4d72ada5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a1c478e-3f56-4386-b047-f3dd4d72ada5_0">
											<gml:posList>35.671864604776935 139.7475889197212 25.019 35.6718675188353 139.74757994687502 25.019 35.6718675188353 139.74757994687502 25.7 35.671864604776935 139.7475889197212 25.7 35.671864604776935 139.7475889197212 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e56f07a9-256e-4012-9a78-0dd07c1dd586">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e56f07a9-256e-4012-9a78-0dd07c1dd586_0">
											<gml:posList>35.67190908737008 139.74758869540392 25.7 35.67190908737008 139.74758869540392 25.019 35.67191152456648 139.74758093817462 25.019 35.67191152456648 139.74758093817462 25.7 35.67190908737008 139.74758869540392 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0354b997-7d3a-4a30-9fd1-ca783b7b8e7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0354b997-7d3a-4a30-9fd1-ca783b7b8e7d_0">
											<gml:posList>35.67198954790879 139.74750573864466 25.7 35.67196219445088 139.74758615314852 25.7 35.672095517054615 139.74765022383968 25.7 35.672127401074086 139.74766635079487 25.7 35.672153144888476 139.74759121810317 25.7 35.67213337988782 139.7475815183198 25.7 35.67198954790879 139.74750573864466 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6927d2b8-ed70-4e12-bb46-0ae175a0a7e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6927d2b8-ed70-4e12-bb46-0ae175a0a7e9_0">
											<gml:posList>35.672153144888476 139.74759121810317 25.019 35.67213337988782 139.7475815183198 25.019 35.67213337988782 139.7475815183198 25.7 35.672153144888476 139.74759121810317 25.7 35.672153144888476 139.74759121810317 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31b88903-ba98-46a1-b278-8a6cc260e8d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31b88903-ba98-46a1-b278-8a6cc260e8d3_0">
											<gml:posList>35.671873074332616 139.74758421591514 25.019 35.67187037621786 139.74759264725404 25.019 35.67187037621786 139.74759264725404 25.7 35.671873074332616 139.74758421591514 25.7 35.671873074332616 139.74758421591514 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc33b3c6-ecc6-4cf1-93f9-7ac77006ea24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc33b3c6-ecc6-4cf1-93f9-7ac77006ea24_0">
											<gml:posList>35.671834271509155 139.74758601380384 25.019 35.67183120443728 139.7475952961106 25.019 35.67183120443728 139.7475952961106 25.7 35.671834271509155 139.74758601380384 25.7 35.671834271509155 139.74758601380384 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3fb5444-beb0-40f3-87db-aaceb7ffa12f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3fb5444-beb0-40f3-87db-aaceb7ffa12f_0">
											<gml:posList>35.671860285332315 139.7475989545302 25.019 35.671834271509155 139.74758601380384 25.019 35.671834271509155 139.74758601380384 25.7 35.671860285332315 139.7475989545302 25.7 35.671860285332315 139.7475989545302 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69b88971-eff5-429b-a4bb-852d3b4824cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69b88971-eff5-429b-a4bb-852d3b4824cc_0">
											<gml:posList>35.67187037621786 139.74759264725404 25.7 35.67190233178968 139.74760797871886 25.7 35.67190502991336 139.7475995584236 25.7 35.671873074332616 139.74758421591514 25.7 35.67187037621786 139.74759264725404 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f2ed1d1-c4e0-4b8e-a317-916dffaebd2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f2ed1d1-c4e0-4b8e-a317-916dffaebd2f_0">
											<gml:posList>35.67183120443728 139.7475952961106 25.7 35.67185720924575 139.74760823684912 25.7 35.671860285332315 139.7475989545302 25.7 35.671834271509155 139.74758601380384 25.7 35.67183120443728 139.7475952961106 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40e87090-6d88-473c-8188-4fd626a37bc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40e87090-6d88-473c-8188-4fd626a37bc8_0">
											<gml:posList>35.67183120443728 139.7475952961106 25.019 35.67185720924575 139.74760823684912 25.019 35.67185720924575 139.74760823684912 25.7 35.67183120443728 139.7475952961106 25.7 35.67183120443728 139.7475952961106 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bf2d495-da21-4a84-8072-cd0408f3aeed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bf2d495-da21-4a84-8072-cd0408f3aeed_0">
											<gml:posList>35.67185720924575 139.74760823684912 25.019 35.671860285332315 139.7475989545302 25.019 35.671860285332315 139.7475989545302 25.7 35.67185720924575 139.74760823684912 25.7 35.67185720924575 139.74760823684912 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4d92209-db8a-4e7e-800a-9bc0da28207a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4d92209-db8a-4e7e-800a-9bc0da28207a_0">
											<gml:posList>35.67190233178968 139.74760797871886 25.019 35.67190502991336 139.7475995584236 25.019 35.67190502991336 139.7475995584236 25.7 35.67190233178968 139.74760797871886 25.7 35.67190233178968 139.74760797871886 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b5bdbbb-f38a-4145-82d3-c23cdf411a8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b5bdbbb-f38a-4145-82d3-c23cdf411a8c_0">
											<gml:posList>35.67186610232916 139.74760336689562 25.019 35.67186351214968 139.7476114777703 25.019 35.67186351214968 139.7476114777703 25.7 35.67186610232916 139.74760336689562 25.7 35.67186610232916 139.74760336689562 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-903cbc38-0679-495e-80cb-4cd965434851">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-903cbc38-0679-495e-80cb-4cd965434851_0">
											<gml:posList>35.671899076772654 139.7476191501799 25.019 35.67186610232916 139.74760336689562 25.019 35.67186610232916 139.74760336689562 25.7 35.671899076772654 139.7476191501799 25.7 35.671899076772654 139.7476191501799 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf9155cf-b893-4d18-94c0-3c006199f0c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf9155cf-b893-4d18-94c0-3c006199f0c5_0">
											<gml:posList>35.67186351214968 139.7476114777703 25.7 35.67189648659212 139.74762726105737 25.7 35.671899076772654 139.7476191501799 25.7 35.67186610232916 139.74760336689562 25.7 35.67186351214968 139.7476114777703 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9a2eb98-6005-46f1-a8ee-e752e5cad675">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9a2eb98-6005-46f1-a8ee-e752e5cad675_0">
											<gml:posList>35.67196219445088 139.74758615314852 25.019 35.672095517054615 139.74765022383968 25.019 35.672095517054615 139.74765022383968 25.7 35.67196219445088 139.74758615314852 25.7 35.67196219445088 139.74758615314852 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-955223da-3191-4b52-9117-10da046e9c5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-955223da-3191-4b52-9117-10da046e9c5c_0">
											<gml:posList>35.67186351214968 139.7476114777703 25.019 35.67189648659212 139.74762726105737 25.019 35.67189648659212 139.74762726105737 25.7 35.67186351214968 139.7476114777703 25.7 35.67186351214968 139.7476114777703 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18bda88e-e977-49d4-a2e0-306b1910f822">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18bda88e-e977-49d4-a2e0-306b1910f822_0">
											<gml:posList>35.67189648659212 139.74762726105737 25.019 35.671899076772654 139.7476191501799 25.019 35.671899076772654 139.7476191501799 25.7 35.67189648659212 139.74762726105737 25.7 35.67189648659212 139.74762726105737 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2e1a13f-3655-4d89-8ad0-a031e3050970">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2e1a13f-3655-4d89-8ad0-a031e3050970_0">
											<gml:posList>35.67202759369585 139.74763065577753 26.193 35.67202759369585 139.74763065577753 25.019 35.67200784652882 139.7476206798184 25.019 35.67200784652882 139.7476206798184 26.193 35.67202759369585 139.74763065577753 26.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0b1261e-115c-4bad-b19b-896555c6ebc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0b1261e-115c-4bad-b19b-896555c6ebc3_0">
											<gml:posList>35.67200784652882 139.7476206798184 26.193 35.67200784652882 139.7476206798184 25.019 35.672003789934145 139.74763275796215 25.019 35.672003789934145 139.74763275796215 26.193 35.67200784652882 139.7476206798184 26.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22968ae4-ee70-4139-95c7-fed52f5f3f1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22968ae4-ee70-4139-95c7-fed52f5f3f1e_0">
											<gml:posList>35.672127401074086 139.74766635079487 25.019 35.672153144888476 139.74759121810317 25.019 35.672153144888476 139.74759121810317 25.7 35.672127401074086 139.74766635079487 25.7 35.672127401074086 139.74766635079487 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c09f0091-ac7e-4cfc-b3d5-0ed95cac71c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c09f0091-ac7e-4cfc-b3d5-0ed95cac71c5_0">
											<gml:posList>35.67200784652882 139.7476206798184 26.193 35.672003789934145 139.74763275796215 26.193 35.67202352808646 139.74764273393336 26.193 35.67202759369585 139.74763065577753 26.193 35.67200784652882 139.7476206798184 26.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b1b355c-f3c8-4dbe-89fe-767fb5977e0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b1b355c-f3c8-4dbe-89fe-767fb5977e0c_0">
											<gml:posList>35.67202352808646 139.74764273393336 26.193 35.67202352808646 139.74764273393336 25.019 35.67202759369585 139.74763065577753 25.019 35.67202759369585 139.74763065577753 26.193 35.67202352808646 139.74764273393336 26.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb60e36c-2920-4e0a-a849-c6ab9a326643">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb60e36c-2920-4e0a-a849-c6ab9a326643_0">
											<gml:posList>35.672003789934145 139.74763275796215 26.193 35.672003789934145 139.74763275796215 25.019 35.67202352808646 139.74764273393336 25.019 35.67202352808646 139.74764273393336 26.193 35.672003789934145 139.74763275796215 26.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e15d68a3-4d7c-488f-b76e-959f9d1def2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e15d68a3-4d7c-488f-b76e-959f9d1def2d_0">
											<gml:posList>35.67207370361179 139.74764991575765 26.193 35.67207370361179 139.74764991575765 25.019 35.67205501134284 139.7476403473807 25.019 35.67205501134284 139.7476403473807 26.193 35.67207370361179 139.74764991575765 26.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2f2c4ed-6d63-4627-9032-2df6ecbd23b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2f2c4ed-6d63-4627-9032-2df6ecbd23b9_0">
											<gml:posList>35.67205501134284 139.7476403473807 26.193 35.67205501134284 139.7476403473807 25.019 35.672049443467095 139.74765668004434 25.019 35.672049443467095 139.74765668004434 26.193 35.67205501134284 139.7476403473807 26.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b81a9e85-fe57-44e2-840e-edd84c454899">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b81a9e85-fe57-44e2-840e-edd84c454899_0">
											<gml:posList>35.67206813573476 139.74766624842448 26.193 35.67207370361179 139.74764991575765 26.193 35.67205501134284 139.7476403473807 26.193 35.672049443467095 139.74765668004434 26.193 35.67206813573476 139.74766624842448 26.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b0d337b-9cfe-4892-af34-7569ac23c278">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b0d337b-9cfe-4892-af34-7569ac23c278_0">
											<gml:posList>35.67206813573476 139.74766624842448 26.193 35.67206813573476 139.74766624842448 25.019 35.67207370361179 139.74764991575765 25.019 35.67207370361179 139.74764991575765 26.193 35.67206813573476 139.74766624842448 26.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59e50ab5-ed91-4936-be3f-c08b0f9d6e8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59e50ab5-ed91-4936-be3f-c08b0f9d6e8d_0">
											<gml:posList>35.672095517054615 139.74765022383968 25.019 35.672127401074086 139.74766635079487 25.019 35.672127401074086 139.74766635079487 25.7 35.672095517054615 139.74765022383968 25.7 35.672095517054615 139.74765022383968 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8113a4b-25f2-4565-99c8-c925e1b40288">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8113a4b-25f2-4565-99c8-c925e1b40288_0">
											<gml:posList>35.67202068695217 139.747665525871 26.193 35.67202068695217 139.747665525871 25.019 35.67199443836342 139.7476519998846 25.019 35.67199443836342 139.7476519998846 26.193 35.67202068695217 139.747665525871 26.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1355f48-cfb3-4117-ae03-3b492f395e15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1355f48-cfb3-4117-ae03-3b492f395e15_0">
											<gml:posList>35.672049443467095 139.74765668004434 26.193 35.672049443467095 139.74765668004434 25.019 35.67206813573476 139.74766624842448 25.019 35.67206813573476 139.74766624842448 26.193 35.672049443467095 139.74765668004434 26.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d6bbf90-8772-4329-b6b3-6ed84a657e65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d6bbf90-8772-4329-b6b3-6ed84a657e65_0">
											<gml:posList>35.67199443836342 139.7476519998846 26.193 35.67199443836342 139.7476519998846 25.019 35.67198580307787 139.7476771509048 25.019 35.67198581209159 139.74767715089516 26.193 35.67199443836342 139.7476519998846 26.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0a53cbc-6ae2-4951-9c14-42f0f7f1d8b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0a53cbc-6ae2-4951-9c14-42f0f7f1d8b3_0">
											<gml:posList>35.67201205166384 139.747690676898 26.193 35.67202068695217 139.747665525871 26.193 35.67199443836342 139.7476519998846 26.193 35.67198581209159 139.74767715089516 26.193 35.67201205166384 139.747690676898 26.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3064d20-b60a-4b93-a459-7b697c054cf1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3064d20-b60a-4b93-a459-7b697c054cf1_0">
											<gml:posList>35.67201205166384 139.747690676898 26.193 35.67201205166384 139.747690676898 25.019 35.67202068695217 139.747665525871 25.019 35.67202068695217 139.747665525871 26.193 35.67201205166384 139.747690676898 26.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43be02b0-76af-4b15-a55b-8706663bbd2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43be02b0-76af-4b15-a55b-8706663bbd2f_0">
											<gml:posList>35.67198581209159 139.74767715089516 26.193 35.67198580307787 139.7476771509048 25.019 35.67201205166384 139.747690676898 25.019 35.67201205166384 139.747690676898 26.193 35.67198581209159 139.74767715089516 26.193</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e8208fe-927a-417c-b8cf-c32723437544">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67187674537504 139.74756235103192 25.019 35.67187410983859 139.74757005323826 25.019 35.671846364433435 139.7475557887962 25.019 35.67184899996897 139.74754808659205 25.019 35.67187674537504 139.74756235103192 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1a0275d-85df-4383-bfee-0cb54ebfb4f4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671864604776935 139.7475889197212 25.019 35.671842522477604 139.74757813989856 25.019 35.67184542752931 139.74756917811055 25.019 35.6718675188353 139.74757994687502 25.019 35.671864604776935 139.7475889197212 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48964ff5-14dd-413f-b427-508e6ee53400">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67190233178968 139.74760797871886 25.019 35.67187037621786 139.74759264725404 25.019 35.671873074332616 139.74758421591514 25.019 35.67190502991336 139.7475995584236 25.019 35.67190233178968 139.74760797871886 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-407271d7-fa1e-4b13-b868-e179a5c0253b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67185720924575 139.74760823684912 25.019 35.67183120443728 139.7475952961106 25.019 35.671834271509155 139.74758601380384 25.019 35.671860285332315 139.7475989545302 25.019 35.67185720924575 139.74760823684912 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec5340cc-9fa5-4026-8022-d58d6ee05388">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67189648659212 139.74762726105737 25.019 35.67186351214968 139.7476114777703 25.019 35.67186610232916 139.74760336689562 25.019 35.671899076772654 139.7476191501799 25.019 35.67189648659212 139.74762726105737 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e9aab8c-1b93-4d35-9c3e-f7767a40e76f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67191152456648 139.74758093817462 25.019 35.67190908737008 139.74758869540392 25.019 35.6718762753585 139.7475731770717 25.019 35.67187872156763 139.74756541983547 25.019 35.67191152456648 139.74758093817462 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7723a6da-f5f0-43e9-a25f-34457890afcc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67190310116938 139.74741014666586 27.628 35.67189008026229 139.74740302460222 27.628 35.67189563085693 139.7473877855724 27.628 35.6719086517728 139.7473949186805 27.628 35.67190310116938 139.74741014666586 27.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29a2312a-a1f8-4582-bd21-47389bf1eef0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671830575072654 139.74753426509236 25.019 35.67186163331773 139.74744146364804 25.019 35.67198593168187 139.74750332333653 25.019 35.67195539694088 139.74759718480288 25.019 35.671830575072654 139.74753426509236 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-451c5aab-9b6c-4b4c-a932-b6b0e1e95f65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671938481371704 139.747424623816 27.628 35.671910186412155 139.74741077976776 27.628 35.671912938580704 139.7474023262677 27.628 35.67194123353333 139.74741615926692 27.628 35.671938481371704 139.747424623816 27.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-925c3608-f299-4281-aea8-d9cf9e752d99">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67198580307787 139.7476771509048 25.019 35.67199443836342 139.7476519998846 25.019 35.67202068695217 139.747665525871 25.019 35.67201205166384 139.747690676898 25.019 35.67198580307787 139.7476771509048 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14d4908e-45bc-41ef-8271-bdd44d22f3ca">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67202759369585 139.74763065577753 25.019 35.67202352808646 139.74764273393336 25.019 35.672003789934145 139.74763275796215 25.019 35.67200784652882 139.7476206798184 25.019 35.67202759369585 139.74763065577753 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d756d35-cbd9-408e-b079-7e65eff99f52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672153144888476 139.74759121810317 25.019 35.672127401074086 139.74766635079487 25.019 35.672095517054615 139.74765022383968 25.019 35.67196219445088 139.74758615314852 25.019 35.67198954790879 139.74750573864466 25.019 35.67213337988782 139.7475815183198 25.019 35.672153144888476 139.74759121810317 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-224e7300-aab8-4632-8564-c87b1ff5e568">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672049443467095 139.74765668004434 25.019 35.67205501134284 139.7476403473807 25.019 35.67207370361179 139.74764991575765 25.019 35.67206813573476 139.74766624842448 25.019 35.672049443467095 139.74765668004434 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_77fe66cf-eaa1-43b2-ab48-0d1eb34b83da_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efc4d54e-a36f-4c7e-98d5-589113f395d3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671959320295215 139.74770186807652 25.019 35.67190247691436 139.74767257831957 25.019 35.67191037514126 139.74765033333463 25.019 35.67196721852742 139.7476796230787 25.019 35.671959320295215 139.74770186807652 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9d0cbc5-e174-4fed-8ee7-2f29e1353891">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6720919693833 139.7477695629274 25.019 35.672059769253366 139.7477525304634 25.019 35.67209465284565 139.74765178231925 25.019 35.67212684396802 139.7476688037133 25.019 35.6720919693833 139.7477695629274 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-086d4366-b500-4a2a-8bf6-ba71497201b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-086d4366-b500-4a2a-8bf6-ba71497201b7_0">
											<gml:posList>35.67191037514126 139.74765033333463 25.7 35.67191037514126 139.74765033333463 25.019 35.67190247691436 139.74767257831957 25.019 35.67190247691436 139.74767257831957 25.7 35.67191037514126 139.74765033333463 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c3cd995-271b-414e-990c-0cc1b72dd3d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c3cd995-271b-414e-990c-0cc1b72dd3d2_0">
											<gml:posList>35.67190247691436 139.74767257831957 25.7 35.67190247691436 139.74767257831957 25.019 35.671959320295215 139.74770186807652 25.019 35.671959320295215 139.74770186807652 25.7 35.67190247691436 139.74767257831957 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0ef90db-600a-4c66-98c6-acca89d72824">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0ef90db-600a-4c66-98c6-acca89d72824_0">
											<gml:posList>35.671959320295215 139.74770186807652 25.7 35.67196721852742 139.7476796230787 25.7 35.67191037514126 139.74765033333463 25.7 35.67190247691436 139.74767257831957 25.7 35.671959320295215 139.74770186807652 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f6bfbf5-a0e0-47a0-808a-5040d140eb0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f6bfbf5-a0e0-47a0-808a-5040d140eb0a_0">
											<gml:posList>35.67196721852742 139.7476796230787 25.7 35.67196721852742 139.7476796230787 25.019 35.67191037514126 139.74765033333463 25.019 35.67191037514126 139.74765033333463 25.7 35.67196721852742 139.7476796230787 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a995ad2-58ed-42df-b39d-be1684e52e88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a995ad2-58ed-42df-b39d-be1684e52e88_0">
											<gml:posList>35.671959320295215 139.74770186807652 25.7 35.671959320295215 139.74770186807652 25.019 35.67196721852742 139.7476796230787 25.019 35.67196721852742 139.7476796230787 25.7 35.671959320295215 139.74770186807652 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d34a74a-bce2-41a7-9341-4040dd81aded">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d34a74a-bce2-41a7-9341-4040dd81aded_0">
											<gml:posList>35.672059769253366 139.7477525304634 25.7 35.672059769253366 139.7477525304634 25.019 35.6720919693833 139.7477695629274 25.019 35.6720919693833 139.7477695629274 25.7 35.672059769253366 139.7477525304634 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab9dc260-c050-4449-baf5-4ef1190a9b7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab9dc260-c050-4449-baf5-4ef1190a9b7e_0">
											<gml:posList>35.67209465284565 139.74765178231925 25.7 35.67209465284565 139.74765178231925 25.019 35.672059769253366 139.7477525304634 25.019 35.672059769253366 139.7477525304634 25.7 35.67209465284565 139.74765178231925 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5608a5a6-1e01-4e0c-9bca-511ba481633d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5608a5a6-1e01-4e0c-9bca-511ba481633d_0">
											<gml:posList>35.6720919693833 139.7477695629274 25.7 35.67212684396802 139.7476688037133 25.7 35.67209465284565 139.74765178231925 25.7 35.672059769253366 139.7477525304634 25.7 35.6720919693833 139.7477695629274 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b4d019b-3a80-42f3-b826-cc7bbd27c9d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b4d019b-3a80-42f3-b826-cc7bbd27c9d9_0">
											<gml:posList>35.6720919693833 139.7477695629274 25.7 35.6720919693833 139.7477695629274 25.019 35.67212684396802 139.7476688037133 25.019 35.67212684396802 139.7476688037133 25.7 35.6720919693833 139.7477695629274 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-369b82be-ee12-4ac6-a0fd-a2e503d8963b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-369b82be-ee12-4ac6-a0fd-a2e503d8963b_0">
											<gml:posList>35.67212684396802 139.7476688037133 25.7 35.67212684396802 139.7476688037133 25.019 35.67209465284565 139.74765178231925 25.019 35.67209465284565 139.74765178231925 25.7 35.67212684396802 139.7476688037133 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_77fe66cf-eaa1-43b2-ab48-0d1eb34b83da_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-feb7c0cf-4d42-4c5e-8adc-5d236e8d4333">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67182485404156 139.74758865293336 25.019 35.671824954238694 139.74759012200525 25.019 35.671825334427545 139.7475923861228 25.019 35.67182775307832 139.74759655909793 25.019 35.67187392094444 139.74762124276347 25.019 35.67187982446855 139.74762058471055 25.019 35.67193035594565 139.74764663350487 25.019 35.6719262721735 139.7476585238746 25.019 35.67182430752368 139.74760597436574 25.019 35.671820726685056 139.7476026200712 25.019 35.671819814804756 139.74760052221922 25.019 35.67181840538425 139.74759591735324 25.019 35.671817724934506 139.7475897099714 25.019 35.67181763258689 139.7475866060154 25.019 35.671817703910015 139.74758550129334 25.019 35.67183436219771 139.74753617207716 25.019 35.67184195448301 139.74753999707443 25.019 35.67182485404156 139.74758865293336 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d41c8ce-9bd2-45d4-a58d-19b8bdd24e08">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67197568211788 139.74764119437918 25.019 35.67196320595165 139.74767756167415 25.019 35.671958823671794 139.74767530182822 25.019 35.67197129984521 139.74763894558137 25.019 35.67197568211788 139.74764119437918 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4167aec4-db94-4a48-81af-cc256fb1ee62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671953287211096 139.74767244670596 25.019 35.671936722920776 139.74766391443276 25.019 35.6719522574266 139.747618662511 25.019 35.67196381726443 139.7476246152504 25.019 35.67196542738672 139.7476199298222 25.019 35.672036914456434 139.7476567818054 25.019 35.67204128439024 139.7476543579544 25.019 35.67204386192957 139.74765381392186 25.019 35.672083780247746 139.74767425146305 25.019 35.6720662668181 139.74772529392362 25.019 35.67205985935764 139.7477271234366 25.019 35.67205832119176 139.74773159890802 25.019 35.67206592254716 139.7477355122967 25.019 35.67206319703527 139.74774345763444 25.019 35.67202075386549 139.74772158671686 25.019 35.67202266083958 139.7477160503908 25.019 35.672052435082115 139.74773139530942 25.019 35.672055178573544 139.74772338367418 25.019 35.672057213719064 139.7477206309247 25.019 35.672060223595324 139.74771963352637 25.019 35.67206306264284 139.7477192438674 25.019 35.67206957508247 139.74770025903814 25.019 35.672066040407216 139.7476984401423 25.019 35.67206038202879 139.7477015944363 25.019 35.672056173201966 139.74770241637208 25.019 35.672037480889976 139.74769278170606 25.019 35.67204290491256 139.74767695733954 25.019 35.67205588944188 139.74768364868692 25.019 35.672060108131454 139.74767134943485 25.019 35.67203631217191 139.7476590801186 25.019 35.672022045985734 139.74770067433843 25.019 35.672049602037745 139.74771487278502 25.019 35.67204641776984 139.74772414419047 25.019 35.672007896995275 139.74770427955843 25.019 35.672002247292575 139.74770695884166 25.019 35.671998263816576 139.74770779158234 25.019 35.67199561401009 139.74770811476037 25.019 35.671981664707374 139.74770099363175 25.019 35.671978876513364 139.74769684313318 25.019 35.67197708604533 139.74768875902217 25.019 35.67197102660052 139.74768563934154 25.019 35.67198392554156 139.74764804543304 25.019 35.67198721676066 139.74764974307368 25.019 35.67197564909203 139.74768345824683 25.019 35.672008687508274 139.74770048976993 25.019 35.67202068695217 139.747665525871 25.019 35.67202828830975 139.7476694392516 25.019 35.672031760407364 139.747659316959 25.019 35.67196830752905 139.74762662090927 25.019 35.6719634490112 139.74763911967005 25.019 35.67196218796274 139.74764034717703 25.019 35.67195791582795 139.74764087092777 25.019 35.671952428831865 139.74765686104436 25.019 35.671957703800665 139.74765958388724 25.019 35.671953287211096 139.74767244670596 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c38bda30-31ec-45e4-a673-510491a6303e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c38bda30-31ec-45e4-a673-510491a6303e_0">
											<gml:posList>35.67196218796274 139.74764034717703 25.019 35.6719634490112 139.74763911967005 25.019 35.6719634490112 139.74763911967005 25.7 35.67196218796274 139.74764034717703 25.7 35.67196218796274 139.74764034717703 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f38c6247-d23c-49fa-b08e-8709ea531c7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f38c6247-d23c-49fa-b08e-8709ea531c7b_0">
											<gml:posList>35.67197568211788 139.74764119437918 25.019 35.67197129984521 139.74763894558137 25.019 35.67197129984521 139.74763894558137 25.7 35.67197568211788 139.74764119437918 25.7 35.67197568211788 139.74764119437918 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1429c979-f794-48e2-acb0-b974e95aef82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1429c979-f794-48e2-acb0-b974e95aef82_0">
											<gml:posList>35.67198721676066 139.74764974307368 25.019 35.67198392554156 139.74764804543304 25.019 35.67198392554156 139.74764804543304 25.7 35.67198721676066 139.74764974307368 25.7 35.67198721676066 139.74764974307368 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d585c547-7aa1-4cab-a51a-ed0c7c5f1547">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d585c547-7aa1-4cab-a51a-ed0c7c5f1547_0">
											<gml:posList>35.67204290491256 139.74767695733954 25.019 35.67204290491256 139.74767695733954 25.7 35.67205588944188 139.74768364868692 25.7 35.67205588944188 139.74768364868692 25.019 35.67204290491256 139.74767695733954 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56aa188f-c077-400a-a52e-7444fca29899">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56aa188f-c077-400a-a52e-7444fca29899_0">
											<gml:posList>35.67206038202879 139.7477015944363 25.019 35.672066040407216 139.7476984401423 25.019 35.672066040407216 139.7476984401423 25.7 35.67206038202879 139.7477015944363 25.7 35.67206038202879 139.7477015944363 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55e68dee-92c8-4a4f-bc8f-fb0035419589">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55e68dee-92c8-4a4f-bc8f-fb0035419589_0">
											<gml:posList>35.671817703910015 139.74758550129334 25.019 35.67181763258689 139.7475866060154 25.019 35.67181763258689 139.7475866060154 25.7 35.671817703910015 139.74758550129334 25.7 35.671817703910015 139.74758550129334 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78cd8334-dedf-42f4-a708-93ff2bf0d947">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78cd8334-dedf-42f4-a708-93ff2bf0d947_0">
											<gml:posList>35.67181763258689 139.7475866060154 25.019 35.671817724934506 139.7475897099714 25.019 35.671817724934506 139.7475897099714 25.7 35.67181763258689 139.7475866060154 25.7 35.67181763258689 139.7475866060154 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25b084d8-c065-41bb-9914-91dbb4dbe7e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25b084d8-c065-41bb-9914-91dbb4dbe7e4_0">
											<gml:posList>35.671817724934506 139.7475897099714 25.019 35.67181840538425 139.74759591735324 25.019 35.67181840538425 139.74759591735324 25.7 35.671817724934506 139.7475897099714 25.7 35.671817724934506 139.7475897099714 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f3c9c92-8798-4004-a0f5-558c9862f9b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f3c9c92-8798-4004-a0f5-558c9862f9b2_0">
											<gml:posList>35.671819814804756 139.74760052221922 25.019 35.671819814804756 139.74760052221922 25.7 35.67181840538425 139.74759591735324 25.7 35.67181840538425 139.74759591735324 25.019 35.671819814804756 139.74760052221922 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-763f0554-3a27-4073-92f6-7df4931e3477">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-763f0554-3a27-4073-92f6-7df4931e3477_0">
											<gml:posList>35.671819814804756 139.74760052221922 25.019 35.671820726685056 139.7476026200712 25.019 35.671820726685056 139.7476026200712 25.7 35.671819814804756 139.74760052221922 25.7 35.671819814804756 139.74760052221922 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c3c7c44-6724-4c9a-8d36-27df21aba468">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c3c7c44-6724-4c9a-8d36-27df21aba468_0">
											<gml:posList>35.671820726685056 139.7476026200712 25.019 35.67182430752368 139.74760597436574 25.019 35.67182430752368 139.74760597436574 25.7 35.671820726685056 139.7476026200712 25.7 35.671820726685056 139.7476026200712 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-521b380e-8060-4101-8753-6c8b7a2c36ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-521b380e-8060-4101-8753-6c8b7a2c36ff_0">
											<gml:posList>35.671824954238694 139.74759012200525 25.019 35.67182485404156 139.74758865293336 25.019 35.67182485404156 139.74758865293336 25.7 35.671824954238694 139.74759012200525 25.7 35.671824954238694 139.74759012200525 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-336fdc24-dd49-44ca-a3fc-98e26f41714e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-336fdc24-dd49-44ca-a3fc-98e26f41714e_0">
											<gml:posList>35.671825334427545 139.7475923861228 25.019 35.671824954238694 139.74759012200525 25.019 35.671824954238694 139.74759012200525 25.7 35.671825334427545 139.7475923861228 25.7 35.671825334427545 139.7475923861228 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a553ae03-d3c2-4428-960d-d22575a6d9d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a553ae03-d3c2-4428-960d-d22575a6d9d4_0">
											<gml:posList>35.67183436219771 139.74753617207716 25.019 35.671817703910015 139.74758550129334 25.019 35.671817703910015 139.74758550129334 25.7 35.67183436219771 139.74753617207716 25.7 35.67183436219771 139.74753617207716 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9da8c290-a299-434f-b180-d03c2bfaf1e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9da8c290-a299-434f-b180-d03c2bfaf1e9_0">
											<gml:posList>35.671825334427545 139.7475923861228 25.019 35.671825334427545 139.7475923861228 25.7 35.67182775307832 139.74759655909793 25.7 35.67182775307832 139.74759655909793 25.019 35.671825334427545 139.7475923861228 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-570f6553-1df2-4524-b4c7-138076d302fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-570f6553-1df2-4524-b4c7-138076d302fb_0">
											<gml:posList>35.67182485404156 139.74758865293336 25.019 35.67184195448301 139.74753999707443 25.019 35.67184195448301 139.74753999707443 25.7 35.67182485404156 139.74758865293336 25.7 35.67182485404156 139.74758865293336 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f33aabde-d4fb-46d0-b2e4-e4b51c3e2501">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f33aabde-d4fb-46d0-b2e4-e4b51c3e2501_0">
											<gml:posList>35.67184195448301 139.74753999707443 25.019 35.67183436219771 139.74753617207716 25.019 35.67183436219771 139.74753617207716 25.7 35.67184195448301 139.74753999707443 25.7 35.67184195448301 139.74753999707443 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7813bba5-8ddf-47be-a84d-b48a648aa7ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7813bba5-8ddf-47be-a84d-b48a648aa7ed_0">
											<gml:posList>35.67187392094444 139.74762124276347 25.019 35.67182775307832 139.74759655909793 25.019 35.67182775307832 139.74759655909793 25.7 35.67187392094444 139.74762124276347 25.7 35.67187392094444 139.74762124276347 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11716f3d-9a9d-4538-bd59-d66bf840921f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11716f3d-9a9d-4538-bd59-d66bf840921f_0">
											<gml:posList>35.67183436219771 139.74753617207716 25.7 35.671817703910015 139.74758550129334 25.7 35.67181763258689 139.7475866060154 25.7 35.671817724934506 139.7475897099714 25.7 35.67181840538425 139.74759591735324 25.7 35.671819814804756 139.74760052221922 25.7 35.671820726685056 139.7476026200712 25.7 35.67182430752368 139.74760597436574 25.7 35.6719262721735 139.7476585238746 25.7 35.67193035594565 139.74764663350487 25.7 35.67187982446855 139.74762058471055 25.7 35.67187392094444 139.74762124276347 25.7 35.67182775307832 139.74759655909793 25.7 35.671825334427545 139.7475923861228 25.7 35.671824954238694 139.74759012200525 25.7 35.67182485404156 139.74758865293336 25.7 35.67184195448301 139.74753999707443 25.7 35.67183436219771 139.74753617207716 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a8ba23c-a8fb-4ede-9aba-d1481af851a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a8ba23c-a8fb-4ede-9aba-d1481af851a1_0">
											<gml:posList>35.6719262721735 139.7476585238746 25.019 35.6719262721735 139.7476585238746 25.7 35.67182430752368 139.74760597436574 25.7 35.67182430752368 139.74760597436574 25.019 35.6719262721735 139.7476585238746 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9c5d72b-9416-4730-9ff5-cf19b18d4864">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9c5d72b-9416-4730-9ff5-cf19b18d4864_0">
											<gml:posList>35.67187982446855 139.74762058471055 25.019 35.67187392094444 139.74762124276347 25.019 35.67187392094444 139.74762124276347 25.7 35.67187982446855 139.74762058471055 25.7 35.67187982446855 139.74762058471055 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-445a443a-ccaf-4edd-b850-ee8c35c3aca6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-445a443a-ccaf-4edd-b850-ee8c35c3aca6_0">
											<gml:posList>35.67193035594565 139.74764663350487 25.019 35.67187982446855 139.74762058471055 25.019 35.67187982446855 139.74762058471055 25.7 35.67193035594565 139.74764663350487 25.7 35.67193035594565 139.74764663350487 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72ff3339-870d-4551-a988-9c51e0ee8102">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72ff3339-870d-4551-a988-9c51e0ee8102_0">
											<gml:posList>35.6719262721735 139.7476585238746 25.019 35.67193035594565 139.74764663350487 25.019 35.67193035594565 139.74764663350487 25.7 35.6719262721735 139.7476585238746 25.7 35.6719262721735 139.7476585238746 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e7dddd2-5239-49d4-8160-b268d3236ebe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e7dddd2-5239-49d4-8160-b268d3236ebe_0">
											<gml:posList>35.671936722920776 139.74766391443276 25.019 35.671936722920776 139.74766391443276 25.7 35.6719522574266 139.747618662511 25.7 35.6719522574266 139.747618662511 25.019 35.671936722920776 139.74766391443276 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59134e4b-e492-4aeb-8d96-147ff7f7c4e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59134e4b-e492-4aeb-8d96-147ff7f7c4e3_0">
											<gml:posList>35.671936722920776 139.74766391443276 25.019 35.671953287211096 139.74767244670596 25.019 35.671953287211096 139.74767244670596 25.7 35.671936722920776 139.74766391443276 25.7 35.671936722920776 139.74766391443276 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-397cb68f-eec0-4758-97d7-c055e819ced8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-397cb68f-eec0-4758-97d7-c055e819ced8_0">
											<gml:posList>35.671957703800665 139.74765958388724 25.019 35.671952428831865 139.74765686104436 25.019 35.671952428831865 139.74765686104436 25.7 35.671957703800665 139.74765958388724 25.7 35.671957703800665 139.74765958388724 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e638532e-5555-46c7-b623-994207f4dda3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e638532e-5555-46c7-b623-994207f4dda3_0">
											<gml:posList>35.671952428831865 139.74765686104436 25.019 35.67195791582795 139.74764087092777 25.019 35.67195791582795 139.74764087092777 25.7 35.671952428831865 139.74765686104436 25.7 35.671952428831865 139.74765686104436 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-129035b3-b4ea-4d0c-882b-5bbc9b0add22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-129035b3-b4ea-4d0c-882b-5bbc9b0add22_0">
											<gml:posList>35.671953287211096 139.74767244670596 25.019 35.671957703800665 139.74765958388724 25.019 35.671957703800665 139.74765958388724 25.7 35.671953287211096 139.74767244670596 25.7 35.671953287211096 139.74767244670596 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d55d994-cef8-426a-8b20-cadcff8a4893">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d55d994-cef8-426a-8b20-cadcff8a4893_0">
											<gml:posList>35.67196381726443 139.7476246152504 25.019 35.6719522574266 139.747618662511 25.019 35.6719522574266 139.747618662511 25.7 35.67196381726443 139.7476246152504 25.7 35.67196381726443 139.7476246152504 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-522ebd27-fa65-41e1-a72f-7c23ae78141a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-522ebd27-fa65-41e1-a72f-7c23ae78141a_0">
											<gml:posList>35.67195791582795 139.74764087092777 25.019 35.67196218796274 139.74764034717703 25.019 35.67196218796274 139.74764034717703 25.7 35.67195791582795 139.74764087092777 25.7 35.67195791582795 139.74764087092777 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-092bb3c8-5575-4dde-834a-e33457547b57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-092bb3c8-5575-4dde-834a-e33457547b57_0">
											<gml:posList>35.671958823671794 139.74767530182822 25.019 35.67196320595165 139.74767756167415 25.019 35.67196320595165 139.74767756167415 25.7 35.671958823671794 139.74767530182822 25.7 35.671958823671794 139.74767530182822 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f1e4128-7004-48f4-a9f0-73d595e33152">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f1e4128-7004-48f4-a9f0-73d595e33152_0">
											<gml:posList>35.67196542738672 139.7476199298222 25.019 35.67196381726443 139.7476246152504 25.019 35.67196381726443 139.7476246152504 25.7 35.67196542738672 139.7476199298222 25.7 35.67196542738672 139.7476199298222 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fa76b45-8a92-4801-a28f-002548edd660">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fa76b45-8a92-4801-a28f-002548edd660_0">
											<gml:posList>35.67197129984521 139.74763894558137 25.019 35.671958823671794 139.74767530182822 25.019 35.671958823671794 139.74767530182822 25.7 35.67197129984521 139.74763894558137 25.7 35.67197129984521 139.74763894558137 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-591333bb-d0ee-4a33-a963-a5e985c2933d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-591333bb-d0ee-4a33-a963-a5e985c2933d_0">
											<gml:posList>35.6719634490112 139.74763911967005 25.019 35.67196830752905 139.74762662090927 25.019 35.67196830752905 139.74762662090927 25.7 35.6719634490112 139.74763911967005 25.7 35.6719634490112 139.74763911967005 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea18f4d1-3cdf-4631-8618-c1fb174ecde0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea18f4d1-3cdf-4631-8618-c1fb174ecde0_0">
											<gml:posList>35.67197568211788 139.74764119437918 25.7 35.67197129984521 139.74763894558137 25.7 35.671958823671794 139.74767530182822 25.7 35.67196320595165 139.74767756167415 25.7 35.67197568211788 139.74764119437918 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-545face4-7399-4b95-bc35-ec1282909e5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-545face4-7399-4b95-bc35-ec1282909e5c_0">
											<gml:posList>35.67196320595165 139.74767756167415 25.019 35.67197568211788 139.74764119437918 25.019 35.67197568211788 139.74764119437918 25.7 35.67196320595165 139.74767756167415 25.7 35.67196320595165 139.74767756167415 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80dee355-19f6-43fd-9087-a2e99fec80e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80dee355-19f6-43fd-9087-a2e99fec80e0_0">
											<gml:posList>35.67197708604533 139.74768875902217 25.019 35.67197708604533 139.74768875902217 25.7 35.67197102660052 139.74768563934154 25.7 35.67197102660052 139.74768563934154 25.019 35.67197708604533 139.74768875902217 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ec06819-8258-48b7-a1d4-674a1cfb532b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ec06819-8258-48b7-a1d4-674a1cfb532b_0">
											<gml:posList>35.67198392554156 139.74764804543304 25.019 35.67197102660052 139.74768563934154 25.019 35.67197102660052 139.74768563934154 25.7 35.67198392554156 139.74764804543304 25.7 35.67198392554156 139.74764804543304 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40c31e26-8c50-472c-ab62-85453bf7f539">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40c31e26-8c50-472c-ab62-85453bf7f539_0">
											<gml:posList>35.67197708604533 139.74768875902217 25.019 35.671978876513364 139.74769684313318 25.019 35.671978876513364 139.74769684313318 25.7 35.67197708604533 139.74768875902217 25.7 35.67197708604533 139.74768875902217 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c4974f1-726a-4780-b70f-da7be926aa82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c4974f1-726a-4780-b70f-da7be926aa82_0">
											<gml:posList>35.671978876513364 139.74769684313318 25.019 35.671981664707374 139.74770099363175 25.019 35.671981664707374 139.74770099363175 25.7 35.671978876513364 139.74769684313318 25.7 35.671978876513364 139.74769684313318 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d6eb4f9-b0f1-4a60-be5c-eec6401e8eee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d6eb4f9-b0f1-4a60-be5c-eec6401e8eee_0">
											<gml:posList>35.67197564909203 139.74768345824683 25.019 35.67198721676066 139.74764974307368 25.019 35.67198721676066 139.74764974307368 25.7 35.67197564909203 139.74768345824683 25.7 35.67197564909203 139.74768345824683 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d88a621-3110-4567-bc53-57884cc86170">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d88a621-3110-4567-bc53-57884cc86170_0">
											<gml:posList>35.671981664707374 139.74770099363175 25.019 35.67199561401009 139.74770811476037 25.019 35.67199561401009 139.74770811476037 25.7 35.671981664707374 139.74770099363175 25.7 35.671981664707374 139.74770099363175 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4668a9a8-1572-4824-a2df-7be4e67f6018">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4668a9a8-1572-4824-a2df-7be4e67f6018_0">
											<gml:posList>35.672008687508274 139.74770048976993 25.019 35.67197564909203 139.74768345824683 25.019 35.67197564909203 139.74768345824683 25.7 35.672008687508274 139.74770048976993 25.7 35.672008687508274 139.74770048976993 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b52405a-7769-4efe-ac2c-34131c8b1e46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b52405a-7769-4efe-ac2c-34131c8b1e46_0">
											<gml:posList>35.67199561401009 139.74770811476037 25.019 35.671998263816576 139.74770779158234 25.019 35.671998263816576 139.74770779158234 25.7 35.67199561401009 139.74770811476037 25.7 35.67199561401009 139.74770811476037 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f58c32ee-3b38-4c26-9c74-9219abf2840d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f58c32ee-3b38-4c26-9c74-9219abf2840d_0">
											<gml:posList>35.67196830752905 139.74762662090927 25.019 35.672031760407364 139.747659316959 25.019 35.672031760407364 139.747659316959 25.7 35.67196830752905 139.74762662090927 25.7 35.67196830752905 139.74762662090927 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ceaf034-73e9-4cfd-a80a-697fe0792ffc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ceaf034-73e9-4cfd-a80a-697fe0792ffc_0">
											<gml:posList>35.671998263816576 139.74770779158234 25.019 35.672002247292575 139.74770695884166 25.019 35.672002247292575 139.74770695884166 25.7 35.671998263816576 139.74770779158234 25.7 35.671998263816576 139.74770779158234 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cbf080d-d713-4cd8-8c1e-a44f387a1fd5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cbf080d-d713-4cd8-8c1e-a44f387a1fd5_0">
											<gml:posList>35.672036914456434 139.7476567818054 25.019 35.67196542738672 139.7476199298222 25.019 35.67196542738672 139.7476199298222 25.7 35.672036914456434 139.7476567818054 25.7 35.672036914456434 139.7476567818054 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46a9f655-f210-4b6c-a606-c40814fdd6be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46a9f655-f210-4b6c-a606-c40814fdd6be_0">
											<gml:posList>35.672002247292575 139.74770695884166 25.019 35.672007896995275 139.74770427955843 25.019 35.672007896995275 139.74770427955843 25.7 35.672002247292575 139.74770695884166 25.7 35.672002247292575 139.74770695884166 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75dd04f6-8871-4e99-a856-24669f0db97c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75dd04f6-8871-4e99-a856-24669f0db97c_0">
											<gml:posList>35.671952428831865 139.74765686104436 25.7 35.67195791582795 139.74764087092777 25.7 35.67196218796274 139.74764034717703 25.7 35.6719634490112 139.74763911967005 25.7 35.67196830752905 139.74762662090927 25.7 35.672031760407364 139.747659316959 25.7 35.67202828830975 139.7476694392516 25.7 35.67202068695217 139.747665525871 25.7 35.672008687508274 139.74770048976993 25.7 35.67197564909203 139.74768345824683 25.7 35.67198721676066 139.74764974307368 25.7 35.67198392554156 139.74764804543304 25.7 35.67197102660052 139.74768563934154 25.7 35.67197708604533 139.74768875902217 25.7 35.671978876513364 139.74769684313318 25.7 35.671981664707374 139.74770099363175 25.7 35.67199561401009 139.74770811476037 25.7 35.671998263816576 139.74770779158234 25.7 35.672002247292575 139.74770695884166 25.7 35.672007896995275 139.74770427955843 25.7 35.67204641776984 139.74772414419047 25.7 35.672049602037745 139.74771487278502 25.7 35.672022045985734 139.74770067433843 25.7 35.67203631217191 139.7476590801186 25.7 35.672060108131454 139.74767134943485 25.7 35.67205588944188 139.74768364868692 25.7 35.67204290491256 139.74767695733954 25.7 35.672037480889976 139.74769278170606 25.7 35.672056173201966 139.74770241637208 25.7 35.67206038202879 139.7477015944363 25.7 35.672066040407216 139.7476984401423 25.7 35.67206957508247 139.74770025903814 25.7 35.67206306264284 139.7477192438674 25.7 35.672060223595324 139.74771963352637 25.7 35.672057213719064 139.7477206309247 25.7 35.672055178573544 139.74772338367418 25.7 35.672052435082115 139.74773139530942 25.7 35.67202266083958 139.7477160503908 25.7 35.67202075386549 139.74772158671686 25.7 35.67206319703527 139.74774345763444 25.7 35.67206592254716 139.7477355122967 25.7 35.67205832119176 139.74773159890802 25.7 35.67205985935764 139.7477271234366 25.7 35.6720662668181 139.74772529392362 25.7 35.672083780247746 139.74767425146305 25.7 35.67204386192957 139.74765381392186 25.7 35.67204128439024 139.7476543579544 25.7 35.672036914456434 139.7476567818054 25.7 35.67196542738672 139.7476199298222 25.7 35.67196381726443 139.7476246152504 25.7 35.6719522574266 139.747618662511 25.7 35.671936722920776 139.74766391443276 25.7 35.671953287211096 139.74767244670596 25.7 35.671957703800665 139.74765958388724 25.7 35.671952428831865 139.74765686104436 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0deb3f5b-466a-4606-9df2-c4ca5f19b09b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0deb3f5b-466a-4606-9df2-c4ca5f19b09b_0">
											<gml:posList>35.67202068695217 139.747665525871 25.019 35.672008687508274 139.74770048976993 25.019 35.672008687508274 139.74770048976993 25.7 35.67202068695217 139.747665525871 25.7 35.67202068695217 139.747665525871 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27f4c2a5-b66a-4c91-bc4f-697ea9778dea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27f4c2a5-b66a-4c91-bc4f-697ea9778dea_0">
											<gml:posList>35.67202266083958 139.7477160503908 25.019 35.67202075386549 139.74772158671686 25.019 35.67202075386549 139.74772158671686 25.7 35.67202266083958 139.7477160503908 25.7 35.67202266083958 139.7477160503908 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30abcbb0-6806-44bc-bf11-ee0aa3e118fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30abcbb0-6806-44bc-bf11-ee0aa3e118fb_0">
											<gml:posList>35.67202828830975 139.7476694392516 25.019 35.67202068695217 139.747665525871 25.019 35.67202068695217 139.747665525871 25.7 35.67202828830975 139.7476694392516 25.7 35.67202828830975 139.7476694392516 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8634e722-3a46-446b-b7b2-6c02d8666a2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8634e722-3a46-446b-b7b2-6c02d8666a2d_0">
											<gml:posList>35.672007896995275 139.74770427955843 25.019 35.67204641776984 139.74772414419047 25.019 35.67204641776984 139.74772414419047 25.7 35.672007896995275 139.74770427955843 25.7 35.672007896995275 139.74770427955843 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55146c6c-a2d8-46d7-9172-245a9a812e3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55146c6c-a2d8-46d7-9172-245a9a812e3b_0">
											<gml:posList>35.67203631217191 139.7476590801186 25.019 35.67203631217191 139.7476590801186 25.7 35.672022045985734 139.74770067433843 25.7 35.672022045985734 139.74770067433843 25.019 35.67203631217191 139.7476590801186 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c13960a8-304a-4a40-922d-ce8953318f31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c13960a8-304a-4a40-922d-ce8953318f31_0">
											<gml:posList>35.672031760407364 139.747659316959 25.019 35.67202828830975 139.7476694392516 25.019 35.67202828830975 139.7476694392516 25.7 35.672031760407364 139.747659316959 25.7 35.672031760407364 139.747659316959 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8bb6df3-877a-46a4-a692-10afc9fdb58a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8bb6df3-877a-46a4-a692-10afc9fdb58a_0">
											<gml:posList>35.672049602037745 139.74771487278502 25.019 35.672022045985734 139.74770067433843 25.019 35.672022045985734 139.74770067433843 25.7 35.672049602037745 139.74771487278502 25.7 35.672049602037745 139.74771487278502 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c528156-62db-42cc-aeea-74b57703cd9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c528156-62db-42cc-aeea-74b57703cd9d_0">
											<gml:posList>35.672052435082115 139.74773139530942 25.019 35.67202266083958 139.7477160503908 25.019 35.67202266083958 139.7477160503908 25.7 35.672052435082115 139.74773139530942 25.7 35.672052435082115 139.74773139530942 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dce1bad0-89fc-4617-9dad-17161d3a54fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dce1bad0-89fc-4617-9dad-17161d3a54fd_0">
											<gml:posList>35.67204128439024 139.7476543579544 25.019 35.672036914456434 139.7476567818054 25.019 35.672036914456434 139.7476567818054 25.7 35.67204128439024 139.7476543579544 25.7 35.67204128439024 139.7476543579544 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36431043-2323-4ca9-a088-0f899821ee9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36431043-2323-4ca9-a088-0f899821ee9e_0">
											<gml:posList>35.67204290491256 139.74767695733954 25.019 35.672037480889976 139.74769278170606 25.019 35.672037480889976 139.74769278170606 25.7 35.67204290491256 139.74767695733954 25.7 35.67204290491256 139.74767695733954 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-251bab55-d593-4121-8601-29e28e8687ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-251bab55-d593-4121-8601-29e28e8687ad_0">
											<gml:posList>35.67202075386549 139.74772158671686 25.019 35.67206319703527 139.74774345763444 25.019 35.67206319703527 139.74774345763444 25.7 35.67202075386549 139.74772158671686 25.7 35.67202075386549 139.74772158671686 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31c546f8-ec9f-44f5-9dc2-fbd2f5103755">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31c546f8-ec9f-44f5-9dc2-fbd2f5103755_0">
											<gml:posList>35.67204386192957 139.74765381392186 25.019 35.67204128439024 139.7476543579544 25.019 35.67204128439024 139.7476543579544 25.7 35.67204386192957 139.74765381392186 25.7 35.67204386192957 139.74765381392186 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e2ab08f-8fbd-4840-ace8-db57d6639704">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e2ab08f-8fbd-4840-ace8-db57d6639704_0">
											<gml:posList>35.672037480889976 139.74769278170606 25.019 35.672056173201966 139.74770241637208 25.019 35.672056173201966 139.74770241637208 25.7 35.672037480889976 139.74769278170606 25.7 35.672037480889976 139.74769278170606 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85f59e86-e161-49da-837b-bd75cc9d9f06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85f59e86-e161-49da-837b-bd75cc9d9f06_0">
											<gml:posList>35.67204641776984 139.74772414419047 25.019 35.672049602037745 139.74771487278502 25.019 35.672049602037745 139.74771487278502 25.7 35.67204641776984 139.74772414419047 25.7 35.67204641776984 139.74772414419047 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff64f845-e6e6-4b89-8818-7ac179b9bd30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff64f845-e6e6-4b89-8818-7ac179b9bd30_0">
											<gml:posList>35.672060108131454 139.74767134943485 25.019 35.672060108131454 139.74767134943485 25.7 35.67203631217191 139.7476590801186 25.7 35.67203631217191 139.7476590801186 25.019 35.672060108131454 139.74767134943485 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-261a0a82-68a2-4028-ba15-a9b7cac7fc33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-261a0a82-68a2-4028-ba15-a9b7cac7fc33_0">
											<gml:posList>35.672055178573544 139.74772338367418 25.019 35.672052435082115 139.74773139530942 25.019 35.672052435082115 139.74773139530942 25.7 35.672055178573544 139.74772338367418 25.7 35.672055178573544 139.74772338367418 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95a1d81d-d5de-4584-b3e4-0debe73cbf30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95a1d81d-d5de-4584-b3e4-0debe73cbf30_0">
											<gml:posList>35.672057213719064 139.7477206309247 25.019 35.672055178573544 139.74772338367418 25.019 35.672055178573544 139.74772338367418 25.7 35.672057213719064 139.7477206309247 25.7 35.672057213719064 139.7477206309247 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4d4cc56-b4b1-4ee6-90b4-c30593c3627b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4d4cc56-b4b1-4ee6-90b4-c30593c3627b_0">
											<gml:posList>35.672060108131454 139.74767134943485 25.019 35.67205588944188 139.74768364868692 25.019 35.67205588944188 139.74768364868692 25.7 35.672060108131454 139.74767134943485 25.7 35.672060108131454 139.74767134943485 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43008242-5e0c-4533-a41e-8f95e0487a69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43008242-5e0c-4533-a41e-8f95e0487a69_0">
											<gml:posList>35.672056173201966 139.74770241637208 25.019 35.67206038202879 139.7477015944363 25.019 35.67206038202879 139.7477015944363 25.7 35.672056173201966 139.74770241637208 25.7 35.672056173201966 139.74770241637208 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68a4711c-da7e-40d5-9857-25787cbd82b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68a4711c-da7e-40d5-9857-25787cbd82b6_0">
											<gml:posList>35.672060223595324 139.74771963352637 25.019 35.672057213719064 139.7477206309247 25.019 35.672057213719064 139.7477206309247 25.7 35.672060223595324 139.74771963352637 25.7 35.672060223595324 139.74771963352637 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8fb8736-f908-4380-971d-7a3958537a43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8fb8736-f908-4380-971d-7a3958537a43_0">
											<gml:posList>35.67205832119176 139.74773159890802 25.019 35.67205985935764 139.7477271234366 25.019 35.67205985935764 139.7477271234366 25.7 35.67205832119176 139.74773159890802 25.7 35.67205832119176 139.74773159890802 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc752ece-ddb1-49fa-b6c7-3e220158a165">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc752ece-ddb1-49fa-b6c7-3e220158a165_0">
											<gml:posList>35.67206306264284 139.7477192438674 25.019 35.672060223595324 139.74771963352637 25.019 35.672060223595324 139.74771963352637 25.7 35.67206306264284 139.7477192438674 25.7 35.67206306264284 139.7477192438674 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a02d7e73-ff46-482b-ae57-9f999a135323">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a02d7e73-ff46-482b-ae57-9f999a135323_0">
											<gml:posList>35.67206592254716 139.7477355122967 25.019 35.67205832119176 139.74773159890802 25.019 35.67205832119176 139.74773159890802 25.7 35.67206592254716 139.7477355122967 25.7 35.67206592254716 139.7477355122967 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30f9b423-2e9c-4ee0-801a-bbe687fce0b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30f9b423-2e9c-4ee0-801a-bbe687fce0b5_0">
											<gml:posList>35.67205985935764 139.7477271234366 25.019 35.6720662668181 139.74772529392362 25.019 35.6720662668181 139.74772529392362 25.7 35.67205985935764 139.7477271234366 25.7 35.67205985935764 139.7477271234366 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73ffc490-513d-4e60-bf1c-faf91faee95e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73ffc490-513d-4e60-bf1c-faf91faee95e_0">
											<gml:posList>35.672083780247746 139.74767425146305 25.019 35.67204386192957 139.74765381392186 25.019 35.67204386192957 139.74765381392186 25.7 35.672083780247746 139.74767425146305 25.7 35.672083780247746 139.74767425146305 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bde3f82e-b070-4849-91ab-5cde70763ebf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bde3f82e-b070-4849-91ab-5cde70763ebf_0">
											<gml:posList>35.67206319703527 139.74774345763444 25.019 35.67206592254716 139.7477355122967 25.019 35.67206592254716 139.7477355122967 25.7 35.67206319703527 139.74774345763444 25.7 35.67206319703527 139.74774345763444 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f73bb5c-f426-479d-ab65-b480dfcf26b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f73bb5c-f426-479d-ab65-b480dfcf26b9_0">
											<gml:posList>35.67206957508247 139.74770025903814 25.019 35.67206306264284 139.7477192438674 25.019 35.67206306264284 139.7477192438674 25.7 35.67206957508247 139.74770025903814 25.7 35.67206957508247 139.74770025903814 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3893e3f6-9565-4985-96bd-250c66d90a91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3893e3f6-9565-4985-96bd-250c66d90a91_0">
											<gml:posList>35.672066040407216 139.7476984401423 25.019 35.67206957508247 139.74770025903814 25.019 35.67206957508247 139.74770025903814 25.7 35.672066040407216 139.7476984401423 25.7 35.672066040407216 139.7476984401423 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-432acf92-8ccf-4da2-8c43-16512a498963">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-432acf92-8ccf-4da2-8c43-16512a498963_0">
											<gml:posList>35.6720662668181 139.74772529392362 25.019 35.672083780247746 139.74767425146305 25.019 35.672083780247746 139.74767425146305 25.7 35.6720662668181 139.74772529392362 25.7 35.6720662668181 139.74772529392362 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f2b0c0f3-d2a7-4308-830e-8bcfc56428ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2b0c0f3-d2a7-4308-830e-8bcfc56428ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2b0c0f3-d2a7-4308-830e-8bcfc56428ac">
											<gml:posList>35.67174509110125 139.7475880202199 7.4 35.6718995006112 139.7473412978806 7.4 35.67214816870411 139.7475650542577 7.4 35.672141056282484 139.74757688162452 7.4 35.672161434767226 139.74758735400692 7.4 35.67209541092676 139.74777985458914 7.4 35.6717918975657 139.74762342927988 7.4 35.671795135821846 139.74761403633116 7.4 35.67174509110125 139.7475880202199 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a58c1ff-4958-4bb1-9b3e-b49b8bb14602">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a58c1ff-4958-4bb1-9b3e-b49b8bb14602">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a58c1ff-4958-4bb1-9b3e-b49b8bb14602">
											<gml:posList>35.671795135821846 139.74761403633116 22.6 35.671796278079555 139.74761054443002 22.6 35.671749523886085 139.74758525386684 22.6 35.67174750403348 139.74758416242875 22.6 35.67174509110125 139.7475880202199 22.6 35.671795135821846 139.74761403633116 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b027fece-cffc-4cb8-bb06-dfa78f034315">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b027fece-cffc-4cb8-bb06-dfa78f034315">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b027fece-cffc-4cb8-bb06-dfa78f034315">
											<gml:posList>35.67179925915842 139.74761974294015 25.7 35.671800329589594 139.74761664878815 25.7 35.671795135821846 139.74761403633116 25.7 35.6717918975657 139.74762342927988 25.7 35.67179925915842 139.74761974294015 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-64320ad8-feec-45fb-aa44-8134d292b4dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64320ad8-feec-45fb-aa44-8134d292b4dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64320ad8-feec-45fb-aa44-8134d292b4dd">
											<gml:posList>35.6718977899604 139.74734403923978 22.6 35.67174750403348 139.74758416242875 22.6 35.671749523886085 139.74758525386684 22.6 35.67189869191637 139.74734485571113 22.6 35.6718977899604 139.74734403923978 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd4ab558-f057-443b-805d-deb1de503195">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd4ab558-f057-443b-805d-deb1de503195">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd4ab558-f057-443b-805d-deb1de503195">
											<gml:posList>35.67185878285397 139.7474384841566 25.7 35.671856386274094 139.747427351889 25.7 35.671795135821846 139.74761403633116 25.7 35.671800329589594 139.74761664878815 25.7 35.67185878285397 139.7474384841566 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-904a647d-0c86-4e21-8775-ac5d4ccc5325">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-904a647d-0c86-4e21-8775-ac5d4ccc5325">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-904a647d-0c86-4e21-8775-ac5d4ccc5325">
											<gml:posList>35.67185878285397 139.7474384841566 25.7 35.67186428691281 139.74743381665166 25.7 35.671865276333904 139.74743088827842 25.7 35.671856386274094 139.747427351889 25.7 35.67185878285397 139.7474384841566 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f935ffb-ba5a-493d-a833-0d6871dc07e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f935ffb-ba5a-493d-a833-0d6871dc07e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f935ffb-ba5a-493d-a833-0d6871dc07e2">
											<gml:posList>35.671886995759394 139.74737523499542 28.357 35.671885460209154 139.747370729683 28.357 35.67186428691281 139.74743381665166 28.357 35.67186796317966 139.74743194586023 28.357 35.671886995759394 139.74737523499542 28.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a95f23ea-42bc-4db6-b9e5-0a19fc91d4a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a95f23ea-42bc-4db6-b9e5-0a19fc91d4a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a95f23ea-42bc-4db6-b9e5-0a19fc91d4a5">
											<gml:posList>35.67194425471326 139.74748156221142 25.7 35.671946386428644 139.74747519715856 25.7 35.67186428691281 139.74743381665166 25.7 35.67185878285397 139.7474384841566 25.7 35.67194425471326 139.74748156221142 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28dae203-566e-4b63-bb82-1dd59bed2233">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28dae203-566e-4b63-bb82-1dd59bed2233">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28dae203-566e-4b63-bb82-1dd59bed2233">
											<gml:posList>35.67186796317966 139.74743194586023 28.357 35.67186428691281 139.74743381665166 28.357 35.671946386428644 139.74747519715856 28.357 35.67194485990375 139.74747070287773 28.357 35.67186796317966 139.74743194586023 28.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a6cb7fc-6919-4a4f-ad1b-e71031bf48e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a6cb7fc-6919-4a4f-ad1b-e71031bf48e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a6cb7fc-6919-4a4f-ad1b-e71031bf48e4">
											<gml:posList>35.67186796317966 139.74743194586023 27.628 35.67194485990375 139.74747070287773 27.628 35.67196389250144 139.74741399196768 27.628 35.671886995759394 139.74737523499542 27.628 35.67186796317966 139.74743194586023 27.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a47a3da-2e79-4c8a-93bc-fafe2b79db46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a47a3da-2e79-4c8a-93bc-fafe2b79db46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a47a3da-2e79-4c8a-93bc-fafe2b79db46">
											<gml:posList>35.67196389250144 139.74741399196768 28.357 35.67196755974631 139.74741211013617 28.357 35.671885460209154 139.747370729683 28.357 35.671886995759394 139.74737523499542 28.357 35.67196389250144 139.74741399196768 28.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-53ecf4d4-41fc-4126-9c42-ff0dd6bfef1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53ecf4d4-41fc-4126-9c42-ff0dd6bfef1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53ecf4d4-41fc-4126-9c42-ff0dd6bfef1a">
											<gml:posList>35.67179925915842 139.74761974294015 25.7 35.6717918975657 139.74762342927988 25.7 35.67209541092676 139.74777985458914 25.7 35.672092402944656 139.74777083281174 25.7 35.67179925915842 139.74761974294015 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d8bb0b2-18c4-4130-93bb-99911e51b02f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d8bb0b2-18c4-4130-93bb-99911e51b02f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d8bb0b2-18c4-4130-93bb-99911e51b02f">
											<gml:posList>35.67198911784635 139.74749673622236 22.236 35.672138522474704 139.747575547708 22.236 35.672144392481854 139.74756579841323 22.236 35.67189869191637 139.74734485571113 22.236 35.671749523886085 139.74758525386684 22.236 35.671796278079555 139.74761054443002 22.236 35.671856386274094 139.747427351889 22.236 35.671865276333904 139.74743088827842 22.236 35.671885460209154 139.747370729683 22.236 35.67196755974631 139.74741211013617 22.236 35.671946386428644 139.74747519715856 22.236 35.67198911784635 139.74749673622236 22.236</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-288a59fb-3124-43f7-ac12-71716c5f9389">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-288a59fb-3124-43f7-ac12-71716c5f9389">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-288a59fb-3124-43f7-ac12-71716c5f9389">
											<gml:posList>35.67194485990375 139.74747070287773 28.357 35.671946386428644 139.74747519715856 28.357 35.67196755974631 139.74741211013617 28.357 35.67196389250144 139.74741399196768 28.357 35.67194485990375 139.74747070287773 28.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5de7a63-0722-496e-81c9-386f8a0c7814">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5de7a63-0722-496e-81c9-386f8a0c7814">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5de7a63-0722-496e-81c9-386f8a0c7814">
											<gml:posList>35.67198688694742 139.7475030571983 25.7 35.67198911784635 139.74749673622236 25.7 35.671946386428644 139.74747519715856 25.7 35.67194425471326 139.74748156221142 25.7 35.67198688694742 139.7475030571983 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f5d4b2fd-7191-4d0b-bb64-041017dc62a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5d4b2fd-7191-4d0b-bb64-041017dc62a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5d4b2fd-7191-4d0b-bb64-041017dc62a5">
											<gml:posList>35.672092402944656 139.74777083281174 25.019 35.672154073160236 139.7475910182733 25.019 35.672138852420574 139.74758320258127 25.019 35.67198688694742 139.7475030571983 25.019 35.67194425471326 139.74748156221142 25.019 35.67185878285397 139.7474384841566 25.019 35.671800329589594 139.74761664878815 25.019 35.67179925915842 139.74761974294015 25.019 35.672092402944656 139.74777083281174 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c235c08-3b87-468e-b472-1f391d041f48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c235c08-3b87-468e-b472-1f391d041f48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c235c08-3b87-468e-b472-1f391d041f48">
											<gml:posList>35.67214601303974 139.74756311237925 22.6 35.6718995006112 139.7473412978806 22.6 35.6718977899604 139.74734403923978 22.6 35.67189869191637 139.74734485571113 22.6 35.672144392481854 139.74756579841323 22.6 35.67214601303974 139.74756311237925 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-067dfc5e-30af-4eb8-aea2-1443f02a3efd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-067dfc5e-30af-4eb8-aea2-1443f02a3efd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-067dfc5e-30af-4eb8-aea2-1443f02a3efd">
											<gml:posList>35.672138852420574 139.74758320258127 25.7 35.672141056282484 139.74757688162452 25.7 35.67198911784635 139.74749673622236 25.7 35.67198688694742 139.7475030571983 25.7 35.672138852420574 139.74758320258127 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2bde59eb-4c6c-4741-86de-ce484536a427">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bde59eb-4c6c-4741-86de-ce484536a427">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bde59eb-4c6c-4741-86de-ce484536a427">
											<gml:posList>35.672092402944656 139.74777083281174 25.7 35.67209541092676 139.74777985458914 25.7 35.672161434767226 139.74758735400692 25.7 35.672154073160236 139.7475910182733 25.7 35.672092402944656 139.74777083281174 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d58fe445-0443-4707-951c-a88c06ac60b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d58fe445-0443-4707-951c-a88c06ac60b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d58fe445-0443-4707-951c-a88c06ac60b2">
											<gml:posList>35.672141056282484 139.74757688162452 22.6 35.67214816870411 139.7475650542577 22.6 35.67214601303974 139.74756311237925 22.6 35.672144392481854 139.74756579841323 22.6 35.672138522474704 139.747575547708 22.6 35.672141056282484 139.74757688162452 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b05f138a-0a2d-49cd-85f2-ff5802a76c6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b05f138a-0a2d-49cd-85f2-ff5802a76c6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b05f138a-0a2d-49cd-85f2-ff5802a76c6b">
											<gml:posList>35.672154073160236 139.7475910182733 25.7 35.672161434767226 139.74758735400692 25.7 35.672141056282484 139.74757688162452 25.7 35.672138852420574 139.74758320258127 25.7 35.672154073160236 139.7475910182733 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff5544b2-49ba-46e6-8086-93d13d62a445">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff5544b2-49ba-46e6-8086-93d13d62a445">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff5544b2-49ba-46e6-8086-93d13d62a445">
											<gml:posList>35.671749523886085 139.74758525386684 22.6 35.671796278079555 139.74761054443002 22.6 35.671796278079555 139.74761054443002 22.236 35.671749523886085 139.74758525386684 22.236 35.671749523886085 139.74758525386684 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9810fb52-168f-4907-b30d-f84bb39c55a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9810fb52-168f-4907-b30d-f84bb39c55a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9810fb52-168f-4907-b30d-f84bb39c55a3">
											<gml:posList>35.671796278079555 139.74761054443002 22.6 35.671856386274094 139.747427351889 22.6 35.671856386274094 139.747427351889 22.236 35.671796278079555 139.74761054443002 22.236 35.671796278079555 139.74761054443002 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9bf29e21-d0d9-4272-b9f1-20b720760da0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bf29e21-d0d9-4272-b9f1-20b720760da0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bf29e21-d0d9-4272-b9f1-20b720760da0">
											<gml:posList>35.671856386274094 139.747427351889 22.6 35.671865276333904 139.74743088827842 22.6 35.671865276333904 139.74743088827842 22.236 35.671856386274094 139.747427351889 22.236 35.671856386274094 139.747427351889 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0088eb39-09a4-4f2c-aae1-22ea9ee26954">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0088eb39-09a4-4f2c-aae1-22ea9ee26954">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0088eb39-09a4-4f2c-aae1-22ea9ee26954">
											<gml:posList>35.671865276333904 139.74743088827842 22.6 35.671885460209154 139.747370729683 22.6 35.671885460209154 139.747370729683 22.236 35.671865276333904 139.74743088827842 22.236 35.671865276333904 139.74743088827842 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3923d60a-464b-46b5-a5dc-cef401ddf727">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3923d60a-464b-46b5-a5dc-cef401ddf727">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3923d60a-464b-46b5-a5dc-cef401ddf727">
											<gml:posList>35.671885460209154 139.747370729683 22.6 35.67196755974631 139.74741211013617 22.6 35.67196755974631 139.74741211013617 22.236 35.671885460209154 139.747370729683 22.236 35.671885460209154 139.747370729683 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be0d5d40-fe4b-4057-a5bb-6fe68820db5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be0d5d40-fe4b-4057-a5bb-6fe68820db5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be0d5d40-fe4b-4057-a5bb-6fe68820db5b">
											<gml:posList>35.671946386428644 139.74747519715856 22.6 35.67198911784635 139.74749673622236 22.6 35.67198911784635 139.74749673622236 22.236 35.671946386428644 139.74747519715856 22.236 35.671946386428644 139.74747519715856 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c34821fd-fbc2-479d-b61b-9d601d22f3ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c34821fd-fbc2-479d-b61b-9d601d22f3ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c34821fd-fbc2-479d-b61b-9d601d22f3ab">
											<gml:posList>35.67198911784635 139.74749673622236 22.6 35.672138522474704 139.747575547708 22.6 35.672138522474704 139.747575547708 22.236 35.67198911784635 139.74749673622236 22.236 35.67198911784635 139.74749673622236 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a1ffd5d-dbda-4516-9b03-dc2099adaab6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a1ffd5d-dbda-4516-9b03-dc2099adaab6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a1ffd5d-dbda-4516-9b03-dc2099adaab6">
											<gml:posList>35.67196755974631 139.74741211013617 22.6 35.671885460209154 139.747370729683 22.6 35.671885460209154 139.747370729683 28.357 35.67196755974631 139.74741211013617 28.357 35.67196755974631 139.74741211013617 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f80cece-ee04-48df-a626-33c42171e677">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f80cece-ee04-48df-a626-33c42171e677">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f80cece-ee04-48df-a626-33c42171e677">
											<gml:posList>35.67196389250144 139.74741399196768 27.628 35.67196389250144 139.74741399196768 28.357 35.671886995759394 139.74737523499542 28.357 35.671886995759394 139.74737523499542 27.628 35.67196389250144 139.74741399196768 27.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51e97eb4-209e-4d49-8531-50bccf6063fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51e97eb4-209e-4d49-8531-50bccf6063fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51e97eb4-209e-4d49-8531-50bccf6063fe">
											<gml:posList>35.671885460209154 139.747370729683 28.357 35.671885460209154 139.747370729683 22.6 35.671865276333904 139.74743088827842 22.6 35.671865276333904 139.74743088827842 25.7 35.67186428691281 139.74743381665166 25.7 35.67186428691281 139.74743381665166 28.357 35.671885460209154 139.747370729683 28.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11dd1932-921a-4578-bdd4-f83e5747d793">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11dd1932-921a-4578-bdd4-f83e5747d793">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11dd1932-921a-4578-bdd4-f83e5747d793">
											<gml:posList>35.671886995759394 139.74737523499542 27.628 35.671886995759394 139.74737523499542 28.357 35.67186796317966 139.74743194586023 28.357 35.67186796317966 139.74743194586023 27.628 35.671886995759394 139.74737523499542 27.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffb6f9e7-c4e4-4e73-9cda-022b9c085cca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffb6f9e7-c4e4-4e73-9cda-022b9c085cca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffb6f9e7-c4e4-4e73-9cda-022b9c085cca">
											<gml:posList>35.671865276333904 139.74743088827842 22.6 35.671856386274094 139.747427351889 22.6 35.671856386274094 139.747427351889 25.7 35.671865276333904 139.74743088827842 25.7 35.671865276333904 139.74743088827842 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68538651-ca5f-4b0a-b25d-47310f861f9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68538651-ca5f-4b0a-b25d-47310f861f9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68538651-ca5f-4b0a-b25d-47310f861f9d">
											<gml:posList>35.67194485990375 139.74747070287773 27.628 35.67194485990375 139.74747070287773 28.357 35.67196389250144 139.74741399196768 28.357 35.67196389250144 139.74741399196768 27.628 35.67194485990375 139.74747070287773 27.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b00a5028-4ce6-4eb2-b7b2-607fb8b3d35f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b00a5028-4ce6-4eb2-b7b2-607fb8b3d35f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b00a5028-4ce6-4eb2-b7b2-607fb8b3d35f">
											<gml:posList>35.67196755974631 139.74741211013617 22.6 35.671946386428644 139.74747519715856 22.6 35.671946386428644 139.74747519715856 22.236 35.67196755974631 139.74741211013617 22.236 35.67196755974631 139.74741211013617 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0529895a-fde1-4c30-8cf1-bd05ece4152d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0529895a-fde1-4c30-8cf1-bd05ece4152d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0529895a-fde1-4c30-8cf1-bd05ece4152d">
											<gml:posList>35.67196755974631 139.74741211013617 28.357 35.671946386428644 139.74747519715856 28.357 35.671946386428644 139.74747519715856 25.7 35.671946386428644 139.74747519715856 22.6 35.67196755974631 139.74741211013617 22.6 35.67196755974631 139.74741211013617 28.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-143e84dd-8ba8-4d09-b74a-51c5498b00d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-143e84dd-8ba8-4d09-b74a-51c5498b00d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-143e84dd-8ba8-4d09-b74a-51c5498b00d2">
											<gml:posList>35.67186796317966 139.74743194586023 27.628 35.67186796317966 139.74743194586023 28.357 35.67194485990375 139.74747070287773 28.357 35.67194485990375 139.74747070287773 27.628 35.67186796317966 139.74743194586023 27.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67ca3e61-73ed-48ed-a685-ed2ec472bc07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67ca3e61-73ed-48ed-a685-ed2ec472bc07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67ca3e61-73ed-48ed-a685-ed2ec472bc07">
											<gml:posList>35.67214816870411 139.7475650542577 7.4 35.6718995006112 139.7473412978806 7.4 35.6718995006112 139.7473412978806 22.6 35.67214601303974 139.74756311237925 22.6 35.67214816870411 139.7475650542577 22.6 35.67214816870411 139.7475650542577 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2040bc3-cefe-4c48-9bc6-b2bd31fe049c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2040bc3-cefe-4c48-9bc6-b2bd31fe049c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2040bc3-cefe-4c48-9bc6-b2bd31fe049c">
											<gml:posList>35.67186428691281 139.74743381665166 25.7 35.671946386428644 139.74747519715856 25.7 35.671946386428644 139.74747519715856 28.357 35.67186428691281 139.74743381665166 28.357 35.67186428691281 139.74743381665166 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fcfc505-e211-4cfe-99bd-bc1649a5aa74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fcfc505-e211-4cfe-99bd-bc1649a5aa74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fcfc505-e211-4cfe-99bd-bc1649a5aa74">
											<gml:posList>35.672144392481854 139.74756579841323 22.6 35.67189869191637 139.74734485571113 22.6 35.67189869191637 139.74734485571113 22.236 35.672144392481854 139.74756579841323 22.236 35.672144392481854 139.74756579841323 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96410c62-7d4b-4db3-b0c4-62edf55f1d67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96410c62-7d4b-4db3-b0c4-62edf55f1d67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96410c62-7d4b-4db3-b0c4-62edf55f1d67">
											<gml:posList>35.67194425471326 139.74748156221142 25.019 35.67194425471326 139.74748156221142 25.7 35.67185878285397 139.7474384841566 25.7 35.67185878285397 139.7474384841566 25.019 35.67194425471326 139.74748156221142 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a357590b-629a-497a-970f-80ab7d9db2b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a357590b-629a-497a-970f-80ab7d9db2b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a357590b-629a-497a-970f-80ab7d9db2b6">
											<gml:posList>35.6718995006112 139.7473412978806 7.4 35.67174509110125 139.7475880202199 7.4 35.67174509110125 139.7475880202199 22.6 35.67174750403348 139.74758416242875 22.6 35.6718977899604 139.74734403923978 22.6 35.6718995006112 139.7473412978806 22.6 35.6718995006112 139.7473412978806 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-774cc937-baed-4217-9ee1-c0f335a3fd56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-774cc937-baed-4217-9ee1-c0f335a3fd56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-774cc937-baed-4217-9ee1-c0f335a3fd56">
											<gml:posList>35.67189869191637 139.74734485571113 22.6 35.671749523886085 139.74758525386684 22.6 35.671749523886085 139.74758525386684 22.236 35.67189869191637 139.74734485571113 22.236 35.67189869191637 139.74734485571113 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eea350c6-afd5-4485-9647-0277a92cfff2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eea350c6-afd5-4485-9647-0277a92cfff2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eea350c6-afd5-4485-9647-0277a92cfff2">
											<gml:posList>35.67198911784635 139.74749673622236 22.6 35.671946386428644 139.74747519715856 22.6 35.671946386428644 139.74747519715856 25.7 35.67198911784635 139.74749673622236 25.7 35.67198911784635 139.74749673622236 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66df2721-8b6b-462d-9336-23e5211c3b45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66df2721-8b6b-462d-9336-23e5211c3b45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66df2721-8b6b-462d-9336-23e5211c3b45">
											<gml:posList>35.67198688694742 139.7475030571983 25.019 35.67198688694742 139.7475030571983 25.7 35.67194425471326 139.74748156221142 25.7 35.67194425471326 139.74748156221142 25.019 35.67198688694742 139.7475030571983 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b1801a9-b300-42af-ad28-f5cd36b6c7d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b1801a9-b300-42af-ad28-f5cd36b6c7d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b1801a9-b300-42af-ad28-f5cd36b6c7d1">
											<gml:posList>35.671795135821846 139.74761403633116 25.7 35.671856386274094 139.747427351889 25.7 35.671856386274094 139.747427351889 22.6 35.671796278079555 139.74761054443002 22.6 35.671795135821846 139.74761403633116 22.6 35.671795135821846 139.74761403633116 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31eb1b08-1ee8-4656-8255-ec3d77989ed0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31eb1b08-1ee8-4656-8255-ec3d77989ed0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31eb1b08-1ee8-4656-8255-ec3d77989ed0">
											<gml:posList>35.67185878285397 139.7474384841566 25.019 35.67185878285397 139.7474384841566 25.7 35.671800329589594 139.74761664878815 25.7 35.671800329589594 139.74761664878815 25.019 35.67185878285397 139.7474384841566 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07bb8b6a-1deb-46de-a935-a10579ebfd00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07bb8b6a-1deb-46de-a935-a10579ebfd00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07bb8b6a-1deb-46de-a935-a10579ebfd00">
											<gml:posList>35.67198911784635 139.74749673622236 25.7 35.672141056282484 139.74757688162452 25.7 35.672141056282484 139.74757688162452 22.6 35.672138522474704 139.747575547708 22.6 35.67198911784635 139.74749673622236 22.6 35.67198911784635 139.74749673622236 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cee7b6b2-39d3-467e-ba5d-9efb045cebaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cee7b6b2-39d3-467e-ba5d-9efb045cebaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cee7b6b2-39d3-467e-ba5d-9efb045cebaa">
											<gml:posList>35.672138852420574 139.74758320258127 25.019 35.672138852420574 139.74758320258127 25.7 35.67198688694742 139.7475030571983 25.7 35.67198688694742 139.7475030571983 25.019 35.672138852420574 139.74758320258127 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-745e011a-70d4-40d2-a44e-412c256c7104">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-745e011a-70d4-40d2-a44e-412c256c7104">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-745e011a-70d4-40d2-a44e-412c256c7104">
											<gml:posList>35.672138522474704 139.747575547708 22.6 35.672144392481854 139.74756579841323 22.6 35.672144392481854 139.74756579841323 22.236 35.672138522474704 139.747575547708 22.236 35.672138522474704 139.747575547708 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2647c16b-304c-4f37-ba33-496d324f9688">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2647c16b-304c-4f37-ba33-496d324f9688">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2647c16b-304c-4f37-ba33-496d324f9688">
											<gml:posList>35.67214816870411 139.7475650542577 22.6 35.672141056282484 139.74757688162452 22.6 35.672141056282484 139.74757688162452 7.4 35.67214816870411 139.7475650542577 7.4 35.67214816870411 139.7475650542577 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cee1ba8-b5ec-44e2-92c8-772ea8d3c062">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cee1ba8-b5ec-44e2-92c8-772ea8d3c062">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cee1ba8-b5ec-44e2-92c8-772ea8d3c062">
											<gml:posList>35.672161434767226 139.74758735400692 25.7 35.672161434767226 139.74758735400692 7.4 35.672141056282484 139.74757688162452 7.4 35.672141056282484 139.74757688162452 22.6 35.672141056282484 139.74757688162452 25.7 35.672161434767226 139.74758735400692 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21b153eb-eed3-4f64-81a6-990cd7731eb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21b153eb-eed3-4f64-81a6-990cd7731eb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21b153eb-eed3-4f64-81a6-990cd7731eb1">
											<gml:posList>35.672154073160236 139.7475910182733 25.019 35.672154073160236 139.7475910182733 25.7 35.672138852420574 139.74758320258127 25.7 35.672138852420574 139.74758320258127 25.019 35.672154073160236 139.7475910182733 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78df1595-0964-471c-a0b2-fc09c046af34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78df1595-0964-471c-a0b2-fc09c046af34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78df1595-0964-471c-a0b2-fc09c046af34">
											<gml:posList>35.671795135821846 139.74761403633116 22.6 35.67174509110125 139.7475880202199 22.6 35.67174509110125 139.7475880202199 7.4 35.671795135821846 139.74761403633116 7.4 35.671795135821846 139.74761403633116 22.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a08ec06b-f443-4907-a907-fb2d2debe24e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a08ec06b-f443-4907-a907-fb2d2debe24e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a08ec06b-f443-4907-a907-fb2d2debe24e">
											<gml:posList>35.671800329589594 139.74761664878815 25.019 35.671800329589594 139.74761664878815 25.7 35.67179925915842 139.74761974294015 25.7 35.67179925915842 139.74761974294015 25.019 35.671800329589594 139.74761664878815 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18cf3d13-84cc-4636-9d84-1dd066bd22d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18cf3d13-84cc-4636-9d84-1dd066bd22d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18cf3d13-84cc-4636-9d84-1dd066bd22d4">
											<gml:posList>35.6717918975657 139.74762342927988 25.7 35.671795135821846 139.74761403633116 25.7 35.671795135821846 139.74761403633116 22.6 35.671795135821846 139.74761403633116 7.4 35.6717918975657 139.74762342927988 7.4 35.6717918975657 139.74762342927988 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c91da311-4099-437e-a3a2-702ab0f5f0fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c91da311-4099-437e-a3a2-702ab0f5f0fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c91da311-4099-437e-a3a2-702ab0f5f0fd">
											<gml:posList>35.672092402944656 139.74777083281174 25.019 35.672092402944656 139.74777083281174 25.7 35.672154073160236 139.7475910182733 25.7 35.672154073160236 139.7475910182733 25.019 35.672092402944656 139.74777083281174 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c23ee4b-a1fc-4760-b8d8-38f25412a0ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c23ee4b-a1fc-4760-b8d8-38f25412a0ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c23ee4b-a1fc-4760-b8d8-38f25412a0ef">
											<gml:posList>35.672161434767226 139.74758735400692 25.7 35.67209541092676 139.74777985458914 25.7 35.67209541092676 139.74777985458914 7.4 35.672161434767226 139.74758735400692 7.4 35.672161434767226 139.74758735400692 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6475a86e-f61f-48c3-bb50-9902598def88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6475a86e-f61f-48c3-bb50-9902598def88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6475a86e-f61f-48c3-bb50-9902598def88">
											<gml:posList>35.67179925915842 139.74761974294015 25.019 35.67179925915842 139.74761974294015 25.7 35.672092402944656 139.74777083281174 25.7 35.672092402944656 139.74777083281174 25.019 35.67179925915842 139.74761974294015 25.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e4ce829-1247-44b2-b53c-de6135761139">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e4ce829-1247-44b2-b53c-de6135761139">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e4ce829-1247-44b2-b53c-de6135761139">
											<gml:posList>35.67209541092676 139.74777985458914 25.7 35.6717918975657 139.74762342927988 25.7 35.6717918975657 139.74762342927988 7.4 35.67209541092676 139.74777985458914 7.4 35.67209541092676 139.74777985458914 25.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区霞が関三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-61</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">1117.61447</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>