<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_78078110-0aa0-4aab-a1de-e8ff50ea3be1">
			<core:creationDate>2023-08-22</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門一・二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">17</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66673973182275 139.7480157084608 0 35.66674824159104 139.74803083430683 0 35.6667972860787 139.74805479452635 0 35.66680083969855 139.74804391177113 0 35.66685211405681 139.74806896869777 0 35.66686882589658 139.7480771325346 0 35.66689403743496 139.74799967260313 0 35.666920803973696 139.7480127433137 0 35.66693315480134 139.74797487737064 0 35.66678253535681 139.74790128955019 0 35.66673973182275 139.7480157084608 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
							<gml:interior>
								<gml:LinearRing>
									<gml:posList>35.666819356123916 139.74794655012732 0 35.66682089079412 139.74794730071008 0 35.66681932671345 139.74795210728533 0 35.66688153763522 139.74798250198793 0 35.66686028624591 139.74804780403485 0 35.66680790190816 139.7480222048483 0 35.666796546977835 139.74801665538524 0 35.666819356123916 139.74794655012732 0</gml:posList>
								</gml:LinearRing>
							</gml:interior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66673973182275 139.7480157084608 5.36 35.66678253535681 139.74790128955019 5.36 35.66693315480134 139.74797487737064 5.36 35.666920803973696 139.7480127433137 5.36 35.66689403743496 139.74799967260313 5.36 35.66686882589658 139.7480771325346 5.36 35.66685211405681 139.74806896869777 5.36 35.66680083969855 139.74804391177113 5.36 35.6667972860787 139.74805479452635 5.36 35.66674824159104 139.74803083430683 5.36 35.66673973182275 139.7480157084608 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
									<gml:interior>
										<gml:LinearRing>
											<gml:posList>35.666819356123916 139.74794655012732 5.36 35.666796546977835 139.74801665538524 5.36 35.66680790190816 139.7480222048483 5.36 35.66686028624591 139.74804780403485 5.36 35.66688153763522 139.74798250198793 5.36 35.66681932671345 139.74795210728533 5.36 35.66682089079412 139.74794730071008 5.36 35.666819356123916 139.74794655012732 5.36</gml:posList>
										</gml:LinearRing>
									</gml:interior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66673973182275 139.7480157084608 5.36 35.66674824159104 139.74803083430683 5.36 35.66674824159104 139.74803083430683 13.27 35.66673973182275 139.7480157084608 13.27 35.66673973182275 139.7480157084608 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66674824159104 139.74803083430683 5.36 35.6667972860787 139.74805479452635 5.36 35.6667972860787 139.74805479452635 13.27 35.66674824159104 139.74803083430683 13.27 35.66674824159104 139.74803083430683 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6667972860787 139.74805479452635 5.36 35.66680083969855 139.74804391177113 5.36 35.66680083969855 139.74804391177113 13.27 35.6667972860787 139.74805479452635 13.27 35.6667972860787 139.74805479452635 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66680083969855 139.74804391177113 5.36 35.66685211405681 139.74806896869777 5.36 35.66685211405681 139.74806896869777 13.27 35.66680083969855 139.74804391177113 13.27 35.66680083969855 139.74804391177113 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66685211405681 139.74806896869777 5.36 35.66686882589658 139.7480771325346 5.36 35.66686882589658 139.7480771325346 13.27 35.66685211405681 139.74806896869777 13.27 35.66685211405681 139.74806896869777 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66686882589658 139.7480771325346 5.36 35.66689403743496 139.74799967260313 5.36 35.66689403743496 139.74799967260313 13.27 35.66686882589658 139.7480771325346 13.27 35.66686882589658 139.7480771325346 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66689403743496 139.74799967260313 5.36 35.666920803973696 139.7480127433137 5.36 35.666920803973696 139.7480127433137 13.27 35.66689403743496 139.74799967260313 13.27 35.66689403743496 139.74799967260313 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666920803973696 139.7480127433137 5.36 35.66693315480134 139.74797487737064 5.36 35.66693315480134 139.74797487737064 13.27 35.666920803973696 139.7480127433137 13.27 35.666920803973696 139.7480127433137 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66693315480134 139.74797487737064 5.36 35.66678253535681 139.74790128955019 5.36 35.66678253535681 139.74790128955019 13.27 35.66693315480134 139.74797487737064 13.27 35.66693315480134 139.74797487737064 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66678253535681 139.74790128955019 5.36 35.66673973182275 139.7480157084608 5.36 35.66673973182275 139.7480157084608 13.27 35.66678253535681 139.74790128955019 13.27 35.66678253535681 139.74790128955019 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666819356123916 139.74794655012732 5.36 35.66682089079412 139.74794730071008 5.36 35.66682089079412 139.74794730071008 13.27 35.666819356123916 139.74794655012732 13.27 35.666819356123916 139.74794655012732 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66682089079412 139.74794730071008 5.36 35.66681932671345 139.74795210728533 5.36 35.66681932671345 139.74795210728533 13.27 35.66682089079412 139.74794730071008 13.27 35.66682089079412 139.74794730071008 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66681932671345 139.74795210728533 5.36 35.66688153763522 139.74798250198793 5.36 35.66688153763522 139.74798250198793 13.27 35.66681932671345 139.74795210728533 13.27 35.66681932671345 139.74795210728533 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66688153763522 139.74798250198793 5.36 35.66686028624591 139.74804780403485 5.36 35.66686028624591 139.74804780403485 13.27 35.66688153763522 139.74798250198793 13.27 35.66688153763522 139.74798250198793 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66686028624591 139.74804780403485 5.36 35.66680790190816 139.7480222048483 5.36 35.66680790190816 139.7480222048483 13.27 35.66686028624591 139.74804780403485 13.27 35.66686028624591 139.74804780403485 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66680790190816 139.7480222048483 5.36 35.666796546977835 139.74801665538524 5.36 35.666796546977835 139.74801665538524 13.27 35.66680790190816 139.7480222048483 13.27 35.66680790190816 139.7480222048483 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666796546977835 139.74801665538524 5.36 35.666819356123916 139.74794655012732 5.36 35.666819356123916 139.74794655012732 13.27 35.666796546977835 139.74801665538524 13.27 35.666796546977835 139.74801665538524 5.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66673973182275 139.7480157084608 13.27 35.66674824159104 139.74803083430683 13.27 35.6667972860787 139.74805479452635 13.27 35.66680083969855 139.74804391177113 13.27 35.66685211405681 139.74806896869777 13.27 35.66686882589658 139.7480771325346 13.27 35.66689403743496 139.74799967260313 13.27 35.666920803973696 139.7480127433137 13.27 35.66693315480134 139.74797487737064 13.27 35.66678253535681 139.74790128955019 13.27 35.66673973182275 139.7480157084608 13.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
									<gml:interior>
										<gml:LinearRing>
											<gml:posList>35.666819356123916 139.74794655012732 13.27 35.66682089079412 139.74794730071008 13.27 35.66681932671345 139.74795210728533 13.27 35.66688153763522 139.74798250198793 13.27 35.66686028624591 139.74804780403485 13.27 35.66680790190816 139.7480222048483 13.27 35.666796546977835 139.74801665538524 13.27 35.666819356123916 139.74794655012732 13.27</gml:posList>
										</gml:LinearRing>
									</gml:interior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p55_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p55_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p55_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p53_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p53_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p53_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p53_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p51_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p51_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p51_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p51_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p51_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p51_5"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p54_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p54_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p54_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p54_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p54_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p50_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p50_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p50_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p50_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p50_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p49_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p49_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p48_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p48_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p48_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p48_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p47_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p47_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p47_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_p47_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0004_b_0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gnd_TMmnt0004_b_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_b_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_b_0">
											<gml:posList>35.666739754774255 139.74801571471346 5.39344999 35.666782547091735 139.74790129238926 5.39444174 35.666933155095045 139.7479748771724 5.40135264 35.66692083274161 139.74801275072377 5.40109992 35.666894041062754 139.7479996606811 5.39986682 35.66686882988151 139.74807713413222 5.3993563 35.666800840398 139.74804390905192 5.39623425 35.666797297919494 139.74805479705418 5.39616325 35.666748265375084 139.74803084044913 5.39391816 35.666739754774255 139.74801571471346 5.39344999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
									<gml:interior>
										<gml:LinearRing gml:id="line_TMmnt0004_b_0_hole0">
											<gml:posList>35.666860294720735 139.74804780826167 5.39878125 35.666881547822015 139.7479824983334 5.39921314 35.66681936171678 139.74795211606755 5.39635938 35.66682092551791 139.74794730947426 5.3963914 35.666819358015424 139.74794654361656 5.39631958 35.666796546615736 139.74801665585386 5.39585588 35.66680790196312 139.7480222049322 5.39637631 35.666860294720735 139.74804780826167 5.39878125</gml:posList>
										</gml:LinearRing>
									</gml:interior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0004_p49_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p49_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p49_0">
											<gml:posList>35.66678627468855 139.7479303871618 14.67445964 35.666820893597446 139.74794730142395 14.67604457 35.66682854774504 139.74792377516306 14.67620179 35.6667939290381 139.74790686100985 14.67461687 35.66678627468855 139.7479303871618 14.67445964</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0004_p54_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p54_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p54_0">
											<gml:posList>35.666781711937176 139.748026122493 14.18995137 35.66678918730079 139.74800314653282 14.19010202 35.6667739137364 139.7479956838672 14.18940283 35.6667664380455 139.74801865964673 14.18925217 35.666781711937176 139.748026122493 14.18995137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0004_p53_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p53_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p53_1">
											<gml:posList>35.66685917485321 139.74804726396752 9.09838396 35.66680788922436 139.74802220174115 9.0960299 35.66680082768352 139.7480439057864 9.09588784 35.66685211197696 139.74806896737383 9.09824184 35.66685917485321 139.74804726396752 9.09838396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0004_p48_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p48_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p48_1">
											<gml:posList>35.66692077387762 139.74801273577108 22.43575248 35.66693309619804 139.74797486232072 22.43600521 35.66690520218742 139.747961233708 22.43472141 35.66689287987148 139.74799910714663 22.43446868 35.66692077387762 139.74801273577108 22.43575248</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0004_p55_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p55_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p55_0">
											<gml:posList>35.666881539217044 139.74798249615552 7.89386682 35.66686028612412 139.74804780605825 7.89343493 35.66685917900543 139.74804726503177 7.89338405 35.66685211612782 139.7480689684422 7.89324193 35.66686882128146 139.74807713191728 7.89400998 35.6668940324529 139.74799965849647 7.8945205 35.66689293005123 139.74799911987847 7.89446979 35.666896034509804 139.74798957812814 7.89453326 35.666881539217044 139.74798249615552 7.89386682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0004_p50_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p50_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p50_0">
											<gml:posList>35.666819328006305 139.74794653604872 14.12097278 35.666786276594564 139.7479303876418 14.11945968 35.66676289737184 139.74800224512083 14.11898454 35.666770560862126 139.7480059893889 14.11933516 35.666773913976755 139.74799568392848 14.11940284 35.666789187541234 139.74800314659421 14.12010203 35.66678583463943 139.7480134519329 14.12003436 35.66679594877402 139.74801839355268 14.12049764 35.666819328006305 139.74794653604872 14.12097278</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0004_p47_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p47_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p47_0">
											<gml:posList>35.6668193270642 139.74795210731995 15.47101248 35.66689600834634 139.74798957150202 15.47453268 35.66690522622099 139.74796123976125 15.47472194 35.66682854500942 139.7479237744764 15.47120173 35.6668193270642 139.74795210731995 15.47101248</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0004_p51_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p51_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p51_1">
											<gml:posList>35.666782523708825 139.74790128653075 12.20409509 35.66673973143706 139.74801570873294 12.20310335 35.66674824202885 139.7480308344525 12.20357152 35.6667972745208 139.74805479103193 12.2058166 35.666807878552994 139.7480221989448 12.20602966 35.666796523217776 139.74801664987228 12.20550924 35.666795955353706 139.74801839523525 12.20549779 35.66678584121615 139.74801345361402 12.2050345 35.66678171875297 139.74802612423957 12.20495152 35.66676644485653 139.74801866139092 12.20425232 35.66677056743424 139.74800599106783 12.20433531 35.66676290394161 139.74800224679865 12.20398469 35.66679393752397 139.74790686313693 12.20461705 35.666782523708825 139.74790128653075 12.20409509</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p53_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p53_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p53_3">
											<gml:posList>35.66685211197696 139.74806896737383 9.09824184 35.66685211612782 139.7480689684422 7.89324193 35.66685917900543 139.74804726503177 7.89338405 35.66685917485321 139.74804726396752 9.09838396 35.66685211197696 139.74806896737383 9.09824184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p51_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p51_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p51_2">
											<gml:posList>35.66674824202885 139.7480308344525 12.20357152 35.66673973143706 139.74801570873294 12.20310335 35.666739754774255 139.74801571471346 5.39344999 35.666748265375084 139.74803084044913 5.39391816 35.66674824202885 139.7480308344525 12.20357152</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p50_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p50_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p50_4">
											<gml:posList>35.66676290394161 139.74800224679865 12.20398469 35.66677056743424 139.74800599106783 12.20433531 35.666770560862126 139.7480059893889 14.11933516 35.66676289737184 139.74800224512083 14.11898454 35.66676290394161 139.74800224679865 12.20398469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p51_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p51_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p51_0">
											<gml:posList>35.666796546615736 139.74801665585386 5.39585588 35.666796523217776 139.74801664987228 12.20550924 35.666807878552994 139.7480221989448 12.20602966 35.66680788922436 139.74802220174115 9.0960299 35.66680790196312 139.7480222049322 5.39637631 35.666796546615736 139.74801665585386 5.39585588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p50_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p50_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p50_2">
											<gml:posList>35.66676289737184 139.74800224512083 14.11898454 35.666786276594564 139.7479303876418 14.11945968 35.66678627468855 139.7479303871618 14.67445964 35.6667939290381 139.74790686100985 14.67461687 35.66679393752397 139.74790686313693 12.20461705 35.66676290394161 139.74800224679865 12.20398469 35.66676289737184 139.74800224512083 14.11898454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p50_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p50_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p50_3">
											<gml:posList>35.66679594877402 139.74801839355268 14.12049764 35.66678583463943 139.7480134519329 14.12003436 35.66678584121615 139.74801345361402 12.2050345 35.666795955353706 139.74801839523525 12.20549779 35.66679594877402 139.74801839355268 14.12049764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p48_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p48_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p48_0">
											<gml:posList>35.66692077387762 139.74801273577108 22.43575248 35.66689287987148 139.74799910714663 22.43446868 35.66689293005123 139.74799911987847 7.89446979 35.6668940324529 139.74799965849647 7.8945205 35.666894041062754 139.7479996606811 5.39986682 35.66692083274161 139.74801275072377 5.40109992 35.66692077387762 139.74801273577108 22.43575248</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p47_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p47_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p47_1">
											<gml:posList>35.6668193270642 139.74795210731995 15.47101248 35.66682854500942 139.7479237744764 15.47120173 35.66682854774504 139.74792377516306 14.67620179 35.666820893597446 139.74794730142395 14.67604457 35.66682092551791 139.74794730947426 5.3963914 35.66681936171678 139.74795211606755 5.39635938 35.6668193270642 139.74795210731995 15.47101248</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p53_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p53_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p53_2">
											<gml:posList>35.666800840398 139.74804390905192 5.39623425 35.66686882988151 139.74807713413222 5.3993563 35.66686882128146 139.74807713191728 7.89400998 35.66685211612782 139.7480689684422 7.89324193 35.66685211197696 139.74806896737383 9.09824184 35.66680082768352 139.7480439057864 9.09588784 35.666800840398 139.74804390905192 5.39623425</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p47_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p47_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p47_3">
											<gml:posList>35.666881547822015 139.7479824983334 5.39921314 35.666881539217044 139.74798249615552 7.89386682 35.666896034509804 139.74798957812814 7.89453326 35.66689600834634 139.74798957150202 15.47453268 35.6668193270642 139.74795210731995 15.47101248 35.66681936171678 139.74795211606755 5.39635938 35.666881547822015 139.7479824983334 5.39921314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p51_5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p51_5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p51_5">
											<gml:posList>35.6667972745208 139.74805479103193 12.2058166 35.66674824202885 139.7480308344525 12.20357152 35.666748265375084 139.74803084044913 5.39391816 35.666797297919494 139.74805479705418 5.39616325 35.6667972745208 139.74805479103193 12.2058166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p53_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p53_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p53_0">
											<gml:posList>35.66685917485321 139.74804726396752 9.09838396 35.66685917900543 139.74804726503177 7.89338405 35.66686028612412 139.74804780605825 7.89343493 35.666860294720735 139.74804780826167 5.39878125 35.66680790196312 139.7480222049322 5.39637631 35.66680788922436 139.74802220174115 9.0960299 35.66685917485321 139.74804726396752 9.09838396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p48_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p48_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p48_3">
											<gml:posList>35.66689287987148 139.74799910714663 22.43446868 35.66690520218742 139.747961233708 22.43472141 35.66690522622099 139.74796123976125 15.47472194 35.66689600834634 139.74798957150202 15.47453268 35.666896034509804 139.74798957812814 7.89453326 35.66689293005123 139.74799911987847 7.89446979 35.66689287987148 139.74799910714663 22.43446868</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p51_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p51_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p51_4">
											<gml:posList>35.66680082768352 139.7480439057864 9.09588784 35.66680788922436 139.74802220174115 9.0960299 35.666807878552994 139.7480221989448 12.20602966 35.6667972745208 139.74805479103193 12.2058166 35.666797297919494 139.74805479705418 5.39616325 35.666800840398 139.74804390905192 5.39623425 35.66680082768352 139.7480439057864 9.09588784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p51_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p51_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p51_3">
											<gml:posList>35.66673973143706 139.74801570873294 12.20310335 35.666782523708825 139.74790128653075 12.20409509 35.666782547091735 139.74790129238926 5.39444174 35.666739754774255 139.74801571471346 5.39344999 35.66673973143706 139.74801570873294 12.20310335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p55_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p55_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p55_2">
											<gml:posList>35.66686882988151 139.74807713413222 5.3993563 35.666894041062754 139.7479996606811 5.39986682 35.6668940324529 139.74799965849647 7.8945205 35.66686882128146 139.74807713191728 7.89400998 35.66686882988151 139.74807713413222 5.3993563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p48_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p48_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p48_2">
											<gml:posList>35.66693309619804 139.74797486232072 22.43600521 35.66692077387762 139.74801273577108 22.43575248 35.66692083274161 139.74801275072377 5.40109992 35.666933155095045 139.7479748771724 5.40135264 35.66693309619804 139.74797486232072 22.43600521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p54_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p54_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p54_2">
											<gml:posList>35.66678918730079 139.74800314653282 14.19010202 35.666789187541234 139.74800314659421 14.12010203 35.666773913976755 139.74799568392848 14.11940284 35.6667739137364 139.7479956838672 14.18940283 35.66678918730079 139.74800314653282 14.19010202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p54_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p54_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p54_4">
											<gml:posList>35.6667664380455 139.74801865964673 14.18925217 35.66676644485653 139.74801866139092 12.20425232 35.66678171875297 139.74802612423957 12.20495152 35.666781711937176 139.748026122493 14.18995137 35.6667664380455 139.74801865964673 14.18925217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p49_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p49_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p49_1">
											<gml:posList>35.666820893597446 139.74794730142395 14.67604457 35.66678627468855 139.7479303871618 14.67445964 35.666786276594564 139.7479303876418 14.11945968 35.666819328006305 139.74794653604872 14.12097278 35.666819358015424 139.74794654361656 5.39631958 35.66682092551791 139.74794730947426 5.3963914 35.666820893597446 139.74794730142395 14.67604457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p55_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p55_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p55_1">
											<gml:posList>35.66686028612412 139.74804780605825 7.89343493 35.666881539217044 139.74798249615552 7.89386682 35.666881547822015 139.7479824983334 5.39921314 35.666860294720735 139.74804780826167 5.39878125 35.66686028612412 139.74804780605825 7.89343493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p50_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p50_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p50_1">
											<gml:posList>35.666819358015424 139.74794654361656 5.39631958 35.666819328006305 139.74794653604872 14.12097278 35.66679594877402 139.74801839355268 14.12049764 35.666795955353706 139.74801839523525 12.20549779 35.666796523217776 139.74801664987228 12.20550924 35.666796546615736 139.74801665585386 5.39585588 35.666819358015424 139.74794654361656 5.39631958</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p54_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p54_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p54_3">
											<gml:posList>35.66678584121615 139.74801345361402 12.2050345 35.66678583463943 139.7480134519329 14.12003436 35.666789187541234 139.74800314659421 14.12010203 35.66678918730079 139.74800314653282 14.19010202 35.666781711937176 139.748026122493 14.18995137 35.66678171875297 139.74802612423957 12.20495152 35.66678584121615 139.74801345361402 12.2050345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p47_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p47_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p47_2">
											<gml:posList>35.666933155095045 139.7479748771724 5.40135264 35.666782547091735 139.74790129238926 5.39444174 35.666782523708825 139.74790128653075 12.20409509 35.66679393752397 139.74790686313693 12.20461705 35.6667939290381 139.74790686100985 14.67461687 35.66682854774504 139.74792377516306 14.67620179 35.66682854500942 139.7479237744764 15.47120173 35.66690522622099 139.74796123976125 15.47472194 35.66690520218742 139.747961233708 22.43472141 35.66693309619804 139.74797486232072 22.43600521 35.666933155095045 139.7479748771724 5.40135264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0004_p54_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0004_p54_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0004_p54_1">
											<gml:posList>35.6667664380455 139.74801865964673 14.18925217 35.6667739137364 139.7479956838672 14.18940283 35.666773913976755 139.74799568392848 14.11940284 35.666770560862126 139.7480059893889 14.11933516 35.66677056743424 139.74800599106783 12.20433531 35.66676644485653 139.74801866139092 12.20425232 35.6667664380455 139.74801865964673 14.18925217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">9</uro:districtsAndZonesType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.12</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7000100000</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>