<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_79563076-0fbe-4631-8711-993db64f0269">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">8.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66872818256932 139.7395889485563 0 35.6686543565687 139.7397002683065 0 35.66868223062072 139.73972807174076 0 35.66875614678389 139.739616751872 0 35.66872818256932 139.7395889485563 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872818256932 139.7395889485563 11.322 35.66875614678389 139.739616751872 11.322 35.66868223062072 139.73972807174076 11.322 35.6686543565687 139.7397002683065 11.322 35.66872818256932 139.7395889485563 11.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872818256932 139.7395889485563 11.322 35.6686543565687 139.7397002683065 11.322 35.6686543565687 139.7397002683065 20.04 35.66872818256932 139.7395889485563 20.04 35.66872818256932 139.7395889485563 11.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686543565687 139.7397002683065 11.322 35.66868223062072 139.73972807174076 11.322 35.66868223062072 139.73972807174076 20.04 35.6686543565687 139.7397002683065 20.04 35.6686543565687 139.7397002683065 11.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868223062072 139.73972807174076 11.322 35.66875614678389 139.739616751872 11.322 35.66875614678389 139.739616751872 20.04 35.66868223062072 139.73972807174076 20.04 35.66868223062072 139.73972807174076 11.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66875614678389 139.739616751872 11.322 35.66872818256932 139.7395889485563 11.322 35.66872818256932 139.7395889485563 20.04 35.66875614678389 139.739616751872 20.04 35.66875614678389 139.739616751872 11.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872818256932 139.7395889485563 20.04 35.6686543565687 139.7397002683065 20.04 35.66868223062072 139.73972807174076 20.04 35.66875614678389 139.739616751872 20.04 35.66872818256932 139.7395889485563 20.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-84877d21-b269-4c84-9d58-fe023a68c8aa"/>
							<gml:surfaceMember xlink:href="#poly-ef949d7a-5cdf-46ba-845c-2acf3f33fcf7"/>
							<gml:surfaceMember xlink:href="#poly-376832a1-5d7c-485b-bad6-e55a23551245"/>
							<gml:surfaceMember xlink:href="#poly-12e3e65d-764f-4339-8f3a-00af343a1003"/>
							<gml:surfaceMember xlink:href="#poly-4c5c84ef-f259-4828-a85c-9deeea10b706"/>
							<gml:surfaceMember xlink:href="#poly-0fcb2cf8-7061-4ac8-80e6-50ab3e891c80"/>
							<gml:surfaceMember xlink:href="#poly-7c7d35bd-af00-4943-8125-d791c8c7035a"/>
							<gml:surfaceMember xlink:href="#poly-614b45f8-7257-47eb-9512-db6e163316b0"/>
							<gml:surfaceMember xlink:href="#poly-536585c8-4bd0-459a-9ad5-a5e53ae28a3c"/>
							<gml:surfaceMember xlink:href="#poly-a086ddef-45e1-43a1-a231-5f07edaae0f7"/>
							<gml:surfaceMember xlink:href="#poly-e3d2fda8-0e69-4db7-a225-d51bec8bd099"/>
							<gml:surfaceMember xlink:href="#poly-23ebe276-484d-4a31-86c7-b1f3b73c5a77"/>
							<gml:surfaceMember xlink:href="#poly-2d97d995-4d16-424e-bf30-8fdf68f3e733"/>
							<gml:surfaceMember xlink:href="#poly-67d70ae3-e317-40cd-989a-1e11c0f69108"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_79563076-0fbe-4631-8711-993db64f0269_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab132310-2bc6-49e9-9035-813e369a8ea0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66870722752804 139.73967245894195 20.033 35.66870156250103 139.73966679894679 20.033 35.66872604215841 139.73962993183548 20.033 35.66873170717853 139.73963558078373 20.033 35.66873751662425 139.73964149466875 20.033 35.668713036971965 139.73967837282785 20.033 35.66870722752804 139.73967245894195 20.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e6dc786-45ea-40d6-b7ba-c737238c9d46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668713036971965 139.73967837282785 20.777 35.66873751662425 139.73964149466875 20.777 35.66873798570751 139.73964196910006 20.777 35.66871349703277 139.73967883622373 20.777 35.668713036971965 139.73967837282785 20.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3068ae8-271d-4a30-b84a-477a6fd2d6c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3068ae8-271d-4a30-b84a-477a6fd2d6c9_0">
											<gml:posList>35.66870722752804 139.73967245894195 20.033 35.66870722752804 139.73967245894195 22.644 35.66870156250103 139.73966679894679 22.644 35.66870156250103 139.73966679894679 20.033 35.66870722752804 139.73967245894195 20.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e184a2e-76c0-4df7-aa8d-1fb1df61ecdd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e184a2e-76c0-4df7-aa8d-1fb1df61ecdd_0">
											<gml:posList>35.66870722752804 139.73967245894195 23.049 35.66870722752804 139.73967245894195 22.644 35.66870722752804 139.73967245894195 20.033 35.668713036971965 139.73967837282785 20.033 35.668713036971965 139.73967837282785 20.777 35.66871349703277 139.73967883622373 20.777 35.6687135150774 139.73967885829472 23.049 35.66870722752804 139.73967245894195 23.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23b1bcbe-ad09-4480-83b9-8d9ff9b961a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23b1bcbe-ad09-4480-83b9-8d9ff9b961a5_0">
											<gml:posList>35.66870156250103 139.73966679894679 22.644 35.66872604215841 139.73962993183548 22.644 35.66872604215841 139.73962993183548 20.033 35.66870156250103 139.73966679894679 20.033 35.66870156250103 139.73966679894679 22.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b441668f-9de4-4f82-b16c-80b29b82191b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b441668f-9de4-4f82-b16c-80b29b82191b_0">
											<gml:posList>35.66873170717853 139.73963558078373 22.644 35.66872604215841 139.73962993183548 22.644 35.66870156250103 139.73966679894679 22.644 35.66870722752804 139.73967245894195 22.644 35.66873170717853 139.73963558078373 22.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-969f2499-3af8-45fd-9a15-19ce7c377a36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-969f2499-3af8-45fd-9a15-19ce7c377a36_0">
											<gml:posList>35.66870722752804 139.73967245894195 23.049 35.66873170717853 139.73963558078373 23.049 35.66873170717853 139.73963558078373 22.644 35.66870722752804 139.73967245894195 22.644 35.66870722752804 139.73967245894195 23.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73c0f4bb-c887-4a76-a84e-b5813e058e57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73c0f4bb-c887-4a76-a84e-b5813e058e57_0">
											<gml:posList>35.66873799472983 139.73964198013556 23.049 35.66873170717853 139.73963558078373 23.049 35.66870722752804 139.73967245894195 23.049 35.6687135150774 139.73967885829472 23.049 35.66873799472983 139.73964198013556 23.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04206100-18a2-43a0-b501-8c34f73ce14c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04206100-18a2-43a0-b501-8c34f73ce14c_0">
											<gml:posList>35.66873751662425 139.73964149466875 20.777 35.668713036971965 139.73967837282785 20.777 35.668713036971965 139.73967837282785 20.033 35.66873751662425 139.73964149466875 20.033 35.66873751662425 139.73964149466875 20.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7337b472-5adb-423e-9e9d-4e8130487242">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7337b472-5adb-423e-9e9d-4e8130487242_0">
											<gml:posList>35.66871349703277 139.73967883622373 20.777 35.66873798570751 139.73964196910006 20.777 35.66873799472983 139.73964198013556 23.049 35.6687135150774 139.73967885829472 23.049 35.66871349703277 139.73967883622373 20.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dd46acb-41c3-4a80-a1aa-c4c8a31f47ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dd46acb-41c3-4a80-a1aa-c4c8a31f47ad_0">
											<gml:posList>35.66872604215841 139.73962993183548 22.644 35.66873170717853 139.73963558078373 22.644 35.66873170717853 139.73963558078373 20.033 35.66872604215841 139.73962993183548 20.033 35.66872604215841 139.73962993183548 22.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a49d2e2-5b97-43b2-b90d-dbe58c10ab7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a49d2e2-5b97-43b2-b90d-dbe58c10ab7d_0">
											<gml:posList>35.66873798570751 139.73964196910006 20.777 35.66873751662425 139.73964149466875 20.777 35.66873751662425 139.73964149466875 20.033 35.66873170717853 139.73963558078373 20.033 35.66873170717853 139.73963558078373 22.644 35.66873170717853 139.73963558078373 23.049 35.66873799472983 139.73964198013556 23.049 35.66873798570751 139.73964196910006 20.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-84877d21-b269-4c84-9d58-fe023a68c8aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84877d21-b269-4c84-9d58-fe023a68c8aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84877d21-b269-4c84-9d58-fe023a68c8aa">
											<gml:posList>35.66872818256928 139.73958894855633 11.322 35.66875614678389 139.739616751872 11.322 35.66868223062073 139.73972807174076 11.322 35.668654356568716 139.7397002683065 11.322 35.66872818256928 139.73958894855633 11.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef949d7a-5cdf-46ba-845c-2acf3f33fcf7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef949d7a-5cdf-46ba-845c-2acf3f33fcf7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef949d7a-5cdf-46ba-845c-2acf3f33fcf7">
											<gml:posList>35.66872818256928 139.73958894855633 20.777 35.66872842822726 139.73959188651355 20.777 35.66875374036004 139.7396170639736 20.777 35.66875614678389 139.739616751872 20.777 35.66872818256928 139.73958894855633 20.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-376832a1-5d7c-485b-bad6-e55a23551245">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-376832a1-5d7c-485b-bad6-e55a23551245">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-376832a1-5d7c-485b-bad6-e55a23551245">
											<gml:posList>35.668654356568716 139.7397002683065 20.777 35.66865676298422 139.73969994516176 20.777 35.66872842822726 139.73959188651355 20.777 35.66872818256928 139.73958894855633 20.777 35.668654356568716 139.7397002683065 20.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-12e3e65d-764f-4339-8f3a-00af343a1003">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12e3e65d-764f-4339-8f3a-00af343a1003">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12e3e65d-764f-4339-8f3a-00af343a1003">
											<gml:posList>35.66875374036004 139.7396170639736 20.033 35.66872842822726 139.73959188651355 20.033 35.66865676298422 139.73969994516176 20.033 35.668681993971205 139.73972512272823 20.033 35.66875374036004 139.7396170639736 20.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c5c84ef-f259-4828-a85c-9deeea10b706">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c5c84ef-f259-4828-a85c-9deeea10b706">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c5c84ef-f259-4828-a85c-9deeea10b706">
											<gml:posList>35.66875614678389 139.739616751872 20.777 35.66875374036004 139.7396170639736 20.777 35.668681993971205 139.73972512272823 20.777 35.66868223062073 139.73972807174076 20.777 35.66875614678389 139.739616751872 20.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0fcb2cf8-7061-4ac8-80e6-50ab3e891c80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fcb2cf8-7061-4ac8-80e6-50ab3e891c80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fcb2cf8-7061-4ac8-80e6-50ab3e891c80">
											<gml:posList>35.66868223062073 139.73972807174076 20.777 35.668681993971205 139.73972512272823 20.777 35.66865676298422 139.73969994516176 20.777 35.668654356568716 139.7397002683065 20.777 35.66868223062073 139.73972807174076 20.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c7d35bd-af00-4943-8125-d791c8c7035a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c7d35bd-af00-4943-8125-d791c8c7035a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c7d35bd-af00-4943-8125-d791c8c7035a">
											<gml:posList>35.66865676298422 139.73969994516176 20.777 35.66865676298422 139.73969994516176 20.033 35.66872842822726 139.73959188651355 20.033 35.66872842822726 139.73959188651355 20.777 35.66865676298422 139.73969994516176 20.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-614b45f8-7257-47eb-9512-db6e163316b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-614b45f8-7257-47eb-9512-db6e163316b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-614b45f8-7257-47eb-9512-db6e163316b0">
											<gml:posList>35.66875374036004 139.7396170639736 20.777 35.66875374036004 139.7396170639736 20.033 35.668681993971205 139.73972512272823 20.033 35.668681993971205 139.73972512272823 20.777 35.66875374036004 139.7396170639736 20.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-536585c8-4bd0-459a-9ad5-a5e53ae28a3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-536585c8-4bd0-459a-9ad5-a5e53ae28a3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-536585c8-4bd0-459a-9ad5-a5e53ae28a3c">
											<gml:posList>35.66875614678389 139.739616751872 11.322 35.66872818256928 139.73958894855633 11.322 35.66872818256928 139.73958894855633 20.777 35.66875614678389 139.739616751872 20.777 35.66875614678389 139.739616751872 11.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a086ddef-45e1-43a1-a231-5f07edaae0f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a086ddef-45e1-43a1-a231-5f07edaae0f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a086ddef-45e1-43a1-a231-5f07edaae0f7">
											<gml:posList>35.66872842822726 139.73959188651355 20.777 35.66872842822726 139.73959188651355 20.033 35.66875374036004 139.7396170639736 20.033 35.66875374036004 139.7396170639736 20.777 35.66872842822726 139.73959188651355 20.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3d2fda8-0e69-4db7-a225-d51bec8bd099">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3d2fda8-0e69-4db7-a225-d51bec8bd099">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3d2fda8-0e69-4db7-a225-d51bec8bd099">
											<gml:posList>35.66872818256928 139.73958894855633 11.322 35.668654356568716 139.7397002683065 11.322 35.668654356568716 139.7397002683065 20.777 35.66872818256928 139.73958894855633 20.777 35.66872818256928 139.73958894855633 11.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23ebe276-484d-4a31-86c7-b1f3b73c5a77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23ebe276-484d-4a31-86c7-b1f3b73c5a77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23ebe276-484d-4a31-86c7-b1f3b73c5a77">
											<gml:posList>35.66875614678389 139.739616751872 20.777 35.66868223062073 139.73972807174076 20.777 35.66868223062073 139.73972807174076 11.322 35.66875614678389 139.739616751872 11.322 35.66875614678389 139.739616751872 20.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d97d995-4d16-424e-bf30-8fdf68f3e733">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d97d995-4d16-424e-bf30-8fdf68f3e733">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d97d995-4d16-424e-bf30-8fdf68f3e733">
											<gml:posList>35.668681993971205 139.73972512272823 20.777 35.668681993971205 139.73972512272823 20.033 35.66865676298422 139.73969994516176 20.033 35.66865676298422 139.73969994516176 20.777 35.668681993971205 139.73972512272823 20.777</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67d70ae3-e317-40cd-989a-1e11c0f69108">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67d70ae3-e317-40cd-989a-1e11c0f69108">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67d70ae3-e317-40cd-989a-1e11c0f69108">
											<gml:posList>35.668654356568716 139.7397002683065 11.322 35.66868223062073 139.73972807174076 11.322 35.66868223062073 139.73972807174076 20.777 35.668654356568716 139.7397002683065 20.777 35.668654356568716 139.7397002683065 11.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10743</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">51.84325</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>