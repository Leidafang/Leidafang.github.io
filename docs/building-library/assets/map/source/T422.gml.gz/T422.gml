<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_7c00db9e-9ae7-470a-8ff1-72fb4f5958c3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">95.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>21</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>2</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6678835003664 139.7394665532115 0 35.66820172600396 139.73975061413492 0 35.668347197501205 139.73950588637325 0 35.66802897129477 139.73922182590834 0 35.6678835003664 139.7394665532115 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6678835003664 139.7394665532115 11.14 35.66802897129477 139.73922182590834 11.14 35.668347197501205 139.73950588637325 11.14 35.66820172600396 139.73975061413492 11.14 35.6678835003664 139.7394665532115 11.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6678835003664 139.7394665532115 11.14 35.66820172600396 139.73975061413492 11.14 35.66820172600396 139.73975061413492 105.3 35.6678835003664 139.7394665532115 105.3 35.6678835003664 139.7394665532115 11.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66820172600396 139.73975061413492 11.14 35.668347197501205 139.73950588637325 11.14 35.668347197501205 139.73950588637325 105.3 35.66820172600396 139.73975061413492 105.3 35.66820172600396 139.73975061413492 11.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668347197501205 139.73950588637325 11.14 35.66802897129477 139.73922182590834 11.14 35.66802897129477 139.73922182590834 105.3 35.668347197501205 139.73950588637325 105.3 35.668347197501205 139.73950588637325 11.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66802897129477 139.73922182590834 11.14 35.6678835003664 139.7394665532115 11.14 35.6678835003664 139.7394665532115 105.3 35.66802897129477 139.73922182590834 105.3 35.66802897129477 139.73922182590834 11.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6678835003664 139.7394665532115 105.3 35.66820172600396 139.73975061413492 105.3 35.668347197501205 139.73950588637325 105.3 35.66802897129477 139.73922182590834 105.3 35.6678835003664 139.7394665532115 105.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f467a794-1b58-4931-acbe-31d27b216b0b"/>
							<gml:surfaceMember xlink:href="#poly-7f15b9d4-ab8a-4c09-b2c0-f52168ac315f"/>
							<gml:surfaceMember xlink:href="#poly-6ada26d7-0bec-48bb-b673-38d626f8476c"/>
							<gml:surfaceMember xlink:href="#poly-22524797-ee69-48e2-94f3-fcc9c14d9d64"/>
							<gml:surfaceMember xlink:href="#poly-0406713c-3259-49fa-bdd5-1a6b7f9b78f4"/>
							<gml:surfaceMember xlink:href="#poly-0f6d5a5e-cf6e-45a7-9bb4-2dfb75857440"/>
							<gml:surfaceMember xlink:href="#poly-bd22c325-b2af-470b-8816-93a124498a20"/>
							<gml:surfaceMember xlink:href="#poly-54a22cab-87c9-433a-adf2-e2f062ee43ec"/>
							<gml:surfaceMember xlink:href="#poly-fbd4781c-9479-40d9-ab1a-40e998ae2d23"/>
							<gml:surfaceMember xlink:href="#poly-bac8dfb2-7bd3-409f-949f-b3c640f0607f"/>
							<gml:surfaceMember xlink:href="#poly-f253a6d4-6cd4-4978-b9f9-c7927271d769"/>
							<gml:surfaceMember xlink:href="#poly-c4047315-acc0-4eb6-af6b-5a8bfa0069cc"/>
							<gml:surfaceMember xlink:href="#poly-a77c243d-2339-4dea-b250-3ab9bdc94afb"/>
							<gml:surfaceMember xlink:href="#poly-f767a40a-d3cb-473b-b947-19899a7d0e5f"/>
							<gml:surfaceMember xlink:href="#poly-681d8fe6-92d6-414a-a1bd-d677d8c09e62"/>
							<gml:surfaceMember xlink:href="#poly-ee307266-dc60-4b00-8dce-35abc0ec36ce"/>
							<gml:surfaceMember xlink:href="#poly-9b79e5d3-9550-40bd-9482-416bb8c605d4"/>
							<gml:surfaceMember xlink:href="#poly-7fc23087-ad9b-4f0e-963a-cafebd43cfe1"/>
							<gml:surfaceMember xlink:href="#poly-78315eb5-51c8-40d3-947f-4ade13b5a3aa"/>
							<gml:surfaceMember xlink:href="#poly-0a86c1ea-366a-4cb7-a86d-1684dc5e7e51"/>
							<gml:surfaceMember xlink:href="#poly-e47e0d19-f5f4-4612-8e11-1829fb80cfc0"/>
							<gml:surfaceMember xlink:href="#poly-406812af-7414-489f-9f49-d48dd48b25fd"/>
							<gml:surfaceMember xlink:href="#poly-0bf11bb2-7018-4fd5-9fe3-8ce9bb3a1bfb"/>
							<gml:surfaceMember xlink:href="#poly-ba53ba6c-adf6-4340-a5c7-1163834dbef9"/>
							<gml:surfaceMember xlink:href="#poly-e5c49a3f-0a31-43f2-8027-a25dbe52bc07"/>
							<gml:surfaceMember xlink:href="#poly-42c0f998-33eb-440f-8544-5e6523c7b7dd"/>
							<gml:surfaceMember xlink:href="#poly-dfe7e853-fc89-4e8b-8316-d126fb0a929c"/>
							<gml:surfaceMember xlink:href="#poly-4c44d1be-f140-4791-9b58-e331b836c664"/>
							<gml:surfaceMember xlink:href="#poly-c4b7a5ce-e4d2-4a98-b737-603879204b1b"/>
							<gml:surfaceMember xlink:href="#poly-801512eb-ff28-48ed-bc21-1816da886a2e"/>
							<gml:surfaceMember xlink:href="#poly-79403ab8-1661-42c6-a0e3-0fddec4082cd"/>
							<gml:surfaceMember xlink:href="#poly-949fda44-6f73-4225-b782-9534bfe80e18"/>
							<gml:surfaceMember xlink:href="#poly-a7f9b5ff-087b-4066-9199-767ca4557f6d"/>
							<gml:surfaceMember xlink:href="#poly-7a83a99b-1436-43f1-b414-279727a26b7e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_7c00db9e-9ae7-470a-8ff1-72fb4f5958c3_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cd910ea-8516-4055-ad91-4dc6a3d01bb6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668051058650214 139.73929579672634 105.172 35.66802505212183 139.73933953599018 105.172 35.66825409729042 139.73954399343955 105.172 35.66827910465957 139.73950191218154 105.172 35.66828660930371 139.73950860830394 105.172 35.66825735301957 139.73955784127386 105.172 35.66801859331538 139.73934471305844 105.172 35.66804883972954 139.73929382210568 105.172 35.668051058650214 139.73929579672634 105.172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ef26cf6-c748-44a4-a235-d4b52ebcaeaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ef26cf6-c748-44a4-a235-d4b52ebcaeaf_0">
											<gml:posList>35.66801859331538 139.73934471305844 105.172 35.66801859331538 139.73934471305844 108.654 35.66804883972954 139.73929382210568 108.654 35.66804883972954 139.73929382210568 105.172 35.66801859331538 139.73934471305844 105.172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09e5de45-4b55-474b-83ec-6c58a8e88b8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09e5de45-4b55-474b-83ec-6c58a8e88b8c_0">
											<gml:posList>35.668051058650214 139.73929579672634 105.172 35.668051058650214 139.73929579672634 108.654 35.66802505212183 139.73933953599018 108.654 35.66802505212183 139.73933953599018 105.172 35.668051058650214 139.73929579672634 105.172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f412ef4c-792d-4bac-86b4-5ebc82747e8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f412ef4c-792d-4bac-86b4-5ebc82747e8e_0">
											<gml:posList>35.66804883972954 139.73929382210568 105.172 35.66804883972954 139.73929382210568 108.654 35.668051058650214 139.73929579672634 108.654 35.668051058650214 139.73929579672634 105.172 35.66804883972954 139.73929382210568 105.172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f80508b1-4f6c-4fb0-badf-8af44717e136">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f80508b1-4f6c-4fb0-badf-8af44717e136_0">
											<gml:posList>35.66825735301957 139.73955784127386 105.172 35.66825735301957 139.73955784127386 108.654 35.66801859331538 139.73934471305844 108.654 35.66801859331538 139.73934471305844 105.172 35.66825735301957 139.73955784127386 105.172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc6a4b91-d405-47f9-9e53-56d29a1a39a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc6a4b91-d405-47f9-9e53-56d29a1a39a2_0">
											<gml:posList>35.66802505212183 139.73933953599018 105.172 35.66802505212183 139.73933953599018 108.654 35.66825409729042 139.73954399343955 108.654 35.66825409729042 139.73954399343955 105.172 35.66802505212183 139.73933953599018 105.172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc4684e1-ea95-436e-af8e-65a4af1e6cb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc4684e1-ea95-436e-af8e-65a4af1e6cb9_0">
											<gml:posList>35.66801859331538 139.73934471305844 108.654 35.66825735301957 139.73955784127386 108.654 35.66828660930371 139.73950860830394 108.654 35.66827910465957 139.73950191218154 108.654 35.66825409729042 139.73954399343955 108.654 35.66802505212183 139.73933953599018 108.654 35.668051058650214 139.73929579672634 108.654 35.66804883972954 139.73929382210568 108.654 35.66801859331538 139.73934471305844 108.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ff7bff2-0cd1-4116-8f2e-32b55b116141">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ff7bff2-0cd1-4116-8f2e-32b55b116141_0">
											<gml:posList>35.66825409729042 139.73954399343955 105.172 35.66825409729042 139.73954399343955 108.654 35.66827910465957 139.73950191218154 108.654 35.66827910465957 139.73950191218154 105.172 35.66825409729042 139.73954399343955 105.172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4304ce26-f195-4157-a5b7-f457f8987498">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4304ce26-f195-4157-a5b7-f457f8987498_0">
											<gml:posList>35.66828660930371 139.73950860830394 105.172 35.66828660930371 139.73950860830394 108.654 35.66825735301957 139.73955784127386 108.654 35.66825735301957 139.73955784127386 105.172 35.66828660930371 139.73950860830394 105.172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a76107b0-d21c-4573-95b2-1805255439b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a76107b0-d21c-4573-95b2-1805255439b4_0">
											<gml:posList>35.66827910465957 139.73950191218154 108.654 35.66828660930371 139.73950860830394 108.654 35.66828660930371 139.73950860830394 105.172 35.66827910465957 139.73950191218154 105.172 35.66827910465957 139.73950191218154 108.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f467a794-1b58-4931-acbe-31d27b216b0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f467a794-1b58-4931-acbe-31d27b216b0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f467a794-1b58-4931-acbe-31d27b216b0b">
											<gml:posList>35.66788350036639 139.73946655321149 11.14 35.668028971294746 139.73922182590834 11.14 35.6683471975012 139.73950588637325 11.14 35.668201726003936 139.73975061413495 11.14 35.66788350036639 139.73946655321149 11.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f15b9d4-ab8a-4c09-b2c0-f52168ac315f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f15b9d4-ab8a-4c09-b2c0-f52168ac315f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f15b9d4-ab8a-4c09-b2c0-f52168ac315f">
											<gml:posList>35.66788350036639 139.73946655321149 111.881 35.667889079027674 139.7394654752271 111.881 35.66802985097839 139.7392286733559 111.881 35.668028971294746 139.73922182590834 111.881 35.66788350036639 139.73946655321149 111.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ada26d7-0bec-48bb-b673-38d626f8476c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ada26d7-0bec-48bb-b673-38d626f8476c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ada26d7-0bec-48bb-b673-38d626f8476c">
											<gml:posList>35.668201726003936 139.73975061413495 111.881 35.66820083734483 139.7397437777234 111.881 35.667889079027674 139.7394654752271 111.881 35.66788350036639 139.73946655321149 111.881 35.668201726003936 139.73975061413495 111.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22524797-ee69-48e2-94f3-fcc9c14d9d64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22524797-ee69-48e2-94f3-fcc9c14d9d64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22524797-ee69-48e2-94f3-fcc9c14d9d64">
											<gml:posList>35.66802505212183 139.73933953599018 118.165 35.66802942313224 139.73933870242124 118.165 35.66807282134147 139.73926570415117 118.165 35.668072123099414 139.73926034768877 118.165 35.66802505212183 139.73933953599018 118.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0406713c-3259-49fa-bdd5-1a6b7f9b78f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0406713c-3259-49fa-bdd5-1a6b7f9b78f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0406713c-3259-49fa-bdd5-1a6b7f9b78f4">
											<gml:posList>35.66802985097839 139.7392286733559 111.881 35.66806977360624 139.7392643048921 111.881 35.668072123099414 139.73926034768877 111.881 35.668028971294746 139.73922182590834 111.881 35.66802985097839 139.7392286733559 111.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0f6d5a5e-cf6e-45a7-9bb4-2dfb75857440">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f6d5a5e-cf6e-45a7-9bb4-2dfb75857440">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f6d5a5e-cf6e-45a7-9bb4-2dfb75857440">
											<gml:posList>35.668341618839975 139.73950696436106 110.13 35.66829881889211 139.73946875119404 110.13 35.66827910465957 139.73950191218154 110.13 35.66830039188085 139.7395209194823 110.13 35.6682004522974 139.73968907858347 110.13 35.667933252756924 139.73945059988776 110.13 35.66803420022947 139.73928074984045 110.13 35.668051058650214 139.73929579672634 110.13 35.66806977360624 139.7392643048921 110.13 35.66802985097839 139.7392286733559 110.13 35.667889079027674 139.7394654752271 110.13 35.66820083734483 139.7397437777234 110.13 35.668341618839975 139.73950696436106 110.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd22c325-b2af-470b-8816-93a124498a20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd22c325-b2af-470b-8816-93a124498a20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd22c325-b2af-470b-8816-93a124498a20">
											<gml:posList>35.66802505212183 139.73933953599018 105.172 35.668051058650214 139.73929579672634 105.172 35.66803420022947 139.73928074984045 105.172 35.667933252756924 139.73945059988776 105.172 35.6682004522974 139.73968907858347 105.172 35.66830039188085 139.7395209194823 105.172 35.66827910465957 139.73950191218154 105.172 35.66825409729042 139.73954399343955 105.172 35.66802505212183 139.73933953599018 105.172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54a22cab-87c9-433a-adf2-e2f062ee43ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54a22cab-87c9-433a-adf2-e2f062ee43ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54a22cab-87c9-433a-adf2-e2f062ee43ec">
											<gml:posList>35.66825409729042 139.73954399343955 118.165 35.66825339906937 139.7395386480085 118.165 35.66802942313224 139.73933870242124 118.165 35.66802505212183 139.73933953599018 118.165 35.66825409729042 139.73954399343955 118.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fbd4781c-9479-40d9-ab1a-40e998ae2d23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbd4781c-9479-40d9-ab1a-40e998ae2d23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbd4781c-9479-40d9-ab1a-40e998ae2d23">
											<gml:posList>35.66829679738943 139.73946563859624 117.435 35.66807282134147 139.73926570415117 117.435 35.66802942313224 139.73933870242124 117.435 35.66825339906937 139.7395386480085 117.435 35.66829679738943 139.73946563859624 117.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bac8dfb2-7bd3-409f-949f-b3c640f0607f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bac8dfb2-7bd3-409f-949f-b3c640f0607f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bac8dfb2-7bd3-409f-949f-b3c640f0607f">
											<gml:posList>35.668072123099414 139.73926034768877 118.165 35.66807282134147 139.73926570415117 118.165 35.66829679738943 139.73946563859624 118.165 35.66830116839192 139.73946479398538 118.165 35.668072123099414 139.73926034768877 118.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f253a6d4-6cd4-4978-b9f9-c7927271d769">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f253a6d4-6cd4-4978-b9f9-c7927271d769">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f253a6d4-6cd4-4978-b9f9-c7927271d769">
											<gml:posList>35.6683471975012 139.73950588637325 111.881 35.668341618839975 139.73950696436106 111.881 35.66820083734483 139.7397437777234 111.881 35.668201726003936 139.73975061413495 111.881 35.6683471975012 139.73950588637325 111.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c4047315-acc0-4eb6-af6b-5a8bfa0069cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4047315-acc0-4eb6-af6b-5a8bfa0069cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4047315-acc0-4eb6-af6b-5a8bfa0069cc">
											<gml:posList>35.66830116839192 139.73946479398538 118.165 35.66829679738943 139.73946563859624 118.165 35.66825339906937 139.7395386480085 118.165 35.66825409729042 139.73954399343955 118.165 35.66830116839192 139.73946479398538 118.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a77c243d-2339-4dea-b250-3ab9bdc94afb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a77c243d-2339-4dea-b250-3ab9bdc94afb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a77c243d-2339-4dea-b250-3ab9bdc94afb">
											<gml:posList>35.668341618839975 139.73950696436106 111.881 35.6683471975012 139.73950588637325 111.881 35.66830116839192 139.73946479398538 111.881 35.66829881889211 139.73946875119404 111.881 35.668341618839975 139.73950696436106 111.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f767a40a-d3cb-473b-b947-19899a7d0e5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f767a40a-d3cb-473b-b947-19899a7d0e5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f767a40a-d3cb-473b-b947-19899a7d0e5f">
											<gml:posList>35.66807282134147 139.73926570415117 118.165 35.66807282134147 139.73926570415117 117.435 35.66829679738943 139.73946563859624 117.435 35.66829679738943 139.73946563859624 118.165 35.66807282134147 139.73926570415117 118.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-681d8fe6-92d6-414a-a1bd-d677d8c09e62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-681d8fe6-92d6-414a-a1bd-d677d8c09e62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-681d8fe6-92d6-414a-a1bd-d677d8c09e62">
											<gml:posList>35.66825339906937 139.7395386480085 118.165 35.66825339906937 139.7395386480085 117.435 35.66802942313224 139.73933870242124 117.435 35.66802942313224 139.73933870242124 118.165 35.66825339906937 139.7395386480085 118.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee307266-dc60-4b00-8dce-35abc0ec36ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee307266-dc60-4b00-8dce-35abc0ec36ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee307266-dc60-4b00-8dce-35abc0ec36ce">
											<gml:posList>35.6682004522974 139.73968907858347 110.13 35.6682004522974 139.73968907858347 105.172 35.667933252756924 139.73945059988776 105.172 35.667933252756924 139.73945059988776 110.13 35.6682004522974 139.73968907858347 110.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b79e5d3-9550-40bd-9482-416bb8c605d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b79e5d3-9550-40bd-9482-416bb8c605d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b79e5d3-9550-40bd-9482-416bb8c605d4">
											<gml:posList>35.66820083734483 139.7397437777234 111.881 35.66820083734483 139.7397437777234 110.13 35.667889079027674 139.7394654752271 110.13 35.667889079027674 139.7394654752271 111.881 35.66820083734483 139.7397437777234 111.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7fc23087-ad9b-4f0e-963a-cafebd43cfe1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fc23087-ad9b-4f0e-963a-cafebd43cfe1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fc23087-ad9b-4f0e-963a-cafebd43cfe1">
											<gml:posList>35.668028971294746 139.73922182590834 11.14 35.66788350036639 139.73946655321149 11.14 35.66788350036639 139.73946655321149 111.881 35.668028971294746 139.73922182590834 111.881 35.668028971294746 139.73922182590834 11.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78315eb5-51c8-40d3-947f-4ade13b5a3aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78315eb5-51c8-40d3-947f-4ade13b5a3aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78315eb5-51c8-40d3-947f-4ade13b5a3aa">
											<gml:posList>35.667889079027674 139.7394654752271 111.881 35.667889079027674 139.7394654752271 110.13 35.66802985097839 139.7392286733559 110.13 35.66802985097839 139.7392286733559 111.881 35.667889079027674 139.7394654752271 111.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a86c1ea-366a-4cb7-a86d-1684dc5e7e51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a86c1ea-366a-4cb7-a86d-1684dc5e7e51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a86c1ea-366a-4cb7-a86d-1684dc5e7e51">
											<gml:posList>35.667933252756924 139.73945059988776 110.13 35.667933252756924 139.73945059988776 105.172 35.66803420022947 139.73928074984045 105.172 35.66803420022947 139.73928074984045 110.13 35.667933252756924 139.73945059988776 110.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e47e0d19-f5f4-4612-8e11-1829fb80cfc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e47e0d19-f5f4-4612-8e11-1829fb80cfc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e47e0d19-f5f4-4612-8e11-1829fb80cfc0">
											<gml:posList>35.66788350036639 139.73946655321149 11.14 35.668201726003936 139.73975061413495 11.14 35.668201726003936 139.73975061413495 111.881 35.66788350036639 139.73946655321149 111.881 35.66788350036639 139.73946655321149 11.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-406812af-7414-489f-9f49-d48dd48b25fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-406812af-7414-489f-9f49-d48dd48b25fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-406812af-7414-489f-9f49-d48dd48b25fd">
											<gml:posList>35.66803420022947 139.73928074984045 110.13 35.66803420022947 139.73928074984045 105.172 35.668051058650214 139.73929579672634 105.172 35.668051058650214 139.73929579672634 110.13 35.66803420022947 139.73928074984045 110.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bf11bb2-7018-4fd5-9fe3-8ce9bb3a1bfb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bf11bb2-7018-4fd5-9fe3-8ce9bb3a1bfb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bf11bb2-7018-4fd5-9fe3-8ce9bb3a1bfb">
											<gml:posList>35.66806977360624 139.7392643048921 111.881 35.66806977360624 139.7392643048921 110.13 35.668051058650214 139.73929579672634 110.13 35.668051058650214 139.73929579672634 105.172 35.66802505212183 139.73933953599018 105.172 35.66802505212183 139.73933953599018 118.165 35.668072123099414 139.73926034768877 118.165 35.668072123099414 139.73926034768877 111.881 35.66806977360624 139.7392643048921 111.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba53ba6c-adf6-4340-a5c7-1163834dbef9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba53ba6c-adf6-4340-a5c7-1163834dbef9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba53ba6c-adf6-4340-a5c7-1163834dbef9">
											<gml:posList>35.66802985097839 139.7392286733559 111.881 35.66802985097839 139.7392286733559 110.13 35.66806977360624 139.7392643048921 110.13 35.66806977360624 139.7392643048921 111.881 35.66802985097839 139.7392286733559 111.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5c49a3f-0a31-43f2-8027-a25dbe52bc07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5c49a3f-0a31-43f2-8027-a25dbe52bc07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5c49a3f-0a31-43f2-8027-a25dbe52bc07">
											<gml:posList>35.66802942313224 139.73933870242124 118.165 35.66802942313224 139.73933870242124 117.435 35.66807282134147 139.73926570415117 117.435 35.66807282134147 139.73926570415117 118.165 35.66802942313224 139.73933870242124 118.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-42c0f998-33eb-440f-8544-5e6523c7b7dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42c0f998-33eb-440f-8544-5e6523c7b7dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42c0f998-33eb-440f-8544-5e6523c7b7dd">
											<gml:posList>35.66802505212183 139.73933953599018 105.172 35.66825409729042 139.73954399343955 105.172 35.66825409729042 139.73954399343955 118.165 35.66802505212183 139.73933953599018 118.165 35.66802505212183 139.73933953599018 105.172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dfe7e853-fc89-4e8b-8316-d126fb0a929c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfe7e853-fc89-4e8b-8316-d126fb0a929c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfe7e853-fc89-4e8b-8316-d126fb0a929c">
											<gml:posList>35.66830116839192 139.73946479398538 111.881 35.6683471975012 139.73950588637325 111.881 35.6683471975012 139.73950588637325 11.14 35.668028971294746 139.73922182590834 11.14 35.668028971294746 139.73922182590834 111.881 35.668072123099414 139.73926034768877 111.881 35.668072123099414 139.73926034768877 118.165 35.66830116839192 139.73946479398538 118.165 35.66830116839192 139.73946479398538 111.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c44d1be-f140-4791-9b58-e331b836c664">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c44d1be-f140-4791-9b58-e331b836c664">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c44d1be-f140-4791-9b58-e331b836c664">
											<gml:posList>35.66830039188085 139.7395209194823 110.13 35.66830039188085 139.7395209194823 105.172 35.6682004522974 139.73968907858347 105.172 35.6682004522974 139.73968907858347 110.13 35.66830039188085 139.7395209194823 110.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4b7a5ce-e4d2-4a98-b737-603879204b1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4b7a5ce-e4d2-4a98-b737-603879204b1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4b7a5ce-e4d2-4a98-b737-603879204b1b">
											<gml:posList>35.668341618839975 139.73950696436106 111.881 35.668341618839975 139.73950696436106 110.13 35.66820083734483 139.7397437777234 110.13 35.66820083734483 139.7397437777234 111.881 35.668341618839975 139.73950696436106 111.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-801512eb-ff28-48ed-bc21-1816da886a2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-801512eb-ff28-48ed-bc21-1816da886a2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-801512eb-ff28-48ed-bc21-1816da886a2e">
											<gml:posList>35.668201726003936 139.73975061413495 11.14 35.6683471975012 139.73950588637325 11.14 35.6683471975012 139.73950588637325 111.881 35.668201726003936 139.73975061413495 111.881 35.668201726003936 139.73975061413495 11.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79403ab8-1661-42c6-a0e3-0fddec4082cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79403ab8-1661-42c6-a0e3-0fddec4082cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79403ab8-1661-42c6-a0e3-0fddec4082cd">
											<gml:posList>35.66829679738943 139.73946563859624 118.165 35.66829679738943 139.73946563859624 117.435 35.66825339906937 139.7395386480085 117.435 35.66825339906937 139.7395386480085 118.165 35.66829679738943 139.73946563859624 118.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-949fda44-6f73-4225-b782-9534bfe80e18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-949fda44-6f73-4225-b782-9534bfe80e18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-949fda44-6f73-4225-b782-9534bfe80e18">
											<gml:posList>35.66825409729042 139.73954399343955 105.172 35.66827910465957 139.73950191218154 105.172 35.66827910465957 139.73950191218154 110.13 35.66829881889211 139.73946875119404 110.13 35.66829881889211 139.73946875119404 111.881 35.66830116839192 139.73946479398538 111.881 35.66830116839192 139.73946479398538 118.165 35.66825409729042 139.73954399343955 118.165 35.66825409729042 139.73954399343955 105.172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7f9b5ff-087b-4066-9199-767ca4557f6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7f9b5ff-087b-4066-9199-767ca4557f6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7f9b5ff-087b-4066-9199-767ca4557f6d">
											<gml:posList>35.66827910465957 139.73950191218154 110.13 35.66827910465957 139.73950191218154 105.172 35.66830039188085 139.7395209194823 105.172 35.66830039188085 139.7395209194823 110.13 35.66827910465957 139.73950191218154 110.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a83a99b-1436-43f1-b414-279727a26b7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a83a99b-1436-43f1-b414-279727a26b7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a83a99b-1436-43f1-b414-279727a26b7e">
											<gml:posList>35.66829881889211 139.73946875119404 111.881 35.66829881889211 139.73946875119404 110.13 35.668341618839975 139.73950696436106 110.13 35.668341618839975 139.73950696436106 111.881 35.66829881889211 139.73946875119404 111.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3877</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">1197.2192</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.18</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>