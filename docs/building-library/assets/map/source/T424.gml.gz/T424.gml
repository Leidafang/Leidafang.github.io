<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_7c4d1f98-e5ae-4fe6-8b2a-177f38d0a520">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">27.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67011364988846 139.74129827813437 0 35.67021262386223 139.7413024725561 0 35.67020833404935 139.74111491239546 0 35.670107204220194 139.74112044136047 0 35.67011364988846 139.74129827813437 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67011364988846 139.74129827813437 8.56 35.670107204220194 139.74112044136047 8.56 35.67020833404935 139.74111491239546 8.56 35.67021262386223 139.7413024725561 8.56 35.67011364988846 139.74129827813437 8.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67011364988846 139.74129827813437 8.56 35.67021262386223 139.7413024725561 8.56 35.67021262386223 139.7413024725561 35.64 35.67011364988846 139.74129827813437 35.64 35.67011364988846 139.74129827813437 8.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021262386223 139.7413024725561 8.56 35.67020833404935 139.74111491239546 8.56 35.67020833404935 139.74111491239546 35.64 35.67021262386223 139.7413024725561 35.64 35.67021262386223 139.7413024725561 8.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67020833404935 139.74111491239546 8.56 35.670107204220194 139.74112044136047 8.56 35.670107204220194 139.74112044136047 35.64 35.67020833404935 139.74111491239546 35.64 35.67020833404935 139.74111491239546 8.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670107204220194 139.74112044136047 8.56 35.67011364988846 139.74129827813437 8.56 35.67011364988846 139.74129827813437 35.64 35.670107204220194 139.74112044136047 35.64 35.670107204220194 139.74112044136047 8.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67011364988846 139.74129827813437 35.64 35.67021262386223 139.7413024725561 35.64 35.67020833404935 139.74111491239546 35.64 35.670107204220194 139.74112044136047 35.64 35.67011364988846 139.74129827813437 35.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-700fea6d-68d4-4a0c-b926-f5596d2e9338"/>
							<gml:surfaceMember xlink:href="#poly-776b28a6-12ff-4bfa-81c2-068d4f21b0d2"/>
							<gml:surfaceMember xlink:href="#poly-6d312ddc-b707-4c16-b19a-ce345c700c09"/>
							<gml:surfaceMember xlink:href="#poly-2bfb5c06-b7df-4c6a-975e-19c79316e15d"/>
							<gml:surfaceMember xlink:href="#poly-f7eebb0f-48ad-4110-912a-57dccf303827"/>
							<gml:surfaceMember xlink:href="#poly-fdb44904-3932-4114-bb91-694e27fee096"/>
							<gml:surfaceMember xlink:href="#poly-69a59ff9-4ac0-4c4a-b47e-7c61b5703db8"/>
							<gml:surfaceMember xlink:href="#poly-f115b750-834d-4834-9ce0-85a4fd85dd91"/>
							<gml:surfaceMember xlink:href="#poly-68e7f5d3-b190-4424-a61f-3a6206d97275"/>
							<gml:surfaceMember xlink:href="#poly-46abe5c2-27e1-4d31-a703-fc94873e1dfa"/>
							<gml:surfaceMember xlink:href="#poly-d39643b6-e6e6-4914-9061-a3d760385374"/>
							<gml:surfaceMember xlink:href="#poly-a15e302f-9ee4-4884-897e-3c147cf504d3"/>
							<gml:surfaceMember xlink:href="#poly-251e9f36-fb43-4f31-bfaf-04e3a5e073ec"/>
							<gml:surfaceMember xlink:href="#poly-0f38de6b-9056-4755-b21a-2d497cf0f1ec"/>
							<gml:surfaceMember xlink:href="#poly-c5844e90-c19c-4b0e-bba0-643ed36af6b7"/>
							<gml:surfaceMember xlink:href="#poly-9fb86e2d-82e1-443d-b041-d4a5f852dba2"/>
							<gml:surfaceMember xlink:href="#poly-6aa695e6-dc10-4f35-9ee9-461609d473c1"/>
							<gml:surfaceMember xlink:href="#poly-e51321a8-e206-470c-badf-80861335733e"/>
							<gml:surfaceMember xlink:href="#poly-a392c3e5-cb9a-4e15-b907-ca0ce39c0003"/>
							<gml:surfaceMember xlink:href="#poly-38096e95-7476-4889-9c10-11cd168b6ebc"/>
							<gml:surfaceMember xlink:href="#poly-890acb38-6855-4572-8ecd-9522754b4cbc"/>
							<gml:surfaceMember xlink:href="#poly-aea9fcbb-16b8-4a17-b6f8-d611a5bb8d31"/>
							<gml:surfaceMember xlink:href="#poly-07ab32b5-3d0a-4656-a241-475890a47ddc"/>
							<gml:surfaceMember xlink:href="#poly-859dc702-de56-4326-b564-190fa087b33d"/>
							<gml:surfaceMember xlink:href="#poly-8bbef770-97ca-4b3c-8c56-10cb2780c714"/>
							<gml:surfaceMember xlink:href="#poly-52af8765-4fcb-428b-835c-55b414d718f3"/>
							<gml:surfaceMember xlink:href="#poly-352d002d-68d7-487f-82fd-201d02c4069a"/>
							<gml:surfaceMember xlink:href="#poly-037bff49-958c-4b25-b83f-7e68a88d2f65"/>
							<gml:surfaceMember xlink:href="#poly-7ef39aa7-1a00-4f37-9fe8-17fc423f3984"/>
							<gml:surfaceMember xlink:href="#poly-31eaed68-b39b-46dc-b2df-c582ed0bdf5b"/>
							<gml:surfaceMember xlink:href="#poly-bed02789-1b99-4e12-b8dc-bbc2229bc5db"/>
							<gml:surfaceMember xlink:href="#poly-c7db303b-b41a-4282-8d14-03cf45a074df"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_7c4d1f98-e5ae-4fe6-8b2a-177f38d0a520_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17f0f039-d2d6-4ede-8597-defc8ede7f3f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670134810796384 139.7411289704351 39.007 35.67013462651251 139.74112373473608 39.007 35.67017587162653 139.74112148910172 39.007 35.67017605591898 139.7411267358497 39.007 35.670134810796384 139.7411289704351 39.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e94807d-ccfd-46c4-b715-5a538df440f6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670134810796384 139.7411289704351 41.657 35.670134810796384 139.7411289704351 39.007 35.67017605591898 139.7411267358497 39.007 35.67017605591898 139.7411267358497 41.657 35.670134810796384 139.7411289704351 41.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-026d474f-c37f-4658-9789-3f4c5097c988">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013496725227 139.7411331788672 41.657 35.670134810796384 139.7411289704351 41.657 35.67017605591898 139.7411267358497 41.657 35.67017621237493 139.74113094428392 41.657 35.67013496725227 139.7411331788672 41.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40c3100d-2a93-4388-a389-25e2ebffb095">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67017621237493 139.74113094428392 41.343 35.67013496725227 139.7411331788672 41.343 35.67013496725227 139.7411331788672 41.657 35.67017621237493 139.74113094428392 41.657 35.67017621237493 139.74113094428392 41.343</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-394d7c7a-4f7d-4fa9-8084-2983a04eae26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670135538281635 139.74114908477569 41.343 35.67013496725227 139.7411331788672 41.343 35.67017621237493 139.74113094428392 41.343 35.670176783404614 139.7411468502006 41.343 35.670135538281635 139.74114908477569 41.343</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2f9d318-e2ea-4715-bb9b-7b49ec086223">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670176783404614 139.7411468502006 41.657 35.670135538281635 139.74114908477569 41.657 35.670135538281635 139.74114908477569 41.343 35.670176783404614 139.7411468502006 41.343 35.670176783404614 139.7411468502006 41.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-461acbad-1c21-43ef-8b7f-ce504d4a5f4c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013569474528 139.74115330425408 41.657 35.670135538281635 139.74114908477569 41.657 35.670176783404614 139.7411468502006 41.657 35.67017693986833 139.74115106968114 41.657 35.67013569474528 139.74115330425408 41.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f0e9406-55c9-4cf4-87b9-8d055e327c3a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013569474528 139.74115330425408 41.657 35.67017693986833 139.74115106968114 41.657 35.67017693986833 139.74115106968114 38.868 35.67013569474528 139.74115330425408 38.868 35.67013569474528 139.74115330425408 41.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da5c3136-a28e-4d1d-a180-e1da560ba65e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670136440642814 139.74117392670036 38.868 35.67013569474528 139.74115330425408 38.868 35.67017693986833 139.74115106968114 38.868 35.670177685757814 139.74117168109177 38.868 35.670136440642814 139.74117392670036 38.868</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5668a882-fedb-499d-a06c-0918f9514e9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5668a882-fedb-499d-a06c-0918f9514e9c_0">
											<gml:posList>35.67017587162653 139.74112148910172 39.007 35.67013462651251 139.74112373473608 39.007 35.67013462651251 139.74112373473608 43.895 35.67014837188214 139.74112298987708 43.895 35.67014837188214 139.74112298987708 42.214 35.67016211725173 139.74112224501783 42.214 35.67016211725173 139.74112224501783 43.895 35.67017587162653 139.74112148910172 43.895 35.67017587162653 139.74112148910172 39.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3738016-48a0-4d04-99fb-d5c264fc0108">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3738016-48a0-4d04-99fb-d5c264fc0108_0">
											<gml:posList>35.67017587162653 139.74112148910172 39.007 35.67017587162653 139.74112148910172 43.895 35.670177685757814 139.74117168109177 43.895 35.670177685757814 139.74117168109177 38.868 35.67017693986833 139.74115106968114 38.868 35.67017693986833 139.74115106968114 41.657 35.670176783404614 139.7411468502006 41.657 35.670176783404614 139.7411468502006 41.343 35.67017621237493 139.74113094428392 41.343 35.67017621237493 139.74113094428392 41.657 35.67017605591898 139.7411267358497 41.657 35.67017605591898 139.7411267358497 39.007 35.67017587162653 139.74112148910172 39.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b306413-bad9-4c5e-8314-ca73a341ab6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b306413-bad9-4c5e-8314-ca73a341ab6b_0">
											<gml:posList>35.67016394038793 139.7411724259427 43.895 35.670177685757814 139.74117168109177 43.895 35.67017587162653 139.74112148910172 43.895 35.67016211725173 139.74112224501783 43.895 35.67016394038793 139.7411724259427 43.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d747896-fd0b-49b2-b755-2f52f31aafb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d747896-fd0b-49b2-b755-2f52f31aafb9_0">
											<gml:posList>35.67016394038793 139.7411724259427 43.895 35.67016211725173 139.74112224501783 43.895 35.67016211725173 139.74112224501783 42.214 35.67016394038793 139.7411724259427 42.214 35.67016394038793 139.7411724259427 43.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-421febbd-b952-465d-b52a-81f83e6dfaa9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-421febbd-b952-465d-b52a-81f83e6dfaa9_0">
											<gml:posList>35.67016211725173 139.74112224501783 42.214 35.67014837188214 139.74112298987708 42.214 35.67015018601276 139.74117318184994 42.214 35.67016394038793 139.7411724259427 42.214 35.67016211725173 139.74112224501783 42.214</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16536cd0-673c-4810-97af-445849229927">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16536cd0-673c-4810-97af-445849229927_0">
											<gml:posList>35.67014837188214 139.74112298987708 43.895 35.67015018601276 139.74117318184994 43.895 35.67015018601276 139.74117318184994 42.214 35.67014837188214 139.74112298987708 42.214 35.67014837188214 139.74112298987708 43.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f961b03-7795-40fd-9a84-ab7b6260a81c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f961b03-7795-40fd-9a84-ab7b6260a81c_0">
											<gml:posList>35.67014837188214 139.74112298987708 43.895 35.67013462651251 139.74112373473608 43.895 35.670136440642814 139.74117392670036 43.895 35.67015018601276 139.74117318184994 43.895 35.67014837188214 139.74112298987708 43.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b30bad46-979d-4981-8cd9-2d60d48407f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b30bad46-979d-4981-8cd9-2d60d48407f1_0">
											<gml:posList>35.670134810796384 139.7411289704351 41.657 35.67013496725227 139.7411331788672 41.657 35.67013496725227 139.7411331788672 41.343 35.670135538281635 139.74114908477569 41.343 35.670135538281635 139.74114908477569 41.657 35.67013569474528 139.74115330425408 41.657 35.67013569474528 139.74115330425408 38.868 35.670136440642814 139.74117392670036 38.868 35.670136440642814 139.74117392670036 43.895 35.67013462651251 139.74112373473608 43.895 35.67013462651251 139.74112373473608 39.007 35.670134810796384 139.7411289704351 39.007 35.670134810796384 139.7411289704351 41.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb0e6162-d769-450b-bb40-d322a4ed871e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb0e6162-d769-450b-bb40-d322a4ed871e_0">
											<gml:posList>35.670136440642814 139.74117392670036 43.895 35.670136440642814 139.74117392670036 38.868 35.670177685757814 139.74117168109177 38.868 35.670177685757814 139.74117168109177 43.895 35.67016394038793 139.7411724259427 43.895 35.67016394038793 139.7411724259427 42.214 35.67015018601276 139.74117318184994 42.214 35.67015018601276 139.74117318184994 43.895 35.670136440642814 139.74117392670036 43.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_7c4d1f98-e5ae-4fe6-8b2a-177f38d0a520_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8283564a-0bdd-44cb-911e-39268f385304">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67016252250016 139.74113353379832 42.214 35.67016345253145 139.74115919312035 42.214 35.67014970715317 139.74115992692705 42.214 35.670148777113596 139.7411342565632 42.214 35.67016252250016 139.74113353379832 42.214</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-215ec5dc-3af6-4831-a49e-18d92cffedb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-215ec5dc-3af6-4831-a49e-18d92cffedb9_0">
											<gml:posList>35.670148777113596 139.7411342565632 42.214 35.670148777113596 139.7411342565632 42.792 35.67016252250016 139.74113353379832 42.792 35.67016252250016 139.74113353379832 42.214 35.670148777113596 139.7411342565632 42.214</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e98d811d-e93a-4fd5-9851-e5d6bf28e677">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e98d811d-e93a-4fd5-9851-e5d6bf28e677_0">
											<gml:posList>35.67016345253145 139.74115919312035 42.792 35.67016345253145 139.74115919312035 42.214 35.67016252250016 139.74113353379832 42.214 35.67016252250016 139.74113353379832 42.792 35.67016345253145 139.74115919312035 42.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-162a4a6a-eab9-4a67-a0f3-cd42c1ebf93d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-162a4a6a-eab9-4a67-a0f3-cd42c1ebf93d_0">
											<gml:posList>35.67014970715317 139.74115992692705 42.792 35.67016345253145 139.74115919312035 42.792 35.67016252250016 139.74113353379832 42.792 35.670148777113596 139.7411342565632 42.792 35.67014970715317 139.74115992692705 42.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e867685-e93f-46b7-a350-a564bfc59eaa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e867685-e93f-46b7-a350-a564bfc59eaa_0">
											<gml:posList>35.67014970715317 139.74115992692705 42.792 35.670148777113596 139.7411342565632 42.792 35.670148777113596 139.7411342565632 42.214 35.67014970715317 139.74115992692705 42.214 35.67014970715317 139.74115992692705 42.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d564286-acba-4fae-bff0-72fa4d1d2fdd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d564286-acba-4fae-bff0-72fa4d1d2fdd_0">
											<gml:posList>35.67014970715317 139.74115992692705 42.214 35.67016345253145 139.74115919312035 42.214 35.67016345253145 139.74115919312035 42.792 35.67014970715317 139.74115992692705 42.792 35.67014970715317 139.74115992692705 42.214</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-700fea6d-68d4-4a0c-b926-f5596d2e9338">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-700fea6d-68d4-4a0c-b926-f5596d2e9338">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-700fea6d-68d4-4a0c-b926-f5596d2e9338">
											<gml:posList>35.670113649888414 139.74129827813434 8.56 35.670107204220194 139.74112044136047 8.56 35.67020833404933 139.7411149123955 8.56 35.6702126238622 139.7413024725561 8.56 35.670113649888414 139.74129827813434 8.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-776b28a6-12ff-4bfa-81c2-068d4f21b0d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-776b28a6-12ff-4bfa-81c2-068d4f21b0d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-776b28a6-12ff-4bfa-81c2-068d4f21b0d2">
											<gml:posList>35.67010737914368 139.74112522417337 39.007 35.670111835754696 139.7411302229869 39.007 35.670199067015275 139.74112548325436 39.007 35.67020314604464 139.74112001067695 39.007 35.67010737914368 139.74112522417337 39.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d312ddc-b707-4c16-b19a-ce345c700c09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d312ddc-b707-4c16-b19a-ce345c700c09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d312ddc-b707-4c16-b19a-ce345c700c09">
											<gml:posList>35.670111835754696 139.7411302229869 41.657 35.67011542629531 139.74113423968308 41.657 35.67019578037283 139.74112988343532 41.657 35.670199067015275 139.74112548325436 41.657 35.670111835754696 139.7411302229869 41.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2bfb5c06-b7df-4c6a-975e-19c79316e15d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bfb5c06-b7df-4c6a-975e-19c79316e15d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bfb5c06-b7df-4c6a-975e-19c79316e15d">
											<gml:posList>35.670199067015275 139.74112548325436 41.657 35.67019578037283 139.74112988343532 41.657 35.67019636041637 139.7411457893455 41.657 35.670199950964886 139.7411498170928 41.657 35.670199067015275 139.74112548325436 41.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f7eebb0f-48ad-4110-912a-57dccf303827">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7eebb0f-48ad-4110-912a-57dccf303827">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7eebb0f-48ad-4110-912a-57dccf303827">
											<gml:posList>35.67019636041637 139.7411457893455 41.343 35.67019578037283 139.74112988343532 41.343 35.67011542629531 139.74113423968308 41.343 35.67011600633826 139.74115014557734 41.343 35.67019636041637 139.7411457893455 41.343</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fdb44904-3932-4114-bb91-694e27fee096">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdb44904-3932-4114-bb91-694e27fee096">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdb44904-3932-4114-bb91-694e27fee096">
											<gml:posList>35.670112719703326 139.7411545567989 41.657 35.67011600633826 139.74115014557734 41.657 35.67011542629531 139.74113423968308 41.657 35.670111835754696 139.7411302229869 41.657 35.670112719703326 139.7411545567989 41.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-69a59ff9-4ac0-4c4a-b47e-7c61b5703db8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69a59ff9-4ac0-4c4a-b47e-7c61b5703db8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69a59ff9-4ac0-4c4a-b47e-7c61b5703db8">
											<gml:posList>35.670199950964886 139.7411498170928 41.657 35.67019636041637 139.7411457893455 41.657 35.67011600633826 139.74115014557734 41.657 35.670112719703326 139.7411545567989 41.657 35.670199950964886 139.7411498170928 41.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f115b750-834d-4834-9ce0-85a4fd85dd91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f115b750-834d-4834-9ce0-85a4fd85dd91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f115b750-834d-4834-9ce0-85a4fd85dd91">
											<gml:posList>35.67020643350389 139.7412108842761 39.007 35.67020314604464 139.74112001067695 39.007 35.670199067015275 139.74112548325436 39.007 35.670199950964886 139.7411498170928 39.007 35.67020196789101 139.74120589650877 39.007 35.67020643350389 139.7412108842761 39.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68e7f5d3-b190-4424-a61f-3a6206d97275">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68e7f5d3-b190-4424-a61f-3a6206d97275">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68e7f5d3-b190-4424-a61f-3a6206d97275">
											<gml:posList>35.670110675612605 139.74121609765388 39.007 35.6701147456409 139.74121063614365 39.007 35.670112719703326 139.7411545567989 39.007 35.670111835754696 139.7411302229869 39.007 35.67010737914368 139.74112522417337 39.007 35.670110675612605 139.74121609765388 39.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46abe5c2-27e1-4d31-a703-fc94873e1dfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46abe5c2-27e1-4d31-a703-fc94873e1dfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46abe5c2-27e1-4d31-a703-fc94873e1dfa">
											<gml:posList>35.67020643350389 139.7412108842761 36.139 35.670110675612605 139.74121609765388 36.139 35.670111476849 139.7412383769641 36.139 35.67021108496976 139.74123494868041 36.139 35.67020833404933 139.7411149123955 36.139 35.670107204220194 139.74112044136047 36.139 35.67010737914368 139.74112522417337 36.139 35.67020314604464 139.74112001067695 36.139 35.67020643350389 139.7412108842761 36.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d39643b6-e6e6-4914-9061-a3d760385374">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d39643b6-e6e6-4914-9061-a3d760385374">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d39643b6-e6e6-4914-9061-a3d760385374">
											<gml:posList>35.6701147456409 139.74121063614365 38.868 35.67020196789101 139.74120589650877 38.868 35.670199950964886 139.7411498170928 38.868 35.670112719703326 139.7411545567989 38.868 35.6701147456409 139.74121063614365 38.868</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a15e302f-9ee4-4884-897e-3c147cf504d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a15e302f-9ee4-4884-897e-3c147cf504d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a15e302f-9ee4-4884-897e-3c147cf504d3">
											<gml:posList>35.67020643350389 139.7412108842761 39.007 35.67020196789101 139.74120589650877 39.007 35.6701147456409 139.74121063614365 39.007 35.670110675612605 139.74121609765388 39.007 35.67020643350389 139.7412108842761 39.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-251e9f36-fb43-4f31-bfaf-04e3a5e073ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-251e9f36-fb43-4f31-bfaf-04e3a5e073ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-251e9f36-fb43-4f31-bfaf-04e3a5e073ec">
											<gml:posList>35.67021108496976 139.74123494868041 36.139 35.670111476849 139.7412383769641 36.139 35.670113649888414 139.74129827813434 25.871 35.67021108496976 139.74123494868041 36.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0f38de6b-9056-4755-b21a-2d497cf0f1ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f38de6b-9056-4755-b21a-2d497cf0f1ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f38de6b-9056-4755-b21a-2d497cf0f1ec">
											<gml:posList>35.670113649888414 139.74129827813434 25.871 35.6702126238622 139.7413024725561 25.871 35.67021108496976 139.74123494868041 36.139 35.670113649888414 139.74129827813434 25.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5844e90-c19c-4b0e-bba0-643ed36af6b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5844e90-c19c-4b0e-bba0-643ed36af6b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5844e90-c19c-4b0e-bba0-643ed36af6b7">
											<gml:posList>35.670110675612605 139.74121609765388 36.139 35.670110675612605 139.74121609765388 39.007 35.67010737914368 139.74112522417337 39.007 35.67010737914368 139.74112522417337 36.139 35.670107204220194 139.74112044136047 36.139 35.670107204220194 139.74112044136047 8.56 35.670113649888414 139.74129827813434 8.56 35.670113649888414 139.74129827813434 25.871 35.670111476849 139.7412383769641 36.139 35.670110675612605 139.74121609765388 36.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9fb86e2d-82e1-443d-b041-d4a5f852dba2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fb86e2d-82e1-443d-b041-d4a5f852dba2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fb86e2d-82e1-443d-b041-d4a5f852dba2">
											<gml:posList>35.670112719703326 139.7411545567989 39.007 35.670112719703326 139.7411545567989 41.657 35.670111835754696 139.7411302229869 41.657 35.670111835754696 139.7411302229869 39.007 35.670112719703326 139.7411545567989 39.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6aa695e6-dc10-4f35-9ee9-461609d473c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6aa695e6-dc10-4f35-9ee9-461609d473c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6aa695e6-dc10-4f35-9ee9-461609d473c1">
											<gml:posList>35.6701147456409 139.74121063614365 39.007 35.6701147456409 139.74121063614365 38.868 35.670112719703326 139.7411545567989 38.868 35.670112719703326 139.7411545567989 39.007 35.6701147456409 139.74121063614365 39.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e51321a8-e206-470c-badf-80861335733e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e51321a8-e206-470c-badf-80861335733e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e51321a8-e206-470c-badf-80861335733e">
											<gml:posList>35.67011600633826 139.74115014557734 41.657 35.67011600633826 139.74115014557734 41.343 35.67011542629531 139.74113423968308 41.343 35.67011542629531 139.74113423968308 41.657 35.67011600633826 139.74115014557734 41.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a392c3e5-cb9a-4e15-b907-ca0ce39c0003">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a392c3e5-cb9a-4e15-b907-ca0ce39c0003">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a392c3e5-cb9a-4e15-b907-ca0ce39c0003">
											<gml:posList>35.67010737914368 139.74112522417337 36.139 35.67010737914368 139.74112522417337 39.007 35.67020314604464 139.74112001067695 39.007 35.67020314604464 139.74112001067695 36.139 35.67010737914368 139.74112522417337 36.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38096e95-7476-4889-9c10-11cd168b6ebc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38096e95-7476-4889-9c10-11cd168b6ebc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38096e95-7476-4889-9c10-11cd168b6ebc">
											<gml:posList>35.670111835754696 139.7411302229869 39.007 35.670111835754696 139.7411302229869 41.657 35.670199067015275 139.74112548325436 41.657 35.670199067015275 139.74112548325436 39.007 35.670111835754696 139.7411302229869 39.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-890acb38-6855-4572-8ecd-9522754b4cbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-890acb38-6855-4572-8ecd-9522754b4cbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-890acb38-6855-4572-8ecd-9522754b4cbc">
											<gml:posList>35.67011542629531 139.74113423968308 41.657 35.67011542629531 139.74113423968308 41.343 35.67019578037283 139.74112988343532 41.343 35.67019578037283 139.74112988343532 41.657 35.67011542629531 139.74113423968308 41.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aea9fcbb-16b8-4a17-b6f8-d611a5bb8d31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aea9fcbb-16b8-4a17-b6f8-d611a5bb8d31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aea9fcbb-16b8-4a17-b6f8-d611a5bb8d31">
											<gml:posList>35.67019636041637 139.7411457893455 41.657 35.67019636041637 139.7411457893455 41.343 35.67011600633826 139.74115014557734 41.343 35.67011600633826 139.74115014557734 41.657 35.67019636041637 139.7411457893455 41.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07ab32b5-3d0a-4656-a241-475890a47ddc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07ab32b5-3d0a-4656-a241-475890a47ddc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07ab32b5-3d0a-4656-a241-475890a47ddc">
											<gml:posList>35.670112719703326 139.7411545567989 39.007 35.670112719703326 139.7411545567989 38.868 35.670199950964886 139.7411498170928 38.868 35.670199950964886 139.7411498170928 39.007 35.670199950964886 139.7411498170928 41.657 35.670112719703326 139.7411545567989 41.657 35.670112719703326 139.7411545567989 39.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-859dc702-de56-4326-b564-190fa087b33d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-859dc702-de56-4326-b564-190fa087b33d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-859dc702-de56-4326-b564-190fa087b33d">
											<gml:posList>35.67020833404933 139.7411149123955 8.56 35.670107204220194 139.74112044136047 8.56 35.670107204220194 139.74112044136047 36.139 35.67020833404933 139.7411149123955 36.139 35.67020833404933 139.7411149123955 8.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8bbef770-97ca-4b3c-8c56-10cb2780c714">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bbef770-97ca-4b3c-8c56-10cb2780c714">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bbef770-97ca-4b3c-8c56-10cb2780c714">
											<gml:posList>35.67020196789101 139.74120589650877 39.007 35.67020196789101 139.74120589650877 38.868 35.6701147456409 139.74121063614365 38.868 35.6701147456409 139.74121063614365 39.007 35.67020196789101 139.74120589650877 39.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52af8765-4fcb-428b-835c-55b414d718f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52af8765-4fcb-428b-835c-55b414d718f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52af8765-4fcb-428b-835c-55b414d718f3">
											<gml:posList>35.67020643350389 139.7412108842761 36.139 35.67020643350389 139.7412108842761 39.007 35.670110675612605 139.74121609765388 39.007 35.670110675612605 139.74121609765388 36.139 35.67020643350389 139.7412108842761 36.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-352d002d-68d7-487f-82fd-201d02c4069a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-352d002d-68d7-487f-82fd-201d02c4069a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-352d002d-68d7-487f-82fd-201d02c4069a">
											<gml:posList>35.670113649888414 139.74129827813434 8.56 35.6702126238622 139.7413024725561 8.56 35.6702126238622 139.7413024725561 25.871 35.670113649888414 139.74129827813434 25.871 35.670113649888414 139.74129827813434 8.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-037bff49-958c-4b25-b83f-7e68a88d2f65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-037bff49-958c-4b25-b83f-7e68a88d2f65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-037bff49-958c-4b25-b83f-7e68a88d2f65">
											<gml:posList>35.67019578037283 139.74112988343532 41.657 35.67019578037283 139.74112988343532 41.343 35.67019636041637 139.7411457893455 41.343 35.67019636041637 139.7411457893455 41.657 35.67019578037283 139.74112988343532 41.657</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ef39aa7-1a00-4f37-9fe8-17fc423f3984">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ef39aa7-1a00-4f37-9fe8-17fc423f3984">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ef39aa7-1a00-4f37-9fe8-17fc423f3984">
											<gml:posList>35.670199067015275 139.74112548325436 39.007 35.670199067015275 139.74112548325436 41.657 35.670199950964886 139.7411498170928 41.657 35.670199950964886 139.7411498170928 39.007 35.670199067015275 139.74112548325436 39.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31eaed68-b39b-46dc-b2df-c582ed0bdf5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31eaed68-b39b-46dc-b2df-c582ed0bdf5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31eaed68-b39b-46dc-b2df-c582ed0bdf5b">
											<gml:posList>35.670199950964886 139.7411498170928 39.007 35.670199950964886 139.7411498170928 38.868 35.67020196789101 139.74120589650877 38.868 35.67020196789101 139.74120589650877 39.007 35.670199950964886 139.7411498170928 39.007</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bed02789-1b99-4e12-b8dc-bbc2229bc5db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bed02789-1b99-4e12-b8dc-bbc2229bc5db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bed02789-1b99-4e12-b8dc-bbc2229bc5db">
											<gml:posList>35.67020314604464 139.74112001067695 36.139 35.67020314604464 139.74112001067695 39.007 35.67020643350389 139.7412108842761 39.007 35.67020643350389 139.7412108842761 36.139 35.67020314604464 139.74112001067695 36.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7db303b-b41a-4282-8d14-03cf45a074df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7db303b-b41a-4282-8d14-03cf45a074df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7db303b-b41a-4282-8d14-03cf45a074df">
											<gml:posList>35.67020833404933 139.7411149123955 36.139 35.67021108496976 139.74123494868041 36.139 35.6702126238622 139.7413024725561 25.871 35.6702126238622 139.7413024725561 8.56 35.67020833404933 139.7411149123955 8.56 35.67020833404933 139.7411149123955 36.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4597</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">183.623</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.26</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>