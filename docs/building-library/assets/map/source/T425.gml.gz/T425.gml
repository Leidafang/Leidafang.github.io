<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_7c6d6f74-eb3d-42f6-be19-c28715ab2f40">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">23.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6673712786734 139.7390419982588 0 35.66744604725839 139.7390991278675 0 35.667527136182535 139.7389397511809 0 35.66762093199729 139.7390073520051 0 35.667623928713994 139.73900115174146 0 35.66764349962742 139.73901533372242 0 35.6676951006327 139.73890847032249 0 35.667675529698236 139.73889427731262 0 35.66767573667606 139.73889384627927 0 35.667584195183785 139.73882745793108 0 35.667586085205485 139.73882381056498 0 35.667511316491854 139.73876668111382 0 35.6673712786734 139.7390419982588 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6673712786734 139.7390419982588 11.63 35.667511316491854 139.73876668111382 11.63 35.667586085205485 139.73882381056498 11.63 35.667584195183785 139.73882745793108 11.63 35.66767573667606 139.73889384627927 11.63 35.667675529698236 139.73889427731262 11.63 35.6676951006327 139.73890847032249 11.63 35.66764349962742 139.73901533372242 11.63 35.667623928713994 139.73900115174146 11.63 35.66762093199729 139.7390073520051 11.63 35.667527136182535 139.7389397511809 11.63 35.66744604725839 139.7390991278675 11.63 35.6673712786734 139.7390419982588 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6673712786734 139.7390419982588 11.63 35.66744604725839 139.7390991278675 11.63 35.66744604725839 139.7390991278675 34.86 35.6673712786734 139.7390419982588 34.86 35.6673712786734 139.7390419982588 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66744604725839 139.7390991278675 11.63 35.667527136182535 139.7389397511809 11.63 35.667527136182535 139.7389397511809 34.86 35.66744604725839 139.7390991278675 34.86 35.66744604725839 139.7390991278675 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667527136182535 139.7389397511809 11.63 35.66762093199729 139.7390073520051 11.63 35.66762093199729 139.7390073520051 34.86 35.667527136182535 139.7389397511809 34.86 35.667527136182535 139.7389397511809 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66762093199729 139.7390073520051 11.63 35.667623928713994 139.73900115174146 11.63 35.667623928713994 139.73900115174146 34.86 35.66762093199729 139.7390073520051 34.86 35.66762093199729 139.7390073520051 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667623928713994 139.73900115174146 11.63 35.66764349962742 139.73901533372242 11.63 35.66764349962742 139.73901533372242 34.86 35.667623928713994 139.73900115174146 34.86 35.667623928713994 139.73900115174146 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66764349962742 139.73901533372242 11.63 35.6676951006327 139.73890847032249 11.63 35.6676951006327 139.73890847032249 34.86 35.66764349962742 139.73901533372242 34.86 35.66764349962742 139.73901533372242 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6676951006327 139.73890847032249 11.63 35.667675529698236 139.73889427731262 11.63 35.667675529698236 139.73889427731262 34.86 35.6676951006327 139.73890847032249 34.86 35.6676951006327 139.73890847032249 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667675529698236 139.73889427731262 11.63 35.66767573667606 139.73889384627927 11.63 35.66767573667606 139.73889384627927 34.86 35.667675529698236 139.73889427731262 34.86 35.667675529698236 139.73889427731262 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66767573667606 139.73889384627927 11.63 35.667584195183785 139.73882745793108 11.63 35.667584195183785 139.73882745793108 34.86 35.66767573667606 139.73889384627927 34.86 35.66767573667606 139.73889384627927 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667584195183785 139.73882745793108 11.63 35.667586085205485 139.73882381056498 11.63 35.667586085205485 139.73882381056498 34.86 35.667584195183785 139.73882745793108 34.86 35.667584195183785 139.73882745793108 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667586085205485 139.73882381056498 11.63 35.667511316491854 139.73876668111382 11.63 35.667511316491854 139.73876668111382 34.86 35.667586085205485 139.73882381056498 34.86 35.667586085205485 139.73882381056498 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667511316491854 139.73876668111382 11.63 35.6673712786734 139.7390419982588 11.63 35.6673712786734 139.7390419982588 34.86 35.667511316491854 139.73876668111382 34.86 35.667511316491854 139.73876668111382 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6673712786734 139.7390419982588 34.86 35.66744604725839 139.7390991278675 34.86 35.667527136182535 139.7389397511809 34.86 35.66762093199729 139.7390073520051 34.86 35.667623928713994 139.73900115174146 34.86 35.66764349962742 139.73901533372242 34.86 35.6676951006327 139.73890847032249 34.86 35.667675529698236 139.73889427731262 34.86 35.66767573667606 139.73889384627927 34.86 35.667584195183785 139.73882745793108 34.86 35.667586085205485 139.73882381056498 34.86 35.667511316491854 139.73876668111382 34.86 35.6673712786734 139.7390419982588 34.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7dfe5dae-b9ad-4188-aef7-682e59186b0a"/>
							<gml:surfaceMember xlink:href="#poly-15fb09cb-4c1d-4cfb-93e6-4fa54c2fb1a2"/>
							<gml:surfaceMember xlink:href="#poly-afd1b4c4-2dbe-4e99-a44a-4a42e56aef75"/>
							<gml:surfaceMember xlink:href="#poly-aa959d1e-255b-4e9d-bc07-5e881f1a1aad"/>
							<gml:surfaceMember xlink:href="#poly-9807fe44-7f97-437f-84c8-692489db5dd5"/>
							<gml:surfaceMember xlink:href="#poly-826c9a97-e51a-4b43-8cf5-9092eb611588"/>
							<gml:surfaceMember xlink:href="#poly-dc0f6377-da38-4c13-8fee-00264cf035ef"/>
							<gml:surfaceMember xlink:href="#poly-5367542c-f81c-4f25-bbd6-5f9336a2a664"/>
							<gml:surfaceMember xlink:href="#poly-0ce40d12-099f-4923-a843-de4d792f4672"/>
							<gml:surfaceMember xlink:href="#poly-8b3258ff-6872-4292-844f-68d92424d059"/>
							<gml:surfaceMember xlink:href="#poly-0b7204bb-80da-477a-8a74-0ca91a400894"/>
							<gml:surfaceMember xlink:href="#poly-d2e64e89-865e-4761-bb16-d2bcef7982c5"/>
							<gml:surfaceMember xlink:href="#poly-0658ff5f-8b99-4c66-8b87-644d36f8246d"/>
							<gml:surfaceMember xlink:href="#poly-5deebed5-374f-4d53-9b5e-7dc44b2b8133"/>
							<gml:surfaceMember xlink:href="#poly-5bf3286f-7299-44ec-9f86-55735623b960"/>
							<gml:surfaceMember xlink:href="#poly-ae8f3506-f0db-4b64-8e5d-708f06f37bfc"/>
							<gml:surfaceMember xlink:href="#poly-9e91b2e9-51b7-44e8-bf35-10c49ed7a35d"/>
							<gml:surfaceMember xlink:href="#poly-fd2ec136-dcb2-4dae-b906-fc31b349bf3c"/>
							<gml:surfaceMember xlink:href="#poly-27d46daf-078c-4bb5-8ce5-a9f86ea81bca"/>
							<gml:surfaceMember xlink:href="#poly-fbd04340-fb9a-41c0-ab2b-fedc208eaa86"/>
							<gml:surfaceMember xlink:href="#poly-03b3be35-f055-4279-a88a-e3e1bf7df512"/>
							<gml:surfaceMember xlink:href="#poly-1c8fd7c2-8036-41b8-88a2-fda788fe9a56"/>
							<gml:surfaceMember xlink:href="#poly-1c03ebe5-4bf1-46d5-8376-5630b363d8da"/>
							<gml:surfaceMember xlink:href="#poly-8655c9fa-59ab-44ec-a2d1-df08e981c0a7"/>
							<gml:surfaceMember xlink:href="#poly-ceed687b-7352-41a9-8e9c-f519fa0c3b37"/>
							<gml:surfaceMember xlink:href="#poly-d275bf1d-18b9-42f6-954d-8d1329232088"/>
							<gml:surfaceMember xlink:href="#poly-2ff2d7db-9780-44eb-a469-eff624d14180"/>
							<gml:surfaceMember xlink:href="#poly-9fce71a6-f3a3-46f0-aa88-b85e80bd6396"/>
							<gml:surfaceMember xlink:href="#poly-8126042f-3a9a-4e36-a204-40e8453ef697"/>
							<gml:surfaceMember xlink:href="#poly-dcf813c5-5d5c-485d-a5ad-b2bbcbc3c5e2"/>
							<gml:surfaceMember xlink:href="#poly-5c3cc84e-9d79-451c-814a-1705eb538300"/>
							<gml:surfaceMember xlink:href="#poly-7f48ec63-bb13-4b27-9504-65e9905f1978"/>
							<gml:surfaceMember xlink:href="#poly-ebf24844-a204-45a1-aa98-4326a7c9f365"/>
							<gml:surfaceMember xlink:href="#poly-4209d15f-cf14-4cb9-8d29-65c92f437ebc"/>
							<gml:surfaceMember xlink:href="#poly-28f83fd9-3526-4b4a-90c2-33fdc8e07a4b"/>
							<gml:surfaceMember xlink:href="#poly-404279eb-201a-4c9c-8ae9-1998716ebba8"/>
							<gml:surfaceMember xlink:href="#poly-1a9c5cd9-a2ac-48cd-8106-b868714003bb"/>
							<gml:surfaceMember xlink:href="#poly-694ad3d4-d55b-4b54-ab3c-1f17abff3256"/>
							<gml:surfaceMember xlink:href="#poly-773349d1-5aa7-4469-8306-824db8680d35"/>
							<gml:surfaceMember xlink:href="#poly-fa8cedda-dd15-4c69-9908-d0790efc5579"/>
							<gml:surfaceMember xlink:href="#poly-679fedfc-20ea-494c-a73c-222e09f71da3"/>
							<gml:surfaceMember xlink:href="#poly-f4e6be11-61c2-4fe5-8246-05f503f66d95"/>
							<gml:surfaceMember xlink:href="#poly-c2d5e58f-4f36-495d-8179-6391e4ad0e22"/>
							<gml:surfaceMember xlink:href="#poly-f67a24c1-443c-4d9b-9301-05f0b02d8cac"/>
							<gml:surfaceMember xlink:href="#poly-b2e2b76f-5c48-4d15-91d0-c57e08307d9a"/>
							<gml:surfaceMember xlink:href="#poly-3fd69e9c-eb8a-40ca-a5cb-a1eef6a1c3e0"/>
							<gml:surfaceMember xlink:href="#poly-5f39aa0f-6158-4b81-8514-c00a8440a9a9"/>
							<gml:surfaceMember xlink:href="#poly-37d5dfdf-f43f-4686-8b40-fb9b0636b9ce"/>
							<gml:surfaceMember xlink:href="#poly-7c6b1eca-9bc0-4874-a151-53102b1c55bb"/>
							<gml:surfaceMember xlink:href="#poly-5f64852a-ed3e-4abd-a6ae-3ad667bf723a"/>
							<gml:surfaceMember xlink:href="#poly-cd182bcc-6ba5-4db6-ba10-39563f280ed2"/>
							<gml:surfaceMember xlink:href="#poly-09ef23a7-de0f-447d-a436-deb55044038f"/>
							<gml:surfaceMember xlink:href="#poly-c87a2d00-e0b7-4b95-8e03-136125db75d8"/>
							<gml:surfaceMember xlink:href="#poly-4d1cb66a-0b32-4c86-bf87-2693c8254de2"/>
							<gml:surfaceMember xlink:href="#poly-1216bb4a-d357-4237-bb89-5319203990e1"/>
							<gml:surfaceMember xlink:href="#poly-f78f07ab-e029-4de6-a513-5664f19fd1d4"/>
							<gml:surfaceMember xlink:href="#poly-97008a42-4203-4bdd-9a98-9427c9e73f44"/>
							<gml:surfaceMember xlink:href="#poly-9ec9640a-7af2-4ae6-ab3b-3745c0bb9a93"/>
							<gml:surfaceMember xlink:href="#poly-ce7a7807-ab52-49ec-8193-679ee614caaf"/>
							<gml:surfaceMember xlink:href="#poly-34f7f1cb-1e19-46c6-9dcb-3a8ae8446c36"/>
							<gml:surfaceMember xlink:href="#poly-0cd2ab60-04b7-4604-ada5-296152638974"/>
							<gml:surfaceMember xlink:href="#poly-a2bdd7c0-c4cb-4a2e-85c0-45d6546f43d4"/>
							<gml:surfaceMember xlink:href="#poly-d3be4f46-ec17-4e6c-bc0c-2d1ae7db050b"/>
							<gml:surfaceMember xlink:href="#poly-233d570f-6291-499f-963f-9931521bbbfd"/>
							<gml:surfaceMember xlink:href="#poly-3818213f-6005-4fb1-bbc5-db6675ae553c"/>
							<gml:surfaceMember xlink:href="#poly-e60ddaab-3da3-4c9f-944b-e9df62efda50"/>
							<gml:surfaceMember xlink:href="#poly-85d3c046-42c2-4d71-9a24-69a99d716591"/>
							<gml:surfaceMember xlink:href="#poly-c664cf74-2931-43a6-8a53-8af577143920"/>
							<gml:surfaceMember xlink:href="#poly-f85c57df-ba01-4dd1-9241-f2a3094b7d04"/>
							<gml:surfaceMember xlink:href="#poly-2653d969-eb0a-4c4a-a76e-0de73362a26e"/>
							<gml:surfaceMember xlink:href="#poly-76ae9907-8230-4405-a1cf-f7bec3ebf751"/>
							<gml:surfaceMember xlink:href="#poly-70a2dd4f-638a-4a76-82c2-cbe8a4d557a4"/>
							<gml:surfaceMember xlink:href="#poly-86f6f25d-dbfd-4707-aec1-2724b6491204"/>
							<gml:surfaceMember xlink:href="#poly-7f6804a0-c562-4081-ab86-eb2c87947be4"/>
							<gml:surfaceMember xlink:href="#poly-6af94a5f-bd77-4a0d-91cc-3d88ef91a722"/>
							<gml:surfaceMember xlink:href="#poly-71d59c53-f723-4985-b60a-6b77f48facdd"/>
							<gml:surfaceMember xlink:href="#poly-49186757-cf3b-4ec7-9c83-25baa24066c3"/>
							<gml:surfaceMember xlink:href="#poly-c271fc26-309e-4051-8b01-88032a9ae21c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_7c6d6f74-eb3d-42f6-be19-c28715ab2f40_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0db85ee-62cb-47a5-9ffa-5880f09d294c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667493356353134 139.73892141063223 39.848 35.66749829770058 139.73891223674855 39.848 35.66750668580145 139.7389190311232 39.848 35.6675017444535 139.73892820500743 39.848 35.667493356353134 139.73892141063223 39.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebe9f2fc-7be6-4ba2-8e7e-a2bba6db5353">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66757388795481 139.73891360579415 23.608 35.66757865786754 139.7389042111852 23.608 35.667587036651895 139.73891061897118 23.608 35.667582266730015 139.73892000253488 23.608 35.66757388795481 139.73891360579415 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe44e89e-6270-4834-a205-6ac72318c7a9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66757835631549 139.73894497081278 27.185 35.66758268523346 139.73893643830246 27.185 35.66759091970123 139.7389427247574 27.185 35.66758658176044 139.73895124623297 27.185 35.66757835631549 139.73894497081278 27.185</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0109da5-f210-4ad9-8c78-b0478c5756eb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66759510700153 139.73897201349044 23.608 35.66758873951065 139.7389671718446 23.608 35.66759289742045 139.738958959866 23.608 35.66759926491166 139.73896380151146 23.608 35.66759510700153 139.73897201349044 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a64e0b31-a143-45a7-90e5-ac5c63538799">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66759858233833 139.73893245411847 23.608 35.66759074471647 139.73892647648125 23.608 35.6675953256364 139.73891745765337 23.608 35.6676031632587 139.73892343529005 23.608 35.66759858233833 139.73893245411847 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e006646a-0568-4663-8ba4-1636c1d8ab63">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66761159555268 139.7389521115068 23.608 35.66761788221495 139.73895732880783 23.608 35.66761304869996 139.73896608283218 23.608 35.667606753024344 139.73896086554137 23.608 35.66761159555268 139.7389521115068 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e577abcf-4021-48bf-b0db-bad1be35c137">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6676170537066 139.73893529325508 23.608 35.66762458420323 139.73894043176978 23.608 35.66761969818284 139.73895119620764 23.608 35.66761216768666 139.73894605769226 23.608 35.6676170537066 139.73893529325508 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-860f6818-9894-487e-8354-6fc6accf6fe8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66762167324921 139.73897555004672 23.608 35.667627300990986 139.73897959726227 23.608 35.66762285548004 139.738988881032 23.608 35.66761722774721 139.73898484486185 23.608 35.66762167324921 139.73897555004672 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9cf7e25-0296-4dc0-9e43-3d36bc70d559">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9cf7e25-0296-4dc0-9e43-3d36bc70d559_0">
											<gml:posList>35.667587036651895 139.73891061897118 23.608 35.66757865786754 139.7389042111852 23.608 35.66757865786754 139.7389042111852 24.668 35.667587036651895 139.73891061897118 24.668 35.667587036651895 139.73891061897118 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c7c6917-9047-481d-a4c1-31dad3c6957c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c7c6917-9047-481d-a4c1-31dad3c6957c_0">
											<gml:posList>35.66757388795481 139.73891360579415 24.668 35.66757865786754 139.7389042111852 24.668 35.66757865786754 139.7389042111852 23.608 35.66757388795481 139.73891360579415 23.608 35.66757388795481 139.73891360579415 24.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da24f322-9b7c-4554-be8e-f9cdc1a87dd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da24f322-9b7c-4554-be8e-f9cdc1a87dd8_0">
											<gml:posList>35.66757388795481 139.73891360579415 24.668 35.667582266730015 139.73892000253488 24.668 35.667587036651895 139.73891061897118 24.668 35.66757865786754 139.7389042111852 24.668 35.66757388795481 139.73891360579415 24.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1702e79b-4ad7-4c3f-9d57-d23cbf2c416a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1702e79b-4ad7-4c3f-9d57-d23cbf2c416a_0">
											<gml:posList>35.667582266730015 139.73892000253488 23.608 35.667587036651895 139.73891061897118 23.608 35.667587036651895 139.73891061897118 24.668 35.667582266730015 139.73892000253488 24.668 35.667582266730015 139.73892000253488 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89a27de0-c185-4537-9882-1c0723ec258c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89a27de0-c185-4537-9882-1c0723ec258c_0">
											<gml:posList>35.66749829770058 139.73891223674855 39.848 35.66749829770058 139.73891223674855 41.621 35.66750668580145 139.7389190311232 41.621 35.66750668580145 139.7389190311232 39.848 35.66749829770058 139.73891223674855 39.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-986e0c4d-7dbe-49e7-beb6-84d551f27e7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-986e0c4d-7dbe-49e7-beb6-84d551f27e7e_0">
											<gml:posList>35.667493356353134 139.73892141063223 39.848 35.667493356353134 139.73892141063223 41.621 35.66749829770058 139.73891223674855 41.621 35.66749829770058 139.73891223674855 39.848 35.667493356353134 139.73892141063223 39.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f6ffa9e-74dc-4ad6-80cc-6684e968eaab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f6ffa9e-74dc-4ad6-80cc-6684e968eaab_0">
											<gml:posList>35.667582266730015 139.73892000253488 24.668 35.66757388795481 139.73891360579415 24.668 35.66757388795481 139.73891360579415 23.608 35.667582266730015 139.73892000253488 23.608 35.667582266730015 139.73892000253488 24.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79a7e903-0f42-4808-84f8-b5b57876417e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79a7e903-0f42-4808-84f8-b5b57876417e_0">
											<gml:posList>35.66750668580145 139.7389190311232 41.621 35.66749829770058 139.73891223674855 41.621 35.667493356353134 139.73892141063223 41.621 35.6675017444535 139.73892820500743 41.621 35.66750668580145 139.7389190311232 41.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d24fdb2-e0c0-442f-acdd-f5b796be1e56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d24fdb2-e0c0-442f-acdd-f5b796be1e56_0">
											<gml:posList>35.6675953256364 139.73891745765337 23.608 35.6675953256364 139.73891745765337 24.734 35.6676031632587 139.73892343529005 24.734 35.6676031632587 139.73892343529005 23.608 35.6675953256364 139.73891745765337 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f7f235b-b833-4574-8a72-441184f0a655">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f7f235b-b833-4574-8a72-441184f0a655_0">
											<gml:posList>35.66759074471647 139.73892647648125 23.608 35.66759074471647 139.73892647648125 24.734 35.6675953256364 139.73891745765337 24.734 35.6675953256364 139.73891745765337 23.608 35.66759074471647 139.73892647648125 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be977e28-7aaa-4c9a-93ea-c8f3ccc5fd95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be977e28-7aaa-4c9a-93ea-c8f3ccc5fd95_0">
											<gml:posList>35.6675017444535 139.73892820500743 39.848 35.66750668580145 139.7389190311232 39.848 35.66750668580145 139.7389190311232 41.621 35.6675017444535 139.73892820500743 41.621 35.6675017444535 139.73892820500743 39.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34586e69-7ce1-441a-b86b-87091706cf79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34586e69-7ce1-441a-b86b-87091706cf79_0">
											<gml:posList>35.6675017444535 139.73892820500743 39.848 35.6675017444535 139.73892820500743 41.621 35.667493356353134 139.73892141063223 41.621 35.667493356353134 139.73892141063223 39.848 35.6675017444535 139.73892820500743 39.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec7476b0-2582-4d94-8ade-07114dc168ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec7476b0-2582-4d94-8ade-07114dc168ef_0">
											<gml:posList>35.66759858233833 139.73893245411847 24.734 35.6676031632587 139.73892343529005 24.734 35.6675953256364 139.73891745765337 24.734 35.66759074471647 139.73892647648125 24.734 35.66759858233833 139.73893245411847 24.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ba6ae3a-aec8-43cf-bec2-91ee1fe77d47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ba6ae3a-aec8-43cf-bec2-91ee1fe77d47_0">
											<gml:posList>35.66759858233833 139.73893245411847 24.734 35.66759858233833 139.73893245411847 23.608 35.6676031632587 139.73892343529005 23.608 35.6676031632587 139.73892343529005 24.734 35.66759858233833 139.73893245411847 24.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-faa0de47-8d9c-4870-830d-c95a534267a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-faa0de47-8d9c-4870-830d-c95a534267a0_0">
											<gml:posList>35.66759074471647 139.73892647648125 24.734 35.66759074471647 139.73892647648125 23.608 35.66759858233833 139.73893245411847 23.608 35.66759858233833 139.73893245411847 24.734 35.66759074471647 139.73892647648125 24.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc234b69-c031-46c0-b78a-c17ba778d2ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc234b69-c031-46c0-b78a-c17ba778d2ff_0">
											<gml:posList>35.66762458420323 139.73894043176978 23.608 35.6676170537066 139.73893529325508 23.608 35.6676170537066 139.73893529325508 24.755 35.66762458420323 139.73894043176978 24.755 35.66762458420323 139.73894043176978 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fd3dfb7-d034-470a-aaee-13c490b1ccc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fd3dfb7-d034-470a-aaee-13c490b1ccc3_0">
											<gml:posList>35.66759091970123 139.7389427247574 27.185 35.66758268523346 139.73893643830246 27.185 35.66758268523346 139.73893643830246 28.102 35.66759091970123 139.7389427247574 28.102 35.66759091970123 139.7389427247574 27.185</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7003e82-59c3-4fde-9dc2-425d228ea02a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7003e82-59c3-4fde-9dc2-425d228ea02a_0">
											<gml:posList>35.66758268523346 139.73893643830246 27.185 35.66757835631549 139.73894497081278 27.185 35.66757835631549 139.73894497081278 28.102 35.66758268523346 139.73893643830246 28.102 35.66758268523346 139.73893643830246 27.185</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9b336b7-8ec9-4830-876d-e98655d24ddf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9b336b7-8ec9-4830-876d-e98655d24ddf_0">
											<gml:posList>35.6676170537066 139.73893529325508 23.608 35.66761216768666 139.73894605769226 23.608 35.66761216768666 139.73894605769226 24.755 35.6676170537066 139.73893529325508 24.755 35.6676170537066 139.73893529325508 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17bae7f4-95fb-4397-9d10-87e4acd77204">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17bae7f4-95fb-4397-9d10-87e4acd77204_0">
											<gml:posList>35.66761969818284 139.73895119620764 24.755 35.66762458420323 139.73894043176978 24.755 35.6676170537066 139.73893529325508 24.755 35.66761216768666 139.73894605769226 24.755 35.66761969818284 139.73895119620764 24.755</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fb90658-d5d3-4b41-9ff6-9d8dadfe2c54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fb90658-d5d3-4b41-9ff6-9d8dadfe2c54_0">
											<gml:posList>35.66757835631549 139.73894497081278 28.102 35.66758658176044 139.73895124623297 28.102 35.66759091970123 139.7389427247574 28.102 35.66758268523346 139.73893643830246 28.102 35.66757835631549 139.73894497081278 28.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74d01781-99b8-4cc7-beff-6a6093abc47d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74d01781-99b8-4cc7-beff-6a6093abc47d_0">
											<gml:posList>35.66761969818284 139.73895119620764 23.608 35.66762458420323 139.73894043176978 23.608 35.66762458420323 139.73894043176978 24.755 35.66761969818284 139.73895119620764 24.755 35.66761969818284 139.73895119620764 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c53f82c-f1f7-4993-b554-1f4f668ac58d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c53f82c-f1f7-4993-b554-1f4f668ac58d_0">
											<gml:posList>35.66758658176044 139.73895124623297 27.185 35.66759091970123 139.7389427247574 27.185 35.66759091970123 139.7389427247574 28.102 35.66758658176044 139.73895124623297 28.102 35.66758658176044 139.73895124623297 27.185</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9810aae1-aa26-4ccf-bf4f-24d9707d560d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9810aae1-aa26-4ccf-bf4f-24d9707d560d_0">
											<gml:posList>35.66758658176044 139.73895124623297 28.102 35.66757835631549 139.73894497081278 28.102 35.66757835631549 139.73894497081278 27.185 35.66758658176044 139.73895124623297 27.185 35.66758658176044 139.73895124623297 28.102</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ee66fa5-7525-4522-b6ef-0f421603ec20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ee66fa5-7525-4522-b6ef-0f421603ec20_0">
											<gml:posList>35.66761216768666 139.73894605769226 23.608 35.66761969818284 139.73895119620764 23.608 35.66761969818284 139.73895119620764 24.755 35.66761216768666 139.73894605769226 24.755 35.66761216768666 139.73894605769226 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0018189d-133f-48bc-99a6-6fc40049527b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0018189d-133f-48bc-99a6-6fc40049527b_0">
											<gml:posList>35.66761788221495 139.73895732880783 23.608 35.66761159555268 139.7389521115068 23.608 35.66761159555268 139.7389521115068 24.585 35.66761788221495 139.73895732880783 24.585 35.66761788221495 139.73895732880783 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ac5bb15-559c-498d-ad5c-058ce80b782c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ac5bb15-559c-498d-ad5c-058ce80b782c_0">
											<gml:posList>35.667606753024344 139.73896086554137 23.608 35.667606753024344 139.73896086554137 24.585 35.66761159555268 139.7389521115068 24.585 35.66761159555268 139.7389521115068 23.608 35.667606753024344 139.73896086554137 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41c6c91a-5368-427c-84ac-9b697e8da944">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41c6c91a-5368-427c-84ac-9b697e8da944_0">
											<gml:posList>35.66761304869996 139.73896608283218 24.585 35.66761788221495 139.73895732880783 24.585 35.66761159555268 139.7389521115068 24.585 35.667606753024344 139.73896086554137 24.585 35.66761304869996 139.73896608283218 24.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-627c3042-b169-40cd-8bee-b2b8abd80b51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-627c3042-b169-40cd-8bee-b2b8abd80b51_0">
											<gml:posList>35.66759926491166 139.73896380151146 23.608 35.66759289742045 139.738958959866 23.608 35.66759289742045 139.738958959866 24.649 35.66759926491166 139.73896380151146 24.649 35.66759926491166 139.73896380151146 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca31a527-8b83-4107-b83c-5f167bbed2b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca31a527-8b83-4107-b83c-5f167bbed2b3_0">
											<gml:posList>35.66761304869996 139.73896608283218 23.608 35.66761788221495 139.73895732880783 23.608 35.66761788221495 139.73895732880783 24.585 35.66761304869996 139.73896608283218 24.585 35.66761304869996 139.73896608283218 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-781c500a-7c8b-4eca-86f6-bd8363a2ab22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-781c500a-7c8b-4eca-86f6-bd8363a2ab22_0">
											<gml:posList>35.66759289742045 139.738958959866 23.608 35.66758873951065 139.7389671718446 23.608 35.66758873951065 139.7389671718446 24.649 35.66759289742045 139.738958959866 24.649 35.66759289742045 139.738958959866 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aac8bf57-23f0-42d0-b9c1-304f5bfcfea0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aac8bf57-23f0-42d0-b9c1-304f5bfcfea0_0">
											<gml:posList>35.66761304869996 139.73896608283218 23.608 35.66761304869996 139.73896608283218 24.585 35.667606753024344 139.73896086554137 24.585 35.667606753024344 139.73896086554137 23.608 35.66761304869996 139.73896608283218 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58663e4b-7a58-4486-ba87-4f016f7ddfec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58663e4b-7a58-4486-ba87-4f016f7ddfec_0">
											<gml:posList>35.66759289742045 139.738958959866 24.649 35.66758873951065 139.7389671718446 24.649 35.66759510700153 139.73897201349044 24.649 35.66759926491166 139.73896380151146 24.649 35.66759289742045 139.738958959866 24.649</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b24029d-46db-4b06-8fbe-65448133b990">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b24029d-46db-4b06-8fbe-65448133b990_0">
											<gml:posList>35.66759510700153 139.73897201349044 23.608 35.66759926491166 139.73896380151146 23.608 35.66759926491166 139.73896380151146 24.649 35.66759510700153 139.73897201349044 24.649 35.66759510700153 139.73897201349044 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8fa702c-47aa-4c4d-b380-27c207642a35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8fa702c-47aa-4c4d-b380-27c207642a35_0">
											<gml:posList>35.66758873951065 139.7389671718446 23.608 35.66759510700153 139.73897201349044 23.608 35.66759510700153 139.73897201349044 24.649 35.66758873951065 139.7389671718446 24.649 35.66758873951065 139.7389671718446 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9b4f875-0287-4d99-b17a-01a563c8c116">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9b4f875-0287-4d99-b17a-01a563c8c116_0">
											<gml:posList>35.667627300990986 139.73897959726227 23.608 35.66762167324921 139.73897555004672 23.608 35.66762167324921 139.73897555004672 24.72 35.667627300990986 139.73897959726227 24.72 35.667627300990986 139.73897959726227 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47614425-a464-4964-be44-9e81c14327e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47614425-a464-4964-be44-9e81c14327e8_0">
											<gml:posList>35.66761722774721 139.73898484486185 23.608 35.66761722774721 139.73898484486185 24.72 35.66762167324921 139.73897555004672 24.72 35.66762167324921 139.73897555004672 23.608 35.66761722774721 139.73898484486185 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92f9c33c-4ad9-42db-8e76-8cc8f0cb90f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92f9c33c-4ad9-42db-8e76-8cc8f0cb90f1_0">
											<gml:posList>35.66762167324921 139.73897555004672 24.72 35.66761722774721 139.73898484486185 24.72 35.66762285548004 139.738988881032 24.72 35.667627300990986 139.73897959726227 24.72 35.66762167324921 139.73897555004672 24.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1c57d49-e4fb-4670-9a12-279dbd00150f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1c57d49-e4fb-4670-9a12-279dbd00150f_0">
											<gml:posList>35.66762285548004 139.738988881032 23.608 35.667627300990986 139.73897959726227 23.608 35.667627300990986 139.73897959726227 24.72 35.66762285548004 139.738988881032 24.72 35.66762285548004 139.738988881032 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01840be1-2989-4181-9790-a3d69eabbc82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01840be1-2989-4181-9790-a3d69eabbc82_0">
											<gml:posList>35.66761722774721 139.73898484486185 23.608 35.66762285548004 139.738988881032 23.608 35.66762285548004 139.738988881032 24.72 35.66761722774721 139.73898484486185 24.72 35.66761722774721 139.73898484486185 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7dfe5dae-b9ad-4188-aef7-682e59186b0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dfe5dae-b9ad-4188-aef7-682e59186b0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dfe5dae-b9ad-4188-aef7-682e59186b0a">
											<gml:posList>35.66767552969822 139.73889427731262 11.63 35.667695100632706 139.73890847032246 11.63 35.66764349962742 139.73901533372242 11.63 35.66762392871397 139.73900115174146 11.63 35.6676209319973 139.7390073520051 11.63 35.6675271361825 139.7389397511809 11.63 35.667446047258366 139.7390991278675 11.63 35.667371278673386 139.73904199825878 11.63 35.66751131649185 139.73876668111382 11.63 35.66758608520547 139.73882381056498 11.63 35.66758419518375 139.73882745793108 11.63 35.66767573667607 139.73889384627927 11.63 35.66767552969822 139.73889427731262 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-15fb09cb-4c1d-4cfb-93e6-4fa54c2fb1a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15fb09cb-4c1d-4cfb-93e6-4fa54c2fb1a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15fb09cb-4c1d-4cfb-93e6-4fa54c2fb1a2">
											<gml:posList>35.66751131649185 139.73876668111382 36.463 35.667512140141326 139.73877101012118 36.463 35.66758253456881 139.73882479783265 36.463 35.66758608520547 139.73882381056498 36.463 35.66751131649185 139.73876668111382 36.463</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-afd1b4c4-2dbe-4e99-a44a-4a42e56aef75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afd1b4c4-2dbe-4e99-a44a-4a42e56aef75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afd1b4c4-2dbe-4e99-a44a-4a42e56aef75">
											<gml:posList>35.667584765337104 139.7388303733699 24.183 35.66758419518375 139.73882745793108 24.183 35.667548978806785 139.73889675703674 24.183 35.66755046696391 139.73889789300864 24.183 35.667584765337104 139.7388303733699 24.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa959d1e-255b-4e9d-bc07-5e881f1a1aad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa959d1e-255b-4e9d-bc07-5e881f1a1aad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa959d1e-255b-4e9d-bc07-5e881f1a1aad">
											<gml:posList>35.66747230726682 139.73887286677495 40.416 35.66747269668532 139.73887519699244 40.416 35.66751983238554 139.73891334911502 40.416 35.667521733900756 139.73891286085788 40.416 35.66747230726682 139.73887286677495 40.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9807fe44-7f97-437f-84c8-692489db5dd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9807fe44-7f97-437f-84c8-692489db5dd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9807fe44-7f97-437f-84c8-692489db5dd5">
											<gml:posList>35.66744182211657 139.73892944641605 40.416 35.667443714626806 139.7389289692162 40.416 35.66747269668532 139.73887519699244 40.416 35.66747230726682 139.73887286677495 40.416 35.66744182211657 139.73892944641605 40.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-826c9a97-e51a-4b43-8cf5-9092eb611588">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-826c9a97-e51a-4b43-8cf5-9092eb611588">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-826c9a97-e51a-4b43-8cf5-9092eb611588">
											<gml:posList>35.66751131649185 139.73876668111382 36.463 35.667371278673386 139.73904199825878 36.463 35.667374721052106 139.73904088962635 36.463 35.667512140141326 139.73877101012118 36.463 35.66751131649185 139.73876668111382 36.463</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc0f6377-da38-4c13-8fee-00264cf035ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc0f6377-da38-4c13-8fee-00264cf035ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc0f6377-da38-4c13-8fee-00264cf035ef">
											<gml:posList>35.66747269668532 139.73887519699244 39.175 35.667443714626806 139.7389289692162 39.175 35.66746728246574 139.73894803975793 39.175 35.667496264532645 139.73889426752518 39.175 35.66747269668532 139.73887519699244 39.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5367542c-f81c-4f25-bbd6-5f9336a2a664">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5367542c-f81c-4f25-bbd6-5f9336a2a664">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5367542c-f81c-4f25-bbd6-5f9336a2a664">
											<gml:posList>35.66756487615338 139.73893906609348 29.269 35.66757338101437 139.73892233263044 29.269 35.66754643185491 139.73890177486078 29.269 35.6675379360018 139.73891849726388 29.269 35.66756487615338 139.73893906609348 29.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ce40d12-099f-4923-a843-de4d792f4672">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ce40d12-099f-4923-a843-de4d792f4672">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ce40d12-099f-4923-a843-de4d792f4672">
											<gml:posList>35.667490841296505 139.7389671213673 39.848 35.66751983238554 139.73891334911502 39.848 35.667496264532645 139.73889426752518 39.848 35.66746728246574 139.73894803975793 39.848 35.667490841296505 139.7389671213673 39.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b3258ff-6872-4292-844f-68d92424d059">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b3258ff-6872-4292-844f-68d92424d059">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b3258ff-6872-4292-844f-68d92424d059">
											<gml:posList>35.66756487615338 139.73893906609348 27.185 35.6675379360018 139.73891849726388 27.185 35.6675335350705 139.73892715135972 27.185 35.66758405122158 139.7389657082607 27.185 35.66759949495879 139.7389353028801 27.185 35.667548978806785 139.73889675703674 27.185 35.66754643185491 139.73890177486078 27.185 35.66757338101437 139.73892233263044 27.185 35.66756487615338 139.73893906609348 27.185</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b7204bb-80da-477a-8a74-0ca91a400894">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b7204bb-80da-477a-8a74-0ca91a400894">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b7204bb-80da-477a-8a74-0ca91a400894">
											<gml:posList>35.667512140141326 139.73877101012118 34.887 35.667374721052106 139.73904088962635 34.887 35.667382051946 139.73903286172145 34.887 35.66749531599097 139.73882265831995 34.887 35.66755080372176 139.7388675606544 34.887 35.667437539590935 139.73907775309246 34.887 35.667445458038095 139.73909487590578 34.887 35.66758202155797 139.73882578152006 34.887 35.66758253456881 139.73882479783265 34.887 35.667512140141326 139.73877101012118 34.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d2e64e89-865e-4761-bb16-d2bcef7982c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2e64e89-865e-4761-bb16-d2bcef7982c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2e64e89-865e-4761-bb16-d2bcef7982c5">
											<gml:posList>35.66752956029481 139.73893900825422 24.183 35.667535023227344 139.73892828733196 24.183 35.6675335350705 139.73892715135972 24.183 35.6675271361825 139.7389397511809 24.183 35.66752956029481 139.73893900825422 24.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0658ff5f-8b99-4c66-8b87-644d36f8246d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0658ff5f-8b99-4c66-8b87-644d36f8246d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0658ff5f-8b99-4c66-8b87-644d36f8246d">
											<gml:posList>35.667521733900756 139.73891286085788 40.416 35.66751983238554 139.73891334911502 40.416 35.667490841296505 139.7389671213673 40.416 35.66749123971827 139.7389694405293 40.416 35.667521733900756 139.73891286085788 40.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5deebed5-374f-4d53-9b5e-7dc44b2b8133">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5deebed5-374f-4d53-9b5e-7dc44b2b8133">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5deebed5-374f-4d53-9b5e-7dc44b2b8133">
											<gml:posList>35.66749123971827 139.7389694405293 40.416 35.667490841296505 139.7389671213673 40.416 35.667443714626806 139.7389289692162 40.416 35.66744182211657 139.73892944641605 40.416 35.66749123971827 139.7389694405293 40.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5bf3286f-7299-44ec-9f86-55735623b960">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bf3286f-7299-44ec-9f86-55735623b960">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bf3286f-7299-44ec-9f86-55735623b960">
											<gml:posList>35.66749531599097 139.73882265831995 38.843 35.667382051946 139.73903286172145 38.843 35.66744182211657 139.73892944641605 38.843 35.66747230726682 139.73887286677495 38.843 35.667521733900756 139.73891286085788 38.843 35.66749123971827 139.7389694405293 38.843 35.667437539590935 139.73907775309246 38.843 35.66755080372176 139.7388675606544 38.843 35.66749531599097 139.73882265831995 38.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ae8f3506-f0db-4b64-8e5d-708f06f37bfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae8f3506-f0db-4b64-8e5d-708f06f37bfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae8f3506-f0db-4b64-8e5d-708f06f37bfc">
											<gml:posList>35.66758419518375 139.73882745793108 36.463 35.66758202155797 139.73882578152006 36.463 35.667445458038095 139.73909487590578 36.463 35.667446047258366 139.7390991278675 36.463 35.66758419518375 139.73882745793108 36.463</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e91b2e9-51b7-44e8-bf35-10c49ed7a35d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e91b2e9-51b7-44e8-bf35-10c49ed7a35d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e91b2e9-51b7-44e8-bf35-10c49ed7a35d">
											<gml:posList>35.66744182211657 139.73892944641605 38.843 35.667382051946 139.73903286172145 38.843 35.667437539590935 139.73907775309246 38.843 35.66749123971827 139.7389694405293 38.843 35.66744182211657 139.73892944641605 38.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fd2ec136-dcb2-4dae-b906-fc31b349bf3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd2ec136-dcb2-4dae-b906-fc31b349bf3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd2ec136-dcb2-4dae-b906-fc31b349bf3c">
											<gml:posList>35.667382051946 139.73903286172145 34.887 35.667374721052106 139.73904088962635 34.887 35.667445458038095 139.73909487590578 34.887 35.667382051946 139.73903286172145 34.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-27d46daf-078c-4bb5-8ce5-a9f86ea81bca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27d46daf-078c-4bb5-8ce5-a9f86ea81bca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27d46daf-078c-4bb5-8ce5-a9f86ea81bca">
											<gml:posList>35.667382051946 139.73903286172145 34.887 35.667445458038095 139.73909487590578 34.887 35.667437539590935 139.73907775309246 34.887 35.667382051946 139.73903286172145 34.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fbd04340-fb9a-41c0-ab2b-fedc208eaa86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbd04340-fb9a-41c0-ab2b-fedc208eaa86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbd04340-fb9a-41c0-ab2b-fedc208eaa86">
											<gml:posList>35.667446047258366 139.7390991278675 36.463 35.667445458038095 139.73909487590578 36.463 35.667374721052106 139.73904088962635 36.463 35.667371278673386 139.73904199825878 36.463 35.667446047258366 139.7390991278675 36.463</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03b3be35-f055-4279-a88a-e3e1bf7df512">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03b3be35-f055-4279-a88a-e3e1bf7df512">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03b3be35-f055-4279-a88a-e3e1bf7df512">
											<gml:posList>35.66758419518375 139.73882745793108 36.463 35.66758608520547 139.73882381056498 36.463 35.66758253456881 139.73882479783265 36.463 35.66758202155797 139.73882578152006 36.463 35.66758419518375 139.73882745793108 36.463</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c8fd7c2-8036-41b8-88a2-fda788fe9a56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c8fd7c2-8036-41b8-88a2-fda788fe9a56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c8fd7c2-8036-41b8-88a2-fda788fe9a56">
											<gml:posList>35.66758419518375 139.73882745793108 24.183 35.667584765337104 139.7388303733699 24.183 35.66767333060021 139.73889460023332 24.183 35.66767573667607 139.73889384627927 24.183 35.66758419518375 139.73882745793108 24.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c03ebe5-4bf1-46d5-8376-5630b363d8da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c03ebe5-4bf1-46d5-8376-5630b363d8da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c03ebe5-4bf1-46d5-8376-5630b363d8da">
											<gml:posList>35.667584765337104 139.7388303733699 23.608 35.66755046696391 139.73889789300864 23.608 35.66759949495879 139.7389353028801 23.608 35.66758405122158 139.7389657082607 23.608 35.667535023227344 139.73892828733196 23.608 35.66752956029481 139.73893900825422 23.608 35.667620307748564 139.73900441453557 23.608 35.66767333060021 139.73889460023332 23.608 35.667584765337104 139.7388303733699 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8655c9fa-59ab-44ec-a2d1-df08e981c0a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8655c9fa-59ab-44ec-a2d1-df08e981c0a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8655c9fa-59ab-44ec-a2d1-df08e981c0a7">
											<gml:posList>35.66767573667607 139.73889384627927 24.183 35.66767333060021 139.73889460023332 24.183 35.667620307748564 139.73900441453557 24.183 35.6676209319973 139.7390073520051 24.183 35.66767573667607 139.73889384627927 24.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ceed687b-7352-41a9-8e9c-f519fa0c3b37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ceed687b-7352-41a9-8e9c-f519fa0c3b37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ceed687b-7352-41a9-8e9c-f519fa0c3b37">
											<gml:posList>35.66764349962742 139.73901533372242 17.328 35.667695100632706 139.73890847032246 17.328 35.66767552969822 139.73889427731262 17.328 35.66762392871397 139.73900115174146 17.328 35.66764349962742 139.73901533372242 17.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d275bf1d-18b9-42f6-954d-8d1329232088">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d275bf1d-18b9-42f6-954d-8d1329232088">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d275bf1d-18b9-42f6-954d-8d1329232088">
											<gml:posList>35.6676209319973 139.7390073520051 24.183 35.667620307748564 139.73900441453557 24.183 35.66752956029481 139.73893900825422 24.183 35.6675271361825 139.7389397511809 24.183 35.6676209319973 139.7390073520051 24.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ff2d7db-9780-44eb-a469-eff624d14180">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ff2d7db-9780-44eb-a469-eff624d14180">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ff2d7db-9780-44eb-a469-eff624d14180">
											<gml:posList>35.667374721052106 139.73904088962635 36.463 35.667374721052106 139.73904088962635 34.887 35.667512140141326 139.73877101012118 34.887 35.667512140141326 139.73877101012118 36.463 35.667374721052106 139.73904088962635 36.463</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9fce71a6-f3a3-46f0-aa88-b85e80bd6396">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fce71a6-f3a3-46f0-aa88-b85e80bd6396">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fce71a6-f3a3-46f0-aa88-b85e80bd6396">
											<gml:posList>35.667496264532645 139.73889426752518 39.848 35.667496264532645 139.73889426752518 39.175 35.66746728246574 139.73894803975793 39.175 35.66746728246574 139.73894803975793 39.848 35.667496264532645 139.73889426752518 39.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8126042f-3a9a-4e36-a204-40e8453ef697">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8126042f-3a9a-4e36-a204-40e8453ef697">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8126042f-3a9a-4e36-a204-40e8453ef697">
											<gml:posList>35.66758202155797 139.73882578152006 36.463 35.66758202155797 139.73882578152006 34.887 35.667445458038095 139.73909487590578 34.887 35.667445458038095 139.73909487590578 36.463 35.66758202155797 139.73882578152006 36.463</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dcf813c5-5d5c-485d-a5ad-b2bbcbc3c5e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcf813c5-5d5c-485d-a5ad-b2bbcbc3c5e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcf813c5-5d5c-485d-a5ad-b2bbcbc3c5e2">
											<gml:posList>35.66764349962742 139.73901533372242 11.63 35.667695100632706 139.73890847032246 11.63 35.667695100632706 139.73890847032246 17.328 35.66764349962742 139.73901533372242 17.328 35.66764349962742 139.73901533372242 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c3cc84e-9d79-451c-814a-1705eb538300">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c3cc84e-9d79-451c-814a-1705eb538300">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c3cc84e-9d79-451c-814a-1705eb538300">
											<gml:posList>35.66758608520547 139.73882381056498 11.63 35.66751131649185 139.73876668111382 11.63 35.66751131649185 139.73876668111382 36.463 35.66758608520547 139.73882381056498 36.463 35.66758608520547 139.73882381056498 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f48ec63-bb13-4b27-9504-65e9905f1978">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f48ec63-bb13-4b27-9504-65e9905f1978">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f48ec63-bb13-4b27-9504-65e9905f1978">
											<gml:posList>35.667512140141326 139.73877101012118 36.463 35.667512140141326 139.73877101012118 34.887 35.66758253456881 139.73882479783265 34.887 35.66758253456881 139.73882479783265 36.463 35.667512140141326 139.73877101012118 36.463</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebf24844-a204-45a1-aa98-4326a7c9f365">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebf24844-a204-45a1-aa98-4326a7c9f365">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebf24844-a204-45a1-aa98-4326a7c9f365">
											<gml:posList>35.66758253456881 139.73882479783265 36.463 35.66758253456881 139.73882479783265 34.887 35.66758202155797 139.73882578152006 34.887 35.66758202155797 139.73882578152006 36.463 35.66758253456881 139.73882479783265 36.463</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4209d15f-cf14-4cb9-8d29-65c92f437ebc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4209d15f-cf14-4cb9-8d29-65c92f437ebc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4209d15f-cf14-4cb9-8d29-65c92f437ebc">
											<gml:posList>35.66758608520547 139.73882381056498 36.463 35.66758419518375 139.73882745793108 36.463 35.66758419518375 139.73882745793108 24.183 35.66758419518375 139.73882745793108 11.63 35.66758608520547 139.73882381056498 11.63 35.66758608520547 139.73882381056498 36.463</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28f83fd9-3526-4b4a-90c2-33fdc8e07a4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28f83fd9-3526-4b4a-90c2-33fdc8e07a4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28f83fd9-3526-4b4a-90c2-33fdc8e07a4b">
											<gml:posList>35.66749531599097 139.73882265831995 38.843 35.66755080372176 139.7388675606544 38.843 35.66755080372176 139.7388675606544 34.887 35.66749531599097 139.73882265831995 34.887 35.66749531599097 139.73882265831995 38.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-404279eb-201a-4c9c-8ae9-1998716ebba8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-404279eb-201a-4c9c-8ae9-1998716ebba8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-404279eb-201a-4c9c-8ae9-1998716ebba8">
											<gml:posList>35.66767573667607 139.73889384627927 11.63 35.66758419518375 139.73882745793108 11.63 35.66758419518375 139.73882745793108 24.183 35.66767573667607 139.73889384627927 24.183 35.66767573667607 139.73889384627927 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a9c5cd9-a2ac-48cd-8106-b868714003bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a9c5cd9-a2ac-48cd-8106-b868714003bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a9c5cd9-a2ac-48cd-8106-b868714003bb">
											<gml:posList>35.667548978806785 139.73889675703674 27.185 35.667548978806785 139.73889675703674 24.183 35.66758419518375 139.73882745793108 24.183 35.667548978806785 139.73889675703674 27.185</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-694ad3d4-d55b-4b54-ab3c-1f17abff3256">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-694ad3d4-d55b-4b54-ab3c-1f17abff3256">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-694ad3d4-d55b-4b54-ab3c-1f17abff3256">
											<gml:posList>35.667584765337104 139.7388303733699 24.183 35.667584765337104 139.7388303733699 23.608 35.66767333060021 139.73889460023332 23.608 35.66767333060021 139.73889460023332 24.183 35.667584765337104 139.7388303733699 24.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-773349d1-5aa7-4469-8306-824db8680d35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-773349d1-5aa7-4469-8306-824db8680d35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-773349d1-5aa7-4469-8306-824db8680d35">
											<gml:posList>35.66755046696391 139.73889789300864 24.183 35.66755046696391 139.73889789300864 23.608 35.667584765337104 139.7388303733699 23.608 35.667584765337104 139.7388303733699 24.183 35.66755046696391 139.73889789300864 24.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa8cedda-dd15-4c69-9908-d0790efc5579">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa8cedda-dd15-4c69-9908-d0790efc5579">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa8cedda-dd15-4c69-9908-d0790efc5579">
											<gml:posList>35.66754643185491 139.73890177486078 29.269 35.667548978806785 139.73889675703674 27.185 35.66758419518375 139.73882745793108 24.183 35.66754643185491 139.73890177486078 29.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-679fedfc-20ea-494c-a73c-222e09f71da3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-679fedfc-20ea-494c-a73c-222e09f71da3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-679fedfc-20ea-494c-a73c-222e09f71da3">
											<gml:posList>35.66754643185491 139.73890177486078 29.269 35.66758419518375 139.73882745793108 24.183 35.66758419518375 139.73882745793108 36.463 35.66754643185491 139.73890177486078 29.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4e6be11-61c2-4fe5-8246-05f503f66d95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4e6be11-61c2-4fe5-8246-05f503f66d95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4e6be11-61c2-4fe5-8246-05f503f66d95">
											<gml:posList>35.6675379360018 139.73891849726388 29.269 35.66754643185491 139.73890177486078 29.269 35.66758419518375 139.73882745793108 36.463 35.6675379360018 139.73891849726388 29.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2d5e58f-4f36-495d-8179-6391e4ad0e22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2d5e58f-4f36-495d-8179-6391e4ad0e22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2d5e58f-4f36-495d-8179-6391e4ad0e22">
											<gml:posList>35.66747230726682 139.73887286677495 38.843 35.66747230726682 139.73887286677495 40.416 35.667521733900756 139.73891286085788 40.416 35.667521733900756 139.73891286085788 38.843 35.66747230726682 139.73887286677495 38.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f67a24c1-443c-4d9b-9301-05f0b02d8cac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f67a24c1-443c-4d9b-9301-05f0b02d8cac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f67a24c1-443c-4d9b-9301-05f0b02d8cac">
											<gml:posList>35.66747269668532 139.73887519699244 40.416 35.66747269668532 139.73887519699244 39.175 35.667496264532645 139.73889426752518 39.175 35.667496264532645 139.73889426752518 39.848 35.66751983238554 139.73891334911502 39.848 35.66751983238554 139.73891334911502 40.416 35.66747269668532 139.73887519699244 40.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2e2b76f-5c48-4d15-91d0-c57e08307d9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2e2b76f-5c48-4d15-91d0-c57e08307d9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2e2b76f-5c48-4d15-91d0-c57e08307d9a">
											<gml:posList>35.66754643185491 139.73890177486078 29.269 35.66754643185491 139.73890177486078 27.185 35.667548978806785 139.73889675703674 27.185 35.66754643185491 139.73890177486078 29.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fd69e9c-eb8a-40ca-a5cb-a1eef6a1c3e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fd69e9c-eb8a-40ca-a5cb-a1eef6a1c3e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fd69e9c-eb8a-40ca-a5cb-a1eef6a1c3e0">
											<gml:posList>35.66744182211657 139.73892944641605 38.843 35.66744182211657 139.73892944641605 40.416 35.66747230726682 139.73887286677495 40.416 35.66747230726682 139.73887286677495 38.843 35.66744182211657 139.73892944641605 38.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f39aa0f-6158-4b81-8514-c00a8440a9a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f39aa0f-6158-4b81-8514-c00a8440a9a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f39aa0f-6158-4b81-8514-c00a8440a9a9">
											<gml:posList>35.667695100632706 139.73890847032246 11.63 35.66767552969822 139.73889427731262 11.63 35.66767552969822 139.73889427731262 17.328 35.667695100632706 139.73890847032246 17.328 35.667695100632706 139.73890847032246 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37d5dfdf-f43f-4686-8b40-fb9b0636b9ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37d5dfdf-f43f-4686-8b40-fb9b0636b9ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37d5dfdf-f43f-4686-8b40-fb9b0636b9ce">
											<gml:posList>35.667443714626806 139.7389289692162 39.175 35.66747269668532 139.73887519699244 39.175 35.66747269668532 139.73887519699244 40.416 35.667443714626806 139.7389289692162 40.416 35.667443714626806 139.7389289692162 39.175</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c6b1eca-9bc0-4874-a151-53102b1c55bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c6b1eca-9bc0-4874-a151-53102b1c55bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c6b1eca-9bc0-4874-a151-53102b1c55bb">
											<gml:posList>35.66751131649185 139.73876668111382 11.63 35.667371278673386 139.73904199825878 11.63 35.667371278673386 139.73904199825878 36.463 35.66751131649185 139.73876668111382 36.463 35.66751131649185 139.73876668111382 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f64852a-ed3e-4abd-a6ae-3ad667bf723a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f64852a-ed3e-4abd-a6ae-3ad667bf723a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f64852a-ed3e-4abd-a6ae-3ad667bf723a">
											<gml:posList>35.66754643185491 139.73890177486078 27.185 35.66754643185491 139.73890177486078 29.269 35.66757338101437 139.73892233263044 29.269 35.66757338101437 139.73892233263044 27.185 35.66754643185491 139.73890177486078 27.185</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd182bcc-6ba5-4db6-ba10-39563f280ed2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd182bcc-6ba5-4db6-ba10-39563f280ed2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd182bcc-6ba5-4db6-ba10-39563f280ed2">
											<gml:posList>35.66755046696391 139.73889789300864 24.183 35.667548978806785 139.73889675703674 24.183 35.667548978806785 139.73889675703674 27.185 35.66759949495879 139.7389353028801 27.185 35.66759949495879 139.7389353028801 23.608 35.66755046696391 139.73889789300864 23.608 35.66755046696391 139.73889789300864 24.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09ef23a7-de0f-447d-a436-deb55044038f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09ef23a7-de0f-447d-a436-deb55044038f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09ef23a7-de0f-447d-a436-deb55044038f">
											<gml:posList>35.6675335350705 139.73892715135972 27.185 35.6675379360018 139.73891849726388 27.185 35.6675379360018 139.73891849726388 29.269 35.6675335350705 139.73892715135972 27.185</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c87a2d00-e0b7-4b95-8e03-136125db75d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c87a2d00-e0b7-4b95-8e03-136125db75d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c87a2d00-e0b7-4b95-8e03-136125db75d8">
											<gml:posList>35.667382051946 139.73903286172145 38.843 35.66749531599097 139.73882265831995 38.843 35.66749531599097 139.73882265831995 34.887 35.667382051946 139.73903286172145 34.887 35.667382051946 139.73903286172145 38.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d1cb66a-0b32-4c86-bf87-2693c8254de2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d1cb66a-0b32-4c86-bf87-2693c8254de2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d1cb66a-0b32-4c86-bf87-2693c8254de2">
											<gml:posList>35.66756487615338 139.73893906609348 27.185 35.66756487615338 139.73893906609348 29.269 35.6675379360018 139.73891849726388 29.269 35.6675379360018 139.73891849726388 27.185 35.66756487615338 139.73893906609348 27.185</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1216bb4a-d357-4237-bb89-5319203990e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1216bb4a-d357-4237-bb89-5319203990e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1216bb4a-d357-4237-bb89-5319203990e1">
											<gml:posList>35.66757338101437 139.73892233263044 27.185 35.66757338101437 139.73892233263044 29.269 35.66756487615338 139.73893906609348 29.269 35.66756487615338 139.73893906609348 27.185 35.66757338101437 139.73892233263044 27.185</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f78f07ab-e029-4de6-a513-5664f19fd1d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f78f07ab-e029-4de6-a513-5664f19fd1d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f78f07ab-e029-4de6-a513-5664f19fd1d4">
											<gml:posList>35.6675335350705 139.73892715135972 27.185 35.6675271361825 139.7389397511809 24.183 35.6675335350705 139.73892715135972 24.183 35.6675335350705 139.73892715135972 27.185</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97008a42-4203-4bdd-9a98-9427c9e73f44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97008a42-4203-4bdd-9a98-9427c9e73f44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97008a42-4203-4bdd-9a98-9427c9e73f44">
											<gml:posList>35.66752956029481 139.73893900825422 24.183 35.66752956029481 139.73893900825422 23.608 35.667535023227344 139.73892828733196 23.608 35.667535023227344 139.73892828733196 24.183 35.66752956029481 139.73893900825422 24.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ec9640a-7af2-4ae6-ab3b-3745c0bb9a93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ec9640a-7af2-4ae6-ab3b-3745c0bb9a93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ec9640a-7af2-4ae6-ab3b-3745c0bb9a93">
											<gml:posList>35.66751983238554 139.73891334911502 40.416 35.66751983238554 139.73891334911502 39.848 35.667490841296505 139.7389671213673 39.848 35.667490841296505 139.7389671213673 40.416 35.66751983238554 139.73891334911502 40.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce7a7807-ab52-49ec-8193-679ee614caaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce7a7807-ab52-49ec-8193-679ee614caaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce7a7807-ab52-49ec-8193-679ee614caaf">
											<gml:posList>35.667521733900756 139.73891286085788 38.843 35.667521733900756 139.73891286085788 40.416 35.66749123971827 139.7389694405293 40.416 35.66749123971827 139.7389694405293 38.843 35.667521733900756 139.73891286085788 38.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34f7f1cb-1e19-46c6-9dcb-3a8ae8446c36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34f7f1cb-1e19-46c6-9dcb-3a8ae8446c36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34f7f1cb-1e19-46c6-9dcb-3a8ae8446c36">
											<gml:posList>35.6675335350705 139.73892715135972 27.185 35.6675335350705 139.73892715135972 24.183 35.667535023227344 139.73892828733196 24.183 35.667535023227344 139.73892828733196 23.608 35.66758405122158 139.7389657082607 23.608 35.66758405122158 139.7389657082607 27.185 35.6675335350705 139.73892715135972 27.185</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0cd2ab60-04b7-4604-ada5-296152638974">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cd2ab60-04b7-4604-ada5-296152638974">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cd2ab60-04b7-4604-ada5-296152638974">
											<gml:posList>35.667443714626806 139.7389289692162 40.416 35.667490841296505 139.7389671213673 40.416 35.667490841296505 139.7389671213673 39.848 35.66746728246574 139.73894803975793 39.848 35.66746728246574 139.73894803975793 39.175 35.667443714626806 139.7389289692162 39.175 35.667443714626806 139.7389289692162 40.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2bdd7c0-c4cb-4a2e-85c0-45d6546f43d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2bdd7c0-c4cb-4a2e-85c0-45d6546f43d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2bdd7c0-c4cb-4a2e-85c0-45d6546f43d4">
											<gml:posList>35.66749123971827 139.7389694405293 38.843 35.66749123971827 139.7389694405293 40.416 35.66744182211657 139.73892944641605 40.416 35.66744182211657 139.73892944641605 38.843 35.66749123971827 139.7389694405293 38.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3be4f46-ec17-4e6c-bc0c-2d1ae7db050b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3be4f46-ec17-4e6c-bc0c-2d1ae7db050b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3be4f46-ec17-4e6c-bc0c-2d1ae7db050b">
											<gml:posList>35.66767333060021 139.73889460023332 24.183 35.66767333060021 139.73889460023332 23.608 35.667620307748564 139.73900441453557 23.608 35.667620307748564 139.73900441453557 24.183 35.66767333060021 139.73889460023332 24.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-233d570f-6291-499f-963f-9931521bbbfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-233d570f-6291-499f-963f-9931521bbbfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-233d570f-6291-499f-963f-9931521bbbfd">
											<gml:posList>35.66758405122158 139.7389657082607 23.608 35.66759949495879 139.7389353028801 23.608 35.66759949495879 139.7389353028801 27.185 35.66758405122158 139.7389657082607 27.185 35.66758405122158 139.7389657082607 23.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3818213f-6005-4fb1-bbc5-db6675ae553c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3818213f-6005-4fb1-bbc5-db6675ae553c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3818213f-6005-4fb1-bbc5-db6675ae553c">
											<gml:posList>35.6676209319973 139.7390073520051 24.183 35.6676209319973 139.7390073520051 11.63 35.66762392871397 139.73900115174146 11.63 35.66762392871397 139.73900115174146 17.328 35.66767552969822 139.73889427731262 17.328 35.66767552969822 139.73889427731262 11.63 35.66767573667607 139.73889384627927 11.63 35.66767573667607 139.73889384627927 24.183 35.6676209319973 139.7390073520051 24.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e60ddaab-3da3-4c9f-944b-e9df62efda50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e60ddaab-3da3-4c9f-944b-e9df62efda50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e60ddaab-3da3-4c9f-944b-e9df62efda50">
											<gml:posList>35.6675379360018 139.73891849726388 29.269 35.66758419518375 139.73882745793108 36.463 35.667446047258366 139.7390991278675 36.463 35.6675379360018 139.73891849726388 29.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85d3c046-42c2-4d71-9a24-69a99d716591">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85d3c046-42c2-4d71-9a24-69a99d716591">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85d3c046-42c2-4d71-9a24-69a99d716591">
											<gml:posList>35.667620307748564 139.73900441453557 24.183 35.667620307748564 139.73900441453557 23.608 35.66752956029481 139.73893900825422 23.608 35.66752956029481 139.73893900825422 24.183 35.667620307748564 139.73900441453557 24.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c664cf74-2931-43a6-8a53-8af577143920">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c664cf74-2931-43a6-8a53-8af577143920">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c664cf74-2931-43a6-8a53-8af577143920">
											<gml:posList>35.667437539590935 139.73907775309246 34.887 35.66755080372176 139.7388675606544 34.887 35.66755080372176 139.7388675606544 38.843 35.667437539590935 139.73907775309246 38.843 35.667437539590935 139.73907775309246 34.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f85c57df-ba01-4dd1-9241-f2a3094b7d04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f85c57df-ba01-4dd1-9241-f2a3094b7d04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f85c57df-ba01-4dd1-9241-f2a3094b7d04">
											<gml:posList>35.6675271361825 139.7389397511809 11.63 35.6676209319973 139.7390073520051 11.63 35.6676209319973 139.7390073520051 24.183 35.6675271361825 139.7389397511809 24.183 35.6675271361825 139.7389397511809 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2653d969-eb0a-4c4a-a76e-0de73362a26e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2653d969-eb0a-4c4a-a76e-0de73362a26e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2653d969-eb0a-4c4a-a76e-0de73362a26e">
											<gml:posList>35.66762392871397 139.73900115174146 11.63 35.66764349962742 139.73901533372242 11.63 35.66764349962742 139.73901533372242 17.328 35.66762392871397 139.73900115174146 17.328 35.66762392871397 139.73900115174146 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76ae9907-8230-4405-a1cf-f7bec3ebf751">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76ae9907-8230-4405-a1cf-f7bec3ebf751">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76ae9907-8230-4405-a1cf-f7bec3ebf751">
											<gml:posList>35.6675379360018 139.73891849726388 29.269 35.667446047258366 139.7390991278675 36.463 35.6675271361825 139.7389397511809 24.183 35.6675379360018 139.73891849726388 29.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70a2dd4f-638a-4a76-82c2-cbe8a4d557a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70a2dd4f-638a-4a76-82c2-cbe8a4d557a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70a2dd4f-638a-4a76-82c2-cbe8a4d557a4">
											<gml:posList>35.667446047258366 139.7390991278675 36.463 35.667446047258366 139.7390991278675 11.63 35.6675271361825 139.7389397511809 11.63 35.667446047258366 139.7390991278675 36.463</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86f6f25d-dbfd-4707-aec1-2724b6491204">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86f6f25d-dbfd-4707-aec1-2724b6491204">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86f6f25d-dbfd-4707-aec1-2724b6491204">
											<gml:posList>35.667446047258366 139.7390991278675 36.463 35.6675271361825 139.7389397511809 11.63 35.6675271361825 139.7389397511809 24.183 35.667446047258366 139.7390991278675 36.463</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f6804a0-c562-4081-ab86-eb2c87947be4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f6804a0-c562-4081-ab86-eb2c87947be4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f6804a0-c562-4081-ab86-eb2c87947be4">
											<gml:posList>35.667382051946 139.73903286172145 38.843 35.667437539590935 139.73907775309246 34.887 35.667437539590935 139.73907775309246 38.843 35.667382051946 139.73903286172145 38.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6af94a5f-bd77-4a0d-91cc-3d88ef91a722">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6af94a5f-bd77-4a0d-91cc-3d88ef91a722">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6af94a5f-bd77-4a0d-91cc-3d88ef91a722">
											<gml:posList>35.667382051946 139.73903286172145 38.843 35.667382051946 139.73903286172145 34.887 35.667437539590935 139.73907775309246 34.887 35.667382051946 139.73903286172145 38.843</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71d59c53-f723-4985-b60a-6b77f48facdd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71d59c53-f723-4985-b60a-6b77f48facdd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71d59c53-f723-4985-b60a-6b77f48facdd">
											<gml:posList>35.667445458038095 139.73909487590578 36.463 35.667445458038095 139.73909487590578 34.887 35.667374721052106 139.73904088962635 34.887 35.667374721052106 139.73904088962635 36.463 35.667445458038095 139.73909487590578 36.463</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49186757-cf3b-4ec7-9c83-25baa24066c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49186757-cf3b-4ec7-9c83-25baa24066c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49186757-cf3b-4ec7-9c83-25baa24066c3">
											<gml:posList>35.667371278673386 139.73904199825878 11.63 35.667446047258366 139.7390991278675 11.63 35.667446047258366 139.7390991278675 36.463 35.667371278673386 139.73904199825878 36.463 35.667371278673386 139.73904199825878 11.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c271fc26-309e-4051-8b01-88032a9ae21c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c271fc26-309e-4051-8b01-88032a9ae21c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c271fc26-309e-4051-8b01-88032a9ae21c">
											<gml:posList>35.6675335350705 139.73892715135972 27.185 35.6675379360018 139.73891849726388 29.269 35.6675271361825 139.7389397511809 24.183 35.6675335350705 139.73892715135972 27.185</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6430</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">287.11595</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>