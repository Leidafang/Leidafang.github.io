<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_7d414b80-72e4-42bf-92d1-8ce6997fe22e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">13.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66900572107669 139.73975847949154 0 35.66903906396455 139.7397830843716 0 35.66904694753417 139.73976704731774 0 35.669062460049105 139.73977849504448 0 35.66906452916344 139.73977328992746 0 35.66907551291767 139.73977976115975 0 35.66908258697196 139.73978914207444 0 35.66908777955826 139.73977841027153 0 35.66909435434797 139.73978327392237 0 35.669106566677925 139.73975842807727 0 35.669099676235135 139.73975334387444 0 35.669103509900715 139.73974538622005 0 35.669033556512204 139.739701824832 0 35.66900572107669 139.73975847949154 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66900572107669 139.73975847949154 11.2 35.669033556512204 139.739701824832 11.2 35.669103509900715 139.73974538622005 11.2 35.669099676235135 139.73975334387444 11.2 35.669106566677925 139.73975842807727 11.2 35.66909435434797 139.73978327392237 11.2 35.66908777955826 139.73977841027153 11.2 35.66908258697196 139.73978914207444 11.2 35.66907551291767 139.73977976115975 11.2 35.66906452916344 139.73977328992746 11.2 35.669062460049105 139.73977849504448 11.2 35.66904694753417 139.73976704731774 11.2 35.66903906396455 139.7397830843716 11.2 35.66900572107669 139.73975847949154 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66900572107669 139.73975847949154 11.2 35.66903906396455 139.7397830843716 11.2 35.66903906396455 139.7397830843716 24.38 35.66900572107669 139.73975847949154 24.38 35.66900572107669 139.73975847949154 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903906396455 139.7397830843716 11.2 35.66904694753417 139.73976704731774 11.2 35.66904694753417 139.73976704731774 24.38 35.66903906396455 139.7397830843716 24.38 35.66903906396455 139.7397830843716 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66904694753417 139.73976704731774 11.2 35.669062460049105 139.73977849504448 11.2 35.669062460049105 139.73977849504448 24.38 35.66904694753417 139.73976704731774 24.38 35.66904694753417 139.73976704731774 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669062460049105 139.73977849504448 11.2 35.66906452916344 139.73977328992746 11.2 35.66906452916344 139.73977328992746 24.38 35.669062460049105 139.73977849504448 24.38 35.669062460049105 139.73977849504448 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66906452916344 139.73977328992746 11.2 35.66907551291767 139.73977976115975 11.2 35.66907551291767 139.73977976115975 24.38 35.66906452916344 139.73977328992746 24.38 35.66906452916344 139.73977328992746 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66907551291767 139.73977976115975 11.2 35.66908258697196 139.73978914207444 11.2 35.66908258697196 139.73978914207444 24.38 35.66907551291767 139.73977976115975 24.38 35.66907551291767 139.73977976115975 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908258697196 139.73978914207444 11.2 35.66908777955826 139.73977841027153 11.2 35.66908777955826 139.73977841027153 24.38 35.66908258697196 139.73978914207444 24.38 35.66908258697196 139.73978914207444 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908777955826 139.73977841027153 11.2 35.66909435434797 139.73978327392237 11.2 35.66909435434797 139.73978327392237 24.38 35.66908777955826 139.73977841027153 24.38 35.66908777955826 139.73977841027153 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909435434797 139.73978327392237 11.2 35.669106566677925 139.73975842807727 11.2 35.669106566677925 139.73975842807727 24.38 35.66909435434797 139.73978327392237 24.38 35.66909435434797 139.73978327392237 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669106566677925 139.73975842807727 11.2 35.669099676235135 139.73975334387444 11.2 35.669099676235135 139.73975334387444 24.38 35.669106566677925 139.73975842807727 24.38 35.669106566677925 139.73975842807727 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669099676235135 139.73975334387444 11.2 35.669103509900715 139.73974538622005 11.2 35.669103509900715 139.73974538622005 24.38 35.669099676235135 139.73975334387444 24.38 35.669099676235135 139.73975334387444 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669103509900715 139.73974538622005 11.2 35.669033556512204 139.739701824832 11.2 35.669033556512204 139.739701824832 24.38 35.669103509900715 139.73974538622005 24.38 35.669103509900715 139.73974538622005 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669033556512204 139.739701824832 11.2 35.66900572107669 139.73975847949154 11.2 35.66900572107669 139.73975847949154 24.38 35.669033556512204 139.739701824832 24.38 35.669033556512204 139.739701824832 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66900572107669 139.73975847949154 24.38 35.66903906396455 139.7397830843716 24.38 35.66904694753417 139.73976704731774 24.38 35.669062460049105 139.73977849504448 24.38 35.66906452916344 139.73977328992746 24.38 35.66907551291767 139.73977976115975 24.38 35.66908258697196 139.73978914207444 24.38 35.66908777955826 139.73977841027153 24.38 35.66909435434797 139.73978327392237 24.38 35.669106566677925 139.73975842807727 24.38 35.669099676235135 139.73975334387444 24.38 35.669103509900715 139.73974538622005 24.38 35.669033556512204 139.739701824832 24.38 35.66900572107669 139.73975847949154 24.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7c6a651f-c492-45cf-be29-fff893997f94"/>
							<gml:surfaceMember xlink:href="#poly-44988c43-dba3-49c4-9d9e-c2db3c94363b"/>
							<gml:surfaceMember xlink:href="#poly-60623b01-3b40-4547-bf44-5dbaabbb4d9c"/>
							<gml:surfaceMember xlink:href="#poly-311f439f-c540-46fe-84f4-8cb9f5460ace"/>
							<gml:surfaceMember xlink:href="#poly-dd053cd1-83f5-4112-ab5b-bf05354b99a8"/>
							<gml:surfaceMember xlink:href="#poly-034c837c-981a-4b1e-8d7a-a96ce6d363f1"/>
							<gml:surfaceMember xlink:href="#poly-9e90a940-e2fe-49a0-90ce-c01dbd5472fd"/>
							<gml:surfaceMember xlink:href="#poly-93fe5cf0-1512-4854-b1bf-7e0a527c43dc"/>
							<gml:surfaceMember xlink:href="#poly-dbe6668f-a58b-4ada-b36d-4740d1a3bf67"/>
							<gml:surfaceMember xlink:href="#poly-720e8693-c627-4a2e-8ef7-808c3088f5ed"/>
							<gml:surfaceMember xlink:href="#poly-c7124e2d-b04d-4da7-887e-d8805f4a568e"/>
							<gml:surfaceMember xlink:href="#poly-04130ea5-2458-4210-b38f-cfaf90312b93"/>
							<gml:surfaceMember xlink:href="#poly-f1dfe67d-b961-44d4-8ee6-897b7b121ede"/>
							<gml:surfaceMember xlink:href="#poly-308f6db3-5ba1-4fc6-9379-ec278801c6f3"/>
							<gml:surfaceMember xlink:href="#poly-bf616ec1-cfed-42e4-ac10-04cd4b3893d8"/>
							<gml:surfaceMember xlink:href="#poly-0d180913-c7a9-4543-b8d2-baeca69c38ab"/>
							<gml:surfaceMember xlink:href="#poly-731305b5-d232-4ad2-9001-49f17ef6d267"/>
							<gml:surfaceMember xlink:href="#poly-75322cca-1baa-4c80-9544-586602a31c81"/>
							<gml:surfaceMember xlink:href="#poly-953a7453-3c78-404a-a8e5-365d5599c785"/>
							<gml:surfaceMember xlink:href="#poly-e16020b3-c329-4a86-bf88-f994ed521012"/>
							<gml:surfaceMember xlink:href="#poly-d491111b-5ac9-4236-a46c-b728bd34bd9e"/>
							<gml:surfaceMember xlink:href="#poly-3e5a30c9-d30d-495e-a542-c66136c7b4d5"/>
							<gml:surfaceMember xlink:href="#poly-0844c12c-f8a2-4e41-8b53-9cce4217c269"/>
							<gml:surfaceMember xlink:href="#poly-e5ee481e-c6f1-49ff-b350-d20f84c8b79d"/>
							<gml:surfaceMember xlink:href="#poly-ff246193-77fc-41c7-b1d7-63191b95bf68"/>
							<gml:surfaceMember xlink:href="#poly-d4702279-db79-451c-b8f7-6d14118ecf34"/>
							<gml:surfaceMember xlink:href="#poly-439e88b4-3f31-4c4e-855a-0663465fa0c7"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_7d414b80-72e4-42bf-92d1-8ce6997fe22e_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4fcd914-4775-43ca-a899-cdc410302606">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4fcd914-4775-43ca-a899-cdc410302606_0">
											<gml:posList>35.66906246004908 139.73977849504448 25.477 35.66904694753417 139.73976704731774 26.733 35.66903906397314 139.73978309541764 26.733 35.66906246004908 139.73977849504448 25.477</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce407c4a-be66-478e-82ac-e37821e38d88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce407c4a-be66-478e-82ac-e37821e38d88_0">
											<gml:posList>35.66907551291766 139.73977976115975 23.582 35.66906246004908 139.73977849504448 25.477 35.66903906397314 139.73978309541764 26.733 35.66907551291766 139.73977976115975 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57795908-7ebf-4f49-8ff5-81569bbf618a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57795908-7ebf-4f49-8ff5-81569bbf618a_0">
											<gml:posList>35.66907551291766 139.73977976115975 23.582 35.66903906397314 139.73978309541764 26.733 35.66906469568571 139.73980199849024 23.582 35.66907551291766 139.73977976115975 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45e1fc27-56a9-459b-97e9-05e2d39f2ffa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45e1fc27-56a9-459b-97e9-05e2d39f2ffa_0">
											<gml:posList>35.66906246004908 139.73977849504448 25.477 35.66906246004908 139.73977849504448 11.2 35.66904694753417 139.73976704731774 11.2 35.66906246004908 139.73977849504448 25.477</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b44802b-1e10-4907-9a01-aa30cff790aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b44802b-1e10-4907-9a01-aa30cff790aa_0">
											<gml:posList>35.66904694753417 139.73976704731774 26.733 35.66906246004908 139.73977849504448 25.477 35.66904694753417 139.73976704731774 11.2 35.66904694753417 139.73976704731774 26.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bb8a2e7-a331-4f3f-a1a9-db9450a57989">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bb8a2e7-a331-4f3f-a1a9-db9450a57989_0">
											<gml:posList>35.66903906397314 139.73978309541764 11.2 35.66904694753417 139.73976704731774 26.733 35.66904694753417 139.73976704731774 11.2 35.66903906397314 139.73978309541764 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c67ef31a-1bbe-4793-b2e3-a7a3314bbecc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c67ef31a-1bbe-4793-b2e3-a7a3314bbecc_0">
											<gml:posList>35.66903906397314 139.73978309541764 11.2 35.66903906397314 139.73978309541764 26.733 35.66904694753417 139.73976704731774 26.733 35.66903906397314 139.73978309541764 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bde7cc78-f249-47e9-ab40-aa181db72dbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bde7cc78-f249-47e9-ab40-aa181db72dbf_0">
											<gml:posList>35.66906409735433 139.73977438399305 24.842 35.66906452916344 139.73977328992746 25.506 35.66906452916344 139.73977328992746 11.2 35.66906409735433 139.73977438399305 24.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c14702a4-8d6a-4e6e-bf01-1437cba4fefe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c14702a4-8d6a-4e6e-bf01-1437cba4fefe_0">
											<gml:posList>35.66906409735433 139.73977438399305 24.842 35.66906246004908 139.73977849504448 25.477 35.66906452916344 139.73977328992746 25.506 35.66906409735433 139.73977438399305 24.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d7c6f2e-323b-49e0-9fb3-ab0d9180f14d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d7c6f2e-323b-49e0-9fb3-ab0d9180f14d_0">
											<gml:posList>35.66906246004908 139.73977849504448 11.2 35.669064304258036 139.7397738535399 11.2 35.66906452916344 139.73977328992746 11.2 35.66906246004908 139.73977849504448 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6cf8990-5147-419f-95f2-295364c7e7c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6cf8990-5147-419f-95f2-295364c7e7c1_0">
											<gml:posList>35.66906409735433 139.73977438399305 24.842 35.66906246004908 139.73977849504448 24.842 35.66906246004908 139.73977849504448 25.477 35.66906409735433 139.73977438399305 24.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d427378-6e5e-40cc-b99d-8ff93fadcd8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d427378-6e5e-40cc-b99d-8ff93fadcd8a_0">
											<gml:posList>35.66906246004908 139.73977849504448 24.842 35.66906409735433 139.73977438399305 24.842 35.66906246004908 139.73977849504448 11.2 35.66906246004908 139.73977849504448 24.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e391dd57-b543-45e7-b30f-84187dcfdd0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e391dd57-b543-45e7-b30f-84187dcfdd0b_0">
											<gml:posList>35.669064304258036 139.7397738535399 11.2 35.66906409735433 139.73977438399305 24.842 35.66906452916344 139.73977328992746 11.2 35.669064304258036 139.7397738535399 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ff34996-392d-4ead-9dbc-a6e104d0e9c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ff34996-392d-4ead-9dbc-a6e104d0e9c2_0">
											<gml:posList>35.66906246004908 139.73977849504448 11.2 35.66906409735433 139.73977438399305 24.842 35.669064304258036 139.7397738535399 11.2 35.66906246004908 139.73977849504448 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-491feef7-9ff9-473b-a39d-6ab75ba77cbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-491feef7-9ff9-473b-a39d-6ab75ba77cbf_0">
											<gml:posList>35.66906246004908 139.73977849504448 11.2 35.66906409735433 139.73977438399305 24.842 35.669064304258036 139.7397738535399 11.2 35.66906246004908 139.73977849504448 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55855cd1-7689-4074-b612-75c3dc30e55d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55855cd1-7689-4074-b612-75c3dc30e55d_0">
											<gml:posList>35.66906246004908 139.73977849504448 11.2 35.66906246004908 139.73977849504448 24.842 35.66906409735433 139.73977438399305 24.842 35.66906246004908 139.73977849504448 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e9c02ee-7420-4f1a-b8be-071f61c0b28c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e9c02ee-7420-4f1a-b8be-071f61c0b28c_0">
											<gml:posList>35.669069822648545 139.73977640979106 24.579 35.66906246004908 139.73977849504448 25.477 35.66907551291766 139.73977976115975 23.582 35.669069822648545 139.73977640979106 24.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7790d0b0-ef7a-4437-995b-6457864c43c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7790d0b0-ef7a-4437-995b-6457864c43c5_0">
											<gml:posList>35.669069822648545 139.73977640979106 24.579 35.66906452916344 139.73977328992746 25.506 35.66906246004908 139.73977849504448 25.477 35.669069822648545 139.73977640979106 24.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bc0b4d2-fe56-4ea6-9dec-29b88805e447">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1bc0b4d2-fe56-4ea6-9dec-29b88805e447_0">
											<gml:posList>35.66907603625434 139.73978045645217 11.2 35.66907551291766 139.73977976115975 23.582 35.66907639717234 139.73978093101252 23.582 35.66907603625434 139.73978045645217 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df0892b8-c862-4103-af0e-91ff88f99f75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df0892b8-c862-4103-af0e-91ff88f99f75_0">
											<gml:posList>35.66907603625434 139.73978045645217 11.2 35.66907551291766 139.73977976115975 11.2 35.66907551291766 139.73977976115975 23.582 35.66907603625434 139.73978045645217 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db140f0d-047a-4e95-a3e8-2fa6e52f774d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db140f0d-047a-4e95-a3e8-2fa6e52f774d_0">
											<gml:posList>35.669069822648545 139.73977640979106 24.579 35.66906452916344 139.73977328992746 11.2 35.66906452916344 139.73977328992746 25.506 35.669069822648545 139.73977640979106 24.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d108bb2-10a6-42aa-b4e7-d9d6cc5d9194">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d108bb2-10a6-42aa-b4e7-d9d6cc5d9194_0">
											<gml:posList>35.66906452916344 139.73977328992746 11.2 35.66907002104489 139.73977653106644 11.2 35.66907551291766 139.73977976115975 11.2 35.66906452916344 139.73977328992746 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dacebf2-d2b4-4263-b363-9ea9b38676c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2dacebf2-d2b4-4263-b363-9ea9b38676c0_0">
											<gml:posList>35.66907603625434 139.73978045645217 11.2 35.669082559913626 139.73978912001388 11.2 35.66907551291766 139.73977976115975 11.2 35.66907603625434 139.73978045645217 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe452a4d-3b4a-49c0-92b8-31e7817fda96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe452a4d-3b4a-49c0-92b8-31e7817fda96_0">
											<gml:posList>35.66907639717234 139.73978093101252 23.582 35.669082559913626 139.73978912001388 23.582 35.669082559913626 139.73978912001388 11.2 35.66907639717234 139.73978093101252 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92a9f203-ec7d-4067-8ebc-a5c63f28125b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92a9f203-ec7d-4067-8ebc-a5c63f28125b_0">
											<gml:posList>35.669069822648545 139.73977640979106 24.579 35.66907002104489 139.73977653106644 11.2 35.66906452916344 139.73977328992746 11.2 35.669069822648545 139.73977640979106 24.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3740e52b-eb86-4042-9a5d-5a4b012d3dbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3740e52b-eb86-4042-9a5d-5a4b012d3dbd_0">
											<gml:posList>35.66907639717234 139.73978093101252 23.582 35.669082559913626 139.73978912001388 11.2 35.66907603625434 139.73978045645217 11.2 35.66907639717234 139.73978093101252 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ade66be1-b87b-4834-b4b2-273f107e71c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ade66be1-b87b-4834-b4b2-273f107e71c9_0">
											<gml:posList>35.669082559913626 139.73978912001388 23.582 35.66908058901427 139.7397931209943 11.2 35.669082559913626 139.73978912001388 11.2 35.669082559913626 139.73978912001388 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71eeda61-2c7f-43a9-b564-7ce8490ee82c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71eeda61-2c7f-43a9-b564-7ce8490ee82c_0">
											<gml:posList>35.669082559913626 139.73978912001388 23.582 35.66908058901427 139.7397931209943 23.582 35.66908058901427 139.7397931209943 11.2 35.669082559913626 139.73978912001388 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bee393f0-2f12-467b-9350-13fd0900230d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bee393f0-2f12-467b-9350-13fd0900230d_0">
											<gml:posList>35.66907551291766 139.73977976115975 23.582 35.66906469568571 139.73980199849024 23.582 35.66907639717234 139.73978093101252 23.582 35.66907551291766 139.73977976115975 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6950c2a2-4328-4835-9188-701874cbbc19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6950c2a2-4328-4835-9188-701874cbbc19_0">
											<gml:posList>35.669082559913626 139.73978912001388 23.582 35.66907639717234 139.73978093101252 23.582 35.66908058901427 139.7397931209943 23.582 35.669082559913626 139.73978912001388 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94fcb5cc-2a14-4ecb-b8f3-d8b779ce0a03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94fcb5cc-2a14-4ecb-b8f3-d8b779ce0a03_0">
											<gml:posList>35.66908058901427 139.7397931209943 23.582 35.66906469568571 139.73980199849024 23.582 35.66907166730147 139.73980714887685 23.582 35.66908058901427 139.7397931209943 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71d026cc-75f2-424b-b1fa-055e1f433dd9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71d026cc-75f2-424b-b1fa-055e1f433dd9_0">
											<gml:posList>35.669082883442634 139.73979948086006 23.582 35.66908058901427 139.7397931209943 23.582 35.6690794546275 139.73980645493648 23.582 35.669082883442634 139.73979948086006 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ae9ec0b-eaa6-421f-9415-869a3cc1fb7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ae9ec0b-eaa6-421f-9415-869a3cc1fb7c_0">
											<gml:posList>35.6690794546275 139.73980645493648 23.582 35.66908058901427 139.7397931209943 23.582 35.66907166730147 139.73980714887685 23.582 35.6690794546275 139.73980645493648 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cd1091a-73e6-42c1-8fc4-240d4da897df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cd1091a-73e6-42c1-8fc4-240d4da897df_0">
											<gml:posList>35.66907639717234 139.73978093101252 23.582 35.66906469568571 139.73980199849024 23.582 35.66908058901427 139.7397931209943 23.582 35.66907639717234 139.73978093101252 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a01eb99-5f39-44da-a027-fa0f34559f93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a01eb99-5f39-44da-a027-fa0f34559f93_0">
											<gml:posList>35.66903906397314 139.73978309541764 26.733 35.66903906397314 139.73978309541764 11.2 35.66906469568571 139.73980199849024 23.582 35.66903906397314 139.73978309541764 26.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75f659ca-a706-4e99-a4ce-b38da8f6e9af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75f659ca-a706-4e99-a4ce-b38da8f6e9af_0">
											<gml:posList>35.66906469568571 139.73980199849024 23.582 35.66907166730147 139.73980714887685 11.2 35.66907166730147 139.73980714887685 23.582 35.66906469568571 139.73980199849024 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7dc60349-346f-4b9f-9c5e-ea68c7e7e4dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7dc60349-346f-4b9f-9c5e-ea68c7e7e4dc_0">
											<gml:posList>35.66906469568571 139.73980199849024 23.582 35.66903906397314 139.73978309541764 11.2 35.66907166730147 139.73980714887685 11.2 35.66906469568571 139.73980199849024 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4012e43a-79dc-48ae-bda8-2b25939d9a6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4012e43a-79dc-48ae-bda8-2b25939d9a6d_0">
											<gml:posList>35.66908058901427 139.7397931209943 23.582 35.669082883442634 139.73979948086006 11.2 35.66908058901427 139.7397931209943 11.2 35.66908058901427 139.7397931209943 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6964532d-26cf-448f-95ad-19bd9e8ec0bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6964532d-26cf-448f-95ad-19bd9e8ec0bc_0">
											<gml:posList>35.66908058901427 139.7397931209943 23.582 35.669082883442634 139.73979948086006 23.582 35.669082883442634 139.73979948086006 11.2 35.66908058901427 139.7397931209943 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9054c6ad-9d4b-41c8-8bd5-20ec404bb397">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9054c6ad-9d4b-41c8-8bd5-20ec404bb397_0">
											<gml:posList>35.669082883442634 139.73979948086006 11.2 35.6690794546275 139.73980645493648 23.582 35.6690794546275 139.73980645493648 11.2 35.669082883442634 139.73979948086006 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5ea3c02-9f6a-46f2-911d-f6b3ff7fc803">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5ea3c02-9f6a-46f2-911d-f6b3ff7fc803_0">
											<gml:posList>35.669082883442634 139.73979948086006 11.2 35.669082883442634 139.73979948086006 23.582 35.6690794546275 139.73980645493648 23.582 35.669082883442634 139.73979948086006 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9feb687a-c6dc-4d1a-855e-3262fdb1cd91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9feb687a-c6dc-4d1a-855e-3262fdb1cd91_0">
											<gml:posList>35.6690794546275 139.73980645493648 23.582 35.66907166730147 139.73980714887685 11.2 35.6690794546275 139.73980645493648 11.2 35.6690794546275 139.73980645493648 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d3247ae-ae88-4156-ae92-edd7d703abc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d3247ae-ae88-4156-ae92-edd7d703abc3_0">
											<gml:posList>35.6690794546275 139.73980645493648 23.582 35.66907166730147 139.73980714887685 23.582 35.66907166730147 139.73980714887685 11.2 35.6690794546275 139.73980645493648 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82c6aa73-7686-417d-bd04-a7c21e577457">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82c6aa73-7686-417d-bd04-a7c21e577457_0">
											<gml:posList>35.66907551291766 139.73977976115975 23.582 35.66907002104489 139.73977653106644 11.2 35.669069822648545 139.73977640979106 24.579 35.66907551291766 139.73977976115975 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea3bd61b-256e-4437-a9bd-ceb6f232faeb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea3bd61b-256e-4437-a9bd-ceb6f232faeb_0">
											<gml:posList>35.66907551291766 139.73977976115975 23.582 35.66907551291766 139.73977976115975 11.2 35.66907002104489 139.73977653106644 11.2 35.66907551291766 139.73977976115975 23.582</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32be0bb8-5803-47f5-93c5-577fc7923d13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66906246004908 139.73977849504448 11.2 35.66906452916344 139.73977328992746 11.2 35.66907551291766 139.73977976115975 11.2 35.66906246004908 139.73977849504448 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3a25b40-d052-4f49-86a9-a4409516af07">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66907551291766 139.73977976115975 11.2 35.669082559913626 139.73978912001388 11.2 35.66908058901427 139.7397931209943 11.2 35.66907551291766 139.73977976115975 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84de3ed9-9a5c-4311-96df-e402a8b1b965">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903906397314 139.73978309541764 11.2 35.66904694753417 139.73976704731774 11.2 35.66906246004908 139.73977849504448 11.2 35.66903906397314 139.73978309541764 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63fbb545-8428-418b-a8b2-ee9bd697eb92">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669082883442634 139.73979948086006 11.2 35.6690794546275 139.73980645493648 11.2 35.66908058901427 139.7397931209943 11.2 35.669082883442634 139.73979948086006 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4271fa74-f4cd-47eb-b3e5-ee6dabaef055">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66907166730147 139.73980714887685 11.2 35.66903906397314 139.73978309541764 11.2 35.66906246004908 139.73977849504448 11.2 35.66907166730147 139.73980714887685 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa998edc-8da5-4e34-ad49-b2dd5c909394">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908058901427 139.7397931209943 11.2 35.6690794546275 139.73980645493648 11.2 35.66907166730147 139.73980714887685 11.2 35.66908058901427 139.7397931209943 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c797dd48-663c-4b31-9a63-7a217da34a9f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908058901427 139.7397931209943 11.2 35.66906246004908 139.73977849504448 11.2 35.66907551291766 139.73977976115975 11.2 35.66908058901427 139.7397931209943 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfeb75eb-16d4-4c57-aa50-009648609118">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908058901427 139.7397931209943 11.2 35.66907166730147 139.73980714887685 11.2 35.66906246004908 139.73977849504448 11.2 35.66908058901427 139.7397931209943 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_7d414b80-72e4-42bf-92d1-8ce6997fe22e_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6825744b-bed0-46f5-89cb-868d243802b3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903539796656 139.73975161838368 27.312 35.66902716392045 139.73974581775946 27.312 35.669036045767406 139.7397268965136 27.312 35.66904427981442 139.7397326971365 27.312 35.66903539796656 139.73975161838368 27.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1899f305-0f45-49b2-8ab0-0aca319add05">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66905957847563 139.73975892475747 24.842 35.669053238187644 139.73975424862033 24.842 35.66906515353103 139.73973001066452 24.842 35.66907149381994 139.73973468680043 24.842 35.66905957847563 139.73975892475747 24.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27ff486e-e2cf-4eff-a172-22e5d06101d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27ff486e-e2cf-4eff-a172-22e5d06101d3_0">
											<gml:posList>35.66902716392045 139.73974581775946 27.312 35.66903539796656 139.73975161838368 27.312 35.66903539796656 139.73975161838368 29.885 35.66902716392045 139.73974581775946 29.885 35.66902716392045 139.73974581775946 27.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc1823f6-4645-4012-8e1f-31034910e01a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc1823f6-4645-4012-8e1f-31034910e01a_0">
											<gml:posList>35.66902716392045 139.73974581775946 27.312 35.66902716392045 139.73974581775946 29.885 35.669036045767406 139.7397268965136 29.885 35.669036045767406 139.7397268965136 27.312 35.66902716392045 139.73974581775946 27.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e2265c5-051d-4d66-b32c-c5df49f03c09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e2265c5-051d-4d66-b32c-c5df49f03c09_0">
											<gml:posList>35.66903539796656 139.73975161838368 29.885 35.66904427981442 139.7397326971365 29.885 35.669036045767406 139.7397268965136 29.885 35.66902716392045 139.73974581775946 29.885 35.66903539796656 139.73975161838368 29.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe243cab-f1ce-4c74-b44e-ab73eeea7f1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe243cab-f1ce-4c74-b44e-ab73eeea7f1e_0">
											<gml:posList>35.66904427981442 139.7397326971365 27.312 35.66904427981442 139.7397326971365 29.885 35.66903539796656 139.73975161838368 29.885 35.66903539796656 139.73975161838368 27.312 35.66904427981442 139.7397326971365 27.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddcd2879-fef6-47c0-b3c7-e6f95d2b60c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddcd2879-fef6-47c0-b3c7-e6f95d2b60c6_0">
											<gml:posList>35.66904427981442 139.7397326971365 27.312 35.669036045767406 139.7397268965136 27.312 35.669036045767406 139.7397268965136 29.885 35.66904427981442 139.7397326971365 29.885 35.66904427981442 139.7397326971365 27.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3893a8d8-6c65-4864-b65a-c77bd20a31ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3893a8d8-6c65-4864-b65a-c77bd20a31ec_0">
											<gml:posList>35.66905957847563 139.73975892475747 24.842 35.66905957847563 139.73975892475747 26.383 35.669053238187644 139.73975424862033 26.383 35.669053238187644 139.73975424862033 24.842 35.66905957847563 139.73975892475747 24.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b895f42-36f6-4e32-b9cb-6a4ceae8bc1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b895f42-36f6-4e32-b9cb-6a4ceae8bc1c_0">
											<gml:posList>35.66906515353103 139.73973001066452 24.842 35.669053238187644 139.73975424862033 24.842 35.669053238187644 139.73975424862033 26.383 35.66906515353103 139.73973001066452 26.383 35.66906515353103 139.73973001066452 24.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bd86ef5-bf55-41ea-850f-707173e9ea0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bd86ef5-bf55-41ea-850f-707173e9ea0b_0">
											<gml:posList>35.66905957847563 139.73975892475747 26.383 35.66907149381994 139.73973468680043 26.383 35.66906515353103 139.73973001066452 26.383 35.669053238187644 139.73975424862033 26.383 35.66905957847563 139.73975892475747 26.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62a45e0f-76b5-444a-b5f9-743663deed97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62a45e0f-76b5-444a-b5f9-743663deed97_0">
											<gml:posList>35.66905957847563 139.73975892475747 24.842 35.66907149381994 139.73973468680043 24.842 35.66907149381994 139.73973468680043 26.383 35.66905957847563 139.73975892475747 26.383 35.66905957847563 139.73975892475747 24.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e90888ad-73e3-4038-851d-071dcf3899b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e90888ad-73e3-4038-851d-071dcf3899b7_0">
											<gml:posList>35.66907149381994 139.73973468680043 24.842 35.66906515353103 139.73973001066452 24.842 35.66906515353103 139.73973001066452 26.383 35.66907149381994 139.73973468680043 26.383 35.66907149381994 139.73973468680043 24.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7c6a651f-c492-45cf-be29-fff893997f94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c6a651f-c492-45cf-be29-fff893997f94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c6a651f-c492-45cf-be29-fff893997f94">
											<gml:posList>35.66900572107666 139.7397584794915 11.2 35.6690335565122 139.739701824832 11.2 35.669103509900694 139.73974538622002 11.2 35.66909967623512 139.7397533438744 11.2 35.66910656667789 139.73975842807724 11.2 35.66909435434797 139.73978327392237 11.2 35.66908777955824 139.73977841027153 11.2 35.66908258697197 139.73978914207444 11.2 35.66907551291766 139.73977976115975 11.2 35.66906452916344 139.73977328992746 11.2 35.66906246004908 139.73977849504448 11.2 35.66904694753417 139.73976704731774 11.2 35.669039063964554 139.7397830843716 11.2 35.66900572107666 139.7397584794915 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44988c43-dba3-49c4-9d9e-c2db3c94363b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44988c43-dba3-49c4-9d9e-c2db3c94363b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44988c43-dba3-49c4-9d9e-c2db3c94363b">
											<gml:posList>35.6690335565122 139.739701824832 27.67 35.66903397252636 139.7397036027641 27.67 35.66906678037828 139.73972404388303 27.67 35.66906834834557 139.7397235007946 27.67 35.6690335565122 139.739701824832 27.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-60623b01-3b40-4547-bf44-5dbaabbb4d9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60623b01-3b40-4547-bf44-5dbaabbb4d9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60623b01-3b40-4547-bf44-5dbaabbb4d9c">
											<gml:posList>35.66900572107666 139.7397584794915 27.67 35.66900723501328 139.73975800274368 27.67 35.66903397252636 139.7397036027641 27.67 35.6690335565122 139.739701824832 27.67 35.66900572107666 139.7397584794915 27.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-311f439f-c540-46fe-84f4-8cb9f5460ace">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-311f439f-c540-46fe-84f4-8cb9f5460ace">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-311f439f-c540-46fe-84f4-8cb9f5460ace">
											<gml:posList>35.66903867492409 139.7397812180389 27.312 35.66906678037828 139.73972404388303 27.312 35.66903397252636 139.7397036027641 27.312 35.66900723501328 139.73975800274368 27.312 35.66903867492409 139.7397812180389 27.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd053cd1-83f5-4112-ab5b-bf05354b99a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd053cd1-83f5-4112-ab5b-bf05354b99a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd053cd1-83f5-4112-ab5b-bf05354b99a8">
											<gml:posList>35.66909446475653 139.73973976327562 24.842 35.66906834834557 139.7397235007946 24.842 35.66904694753417 139.73976704731774 24.842 35.66906246004908 139.73977849504448 24.842 35.66906452916344 139.73977328992746 24.842 35.66907551291766 139.73977976115975 24.842 35.66909446475653 139.73973976327562 24.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-034c837c-981a-4b1e-8d7a-a96ce6d363f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-034c837c-981a-4b1e-8d7a-a96ce6d363f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-034c837c-981a-4b1e-8d7a-a96ce6d363f1">
											<gml:posList>35.66906834834557 139.7397235007946 27.67 35.66906678037828 139.73972404388303 27.67 35.66903867492409 139.7397812180389 27.67 35.669039063964554 139.7397830843716 27.67 35.66906834834557 139.7397235007946 27.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e90a940-e2fe-49a0-90ce-c01dbd5472fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e90a940-e2fe-49a0-90ce-c01dbd5472fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e90a940-e2fe-49a0-90ce-c01dbd5472fd">
											<gml:posList>35.66907551291766 139.73977976115975 24.842 35.66908258697197 139.73978914207444 21.354 35.669103509900694 139.73974538622002 21.354 35.66909446475653 139.73973976327562 24.842 35.66907551291766 139.73977976115975 24.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93fe5cf0-1512-4854-b1bf-7e0a527c43dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93fe5cf0-1512-4854-b1bf-7e0a527c43dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93fe5cf0-1512-4854-b1bf-7e0a527c43dc">
											<gml:posList>35.66908777955824 139.73977841027153 19.355 35.66909435434797 139.73978327392237 19.355 35.66910656667789 139.73975842807724 19.355 35.66909967623512 139.7397533438744 19.355 35.66908777955824 139.73977841027153 19.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dbe6668f-a58b-4ada-b36d-4740d1a3bf67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbe6668f-a58b-4ada-b36d-4740d1a3bf67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbe6668f-a58b-4ada-b36d-4740d1a3bf67">
											<gml:posList>35.669039063964554 139.7397830843716 27.67 35.66903867492409 139.7397812180389 27.67 35.66900723501328 139.73975800274368 27.67 35.66900572107666 139.7397584794915 27.67 35.669039063964554 139.7397830843716 27.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-720e8693-c627-4a2e-8ef7-808c3088f5ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-720e8693-c627-4a2e-8ef7-808c3088f5ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-720e8693-c627-4a2e-8ef7-808c3088f5ed">
											<gml:posList>35.66903397252636 139.7397036027641 27.67 35.66903397252636 139.7397036027641 27.312 35.66906678037828 139.73972404388303 27.312 35.66906678037828 139.73972404388303 27.67 35.66903397252636 139.7397036027641 27.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7124e2d-b04d-4da7-887e-d8805f4a568e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7124e2d-b04d-4da7-887e-d8805f4a568e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7124e2d-b04d-4da7-887e-d8805f4a568e">
											<gml:posList>35.66906834834557 139.7397235007946 24.842 35.66909446475653 139.73973976327562 24.842 35.669103509900694 139.73974538622002 21.354 35.669103509900694 139.73974538622002 11.2 35.6690335565122 139.739701824832 11.2 35.6690335565122 139.739701824832 27.67 35.66906834834557 139.7397235007946 27.67 35.66906834834557 139.7397235007946 24.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04130ea5-2458-4210-b38f-cfaf90312b93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04130ea5-2458-4210-b38f-cfaf90312b93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04130ea5-2458-4210-b38f-cfaf90312b93">
											<gml:posList>35.6690335565122 139.739701824832 11.2 35.66900572107666 139.7397584794915 11.2 35.66900572107666 139.7397584794915 27.67 35.6690335565122 139.739701824832 27.67 35.6690335565122 139.739701824832 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1dfe67d-b961-44d4-8ee6-897b7b121ede">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1dfe67d-b961-44d4-8ee6-897b7b121ede">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1dfe67d-b961-44d4-8ee6-897b7b121ede">
											<gml:posList>35.66900723501328 139.73975800274368 27.67 35.66900723501328 139.73975800274368 27.312 35.66903397252636 139.7397036027641 27.312 35.66903397252636 139.7397036027641 27.67 35.66900723501328 139.73975800274368 27.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-308f6db3-5ba1-4fc6-9379-ec278801c6f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-308f6db3-5ba1-4fc6-9379-ec278801c6f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-308f6db3-5ba1-4fc6-9379-ec278801c6f3">
											<gml:posList>35.66909967623512 139.7397533438744 19.355 35.66909967623512 139.7397533438744 11.2 35.669103509900694 139.73974538622002 11.2 35.669103509900694 139.73974538622002 21.354 35.66909967623512 139.7397533438744 19.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf616ec1-cfed-42e4-ac10-04cd4b3893d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf616ec1-cfed-42e4-ac10-04cd4b3893d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf616ec1-cfed-42e4-ac10-04cd4b3893d8">
											<gml:posList>35.66906678037828 139.73972404388303 27.67 35.66906678037828 139.73972404388303 27.312 35.66903867492409 139.7397812180389 27.312 35.66903867492409 139.7397812180389 27.67 35.66906678037828 139.73972404388303 27.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d180913-c7a9-4543-b8d2-baeca69c38ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d180913-c7a9-4543-b8d2-baeca69c38ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d180913-c7a9-4543-b8d2-baeca69c38ab">
											<gml:posList>35.669039063964554 139.7397830843716 27.67 35.669039063964554 139.7397830843716 11.2 35.66904694753417 139.73976704731774 11.2 35.66904694753417 139.73976704731774 24.842 35.66906834834557 139.7397235007946 24.842 35.66906834834557 139.7397235007946 27.67 35.669039063964554 139.7397830843716 27.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-731305b5-d232-4ad2-9001-49f17ef6d267">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-731305b5-d232-4ad2-9001-49f17ef6d267">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-731305b5-d232-4ad2-9001-49f17ef6d267">
											<gml:posList>35.66910656667789 139.73975842807724 11.2 35.66909967623512 139.7397533438744 11.2 35.66909967623512 139.7397533438744 19.355 35.66910656667789 139.73975842807724 19.355 35.66910656667789 139.73975842807724 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75322cca-1baa-4c80-9544-586602a31c81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75322cca-1baa-4c80-9544-586602a31c81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75322cca-1baa-4c80-9544-586602a31c81">
											<gml:posList>35.669103509900694 139.73974538622002 21.354 35.66908258697197 139.73978914207444 21.354 35.66908777955824 139.73977841027153 19.355 35.66909967623512 139.7397533438744 19.355 35.669103509900694 139.73974538622002 21.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-953a7453-3c78-404a-a8e5-365d5599c785">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-953a7453-3c78-404a-a8e5-365d5599c785">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-953a7453-3c78-404a-a8e5-365d5599c785">
											<gml:posList>35.66903867492409 139.7397812180389 27.67 35.66903867492409 139.7397812180389 27.312 35.66900723501328 139.73975800274368 27.312 35.66900723501328 139.73975800274368 27.67 35.66903867492409 139.7397812180389 27.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e16020b3-c329-4a86-bf88-f994ed521012">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e16020b3-c329-4a86-bf88-f994ed521012">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e16020b3-c329-4a86-bf88-f994ed521012">
											<gml:posList>35.66900572107666 139.7397584794915 11.2 35.669039063964554 139.7397830843716 11.2 35.669039063964554 139.7397830843716 27.67 35.66900572107666 139.7397584794915 27.67 35.66900572107666 139.7397584794915 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d491111b-5ac9-4236-a46c-b728bd34bd9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d491111b-5ac9-4236-a46c-b728bd34bd9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d491111b-5ac9-4236-a46c-b728bd34bd9e">
											<gml:posList>35.66909435434797 139.73978327392237 11.2 35.66910656667789 139.73975842807724 11.2 35.66910656667789 139.73975842807724 19.355 35.66909435434797 139.73978327392237 19.355 35.66909435434797 139.73978327392237 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e5a30c9-d30d-495e-a542-c66136c7b4d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e5a30c9-d30d-495e-a542-c66136c7b4d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e5a30c9-d30d-495e-a542-c66136c7b4d5">
											<gml:posList>35.66904694753417 139.73976704731774 11.2 35.66906246004908 139.73977849504448 11.2 35.66906246004908 139.73977849504448 24.842 35.66904694753417 139.73976704731774 24.842 35.66904694753417 139.73976704731774 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0844c12c-f8a2-4e41-8b53-9cce4217c269">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0844c12c-f8a2-4e41-8b53-9cce4217c269">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0844c12c-f8a2-4e41-8b53-9cce4217c269">
											<gml:posList>35.66906246004908 139.73977849504448 11.2 35.66906452916344 139.73977328992746 11.2 35.66906452916344 139.73977328992746 24.842 35.66906246004908 139.73977849504448 24.842 35.66906246004908 139.73977849504448 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5ee481e-c6f1-49ff-b350-d20f84c8b79d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5ee481e-c6f1-49ff-b350-d20f84c8b79d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5ee481e-c6f1-49ff-b350-d20f84c8b79d">
											<gml:posList>35.66906452916344 139.73977328992746 11.2 35.66907551291766 139.73977976115975 11.2 35.66907551291766 139.73977976115975 24.842 35.66906452916344 139.73977328992746 24.842 35.66906452916344 139.73977328992746 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff246193-77fc-41c7-b1d7-63191b95bf68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff246193-77fc-41c7-b1d7-63191b95bf68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff246193-77fc-41c7-b1d7-63191b95bf68">
											<gml:posList>35.66908777955824 139.73977841027153 11.2 35.66909435434797 139.73978327392237 11.2 35.66909435434797 139.73978327392237 19.355 35.66908777955824 139.73977841027153 19.355 35.66908777955824 139.73977841027153 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4702279-db79-451c-b8f7-6d14118ecf34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4702279-db79-451c-b8f7-6d14118ecf34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4702279-db79-451c-b8f7-6d14118ecf34">
											<gml:posList>35.66908258697197 139.73978914207444 11.2 35.66908777955824 139.73977841027153 11.2 35.66908777955824 139.73977841027153 19.355 35.66908258697197 139.73978914207444 21.354 35.66908258697197 139.73978914207444 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-439e88b4-3f31-4c4e-855a-0663465fa0c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-439e88b4-3f31-4c4e-855a-0663465fa0c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-439e88b4-3f31-4c4e-855a-0663465fa0c7">
											<gml:posList>35.66907551291766 139.73977976115975 11.2 35.66908258697197 139.73978914207444 11.2 35.66908258697197 139.73978914207444 21.354 35.66907551291766 139.73977976115975 24.842 35.66907551291766 139.73977976115975 11.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5894</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">58.049</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.07</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>