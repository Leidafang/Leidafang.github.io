<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_7e3fda2c-5b9a-4990-8b16-c2130009b08e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">31.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>11</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66737750393028 139.73881941714902 0 35.667327535365196 139.73877805415054 0 35.667286673561485 139.73885520224943 0 35.66734178061777 139.73889744289062 0 35.66729929669949 139.73897514514303 0 35.667360904583724 139.73903140644805 0 35.66749204880024 139.73879431849048 0 35.66747058216761 139.73877655996742 0 35.66744930838494 139.73877481771692 0 35.6674343669332 139.73880200813588 0 35.667414704347806 139.73878590437397 0 35.66739739703848 139.73878470973762 0 35.66738047464533 139.73881455347527 0 35.66737750393028 139.73881941714902 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737750393028 139.73881941714902 11.8 35.66738047464533 139.73881455347527 11.8 35.66739739703848 139.73878470973762 11.8 35.667414704347806 139.73878590437397 11.8 35.6674343669332 139.73880200813588 11.8 35.66744930838494 139.73877481771692 11.8 35.66747058216761 139.73877655996742 11.8 35.66749204880024 139.73879431849048 11.8 35.667360904583724 139.73903140644805 11.8 35.66729929669949 139.73897514514303 11.8 35.66734178061777 139.73889744289062 11.8 35.667286673561485 139.73885520224943 11.8 35.667327535365196 139.73877805415054 11.8 35.66737750393028 139.73881941714902 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737750393028 139.73881941714902 11.8 35.667327535365196 139.73877805415054 11.8 35.667327535365196 139.73877805415054 43.2 35.66737750393028 139.73881941714902 43.2 35.66737750393028 139.73881941714902 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667327535365196 139.73877805415054 11.8 35.667286673561485 139.73885520224943 11.8 35.667286673561485 139.73885520224943 43.2 35.667327535365196 139.73877805415054 43.2 35.667327535365196 139.73877805415054 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667286673561485 139.73885520224943 11.8 35.66734178061777 139.73889744289062 11.8 35.66734178061777 139.73889744289062 43.2 35.667286673561485 139.73885520224943 43.2 35.667286673561485 139.73885520224943 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66734178061777 139.73889744289062 11.8 35.66729929669949 139.73897514514303 11.8 35.66729929669949 139.73897514514303 43.2 35.66734178061777 139.73889744289062 43.2 35.66734178061777 139.73889744289062 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66729929669949 139.73897514514303 11.8 35.667360904583724 139.73903140644805 11.8 35.667360904583724 139.73903140644805 43.2 35.66729929669949 139.73897514514303 43.2 35.66729929669949 139.73897514514303 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667360904583724 139.73903140644805 11.8 35.66749204880024 139.73879431849048 11.8 35.66749204880024 139.73879431849048 43.2 35.667360904583724 139.73903140644805 43.2 35.667360904583724 139.73903140644805 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66749204880024 139.73879431849048 11.8 35.66747058216761 139.73877655996742 11.8 35.66747058216761 139.73877655996742 43.2 35.66749204880024 139.73879431849048 43.2 35.66749204880024 139.73879431849048 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66747058216761 139.73877655996742 11.8 35.66744930838494 139.73877481771692 11.8 35.66744930838494 139.73877481771692 43.2 35.66747058216761 139.73877655996742 43.2 35.66747058216761 139.73877655996742 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66744930838494 139.73877481771692 11.8 35.6674343669332 139.73880200813588 11.8 35.6674343669332 139.73880200813588 43.2 35.66744930838494 139.73877481771692 43.2 35.66744930838494 139.73877481771692 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6674343669332 139.73880200813588 11.8 35.667414704347806 139.73878590437397 11.8 35.667414704347806 139.73878590437397 43.2 35.6674343669332 139.73880200813588 43.2 35.6674343669332 139.73880200813588 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667414704347806 139.73878590437397 11.8 35.66739739703848 139.73878470973762 11.8 35.66739739703848 139.73878470973762 43.2 35.667414704347806 139.73878590437397 43.2 35.667414704347806 139.73878590437397 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66739739703848 139.73878470973762 11.8 35.66738047464533 139.73881455347527 11.8 35.66738047464533 139.73881455347527 43.2 35.66739739703848 139.73878470973762 43.2 35.66739739703848 139.73878470973762 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66738047464533 139.73881455347527 11.8 35.66737750393028 139.73881941714902 11.8 35.66737750393028 139.73881941714902 43.2 35.66738047464533 139.73881455347527 43.2 35.66738047464533 139.73881455347527 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737750393028 139.73881941714902 43.2 35.667327535365196 139.73877805415054 43.2 35.667286673561485 139.73885520224943 43.2 35.66734178061777 139.73889744289062 43.2 35.66729929669949 139.73897514514303 43.2 35.667360904583724 139.73903140644805 43.2 35.66749204880024 139.73879431849048 43.2 35.66747058216761 139.73877655996742 43.2 35.66744930838494 139.73877481771692 43.2 35.6674343669332 139.73880200813588 43.2 35.667414704347806 139.73878590437397 43.2 35.66739739703848 139.73878470973762 43.2 35.66738047464533 139.73881455347527 43.2 35.66737750393028 139.73881941714902 43.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9d36e5d4-6fc8-4973-a9cb-1d0ad83fbe17"/>
							<gml:surfaceMember xlink:href="#poly-8a240ff3-74db-4e00-b667-73b34c90dcd1"/>
							<gml:surfaceMember xlink:href="#poly-9115e796-2fd9-4961-9397-81b4a41a965b"/>
							<gml:surfaceMember xlink:href="#poly-010c24f1-3e99-430a-b555-ecb509bb9f59"/>
							<gml:surfaceMember xlink:href="#poly-6450dc2e-d589-435a-a5d1-afd44adfda65"/>
							<gml:surfaceMember xlink:href="#poly-f19764ad-09bd-4bce-998c-0c271c8e9713"/>
							<gml:surfaceMember xlink:href="#poly-f820ca74-35bf-46b9-b0f1-d0e50b0b294c"/>
							<gml:surfaceMember xlink:href="#poly-1359964f-d1de-4d0b-b269-25b5e68ea13c"/>
							<gml:surfaceMember xlink:href="#poly-37e647e0-702b-4226-b01a-70cdbc61f496"/>
							<gml:surfaceMember xlink:href="#poly-c824904d-d32c-4819-a5d1-f48e2b3a6684"/>
							<gml:surfaceMember xlink:href="#poly-133db851-bcb8-4c28-8cda-437fe1603866"/>
							<gml:surfaceMember xlink:href="#poly-87aab563-e06a-4f06-8a2d-712c1a4d0df7"/>
							<gml:surfaceMember xlink:href="#poly-03ee7950-6517-441c-b7d8-afc662270c1d"/>
							<gml:surfaceMember xlink:href="#poly-22599dc5-2055-413d-88e5-3a92b0a85b69"/>
							<gml:surfaceMember xlink:href="#poly-18b0c584-5f08-42c5-b6cd-06931a219ca1"/>
							<gml:surfaceMember xlink:href="#poly-8a3737fb-62ca-467e-b954-95bc194cfa13"/>
							<gml:surfaceMember xlink:href="#poly-7f49cdb7-6516-4f0f-914d-e260d48b58e5"/>
							<gml:surfaceMember xlink:href="#poly-58bfcfba-1a7c-412b-bf0e-2d5c9cc0f07f"/>
							<gml:surfaceMember xlink:href="#poly-e1b55687-7d63-4e65-b691-4b3a567b392f"/>
							<gml:surfaceMember xlink:href="#poly-70fac8de-3f75-43ce-afc0-46eccf4293a2"/>
							<gml:surfaceMember xlink:href="#poly-b9c87531-35c1-4076-957d-8422e2743460"/>
							<gml:surfaceMember xlink:href="#poly-bdb27ff1-7399-42e1-b247-a23e93f4637b"/>
							<gml:surfaceMember xlink:href="#poly-8d38963f-902b-44b4-ac7a-985e3f60e7b2"/>
							<gml:surfaceMember xlink:href="#poly-ff6fc2b6-9d5f-49d1-be31-e63bfb5ba906"/>
							<gml:surfaceMember xlink:href="#poly-4073b804-4a8f-4bda-bf52-d8a1e1f15bc8"/>
							<gml:surfaceMember xlink:href="#poly-28b5aaa7-41ea-4198-9619-22d25ec7f064"/>
							<gml:surfaceMember xlink:href="#poly-6d7c6af9-1ba7-477a-b8c0-bca474486c48"/>
							<gml:surfaceMember xlink:href="#poly-c4ed48b0-6232-4a45-a5b4-7bc78fac4b5a"/>
							<gml:surfaceMember xlink:href="#poly-738da0c5-bc11-4c49-9245-815143a1a24c"/>
							<gml:surfaceMember xlink:href="#poly-ecf6b77a-5706-4f44-9cb3-4be47fb863f5"/>
							<gml:surfaceMember xlink:href="#poly-73c5f180-b5f7-41ad-b625-1577b7818d0d"/>
							<gml:surfaceMember xlink:href="#poly-3d5ef743-1986-4d62-b0f3-a4d9f6e5d30d"/>
							<gml:surfaceMember xlink:href="#poly-b3c09429-12b6-4ff7-831f-6e5cb0a60412"/>
							<gml:surfaceMember xlink:href="#poly-aa0e8528-5e77-4e99-909c-0bedaf62fca9"/>
							<gml:surfaceMember xlink:href="#poly-cc593c3f-7c31-430d-bfda-77477d259412"/>
							<gml:surfaceMember xlink:href="#poly-ea89202b-a32a-4c80-be9d-f7e2da6bdf7f"/>
							<gml:surfaceMember xlink:href="#poly-9ab0e6b8-5838-4394-b977-ad636db96293"/>
							<gml:surfaceMember xlink:href="#poly-ceb04a40-f654-4124-b9f0-a9f9767e9967"/>
							<gml:surfaceMember xlink:href="#poly-fc56b6c9-ebd8-4b47-b9e8-ddbcc9ff89af"/>
							<gml:surfaceMember xlink:href="#poly-5867aa91-67f2-4abf-87f3-906dcce98f19"/>
							<gml:surfaceMember xlink:href="#poly-ddcb3ef4-a8f5-482f-a71f-71df2a5cb76c"/>
							<gml:surfaceMember xlink:href="#poly-ea2fa2a4-eabe-4492-8440-8277b9550cc7"/>
							<gml:surfaceMember xlink:href="#poly-92d290c6-b821-45e9-9b3d-d19112a076b2"/>
							<gml:surfaceMember xlink:href="#poly-bb428a44-f20d-4643-849c-fea5692e7847"/>
							<gml:surfaceMember xlink:href="#poly-193f2b68-bccb-4b29-9008-e83db67addf9"/>
							<gml:surfaceMember xlink:href="#poly-57f073cb-5f63-4301-b29c-cd069c54af99"/>
							<gml:surfaceMember xlink:href="#poly-7cbf954b-d967-4ed6-9336-54f6e26c2179"/>
							<gml:surfaceMember xlink:href="#poly-fc3aec10-81d1-4e96-8521-c5b36d04cf03"/>
							<gml:surfaceMember xlink:href="#poly-6c4bd4ae-ec42-44d2-adc5-fb6e0572ad20"/>
							<gml:surfaceMember xlink:href="#poly-45c344ff-7c47-4d05-977d-94bf9168d98e"/>
							<gml:surfaceMember xlink:href="#poly-ee414721-7b17-42c2-b9f8-e238f14e7500"/>
							<gml:surfaceMember xlink:href="#poly-792032f9-ce4f-4802-a65e-aa15055cc5d2"/>
							<gml:surfaceMember xlink:href="#poly-06a8884e-0641-4b64-94e1-9c5c4d824494"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_7e3fda2c-5b9a-4990-8b16-c2130009b08e_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51e9a1d1-d958-4d8a-ba2e-905f059d7597">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667394658248696 139.73882092125663 43.476 35.66739859166386 139.73881380309402 43.476 35.66741152579234 139.73882454650615 43.476 35.66740758336282 139.73883166468 43.476 35.667394658248696 139.73882092125663 43.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08c1bd94-1068-4bdd-99b9-25c2fdbf0a04">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667426776965925 139.7388244622558 43.476 35.66743877305037 139.73883442252318 43.476 35.66743076218829 139.73884890203132 43.476 35.66741876610502 139.7388389417627 43.476 35.667426776965925 139.7388244622558 43.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec33ddf2-0ded-4c67-af0f-435d21e16eff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec33ddf2-0ded-4c67-af0f-435d21e16eff_0">
											<gml:posList>35.66739859166386 139.73881380309402 43.476 35.667394658248696 139.73882092125663 43.476 35.667394658248696 139.73882092125663 45.005 35.66739859166386 139.73881380309402 45.005 35.66739859166386 139.73881380309402 43.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3db33313-1f15-44a5-a50d-229b480ef478">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3db33313-1f15-44a5-a50d-229b480ef478_0">
											<gml:posList>35.66741152579234 139.73882454650615 43.476 35.66739859166386 139.73881380309402 43.476 35.66739859166386 139.73881380309402 45.005 35.66741152579234 139.73882454650615 45.005 35.66741152579234 139.73882454650615 43.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bb7000e-392b-4e18-bd0e-77768cee6447">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bb7000e-392b-4e18-bd0e-77768cee6447_0">
											<gml:posList>35.667394658248696 139.73882092125663 45.005 35.66740758336282 139.73883166468 45.005 35.66741152579234 139.73882454650615 45.005 35.66739859166386 139.73881380309402 45.005 35.667394658248696 139.73882092125663 45.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2735a63-7f18-4fa0-90ae-4616b8e9f4bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2735a63-7f18-4fa0-90ae-4616b8e9f4bf_0">
											<gml:posList>35.667394658248696 139.73882092125663 43.476 35.66740758336282 139.73883166468 43.476 35.66740758336282 139.73883166468 45.005 35.667394658248696 139.73882092125663 45.005 35.667394658248696 139.73882092125663 43.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54b23a42-c7bd-464f-8d15-e1e4764002bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54b23a42-c7bd-464f-8d15-e1e4764002bf_0">
											<gml:posList>35.66741152579234 139.73882454650615 45.005 35.66740758336282 139.73883166468 45.005 35.66740758336282 139.73883166468 43.476 35.66741152579234 139.73882454650615 43.476 35.66741152579234 139.73882454650615 45.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba1fd69e-8b4d-42b5-b58e-ecc1a5f48a0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba1fd69e-8b4d-42b5-b58e-ecc1a5f48a0d_0">
											<gml:posList>35.667426776965925 139.7388244622558 43.476 35.667426776965925 139.7388244622558 45.976 35.66743877305037 139.73883442252318 45.976 35.66743877305037 139.73883442252318 43.476 35.667426776965925 139.7388244622558 43.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e55d1bd-35bc-43db-96d9-6203001a7f2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e55d1bd-35bc-43db-96d9-6203001a7f2c_0">
											<gml:posList>35.667426776965925 139.7388244622558 43.476 35.66741876610502 139.7388389417627 43.476 35.66741876610502 139.7388389417627 45.976 35.667426776965925 139.7388244622558 45.976 35.667426776965925 139.7388244622558 43.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00c7aa3d-f698-4352-9eb5-6b46c4d7fff4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00c7aa3d-f698-4352-9eb5-6b46c4d7fff4_0">
											<gml:posList>35.667426776965925 139.7388244622558 45.976 35.66741876610502 139.7388389417627 45.976 35.66743076218829 139.73884890203132 45.976 35.66743877305037 139.73883442252318 45.976 35.667426776965925 139.7388244622558 45.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16f5f8e3-4c1e-4525-9c46-ba0228129519">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16f5f8e3-4c1e-4525-9c46-ba0228129519_0">
											<gml:posList>35.66743076218829 139.73884890203132 43.476 35.66743877305037 139.73883442252318 43.476 35.66743877305037 139.73883442252318 45.976 35.66743076218829 139.73884890203132 45.976 35.66743076218829 139.73884890203132 43.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e344ff78-b43d-4bb3-87ff-6899a05d58a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e344ff78-b43d-4bb3-87ff-6899a05d58a0_0">
											<gml:posList>35.66741876610502 139.7388389417627 43.476 35.66743076218829 139.73884890203132 43.476 35.66743076218829 139.73884890203132 45.976 35.66741876610502 139.7388389417627 45.976 35.66741876610502 139.7388389417627 43.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9d36e5d4-6fc8-4973-a9cb-1d0ad83fbe17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d36e5d4-6fc8-4973-a9cb-1d0ad83fbe17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d36e5d4-6fc8-4973-a9cb-1d0ad83fbe17">
											<gml:posList>35.66734178061775 139.73889744289062 11.8 35.66728667356148 139.73885520224943 11.8 35.66732753536519 139.73877805415052 11.8 35.667377503930254 139.73881941714902 11.8 35.66738047464531 139.73881455347527 11.8 35.66739739703846 139.73878470973764 11.8 35.6674147043478 139.73878590437394 11.8 35.6674343669332 139.73880200813588 11.8 35.667449308384946 139.73877481771692 11.8 35.66747058216762 139.73877655996742 11.8 35.667492048800256 139.73879431849048 11.8 35.6673609045837 139.73903140644805 11.8 35.66729929669949 139.73897514514303 11.8 35.66734178061775 139.73889744289062 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a240ff3-74db-4e00-b667-73b34c90dcd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a240ff3-74db-4e00-b667-73b34c90dcd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a240ff3-74db-4e00-b667-73b34c90dcd1">
											<gml:posList>35.66747058216762 139.73877655996742 43.87 35.667449308384946 139.73877481771692 43.87 35.667450175428776 139.7387770148197 43.87 35.66746998889229 139.7387786372884 43.87 35.66747058216762 139.73877655996742 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9115e796-2fd9-4961-9397-81b4a41a965b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9115e796-2fd9-4961-9397-81b4a41a965b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9115e796-2fd9-4961-9397-81b4a41a965b">
											<gml:posList>35.66747058216762 139.73877655996742 43.87 35.66746998889229 139.7387786372884 43.87 35.66748963357247 139.73879489572278 43.87 35.667492048800256 139.73879431849048 43.87 35.66747058216762 139.73877655996742 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-010c24f1-3e99-430a-b555-ecb509bb9f59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-010c24f1-3e99-430a-b555-ecb509bb9f59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-010c24f1-3e99-430a-b555-ecb509bb9f59">
											<gml:posList>35.6674147043478 139.73878590437394 43.87 35.66739739703846 139.73878470973764 43.87 35.667398255059716 139.7387868958039 43.87 35.66741412009469 139.73878799272862 43.87 35.6674147043478 139.73878590437394 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6450dc2e-d589-435a-a5d1-afd44adfda65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6450dc2e-d589-435a-a5d1-afd44adfda65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6450dc2e-d589-435a-a5d1-afd44adfda65">
											<gml:posList>35.6674343669332 139.73880200813588 43.87 35.66743482894848 139.73880495683412 43.87 35.667450175428776 139.7387770148197 43.87 35.667449308384946 139.73877481771692 43.87 35.6674343669332 139.73880200813588 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f19764ad-09bd-4bce-998c-0c271c8e9713">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f19764ad-09bd-4bce-998c-0c271c8e9713">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f19764ad-09bd-4bce-998c-0c271c8e9713">
											<gml:posList>35.667350246707514 139.73879684948403 21.927 35.66732753536519 139.73877805415052 21.927 35.66732005604209 139.73879217955064 21.927 35.66734255091408 139.73881079840814 21.927 35.667350246707514 139.73879684948403 21.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f820ca74-35bf-46b9-b0f1-d0e50b0b294c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f820ca74-35bf-46b9-b0f1-d0e50b0b294c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f820ca74-35bf-46b9-b0f1-d0e50b0b294c">
											<gml:posList>35.6674343669332 139.73880200813588 43.87 35.6674147043478 139.73878590437394 43.87 35.66741412009469 139.73878799272862 43.87 35.66743482894848 139.73880495683412 43.87 35.6674343669332 139.73880200813588 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1359964f-d1de-4d0b-b269-25b5e68ea13c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1359964f-d1de-4d0b-b269-25b5e68ea13c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1359964f-d1de-4d0b-b269-25b5e68ea13c">
											<gml:posList>35.66738047464531 139.73881455347527 43.87 35.66738187275269 139.73881580000787 43.87 35.667398255059716 139.7387868958039 43.87 35.66739739703846 139.73878470973764 43.87 35.66738047464531 139.73881455347527 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-37e647e0-702b-4226-b01a-70cdbc61f496">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37e647e0-702b-4226-b01a-70cdbc61f496">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37e647e0-702b-4226-b01a-70cdbc61f496">
											<gml:posList>35.667377503930254 139.73881941714902 43.87 35.667350246707514 139.73879684948403 43.87 35.66735070873159 139.73879980922496 43.87 35.66737790280567 139.73882231069047 43.87 35.667377503930254 139.73881941714902 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c824904d-d32c-4819-a5d1-f48e2b3a6684">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c824904d-d32c-4819-a5d1-f48e2b3a6684">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c824904d-d32c-4819-a5d1-f48e2b3a6684">
											<gml:posList>35.667377503930254 139.73881941714902 43.87 35.66737790280567 139.73882231069047 43.87 35.66738187275269 139.73881580000787 43.87 35.66738047464531 139.73881455347527 43.87 35.667377503930254 139.73881941714902 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-133db851-bcb8-4c28-8cda-437fe1603866">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-133db851-bcb8-4c28-8cda-437fe1603866">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-133db851-bcb8-4c28-8cda-437fe1603866">
											<gml:posList>35.66730875245805 139.7388721205481 29.6 35.66734255091408 139.73881079840814 29.6 35.66732005604209 139.73879217955064 29.6 35.66728667356148 139.73885520224943 29.6 35.66730875245805 139.7388721205481 29.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-87aab563-e06a-4f06-8a2d-712c1a4d0df7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87aab563-e06a-4f06-8a2d-712c1a4d0df7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87aab563-e06a-4f06-8a2d-712c1a4d0df7">
											<gml:posList>35.66730875245805 139.7388721205481 43.87 35.66731119468414 139.73887148805846 43.87 35.66735070873159 139.73879980922496 43.87 35.667350246707514 139.73879684948403 43.87 35.66730875245805 139.7388721205481 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03ee7950-6517-441c-b7d8-afc662270c1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03ee7950-6517-441c-b7d8-afc662270c1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03ee7950-6517-441c-b7d8-afc662270c1d">
											<gml:posList>35.66748963357247 139.73879489572278 43.87 35.66742912906153 139.73890426576958 43.87 35.6674305721933 139.7389054570222 43.87 35.667492048800256 139.73879431849048 43.87 35.66748963357247 139.73879489572278 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22599dc5-2055-413d-88e5-3a92b0a85b69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22599dc5-2055-413d-88e5-3a92b0a85b69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22599dc5-2055-413d-88e5-3a92b0a85b69">
											<gml:posList>35.66734178061775 139.73889744289062 43.87 35.667344213830226 139.73889681041206 43.87 35.66731119468414 139.73887148805846 43.87 35.66730875245805 139.7388721205481 43.87 35.66734178061775 139.73889744289062 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18b0c584-5f08-42c5-b6cd-06931a219ca1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18b0c584-5f08-42c5-b6cd-06931a219ca1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18b0c584-5f08-42c5-b6cd-06931a219ca1">
											<gml:posList>35.66738375210736 139.73890195539522 43.476 35.66739268152628 139.73890937873503 43.476 35.66740609297345 139.73888512834833 43.476 35.66742912906153 139.73890426576958 43.476 35.66748963357247 139.73879489572278 43.476 35.66746998889229 139.7387786372884 43.476 35.667450175428776 139.7387770148197 43.476 35.66743482894848 139.73880495683412 43.476 35.66741412009469 139.73878799272862 43.476 35.667398255059716 139.7387868958039 43.476 35.66738187275269 139.73881580000787 43.476 35.66737790280567 139.73882231069047 43.476 35.66735070873159 139.73879980922496 43.476 35.66731119468414 139.73887148805846 43.476 35.667344213830226 139.73889681041206 43.476 35.66730164889273 139.73897464531254 43.476 35.66736048758206 139.7390283803774 43.476 35.66740875085749 139.73894111663103 43.476 35.66737678535703 139.7389145558635 43.476 35.66738375210736 139.73890195539522 43.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a3737fb-62ca-467e-b954-95bc194cfa13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a3737fb-62ca-467e-b954-95bc194cfa13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a3737fb-62ca-467e-b954-95bc194cfa13">
											<gml:posList>35.667410193988886 139.73894230788406 48.054 35.6674305721933 139.7389054570222 48.054 35.66740609297345 139.73888512834833 48.054 35.66739268152628 139.73890937873503 48.054 35.66738375210736 139.73890195539522 48.054 35.66737678535703 139.7389145558635 48.054 35.667410193988886 139.73894230788406 48.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f49cdb7-6516-4f0f-914d-e260d48b58e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f49cdb7-6516-4f0f-914d-e260d48b58e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f49cdb7-6516-4f0f-914d-e260d48b58e5">
											<gml:posList>35.66734178061775 139.73889744289062 43.87 35.66729929669949 139.73897514514303 43.87 35.66730164889273 139.73897464531254 43.87 35.667344213830226 139.73889681041206 43.87 35.66734178061775 139.73889744289062 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-58bfcfba-1a7c-412b-bf0e-2d5c9cc0f07f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58bfcfba-1a7c-412b-bf0e-2d5c9cc0f07f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58bfcfba-1a7c-412b-bf0e-2d5c9cc0f07f">
											<gml:posList>35.66736048758206 139.7390283803774 43.87 35.6673609045837 139.73903140644805 43.87 35.667410193988886 139.73894230788406 43.87 35.66740875085749 139.73894111663103 43.87 35.66736048758206 139.7390283803774 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e1b55687-7d63-4e65-b691-4b3a567b392f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1b55687-7d63-4e65-b691-4b3a567b392f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1b55687-7d63-4e65-b691-4b3a567b392f">
											<gml:posList>35.6673609045837 139.73903140644805 43.87 35.66736048758206 139.7390283803774 43.87 35.66730164889273 139.73897464531254 43.87 35.66729929669949 139.73897514514303 43.87 35.6673609045837 139.73903140644805 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70fac8de-3f75-43ce-afc0-46eccf4293a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70fac8de-3f75-43ce-afc0-46eccf4293a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70fac8de-3f75-43ce-afc0-46eccf4293a2">
											<gml:posList>35.66737790280567 139.73882231069047 43.87 35.66737790280567 139.73882231069047 43.476 35.66738187275269 139.73881580000787 43.476 35.66738187275269 139.73881580000787 43.87 35.66737790280567 139.73882231069047 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9c87531-35c1-4076-957d-8422e2743460">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9c87531-35c1-4076-957d-8422e2743460">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9c87531-35c1-4076-957d-8422e2743460">
											<gml:posList>35.66738187275269 139.73881580000787 43.87 35.66738187275269 139.73881580000787 43.476 35.667398255059716 139.7387868958039 43.476 35.667398255059716 139.7387868958039 43.87 35.66738187275269 139.73881580000787 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bdb27ff1-7399-42e1-b247-a23e93f4637b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdb27ff1-7399-42e1-b247-a23e93f4637b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdb27ff1-7399-42e1-b247-a23e93f4637b">
											<gml:posList>35.66743482894848 139.73880495683412 43.87 35.66743482894848 139.73880495683412 43.476 35.667450175428776 139.7387770148197 43.476 35.667450175428776 139.7387770148197 43.87 35.66743482894848 139.73880495683412 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d38963f-902b-44b4-ac7a-985e3f60e7b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d38963f-902b-44b4-ac7a-985e3f60e7b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d38963f-902b-44b4-ac7a-985e3f60e7b2">
											<gml:posList>35.66747058216762 139.73877655996742 11.8 35.667449308384946 139.73877481771692 11.8 35.667449308384946 139.73877481771692 43.87 35.66747058216762 139.73877655996742 43.87 35.66747058216762 139.73877655996742 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff6fc2b6-9d5f-49d1-be31-e63bfb5ba906">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff6fc2b6-9d5f-49d1-be31-e63bfb5ba906">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff6fc2b6-9d5f-49d1-be31-e63bfb5ba906">
											<gml:posList>35.667450175428776 139.7387770148197 43.87 35.667450175428776 139.7387770148197 43.476 35.66746998889229 139.7387786372884 43.476 35.66746998889229 139.7387786372884 43.87 35.667450175428776 139.7387770148197 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4073b804-4a8f-4bda-bf52-d8a1e1f15bc8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4073b804-4a8f-4bda-bf52-d8a1e1f15bc8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4073b804-4a8f-4bda-bf52-d8a1e1f15bc8">
											<gml:posList>35.6674147043478 139.73878590437394 11.8 35.66739739703846 139.73878470973764 11.8 35.66739739703846 139.73878470973764 43.87 35.6674147043478 139.73878590437394 43.87 35.6674147043478 139.73878590437394 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28b5aaa7-41ea-4198-9619-22d25ec7f064">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28b5aaa7-41ea-4198-9619-22d25ec7f064">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28b5aaa7-41ea-4198-9619-22d25ec7f064">
											<gml:posList>35.667492048800256 139.73879431849048 11.8 35.66747058216762 139.73877655996742 11.8 35.66747058216762 139.73877655996742 43.87 35.667492048800256 139.73879431849048 43.87 35.667492048800256 139.73879431849048 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d7c6af9-1ba7-477a-b8c0-bca474486c48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d7c6af9-1ba7-477a-b8c0-bca474486c48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d7c6af9-1ba7-477a-b8c0-bca474486c48">
											<gml:posList>35.66746998889229 139.7387786372884 43.87 35.66746998889229 139.7387786372884 43.476 35.66748963357247 139.73879489572278 43.476 35.66748963357247 139.73879489572278 43.87 35.66746998889229 139.7387786372884 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4ed48b0-6232-4a45-a5b4-7bc78fac4b5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4ed48b0-6232-4a45-a5b4-7bc78fac4b5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4ed48b0-6232-4a45-a5b4-7bc78fac4b5a">
											<gml:posList>35.667398255059716 139.7387868958039 43.87 35.667398255059716 139.7387868958039 43.476 35.66741412009469 139.73878799272862 43.476 35.66741412009469 139.73878799272862 43.87 35.667398255059716 139.7387868958039 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-738da0c5-bc11-4c49-9245-815143a1a24c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-738da0c5-bc11-4c49-9245-815143a1a24c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-738da0c5-bc11-4c49-9245-815143a1a24c">
											<gml:posList>35.667449308384946 139.73877481771692 11.8 35.6674343669332 139.73880200813588 11.8 35.6674343669332 139.73880200813588 43.87 35.667449308384946 139.73877481771692 43.87 35.667449308384946 139.73877481771692 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecf6b77a-5706-4f44-9cb3-4be47fb863f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecf6b77a-5706-4f44-9cb3-4be47fb863f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecf6b77a-5706-4f44-9cb3-4be47fb863f5">
											<gml:posList>35.6674343669332 139.73880200813588 11.8 35.6674147043478 139.73878590437394 11.8 35.6674147043478 139.73878590437394 43.87 35.6674343669332 139.73880200813588 43.87 35.6674343669332 139.73880200813588 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73c5f180-b5f7-41ad-b625-1577b7818d0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73c5f180-b5f7-41ad-b625-1577b7818d0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73c5f180-b5f7-41ad-b625-1577b7818d0d">
											<gml:posList>35.66741412009469 139.73878799272862 43.87 35.66741412009469 139.73878799272862 43.476 35.66743482894848 139.73880495683412 43.476 35.66743482894848 139.73880495683412 43.87 35.66741412009469 139.73878799272862 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d5ef743-1986-4d62-b0f3-a4d9f6e5d30d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d5ef743-1986-4d62-b0f3-a4d9f6e5d30d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d5ef743-1986-4d62-b0f3-a4d9f6e5d30d">
											<gml:posList>35.667350246707514 139.73879684948403 21.927 35.667350246707514 139.73879684948403 43.87 35.667377503930254 139.73881941714902 43.87 35.667377503930254 139.73881941714902 11.8 35.66732753536519 139.73877805415052 11.8 35.66732753536519 139.73877805415052 21.927 35.667350246707514 139.73879684948403 21.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3c09429-12b6-4ff7-831f-6e5cb0a60412">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3c09429-12b6-4ff7-831f-6e5cb0a60412">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3c09429-12b6-4ff7-831f-6e5cb0a60412">
											<gml:posList>35.66739739703846 139.73878470973764 11.8 35.66738047464531 139.73881455347527 11.8 35.66738047464531 139.73881455347527 43.87 35.66739739703846 139.73878470973764 43.87 35.66739739703846 139.73878470973764 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa0e8528-5e77-4e99-909c-0bedaf62fca9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa0e8528-5e77-4e99-909c-0bedaf62fca9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa0e8528-5e77-4e99-909c-0bedaf62fca9">
											<gml:posList>35.66732005604209 139.73879217955064 29.6 35.66734255091408 139.73881079840814 29.6 35.66734255091408 139.73881079840814 21.927 35.66732005604209 139.73879217955064 21.927 35.66732005604209 139.73879217955064 29.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc593c3f-7c31-430d-bfda-77477d259412">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc593c3f-7c31-430d-bfda-77477d259412">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc593c3f-7c31-430d-bfda-77477d259412">
											<gml:posList>35.66735070873159 139.73879980922496 43.87 35.66735070873159 139.73879980922496 43.476 35.66737790280567 139.73882231069047 43.476 35.66737790280567 139.73882231069047 43.87 35.66735070873159 139.73879980922496 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea89202b-a32a-4c80-be9d-f7e2da6bdf7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea89202b-a32a-4c80-be9d-f7e2da6bdf7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea89202b-a32a-4c80-be9d-f7e2da6bdf7f">
											<gml:posList>35.66728667356148 139.73885520224943 29.6 35.66732005604209 139.73879217955064 29.6 35.66732005604209 139.73879217955064 21.927 35.66732753536519 139.73877805415052 21.927 35.66732753536519 139.73877805415052 11.8 35.66728667356148 139.73885520224943 11.8 35.66728667356148 139.73885520224943 29.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ab0e6b8-5838-4394-b977-ad636db96293">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ab0e6b8-5838-4394-b977-ad636db96293">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ab0e6b8-5838-4394-b977-ad636db96293">
											<gml:posList>35.66738047464531 139.73881455347527 11.8 35.667377503930254 139.73881941714902 11.8 35.667377503930254 139.73881941714902 43.87 35.66738047464531 139.73881455347527 43.87 35.66738047464531 139.73881455347527 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ceb04a40-f654-4124-b9f0-a9f9767e9967">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ceb04a40-f654-4124-b9f0-a9f9767e9967">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ceb04a40-f654-4124-b9f0-a9f9767e9967">
											<gml:posList>35.667350246707514 139.73879684948403 43.87 35.667350246707514 139.73879684948403 21.927 35.66734255091408 139.73881079840814 21.927 35.66734255091408 139.73881079840814 29.6 35.66730875245805 139.7388721205481 29.6 35.66730875245805 139.7388721205481 43.87 35.667350246707514 139.73879684948403 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc56b6c9-ebd8-4b47-b9e8-ddbcc9ff89af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc56b6c9-ebd8-4b47-b9e8-ddbcc9ff89af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc56b6c9-ebd8-4b47-b9e8-ddbcc9ff89af">
											<gml:posList>35.66731119468414 139.73887148805846 43.87 35.66731119468414 139.73887148805846 43.476 35.66735070873159 139.73879980922496 43.476 35.66735070873159 139.73879980922496 43.87 35.66731119468414 139.73887148805846 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5867aa91-67f2-4abf-87f3-906dcce98f19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5867aa91-67f2-4abf-87f3-906dcce98f19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5867aa91-67f2-4abf-87f3-906dcce98f19">
											<gml:posList>35.66748963357247 139.73879489572278 43.87 35.66748963357247 139.73879489572278 43.476 35.66742912906153 139.73890426576958 43.476 35.66742912906153 139.73890426576958 43.87 35.66748963357247 139.73879489572278 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ddcb3ef4-a8f5-482f-a71f-71df2a5cb76c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ddcb3ef4-a8f5-482f-a71f-71df2a5cb76c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ddcb3ef4-a8f5-482f-a71f-71df2a5cb76c">
											<gml:posList>35.66734178061775 139.73889744289062 11.8 35.66734178061775 139.73889744289062 43.87 35.66730875245805 139.7388721205481 43.87 35.66730875245805 139.7388721205481 29.6 35.66728667356148 139.73885520224943 29.6 35.66728667356148 139.73885520224943 11.8 35.66734178061775 139.73889744289062 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea2fa2a4-eabe-4492-8440-8277b9550cc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea2fa2a4-eabe-4492-8440-8277b9550cc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea2fa2a4-eabe-4492-8440-8277b9550cc7">
											<gml:posList>35.667344213830226 139.73889681041206 43.87 35.667344213830226 139.73889681041206 43.476 35.66731119468414 139.73887148805846 43.476 35.66731119468414 139.73887148805846 43.87 35.667344213830226 139.73889681041206 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92d290c6-b821-45e9-9b3d-d19112a076b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92d290c6-b821-45e9-9b3d-d19112a076b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92d290c6-b821-45e9-9b3d-d19112a076b2">
											<gml:posList>35.66740609297345 139.73888512834833 43.476 35.66740609297345 139.73888512834833 48.054 35.6674305721933 139.7389054570222 48.054 35.6674305721933 139.7389054570222 43.87 35.66742912906153 139.73890426576958 43.87 35.66742912906153 139.73890426576958 43.476 35.66740609297345 139.73888512834833 43.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb428a44-f20d-4643-849c-fea5692e7847">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb428a44-f20d-4643-849c-fea5692e7847">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb428a44-f20d-4643-849c-fea5692e7847">
											<gml:posList>35.66739268152628 139.73890937873503 48.054 35.66740609297345 139.73888512834833 48.054 35.66740609297345 139.73888512834833 43.476 35.66739268152628 139.73890937873503 43.476 35.66739268152628 139.73890937873503 48.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-193f2b68-bccb-4b29-9008-e83db67addf9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-193f2b68-bccb-4b29-9008-e83db67addf9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-193f2b68-bccb-4b29-9008-e83db67addf9">
											<gml:posList>35.66738375210736 139.73890195539522 48.054 35.66739268152628 139.73890937873503 48.054 35.66739268152628 139.73890937873503 43.476 35.66738375210736 139.73890195539522 43.476 35.66738375210736 139.73890195539522 48.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57f073cb-5f63-4301-b29c-cd069c54af99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57f073cb-5f63-4301-b29c-cd069c54af99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57f073cb-5f63-4301-b29c-cd069c54af99">
											<gml:posList>35.66737678535703 139.7389145558635 48.054 35.66738375210736 139.73890195539522 48.054 35.66738375210736 139.73890195539522 43.476 35.66737678535703 139.7389145558635 43.476 35.66737678535703 139.7389145558635 48.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7cbf954b-d967-4ed6-9336-54f6e26c2179">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cbf954b-d967-4ed6-9336-54f6e26c2179">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cbf954b-d967-4ed6-9336-54f6e26c2179">
											<gml:posList>35.6674305721933 139.7389054570222 43.87 35.6674305721933 139.7389054570222 48.054 35.667410193988886 139.73894230788406 48.054 35.667410193988886 139.73894230788406 43.87 35.6673609045837 139.73903140644805 43.87 35.6673609045837 139.73903140644805 11.8 35.667492048800256 139.73879431849048 11.8 35.667492048800256 139.73879431849048 43.87 35.6674305721933 139.7389054570222 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc3aec10-81d1-4e96-8521-c5b36d04cf03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc3aec10-81d1-4e96-8521-c5b36d04cf03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc3aec10-81d1-4e96-8521-c5b36d04cf03">
											<gml:posList>35.667410193988886 139.73894230788406 48.054 35.66737678535703 139.7389145558635 48.054 35.66737678535703 139.7389145558635 43.476 35.66740875085749 139.73894111663103 43.476 35.66740875085749 139.73894111663103 43.87 35.667410193988886 139.73894230788406 43.87 35.667410193988886 139.73894230788406 48.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c4bd4ae-ec42-44d2-adc5-fb6e0572ad20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c4bd4ae-ec42-44d2-adc5-fb6e0572ad20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c4bd4ae-ec42-44d2-adc5-fb6e0572ad20">
											<gml:posList>35.66730164889273 139.73897464531254 43.87 35.66730164889273 139.73897464531254 43.476 35.667344213830226 139.73889681041206 43.476 35.667344213830226 139.73889681041206 43.87 35.66730164889273 139.73897464531254 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45c344ff-7c47-4d05-977d-94bf9168d98e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45c344ff-7c47-4d05-977d-94bf9168d98e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45c344ff-7c47-4d05-977d-94bf9168d98e">
											<gml:posList>35.66734178061775 139.73889744289062 11.8 35.66729929669949 139.73897514514303 11.8 35.66729929669949 139.73897514514303 43.87 35.66734178061775 139.73889744289062 43.87 35.66734178061775 139.73889744289062 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee414721-7b17-42c2-b9f8-e238f14e7500">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee414721-7b17-42c2-b9f8-e238f14e7500">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee414721-7b17-42c2-b9f8-e238f14e7500">
											<gml:posList>35.66740875085749 139.73894111663103 43.87 35.66740875085749 139.73894111663103 43.476 35.66736048758206 139.7390283803774 43.476 35.66736048758206 139.7390283803774 43.87 35.66740875085749 139.73894111663103 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-792032f9-ce4f-4802-a65e-aa15055cc5d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-792032f9-ce4f-4802-a65e-aa15055cc5d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-792032f9-ce4f-4802-a65e-aa15055cc5d2">
											<gml:posList>35.66736048758206 139.7390283803774 43.87 35.66736048758206 139.7390283803774 43.476 35.66730164889273 139.73897464531254 43.476 35.66730164889273 139.73897464531254 43.87 35.66736048758206 139.7390283803774 43.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06a8884e-0641-4b64-94e1-9c5c4d824494">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06a8884e-0641-4b64-94e1-9c5c4d824494">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06a8884e-0641-4b64-94e1-9c5c4d824494">
											<gml:posList>35.66729929669949 139.73897514514303 11.8 35.6673609045837 139.73903140644805 11.8 35.6673609045837 139.73903140644805 43.87 35.66729929669949 139.73897514514303 43.87 35.66729929669949 139.73897514514303 11.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-634</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">265.7158</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>