<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_7e84eb7c-6dc7-4d0a-96c3-8428b9c9fa7a">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66936057829978 139.73783551047111 0 35.669377951905815 139.7378521031447 0 35.66938985320932 139.73783337684034 0 35.66937248861448 139.73781678415767 0 35.66936057829978 139.73783551047111 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66936057829978 139.73783551047111 21.779 35.66937248861448 139.73781678415767 21.779 35.66938985320932 139.73783337684034 21.779 35.669377951905815 139.7378521031447 21.779 35.66936057829978 139.73783551047111 21.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66936057829978 139.73783551047111 21.779 35.669377951905815 139.7378521031447 21.779 35.669377951905815 139.7378521031447 24.779 35.66936057829978 139.73783551047111 24.779 35.66936057829978 139.73783551047111 21.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669377951905815 139.7378521031447 21.779 35.66938985320932 139.73783337684034 21.779 35.66938985320932 139.73783337684034 24.779 35.669377951905815 139.7378521031447 24.779 35.669377951905815 139.7378521031447 21.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66938985320932 139.73783337684034 21.779 35.66937248861448 139.73781678415767 21.779 35.66937248861448 139.73781678415767 24.779 35.66938985320932 139.73783337684034 24.779 35.66938985320932 139.73783337684034 21.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66937248861448 139.73781678415767 21.779 35.66936057829978 139.73783551047111 21.779 35.66936057829978 139.73783551047111 24.779 35.66937248861448 139.73781678415767 24.779 35.66937248861448 139.73781678415767 21.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66936057829978 139.73783551047111 24.779 35.669377951905815 139.7378521031447 24.779 35.66938985320932 139.73783337684034 24.779 35.66937248861448 139.73781678415767 24.779 35.66936057829978 139.73783551047111 24.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c3466b06-60b1-46ee-aea1-241af6b0823f"/>
							<gml:surfaceMember xlink:href="#poly-a82bc3df-da7c-4093-913b-d89af144649e"/>
							<gml:surfaceMember xlink:href="#poly-8998b4a3-5bb9-4940-a051-430255e181cf"/>
							<gml:surfaceMember xlink:href="#poly-3bf13a84-991c-45b7-a074-ee33ede25897"/>
							<gml:surfaceMember xlink:href="#poly-00a28d4d-b111-475a-be72-22cef9a18abd"/>
							<gml:surfaceMember xlink:href="#poly-87fb83c1-fdd2-4728-9063-05e20feb9369"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c3466b06-60b1-46ee-aea1-241af6b0823f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3466b06-60b1-46ee-aea1-241af6b0823f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3466b06-60b1-46ee-aea1-241af6b0823f">
											<gml:posList>35.66936057829978 139.73783551047111 21.779 35.669372488614464 139.73781678415767 21.779 35.66938985320929 139.73783337684034 21.779 35.66937795190581 139.73785210314466 21.779 35.66936057829978 139.73783551047111 21.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a82bc3df-da7c-4093-913b-d89af144649e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a82bc3df-da7c-4093-913b-d89af144649e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a82bc3df-da7c-4093-913b-d89af144649e">
											<gml:posList>35.669372488614464 139.73781678415767 24.643 35.66936057829978 139.73783551047111 24.643 35.66937795190581 139.73785210314466 24.643 35.66938985320929 139.73783337684034 24.643 35.669372488614464 139.73781678415767 24.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8998b4a3-5bb9-4940-a051-430255e181cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8998b4a3-5bb9-4940-a051-430255e181cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8998b4a3-5bb9-4940-a051-430255e181cf">
											<gml:posList>35.66938985320929 139.73783337684034 21.779 35.669372488614464 139.73781678415767 21.779 35.669372488614464 139.73781678415767 24.643 35.66938985320929 139.73783337684034 24.643 35.66938985320929 139.73783337684034 21.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3bf13a84-991c-45b7-a074-ee33ede25897">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bf13a84-991c-45b7-a074-ee33ede25897">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bf13a84-991c-45b7-a074-ee33ede25897">
											<gml:posList>35.669372488614464 139.73781678415767 21.779 35.66936057829978 139.73783551047111 21.779 35.66936057829978 139.73783551047111 24.643 35.669372488614464 139.73781678415767 24.643 35.669372488614464 139.73781678415767 21.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00a28d4d-b111-475a-be72-22cef9a18abd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00a28d4d-b111-475a-be72-22cef9a18abd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00a28d4d-b111-475a-be72-22cef9a18abd">
											<gml:posList>35.66937795190581 139.73785210314466 21.779 35.66938985320929 139.73783337684034 21.779 35.66938985320929 139.73783337684034 24.643 35.66937795190581 139.73785210314466 24.643 35.66937795190581 139.73785210314466 21.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87fb83c1-fdd2-4728-9063-05e20feb9369">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87fb83c1-fdd2-4728-9063-05e20feb9369">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87fb83c1-fdd2-4728-9063-05e20feb9369">
											<gml:posList>35.66936057829978 139.73783551047111 21.779 35.66937795190581 139.73785210314466 21.779 35.66937795190581 139.73785210314466 24.643 35.66936057829978 139.73783551047111 24.643 35.66936057829978 139.73783551047111 21.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3058</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>