<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_7f6f023f-14a0-467d-a5b8-f3f7fd3f32ba">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">23.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67291782299851 139.73873051144403 0 35.672906794659355 139.73873619136737 0 35.6729277003025 139.73879715503492 0 35.67295736740093 139.73878939846813 0 35.673032280237024 139.73869729174007 0 35.67307260075347 139.73867705090373 0 35.673015089189 139.73851159621913 0 35.67290650878706 139.73856751001063 0 35.67294840154499 139.7386897023115 0 35.67291051415653 139.73870921116205 0 35.67291782299851 139.73873051144403 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67291782299851 139.73873051144403 8.01 35.67291051415653 139.73870921116205 8.01 35.67294840154499 139.7386897023115 8.01 35.67290650878706 139.73856751001063 8.01 35.673015089189 139.73851159621913 8.01 35.67307260075347 139.73867705090373 8.01 35.673032280237024 139.73869729174007 8.01 35.67295736740093 139.73878939846813 8.01 35.6729277003025 139.73879715503492 8.01 35.672906794659355 139.73873619136737 8.01 35.67291782299851 139.73873051144403 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67291782299851 139.73873051144403 8.01 35.672906794659355 139.73873619136737 8.01 35.672906794659355 139.73873619136737 31.559999999999995 35.67291782299851 139.73873051144403 31.559999999999995 35.67291782299851 139.73873051144403 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672906794659355 139.73873619136737 8.01 35.6729277003025 139.73879715503492 8.01 35.6729277003025 139.73879715503492 31.559999999999995 35.672906794659355 139.73873619136737 31.559999999999995 35.672906794659355 139.73873619136737 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6729277003025 139.73879715503492 8.01 35.67295736740093 139.73878939846813 8.01 35.67295736740093 139.73878939846813 31.559999999999995 35.6729277003025 139.73879715503492 31.559999999999995 35.6729277003025 139.73879715503492 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67295736740093 139.73878939846813 8.01 35.673032280237024 139.73869729174007 8.01 35.673032280237024 139.73869729174007 31.559999999999995 35.67295736740093 139.73878939846813 31.559999999999995 35.67295736740093 139.73878939846813 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673032280237024 139.73869729174007 8.01 35.67307260075347 139.73867705090373 8.01 35.67307260075347 139.73867705090373 31.559999999999995 35.673032280237024 139.73869729174007 31.559999999999995 35.673032280237024 139.73869729174007 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67307260075347 139.73867705090373 8.01 35.673015089189 139.73851159621913 8.01 35.673015089189 139.73851159621913 31.559999999999995 35.67307260075347 139.73867705090373 31.559999999999995 35.67307260075347 139.73867705090373 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673015089189 139.73851159621913 8.01 35.67290650878706 139.73856751001063 8.01 35.67290650878706 139.73856751001063 31.559999999999995 35.673015089189 139.73851159621913 31.559999999999995 35.673015089189 139.73851159621913 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67290650878706 139.73856751001063 8.01 35.67294840154499 139.7386897023115 8.01 35.67294840154499 139.7386897023115 31.559999999999995 35.67290650878706 139.73856751001063 31.559999999999995 35.67290650878706 139.73856751001063 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67294840154499 139.7386897023115 8.01 35.67291051415653 139.73870921116205 8.01 35.67291051415653 139.73870921116205 31.559999999999995 35.67294840154499 139.7386897023115 31.559999999999995 35.67294840154499 139.7386897023115 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67291051415653 139.73870921116205 8.01 35.67291782299851 139.73873051144403 8.01 35.67291782299851 139.73873051144403 31.559999999999995 35.67291051415653 139.73870921116205 31.559999999999995 35.67291051415653 139.73870921116205 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67291782299851 139.73873051144403 31.559999999999995 35.672906794659355 139.73873619136737 31.559999999999995 35.6729277003025 139.73879715503492 31.559999999999995 35.67295736740093 139.73878939846813 31.559999999999995 35.673032280237024 139.73869729174007 31.559999999999995 35.67307260075347 139.73867705090373 31.559999999999995 35.673015089189 139.73851159621913 31.559999999999995 35.67290650878706 139.73856751001063 31.559999999999995 35.67294840154499 139.7386897023115 31.559999999999995 35.67291051415653 139.73870921116205 31.559999999999995 35.67291782299851 139.73873051144403 31.559999999999995</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-465512fd-b339-44f1-b67e-0bdb26db0121"/>
							<gml:surfaceMember xlink:href="#poly-8c8c8949-c627-4180-814f-1757b2d6537c"/>
							<gml:surfaceMember xlink:href="#poly-ecc585da-50b7-4df7-a127-afe9e9305a06"/>
							<gml:surfaceMember xlink:href="#poly-027680c2-ef6b-4375-b825-6cefa6f51e7e"/>
							<gml:surfaceMember xlink:href="#poly-e929f95d-9df2-4672-b110-4ae440325c00"/>
							<gml:surfaceMember xlink:href="#poly-0580660b-ff45-4780-a227-a9e27dd07260"/>
							<gml:surfaceMember xlink:href="#poly-f807fcca-a083-489d-b043-64d0e68a743b"/>
							<gml:surfaceMember xlink:href="#poly-cc04ba0a-3970-48ab-b10e-feaae99c609b"/>
							<gml:surfaceMember xlink:href="#poly-4ef363d0-1a0a-42b0-b5cb-ee9218a37f12"/>
							<gml:surfaceMember xlink:href="#poly-602037d2-bb5b-40c0-b4be-50f24aa6c930"/>
							<gml:surfaceMember xlink:href="#poly-240d1326-2dbd-4f58-955b-ed55220737eb"/>
							<gml:surfaceMember xlink:href="#poly-b708fced-ab74-4bc7-bcd7-22573987f8ea"/>
							<gml:surfaceMember xlink:href="#poly-66ecb443-191a-441e-a034-ce7f9600364f"/>
							<gml:surfaceMember xlink:href="#poly-2c602788-a4c4-4790-ab24-f33c88d128f0"/>
							<gml:surfaceMember xlink:href="#poly-e2d020c8-8509-4f54-a74a-913b5ae26ef7"/>
							<gml:surfaceMember xlink:href="#poly-f2d6fb38-a23e-4197-9690-7c77450e5d8a"/>
							<gml:surfaceMember xlink:href="#poly-2ef6c5a5-73c5-40cc-b546-ed279d3ce26b"/>
							<gml:surfaceMember xlink:href="#poly-7af90367-edfb-4ff7-ba08-39a1df277b40"/>
							<gml:surfaceMember xlink:href="#poly-2d9d136c-4cea-4581-b861-e5ad499adf6f"/>
							<gml:surfaceMember xlink:href="#poly-db816383-9ade-4e3e-8ccf-367c79c9ea55"/>
							<gml:surfaceMember xlink:href="#poly-9d962441-b460-4643-8a06-c4fd31470700"/>
							<gml:surfaceMember xlink:href="#poly-deeb1826-9bc8-4667-8bb0-596153733cfe"/>
							<gml:surfaceMember xlink:href="#poly-f45a1841-5504-437f-85d9-fde13adef23f"/>
							<gml:surfaceMember xlink:href="#poly-4d2ef9d4-b9f7-4dbf-8b33-0d1f335a462d"/>
							<gml:surfaceMember xlink:href="#poly-446b2796-2042-49bb-b23b-6c0fc626cb59"/>
							<gml:surfaceMember xlink:href="#poly-92718451-45da-48ac-863b-e47b896b2c00"/>
							<gml:surfaceMember xlink:href="#poly-13cda06b-2641-4e07-8377-3346ebfa5d0b"/>
							<gml:surfaceMember xlink:href="#poly-cd52a8da-c906-4f7e-b2a7-4e7fce808606"/>
							<gml:surfaceMember xlink:href="#poly-a4d5fb8c-c205-4a34-8013-94be962f0698"/>
							<gml:surfaceMember xlink:href="#poly-6439eb3d-82a1-474b-91e1-995955920b47"/>
							<gml:surfaceMember xlink:href="#poly-1b341159-22bb-4dcb-b202-53e24c7a46c5"/>
							<gml:surfaceMember xlink:href="#poly-ed89760f-7c4e-44c4-9201-6640789496a3"/>
							<gml:surfaceMember xlink:href="#poly-580bb097-7eab-438b-970c-27eb636c78d3"/>
							<gml:surfaceMember xlink:href="#poly-db379c11-ae3b-4d1e-a21f-41b17fba6d44"/>
							<gml:surfaceMember xlink:href="#poly-dd873403-010e-43a1-ba25-4bc2ef89b1e6"/>
							<gml:surfaceMember xlink:href="#poly-20cb2cbf-5ef3-4bae-9ad7-cfbaf1373ca2"/>
							<gml:surfaceMember xlink:href="#poly-ffec48aa-ef20-4f3b-8ea8-5c59f2a56349"/>
							<gml:surfaceMember xlink:href="#poly-acfa03fd-2f05-4217-b2cf-a4d4229edb52"/>
							<gml:surfaceMember xlink:href="#poly-a46f85a8-d9de-422f-9d89-7674b2910431"/>
							<gml:surfaceMember xlink:href="#poly-ccb0c839-c8fe-4bc5-85e0-25e6ec276ea9"/>
							<gml:surfaceMember xlink:href="#poly-176ae664-0eb2-43e5-98d6-eda2970149a6"/>
							<gml:surfaceMember xlink:href="#poly-18784fab-2882-4fe2-8698-4015db7761a3"/>
							<gml:surfaceMember xlink:href="#poly-1ccdf470-1150-4630-b238-5228d6010fa3"/>
							<gml:surfaceMember xlink:href="#poly-48e2a02f-1549-4315-92be-82109ff71719"/>
							<gml:surfaceMember xlink:href="#poly-7fdb1c4f-ba3c-4872-93f1-95dfa5b2f95b"/>
							<gml:surfaceMember xlink:href="#poly-a81ffab1-2b43-44fd-a9eb-3fa47da5ca92"/>
							<gml:surfaceMember xlink:href="#poly-467e109d-9f9d-4236-94df-4698d8d8195d"/>
							<gml:surfaceMember xlink:href="#poly-8282db18-9c6a-47b9-b4b5-2e6ce4f96671"/>
							<gml:surfaceMember xlink:href="#poly-9dffc730-c93a-47c4-b708-07f84ba7a1a2"/>
							<gml:surfaceMember xlink:href="#poly-b57cad28-408b-4064-a0a8-0f2993ff5195"/>
							<gml:surfaceMember xlink:href="#poly-3dcb73b1-7c46-4a4c-bd47-ec4fbb017e40"/>
							<gml:surfaceMember xlink:href="#poly-651ae710-2d81-4f62-94fb-34866f0daf1e"/>
							<gml:surfaceMember xlink:href="#poly-a4f4a680-bcc8-4a79-b6b6-7108dbbd856d"/>
							<gml:surfaceMember xlink:href="#poly-dc6ee279-0094-42a3-a974-a1e7c392689c"/>
							<gml:surfaceMember xlink:href="#poly-084c7cad-4d3c-4ae9-80ce-c956e63e2243"/>
							<gml:surfaceMember xlink:href="#poly-aedf869d-e77a-418a-b962-e5b1288d0e89"/>
							<gml:surfaceMember xlink:href="#poly-e3dd60fe-e760-4056-8449-2d65fb17720c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-465512fd-b339-44f1-b67e-0bdb26db0121">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-465512fd-b339-44f1-b67e-0bdb26db0121">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-465512fd-b339-44f1-b67e-0bdb26db0121">
											<gml:posList>35.67295736740091 139.73878939846813 8.01 35.672927700302495 139.73879715503492 8.01 35.67290679465934 139.73873619136737 8.01 35.67291782299851 139.73873051144403 8.01 35.67291051415654 139.73870921116205 8.01 35.672948401545 139.73868970231146 8.01 35.672906508787065 139.73856751001063 8.01 35.673015089188986 139.73851159621913 8.01 35.67307260075347 139.7386770509037 8.01 35.67303228023699 139.73869729174004 8.01 35.67295736740091 139.73878939846813 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c8c8949-c627-4180-814f-1757b2d6537c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c8c8949-c627-4180-814f-1757b2d6537c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c8c8949-c627-4180-814f-1757b2d6537c">
											<gml:posList>35.67294607968795 139.73868292243225 39.005 35.673015089188986 139.73851159621913 23.677 35.672906508787065 139.73856751001063 23.677 35.67294607968795 139.73868292243225 39.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ecc585da-50b7-4df7-a127-afe9e9305a06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecc585da-50b7-4df7-a127-afe9e9305a06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecc585da-50b7-4df7-a127-afe9e9305a06">
											<gml:posList>35.67294607968795 139.73868292243225 39.005 35.673054487257524 139.73862494325405 39.005 35.673015089188986 139.73851159621913 23.677 35.67294607968795 139.73868292243225 39.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-027680c2-ef6b-4375-b825-6cefa6f51e7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-027680c2-ef6b-4375-b825-6cefa6f51e7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-027680c2-ef6b-4375-b825-6cefa6f51e7e">
											<gml:posList>35.67291782299851 139.73873051144403 34.919 35.67290679465934 139.73873619136737 34.919 35.67291044664725 139.7387380097485 34.919 35.67291890711821 139.73873365844833 34.919 35.67291782299851 139.73873051144403 34.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e929f95d-9df2-4672-b110-4ae440325c00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e929f95d-9df2-4672-b110-4ae440325c00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e929f95d-9df2-4672-b110-4ae440325c00">
											<gml:posList>35.672921096155854 139.73877790858236 34.919 35.67292258891979 139.7387734329449 34.919 35.67291044664725 139.7387380097485 34.919 35.67290679465934 139.73873619136737 34.919 35.672921096155854 139.73877790858236 34.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0580660b-ff45-4780-a227-a9e27dd07260">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0580660b-ff45-4780-a227-a9e27dd07260">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0580660b-ff45-4780-a227-a9e27dd07260">
											<gml:posList>35.672927700302495 139.73879715503492 28.489 35.67292846640206 139.73877411090228 34.801 35.672921096155854 139.73877790858236 34.801 35.672927700302495 139.73879715503492 28.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f807fcca-a083-489d-b043-64d0e68a743b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f807fcca-a083-489d-b043-64d0e68a743b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f807fcca-a083-489d-b043-64d0e68a743b">
											<gml:posList>35.67292846640206 139.73877411090228 34.919 35.672926823658436 139.73877125176784 34.919 35.67292258891979 139.7387734329449 34.919 35.672921096155854 139.73877790858236 34.919 35.67292846640206 139.73877411090228 34.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc04ba0a-3970-48ab-b10e-feaae99c609b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc04ba0a-3970-48ab-b10e-feaae99c609b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc04ba0a-3970-48ab-b10e-feaae99c609b">
											<gml:posList>35.67291782299851 139.73873051144403 35.934 35.67295687484412 139.73871314427052 35.934 35.672948401545 139.73868970231146 35.934 35.67291051415654 139.73870921116205 35.934 35.67291782299851 139.73873051144403 35.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ef363d0-1a0a-42b0-b5cb-ee9218a37f12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ef363d0-1a0a-42b0-b5cb-ee9218a37f12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ef363d0-1a0a-42b0-b5cb-ee9218a37f12">
											<gml:posList>35.672926823658436 139.73877125176784 34.919 35.67295902237067 139.73872749128827 34.919 35.67295538193488 139.7387174321188 34.919 35.67291890711821 139.73873365844833 34.919 35.67291044664725 139.7387380097485 34.919 35.67292258891979 139.7387734329449 34.919 35.672926823658436 139.73877125176784 34.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-602037d2-bb5b-40c0-b4be-50f24aa6c930">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-602037d2-bb5b-40c0-b4be-50f24aa6c930">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-602037d2-bb5b-40c0-b4be-50f24aa6c930">
											<gml:posList>35.67291782299851 139.73873051144403 34.919 35.67291890711821 139.73873365844833 34.919 35.67295538193488 139.7387174321188 34.919 35.67295687484412 139.73871314427052 34.919 35.67291782299851 139.73873051144403 34.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-240d1326-2dbd-4f58-955b-ed55220737eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-240d1326-2dbd-4f58-955b-ed55220737eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-240d1326-2dbd-4f58-955b-ed55220737eb">
											<gml:posList>35.672927700302495 139.73879715503492 28.489 35.67295736740091 139.73878939846813 28.489 35.67292846640206 139.73877411090228 34.801 35.672927700302495 139.73879715503492 28.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b708fced-ab74-4bc7-bcd7-22573987f8ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b708fced-ab74-4bc7-bcd7-22573987f8ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b708fced-ab74-4bc7-bcd7-22573987f8ea">
											<gml:posList>35.67292846640206 139.73877411090228 34.919 35.67296229486252 139.7387281391768 34.919 35.67295902237067 139.73872749128827 34.919 35.672926823658436 139.73877125176784 34.919 35.67292846640206 139.73877411090228 34.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66ecb443-191a-441e-a034-ce7f9600364f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66ecb443-191a-441e-a034-ce7f9600364f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66ecb443-191a-441e-a034-ce7f9600364f">
											<gml:posList>35.67296229486252 139.7387281391768 34.801 35.67292846640206 139.73877411090228 34.801 35.67295736740091 139.73878939846813 28.489 35.67296229486252 139.7387281391768 34.801</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c602788-a4c4-4790-ab24-f33c88d128f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c602788-a4c4-4790-ab24-f33c88d128f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c602788-a4c4-4790-ab24-f33c88d128f0">
											<gml:posList>35.67296229486252 139.7387281391768 34.919 35.67295687484412 139.73871314427052 34.919 35.67295538193488 139.7387174321188 34.919 35.67295902237067 139.73872749128827 34.919 35.67296229486252 139.7387281391768 34.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2d020c8-8509-4f54-a74a-913b5ae26ef7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2d020c8-8509-4f54-a74a-913b5ae26ef7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2d020c8-8509-4f54-a74a-913b5ae26ef7">
											<gml:posList>35.67295736740091 139.73878939846813 28.489 35.67298187073989 139.7387600960344 28.489 35.67296229486252 139.7387281391768 34.801 35.67295736740091 139.73878939846813 28.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f2d6fb38-a23e-4197-9690-7c77450e5d8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2d6fb38-a23e-4197-9690-7c77450e5d8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2d6fb38-a23e-4197-9690-7c77450e5d8a">
											<gml:posList>35.67298187073989 139.7387600960344 28.361 35.67299759393219 139.73874128718595 28.361 35.67298930916281 139.738716872887 28.361 35.67296229486252 139.7387281391768 28.361 35.67298187073989 139.7387600960344 28.361</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ef6c5a5-73c5-40cc-b546-ed279d3ce26b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ef6c5a5-73c5-40cc-b546-ed279d3ce26b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ef6c5a5-73c5-40cc-b546-ed279d3ce26b">
											<gml:posList>35.67294916034705 139.7386918002722 39.005 35.67296229486252 139.7387281391768 34.919 35.673012818262734 139.73870705783446 34.919 35.67294916034705 139.7386918002722 39.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7af90367-edfb-4ff7-ba08-39a1df277b40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7af90367-edfb-4ff7-ba08-39a1df277b40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7af90367-edfb-4ff7-ba08-39a1df277b40">
											<gml:posList>35.67299759393219 139.73874128718595 28.008 35.673012818262734 139.73870705783446 28.008 35.67298930916281 139.738716872887 28.008 35.67299759393219 139.73874128718595 28.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d9d136c-4cea-4581-b861-e5ad499adf6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d9d136c-4cea-4581-b861-e5ad499adf6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d9d136c-4cea-4581-b861-e5ad499adf6f">
											<gml:posList>35.673054487257524 139.73862494325405 39.005 35.67294607968795 139.73868292243225 39.005 35.672948401545 139.73868970231146 39.005 35.67294916034705 139.7386918002722 39.005 35.67305734204794 139.73863314752626 39.005 35.673054487257524 139.73862494325405 39.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-db816383-9ade-4e3e-8ccf-367c79c9ea55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db816383-9ade-4e3e-8ccf-367c79c9ea55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db816383-9ade-4e3e-8ccf-367c79c9ea55">
											<gml:posList>35.67305734204794 139.73863314752626 39.005 35.67294916034705 139.7386918002722 39.005 35.673012818262734 139.73870705783446 34.919 35.67305734204794 139.73863314752626 39.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d962441-b460-4643-8a06-c4fd31470700">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d962441-b460-4643-8a06-c4fd31470700">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d962441-b460-4643-8a06-c4fd31470700">
											<gml:posList>35.67299759393219 139.73874128718595 28.008 35.67303228023699 139.73869729174004 28.008 35.673012818262734 139.73870705783446 28.008 35.67299759393219 139.73874128718595 28.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-deeb1826-9bc8-4667-8bb0-596153733cfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-deeb1826-9bc8-4667-8bb0-596153733cfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-deeb1826-9bc8-4667-8bb0-596153733cfe">
											<gml:posList>35.673012818262734 139.73870705783446 34.919 35.67307260075347 139.7386770509037 34.919 35.67305734204794 139.73863314752626 39.005 35.673012818262734 139.73870705783446 34.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f45a1841-5504-437f-85d9-fde13adef23f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f45a1841-5504-437f-85d9-fde13adef23f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f45a1841-5504-437f-85d9-fde13adef23f">
											<gml:posList>35.67291782299851 139.73873051144403 8.01 35.67290679465934 139.73873619136737 8.01 35.67290679465934 139.73873619136737 34.919 35.67291782299851 139.73873051144403 34.919 35.67291782299851 139.73873051144403 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d2ef9d4-b9f7-4dbf-8b33-0d1f335a462d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d2ef9d4-b9f7-4dbf-8b33-0d1f335a462d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d2ef9d4-b9f7-4dbf-8b33-0d1f335a462d">
											<gml:posList>35.67291051415654 139.73870921116205 35.934 35.67291051415654 139.73870921116205 8.01 35.67291782299851 139.73873051144403 8.01 35.67291782299851 139.73873051144403 34.919 35.67291782299851 139.73873051144403 35.934 35.67291051415654 139.73870921116205 35.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-446b2796-2042-49bb-b23b-6c0fc626cb59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-446b2796-2042-49bb-b23b-6c0fc626cb59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-446b2796-2042-49bb-b23b-6c0fc626cb59">
											<gml:posList>35.672906508787065 139.73856751001063 23.677 35.672906508787065 139.73856751001063 8.01 35.672948401545 139.73868970231146 8.01 35.672906508787065 139.73856751001063 23.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92718451-45da-48ac-863b-e47b896b2c00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92718451-45da-48ac-863b-e47b896b2c00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92718451-45da-48ac-863b-e47b896b2c00">
											<gml:posList>35.672906508787065 139.73856751001063 23.677 35.672948401545 139.73868970231146 8.01 35.672948401545 139.73868970231146 35.934 35.672906508787065 139.73856751001063 23.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13cda06b-2641-4e07-8377-3346ebfa5d0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13cda06b-2641-4e07-8377-3346ebfa5d0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13cda06b-2641-4e07-8377-3346ebfa5d0b">
											<gml:posList>35.672906508787065 139.73856751001063 23.677 35.672948401545 139.73868970231146 39.005 35.67294607968795 139.73868292243225 39.005 35.672906508787065 139.73856751001063 23.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd52a8da-c906-4f7e-b2a7-4e7fce808606">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd52a8da-c906-4f7e-b2a7-4e7fce808606">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd52a8da-c906-4f7e-b2a7-4e7fce808606">
											<gml:posList>35.672906508787065 139.73856751001063 23.677 35.672948401545 139.73868970231146 35.934 35.672948401545 139.73868970231146 39.005 35.672906508787065 139.73856751001063 23.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4d5fb8c-c205-4a34-8013-94be962f0698">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4d5fb8c-c205-4a34-8013-94be962f0698">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4d5fb8c-c205-4a34-8013-94be962f0698">
											<gml:posList>35.67291051415654 139.73870921116205 8.01 35.67291051415654 139.73870921116205 35.934 35.672948401545 139.73868970231146 35.934 35.672948401545 139.73868970231146 8.01 35.67291051415654 139.73870921116205 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6439eb3d-82a1-474b-91e1-995955920b47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6439eb3d-82a1-474b-91e1-995955920b47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6439eb3d-82a1-474b-91e1-995955920b47">
											<gml:posList>35.67295687484412 139.73871314427052 34.919 35.67295687484412 139.73871314427052 35.934 35.67291782299851 139.73873051144403 35.934 35.67291782299851 139.73873051144403 34.919 35.67295687484412 139.73871314427052 34.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b341159-22bb-4dcb-b202-53e24c7a46c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b341159-22bb-4dcb-b202-53e24c7a46c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b341159-22bb-4dcb-b202-53e24c7a46c5">
											<gml:posList>35.672948401545 139.73868970231146 35.934 35.67295687484412 139.73871314427052 35.934 35.672948401545 139.73868970231146 39.005 35.672948401545 139.73868970231146 35.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed89760f-7c4e-44c4-9201-6640789496a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed89760f-7c4e-44c4-9201-6640789496a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed89760f-7c4e-44c4-9201-6640789496a3">
											<gml:posList>35.67295687484412 139.73871314427052 35.934 35.67296229486252 139.7387281391768 34.919 35.672948401545 139.73868970231146 39.005 35.67295687484412 139.73871314427052 35.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-580bb097-7eab-438b-970c-27eb636c78d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-580bb097-7eab-438b-970c-27eb636c78d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-580bb097-7eab-438b-970c-27eb636c78d3">
											<gml:posList>35.67296229486252 139.7387281391768 34.919 35.67294916034705 139.7386918002722 39.005 35.672948401545 139.73868970231146 39.005 35.67296229486252 139.7387281391768 34.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db379c11-ae3b-4d1e-a21f-41b17fba6d44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db379c11-ae3b-4d1e-a21f-41b17fba6d44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db379c11-ae3b-4d1e-a21f-41b17fba6d44">
											<gml:posList>35.67295687484412 139.73871314427052 35.934 35.67295687484412 139.73871314427052 34.919 35.67296229486252 139.7387281391768 34.919 35.67295687484412 139.73871314427052 35.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd873403-010e-43a1-ba25-4bc2ef89b1e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd873403-010e-43a1-ba25-4bc2ef89b1e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd873403-010e-43a1-ba25-4bc2ef89b1e6">
											<gml:posList>35.672906508787065 139.73856751001063 8.01 35.672906508787065 139.73856751001063 23.677 35.673015089188986 139.73851159621913 23.677 35.672906508787065 139.73856751001063 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20cb2cbf-5ef3-4bae-9ad7-cfbaf1373ca2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20cb2cbf-5ef3-4bae-9ad7-cfbaf1373ca2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20cb2cbf-5ef3-4bae-9ad7-cfbaf1373ca2">
											<gml:posList>35.672906508787065 139.73856751001063 8.01 35.673015089188986 139.73851159621913 23.677 35.673015089188986 139.73851159621913 8.01 35.672906508787065 139.73856751001063 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffec48aa-ef20-4f3b-8ea8-5c59f2a56349">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffec48aa-ef20-4f3b-8ea8-5c59f2a56349">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffec48aa-ef20-4f3b-8ea8-5c59f2a56349">
											<gml:posList>35.67296229486252 139.7387281391768 34.801 35.67296229486252 139.7387281391768 28.361 35.67298930916281 139.738716872887 28.361 35.67296229486252 139.7387281391768 34.919 35.67296229486252 139.7387281391768 34.801</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-acfa03fd-2f05-4217-b2cf-a4d4229edb52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-acfa03fd-2f05-4217-b2cf-a4d4229edb52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-acfa03fd-2f05-4217-b2cf-a4d4229edb52">
											<gml:posList>35.673012818262734 139.73870705783446 28.008 35.67296229486252 139.7387281391768 34.919 35.67298930916281 139.738716872887 28.361 35.673012818262734 139.73870705783446 28.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a46f85a8-d9de-422f-9d89-7674b2910431">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a46f85a8-d9de-422f-9d89-7674b2910431">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a46f85a8-d9de-422f-9d89-7674b2910431">
											<gml:posList>35.673012818262734 139.73870705783446 28.008 35.673012818262734 139.73870705783446 34.919 35.67296229486252 139.7387281391768 34.919 35.673012818262734 139.73870705783446 28.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccb0c839-c8fe-4bc5-85e0-25e6ec276ea9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccb0c839-c8fe-4bc5-85e0-25e6ec276ea9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccb0c839-c8fe-4bc5-85e0-25e6ec276ea9">
											<gml:posList>35.67298930916281 139.738716872887 28.008 35.67298930916281 139.738716872887 28.361 35.67299759393219 139.73874128718595 28.361 35.67299759393219 139.73874128718595 28.008 35.67298930916281 139.738716872887 28.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-176ae664-0eb2-43e5-98d6-eda2970149a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-176ae664-0eb2-43e5-98d6-eda2970149a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-176ae664-0eb2-43e5-98d6-eda2970149a6">
											<gml:posList>35.673012818262734 139.73870705783446 28.008 35.67298930916281 139.738716872887 28.361 35.67298930916281 139.738716872887 28.008 35.673012818262734 139.73870705783446 28.008</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18784fab-2882-4fe2-8698-4015db7761a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18784fab-2882-4fe2-8698-4015db7761a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18784fab-2882-4fe2-8698-4015db7761a3">
											<gml:posList>35.67303228023699 139.73869729174004 8.01 35.67303228023699 139.73869729174004 28.008 35.67299759393219 139.73874128718595 28.008 35.67303228023699 139.73869729174004 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ccdf470-1150-4630-b238-5228d6010fa3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ccdf470-1150-4630-b238-5228d6010fa3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ccdf470-1150-4630-b238-5228d6010fa3">
											<gml:posList>35.673015089188986 139.73851159621913 23.677 35.673054487257524 139.73862494325405 39.005 35.67305734204794 139.73863314752626 39.005 35.673015089188986 139.73851159621913 23.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48e2a02f-1549-4315-92be-82109ff71719">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48e2a02f-1549-4315-92be-82109ff71719">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48e2a02f-1549-4315-92be-82109ff71719">
											<gml:posList>35.67307260075347 139.7386770509037 34.919 35.673012818262734 139.73870705783446 34.919 35.673012818262734 139.73870705783446 28.008 35.67303228023699 139.73869729174004 28.008 35.67303228023699 139.73869729174004 8.01 35.67307260075347 139.7386770509037 8.01 35.67307260075347 139.7386770509037 34.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7fdb1c4f-ba3c-4872-93f1-95dfa5b2f95b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fdb1c4f-ba3c-4872-93f1-95dfa5b2f95b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fdb1c4f-ba3c-4872-93f1-95dfa5b2f95b">
											<gml:posList>35.673015089188986 139.73851159621913 23.677 35.67305734204794 139.73863314752626 39.005 35.67307260075347 139.7386770509037 34.919 35.673015089188986 139.73851159621913 23.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a81ffab1-2b43-44fd-a9eb-3fa47da5ca92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a81ffab1-2b43-44fd-a9eb-3fa47da5ca92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a81ffab1-2b43-44fd-a9eb-3fa47da5ca92">
											<gml:posList>35.673015089188986 139.73851159621913 23.677 35.67307260075347 139.7386770509037 34.919 35.67307260075347 139.7386770509037 8.01 35.673015089188986 139.73851159621913 23.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-467e109d-9f9d-4236-94df-4698d8d8195d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-467e109d-9f9d-4236-94df-4698d8d8195d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-467e109d-9f9d-4236-94df-4698d8d8195d">
											<gml:posList>35.673015089188986 139.73851159621913 23.677 35.67307260075347 139.7386770509037 8.01 35.673015089188986 139.73851159621913 8.01 35.673015089188986 139.73851159621913 23.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8282db18-9c6a-47b9-b4b5-2e6ce4f96671">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8282db18-9c6a-47b9-b4b5-2e6ce4f96671">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8282db18-9c6a-47b9-b4b5-2e6ce4f96671">
											<gml:posList>35.67295736740091 139.73878939846813 28.489 35.67295736740091 139.73878939846813 8.01 35.67303228023699 139.73869729174004 8.01 35.67295736740091 139.73878939846813 28.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9dffc730-c93a-47c4-b708-07f84ba7a1a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dffc730-c93a-47c4-b708-07f84ba7a1a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dffc730-c93a-47c4-b708-07f84ba7a1a2">
											<gml:posList>35.67295736740091 139.73878939846813 28.489 35.67303228023699 139.73869729174004 8.01 35.67299759393219 139.73874128718595 28.008 35.67295736740091 139.73878939846813 28.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b57cad28-408b-4064-a0a8-0f2993ff5195">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b57cad28-408b-4064-a0a8-0f2993ff5195">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b57cad28-408b-4064-a0a8-0f2993ff5195">
											<gml:posList>35.67296229486252 139.7387281391768 28.361 35.67296229486252 139.7387281391768 34.801 35.67298187073989 139.7387600960344 28.489 35.67298187073989 139.7387600960344 28.361 35.67296229486252 139.7387281391768 28.361</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3dcb73b1-7c46-4a4c-bd47-ec4fbb017e40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3dcb73b1-7c46-4a4c-bd47-ec4fbb017e40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3dcb73b1-7c46-4a4c-bd47-ec4fbb017e40">
											<gml:posList>35.67298187073989 139.7387600960344 28.361 35.67299759393219 139.73874128718595 28.008 35.67299759393219 139.73874128718595 28.361 35.67298187073989 139.7387600960344 28.361</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-651ae710-2d81-4f62-94fb-34866f0daf1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-651ae710-2d81-4f62-94fb-34866f0daf1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-651ae710-2d81-4f62-94fb-34866f0daf1e">
											<gml:posList>35.67292846640206 139.73877411090228 34.919 35.67292846640206 139.73877411090228 34.801 35.67296229486252 139.7387281391768 34.801 35.67296229486252 139.7387281391768 34.919 35.67292846640206 139.73877411090228 34.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4f4a680-bcc8-4a79-b6b6-7108dbbd856d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4f4a680-bcc8-4a79-b6b6-7108dbbd856d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4f4a680-bcc8-4a79-b6b6-7108dbbd856d">
											<gml:posList>35.67298187073989 139.7387600960344 28.361 35.67295736740091 139.73878939846813 28.489 35.67299759393219 139.73874128718595 28.008 35.67298187073989 139.7387600960344 28.361</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc6ee279-0094-42a3-a974-a1e7c392689c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc6ee279-0094-42a3-a974-a1e7c392689c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc6ee279-0094-42a3-a974-a1e7c392689c">
											<gml:posList>35.672927700302495 139.73879715503492 8.01 35.672927700302495 139.73879715503492 28.489 35.672921096155854 139.73877790858236 34.801 35.672921096155854 139.73877790858236 34.919 35.67290679465934 139.73873619136737 34.919 35.67290679465934 139.73873619136737 8.01 35.672927700302495 139.73879715503492 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-084c7cad-4d3c-4ae9-80ce-c956e63e2243">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-084c7cad-4d3c-4ae9-80ce-c956e63e2243">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-084c7cad-4d3c-4ae9-80ce-c956e63e2243">
											<gml:posList>35.67298187073989 139.7387600960344 28.361 35.67298187073989 139.7387600960344 28.489 35.67295736740091 139.73878939846813 28.489 35.67298187073989 139.7387600960344 28.361</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aedf869d-e77a-418a-b962-e5b1288d0e89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aedf869d-e77a-418a-b962-e5b1288d0e89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aedf869d-e77a-418a-b962-e5b1288d0e89">
											<gml:posList>35.672921096155854 139.73877790858236 34.801 35.67292846640206 139.73877411090228 34.801 35.67292846640206 139.73877411090228 34.919 35.672921096155854 139.73877790858236 34.919 35.672921096155854 139.73877790858236 34.801</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3dd60fe-e760-4056-8449-2d65fb17720c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3dd60fe-e760-4056-8449-2d65fb17720c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3dd60fe-e760-4056-8449-2d65fb17720c">
											<gml:posList>35.672927700302495 139.73879715503492 8.01 35.67295736740091 139.73878939846813 8.01 35.67295736740091 139.73878939846813 28.489 35.672927700302495 139.73879715503492 28.489 35.672927700302495 139.73879715503492 8.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5029</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">345.40815</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.09</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>