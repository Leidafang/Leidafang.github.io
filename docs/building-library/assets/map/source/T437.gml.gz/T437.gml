<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_7fb94eca-e627-4d75-a8bc-a752c12ad629">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">4.1</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66980055859072 139.73806564170417 0 35.66966572493185 139.73811470326456 0 35.66967186531991 139.73814008005186 0 35.66980670800272 139.73809101851964 0 35.66980055859072 139.73806564170417 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66980055859072 139.73806564170417 20.417 35.66980670800272 139.73809101851964 20.417 35.66967186531991 139.73814008005186 20.417 35.66966572493185 139.73811470326456 20.417 35.66980055859072 139.73806564170417 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66980055859072 139.73806564170417 20.417 35.66966572493185 139.73811470326456 20.417 35.66966572493185 139.73811470326456 24.47 35.66980055859072 139.73806564170417 24.47 35.66980055859072 139.73806564170417 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66966572493185 139.73811470326456 20.417 35.66967186531991 139.73814008005186 20.417 35.66967186531991 139.73814008005186 24.47 35.66966572493185 139.73811470326456 24.47 35.66966572493185 139.73811470326456 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66967186531991 139.73814008005186 20.417 35.66980670800272 139.73809101851964 20.417 35.66980670800272 139.73809101851964 24.47 35.66967186531991 139.73814008005186 24.47 35.66967186531991 139.73814008005186 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66980670800272 139.73809101851964 20.417 35.66980055859072 139.73806564170417 20.417 35.66980055859072 139.73806564170417 24.47 35.66980670800272 139.73809101851964 24.47 35.66980670800272 139.73809101851964 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66980055859072 139.73806564170417 24.47 35.66966572493185 139.73811470326456 24.47 35.66967186531991 139.73814008005186 24.47 35.66980670800272 139.73809101851964 24.47 35.66980055859072 139.73806564170417 24.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fc853de9-83ee-4dab-8571-3f2b674bbbbb"/>
							<gml:surfaceMember xlink:href="#poly-d0e130fe-ea63-40ad-b903-21949bec6936"/>
							<gml:surfaceMember xlink:href="#poly-a2205f37-328e-4604-8b45-c396c8721756"/>
							<gml:surfaceMember xlink:href="#poly-0dd96f4e-1473-4f05-bfda-1061aff126e2"/>
							<gml:surfaceMember xlink:href="#poly-4d39b679-eeff-45fd-ad39-69a23f180e4b"/>
							<gml:surfaceMember xlink:href="#poly-90a3c837-eb33-41ed-aece-99ad0398f047"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fc853de9-83ee-4dab-8571-3f2b674bbbbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc853de9-83ee-4dab-8571-3f2b674bbbbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc853de9-83ee-4dab-8571-3f2b674bbbbb">
											<gml:posList>35.669800558590694 139.7380656417042 20.417 35.66980670800272 139.7380910185196 20.417 35.669671865319884 139.73814008005183 20.417 35.66966572493185 139.73811470326456 20.417 35.669800558590694 139.7380656417042 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0e130fe-ea63-40ad-b903-21949bec6936">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0e130fe-ea63-40ad-b903-21949bec6936">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0e130fe-ea63-40ad-b903-21949bec6936">
											<gml:posList>35.669671865319884 139.73814008005183 24.077 35.66980670800272 139.7380910185196 24.077 35.669800558590694 139.7380656417042 24.077 35.66966572493185 139.73811470326456 24.077 35.669671865319884 139.73814008005183 24.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2205f37-328e-4604-8b45-c396c8721756">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2205f37-328e-4604-8b45-c396c8721756">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2205f37-328e-4604-8b45-c396c8721756">
											<gml:posList>35.66980670800272 139.7380910185196 20.417 35.669800558590694 139.7380656417042 20.417 35.669800558590694 139.7380656417042 24.077 35.66980670800272 139.7380910185196 24.077 35.66980670800272 139.7380910185196 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0dd96f4e-1473-4f05-bfda-1061aff126e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dd96f4e-1473-4f05-bfda-1061aff126e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dd96f4e-1473-4f05-bfda-1061aff126e2">
											<gml:posList>35.669800558590694 139.7380656417042 20.417 35.66966572493185 139.73811470326456 20.417 35.66966572493185 139.73811470326456 24.077 35.669800558590694 139.7380656417042 24.077 35.669800558590694 139.7380656417042 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d39b679-eeff-45fd-ad39-69a23f180e4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d39b679-eeff-45fd-ad39-69a23f180e4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d39b679-eeff-45fd-ad39-69a23f180e4b">
											<gml:posList>35.669671865319884 139.73814008005183 20.417 35.66980670800272 139.7380910185196 20.417 35.66980670800272 139.7380910185196 24.077 35.669671865319884 139.73814008005183 24.077 35.669671865319884 139.73814008005183 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90a3c837-eb33-41ed-aece-99ad0398f047">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90a3c837-eb33-41ed-aece-99ad0398f047">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90a3c837-eb33-41ed-aece-99ad0398f047">
											<gml:posList>35.66966572493185 139.73811470326456 20.417 35.669671865319884 139.73814008005183 20.417 35.669671865319884 139.73814008005183 24.077 35.66966572493185 139.73811470326456 24.077 35.66966572493185 139.73811470326456 20.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1662</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>