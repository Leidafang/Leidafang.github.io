<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_802dde37-5ab1-4fd4-aa32-784091cc8523">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">11.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67021192658657 139.74156990273872 0 35.67021534565468 139.74144364033856 0 35.6701829852925 139.7414422414156 0 35.67017956622574 139.74156850376485 0 35.67021192658657 139.74156990273872 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021192658657 139.74156990273872 8.439 35.67017956622574 139.74156850376485 8.439 35.6701829852925 139.7414422414156 8.439 35.67021534565468 139.74144364033856 8.439 35.67021192658657 139.74156990273872 8.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021192658657 139.74156990273872 8.439 35.67021534565468 139.74144364033856 8.439 35.67021534565468 139.74144364033856 20.13 35.67021192658657 139.74156990273872 20.13 35.67021192658657 139.74156990273872 8.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021534565468 139.74144364033856 8.439 35.6701829852925 139.7414422414156 8.439 35.6701829852925 139.7414422414156 20.13 35.67021534565468 139.74144364033856 20.13 35.67021534565468 139.74144364033856 8.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6701829852925 139.7414422414156 8.439 35.67017956622574 139.74156850376485 8.439 35.67017956622574 139.74156850376485 20.13 35.6701829852925 139.7414422414156 20.13 35.6701829852925 139.7414422414156 8.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67017956622574 139.74156850376485 8.439 35.67021192658657 139.74156990273872 8.439 35.67021192658657 139.74156990273872 20.13 35.67017956622574 139.74156850376485 20.13 35.67017956622574 139.74156850376485 8.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021192658657 139.74156990273872 20.13 35.67021534565468 139.74144364033856 20.13 35.6701829852925 139.7414422414156 20.13 35.67017956622574 139.74156850376485 20.13 35.67021192658657 139.74156990273872 20.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-786efd56-2ad0-4f71-9ff4-a81f32a51820"/>
							<gml:surfaceMember xlink:href="#poly-9b6bc579-61ee-4898-874d-314cacd67a7b"/>
							<gml:surfaceMember xlink:href="#poly-0b6f2652-8e5b-4f10-981e-98177423bdfb"/>
							<gml:surfaceMember xlink:href="#poly-9b9c76c7-1bf9-4b6c-ac12-fd2aa57fc97f"/>
							<gml:surfaceMember xlink:href="#poly-96b14cbb-51d0-4e2e-ac3c-9aef89e4c72d"/>
							<gml:surfaceMember xlink:href="#poly-33be45ef-e5d3-4da9-9ef5-0ff2aaf01b9d"/>
							<gml:surfaceMember xlink:href="#poly-ff5ed9d9-3edc-451e-aa09-e53a4515dd71"/>
							<gml:surfaceMember xlink:href="#poly-aa87fc11-a1fb-4516-99bb-74c7e543581e"/>
							<gml:surfaceMember xlink:href="#poly-730d420f-ba91-419f-a656-a74165ec23ea"/>
							<gml:surfaceMember xlink:href="#poly-ca7a9c2d-e386-404a-add6-a2ceac4007b0"/>
							<gml:surfaceMember xlink:href="#poly-ff1ef08c-3431-46e0-98b0-50e3c41816cd"/>
							<gml:surfaceMember xlink:href="#poly-1e72d6b8-aeba-4472-acf9-ef548dfe4687"/>
							<gml:surfaceMember xlink:href="#poly-1370abad-382d-42d2-80ba-5fe72cf68818"/>
							<gml:surfaceMember xlink:href="#poly-f39b7211-8a2d-47ce-b0ab-ae13c2c85c48"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-786efd56-2ad0-4f71-9ff4-a81f32a51820">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-786efd56-2ad0-4f71-9ff4-a81f32a51820">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-786efd56-2ad0-4f71-9ff4-a81f32a51820">
											<gml:posList>35.67021192658655 139.74156990273872 8.439 35.67017956622571 139.74156850376485 8.439 35.6701829852925 139.7414422414156 8.439 35.6702153456547 139.74144364033856 8.439 35.67021192658655 139.74156990273872 8.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b6bc579-61ee-4898-874d-314cacd67a7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b6bc579-61ee-4898-874d-314cacd67a7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b6bc579-61ee-4898-874d-314cacd67a7b">
											<gml:posList>35.6701829852925 139.7414422414156 21.331 35.67018514172189 139.74144505573344 21.331 35.67021304915306 139.74144626092857 21.331 35.6702153456547 139.74144364033856 21.331 35.6701829852925 139.7414422414156 21.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b6f2652-8e5b-4f10-981e-98177423bdfb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b6f2652-8e5b-4f10-981e-98177423bdfb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b6f2652-8e5b-4f10-981e-98177423bdfb">
											<gml:posList>35.67017956622571 139.74156850376485 21.331 35.670181862730026 139.74156588317942 21.331 35.67018514172189 139.74144505573344 21.331 35.6701829852925 139.7414422414156 21.331 35.67017956622571 139.74156850376485 21.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b9c76c7-1bf9-4b6c-ac12-fd2aa57fc97f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b9c76c7-1bf9-4b6c-ac12-fd2aa57fc97f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b9c76c7-1bf9-4b6c-ac12-fd2aa57fc97f">
											<gml:posList>35.67021304915306 139.74144626092857 20.752 35.67018514172189 139.74144505573344 20.752 35.670181862730026 139.74156588317942 20.752 35.67020977016008 139.74156708841653 20.752 35.67021304915306 139.74144626092857 20.752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-96b14cbb-51d0-4e2e-ac3c-9aef89e4c72d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96b14cbb-51d0-4e2e-ac3c-9aef89e4c72d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96b14cbb-51d0-4e2e-ac3c-9aef89e4c72d">
											<gml:posList>35.6702153456547 139.74144364033856 21.331 35.67021304915306 139.74144626092857 21.331 35.67020977016008 139.74156708841653 21.331 35.67021192658655 139.74156990273872 21.331 35.6702153456547 139.74144364033856 21.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-33be45ef-e5d3-4da9-9ef5-0ff2aaf01b9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33be45ef-e5d3-4da9-9ef5-0ff2aaf01b9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33be45ef-e5d3-4da9-9ef5-0ff2aaf01b9d">
											<gml:posList>35.67021192658655 139.74156990273872 21.331 35.67020977016008 139.74156708841653 21.331 35.670181862730026 139.74156588317942 21.331 35.67017956622571 139.74156850376485 21.331 35.67021192658655 139.74156990273872 21.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff5ed9d9-3edc-451e-aa09-e53a4515dd71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff5ed9d9-3edc-451e-aa09-e53a4515dd71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff5ed9d9-3edc-451e-aa09-e53a4515dd71">
											<gml:posList>35.6701829852925 139.7414422414156 8.439 35.67017956622571 139.74156850376485 8.439 35.67017956622571 139.74156850376485 21.331 35.6701829852925 139.7414422414156 21.331 35.6701829852925 139.7414422414156 8.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa87fc11-a1fb-4516-99bb-74c7e543581e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa87fc11-a1fb-4516-99bb-74c7e543581e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa87fc11-a1fb-4516-99bb-74c7e543581e">
											<gml:posList>35.670181862730026 139.74156588317942 21.331 35.670181862730026 139.74156588317942 20.752 35.67018514172189 139.74144505573344 20.752 35.67018514172189 139.74144505573344 21.331 35.670181862730026 139.74156588317942 21.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-730d420f-ba91-419f-a656-a74165ec23ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-730d420f-ba91-419f-a656-a74165ec23ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-730d420f-ba91-419f-a656-a74165ec23ea">
											<gml:posList>35.67017956622571 139.74156850376485 8.439 35.67021192658655 139.74156990273872 8.439 35.67021192658655 139.74156990273872 21.331 35.67017956622571 139.74156850376485 21.331 35.67017956622571 139.74156850376485 8.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca7a9c2d-e386-404a-add6-a2ceac4007b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca7a9c2d-e386-404a-add6-a2ceac4007b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca7a9c2d-e386-404a-add6-a2ceac4007b0">
											<gml:posList>35.67020977016008 139.74156708841653 21.331 35.67020977016008 139.74156708841653 20.752 35.670181862730026 139.74156588317942 20.752 35.670181862730026 139.74156588317942 21.331 35.67020977016008 139.74156708841653 21.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff1ef08c-3431-46e0-98b0-50e3c41816cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff1ef08c-3431-46e0-98b0-50e3c41816cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff1ef08c-3431-46e0-98b0-50e3c41816cd">
											<gml:posList>35.67018514172189 139.74144505573344 21.331 35.67018514172189 139.74144505573344 20.752 35.67021304915306 139.74144626092857 20.752 35.67021304915306 139.74144626092857 21.331 35.67018514172189 139.74144505573344 21.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e72d6b8-aeba-4472-acf9-ef548dfe4687">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e72d6b8-aeba-4472-acf9-ef548dfe4687">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e72d6b8-aeba-4472-acf9-ef548dfe4687">
											<gml:posList>35.6702153456547 139.74144364033856 8.439 35.6701829852925 139.7414422414156 8.439 35.6701829852925 139.7414422414156 21.331 35.6702153456547 139.74144364033856 21.331 35.6702153456547 139.74144364033856 8.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1370abad-382d-42d2-80ba-5fe72cf68818">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1370abad-382d-42d2-80ba-5fe72cf68818">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1370abad-382d-42d2-80ba-5fe72cf68818">
											<gml:posList>35.67021304915306 139.74144626092857 21.331 35.67021304915306 139.74144626092857 20.752 35.67020977016008 139.74156708841653 20.752 35.67020977016008 139.74156708841653 21.331 35.67021304915306 139.74144626092857 21.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f39b7211-8a2d-47ce-b0ab-ae13c2c85c48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f39b7211-8a2d-47ce-b0ab-ae13c2c85c48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f39b7211-8a2d-47ce-b0ab-ae13c2c85c48">
											<gml:posList>35.67021192658655 139.74156990273872 8.439 35.6702153456547 139.74144364033856 8.439 35.6702153456547 139.74144364033856 21.331 35.67021192658655 139.74156990273872 21.331 35.67021192658655 139.74156990273872 8.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9449</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">41.0844</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.13</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>