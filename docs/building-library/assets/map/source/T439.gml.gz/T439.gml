<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_80471f3f-22ca-481f-97b8-56c6cf41a008">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">25.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67170068675332 139.7381540751781 0 35.67151748818498 139.7382180304837 0 35.671554480457175 139.73837782830964 0 35.67161233094328 139.73835544600675 0 35.67165116439785 139.73851850060584 0 35.67177503276013 139.73847488633027 0 35.67170068675332 139.7381540751781 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170068675332 139.7381540751781 10.47 35.67177503276013 139.73847488633027 10.47 35.67165116439785 139.73851850060584 10.47 35.67161233094328 139.73835544600675 10.47 35.671554480457175 139.73837782830964 10.47 35.67151748818498 139.7382180304837 10.47 35.67170068675332 139.7381540751781 10.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170068675332 139.7381540751781 10.47 35.67151748818498 139.7382180304837 10.47 35.67151748818498 139.7382180304837 33.93 35.67170068675332 139.7381540751781 33.93 35.67170068675332 139.7381540751781 10.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67151748818498 139.7382180304837 10.47 35.671554480457175 139.73837782830964 10.47 35.671554480457175 139.73837782830964 33.93 35.67151748818498 139.7382180304837 33.93 35.67151748818498 139.7382180304837 10.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671554480457175 139.73837782830964 10.47 35.67161233094328 139.73835544600675 10.47 35.67161233094328 139.73835544600675 33.93 35.671554480457175 139.73837782830964 33.93 35.671554480457175 139.73837782830964 10.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67161233094328 139.73835544600675 10.47 35.67165116439785 139.73851850060584 10.47 35.67165116439785 139.73851850060584 33.93 35.67161233094328 139.73835544600675 33.93 35.67161233094328 139.73835544600675 10.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67165116439785 139.73851850060584 10.47 35.67177503276013 139.73847488633027 10.47 35.67177503276013 139.73847488633027 33.93 35.67165116439785 139.73851850060584 33.93 35.67165116439785 139.73851850060584 10.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67177503276013 139.73847488633027 10.47 35.67170068675332 139.7381540751781 10.47 35.67170068675332 139.7381540751781 33.93 35.67177503276013 139.73847488633027 33.93 35.67177503276013 139.73847488633027 10.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170068675332 139.7381540751781 33.93 35.67151748818498 139.7382180304837 33.93 35.671554480457175 139.73837782830964 33.93 35.67161233094328 139.73835544600675 33.93 35.67165116439785 139.73851850060584 33.93 35.67177503276013 139.73847488633027 33.93 35.67170068675332 139.7381540751781 33.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1f5b9e03-6994-4b91-8eda-e6d5e2ed6ffc"/>
							<gml:surfaceMember xlink:href="#poly-b9f8fab0-9235-4530-8d83-a2bde29ff45c"/>
							<gml:surfaceMember xlink:href="#poly-5970c3dc-3765-46ce-9fde-5a502101157b"/>
							<gml:surfaceMember xlink:href="#poly-5c150f4c-0875-431e-b29d-01f6130d79b1"/>
							<gml:surfaceMember xlink:href="#poly-9df94adf-51ca-4590-9a86-1c4c70539ca0"/>
							<gml:surfaceMember xlink:href="#poly-493a3837-60dc-4048-9a96-55aa3033704d"/>
							<gml:surfaceMember xlink:href="#poly-bc8fa5c4-d051-4706-a2d6-cd6c8d594ffd"/>
							<gml:surfaceMember xlink:href="#poly-4595b745-98c5-4142-bb33-3ab599496abd"/>
							<gml:surfaceMember xlink:href="#poly-1c8d5381-5e8e-4f53-a9ad-ee5bbdf55f8a"/>
							<gml:surfaceMember xlink:href="#poly-ed731918-fd18-4d02-8481-f644bd73e701"/>
							<gml:surfaceMember xlink:href="#poly-8a10b2d6-8c35-417a-a846-ffe2e779e68d"/>
							<gml:surfaceMember xlink:href="#poly-7d4d3274-1dd1-41e6-bca0-369860a2ede9"/>
							<gml:surfaceMember xlink:href="#poly-2424f207-0b48-4a87-98a7-b723a995ae28"/>
							<gml:surfaceMember xlink:href="#poly-dd982fc4-6f84-4cda-be66-49609e71dc99"/>
							<gml:surfaceMember xlink:href="#poly-ac3527b4-1803-4e56-97d4-e9ec00b72f02"/>
							<gml:surfaceMember xlink:href="#poly-0c417506-8f05-4e42-a22f-ece43099ba54"/>
							<gml:surfaceMember xlink:href="#poly-626c8b7a-7bcc-4398-923a-61f89d52d3e5"/>
							<gml:surfaceMember xlink:href="#poly-3b4a2fcc-312f-49a1-ad7f-bbd67a2ff491"/>
							<gml:surfaceMember xlink:href="#poly-3a9f8748-0148-41ed-8611-dcdcbfe10d37"/>
							<gml:surfaceMember xlink:href="#poly-f0232bab-be59-47e7-8615-3ba0141a7723"/>
							<gml:surfaceMember xlink:href="#poly-fb4c013e-2e4e-4db3-9660-9ee1ee7da924"/>
							<gml:surfaceMember xlink:href="#poly-aa752fc2-2cff-4f90-a276-1c46ed9bbe33"/>
							<gml:surfaceMember xlink:href="#poly-c318d636-5b9a-495a-b43a-6e865fbc6902"/>
							<gml:surfaceMember xlink:href="#poly-4b5bafd5-3ae5-4b23-8188-b6eb098be285"/>
							<gml:surfaceMember xlink:href="#poly-27ce938a-3c99-4823-b880-e67fe00d03eb"/>
							<gml:surfaceMember xlink:href="#poly-a88e0b32-12af-4cd9-8ad6-04898d71ed6c"/>
							<gml:surfaceMember xlink:href="#poly-088fce6b-aa0c-4992-89cd-27ac41724fd5"/>
							<gml:surfaceMember xlink:href="#poly-41ec2693-8316-4bc1-b19d-a0e5a01d77dd"/>
							<gml:surfaceMember xlink:href="#poly-b9b76476-fc34-4edf-8e78-0b9204cfb75f"/>
							<gml:surfaceMember xlink:href="#poly-894707d2-5818-4f10-a1b3-e42c1f0a9ca6"/>
							<gml:surfaceMember xlink:href="#poly-72118f4f-bd40-4b45-9ba5-f25f8b212eb5"/>
							<gml:surfaceMember xlink:href="#poly-a5bee82f-8faa-4a40-9ca7-424636c6e31a"/>
							<gml:surfaceMember xlink:href="#poly-ba7bcea6-2c31-4342-afb8-bf602c290a6f"/>
							<gml:surfaceMember xlink:href="#poly-eceedf27-67c5-459d-b54a-b5ee08f18a9a"/>
							<gml:surfaceMember xlink:href="#poly-8736961b-0d1a-43b9-bcc2-40aef2a0082e"/>
							<gml:surfaceMember xlink:href="#poly-ea01f2bb-a719-475e-8715-acfde87c6ef0"/>
							<gml:surfaceMember xlink:href="#poly-98a54360-b66d-405c-bb0d-0dabd407ae02"/>
							<gml:surfaceMember xlink:href="#poly-a380104e-e98d-4b34-b9b7-8b4d52788e67"/>
							<gml:surfaceMember xlink:href="#poly-77c4ad9e-b1f4-4fb4-9613-70bc07b9134a"/>
							<gml:surfaceMember xlink:href="#poly-964f0f83-a732-4b6a-9c54-3e9bd7e18eb3"/>
							<gml:surfaceMember xlink:href="#poly-6e0622ae-51a4-40d8-94a4-b7f2be46e325"/>
							<gml:surfaceMember xlink:href="#poly-086f08ca-ccd6-4431-a531-19f4b4f42b9a"/>
							<gml:surfaceMember xlink:href="#poly-40af0a18-5666-4c66-93fa-1dafaeff3a66"/>
							<gml:surfaceMember xlink:href="#poly-5fa85b6e-a5ee-44b3-b9a7-16b1c19d24b6"/>
							<gml:surfaceMember xlink:href="#poly-f1e9fc0c-26e3-4cfb-a56c-c26c82849144"/>
							<gml:surfaceMember xlink:href="#poly-f21a6046-b6cc-4048-93a4-4e14620de1cc"/>
							<gml:surfaceMember xlink:href="#poly-281dcd2e-2eb5-447c-9f6c-112c3b14ef94"/>
							<gml:surfaceMember xlink:href="#poly-7c3ecc76-7395-4ca0-839d-705abee783c2"/>
							<gml:surfaceMember xlink:href="#poly-a61177d4-463f-4dfb-a290-0d2622f35cef"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_80471f3f-22ca-481f-97b8-56c6cf41a008_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48706ba8-ed54-49b3-9b30-f36a72cb96fb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715720778118 139.73832393406076 40.01 35.67156677778829 139.73830115157145 40.01 35.67160223703899 139.73828877068107 40.01 35.671607537064816 139.73831155317964 40.01 35.6715720778118 139.73832393406076 40.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d357b7e0-67a5-4922-a5a0-242fa372b320">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67165794370608 139.73830250163948 33.761 35.67168000298974 139.73829448891746 33.761 35.67169582871946 139.73836001973532 33.761 35.67167376040906 139.73836802140517 33.761 35.67165794370608 139.73830250163948 33.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fcdd373-e1c0-4346-839d-c3a69bdbb611">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67157944821558 139.7383432013372 40.01 35.67157884224844 139.7383406061454 40.01 35.671593134087246 139.73833561832012 40.01 35.67159373104078 139.738338213523 40.01 35.67157944821558 139.7383432013372 40.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c1e6275-9424-4375-a954-ef76550e823f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156096575454 139.73834915516377 40.01 35.671558071543 139.73833670927556 40.01 35.6715674252138 139.7383334394979 40.01 35.6715703194344 139.73834589643383 40.01 35.67156096575454 139.73834915516377 40.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-466bb423-85db-43a3-a3e6-f975146f496c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67157944821558 139.7383432013372 40.34 35.67159373104078 139.738338213523 40.34 35.67159475305957 139.73834260878985 40.34 35.67158047023418 139.7383475966033 40.34 35.67157944821558 139.7383432013372 40.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-911958ed-7e41-4c9e-b77d-28920a8057e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-911958ed-7e41-4c9e-b77d-28920a8057e7_0">
											<gml:posList>35.671558071543 139.73833670927556 40.01 35.67156096575454 139.73834915516377 40.01 35.67156096575454 139.73834915516377 41.435 35.671558071543 139.73833670927556 41.435 35.671558071543 139.73833670927556 40.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54aa22d2-6103-405e-97c6-49e300cc0ce2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54aa22d2-6103-405e-97c6-49e300cc0ce2_0">
											<gml:posList>35.6715674252138 139.7383334394979 40.01 35.671558071543 139.73833670927556 40.01 35.671558071543 139.73833670927556 41.435 35.6715674252138 139.7383334394979 41.435 35.6715674252138 139.7383334394979 40.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3972b868-94e7-4301-a4ff-0a6fb3521ad0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3972b868-94e7-4301-a4ff-0a6fb3521ad0_0">
											<gml:posList>35.6715674252138 139.7383334394979 41.435 35.671558071543 139.73833670927556 41.435 35.67156096575454 139.73834915516377 41.435 35.6715703194344 139.73834589643383 41.435 35.6715674252138 139.7383334394979 41.435</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-570da709-34a0-42f2-a085-130b52142c81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-570da709-34a0-42f2-a085-130b52142c81_0">
											<gml:posList>35.67156096575454 139.73834915516377 40.01 35.6715703194344 139.73834589643383 40.01 35.6715703194344 139.73834589643383 41.435 35.67156096575454 139.73834915516377 41.435 35.67156096575454 139.73834915516377 40.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b70319dd-2ce3-460e-88ac-7239a3948ae0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b70319dd-2ce3-460e-88ac-7239a3948ae0_0">
											<gml:posList>35.6715703194344 139.73834589643383 40.01 35.6715674252138 139.7383334394979 40.01 35.6715674252138 139.7383334394979 41.435 35.6715703194344 139.73834589643383 41.435 35.6715703194344 139.73834589643383 40.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddf3e148-b00d-4ce0-a6d9-d58a4b15313d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddf3e148-b00d-4ce0-a6d9-d58a4b15313d_0">
											<gml:posList>35.6715720778118 139.73832393406076 40.01 35.6715720778118 139.73832393406076 42.958 35.67156677778829 139.73830115157145 42.958 35.67156677778829 139.73830115157145 40.01 35.6715720778118 139.73832393406076 40.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db37e6ff-c404-40ee-92e2-a4ac90b60dbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db37e6ff-c404-40ee-92e2-a4ac90b60dbe_0">
											<gml:posList>35.67157944821558 139.7383432013372 40.34 35.67158047023418 139.7383475966033 40.34 35.67158047023418 139.7383475966033 40.957 35.67157884224844 139.7383406061454 40.957 35.67157884224844 139.7383406061454 40.01 35.67157944821558 139.7383432013372 40.01 35.67157944821558 139.7383432013372 40.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eff012d1-2c76-47ba-aa6b-5c6702831855">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eff012d1-2c76-47ba-aa6b-5c6702831855_0">
											<gml:posList>35.67160223703899 139.73828877068107 40.01 35.67156677778829 139.73830115157145 40.01 35.67156677778829 139.73830115157145 42.958 35.67160223703899 139.73828877068107 42.958 35.67160223703899 139.73828877068107 40.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2de98f6d-ac9a-40ae-857a-f47a776ac5fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2de98f6d-ac9a-40ae-857a-f47a776ac5fd_0">
											<gml:posList>35.671593134087246 139.73833561832012 40.01 35.67157884224844 139.7383406061454 40.01 35.67157884224844 139.7383406061454 40.957 35.671593134087246 139.73833561832012 40.957 35.671593134087246 139.73833561832012 40.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4aaecaa-da70-4f64-863b-fa2fdf4104b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4aaecaa-da70-4f64-863b-fa2fdf4104b1_0">
											<gml:posList>35.67159373104078 139.738338213523 40.34 35.67157944821558 139.7383432013372 40.34 35.67157944821558 139.7383432013372 40.01 35.67159373104078 139.738338213523 40.01 35.67159373104078 139.738338213523 40.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-923ff452-cd6c-41bb-9605-4c54bc8c3528">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-923ff452-cd6c-41bb-9605-4c54bc8c3528_0">
											<gml:posList>35.671593134087246 139.73833561832012 40.957 35.67157884224844 139.7383406061454 40.957 35.67158047023418 139.7383475966033 40.957 35.67159475305957 139.73834260878985 40.957 35.671593134087246 139.73833561832012 40.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-535aa98b-18fc-4b2a-a07f-b650c5145572">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-535aa98b-18fc-4b2a-a07f-b650c5145572_0">
											<gml:posList>35.6715720778118 139.73832393406076 42.958 35.671607537064816 139.73831155317964 42.958 35.67160223703899 139.73828877068107 42.958 35.67156677778829 139.73830115157145 42.958 35.6715720778118 139.73832393406076 42.958</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdfbdc4b-1769-40ce-b490-8fa6d2eb74bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdfbdc4b-1769-40ce-b490-8fa6d2eb74bc_0">
											<gml:posList>35.67158047023418 139.7383475966033 40.34 35.67159475305957 139.73834260878985 40.34 35.67159475305957 139.73834260878985 40.957 35.67158047023418 139.7383475966033 40.957 35.67158047023418 139.7383475966033 40.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4e48a7b-2b83-4bbc-86d5-288742b34cf5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4e48a7b-2b83-4bbc-86d5-288742b34cf5_0">
											<gml:posList>35.6715720778118 139.73832393406076 40.01 35.671607537064816 139.73831155317964 40.01 35.671607537064816 139.73831155317964 42.958 35.6715720778118 139.73832393406076 42.958 35.6715720778118 139.73832393406076 40.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74a2bac5-d2e3-4417-85be-684dc8bb2826">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74a2bac5-d2e3-4417-85be-684dc8bb2826_0">
											<gml:posList>35.671593134087246 139.73833561832012 40.01 35.671593134087246 139.73833561832012 40.957 35.67159475305957 139.73834260878985 40.957 35.67159475305957 139.73834260878985 40.34 35.67159373104078 139.738338213523 40.34 35.67159373104078 139.738338213523 40.01 35.671593134087246 139.73833561832012 40.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2a74c0f-0654-4a29-aa74-c617a60419c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2a74c0f-0654-4a29-aa74-c617a60419c1_0">
											<gml:posList>35.671607537064816 139.73831155317964 40.01 35.67160223703899 139.73828877068107 40.01 35.67160223703899 139.73828877068107 42.958 35.671607537064816 139.73831155317964 42.958 35.671607537064816 139.73831155317964 40.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c39440b-ef51-484c-9b87-a14e995f6393">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c39440b-ef51-484c-9b87-a14e995f6393_0">
											<gml:posList>35.67167376040906 139.73836802140517 33.761 35.67167376040906 139.73836802140517 36.258 35.67165794370608 139.73830250163948 36.258 35.67165794370608 139.73830250163948 33.761 35.67167376040906 139.73836802140517 33.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b691b25a-9f03-49ee-8770-ae50f836240f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b691b25a-9f03-49ee-8770-ae50f836240f_0">
											<gml:posList>35.67168000298974 139.73829448891746 33.761 35.67165794370608 139.73830250163948 33.761 35.67165794370608 139.73830250163948 36.258 35.67168000298974 139.73829448891746 36.258 35.67168000298974 139.73829448891746 33.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-feb4788e-cc98-4c54-8093-560a77903f56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-feb4788e-cc98-4c54-8093-560a77903f56_0">
											<gml:posList>35.67165794370608 139.73830250163948 36.258 35.67167376040906 139.73836802140517 36.258 35.67169582871946 139.73836001973532 36.258 35.67168000298974 139.73829448891746 36.258 35.67165794370608 139.73830250163948 36.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20302ed6-79f7-4df2-89b9-012e322d50db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20302ed6-79f7-4df2-89b9-012e322d50db_0">
											<gml:posList>35.67167376040906 139.73836802140517 33.761 35.67169582871946 139.73836001973532 33.761 35.67169582871946 139.73836001973532 36.258 35.67167376040906 139.73836802140517 36.258 35.67167376040906 139.73836802140517 33.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-751cc921-da40-40c3-8945-3a90c7c04bab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-751cc921-da40-40c3-8945-3a90c7c04bab_0">
											<gml:posList>35.67169582871946 139.73836001973532 33.761 35.67168000298974 139.73829448891746 33.761 35.67168000298974 139.73829448891746 36.258 35.67169582871946 139.73836001973532 36.258 35.67169582871946 139.73836001973532 33.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_80471f3f-22ca-481f-97b8-56c6cf41a008_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ae6d891-b1c7-4ccc-92c6-e432eacf3485">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67169674137712 139.73852303097857 10.47 35.67165565003209 139.7385373294727 10.47 35.67165116439784 139.73851850060584 10.47 35.67169221938128 139.73850381552046 10.47 35.67169674137712 139.73852303097857 10.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1252e25-7603-4814-a2c4-7d2831e43800">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1252e25-7603-4814-a2c4-7d2831e43800_0">
											<gml:posList>35.67165116439784 139.73851850060584 33.799 35.67165116439784 139.73851850060584 10.47 35.67165565003209 139.7385373294727 10.47 35.67165565003209 139.7385373294727 33.799 35.67165116439784 139.73851850060584 33.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69cc7456-71e0-4c1b-82b6-b67bfe175cf5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69cc7456-71e0-4c1b-82b6-b67bfe175cf5_0">
											<gml:posList>35.67169221938128 139.73850381552046 33.799 35.67169221938128 139.73850381552046 10.47 35.67165116439784 139.73851850060584 10.47 35.67165116439784 139.73851850060584 33.799 35.67169221938128 139.73850381552046 33.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2cf74131-3b54-4bde-97bc-3fb859474ab2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2cf74131-3b54-4bde-97bc-3fb859474ab2_0">
											<gml:posList>35.67169221938128 139.73850381552046 33.799 35.67165116439784 139.73851850060584 33.799 35.67165565003209 139.7385373294727 33.799 35.67169674137712 139.73852303097857 33.799 35.67169221938128 139.73850381552046 33.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de2531c6-60e3-4a99-9bef-ffebdf3c0389">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de2531c6-60e3-4a99-9bef-ffebdf3c0389_0">
											<gml:posList>35.67165565003209 139.7385373294727 33.799 35.67165565003209 139.7385373294727 10.47 35.67169674137712 139.73852303097857 10.47 35.67169674137712 139.73852303097857 33.799 35.67165565003209 139.7385373294727 33.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84c45dbe-ec6a-4dd7-9769-72b72923f871">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84c45dbe-ec6a-4dd7-9769-72b72923f871_0">
											<gml:posList>35.67169674137712 139.73852303097857 33.799 35.67169674137712 139.73852303097857 10.47 35.67169221938128 139.73850381552046 10.47 35.67169221938128 139.73850381552046 33.799 35.67169674137712 139.73852303097857 33.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1f5b9e03-6994-4b91-8eda-e6d5e2ed6ffc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f5b9e03-6994-4b91-8eda-e6d5e2ed6ffc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f5b9e03-6994-4b91-8eda-e6d5e2ed6ffc">
											<gml:posList>35.67170068675329 139.7381540751781 10.47 35.67177503276014 139.73847488633027 10.47 35.67165116439784 139.73851850060584 10.47 35.671612330943276 139.73835544600675 10.47 35.671554480457154 139.7383778283096 10.47 35.67151748818499 139.7382180304837 10.47 35.67170068675329 139.7381540751781 10.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9f8fab0-9235-4530-8d83-a2bde29ff45c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9f8fab0-9235-4530-8d83-a2bde29ff45c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9f8fab0-9235-4530-8d83-a2bde29ff45c">
											<gml:posList>35.67154161039994 139.73829981164695 46.613 35.671544111863675 139.7382942965185 46.613 35.6715267193603 139.73821944452004 46.613 35.671522219088054 139.7382163789551 46.613 35.67154161039994 139.73829981164695 46.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5970c3dc-3765-46ce-9fde-5a502101157b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5970c3dc-3765-46ce-9fde-5a502101157b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5970c3dc-3765-46ce-9fde-5a502101157b">
											<gml:posList>35.671554806199055 139.73835655251685 34.512 35.671522219088054 139.7382163789551 34.512 35.67151748818499 139.7382180304837 34.512 35.671554806199055 139.73835655251685 34.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c150f4c-0875-431e-b29d-01f6130d79b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c150f4c-0875-431e-b29d-01f6130d79b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c150f4c-0875-431e-b29d-01f6130d79b1">
											<gml:posList>35.671554480457154 139.7383778283096 34.512 35.67155722470251 139.73837156173852 34.512 35.671554806199055 139.73835655251685 34.512 35.67151748818499 139.7382180304837 34.512 35.671554480457154 139.7383778283096 34.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9df94adf-51ca-4590-9a86-1c4c70539ca0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9df94adf-51ca-4590-9a86-1c4c70539ca0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9df94adf-51ca-4590-9a86-1c4c70539ca0">
											<gml:posList>35.67154161039994 139.73829981164695 40.34 35.671554806199055 139.73835655251685 40.34 35.67155737065687 139.73835090475757 40.34 35.671545845688996 139.73829833745285 40.34 35.67154161039994 139.73829981164695 40.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-493a3837-60dc-4048-9a96-55aa3033704d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-493a3837-60dc-4048-9a96-55aa3033704d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-493a3837-60dc-4048-9a96-55aa3033704d">
											<gml:posList>35.671522219088054 139.7382163789551 46.613 35.6715267193603 139.73821944452004 46.613 35.671595015566844 139.73819559158727 46.613 35.6715975170345 139.7381900874983 46.613 35.671522219088054 139.7382163789551 46.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc8fa5c4-d051-4706-a2d6-cd6c8d594ffd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc8fa5c4-d051-4706-a2d6-cd6c8d594ffd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc8fa5c4-d051-4706-a2d6-cd6c8d594ffd">
											<gml:posList>35.671612417098665 139.73827044363355 46.087 35.671595015566844 139.73819559158727 46.087 35.6715267193603 139.73821944452004 46.087 35.671544111863675 139.7382942965185 46.087 35.671612417098665 139.73827044363355 46.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4595b745-98c5-4142-bb33-3ab599496abd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4595b745-98c5-4142-bb33-3ab599496abd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4595b745-98c5-4142-bb33-3ab599496abd">
											<gml:posList>35.67161690836447 139.73827352026208 46.613 35.671612417098665 139.73827044363355 46.613 35.671544111863675 139.7382942965185 46.613 35.67154161039994 139.73829981164695 46.613 35.67161690836447 139.73827352026208 46.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c8d5381-5e8e-4f53-a9ad-ee5bbdf55f8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c8d5381-5e8e-4f53-a9ad-ee5bbdf55f8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c8d5381-5e8e-4f53-a9ad-ee5bbdf55f8a">
											<gml:posList>35.671612330943276 139.73835544600675 34.512 35.67161503914999 139.73834920156588 34.512 35.67155722470251 139.73837156173852 34.512 35.671554480457154 139.7383778283096 34.512 35.671612330943276 139.73835544600675 34.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed731918-fd18-4d02-8481-f644bd73e701">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed731918-fd18-4d02-8481-f644bd73e701">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed731918-fd18-4d02-8481-f644bd73e701">
											<gml:posList>35.6716255047033 139.73832712944474 40.01 35.67161333090296 139.73827477275026 40.01 35.671545845688996 139.73829833745285 40.01 35.67155737065687 139.73835090475757 40.01 35.6716255047033 139.73832712944474 40.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a10b2d6-8c35-417a-a846-ffe2e779e68d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a10b2d6-8c35-417a-a846-ffe2e779e68d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a10b2d6-8c35-417a-a846-ffe2e779e68d">
											<gml:posList>35.671630104184594 139.7383302722273 40.34 35.6716255047033 139.73832712944474 40.34 35.67155737065687 139.73835090475757 40.34 35.671554806199055 139.73835655251685 40.34 35.671630104184594 139.7383302722273 40.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d4d3274-1dd1-41e6-bca0-369860a2ede9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d4d3274-1dd1-41e6-bca0-369860a2ede9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d4d3274-1dd1-41e6-bca0-369860a2ede9">
											<gml:posList>35.6715975170345 139.7381900874983 46.613 35.671595015566844 139.73819559158727 46.613 35.671612417098665 139.73827044363355 46.613 35.67161690836447 139.73827352026208 46.613 35.6715975170345 139.7381900874983 46.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2424f207-0b48-4a87-98a7-b723a995ae28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2424f207-0b48-4a87-98a7-b723a995ae28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2424f207-0b48-4a87-98a7-b723a995ae28">
											<gml:posList>35.67161690836447 139.73827352026208 40.34 35.67161333090296 139.73827477275026 40.34 35.6716255047033 139.73832712944474 40.34 35.671630104184594 139.7383302722273 40.34 35.67161690836447 139.73827352026208 40.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd982fc4-6f84-4cda-be66-49609e71dc99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd982fc4-6f84-4cda-be66-49609e71dc99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd982fc4-6f84-4cda-be66-49609e71dc99">
											<gml:posList>35.671612330943276 139.73835544600675 34.512 35.67165116439784 139.73851850060584 34.512 35.67165389974983 139.73851237764615 34.512 35.67161503914999 139.73834920156588 34.512 35.671612330943276 139.73835544600675 34.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ac3527b4-1803-4e56-97d4-e9ec00b72f02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac3527b4-1803-4e56-97d4-e9ec00b72f02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac3527b4-1803-4e56-97d4-e9ec00b72f02">
											<gml:posList>35.6715975170345 139.7381900874983 34.512 35.67159876516975 139.7381954545807 34.512 35.67167831591028 139.73816703711492 34.512 35.67168110532668 139.73816091407699 34.512 35.6715975170345 139.7381900874983 34.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0c417506-8f05-4e42-a22f-ece43099ba54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c417506-8f05-4e42-a22f-ece43099ba54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c417506-8f05-4e42-a22f-ece43099ba54">
											<gml:posList>35.67175070734889 139.73847824009212 33.761 35.67167831591028 139.73816703711492 33.761 35.67159876516975 139.7381954545807 33.761 35.671630104184594 139.7383302722273 33.761 35.671554806199055 139.73835655251685 33.761 35.67155722470251 139.73837156173852 33.761 35.67161503914999 139.73834920156588 33.761 35.67165389974983 139.73851237764615 33.761 35.67175070734889 139.73847824009212 33.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-626c8b7a-7bcc-4398-923a-61f89d52d3e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-626c8b7a-7bcc-4398-923a-61f89d52d3e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-626c8b7a-7bcc-4398-923a-61f89d52d3e5">
											<gml:posList>35.67168110532668 139.73816091407699 20.671 35.671682009780696 139.73816481239612 20.671 35.67169842825615 139.73815907085054 20.671 35.67170068675329 139.7381540751781 20.671 35.67168110532668 139.73816091407699 20.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b4a2fcc-312f-49a1-ad7f-bbd67a2ff491">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b4a2fcc-312f-49a1-ad7f-bbd67a2ff491">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b4a2fcc-312f-49a1-ad7f-bbd67a2ff491">
											<gml:posList>35.671755703629984 139.7384816364871 34.512 35.67175070734889 139.73847824009212 34.512 35.67165389974983 139.73851237764615 34.512 35.67165116439784 139.73851850060584 34.512 35.671755703629984 139.7384816364871 34.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a9f8748-0148-41ed-8611-dcdcbfe10d37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a9f8748-0148-41ed-8611-dcdcbfe10d37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a9f8748-0148-41ed-8611-dcdcbfe10d37">
											<gml:posList>35.67168110532668 139.73816091407699 34.512 35.67167831591028 139.73816703711492 34.512 35.67175070734889 139.73847824009212 34.512 35.671755703629984 139.7384816364871 34.512 35.67168110532668 139.73816091407699 34.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0232bab-be59-47e7-8615-3ba0141a7723">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0232bab-be59-47e7-8615-3ba0141a7723">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0232bab-be59-47e7-8615-3ba0141a7723">
											<gml:posList>35.67177095635695 139.73847209640127 20.187 35.67169842825615 139.73815907085054 20.187 35.671682009780696 139.73816481239612 20.187 35.67175479918624 139.73847773816078 20.187 35.67177095635695 139.73847209640127 20.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb4c013e-2e4e-4db3-9660-9ee1ee7da924">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb4c013e-2e4e-4db3-9660-9ee1ee7da924">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb4c013e-2e4e-4db3-9660-9ee1ee7da924">
											<gml:posList>35.67170068675329 139.7381540751781 20.671 35.67169842825615 139.73815907085054 20.671 35.67177095635695 139.73847209640127 20.671 35.67177503276014 139.73847488633027 20.671 35.67170068675329 139.7381540751781 20.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa752fc2-2cff-4f90-a276-1c46ed9bbe33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa752fc2-2cff-4f90-a276-1c46ed9bbe33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa752fc2-2cff-4f90-a276-1c46ed9bbe33">
											<gml:posList>35.671755703629984 139.7384816364871 20.671 35.67177503276014 139.73847488633027 20.671 35.67177095635695 139.73847209640127 20.671 35.67175479918624 139.73847773816078 20.671 35.671755703629984 139.7384816364871 20.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c318d636-5b9a-495a-b43a-6e865fbc6902">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c318d636-5b9a-495a-b43a-6e865fbc6902">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c318d636-5b9a-495a-b43a-6e865fbc6902">
											<gml:posList>35.671544111863675 139.7382942965185 46.613 35.671544111863675 139.7382942965185 46.087 35.6715267193603 139.73821944452004 46.087 35.6715267193603 139.73821944452004 46.613 35.671544111863675 139.7382942965185 46.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b5bafd5-3ae5-4b23-8188-b6eb098be285">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b5bafd5-3ae5-4b23-8188-b6eb098be285">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b5bafd5-3ae5-4b23-8188-b6eb098be285">
											<gml:posList>35.67151748818499 139.7382180304837 10.47 35.671554480457154 139.7383778283096 10.47 35.671554480457154 139.7383778283096 34.512 35.67151748818499 139.7382180304837 34.512 35.67151748818499 139.7382180304837 10.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27ce938a-3c99-4823-b880-e67fe00d03eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27ce938a-3c99-4823-b880-e67fe00d03eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27ce938a-3c99-4823-b880-e67fe00d03eb">
											<gml:posList>35.671554806199055 139.73835655251685 34.512 35.671554806199055 139.73835655251685 40.34 35.67154161039994 139.73829981164695 40.34 35.67154161039994 139.73829981164695 46.613 35.671522219088054 139.7382163789551 46.613 35.671522219088054 139.7382163789551 34.512 35.671554806199055 139.73835655251685 34.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a88e0b32-12af-4cd9-8ad6-04898d71ed6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a88e0b32-12af-4cd9-8ad6-04898d71ed6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a88e0b32-12af-4cd9-8ad6-04898d71ed6c">
											<gml:posList>35.67155737065687 139.73835090475757 40.34 35.67155737065687 139.73835090475757 40.01 35.671545845688996 139.73829833745285 40.01 35.671545845688996 139.73829833745285 40.34 35.67155737065687 139.73835090475757 40.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-088fce6b-aa0c-4992-89cd-27ac41724fd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-088fce6b-aa0c-4992-89cd-27ac41724fd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-088fce6b-aa0c-4992-89cd-27ac41724fd5">
											<gml:posList>35.67155722470251 139.73837156173852 34.512 35.67155722470251 139.73837156173852 33.761 35.671554806199055 139.73835655251685 33.761 35.671554806199055 139.73835655251685 34.512 35.67155722470251 139.73837156173852 34.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41ec2693-8316-4bc1-b19d-a0e5a01d77dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41ec2693-8316-4bc1-b19d-a0e5a01d77dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41ec2693-8316-4bc1-b19d-a0e5a01d77dd">
											<gml:posList>35.6715267193603 139.73821944452004 46.613 35.6715267193603 139.73821944452004 46.087 35.671595015566844 139.73819559158727 46.087 35.671595015566844 139.73819559158727 46.613 35.6715267193603 139.73821944452004 46.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9b76476-fc34-4edf-8e78-0b9204cfb75f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9b76476-fc34-4edf-8e78-0b9204cfb75f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9b76476-fc34-4edf-8e78-0b9204cfb75f">
											<gml:posList>35.671612417098665 139.73827044363355 46.613 35.671612417098665 139.73827044363355 46.087 35.671544111863675 139.7382942965185 46.087 35.671544111863675 139.7382942965185 46.613 35.671612417098665 139.73827044363355 46.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-894707d2-5818-4f10-a1b3-e42c1f0a9ca6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-894707d2-5818-4f10-a1b3-e42c1f0a9ca6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-894707d2-5818-4f10-a1b3-e42c1f0a9ca6">
											<gml:posList>35.671545845688996 139.73829833745285 40.34 35.671545845688996 139.73829833745285 40.01 35.67161333090296 139.73827477275026 40.01 35.67161333090296 139.73827477275026 40.34 35.67161690836447 139.73827352026208 40.34 35.67161690836447 139.73827352026208 46.613 35.67154161039994 139.73829981164695 46.613 35.67154161039994 139.73829981164695 40.34 35.671545845688996 139.73829833745285 40.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72118f4f-bd40-4b45-9ba5-f25f8b212eb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72118f4f-bd40-4b45-9ba5-f25f8b212eb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72118f4f-bd40-4b45-9ba5-f25f8b212eb5">
											<gml:posList>35.671554480457154 139.7383778283096 10.47 35.671612330943276 139.73835544600675 10.47 35.671612330943276 139.73835544600675 34.512 35.671554480457154 139.7383778283096 34.512 35.671554480457154 139.7383778283096 10.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5bee82f-8faa-4a40-9ca7-424636c6e31a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5bee82f-8faa-4a40-9ca7-424636c6e31a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5bee82f-8faa-4a40-9ca7-424636c6e31a">
											<gml:posList>35.67161503914999 139.73834920156588 34.512 35.67161503914999 139.73834920156588 33.761 35.67155722470251 139.73837156173852 33.761 35.67155722470251 139.73837156173852 34.512 35.67161503914999 139.73834920156588 34.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba7bcea6-2c31-4342-afb8-bf602c290a6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba7bcea6-2c31-4342-afb8-bf602c290a6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba7bcea6-2c31-4342-afb8-bf602c290a6f">
											<gml:posList>35.6716255047033 139.73832712944474 40.34 35.6716255047033 139.73832712944474 40.01 35.67155737065687 139.73835090475757 40.01 35.67155737065687 139.73835090475757 40.34 35.6716255047033 139.73832712944474 40.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eceedf27-67c5-459d-b54a-b5ee08f18a9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eceedf27-67c5-459d-b54a-b5ee08f18a9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eceedf27-67c5-459d-b54a-b5ee08f18a9a">
											<gml:posList>35.671630104184594 139.7383302722273 33.761 35.671630104184594 139.7383302722273 40.34 35.671554806199055 139.73835655251685 40.34 35.671554806199055 139.73835655251685 34.512 35.671554806199055 139.73835655251685 33.761 35.671630104184594 139.7383302722273 33.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8736961b-0d1a-43b9-bcc2-40aef2a0082e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8736961b-0d1a-43b9-bcc2-40aef2a0082e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8736961b-0d1a-43b9-bcc2-40aef2a0082e">
											<gml:posList>35.671595015566844 139.73819559158727 46.613 35.671595015566844 139.73819559158727 46.087 35.671612417098665 139.73827044363355 46.087 35.671612417098665 139.73827044363355 46.613 35.671595015566844 139.73819559158727 46.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea01f2bb-a719-475e-8715-acfde87c6ef0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea01f2bb-a719-475e-8715-acfde87c6ef0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea01f2bb-a719-475e-8715-acfde87c6ef0">
											<gml:posList>35.67170068675329 139.7381540751781 10.47 35.67151748818499 139.7382180304837 10.47 35.67151748818499 139.7382180304837 34.512 35.671522219088054 139.7382163789551 34.512 35.671522219088054 139.7382163789551 46.613 35.6715975170345 139.7381900874983 46.613 35.6715975170345 139.7381900874983 34.512 35.67168110532668 139.73816091407699 34.512 35.67168110532668 139.73816091407699 20.671 35.67170068675329 139.7381540751781 20.671 35.67170068675329 139.7381540751781 10.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98a54360-b66d-405c-bb0d-0dabd407ae02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98a54360-b66d-405c-bb0d-0dabd407ae02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98a54360-b66d-405c-bb0d-0dabd407ae02">
											<gml:posList>35.6715975170345 139.7381900874983 46.613 35.67161690836447 139.73827352026208 46.613 35.67161690836447 139.73827352026208 40.34 35.671630104184594 139.7383302722273 40.34 35.671630104184594 139.7383302722273 33.761 35.67159876516975 139.7381954545807 33.761 35.67159876516975 139.7381954545807 34.512 35.6715975170345 139.7381900874983 34.512 35.6715975170345 139.7381900874983 46.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a380104e-e98d-4b34-b9b7-8b4d52788e67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a380104e-e98d-4b34-b9b7-8b4d52788e67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a380104e-e98d-4b34-b9b7-8b4d52788e67">
											<gml:posList>35.67161333090296 139.73827477275026 40.34 35.67161333090296 139.73827477275026 40.01 35.6716255047033 139.73832712944474 40.01 35.6716255047033 139.73832712944474 40.34 35.67161333090296 139.73827477275026 40.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77c4ad9e-b1f4-4fb4-9613-70bc07b9134a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77c4ad9e-b1f4-4fb4-9613-70bc07b9134a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77c4ad9e-b1f4-4fb4-9613-70bc07b9134a">
											<gml:posList>35.671612330943276 139.73835544600675 10.47 35.67165116439784 139.73851850060584 10.47 35.67165116439784 139.73851850060584 34.512 35.671612330943276 139.73835544600675 34.512 35.671612330943276 139.73835544600675 10.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-964f0f83-a732-4b6a-9c54-3e9bd7e18eb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-964f0f83-a732-4b6a-9c54-3e9bd7e18eb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-964f0f83-a732-4b6a-9c54-3e9bd7e18eb3">
											<gml:posList>35.67165389974983 139.73851237764615 34.512 35.67165389974983 139.73851237764615 33.761 35.67161503914999 139.73834920156588 33.761 35.67161503914999 139.73834920156588 34.512 35.67165389974983 139.73851237764615 34.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e0622ae-51a4-40d8-94a4-b7f2be46e325">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e0622ae-51a4-40d8-94a4-b7f2be46e325">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e0622ae-51a4-40d8-94a4-b7f2be46e325">
											<gml:posList>35.67159876516975 139.7381954545807 34.512 35.67159876516975 139.7381954545807 33.761 35.67167831591028 139.73816703711492 33.761 35.67167831591028 139.73816703711492 34.512 35.67159876516975 139.7381954545807 34.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-086f08ca-ccd6-4431-a531-19f4b4f42b9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-086f08ca-ccd6-4431-a531-19f4b4f42b9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-086f08ca-ccd6-4431-a531-19f4b4f42b9a">
											<gml:posList>35.671682009780696 139.73816481239612 20.671 35.671682009780696 139.73816481239612 20.187 35.67169842825615 139.73815907085054 20.187 35.67169842825615 139.73815907085054 20.671 35.671682009780696 139.73816481239612 20.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40af0a18-5666-4c66-93fa-1dafaeff3a66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40af0a18-5666-4c66-93fa-1dafaeff3a66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40af0a18-5666-4c66-93fa-1dafaeff3a66">
											<gml:posList>35.67175070734889 139.73847824009212 34.512 35.67175070734889 139.73847824009212 33.761 35.67165389974983 139.73851237764615 33.761 35.67165389974983 139.73851237764615 34.512 35.67175070734889 139.73847824009212 34.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5fa85b6e-a5ee-44b3-b9a7-16b1c19d24b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fa85b6e-a5ee-44b3-b9a7-16b1c19d24b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fa85b6e-a5ee-44b3-b9a7-16b1c19d24b6">
											<gml:posList>35.67165116439784 139.73851850060584 34.512 35.67165116439784 139.73851850060584 10.47 35.67177503276014 139.73847488633027 10.47 35.67177503276014 139.73847488633027 20.671 35.671755703629984 139.7384816364871 20.671 35.671755703629984 139.7384816364871 34.512 35.67165116439784 139.73851850060584 34.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1e9fc0c-26e3-4cfb-a56c-c26c82849144">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1e9fc0c-26e3-4cfb-a56c-c26c82849144">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1e9fc0c-26e3-4cfb-a56c-c26c82849144">
											<gml:posList>35.67167831591028 139.73816703711492 34.512 35.67167831591028 139.73816703711492 33.761 35.67175070734889 139.73847824009212 33.761 35.67175070734889 139.73847824009212 34.512 35.67167831591028 139.73816703711492 34.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f21a6046-b6cc-4048-93a4-4e14620de1cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f21a6046-b6cc-4048-93a4-4e14620de1cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f21a6046-b6cc-4048-93a4-4e14620de1cc">
											<gml:posList>35.67168110532668 139.73816091407699 34.512 35.671755703629984 139.7384816364871 34.512 35.671755703629984 139.7384816364871 20.671 35.67175479918624 139.73847773816078 20.671 35.67175479918624 139.73847773816078 20.187 35.671682009780696 139.73816481239612 20.187 35.671682009780696 139.73816481239612 20.671 35.67168110532668 139.73816091407699 20.671 35.67168110532668 139.73816091407699 34.512</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-281dcd2e-2eb5-447c-9f6c-112c3b14ef94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-281dcd2e-2eb5-447c-9f6c-112c3b14ef94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-281dcd2e-2eb5-447c-9f6c-112c3b14ef94">
											<gml:posList>35.67169842825615 139.73815907085054 20.671 35.67169842825615 139.73815907085054 20.187 35.67177095635695 139.73847209640127 20.187 35.67177095635695 139.73847209640127 20.671 35.67169842825615 139.73815907085054 20.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c3ecc76-7395-4ca0-839d-705abee783c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c3ecc76-7395-4ca0-839d-705abee783c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c3ecc76-7395-4ca0-839d-705abee783c2">
											<gml:posList>35.67177503276014 139.73847488633027 10.47 35.67170068675329 139.7381540751781 10.47 35.67170068675329 139.7381540751781 20.671 35.67177503276014 139.73847488633027 20.671 35.67177503276014 139.73847488633027 10.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a61177d4-463f-4dfb-a290-0d2622f35cef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a61177d4-463f-4dfb-a290-0d2622f35cef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a61177d4-463f-4dfb-a290-0d2622f35cef">
											<gml:posList>35.67177095635695 139.73847209640127 20.671 35.67177095635695 139.73847209640127 20.187 35.67175479918624 139.73847773816078 20.187 35.67175479918624 139.73847773816078 20.671 35.67177095635695 139.73847209640127 20.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3260</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">543.2616</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>