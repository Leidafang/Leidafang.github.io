<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_80e11178-9358-4100-baee-ecdd4fc55f4f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">67.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>16</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671156173677154 139.74152883417992 0 35.67101716063599 139.74173754839342 0 35.67122328096995 139.74194365921113 0 35.67145800081229 139.74159112170443 0 35.671395668429135 139.7415287808733 0 35.671156173677154 139.74152883417992 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671156173677154 139.74152883417992 7.25 35.671395668429135 139.7415287808733 7.25 35.67145800081229 139.74159112170443 7.25 35.67122328096995 139.74194365921113 7.25 35.67101716063599 139.74173754839342 7.25 35.671156173677154 139.74152883417992 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671156173677154 139.74152883417992 7.25 35.67101716063599 139.74173754839342 7.25 35.67101716063599 139.74173754839342 74.97 35.671156173677154 139.74152883417992 74.97 35.671156173677154 139.74152883417992 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67101716063599 139.74173754839342 7.25 35.67122328096995 139.74194365921113 7.25 35.67122328096995 139.74194365921113 74.97 35.67101716063599 139.74173754839342 74.97 35.67101716063599 139.74173754839342 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67122328096995 139.74194365921113 7.25 35.67145800081229 139.74159112170443 7.25 35.67145800081229 139.74159112170443 74.97 35.67122328096995 139.74194365921113 74.97 35.67122328096995 139.74194365921113 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67145800081229 139.74159112170443 7.25 35.671395668429135 139.7415287808733 7.25 35.671395668429135 139.7415287808733 74.97 35.67145800081229 139.74159112170443 74.97 35.67145800081229 139.74159112170443 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671395668429135 139.7415287808733 7.25 35.671156173677154 139.74152883417992 7.25 35.671156173677154 139.74152883417992 74.97 35.671395668429135 139.7415287808733 74.97 35.671395668429135 139.7415287808733 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671156173677154 139.74152883417992 74.97 35.67101716063599 139.74173754839342 74.97 35.67122328096995 139.74194365921113 74.97 35.67145800081229 139.74159112170443 74.97 35.671395668429135 139.7415287808733 74.97 35.671156173677154 139.74152883417992 74.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b13a7338-1f42-4f85-b5a4-ab9e436fa4f4"/>
							<gml:surfaceMember xlink:href="#poly-8b9d13d0-aa54-42d2-84d3-1d2a58945505"/>
							<gml:surfaceMember xlink:href="#poly-e6422f01-dc32-4690-8d9d-26bfbee7dd3b"/>
							<gml:surfaceMember xlink:href="#poly-68751354-49d0-45a4-a643-fc3123a3e1d2"/>
							<gml:surfaceMember xlink:href="#poly-d2ef8fa4-46fb-4379-8e72-1b766b8e31e6"/>
							<gml:surfaceMember xlink:href="#poly-311ae2ae-85c9-4c21-8cfe-a12b26876cdb"/>
							<gml:surfaceMember xlink:href="#poly-623c5285-17d8-4c78-ad84-0b67dd15dcde"/>
							<gml:surfaceMember xlink:href="#poly-6c7d4c32-8604-44c9-8031-ac69ffaa1122"/>
							<gml:surfaceMember xlink:href="#poly-e8e0fa4c-cdc5-4116-acf1-a315aee58703"/>
							<gml:surfaceMember xlink:href="#poly-182a6a09-c916-4625-b9c5-9dffe2f259d7"/>
							<gml:surfaceMember xlink:href="#poly-d87127a0-3262-4eec-a315-53371f597c69"/>
							<gml:surfaceMember xlink:href="#poly-f16ddc40-f025-4151-a120-05158630b409"/>
							<gml:surfaceMember xlink:href="#poly-d17ea70e-6748-4dec-9c7e-e583aca39118"/>
							<gml:surfaceMember xlink:href="#poly-b28565fe-0100-4e65-b5e8-7b06b415ab19"/>
							<gml:surfaceMember xlink:href="#poly-56e4898f-cc80-4855-9a54-ff0058fdb1d3"/>
							<gml:surfaceMember xlink:href="#poly-1c4ee9ad-a331-4d61-b247-45c81c150839"/>
							<gml:surfaceMember xlink:href="#poly-d135c414-acdb-470f-89fe-83f0ab96fc77"/>
							<gml:surfaceMember xlink:href="#poly-a89ab39d-5123-4479-a690-87d759a3d6d6"/>
							<gml:surfaceMember xlink:href="#poly-8cadaf15-f70b-427b-8a75-96edd450928c"/>
							<gml:surfaceMember xlink:href="#poly-41251c7a-f4cf-40fc-b23b-ecfcee0ffe88"/>
							<gml:surfaceMember xlink:href="#poly-750732a3-d136-42dc-856c-836d326f6bee"/>
							<gml:surfaceMember xlink:href="#poly-1f14cc00-ac1c-4474-accf-e5820d204433"/>
							<gml:surfaceMember xlink:href="#poly-07f0790d-304d-4b43-98d4-1de4eb22c86c"/>
							<gml:surfaceMember xlink:href="#poly-254960d3-2581-404a-824a-8791c31d64d4"/>
							<gml:surfaceMember xlink:href="#poly-db6c543b-b062-4b92-a7ce-f6c64842c1c1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_80e11178-9358-4100-baee-ecdd4fc55f4f_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9b362fa-4904-450b-8bf8-3a9ee00050aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9b362fa-4904-450b-8bf8-3a9ee00050aa_0">
											<gml:posList>35.671096868973905 139.74176115176988 75.626 35.67111089596271 139.74177514253378 75.626 35.67111089596271 139.74177514253378 77.173 35.671096868973905 139.74176115176988 77.173 35.671096868973905 139.74176115176988 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eca885e6-057f-4caa-a65b-992fb64527bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eca885e6-057f-4caa-a65b-992fb64527bf_0">
											<gml:posList>35.67116226336476 139.741784572703 75.626 35.67116226336476 139.741784572703 77.181 35.67115621960218 139.74177857038075 77.181 35.67115621960218 139.74177857038075 75.626 35.67116226336476 139.741784572703 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5523397f-2c61-4523-b5e8-7a29e032a2a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5523397f-2c61-4523-b5e8-7a29e032a2a8_0">
											<gml:posList>35.671160955223094 139.74173564983664 75.626 35.671167152338704 139.74174180662996 75.626 35.671167152338704 139.74174180662996 77.13 35.671160955223094 139.74173564983664 77.13 35.671160955223094 139.74173564983664 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-135e3fc0-1df8-4bdc-bb82-83156e6c923a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-135e3fc0-1df8-4bdc-bb82-83156e6c923a_0">
											<gml:posList>35.671172290473045 139.74171851501495 75.626 35.671160955223094 139.74173564983664 75.626 35.671160955223094 139.74173564983664 77.13 35.671172290473045 139.74171851501495 77.13 35.671172290473045 139.74171851501495 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b5655e3-8a98-4206-9407-9ad71fb8293f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b5655e3-8a98-4206-9407-9ad71fb8293f_0">
											<gml:posList>35.671168398988506 139.74182841977864 75.626 35.67117401879309 139.74183401387376 75.626 35.67117401879309 139.74183401387376 76.975 35.671168398988506 139.74182841977864 76.975 35.671168398988506 139.74182841977864 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfe0f689-7ec0-46bc-97cd-83864438f33d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfe0f689-7ec0-46bc-97cd-83864438f33d_0">
											<gml:posList>35.671169966911535 139.7417922300863 75.626 35.67117603773978 139.74179826551884 75.626 35.67117603773978 139.74179826551884 77.363 35.671169966911535 139.7417922300863 77.363 35.671169966911535 139.7417922300863 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10e233ba-bf04-40ff-88c5-0c92f443788f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10e233ba-bf04-40ff-88c5-0c92f443788f_0">
											<gml:posList>35.67119281834829 139.74172326359061 75.626 35.67115621960218 139.74177857038075 75.626 35.67115621960218 139.74177857038075 77.181 35.67119281834829 139.74172326359061 77.181 35.67119281834829 139.74172326359061 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-463fe655-a8fc-465e-9979-6533b4f9ccc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-463fe655-a8fc-465e-9979-6533b4f9ccc3_0">
											<gml:posList>35.671176340347564 139.7418524918001 75.626 35.671181689546366 139.74185783213966 75.626 35.671181689546366 139.74185783213966 77.363 35.671176340347564 139.7418524918001 77.363 35.671176340347564 139.7418524918001 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ddffb3e-7808-4baa-b2cd-5867ff037494">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ddffb3e-7808-4baa-b2cd-5867ff037494_0">
											<gml:posList>35.6711896587624 139.7418118038652 75.626 35.6711896587624 139.7418118038652 77.363 35.67118381344583 139.74180598910058 77.363 35.67118381344583 139.74180598910058 75.626 35.6711896587624 139.7418118038652 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f82ede3-25bf-4a36-9328-fca85ff40546">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f82ede3-25bf-4a36-9328-fca85ff40546_0">
											<gml:posList>35.6711891063838 139.74187964026024 75.626 35.67119700839417 139.74188751835632 75.626 35.67119700839417 139.74188751835632 77.02 35.6711891063838 139.74187964026024 77.02 35.6711891063838 139.74187964026024 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9ee1475-7e32-4f35-8f98-c98d33baa89a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9ee1475-7e32-4f35-8f98-c98d33baa89a_0">
											<gml:posList>35.67122048423851 139.7417505828042 75.626 35.67118381344583 139.74180598910058 75.626 35.67118381344583 139.74180598910058 77.363 35.67122048423851 139.7417505828042 77.363 35.67122048423851 139.7417505828042 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd26f56d-250d-446e-bb44-91f0bac28561">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd26f56d-250d-446e-bb44-91f0bac28561_0">
											<gml:posList>35.67120050564486 139.74181623212505 75.626 35.67120584583993 139.74182158352048 75.626 35.67120584583993 139.74182158352048 77.363 35.67120050564486 139.74181623212505 77.363 35.67120050564486 139.74181623212505 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90a22add-14a6-4329-91b2-7a4f08ed8d42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90a22add-14a6-4329-91b2-7a4f08ed8d42_0">
											<gml:posList>35.67122532910427 139.74160254478514 75.626 35.67122532910427 139.74160254478514 76.608 35.67118776753519 139.74165994051782 76.608 35.67118776753519 139.74165994051782 75.626 35.67122532910427 139.74160254478514 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e658bc0-22c3-4ecf-af0d-adbc86be97d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e658bc0-22c3-4ecf-af0d-adbc86be97d4_0">
											<gml:posList>35.6711896587624 139.7418118038652 75.626 35.671226338571444 139.74175639755714 75.626 35.671226338571444 139.74175639755714 77.363 35.6711896587624 139.7418118038652 77.363 35.6711896587624 139.7418118038652 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d9d6b2c-5a15-499e-bab9-2579aa0211da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d9d6b2c-5a15-499e-bab9-2579aa0211da_0">
											<gml:posList>35.67121318251482 139.74179720684458 75.626 35.67121852271071 139.74180255823956 75.626 35.67121852271071 139.74180255823956 77.363 35.67121318251482 139.74179720684458 77.363 35.67121318251482 139.74179720684458 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2da5cae-a08f-4de7-87c5-c0cec6e6953b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2da5cae-a08f-4de7-87c5-c0cec6e6953b_0">
											<gml:posList>35.67121890793609 139.74155077777166 75.626 35.67121683324764 139.7415487697065 75.626 35.67121683324764 139.7415487697065 76.601 35.67121890793609 139.74155077777166 76.601 35.67121890793609 139.74155077777166 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6999064a-4f56-4d36-b59e-3aa7e8c21e6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6999064a-4f56-4d36-b59e-3aa7e8c21e6d_0">
											<gml:posList>35.67121852271071 139.74180255823956 75.626 35.67122955194024 139.74178599817606 75.626 35.67122955194024 139.74178599817606 77.363 35.67121852271071 139.74180255823956 77.363 35.67121852271071 139.74180255823956 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac0dcdde-0f09-4d11-a485-bf987faa590a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac0dcdde-0f09-4d11-a485-bf987faa590a_0">
											<gml:posList>35.67122955194024 139.74178599817606 75.626 35.67122421175203 139.7417806578278 75.626 35.67122421175203 139.7417806578278 77.363 35.67122955194024 139.74178599817606 77.363 35.67122955194024 139.74178599817606 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f3fd20d-328d-46f3-93ff-3c5b3f7d8b5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f3fd20d-328d-46f3-93ff-3c5b3f7d8b5b_0">
											<gml:posList>35.6712306773789 139.74178431784173 75.626 35.67124177864847 139.74176766931987 75.626 35.67124177864847 139.74176766931987 77.363 35.6712306773789 139.74178431784173 77.363 35.6712306773789 139.74178431784173 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fe38a96-20e8-4606-9224-ad1352414116">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fe38a96-20e8-4606-9224-ad1352414116_0">
											<gml:posList>35.67131300851095 139.74171285311704 75.626 35.67131300851095 139.74171285311704 77.02 35.67119700839417 139.74188751835632 77.02 35.67119700839417 139.74188751835632 75.626 35.67131300851095 139.74171285311704 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcbd6241-84c4-406d-a4d2-92ac8397c6f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dcbd6241-84c4-406d-a4d2-92ac8397c6f0_0">
											<gml:posList>35.67126783383689 139.74163277428676 75.626 35.67127834029757 139.74161628106603 75.626 35.67127834029757 139.74161628106603 77.817 35.67126783383689 139.74163277428676 77.817 35.67126783383689 139.74163277428676 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4b430f8-0ed0-4f91-a5b1-457b645033f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4b430f8-0ed0-4f91-a5b1-457b645033f0_0">
											<gml:posList>35.67128390413954 139.74159572842683 75.626 35.671294770706254 139.74157866037376 75.626 35.671294770706254 139.74157866037376 77.579 35.67128390413954 139.74159572842683 77.579 35.67128390413954 139.74159572842683 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-471aa1d4-814b-49ba-8a65-18c037d172eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-471aa1d4-814b-49ba-8a65-18c037d172eb_0">
											<gml:posList>35.6713042420914 139.7416706548907 75.626 35.671326992582756 139.74163492694782 75.626 35.671326992582756 139.74163492694782 78.07 35.6713042420914 139.7416706548907 78.07 35.6713042420914 139.7416706548907 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73929339-8d8f-4a81-aadd-53b302dbb508">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73929339-8d8f-4a81-aadd-53b302dbb508_0">
											<gml:posList>35.67131572370879 139.74171556742579 75.626 35.671320315445165 139.74170864713912 75.626 35.671320315445165 139.74170864713912 77.02 35.67131572370879 139.74171556742579 77.02 35.67131572370879 139.74171556742579 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-508c422b-75bb-4d44-8ec2-d72e9713921e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-508c422b-75bb-4d44-8ec2-d72e9713921e_0">
											<gml:posList>35.67132385161905 139.74168862704002 75.626 35.67135067166657 139.74164678578447 75.626 35.67135067166657 139.74164678578447 78.417 35.67132385161905 139.74168862704002 78.417 35.67132385161905 139.74168862704002 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa293fb2-86bb-4b6c-ae8b-8824af137685">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa293fb2-86bb-4b6c-ae8b-8824af137685_0">
											<gml:posList>35.671363046389516 139.7416097993489 75.626 35.67137980116501 139.74158384323985 75.626 35.67137980116501 139.74158384323985 78.371 35.671363046389516 139.7416097993489 78.371 35.671363046389516 139.7416097993489 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38ee7492-f536-466e-a977-8bcb18318684">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38ee7492-f536-466e-a977-8bcb18318684_0">
											<gml:posList>35.67138458679741 139.74163030995945 75.626 35.6714080398838 139.74159397361333 75.626 35.6714080398838 139.74159397361333 77.856 35.67138458679741 139.74163030995945 77.856 35.67138458679741 139.74163030995945 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba28b4c6-644a-4a5e-a55c-350be2801686">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba28b4c6-644a-4a5e-a55c-350be2801686_0">
											<gml:posList>35.67130970724722 139.74169806577655 75.626 35.6711891063838 139.74187964026024 75.626 35.6711891063838 139.74187964026024 77.02 35.67130970724722 139.74169806577655 77.02 35.67130970724722 139.74169806577655 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87171031-c60d-40c1-af5a-6bae388007b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87171031-c60d-40c1-af5a-6bae388007b3_0">
											<gml:posList>35.67122421175203 139.7417806578278 77.363 35.67121318251482 139.74179720684458 77.363 35.67121852271071 139.74180255823956 77.363 35.67122955194024 139.74178599817606 77.363 35.67122421175203 139.7417806578278 77.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf72a79c-fde0-461f-8666-b21d9aaa4e6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf72a79c-fde0-461f-8666-b21d9aaa4e6e_0">
											<gml:posList>35.671320315445165 139.74170864713912 77.02 35.67130970724722 139.74169806577655 77.02 35.6711891063838 139.74187964026024 77.02 35.67119700839417 139.74188751835632 77.02 35.67131300851095 139.74171285311704 77.02 35.67131572370879 139.74171556742579 77.02 35.671320315445165 139.74170864713912 77.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d16b143-817b-451d-9cf8-dbd1b0aba22d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d16b143-817b-451d-9cf8-dbd1b0aba22d_0">
											<gml:posList>35.67121171495762 139.7417994177949 77.363 35.67120050564486 139.74181623212505 77.363 35.67120584583993 139.74182158352048 77.363 35.67121705514502 139.7418047581436 77.363 35.67121171495762 139.7417994177949 77.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cabda380-8fac-4713-ab7e-2acb334cee53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cabda380-8fac-4713-ab7e-2acb334cee53_0">
											<gml:posList>35.67121705514502 139.7418047581436 75.626 35.67121705514502 139.7418047581436 77.363 35.67120584583993 139.74182158352048 77.363 35.67120584583993 139.74182158352048 75.626 35.67121705514502 139.7418047581436 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71b108b3-9f8f-408e-9449-8b6a4edbd7c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71b108b3-9f8f-408e-9449-8b6a4edbd7c3_0">
											<gml:posList>35.67118243696089 139.7418212898946 75.626 35.671176817164124 139.74181570684615 75.626 35.671176817164124 139.74181570684615 76.975 35.67118243696089 139.7418212898946 76.975 35.67118243696089 139.7418212898946 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0f13134-2f23-4c78-b181-318c4736f7d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0f13134-2f23-4c78-b181-318c4736f7d9_0">
											<gml:posList>35.671176817164124 139.74181570684615 75.626 35.671168398988506 139.74182841977864 75.626 35.671168398988506 139.74182841977864 76.975 35.671176817164124 139.74181570684615 76.975 35.671176817164124 139.74181570684615 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d09ef5ca-4ca7-494d-bb2e-c9b8fdca2c2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d09ef5ca-4ca7-494d-bb2e-c9b8fdca2c2f_0">
											<gml:posList>35.671176817164124 139.74181570684615 76.975 35.671168398988506 139.74182841977864 76.975 35.67117401879309 139.74183401387376 76.975 35.67118243696089 139.7418212898946 76.975 35.671176817164124 139.74181570684615 76.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-567bfbb9-f364-4c26-b05f-32292480dcc5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-567bfbb9-f364-4c26-b05f-32292480dcc5_0">
											<gml:posList>35.67119937120882 139.7418179345613 75.626 35.671187900797705 139.7418351468536 75.626 35.671187900797705 139.7418351468536 77.363 35.67119937120882 139.7418179345613 77.363 35.67119937120882 139.7418179345613 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b4392a8-ab3e-4429-be3f-5f57b3b1a5f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b4392a8-ab3e-4429-be3f-5f57b3b1a5f8_0">
											<gml:posList>35.67117401879309 139.74183401387376 75.626 35.67118243696089 139.7418212898946 75.626 35.67118243696089 139.7418212898946 76.975 35.67117401879309 139.74183401387376 76.975 35.67117401879309 139.74183401387376 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97683a55-9f3c-47d9-ab99-a042d336ec92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97683a55-9f3c-47d9-ab99-a042d336ec92_0">
											<gml:posList>35.671187900797705 139.7418351468536 77.363 35.67119324099192 139.74184049824942 77.363 35.67120471139542 139.74182327491042 77.363 35.67119937120882 139.7418179345613 77.363 35.671187900797705 139.7418351468536 77.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dfde508-ddcf-41d9-9b13-3c4e1485bbcc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2dfde508-ddcf-41d9-9b13-3c4e1485bbcc_0">
											<gml:posList>35.67119324099192 139.74184049824942 75.626 35.67120471139542 139.74182327491042 75.626 35.67120471139542 139.74182327491042 77.363 35.67119324099192 139.74184049824942 77.363 35.67119324099192 139.74184049824942 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0b2283b-a14e-4303-8676-1c2a8a0c132a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0b2283b-a14e-4303-8676-1c2a8a0c132a_0">
											<gml:posList>35.67118691941 139.7418366060945 75.626 35.671176340347564 139.7418524918001 75.626 35.671176340347564 139.7418524918001 77.363 35.67118691941 139.7418366060945 77.363 35.67118691941 139.7418366060945 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d40e4c2b-ebb4-4372-9e94-d6100b055786">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d40e4c2b-ebb4-4372-9e94-d6100b055786_0">
											<gml:posList>35.67118691941 139.7418366060945 77.363 35.671176340347564 139.7418524918001 77.363 35.671181689546366 139.74185783213966 77.363 35.67119226861789 139.7418419574801 77.363 35.67118691941 139.7418366060945 77.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09a65aaa-21b3-4ae9-8299-1ccb48ec18c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09a65aaa-21b3-4ae9-8299-1ccb48ec18c4_0">
											<gml:posList>35.671181689546366 139.74185783213966 75.626 35.67119226861789 139.7418419574801 75.626 35.67119226861789 139.7418419574801 77.363 35.671181689546366 139.74185783213966 77.363 35.671181689546366 139.74185783213966 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fd2403f-89ac-4ed7-b8de-927c8c8e8f45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fd2403f-89ac-4ed7-b8de-927c8c8e8f45_0">
											<gml:posList>35.671393186099245 139.7415359417823 80.498 35.671393186099245 139.7415359417823 75.626 35.67115894634693 139.7415359890508 75.626 35.67115894634693 139.7415359890508 80.498 35.671393186099245 139.7415359417823 80.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e7b8e2f-175b-4846-9ed6-3a2174263b24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e7b8e2f-175b-4846-9ed6-3a2174263b24_0">
											<gml:posList>35.671164632789356 139.7415462114765 75.626 35.67116778036335 139.74154854970308 75.626 35.67116778036335 139.74154854970308 80.498 35.671164632789356 139.7415462114765 80.498 35.671164632789356 139.7415462114765 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f49080ff-ed67-4343-9d1c-4f392387d5fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f49080ff-ed67-4343-9d1c-4f392387d5fc_0">
											<gml:posList>35.671389915453716 139.74154952155106 75.626 35.671389915453716 139.74154952155106 80.498 35.67116778036335 139.74154854970308 80.498 35.67116778036335 139.74154854970308 75.626 35.67118949451174 139.74154864635472 75.626 35.67118949451174 139.74154864635472 76.601 35.67121683324764 139.7415487697065 76.601 35.67121683324764 139.7415487697065 75.626 35.671389915453716 139.74154952155106 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c83fb271-ecba-4cba-8900-6528a26fe3d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c83fb271-ecba-4cba-8900-6528a26fe3d4_0">
											<gml:posList>35.671393186099245 139.7415359417823 80.498 35.67142964706842 139.74157198863793 80.498 35.67142964706842 139.74157198863793 75.626 35.671393186099245 139.7415359417823 75.626 35.671393186099245 139.7415359417823 80.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a78f8148-ee26-42d8-9db5-737605e4e3b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a78f8148-ee26-42d8-9db5-737605e4e3b3_0">
											<gml:posList>35.67118119090757 139.74155790167234 75.626 35.67117501194475 139.74155192161325 75.626 35.67117501194475 139.74155192161325 76.665 35.67118119090757 139.74155790167234 76.665 35.67118119090757 139.74155790167234 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9d1c990-a817-481a-b7aa-67ec056d6746">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9d1c990-a817-481a-b7aa-67ec056d6746_0">
											<gml:posList>35.67117501194475 139.74155192161325 75.626 35.671167584414036 139.74156346252423 75.626 35.671167584414036 139.74156346252423 76.665 35.67117501194475 139.74155192161325 76.665 35.67117501194475 139.74155192161325 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae03196d-ecd5-4fd7-80dd-d35d0f9a9423">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae03196d-ecd5-4fd7-80dd-d35d0f9a9423_0">
											<gml:posList>35.67118949451174 139.74154864635472 75.626 35.67117535968054 139.741570589579 75.626 35.67117535968054 139.741570589579 76.601 35.67118949451174 139.74154864635472 76.601 35.67118949451174 139.74154864635472 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f256725e-d83e-422c-b83a-a74c18c2f669">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f256725e-d83e-422c-b83a-a74c18c2f669_0">
											<gml:posList>35.67117501194475 139.74155192161325 76.665 35.671167584414036 139.74156346252423 76.665 35.67117376336787 139.74156943153727 76.665 35.67118119090757 139.74155790167234 76.665 35.67117501194475 139.74155192161325 76.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8be12741-4118-49a9-afad-3a109e1988f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8be12741-4118-49a9-afad-3a109e1988f4_0">
											<gml:posList>35.67117376336787 139.74156943153727 75.626 35.67118119090757 139.74155790167234 75.626 35.67118119090757 139.74155790167234 76.665 35.67117376336787 139.74156943153727 76.665 35.67117376336787 139.74156943153727 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51f55992-4a43-4546-b5a2-4e6f6005fd25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51f55992-4a43-4546-b5a2-4e6f6005fd25_0">
											<gml:posList>35.67133401958812 139.74157090507515 75.626 35.671322653880324 139.74155987169414 75.626 35.671322653880324 139.74155987169414 78.252 35.67133401958812 139.74157090507515 78.252 35.67133401958812 139.74157090507515 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31c02bbd-8739-410b-8b6e-6582673e8b54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31c02bbd-8739-410b-8b6e-6582673e8b54_0">
											<gml:posList>35.671167584414036 139.74156346252423 75.626 35.67117376336787 139.74156943153727 75.626 35.67117376336787 139.74156943153727 76.665 35.671167584414036 139.74156346252423 76.665 35.671167584414036 139.74156346252423 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58a645e5-9038-443f-9e6f-53c8ca8b17e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58a645e5-9038-443f-9e6f-53c8ca8b17e4_0">
											<gml:posList>35.67131392085784 139.74157338037693 75.626 35.67131392085784 139.74157338037693 78.252 35.671322653880324 139.74155987169414 78.252 35.671322653880324 139.74155987169414 75.626 35.67131392085784 139.74157338037693 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc7251b1-156b-4b68-887e-51be4bb42f27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc7251b1-156b-4b68-887e-51be4bb42f27_0">
											<gml:posList>35.67127350083567 139.7415583262325 75.626 35.67126263427179 139.74157539428379 75.626 35.67126263427179 139.74157539428379 77.579 35.67127350083567 139.7415583262325 77.579 35.67127350083567 139.7415583262325 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-446d726e-a39b-4580-8bc6-f4b17554b4af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-446d726e-a39b-4580-8bc6-f4b17554b4af_0">
											<gml:posList>35.67127350083567 139.7415583262325 75.626 35.67127350083567 139.7415583262325 77.579 35.671294770706254 139.74157866037376 77.579 35.671294770706254 139.74157866037376 75.626 35.67127350083567 139.7415583262325 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f265313-6749-41b7-ab4b-770510708a64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f265313-6749-41b7-ab4b-770510708a64_0">
											<gml:posList>35.6711943385491 139.74158893797332 76.601 35.67121890793609 139.74155077777166 76.601 35.67121683324764 139.7415487697065 76.601 35.67118949451174 139.74154864635472 76.601 35.67117535968054 139.741570589579 76.601 35.6711943385491 139.74158893797332 76.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa25a800-4e3e-4958-bfc3-4b7e4dc4c392">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa25a800-4e3e-4958-bfc3-4b7e4dc4c392_0">
											<gml:posList>35.6711943385491 139.74158893797332 75.626 35.67121890793609 139.74155077777166 75.626 35.67121890793609 139.74155077777166 76.601 35.6711943385491 139.74158893797332 76.601 35.6711943385491 139.74158893797332 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5ac679f-688c-4431-8509-1a3b901cd6d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5ac679f-688c-4431-8509-1a3b901cd6d1_0">
											<gml:posList>35.67143537853455 139.74159398651676 75.626 35.67143537853455 139.74159398651676 80.498 35.671389915453716 139.74154952155106 80.498 35.671389915453716 139.74154952155106 75.626 35.67143537853455 139.74159398651676 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2638afe-1e22-4515-9774-15c6be68b525">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2638afe-1e22-4515-9774-15c6be68b525_0">
											<gml:posList>35.67132528656441 139.74158441375866 78.252 35.67133401958812 139.74157090507515 78.252 35.671322653880324 139.74155987169414 78.252 35.67131392085784 139.74157338037693 78.252 35.67132528656441 139.74158441375866 78.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1fcbfe3-aed1-4b83-b273-6b427395c74a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1fcbfe3-aed1-4b83-b273-6b427395c74a_0">
											<gml:posList>35.67137980116501 139.74158384323985 75.626 35.6713634652276 139.74156799931097 75.626 35.6713634652276 139.74156799931097 78.371 35.67137980116501 139.74158384323985 78.371 35.67137980116501 139.74158384323985 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1a657b4-506b-4fb8-8f7d-1be76138ffb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1a657b4-506b-4fb8-8f7d-1be76138ffb1_0">
											<gml:posList>35.67127350083567 139.7415583262325 77.579 35.67126263427179 139.74157539428379 77.579 35.67128390413954 139.74159572842683 77.579 35.671294770706254 139.74157866037376 77.579 35.67127350083567 139.7415583262325 77.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2f92901-508d-41b2-9e4e-333b69934be8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2f92901-508d-41b2-9e4e-333b69934be8_0">
											<gml:posList>35.67132528656441 139.74158441375866 75.626 35.67133401958812 139.74157090507515 75.626 35.67133401958812 139.74157090507515 78.252 35.67132528656441 139.74158441375866 78.252 35.67132528656441 139.74158441375866 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-179e814a-8eb5-4145-9564-21270359e424">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-179e814a-8eb5-4145-9564-21270359e424_0">
											<gml:posList>35.67131392085784 139.74157338037693 75.626 35.67132528656441 139.74158441375866 75.626 35.67132528656441 139.74158441375866 78.252 35.67131392085784 139.74157338037693 78.252 35.67131392085784 139.74157338037693 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ed5105c-85a4-4c4e-bd43-50fc3a6d5cf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ed5105c-85a4-4c4e-bd43-50fc3a6d5cf4_0">
											<gml:posList>35.6711943385491 139.74158893797332 75.626 35.6711943385491 139.74158893797332 76.601 35.67117535968054 139.741570589579 76.601 35.67117535968054 139.741570589579 75.626 35.6711943385491 139.74158893797332 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64cd125c-692e-40af-86b6-a035f39efa55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64cd125c-692e-40af-86b6-a035f39efa55_0">
											<gml:posList>35.671346701433336 139.74159394438198 75.626 35.671346701433336 139.74159394438198 78.371 35.6713634652276 139.74156799931097 78.371 35.6713634652276 139.74156799931097 75.626 35.671346701433336 139.74159394438198 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3679b296-5b6f-4cc9-9cdc-272c12f75b44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3679b296-5b6f-4cc9-9cdc-272c12f75b44_0">
											<gml:posList>35.67144979909169 139.74159213631253 75.626 35.67142964706842 139.74157198863793 75.626 35.67142964706842 139.74157198863793 80.498 35.67144979909169 139.74159213631253 80.498 35.67144979909169 139.74159213631253 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4825e528-cd25-4200-a0e3-56e0617b1498">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4825e528-cd25-4200-a0e3-56e0617b1498_0">
											<gml:posList>35.67128390413954 139.74159572842683 75.626 35.67128390413954 139.74159572842683 77.579 35.67126263427179 139.74157539428379 77.579 35.67126263427179 139.74157539428379 75.626 35.67128390413954 139.74159572842683 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9d9bef9-13b8-427f-badf-58ae42d7ae24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9d9bef9-13b8-427f-badf-58ae42d7ae24_0">
											<gml:posList>35.671363046389516 139.7416097993489 78.371 35.67137980116501 139.74158384323985 78.371 35.6713634652276 139.74156799931097 78.371 35.671346701433336 139.74159394438198 78.371 35.671363046389516 139.7416097993489 78.371</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-786b6178-e788-423c-8522-562f9a73591c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-786b6178-e788-423c-8522-562f9a73591c_0">
											<gml:posList>35.6714080398838 139.74159397361333 75.626 35.671399677977966 139.7415858640774 75.626 35.671399677977966 139.7415858640774 77.856 35.6714080398838 139.74159397361333 77.856 35.6714080398838 139.74159397361333 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b94d9c8b-ea9c-4e04-bce9-64d5ab8715e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b94d9c8b-ea9c-4e04-bce9-64d5ab8715e5_0">
											<gml:posList>35.67120928165854 139.741586766831 75.626 35.67119938709137 139.74160188959112 75.626 35.67119938709137 139.74160188959112 76.608 35.67120928165854 139.741586766831 76.608 35.67120928165854 139.741586766831 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5ca311f-c6da-48f9-891a-b9d367673ca9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5ca311f-c6da-48f9-891a-b9d367673ca9_0">
											<gml:posList>35.67120928165854 139.741586766831 75.626 35.67120928165854 139.741586766831 76.608 35.67122532910427 139.74160254478514 76.608 35.67122532910427 139.74160254478514 75.626 35.67120928165854 139.741586766831 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1b842ce-af8e-480c-9e20-4e14badf75b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1b842ce-af8e-480c-9e20-4e14badf75b2_0">
											<gml:posList>35.67118911276189 139.74159179391688 75.626 35.67118911276189 139.74159179391688 76.608 35.67119938709137 139.74160188959112 76.608 35.67119938709137 139.74160188959112 75.626 35.67118911276189 139.74159179391688 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cb0a9e6-019f-42c4-90ef-c51c78791e24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0cb0a9e6-019f-42c4-90ef-c51c78791e24_0">
											<gml:posList>35.671346701433336 139.74159394438198 75.626 35.671363046389516 139.7416097993489 75.626 35.671363046389516 139.7416097993489 78.371 35.671346701433336 139.74159394438198 78.371 35.671346701433336 139.74159394438198 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68bfb9d8-3f68-4397-8105-907f0ec0f1d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68bfb9d8-3f68-4397-8105-907f0ec0f1d7_0">
											<gml:posList>35.67125654724186 139.7415954283377 75.626 35.67124604079241 139.74161193260304 75.626 35.67124604079241 139.74161193260304 77.817 35.67125654724186 139.7415954283377 77.817 35.67125654724186 139.7415954283377 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-745c1e81-d063-4d7f-bc79-ae80747e76dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-745c1e81-d063-4d7f-bc79-ae80747e76dc_0">
											<gml:posList>35.67137622490238 139.74162221146847 75.626 35.67137622490238 139.74162221146847 77.856 35.671399677977966 139.7415858640774 77.856 35.671399677977966 139.7415858640774 75.626 35.67137622490238 139.74162221146847 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4b9e75f-62d1-4ca5-a550-68bd71b54e40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4b9e75f-62d1-4ca5-a550-68bd71b54e40_0">
											<gml:posList>35.67125654724186 139.7415954283377 75.626 35.67125654724186 139.7415954283377 77.817 35.67127834029757 139.74161628106603 77.817 35.67127834029757 139.74161628106603 75.626 35.67125654724186 139.7415954283377 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85ce887e-8763-4acc-ac4e-eb1232df76ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85ce887e-8763-4acc-ac4e-eb1232df76ce_0">
											<gml:posList>35.67138458679741 139.74163030995945 77.856 35.6714080398838 139.74159397361333 77.856 35.671399677977966 139.7415858640774 77.856 35.67137622490238 139.74162221146847 77.856 35.67138458679741 139.74163030995945 77.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac6affe7-73e9-4f04-b580-6bba66b22c73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac6affe7-73e9-4f04-b580-6bba66b22c73_0">
											<gml:posList>35.67118911276189 139.74159179391688 75.626 35.67116144577089 139.7416340668834 75.626 35.67116144577089 139.7416340668834 76.608 35.67118911276189 139.74159179391688 76.608 35.67118911276189 139.74159179391688 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e6d7e86-1e94-4a90-b573-9e2a6f7ed228">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e6d7e86-1e94-4a90-b573-9e2a6f7ed228_0">
											<gml:posList>35.67125654724186 139.7415954283377 77.817 35.67124604079241 139.74161193260304 77.817 35.67126783383689 139.74163277428676 77.817 35.67127834029757 139.74161628106603 77.817 35.67125654724186 139.7415954283377 77.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5904bca4-155e-4f5d-b9a9-e29ec6c3e177">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5904bca4-155e-4f5d-b9a9-e29ec6c3e177_0">
											<gml:posList>35.67124604079241 139.74161193260304 75.626 35.67126783383689 139.74163277428676 75.626 35.67126783383689 139.74163277428676 77.817 35.67124604079241 139.74161193260304 77.817 35.67124604079241 139.74161193260304 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ea68202-1ae0-437e-b437-bde545346313">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ea68202-1ae0-437e-b437-bde545346313_0">
											<gml:posList>35.67120928165854 139.741586766831 76.608 35.67119938709137 139.74160188959112 76.608 35.67118911276189 139.74159179391688 76.608 35.67116144577089 139.7416340668834 76.608 35.67118776753519 139.74165994051782 76.608 35.67122532910427 139.74160254478514 76.608 35.67120928165854 139.741586766831 76.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5b3f041-65c1-4d4b-a88c-d870040106a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5b3f041-65c1-4d4b-a88c-d870040106a6_0">
											<gml:posList>35.67137622490238 139.74162221146847 75.626 35.67138458679741 139.74163030995945 75.626 35.67138458679741 139.74163030995945 77.856 35.67137622490238 139.74162221146847 77.856 35.67137622490238 139.74162221146847 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3549bc0f-fe81-401b-8381-a31e5d76bbbc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3549bc0f-fe81-401b-8381-a31e5d76bbbc_0">
											<gml:posList>35.671326992582756 139.74163492694782 75.626 35.671309565368986 139.74161826683462 75.626 35.671309565368986 139.74161826683462 78.07 35.671326992582756 139.74163492694782 78.07 35.671326992582756 139.74163492694782 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3bee59d-12ce-432f-a0e1-f1effc9a52ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3bee59d-12ce-432f-a0e1-f1effc9a52ea_0">
											<gml:posList>35.6712868148741 139.741653983728 75.626 35.6712868148741 139.741653983728 78.07 35.671309565368986 139.74161826683462 78.07 35.671309565368986 139.74161826683462 75.626 35.6712868148741 139.741653983728 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ab2efda-0e7a-4126-abf7-42b5a8abff64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ab2efda-0e7a-4126-abf7-42b5a8abff64_0">
											<gml:posList>35.67135067166657 139.74164678578447 75.626 35.671339892362376 139.74163641450323 75.626 35.671339892362376 139.74163641450323 78.417 35.67135067166657 139.74164678578447 78.417 35.67135067166657 139.74164678578447 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27c936ed-512b-4b59-aa2d-09029edb49fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27c936ed-512b-4b59-aa2d-09029edb49fe_0">
											<gml:posList>35.6713042420914 139.7416706548907 78.07 35.671326992582756 139.74163492694782 78.07 35.671309565368986 139.74161826683462 78.07 35.6712868148741 139.741653983728 78.07 35.6713042420914 139.7416706548907 78.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-575b6885-db92-44ac-9cd9-c72fef3319e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-575b6885-db92-44ac-9cd9-c72fef3319e1_0">
											<gml:posList>35.67118776753519 139.74165994051782 75.626 35.67118776753519 139.74165994051782 76.608 35.67116144577089 139.7416340668834 76.608 35.67116144577089 139.7416340668834 75.626 35.67118776753519 139.74165994051782 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-411e7de4-e4b2-4b8f-8a31-7714bc2e9792">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-411e7de4-e4b2-4b8f-8a31-7714bc2e9792_0">
											<gml:posList>35.6713130723184 139.7416782557566 75.626 35.6713130723184 139.7416782557566 78.417 35.671339892362376 139.74163641450323 78.417 35.671339892362376 139.74163641450323 75.626 35.6713130723184 139.7416782557566 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d7d6313-ead8-4346-b049-1874b85101f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d7d6313-ead8-4346-b049-1874b85101f2_0">
											<gml:posList>35.67118027631785 139.74167071929395 75.626 35.67115746325717 139.74164794567483 75.626 35.67115746325717 139.74164794567483 77.173 35.67118027631785 139.74167071929395 77.173 35.67118027631785 139.74167071929395 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40912c6d-1071-4491-8ddb-fe8faf8bded4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40912c6d-1071-4491-8ddb-fe8faf8bded4_0">
											<gml:posList>35.6712868148741 139.741653983728 75.626 35.6713042420914 139.7416706548907 75.626 35.6713042420914 139.7416706548907 78.07 35.6712868148741 139.741653983728 78.07 35.6712868148741 139.741653983728 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa9aa4eb-65b1-432e-b4ea-e35137b4c28f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa9aa4eb-65b1-432e-b4ea-e35137b4c28f_0">
											<gml:posList>35.6713130723184 139.7416782557566 78.417 35.67132385161905 139.74168862704002 78.417 35.67135067166657 139.74164678578447 78.417 35.671339892362376 139.74163641450323 78.417 35.6713130723184 139.7416782557566 78.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9eed804e-03fa-4220-b504-07d70fc2e440">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9eed804e-03fa-4220-b504-07d70fc2e440_0">
											<gml:posList>35.6713130723184 139.7416782557566 75.626 35.67132385161905 139.74168862704002 75.626 35.67132385161905 139.74168862704002 78.417 35.6713130723184 139.7416782557566 78.417 35.6713130723184 139.7416782557566 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b940d57d-c1f5-4f6d-a018-5576615a0a38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b940d57d-c1f5-4f6d-a018-5576615a0a38_0">
											<gml:posList>35.671320315445165 139.74170864713912 75.626 35.67130970724722 139.74169806577655 75.626 35.67130970724722 139.74169806577655 77.02 35.671320315445165 139.74170864713912 77.02 35.671320315445165 139.74170864713912 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f1bfb4e-fdd8-4438-801d-e7f41a6cdca3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f1bfb4e-fdd8-4438-801d-e7f41a6cdca3_0">
											<gml:posList>35.67131300851095 139.74171285311704 75.626 35.67131572370879 139.74171556742579 75.626 35.67131572370879 139.74171556742579 77.02 35.67131300851095 139.74171285311704 77.02 35.67131300851095 139.74171285311704 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f17a192a-4aad-4465-a72b-d7d98daea06b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f17a192a-4aad-4465-a72b-d7d98daea06b_0">
											<gml:posList>35.67117848758952 139.74172467180784 75.626 35.671172290473045 139.74171851501495 75.626 35.671172290473045 139.74171851501495 77.13 35.67117848758952 139.74172467180784 77.13 35.67117848758952 139.74172467180784 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9181844e-8f68-4d61-b47c-5853b68e1c5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9181844e-8f68-4d61-b47c-5853b68e1c5b_0">
											<gml:posList>35.67119281834829 139.74172326359061 75.626 35.67119281834829 139.74172326359061 77.181 35.67119886212199 139.74172927695778 77.181 35.67119886212199 139.74172927695778 75.626 35.67119281834829 139.74172326359061 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2369e33c-256d-4fd0-99d8-47b77513909a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2369e33c-256d-4fd0-99d8-47b77513909a_0">
											<gml:posList>35.67117848758952 139.74172467180784 77.13 35.671172290473045 139.74171851501495 77.13 35.671160955223094 139.74173564983664 77.13 35.671167152338704 139.74174180662996 77.13 35.67117848758952 139.74172467180784 77.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44d0e325-ac66-441a-ab36-972108416db1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44d0e325-ac66-441a-ab36-972108416db1_0">
											<gml:posList>35.671164632789356 139.7415462114765 80.498 35.67116778036335 139.74154854970308 80.498 35.671389915453716 139.74154952155106 80.498 35.67143537853455 139.74159398651676 80.498 35.6712218712984 139.7419152605864 80.498 35.67104099153059 139.7417356985202 80.498 35.671056279787294 139.7417132790506 80.498 35.6710470066373 139.74170403280493 80.498 35.671025362349994 139.74173652275937 80.498 35.671222462105206 139.74193360794268 80.498 35.67144979909169 139.74159213631253 80.498 35.67142964706842 139.74157198863793 80.498 35.671393186099245 139.7415359417823 80.498 35.67115894634693 139.7415359890508 80.498 35.6711234188131 139.7415893173784 80.498 35.67113185306447 139.7415977361022 80.498 35.671164632789356 139.7415462114765 80.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-daf186a3-30b6-4280-ad54-033755b87a99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-daf186a3-30b6-4280-ad54-033755b87a99_0">
											<gml:posList>35.67121290659557 139.74174254969955 75.626 35.6712068447783 139.74173651425818 75.626 35.6712068447783 139.74173651425818 77.363 35.67121290659557 139.74174254969955 77.363 35.67121290659557 139.74174254969955 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-088e91da-b382-4773-bc77-d66e21292e37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-088e91da-b382-4773-bc77-d66e21292e37_0">
											<gml:posList>35.671226338571444 139.74175639755714 75.626 35.67122048423851 139.7417505828042 75.626 35.67122048423851 139.7417505828042 77.363 35.671226338571444 139.74175639755714 77.363 35.671226338571444 139.74175639755714 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cd6c7f7-3ea6-4b53-ade1-12c7d7631528">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4cd6c7f7-3ea6-4b53-ade1-12c7d7631528_0">
											<gml:posList>35.67119886212199 139.74172927695778 77.181 35.67119281834829 139.74172326359061 77.181 35.67115621960218 139.74177857038075 77.181 35.67116226336476 139.741784572703 77.181 35.67119886212199 139.74172927695778 77.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cddaf3cb-b9ca-4fe2-83a2-ec338f2ee238">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cddaf3cb-b9ca-4fe2-83a2-ec338f2ee238_0">
											<gml:posList>35.6712218712984 139.7419152605864 80.498 35.67143537853455 139.74159398651676 80.498 35.67143537853455 139.74159398651676 75.626 35.6712218712984 139.7419152605864 75.626 35.6712218712984 139.7419152605864 80.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a716275-d031-4256-8973-e3d3756f5c6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a716275-d031-4256-8973-e3d3756f5c6c_0">
											<gml:posList>35.671222462105206 139.74193360794268 80.498 35.671222462105206 139.74193360794268 75.626 35.67144979909169 139.74159213631253 75.626 35.67144979909169 139.74159213631253 80.498 35.671222462105206 139.74193360794268 80.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cebcde82-27a7-4891-b0ca-87caa078a5e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cebcde82-27a7-4891-b0ca-87caa078a5e8_0">
											<gml:posList>35.671169966911535 139.7417922300863 75.626 35.671169966911535 139.7417922300863 77.363 35.6712068447783 139.74173651425818 77.363 35.6712068447783 139.74173651425818 75.626 35.671169966911535 139.7417922300863 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40da5051-ef95-4f51-a1d4-bae758d3188b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40da5051-ef95-4f51-a1d4-bae758d3188b_0">
											<gml:posList>35.67124177864847 139.74176766931987 75.626 35.67123642943733 139.74176231793595 75.626 35.67123642943733 139.74176231793595 77.363 35.67124177864847 139.74176766931987 77.363 35.67124177864847 139.74176766931987 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1419495a-3872-46b1-8767-932ae97cade9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1419495a-3872-46b1-8767-932ae97cade9_0">
											<gml:posList>35.67121290659557 139.74174254969955 77.363 35.6712068447783 139.74173651425818 77.363 35.671169966911535 139.7417922300863 77.363 35.67117603773978 139.74179826551884 77.363 35.67121290659557 139.74174254969955 77.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f77f7e5-92c7-42d8-8b36-03964d1042d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f77f7e5-92c7-42d8-8b36-03964d1042d7_0">
											<gml:posList>35.67123642943733 139.74176231793595 75.626 35.67122533718221 139.74177896644713 75.626 35.67122533718221 139.74177896644713 77.363 35.67123642943733 139.74176231793595 77.363 35.67123642943733 139.74176231793595 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6876278-f4f2-4b3e-bd18-e4ffe2f2a6ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6876278-f4f2-4b3e-bd18-e4ffe2f2a6ad_0">
											<gml:posList>35.67124177864847 139.74176766931987 77.363 35.67123642943733 139.74176231793595 77.363 35.67122533718221 139.74177896644713 77.363 35.6712306773789 139.74178431784173 77.363 35.67124177864847 139.74176766931987 77.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8000ce4-612f-4002-94f7-a83f6fe8d4bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8000ce4-612f-4002-94f7-a83f6fe8d4bc_0">
											<gml:posList>35.67122048423851 139.7417505828042 77.363 35.67118381344583 139.74180598910058 77.363 35.6711896587624 139.7418118038652 77.363 35.671226338571444 139.74175639755714 77.363 35.67122048423851 139.7417505828042 77.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b44f2dee-158e-4a9e-95a7-496ac86c84ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b44f2dee-158e-4a9e-95a7-496ac86c84ab_0">
											<gml:posList>35.67122533718221 139.74177896644713 75.626 35.6712306773789 139.74178431784173 75.626 35.6712306773789 139.74178431784173 77.363 35.67122533718221 139.74177896644713 77.363 35.67122533718221 139.74177896644713 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9aa0e9ff-a3b4-45c5-b8ae-2c2ae5a9c9e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9aa0e9ff-a3b4-45c5-b8ae-2c2ae5a9c9e6_0">
											<gml:posList>35.6711234188131 139.7415893173784 75.626 35.6711234188131 139.7415893173784 80.498 35.67115894634693 139.7415359890508 80.498 35.67115894634693 139.7415359890508 75.626 35.6711234188131 139.7415893173784 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c90d337-b1e5-4354-b43a-f3c54e5675c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c90d337-b1e5-4354-b43a-f3c54e5675c9_0">
											<gml:posList>35.67113185306447 139.7415977361022 75.626 35.671164632789356 139.7415462114765 75.626 35.671164632789356 139.7415462114765 80.498 35.67113185306447 139.7415977361022 80.498 35.67113185306447 139.7415977361022 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-844a3abb-cc8b-46a7-8b32-a44de961df80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-844a3abb-cc8b-46a7-8b32-a44de961df80_0">
											<gml:posList>35.6711234188131 139.7415893173784 80.498 35.6711234188131 139.7415893173784 75.626 35.67113185306447 139.7415977361022 75.626 35.67113185306447 139.7415977361022 80.498 35.6711234188131 139.7415893173784 80.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dded974c-c21d-4934-82de-08bc4e0333f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dded974c-c21d-4934-82de-08bc4e0333f7_0">
											<gml:posList>35.67115746325717 139.74164794567483 75.626 35.67114894603242 139.74166076919877 75.626 35.67114894603242 139.74166076919877 77.173 35.67115746325717 139.74164794567483 77.173 35.67115746325717 139.74164794567483 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c60be20a-42bb-450d-99ce-4c4e4ffc51b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c60be20a-42bb-450d-99ce-4c4e4ffc51b1_0">
											<gml:posList>35.67114894603242 139.74166076919877 75.626 35.67116255809043 139.74167435171293 75.626 35.67116255809043 139.74167435171293 77.173 35.67114894603242 139.74166076919877 77.173 35.67114894603242 139.74166076919877 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4baa5f39-d157-4f49-b8d8-258c94987928">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4baa5f39-d157-4f49-b8d8-258c94987928_0">
											<gml:posList>35.6710470066373 139.74170403280493 80.498 35.671056279787294 139.7417132790506 80.498 35.671056279787294 139.7417132790506 75.626 35.6710470066373 139.74170403280493 75.626 35.6710470066373 139.74170403280493 80.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22e27b43-e1de-437f-bca0-dad7b9d97635">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22e27b43-e1de-437f-bca0-dad7b9d97635_0">
											<gml:posList>35.67111089596271 139.74177514253378 77.173 35.67118027631785 139.74167071929395 77.173 35.67115746325717 139.74164794567483 77.173 35.67114894603242 139.74166076919877 77.173 35.67116255809043 139.74167435171293 77.173 35.671104630082525 139.74176152952813 77.173 35.67109981309225 139.7417567188174 77.173 35.671096868973905 139.74176115176988 77.173 35.67111089596271 139.74177514253378 77.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80f60551-4ca3-44a5-bdf6-15a4030ec8b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80f60551-4ca3-44a5-bdf6-15a4030ec8b4_0">
											<gml:posList>35.671104630082525 139.74176152952813 75.626 35.671104630082525 139.74176152952813 77.173 35.67116255809043 139.74167435171293 77.173 35.67116255809043 139.74167435171293 75.626 35.671104630082525 139.74176152952813 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb4bbe5c-d1ef-4cd0-81e9-50add402f5c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb4bbe5c-d1ef-4cd0-81e9-50add402f5c5_0">
											<gml:posList>35.6710470066373 139.74170403280493 80.498 35.6710470066373 139.74170403280493 75.626 35.671025362349994 139.74173652275937 75.626 35.671025362349994 139.74173652275937 80.498 35.6710470066373 139.74170403280493 80.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75466a47-69ed-4cff-8fee-e0d419359072">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75466a47-69ed-4cff-8fee-e0d419359072_0">
											<gml:posList>35.67111089596271 139.74177514253378 75.626 35.67118027631785 139.74167071929395 75.626 35.67118027631785 139.74167071929395 77.173 35.67111089596271 139.74177514253378 77.173 35.67111089596271 139.74177514253378 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a16fa24-65de-4cf9-8e01-3ad006ccf967">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a16fa24-65de-4cf9-8e01-3ad006ccf967_0">
											<gml:posList>35.671056279787294 139.7417132790506 75.626 35.671056279787294 139.7417132790506 80.498 35.67104099153059 139.7417356985202 80.498 35.67104099153059 139.7417356985202 75.626 35.671056279787294 139.7417132790506 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a65322f-1fc7-4462-9641-84c07b639513">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a65322f-1fc7-4462-9641-84c07b639513_0">
											<gml:posList>35.67109981309225 139.7417567188174 75.626 35.671096868973905 139.74176115176988 75.626 35.671096868973905 139.74176115176988 77.173 35.67109981309225 139.7417567188174 77.173 35.67109981309225 139.7417567188174 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ae4640b-4fc8-451a-bebb-64062a333cf0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ae4640b-4fc8-451a-bebb-64062a333cf0_0">
											<gml:posList>35.671104630082525 139.74176152952813 75.626 35.67109981309225 139.7417567188174 75.626 35.67109981309225 139.7417567188174 77.173 35.671104630082525 139.74176152952813 77.173 35.671104630082525 139.74176152952813 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3037176e-61dd-4071-9f89-54555b957eb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3037176e-61dd-4071-9f89-54555b957eb5_0">
											<gml:posList>35.671089713624376 139.74176319247212 75.626 35.67108138550739 139.7417757948299 75.626 35.67108138550739 139.7417757948299 76.818 35.671089713624376 139.74176319247212 76.818 35.671089713624376 139.74176319247212 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39df64d5-229f-424c-99da-966679a495e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39df64d5-229f-424c-99da-966679a495e3_0">
											<gml:posList>35.67110664517318 139.74177999673998 75.626 35.671089713624376 139.74176319247212 75.626 35.671089713624376 139.74176319247212 76.818 35.67110664517318 139.74177999673998 76.818 35.67110664517318 139.74177999673998 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4a9b3fa-8748-4ede-9a93-15ee5a070349">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4a9b3fa-8748-4ede-9a93-15ee5a070349_0">
											<gml:posList>35.67110664517318 139.74177999673998 76.818 35.671089713624376 139.74176319247212 76.818 35.67108138550739 139.7417757948299 76.818 35.671098317054465 139.74179259909866 76.818 35.67110664517318 139.74177999673998 76.818</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70812975-293b-40e3-8a8c-ea663ad0a6b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70812975-293b-40e3-8a8c-ea663ad0a6b8_0">
											<gml:posList>35.671098317054465 139.74179259909866 75.626 35.67110664517318 139.74177999673998 75.626 35.67110664517318 139.74177999673998 76.818 35.671098317054465 139.74179259909866 76.818 35.671098317054465 139.74179259909866 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a63d4b8e-fe65-4c3b-9774-b766fc77e319">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a63d4b8e-fe65-4c3b-9774-b766fc77e319_0">
											<gml:posList>35.67104099153059 139.7417356985202 75.626 35.67104099153059 139.7417356985202 80.498 35.6712218712984 139.7419152605864 80.498 35.6712218712984 139.7419152605864 75.626 35.671098317054465 139.74179259909866 75.626 35.671098317054465 139.74179259909866 76.818 35.67108138550739 139.7417757948299 76.818 35.67108138550739 139.7417757948299 75.626 35.67104099153059 139.7417356985202 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-891aa583-5935-48f3-9fc7-ab7c2481d3a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-891aa583-5935-48f3-9fc7-ab7c2481d3a4_0">
											<gml:posList>35.671025362349994 139.74173652275937 80.498 35.671025362349994 139.74173652275937 75.626 35.671222462105206 139.74193360794268 75.626 35.671222462105206 139.74193360794268 80.498 35.671025362349994 139.74173652275937 80.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-122169c5-c5f0-40f6-9bdd-27261013097c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67109981309225 139.7417567188174 75.626 35.671104630082525 139.74176152952813 75.626 35.67116255809043 139.74167435171293 75.626 35.67114894603242 139.74166076919877 75.626 35.67115746325717 139.74164794567483 75.626 35.67118027631785 139.74167071929395 75.626 35.67111089596271 139.74177514253378 75.626 35.671096868973905 139.74176115176988 75.626 35.67109981309225 139.7417567188174 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ab9374d-235b-4993-878b-5b172f1729d1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671160955223094 139.74173564983664 75.626 35.671172290473045 139.74171851501495 75.626 35.67117848758952 139.74172467180784 75.626 35.671167152338704 139.74174180662996 75.626 35.671160955223094 139.74173564983664 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14de8a54-275c-4a1d-8b70-d051b4c6e4e5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671167152338704 139.74174180662996 75.626 35.67117848758952 139.74172467180784 75.626 35.67117848758952 139.74172467180784 77.13 35.671167152338704 139.74174180662996 77.13 35.671167152338704 139.74174180662996 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-506bbba6-7f61-4803-b6d4-506d7db5c48a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117376336787 139.74156943153727 75.626 35.671167584414036 139.74156346252423 75.626 35.67117501194475 139.74155192161325 75.626 35.67118119090757 139.74155790167234 75.626 35.67117376336787 139.74156943153727 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed51d86d-2fb0-48d4-b721-764b883abc8b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117401879309 139.74183401387376 75.626 35.671168398988506 139.74182841977864 75.626 35.671176817164124 139.74181570684615 75.626 35.67118243696089 139.7418212898946 75.626 35.67117401879309 139.74183401387376 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-214c4a23-5a3a-4fab-a20c-69723b22718f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119886212199 139.74172927695778 75.626 35.67116226336476 139.741784572703 75.626 35.67115621960218 139.74177857038075 75.626 35.67119281834829 139.74172326359061 75.626 35.67119886212199 139.74172927695778 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c519ee83-1649-45b7-9e0a-fe5874567f9a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67116226336476 139.741784572703 75.626 35.67119886212199 139.74172927695778 75.626 35.67119886212199 139.74172927695778 77.181 35.67116226336476 139.741784572703 77.181 35.67116226336476 139.741784572703 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e45977dd-cc7a-4fe4-8827-f2491b494af9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671181689546366 139.74185783213966 75.626 35.671176340347564 139.7418524918001 75.626 35.67118691941 139.7418366060945 75.626 35.67119226861789 139.7418419574801 75.626 35.671181689546366 139.74185783213966 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cbf5cc9-5f30-4f9a-98ef-1f09ea7ef026">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119226861789 139.7418419574801 75.626 35.67118691941 139.7418366060945 75.626 35.67118691941 139.7418366060945 77.363 35.67119226861789 139.7418419574801 77.363 35.67119226861789 139.7418419574801 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f64f6e1-59e0-43e3-9806-37a4cf83a07a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119324099192 139.74184049824942 75.626 35.67119324099192 139.74184049824942 77.363 35.671187900797705 139.7418351468536 77.363 35.671187900797705 139.7418351468536 75.626 35.67119324099192 139.74184049824942 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63506a2a-0393-43e1-9204-43fec8239c4c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671169966911535 139.7417922300863 75.626 35.6712068447783 139.74173651425818 75.626 35.67121290659557 139.74174254969955 75.626 35.67117603773978 139.74179826551884 75.626 35.671169966911535 139.7417922300863 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f1d129b-f27c-4957-afc7-88c20686c29c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119938709137 139.74160188959112 75.626 35.67120928165854 139.741586766831 75.626 35.67122532910427 139.74160254478514 75.626 35.67118776753519 139.74165994051782 75.626 35.67116144577089 139.7416340668834 75.626 35.67118911276189 139.74159179391688 75.626 35.67119938709137 139.74160188959112 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7688f4d9-6b18-45b3-b8bb-a8d5909bf239">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121290659557 139.74174254969955 75.626 35.67121290659557 139.74174254969955 77.363 35.67117603773978 139.74179826551884 77.363 35.67117603773978 139.74179826551884 75.626 35.67121290659557 139.74174254969955 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12ab1229-bc90-451c-b056-37b7889c9ec8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67120471139542 139.74182327491042 75.626 35.67119324099192 139.74184049824942 75.626 35.671187900797705 139.7418351468536 75.626 35.67119937120882 139.7418179345613 75.626 35.67120471139542 139.74182327491042 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8fcb92e-d731-4260-9a8c-1653228cd6b7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67120471139542 139.74182327491042 75.626 35.67119937120882 139.7418179345613 75.626 35.67119937120882 139.7418179345613 77.363 35.67120471139542 139.74182327491042 77.363 35.67120471139542 139.74182327491042 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5da09c66-2ae4-4192-8fb5-3faba3750a1b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6711896587624 139.7418118038652 75.626 35.67118381344583 139.74180598910058 75.626 35.67122048423851 139.7417505828042 75.626 35.671226338571444 139.74175639755714 75.626 35.6711896587624 139.7418118038652 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50c7616e-c734-45e0-b5c1-5d279c8aa572">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67120050564486 139.74181623212505 75.626 35.67120050564486 139.74181623212505 77.363 35.67121171495762 139.7417994177949 77.363 35.67121171495762 139.7417994177949 75.626 35.67120050564486 139.74181623212505 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44c5387b-f794-413a-8e0c-b211ed3a0a98">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67120584583993 139.74182158352048 75.626 35.67120050564486 139.74181623212505 75.626 35.67121171495762 139.7417994177949 75.626 35.67121705514502 139.7418047581436 75.626 35.67120584583993 139.74182158352048 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b27642b7-1317-4c1d-b1fc-62aee5260667">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121171495762 139.7417994177949 75.626 35.67121171495762 139.7417994177949 77.363 35.67121705514502 139.7418047581436 77.363 35.67121705514502 139.7418047581436 75.626 35.67121171495762 139.7417994177949 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-541fc2e7-58ca-488a-8f17-3dae49e82fe6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67122421175203 139.7417806578278 75.626 35.67121318251482 139.74179720684458 75.626 35.67121318251482 139.74179720684458 77.363 35.67122421175203 139.7417806578278 77.363 35.67122421175203 139.7417806578278 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f22b38ba-1576-426e-bd28-9d9f83b10780">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121852271071 139.74180255823956 75.626 35.67121318251482 139.74179720684458 75.626 35.67122421175203 139.7417806578278 75.626 35.67122955194024 139.74178599817606 75.626 35.67121852271071 139.74180255823956 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e26c70cd-7ff4-4a2f-9488-8359fe6f1d45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67122533718221 139.74177896644713 75.626 35.67123642943733 139.74176231793595 75.626 35.67124177864847 139.74176766931987 75.626 35.6712306773789 139.74178431784173 75.626 35.67122533718221 139.74177896644713 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7b3cf68-ec19-4ff3-83ce-80a5b9a2e38c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67118949451174 139.74154864635472 75.626 35.67116778036335 139.74154854970308 75.626 35.671164632789356 139.7415462114765 75.626 35.67113185306447 139.7415977361022 75.626 35.6711234188131 139.7415893173784 75.626 35.67115894634693 139.7415359890508 75.626 35.671393186099245 139.7415359417823 75.626 35.67142964706842 139.74157198863793 75.626 35.67144979909169 139.74159213631253 75.626 35.671222462105206 139.74193360794268 75.626 35.671025362349994 139.74173652275937 75.626 35.6710470066373 139.74170403280493 75.626 35.671056279787294 139.7417132790506 75.626 35.67104099153059 139.7417356985202 75.626 35.67108138550739 139.7417757948299 75.626 35.671089713624376 139.74176319247212 75.626 35.67110664517318 139.74177999673998 75.626 35.671098317054465 139.74179259909866 75.626 35.6712218712984 139.7419152605864 75.626 35.67143537853455 139.74159398651676 75.626 35.671389915453716 139.74154952155106 75.626 35.67121683324764 139.7415487697065 75.626 35.67121890793609 139.74155077777166 75.626 35.6711943385491 139.74158893797332 75.626 35.67117535968054 139.741570589579 75.626 35.67118949451174 139.74154864635472 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25241575-a242-4c01-8d61-476e778f871b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67131300851095 139.74171285311704 75.626 35.67119700839417 139.74188751835632 75.626 35.6711891063838 139.74187964026024 75.626 35.67130970724722 139.74169806577655 75.626 35.671320315445165 139.74170864713912 75.626 35.67131572370879 139.74171556742579 75.626 35.67131300851095 139.74171285311704 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88a9e548-904e-44e6-b6e6-4826eebfcb21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67126783383689 139.74163277428676 75.626 35.67124604079241 139.74161193260304 75.626 35.67125654724186 139.7415954283377 75.626 35.67127834029757 139.74161628106603 75.626 35.67126783383689 139.74163277428676 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64f7d38c-9f5e-4b4e-b489-1cf5f7514a60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67128390413954 139.74159572842683 75.626 35.67126263427179 139.74157539428379 75.626 35.67127350083567 139.7415583262325 75.626 35.671294770706254 139.74157866037376 75.626 35.67128390413954 139.74159572842683 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33a66594-b77f-4c8c-83b6-6abdf101f9e1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671309565368986 139.74161826683462 75.626 35.671326992582756 139.74163492694782 75.626 35.6713042420914 139.7416706548907 75.626 35.6712868148741 139.741653983728 75.626 35.671309565368986 139.74161826683462 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0069887-a988-4294-98bb-d0603af64e87">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671322653880324 139.74155987169414 75.626 35.67133401958812 139.74157090507515 75.626 35.67132528656441 139.74158441375866 75.626 35.67131392085784 139.74157338037693 75.626 35.671322653880324 139.74155987169414 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7f08daa-1321-4a45-9679-fb2410d6f702">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67135067166657 139.74164678578447 75.626 35.67132385161905 139.74168862704002 75.626 35.6713130723184 139.7416782557566 75.626 35.671339892362376 139.74163641450323 75.626 35.67135067166657 139.74164678578447 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e98e5c6-1efc-46d3-8743-66e33e2b64e1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6713634652276 139.74156799931097 75.626 35.67137980116501 139.74158384323985 75.626 35.671363046389516 139.7416097993489 75.626 35.671346701433336 139.74159394438198 75.626 35.6713634652276 139.74156799931097 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-907c7786-b000-460a-9200-0c0ed91cebf1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67138458679741 139.74163030995945 75.626 35.67137622490238 139.74162221146847 75.626 35.671399677977966 139.7415858640774 75.626 35.6714080398838 139.74159397361333 75.626 35.67138458679741 139.74163030995945 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_80e11178-9358-4100-baee-ecdd4fc55f4f_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2fe4b75-d2ae-4c3a-9cbf-0e4300731058">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67112240580907 139.7417979511734 75.626 35.6711238463335 139.74179575130273 75.626 35.67111082979103 139.74178295238605 75.626 35.67121136920893 139.74162932612148 75.626 35.671209195278315 139.74162719665787 75.626 35.671218522640494 139.7416129361652 75.626 35.67122589237909 139.74162018520326 75.626 35.671119932986684 139.74178206932874 75.626 35.67113629611409 139.74179814519587 75.626 35.671138654971664 139.7417945413881 75.626 35.671135407604844 139.74179135269665 75.626 35.67114081856982 139.74178308383802 75.626 35.67115584666693 139.74179784671605 75.626 35.67115037268048 139.7418062150645 75.626 35.67114703510957 139.74180293810414 75.626 35.67114473927223 139.74180644242284 75.626 35.67114675084356 139.7418084284722 75.626 35.67114139389202 139.74181660889715 75.626 35.67112240580907 139.7417979511734 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f57bc777-15f1-4b0f-8fff-1b822b38ef82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f57bc777-15f1-4b0f-8fff-1b822b38ef82_0">
											<gml:posList>35.671135407604844 139.74179135269665 75.626 35.671135407604844 139.74179135269665 76.891 35.67114081856982 139.74178308383802 76.891 35.67114081856982 139.74178308383802 75.626 35.671135407604844 139.74179135269665 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3010855f-f969-4fb8-95a2-e874b01d3bb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3010855f-f969-4fb8-95a2-e874b01d3bb2_0">
											<gml:posList>35.671138654971664 139.7417945413881 75.626 35.671138654971664 139.7417945413881 76.891 35.671135407604844 139.74179135269665 76.891 35.671135407604844 139.74179135269665 75.626 35.671138654971664 139.7417945413881 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14836094-cb21-45cb-aabb-9c9d92805108">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14836094-cb21-45cb-aabb-9c9d92805108_0">
											<gml:posList>35.67114473927223 139.74180644242284 75.626 35.67114473927223 139.74180644242284 76.891 35.67114675084356 139.7418084284722 76.891 35.67114675084356 139.7418084284722 75.626 35.67114473927223 139.74180644242284 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92a8aa1f-a7d7-43b1-89fd-91046e3f65c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92a8aa1f-a7d7-43b1-89fd-91046e3f65c2_0">
											<gml:posList>35.671218522640494 139.7416129361652 75.626 35.671218522640494 139.7416129361652 76.891 35.67122589237909 139.74162018520326 76.891 35.67122589237909 139.74162018520326 75.626 35.671218522640494 139.7416129361652 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-232edb52-32c8-40fa-96f9-d4bd533e3465">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-232edb52-32c8-40fa-96f9-d4bd533e3465_0">
											<gml:posList>35.671209195278315 139.74162719665787 75.626 35.671209195278315 139.74162719665787 76.891 35.671218522640494 139.7416129361652 76.891 35.671218522640494 139.7416129361652 75.626 35.671209195278315 139.74162719665787 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e766b222-854d-4d14-8312-2ff072cc8ebc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e766b222-854d-4d14-8312-2ff072cc8ebc_0">
											<gml:posList>35.67121136920893 139.74162932612148 75.626 35.67121136920893 139.74162932612148 76.891 35.671209195278315 139.74162719665787 76.891 35.671209195278315 139.74162719665787 75.626 35.67121136920893 139.74162932612148 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8769ea4-47f9-4871-aea2-b48b06dd4def">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8769ea4-47f9-4871-aea2-b48b06dd4def_0">
											<gml:posList>35.67122589237909 139.74162018520326 76.891 35.671119932986684 139.74178206932874 76.891 35.671119932986684 139.74178206932874 75.626 35.67122589237909 139.74162018520326 75.626 35.67122589237909 139.74162018520326 76.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-087c0c2d-5dc2-4cf6-b6d4-c9f21907074a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-087c0c2d-5dc2-4cf6-b6d4-c9f21907074a_0">
											<gml:posList>35.67111082979103 139.74178295238605 75.626 35.67111082979103 139.74178295238605 76.891 35.67121136920893 139.74162932612148 76.891 35.67121136920893 139.74162932612148 75.626 35.67111082979103 139.74178295238605 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b9b7f34-59be-4744-8281-5784aad3d357">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b9b7f34-59be-4744-8281-5784aad3d357_0">
											<gml:posList>35.67114675084356 139.7418084284722 76.891 35.67114473927223 139.74180644242284 76.891 35.67114703510957 139.74180293810414 76.891 35.67115037268048 139.7418062150645 76.891 35.67115584666693 139.74179784671605 76.891 35.67114081856982 139.74178308383802 76.891 35.671135407604844 139.74179135269665 76.891 35.671138654971664 139.7417945413881 76.891 35.67113629611409 139.74179814519587 76.891 35.671119932986684 139.74178206932874 76.891 35.67122589237909 139.74162018520326 76.891 35.671218522640494 139.7416129361652 76.891 35.671209195278315 139.74162719665787 76.891 35.67121136920893 139.74162932612148 76.891 35.67111082979103 139.74178295238605 76.891 35.6711238463335 139.74179575130273 76.891 35.67112240580907 139.7417979511734 76.891 35.67114139389202 139.74181660889715 76.891 35.67114675084356 139.7418084284722 76.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71b70ee9-03d3-42a7-bb43-3151a17ffe78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71b70ee9-03d3-42a7-bb43-3151a17ffe78_0">
											<gml:posList>35.6711238463335 139.74179575130273 75.626 35.6711238463335 139.74179575130273 76.891 35.67111082979103 139.74178295238605 76.891 35.67111082979103 139.74178295238605 75.626 35.6711238463335 139.74179575130273 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0dec9245-58d0-42e7-9c27-83f378cc2bfd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0dec9245-58d0-42e7-9c27-83f378cc2bfd_0">
											<gml:posList>35.671119932986684 139.74178206932874 75.626 35.671119932986684 139.74178206932874 76.891 35.67113629611409 139.74179814519587 76.891 35.67113629611409 139.74179814519587 75.626 35.671119932986684 139.74178206932874 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4e84773-8c64-44ed-8d3d-f34c8f64943b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4e84773-8c64-44ed-8d3d-f34c8f64943b_0">
											<gml:posList>35.67114081856982 139.74178308383802 75.626 35.67114081856982 139.74178308383802 76.891 35.67115584666693 139.74179784671605 76.891 35.67115584666693 139.74179784671605 75.626 35.67114081856982 139.74178308383802 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abb56f2e-f90e-4dc0-9095-7b2684426c29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abb56f2e-f90e-4dc0-9095-7b2684426c29_0">
											<gml:posList>35.67113629611409 139.74179814519587 75.626 35.67113629611409 139.74179814519587 76.891 35.671138654971664 139.7417945413881 76.891 35.671138654971664 139.7417945413881 75.626 35.67113629611409 139.74179814519587 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f22b5249-27f3-4162-be03-3f9b7096ec78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f22b5249-27f3-4162-be03-3f9b7096ec78_0">
											<gml:posList>35.67112240580907 139.7417979511734 75.626 35.67112240580907 139.7417979511734 76.891 35.6711238463335 139.74179575130273 76.891 35.6711238463335 139.74179575130273 75.626 35.67112240580907 139.7417979511734 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0593d49c-d1aa-472c-8152-ad177e554556">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0593d49c-d1aa-472c-8152-ad177e554556_0">
											<gml:posList>35.67115584666693 139.74179784671605 75.626 35.67115584666693 139.74179784671605 76.891 35.67115037268048 139.7418062150645 76.891 35.67115037268048 139.7418062150645 75.626 35.67115584666693 139.74179784671605 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1f2d6f7-cc12-43ad-91ad-d33382d00063">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1f2d6f7-cc12-43ad-91ad-d33382d00063_0">
											<gml:posList>35.67115037268048 139.7418062150645 75.626 35.67115037268048 139.7418062150645 76.891 35.67114703510957 139.74180293810414 76.891 35.67114703510957 139.74180293810414 75.626 35.67115037268048 139.7418062150645 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-249e148a-485c-466f-8980-5e2ec3859c69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-249e148a-485c-466f-8980-5e2ec3859c69_0">
											<gml:posList>35.67114703510957 139.74180293810414 75.626 35.67114703510957 139.74180293810414 76.891 35.67114473927223 139.74180644242284 76.891 35.67114473927223 139.74180644242284 75.626 35.67114703510957 139.74180293810414 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bf579d1-bafa-4562-8422-54b855f22fef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bf579d1-bafa-4562-8422-54b855f22fef_0">
											<gml:posList>35.67114139389202 139.74181660889715 75.626 35.67114139389202 139.74181660889715 76.891 35.67112240580907 139.7417979511734 76.891 35.67112240580907 139.7417979511734 75.626 35.67114139389202 139.74181660889715 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c70bec96-fa45-43a2-bdd6-1283dc5c4137">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c70bec96-fa45-43a2-bdd6-1283dc5c4137_0">
											<gml:posList>35.67114675084356 139.7418084284722 75.626 35.67114675084356 139.7418084284722 76.891 35.67114139389202 139.74181660889715 76.891 35.67114139389202 139.74181660889715 75.626 35.67114675084356 139.7418084284722 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_80e11178-9358-4100-baee-ecdd4fc55f4f_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed1e3909-c660-4831-b9d4-51bafb870895">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671215497554634 139.74190202325073 75.626 35.671198574986484 139.7418851526458 75.626 35.67131300851095 139.74171285311704 75.626 35.6713299311113 139.74172973475592 75.626 35.671215497554634 139.74190202325073 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-094ee9d4-ec58-4628-b6f3-e8e5cdf92cda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-094ee9d4-ec58-4628-b6f3-e8e5cdf92cda_0">
											<gml:posList>35.6713299311113 139.74172973475592 78.372 35.6713299311113 139.74172973475592 75.626 35.67131300851095 139.74171285311704 75.626 35.67131300851095 139.74171285311704 78.372 35.6713299311113 139.74172973475592 78.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96845ec5-6672-4448-af15-78acc78c1bdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96845ec5-6672-4448-af15-78acc78c1bdf_0">
											<gml:posList>35.671198574986484 139.7418851526458 75.626 35.671198574986484 139.7418851526458 78.372 35.67131300851095 139.74171285311704 78.372 35.67131300851095 139.74171285311704 75.626 35.671198574986484 139.7418851526458 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cf8943a-f866-4a8b-a6b2-53fe402679a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cf8943a-f866-4a8b-a6b2-53fe402679a1_0">
											<gml:posList>35.67131300851095 139.74171285311704 78.372 35.671198574986484 139.7418851526458 78.372 35.671215497554634 139.74190202325073 78.372 35.6713299311113 139.74172973475592 78.372 35.67131300851095 139.74171285311704 78.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edf43b97-43c7-43df-80be-11be8201bb87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edf43b97-43c7-43df-80be-11be8201bb87_0">
											<gml:posList>35.6713299311113 139.74172973475592 75.626 35.6713299311113 139.74172973475592 78.372 35.671215497554634 139.74190202325073 78.372 35.671215497554634 139.74190202325073 75.626 35.6713299311113 139.74172973475592 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf1a5b0e-2336-43fc-83ab-7a8946e20f13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf1a5b0e-2336-43fc-83ab-7a8946e20f13_0">
											<gml:posList>35.671215497554634 139.74190202325073 75.626 35.671215497554634 139.74190202325073 78.372 35.671198574986484 139.7418851526458 78.372 35.671198574986484 139.7418851526458 75.626 35.671215497554634 139.74190202325073 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b13a7338-1f42-4f85-b5a4-ab9e436fa4f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b13a7338-1f42-4f85-b5a4-ab9e436fa4f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b13a7338-1f42-4f85-b5a4-ab9e436fa4f4">
											<gml:posList>35.671156173677126 139.74152883417992 7.25 35.67139566842911 139.74152878087327 7.25 35.67145800081225 139.7415911217044 7.25 35.67122328096995 139.7419436592111 7.25 35.67101716063597 139.74173754839342 7.25 35.671156173677126 139.74152883417992 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b9d13d0-aa54-42d2-84d3-1d2a58945505">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b9d13d0-aa54-42d2-84d3-1d2a58945505">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b9d13d0-aa54-42d2-84d3-1d2a58945505">
											<gml:posList>35.67139358270298 139.74153594132824 81.005 35.67139566842911 139.74152878087327 81.005 35.671156173677126 139.74152883417992 81.005 35.67115894634693 139.7415359890508 81.005 35.67139358270298 139.74153594132824 81.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6422f01-dc32-4690-8d9d-26bfbee7dd3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6422f01-dc32-4690-8d9d-26bfbee7dd3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6422f01-dc32-4690-8d9d-26bfbee7dd3b">
											<gml:posList>35.67144979909169 139.74159213631253 81.005 35.67145800081225 139.7415911217044 81.005 35.67139566842911 139.74152878087327 81.005 35.67139358270298 139.74153594132824 81.005 35.67144979909169 139.74159213631253 81.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68751354-49d0-45a4-a643-fc3123a3e1d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68751354-49d0-45a4-a643-fc3123a3e1d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68751354-49d0-45a4-a643-fc3123a3e1d2">
											<gml:posList>35.671156173677126 139.74152883417992 81.005 35.67101716063597 139.74173754839342 81.005 35.671025362349994 139.74173652275937 81.005 35.67115894634693 139.7415359890508 81.005 35.671156173677126 139.74152883417992 81.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d2ef8fa4-46fb-4379-8e72-1b766b8e31e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2ef8fa4-46fb-4379-8e72-1b766b8e31e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2ef8fa4-46fb-4379-8e72-1b766b8e31e6">
											<gml:posList>35.67104779893701 139.74170283889347 80.194 35.671102427659676 139.7417574890762 80.194 35.671161724346085 139.74166846495234 80.194 35.671137025945065 139.74164376038155 80.194 35.671154789727 139.74161709623115 80.194 35.671124859358976 139.741587150643 80.194 35.67104779893701 139.74170283889347 80.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-311ae2ae-85c9-4c21-8cfe-a12b26876cdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-311ae2ae-85c9-4c21-8cfe-a12b26876cdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-311ae2ae-85c9-4c21-8cfe-a12b26876cdb">
											<gml:posList>35.671154789727 139.74161709623115 75.626 35.671137025945065 139.74164376038155 75.626 35.671161724346085 139.74166846495234 75.626 35.671102427659676 139.7417574890762 75.626 35.67104779893701 139.74170283889347 75.626 35.671025362349994 139.74173652275937 75.626 35.671222462105206 139.74193360794268 75.626 35.67144979909169 139.74159213631253 75.626 35.67139358270298 139.74153594132824 75.626 35.67115894634693 139.7415359890508 75.626 35.671124859358976 139.741587150643 75.626 35.671154789727 139.74161709623115 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-623c5285-17d8-4c78-ad84-0b67dd15dcde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-623c5285-17d8-4c78-ad84-0b67dd15dcde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-623c5285-17d8-4c78-ad84-0b67dd15dcde">
											<gml:posList>35.671222462105206 139.74193360794268 81.005 35.67122328096995 139.7419436592111 81.005 35.67145800081225 139.7415911217044 81.005 35.67144979909169 139.74159213631253 81.005 35.671222462105206 139.74193360794268 81.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c7d4c32-8604-44c9-8031-ac69ffaa1122">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c7d4c32-8604-44c9-8031-ac69ffaa1122">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c7d4c32-8604-44c9-8031-ac69ffaa1122">
											<gml:posList>35.671025362349994 139.74173652275937 81.005 35.67101716063597 139.74173754839342 81.005 35.67122328096995 139.7419436592111 81.005 35.671222462105206 139.74193360794268 81.005 35.671025362349994 139.74173652275937 81.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8e0fa4c-cdc5-4116-acf1-a315aee58703">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8e0fa4c-cdc5-4116-acf1-a315aee58703">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8e0fa4c-cdc5-4116-acf1-a315aee58703">
											<gml:posList>35.67104779893701 139.74170283889347 80.194 35.67104779893701 139.74170283889347 75.626 35.671102427659676 139.7417574890762 75.626 35.671102427659676 139.7417574890762 80.194 35.67104779893701 139.74170283889347 80.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-182a6a09-c916-4625-b9c5-9dffe2f259d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-182a6a09-c916-4625-b9c5-9dffe2f259d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-182a6a09-c916-4625-b9c5-9dffe2f259d7">
											<gml:posList>35.671025362349994 139.74173652275937 75.626 35.67104779893701 139.74170283889347 75.626 35.67104779893701 139.74170283889347 80.194 35.671025362349994 139.74173652275937 81.005 35.671025362349994 139.74173652275937 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d87127a0-3262-4eec-a315-53371f597c69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d87127a0-3262-4eec-a315-53371f597c69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d87127a0-3262-4eec-a315-53371f597c69">
											<gml:posList>35.67101716063597 139.74173754839342 81.005 35.671156173677126 139.74152883417992 81.005 35.671156173677126 139.74152883417992 7.25 35.67101716063597 139.74173754839342 7.25 35.67101716063597 139.74173754839342 81.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f16ddc40-f025-4151-a120-05158630b409">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f16ddc40-f025-4151-a120-05158630b409">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f16ddc40-f025-4151-a120-05158630b409">
											<gml:posList>35.671025362349994 139.74173652275937 81.005 35.67104779893701 139.74170283889347 80.194 35.671124859358976 139.741587150643 80.194 35.67115894634693 139.7415359890508 81.005 35.671025362349994 139.74173652275937 81.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d17ea70e-6748-4dec-9c7e-e583aca39118">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d17ea70e-6748-4dec-9c7e-e583aca39118">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d17ea70e-6748-4dec-9c7e-e583aca39118">
											<gml:posList>35.67101716063597 139.74173754839342 7.25 35.67122328096995 139.7419436592111 7.25 35.67122328096995 139.7419436592111 81.005 35.67101716063597 139.74173754839342 81.005 35.67101716063597 139.74173754839342 7.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b28565fe-0100-4e65-b5e8-7b06b415ab19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b28565fe-0100-4e65-b5e8-7b06b415ab19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b28565fe-0100-4e65-b5e8-7b06b415ab19">
											<gml:posList>35.671025362349994 139.74173652275937 75.626 35.671025362349994 139.74173652275937 81.005 35.671222462105206 139.74193360794268 81.005 35.671222462105206 139.74193360794268 75.626 35.671025362349994 139.74173652275937 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56e4898f-cc80-4855-9a54-ff0058fdb1d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56e4898f-cc80-4855-9a54-ff0058fdb1d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56e4898f-cc80-4855-9a54-ff0058fdb1d3">
											<gml:posList>35.671102427659676 139.7417574890762 80.194 35.671102427659676 139.7417574890762 75.626 35.671161724346085 139.74166846495234 75.626 35.671161724346085 139.74166846495234 80.194 35.671102427659676 139.7417574890762 80.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c4ee9ad-a331-4d61-b247-45c81c150839">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c4ee9ad-a331-4d61-b247-45c81c150839">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c4ee9ad-a331-4d61-b247-45c81c150839">
											<gml:posList>35.671154789727 139.74161709623115 80.194 35.671154789727 139.74161709623115 75.626 35.671124859358976 139.741587150643 75.626 35.671124859358976 139.741587150643 80.194 35.671154789727 139.74161709623115 80.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d135c414-acdb-470f-89fe-83f0ab96fc77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d135c414-acdb-470f-89fe-83f0ab96fc77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d135c414-acdb-470f-89fe-83f0ab96fc77">
											<gml:posList>35.671124859358976 139.741587150643 80.194 35.671124859358976 139.741587150643 75.626 35.67115894634693 139.7415359890508 75.626 35.67115894634693 139.7415359890508 81.005 35.671124859358976 139.741587150643 80.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a89ab39d-5123-4479-a690-87d759a3d6d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a89ab39d-5123-4479-a690-87d759a3d6d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a89ab39d-5123-4479-a690-87d759a3d6d6">
											<gml:posList>35.671137025945065 139.74164376038155 80.194 35.671137025945065 139.74164376038155 75.626 35.671154789727 139.74161709623115 75.626 35.671154789727 139.74161709623115 80.194 35.671137025945065 139.74164376038155 80.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cadaf15-f70b-427b-8a75-96edd450928c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cadaf15-f70b-427b-8a75-96edd450928c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cadaf15-f70b-427b-8a75-96edd450928c">
											<gml:posList>35.671161724346085 139.74166846495234 80.194 35.671161724346085 139.74166846495234 75.626 35.671137025945065 139.74164376038155 75.626 35.671137025945065 139.74164376038155 80.194 35.671161724346085 139.74166846495234 80.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41251c7a-f4cf-40fc-b23b-ecfcee0ffe88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41251c7a-f4cf-40fc-b23b-ecfcee0ffe88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41251c7a-f4cf-40fc-b23b-ecfcee0ffe88">
											<gml:posList>35.671156173677126 139.74152883417992 81.005 35.67139566842911 139.74152878087327 81.005 35.67139566842911 139.74152878087327 7.25 35.671156173677126 139.74152883417992 7.25 35.671156173677126 139.74152883417992 81.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-750732a3-d136-42dc-856c-836d326f6bee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-750732a3-d136-42dc-856c-836d326f6bee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-750732a3-d136-42dc-856c-836d326f6bee">
											<gml:posList>35.67139358270298 139.74153594132824 75.626 35.67139358270298 139.74153594132824 81.005 35.67115894634693 139.7415359890508 81.005 35.67115894634693 139.7415359890508 75.626 35.67139358270298 139.74153594132824 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f14cc00-ac1c-4474-accf-e5820d204433">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f14cc00-ac1c-4474-accf-e5820d204433">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f14cc00-ac1c-4474-accf-e5820d204433">
											<gml:posList>35.671222462105206 139.74193360794268 75.626 35.671222462105206 139.74193360794268 81.005 35.67144979909169 139.74159213631253 81.005 35.67144979909169 139.74159213631253 75.626 35.671222462105206 139.74193360794268 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07f0790d-304d-4b43-98d4-1de4eb22c86c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07f0790d-304d-4b43-98d4-1de4eb22c86c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07f0790d-304d-4b43-98d4-1de4eb22c86c">
											<gml:posList>35.67145800081225 139.7415911217044 81.005 35.67122328096995 139.7419436592111 81.005 35.67122328096995 139.7419436592111 7.25 35.67145800081225 139.7415911217044 7.25 35.67145800081225 139.7415911217044 81.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-254960d3-2581-404a-824a-8791c31d64d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-254960d3-2581-404a-824a-8791c31d64d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-254960d3-2581-404a-824a-8791c31d64d4">
											<gml:posList>35.67144979909169 139.74159213631253 75.626 35.67144979909169 139.74159213631253 81.005 35.67139358270298 139.74153594132824 81.005 35.67139358270298 139.74153594132824 75.626 35.67144979909169 139.74159213631253 75.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db6c543b-b062-4b92-a7ce-f6c64842c1c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db6c543b-b062-4b92-a7ce-f6c64842c1c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db6c543b-b062-4b92-a7ce-f6c64842c1c1">
											<gml:posList>35.67139566842911 139.74152878087327 81.005 35.67145800081225 139.7415911217044 81.005 35.67145800081225 139.7415911217044 7.25 35.67139566842911 139.74152878087327 7.25 35.67139566842911 139.74152878087327 81.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11148</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">1042.6518</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.43</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>