<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8118419d-ea42-4ef0-9673-25ae550bab1e">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">4.6</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671253823622365 139.73951123364904 0 35.67124700155849 139.73945511498184 0 35.6712108796709 139.73946170777714 0 35.67121770173173 139.7395178264197 0 35.671253823622365 139.73951123364904 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671253823622365 139.73951123364904 15.988 35.67121770173173 139.7395178264197 15.988 35.6712108796709 139.73946170777714 15.988 35.67124700155849 139.73945511498184 15.988 35.671253823622365 139.73951123364904 15.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671253823622365 139.73951123364904 15.988 35.67124700155849 139.73945511498184 15.988 35.67124700155849 139.73945511498184 20.58 35.671253823622365 139.73951123364904 20.58 35.671253823622365 139.73951123364904 15.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67124700155849 139.73945511498184 15.988 35.6712108796709 139.73946170777714 15.988 35.6712108796709 139.73946170777714 20.58 35.67124700155849 139.73945511498184 20.58 35.67124700155849 139.73945511498184 15.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6712108796709 139.73946170777714 15.988 35.67121770173173 139.7395178264197 15.988 35.67121770173173 139.7395178264197 20.58 35.6712108796709 139.73946170777714 20.58 35.6712108796709 139.73946170777714 15.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121770173173 139.7395178264197 15.988 35.671253823622365 139.73951123364904 15.988 35.671253823622365 139.73951123364904 20.58 35.67121770173173 139.7395178264197 20.58 35.67121770173173 139.7395178264197 15.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671253823622365 139.73951123364904 20.58 35.67124700155849 139.73945511498184 20.58 35.6712108796709 139.73946170777714 20.58 35.67121770173173 139.7395178264197 20.58 35.671253823622365 139.73951123364904 20.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-83756400-38b8-42ed-8586-a4260860dae1"/>
							<gml:surfaceMember xlink:href="#poly-24a29fe6-ed76-4b84-95ae-4ce5dec6331a"/>
							<gml:surfaceMember xlink:href="#poly-88424e5d-98b9-465d-bd56-b502bbb458e8"/>
							<gml:surfaceMember xlink:href="#poly-41f0acc5-70cd-4001-8987-a502313cc55a"/>
							<gml:surfaceMember xlink:href="#poly-59da40cf-37fa-41e3-96ae-2993795e1c9b"/>
							<gml:surfaceMember xlink:href="#poly-99d5489e-4cae-445a-9195-6c63b26de18d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-83756400-38b8-42ed-8586-a4260860dae1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83756400-38b8-42ed-8586-a4260860dae1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83756400-38b8-42ed-8586-a4260860dae1">
											<gml:posList>35.67125382362236 139.73951123364904 15.988 35.67121770173171 139.7395178264197 15.988 35.67121087967091 139.73946170777717 15.988 35.67124700155848 139.7394551149818 15.988 35.67125382362236 139.73951123364904 15.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-24a29fe6-ed76-4b84-95ae-4ce5dec6331a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24a29fe6-ed76-4b84-95ae-4ce5dec6331a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24a29fe6-ed76-4b84-95ae-4ce5dec6331a">
											<gml:posList>35.67121770173171 139.7395178264197 21.432 35.67125382362236 139.73951123364904 21.432 35.67124700155848 139.7394551149818 21.432 35.67121087967091 139.73946170777717 21.432 35.67121770173171 139.7395178264197 21.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88424e5d-98b9-465d-bd56-b502bbb458e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88424e5d-98b9-465d-bd56-b502bbb458e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88424e5d-98b9-465d-bd56-b502bbb458e8">
											<gml:posList>35.67124700155848 139.7394551149818 15.988 35.67121087967091 139.73946170777717 15.988 35.67121087967091 139.73946170777717 21.432 35.67124700155848 139.7394551149818 21.432 35.67124700155848 139.7394551149818 15.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41f0acc5-70cd-4001-8987-a502313cc55a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41f0acc5-70cd-4001-8987-a502313cc55a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41f0acc5-70cd-4001-8987-a502313cc55a">
											<gml:posList>35.67125382362236 139.73951123364904 15.988 35.67124700155848 139.7394551149818 15.988 35.67124700155848 139.7394551149818 21.432 35.67125382362236 139.73951123364904 21.432 35.67125382362236 139.73951123364904 15.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59da40cf-37fa-41e3-96ae-2993795e1c9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59da40cf-37fa-41e3-96ae-2993795e1c9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59da40cf-37fa-41e3-96ae-2993795e1c9b">
											<gml:posList>35.67121087967091 139.73946170777717 15.988 35.67121770173171 139.7395178264197 15.988 35.67121770173171 139.7395178264197 21.432 35.67121087967091 139.73946170777717 21.432 35.67121087967091 139.73946170777717 15.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99d5489e-4cae-445a-9195-6c63b26de18d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99d5489e-4cae-445a-9195-6c63b26de18d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99d5489e-4cae-445a-9195-6c63b26de18d">
											<gml:posList>35.67121770173171 139.7395178264197 15.988 35.67125382362236 139.73951123364904 15.988 35.67125382362236 139.73951123364904 21.432 35.67121770173171 139.7395178264197 21.432 35.67121770173171 139.7395178264197 15.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5559</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>