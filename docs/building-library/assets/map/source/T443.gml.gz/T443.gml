<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_825e8e35-efdd-4b55-ac01-f9db951ea7fe">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">16.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>13</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67033171533447 139.74109311982997 0 35.67033266257514 139.7410353468373 0 35.67032085442879 139.74103513950539 0 35.6703220623094 139.7409646630304 0 35.67025599036436 139.74096297174964 0 35.67025642172785 139.74093778581994 0 35.6701192299803 139.74093418820067 0 35.670083554451146 139.74095875191918 0 35.67008096049557 139.74110246620748 0 35.67025348671071 139.74110690716788 0 35.67025365945496 139.74109707581374 0 35.67031819898086 139.7410986585053 0 35.670318374770666 139.74109280379005 0 35.67033171533447 139.74109311982997 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033171533447 139.74109311982997 8.91 35.670318374770666 139.74109280379005 8.91 35.67031819898086 139.7410986585053 8.91 35.67025365945496 139.74109707581374 8.91 35.67025348671071 139.74110690716788 8.91 35.67008096049557 139.74110246620748 8.91 35.670083554451146 139.74095875191918 8.91 35.6701192299803 139.74093418820067 8.91 35.67025642172785 139.74093778581994 8.91 35.67025599036436 139.74096297174964 8.91 35.6703220623094 139.7409646630304 8.91 35.67032085442879 139.74103513950539 8.91 35.67033266257514 139.7410353468373 8.91 35.67033171533447 139.74109311982997 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033171533447 139.74109311982997 8.91 35.67033266257514 139.7410353468373 8.91 35.67033266257514 139.7410353468373 24.33 35.67033171533447 139.74109311982997 24.33 35.67033171533447 139.74109311982997 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033266257514 139.7410353468373 8.91 35.67032085442879 139.74103513950539 8.91 35.67032085442879 139.74103513950539 24.33 35.67033266257514 139.7410353468373 24.33 35.67033266257514 139.7410353468373 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67032085442879 139.74103513950539 8.91 35.6703220623094 139.7409646630304 8.91 35.6703220623094 139.7409646630304 24.33 35.67032085442879 139.74103513950539 24.33 35.67032085442879 139.74103513950539 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6703220623094 139.7409646630304 8.91 35.67025599036436 139.74096297174964 8.91 35.67025599036436 139.74096297174964 24.33 35.6703220623094 139.7409646630304 24.33 35.6703220623094 139.7409646630304 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67025599036436 139.74096297174964 8.91 35.67025642172785 139.74093778581994 8.91 35.67025642172785 139.74093778581994 24.33 35.67025599036436 139.74096297174964 24.33 35.67025599036436 139.74096297174964 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67025642172785 139.74093778581994 8.91 35.6701192299803 139.74093418820067 8.91 35.6701192299803 139.74093418820067 24.33 35.67025642172785 139.74093778581994 24.33 35.67025642172785 139.74093778581994 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6701192299803 139.74093418820067 8.91 35.670083554451146 139.74095875191918 8.91 35.670083554451146 139.74095875191918 24.33 35.6701192299803 139.74093418820067 24.33 35.6701192299803 139.74093418820067 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670083554451146 139.74095875191918 8.91 35.67008096049557 139.74110246620748 8.91 35.67008096049557 139.74110246620748 24.33 35.670083554451146 139.74095875191918 24.33 35.670083554451146 139.74095875191918 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67008096049557 139.74110246620748 8.91 35.67025348671071 139.74110690716788 8.91 35.67025348671071 139.74110690716788 24.33 35.67008096049557 139.74110246620748 24.33 35.67008096049557 139.74110246620748 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67025348671071 139.74110690716788 8.91 35.67025365945496 139.74109707581374 8.91 35.67025365945496 139.74109707581374 24.33 35.67025348671071 139.74110690716788 24.33 35.67025348671071 139.74110690716788 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67025365945496 139.74109707581374 8.91 35.67031819898086 139.7410986585053 8.91 35.67031819898086 139.7410986585053 24.33 35.67025365945496 139.74109707581374 24.33 35.67025365945496 139.74109707581374 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67031819898086 139.7410986585053 8.91 35.670318374770666 139.74109280379005 8.91 35.670318374770666 139.74109280379005 24.33 35.67031819898086 139.7410986585053 24.33 35.67031819898086 139.7410986585053 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670318374770666 139.74109280379005 8.91 35.67033171533447 139.74109311982997 8.91 35.67033171533447 139.74109311982997 24.33 35.670318374770666 139.74109280379005 24.33 35.670318374770666 139.74109280379005 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033171533447 139.74109311982997 24.33 35.67033266257514 139.7410353468373 24.33 35.67032085442879 139.74103513950539 24.33 35.6703220623094 139.7409646630304 24.33 35.67025599036436 139.74096297174964 24.33 35.67025642172785 139.74093778581994 24.33 35.6701192299803 139.74093418820067 24.33 35.670083554451146 139.74095875191918 24.33 35.67008096049557 139.74110246620748 24.33 35.67025348671071 139.74110690716788 24.33 35.67025365945496 139.74109707581374 24.33 35.67031819898086 139.7410986585053 24.33 35.670318374770666 139.74109280379005 24.33 35.67033171533447 139.74109311982997 24.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6968f712-633d-4ff8-893a-4d1d8c70068c"/>
							<gml:surfaceMember xlink:href="#poly-08bed4c6-1b34-4394-adb6-c41752df62ff"/>
							<gml:surfaceMember xlink:href="#poly-b5b86f2c-b2de-42d3-a3ab-248d4ccd03cf"/>
							<gml:surfaceMember xlink:href="#poly-aa197f43-8ca8-45f5-b2cc-4445bd8d1bab"/>
							<gml:surfaceMember xlink:href="#poly-15f36365-f3a1-4b9d-8b05-03c2a9c7abc9"/>
							<gml:surfaceMember xlink:href="#poly-73e7c839-777c-45ff-9b88-ed34a09e2d59"/>
							<gml:surfaceMember xlink:href="#poly-e9683f82-af0f-47c9-829f-f59b54a893b2"/>
							<gml:surfaceMember xlink:href="#poly-67e3f2db-b022-4b74-8d98-406c4ad6b79a"/>
							<gml:surfaceMember xlink:href="#poly-db900e36-d356-46dc-abaa-e31394ea8636"/>
							<gml:surfaceMember xlink:href="#poly-c7e6ff5f-6cd1-4578-9091-674c92544e6a"/>
							<gml:surfaceMember xlink:href="#poly-b4e6cd35-0fcb-42f2-8714-27db84461142"/>
							<gml:surfaceMember xlink:href="#poly-15945293-4782-46a4-9666-4eafbbf8dc69"/>
							<gml:surfaceMember xlink:href="#poly-477f7dd9-c61b-4779-a183-ecf749046037"/>
							<gml:surfaceMember xlink:href="#poly-bda7df46-0c12-4e34-8167-656e9a95cc1e"/>
							<gml:surfaceMember xlink:href="#poly-f7c3e850-6810-4ff4-a399-17aa8ea02389"/>
							<gml:surfaceMember xlink:href="#poly-120c5acd-b3d6-41c6-9c30-5947008141c8"/>
							<gml:surfaceMember xlink:href="#poly-0c17838c-6a3b-45f9-b360-302a1617135b"/>
							<gml:surfaceMember xlink:href="#poly-6c46056a-8f4b-4f08-9af9-0a144e437484"/>
							<gml:surfaceMember xlink:href="#poly-f589db91-0e4d-4850-8ff9-2d18b2fd9fb3"/>
							<gml:surfaceMember xlink:href="#poly-0dfe9945-46b1-480d-93bd-9e40c903be65"/>
							<gml:surfaceMember xlink:href="#poly-c3e6b3c9-8f4e-435b-b55c-49e4e1a4e52c"/>
							<gml:surfaceMember xlink:href="#poly-117edbeb-4383-42bd-a269-a4c2b33d188a"/>
							<gml:surfaceMember xlink:href="#poly-5bc9cb50-c9fd-4698-b59a-98ddb9ec013c"/>
							<gml:surfaceMember xlink:href="#poly-4c6faa56-7e0d-4a21-a98c-80a28d243e8e"/>
							<gml:surfaceMember xlink:href="#poly-85879de5-12ed-46b0-95da-93e8696989ce"/>
							<gml:surfaceMember xlink:href="#poly-c906f23e-f515-489c-a403-14cbb4d1e592"/>
							<gml:surfaceMember xlink:href="#poly-a8ebc6f4-6594-41e8-844d-5f9295b47527"/>
							<gml:surfaceMember xlink:href="#poly-0b387520-7ef1-4fa0-8628-dc59dca74878"/>
							<gml:surfaceMember xlink:href="#poly-1a88b7ce-f3e4-4469-b0fe-4b984da62b1a"/>
							<gml:surfaceMember xlink:href="#poly-c31048be-a903-49a7-a0cf-7106fecac7aa"/>
							<gml:surfaceMember xlink:href="#poly-96273f97-8828-4129-8f6b-2e3247c105fc"/>
							<gml:surfaceMember xlink:href="#poly-cd0d5d67-fc35-4c87-9905-f6f02d936f1d"/>
							<gml:surfaceMember xlink:href="#poly-ed24eb2a-5463-4141-8c55-fd99d5b7e427"/>
							<gml:surfaceMember xlink:href="#poly-be91e1be-9022-4538-ab28-2bd0f520ba92"/>
							<gml:surfaceMember xlink:href="#poly-38eee15b-2060-4e98-961c-9d74d2096f09"/>
							<gml:surfaceMember xlink:href="#poly-8409ea42-51b6-4188-9ee6-840338323365"/>
							<gml:surfaceMember xlink:href="#poly-3c42fe94-dbcf-4b63-a3fc-09b241f11642"/>
							<gml:surfaceMember xlink:href="#poly-e09796ae-2eea-461e-98a9-3e511c6a82ce"/>
							<gml:surfaceMember xlink:href="#poly-d2840ee0-069d-497d-957d-ff1fc3b87f98"/>
							<gml:surfaceMember xlink:href="#poly-97dba5f6-72a2-4ac5-b05d-71aebaa1302c"/>
							<gml:surfaceMember xlink:href="#poly-dccff67b-ede5-4eab-b1fa-1e1b9ecaff9b"/>
							<gml:surfaceMember xlink:href="#poly-952d275f-1c86-496d-9604-5950aa56b008"/>
							<gml:surfaceMember xlink:href="#poly-8f1f62aa-cc42-4693-b4f1-eeddb6aabe85"/>
							<gml:surfaceMember xlink:href="#poly-c8a85e9f-ece0-47f8-9b9f-f474c989b82d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_825e8e35-efdd-4b55-ac01-f9db951ea7fe_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-809a7725-2dcd-456b-bf82-954c8d46a624">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67012756099287 139.74098421799764 23.716 35.67011223734993 139.74098382693714 23.716 35.67011204783268 139.7409952820882 23.716 35.670178300061856 139.74099698423146 23.716 35.670178067363416 139.74101090275133 23.716 35.67011145457701 139.74100918996552 23.716 35.67011085944766 139.74104417403714 23.716 35.67010982579026 139.7410479861736 23.716 35.67010749562959 139.74105372184482 23.716 35.67010665053209 139.74105658378892 23.716 35.67010585134962 139.74106055030228 23.716 35.67010521316744 139.74109818551378 23.716 35.67009347705436 139.74109787867434 23.716 35.67009413259517 139.741059370797 23.716 35.67009548958723 139.74105404495708 23.716 35.67009957675516 139.741047434613 23.716 35.670100548349346 139.7410449701874 23.716 35.670101590656316 139.74104068305388 23.716 35.67010373611179 139.74097039347743 23.716 35.67016075810248 139.74097186321566 23.716 35.670160628446126 139.74097909864517 23.716 35.67019854095352 139.74098008227494 23.716 35.67019878247571 139.7409659207241 23.716 35.670204055613866 139.74096605825036 23.716 35.670203658918496 139.74098944358724 23.716 35.67019827308311 139.74099514964726 23.716 35.67012744018854 139.7409912435357 23.716 35.67012756099287 139.74098421799764 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83f03fba-f0d4-4113-97e1-aa0061b6a9e3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67010521316744 139.74109818551378 23.947 35.6701051267869 139.74110309013557 23.947 35.67009339067383 139.7411027832954 23.947 35.67009347705436 139.74109787867434 23.947 35.67010521316744 139.74109818551378 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1394f254-426c-44e6-b3ef-f4b2045fc14f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1394f254-426c-44e6-b3ef-f4b2045fc14f_0">
											<gml:posList>35.67010521316744 139.74109818551378 23.947 35.67009347705436 139.74109787867434 23.947 35.67009347705436 139.74109787867434 23.716 35.67010521316744 139.74109818551378 23.716 35.67010521316744 139.74109818551378 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c88ead7-854d-4e00-8bc7-54965d3370b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c88ead7-854d-4e00-8bc7-54965d3370b8_0">
											<gml:posList>35.67019878247571 139.7409659207241 23.716 35.67019878247571 139.7409659207241 26.614 35.670204055613866 139.74096605825036 26.614 35.670204055613866 139.74096605825036 23.716 35.67019878247571 139.7409659207241 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45387d90-8929-418a-9ce2-5c6f2ce43cfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45387d90-8929-418a-9ce2-5c6f2ce43cfb_0">
											<gml:posList>35.67010373611179 139.74097039347743 23.716 35.67010373611179 139.74097039347743 26.614 35.67016075810248 139.74097186321566 26.614 35.67016075810248 139.74097186321566 23.716 35.67010373611179 139.74097039347743 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9132ea89-0f9e-4fb2-8aeb-aac5e9d65ae4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9132ea89-0f9e-4fb2-8aeb-aac5e9d65ae4_0">
											<gml:posList>35.67019854095352 139.74098008227494 23.716 35.67019854095352 139.74098008227494 26.614 35.67019878247571 139.7409659207241 26.614 35.67019878247571 139.7409659207241 23.716 35.67019854095352 139.74098008227494 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8aa8c2c-623b-48f9-a43f-eaa6f62e1e28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8aa8c2c-623b-48f9-a43f-eaa6f62e1e28_0">
											<gml:posList>35.67016075810248 139.74097186321566 23.716 35.67016075810248 139.74097186321566 26.614 35.670160628446126 139.74097909864517 26.614 35.670160628446126 139.74097909864517 23.716 35.67016075810248 139.74097186321566 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ad41a5d-d851-4655-a8f7-83c6a29da2e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ad41a5d-d851-4655-a8f7-83c6a29da2e9_0">
											<gml:posList>35.670204055613866 139.74096605825036 23.716 35.670204055613866 139.74096605825036 26.614 35.670203658918496 139.74098944358724 26.614 35.670203658918496 139.74098944358724 23.716 35.670204055613866 139.74096605825036 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77005058-8293-4ad1-a1de-d60bbaaa811b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77005058-8293-4ad1-a1de-d60bbaaa811b_0">
											<gml:posList>35.670160628446126 139.74097909864517 23.716 35.670160628446126 139.74097909864517 26.614 35.67019854095352 139.74098008227494 26.614 35.67019854095352 139.74098008227494 23.716 35.670160628446126 139.74097909864517 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e00a419-13a2-4032-9fa8-91b6df98dd07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e00a419-13a2-4032-9fa8-91b6df98dd07_0">
											<gml:posList>35.67012756099287 139.74098421799764 23.716 35.67012756099287 139.74098421799764 26.614 35.67011223734993 139.74098382693714 26.614 35.67011223734993 139.74098382693714 23.716 35.67012756099287 139.74098421799764 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95dab96c-5c96-4340-823f-817bcacbfe92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95dab96c-5c96-4340-823f-817bcacbfe92_0">
											<gml:posList>35.67012744018854 139.7409912435357 23.716 35.67012744018854 139.7409912435357 26.614 35.67012756099287 139.74098421799764 26.614 35.67012756099287 139.74098421799764 23.716 35.67012744018854 139.7409912435357 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc75b4df-3340-4786-9167-58f24416908e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc75b4df-3340-4786-9167-58f24416908e_0">
											<gml:posList>35.67011223734993 139.74098382693714 23.716 35.67011223734993 139.74098382693714 26.614 35.67011204783268 139.7409952820882 26.614 35.67011204783268 139.7409952820882 23.716 35.67011223734993 139.74098382693714 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c43af547-140c-4a8d-823f-9dd6dc2cccc0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c43af547-140c-4a8d-823f-9dd6dc2cccc0_0">
											<gml:posList>35.670203658918496 139.74098944358724 23.716 35.670203658918496 139.74098944358724 26.614 35.67019827308311 139.74099514964726 26.614 35.67019827308311 139.74099514964726 23.716 35.670203658918496 139.74098944358724 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85da4101-7dfb-4766-9f5b-2fe59d01a770">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85da4101-7dfb-4766-9f5b-2fe59d01a770_0">
											<gml:posList>35.67019827308311 139.74099514964726 23.716 35.67019827308311 139.74099514964726 26.614 35.67012744018854 139.7409912435357 26.614 35.67012744018854 139.7409912435357 23.716 35.67019827308311 139.74099514964726 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-886a7c56-7bee-4690-bff6-8c1225111659">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-886a7c56-7bee-4690-bff6-8c1225111659_0">
											<gml:posList>35.67011204783268 139.7409952820882 23.716 35.67011204783268 139.7409952820882 26.614 35.670178300061856 139.74099698423146 26.614 35.670178300061856 139.74099698423146 23.716 35.67011204783268 139.7409952820882 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a634621-f2af-44e4-8a1c-7ee5a75e3321">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a634621-f2af-44e4-8a1c-7ee5a75e3321_0">
											<gml:posList>35.670178300061856 139.74099698423146 23.716 35.670178300061856 139.74099698423146 26.614 35.670178067363416 139.74101090275133 26.614 35.670178067363416 139.74101090275133 23.716 35.670178300061856 139.74099698423146 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3146c766-ffa8-43d5-bc24-fac0efc289d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3146c766-ffa8-43d5-bc24-fac0efc289d7_0">
											<gml:posList>35.670101590656316 139.74104068305388 23.716 35.670101590656316 139.74104068305388 26.614 35.67010373611179 139.74097039347743 26.614 35.67010373611179 139.74097039347743 23.716 35.670101590656316 139.74104068305388 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-435222d7-f0fc-462e-ac83-f646bc5bd506">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-435222d7-f0fc-462e-ac83-f646bc5bd506_0">
											<gml:posList>35.670178067363416 139.74101090275133 23.716 35.670178067363416 139.74101090275133 26.614 35.67011145457701 139.74100918996552 26.614 35.67011145457701 139.74100918996552 23.716 35.670178067363416 139.74101090275133 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59f6b2f7-fadc-4223-9c8f-4415cca67188">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59f6b2f7-fadc-4223-9c8f-4415cca67188_0">
											<gml:posList>35.67011145457701 139.74100918996552 23.716 35.67011145457701 139.74100918996552 26.614 35.67011085944766 139.74104417403714 26.614 35.67011085944766 139.74104417403714 23.716 35.67011145457701 139.74100918996552 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba0f4be0-529c-4f02-a6a0-29648d9417a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba0f4be0-529c-4f02-a6a0-29648d9417a2_0">
											<gml:posList>35.67019827308311 139.74099514964726 26.614 35.670203658918496 139.74098944358724 26.614 35.670204055613866 139.74096605825036 26.614 35.67019878247571 139.7409659207241 26.614 35.67019854095352 139.74098008227494 26.614 35.670160628446126 139.74097909864517 26.614 35.67016075810248 139.74097186321566 26.614 35.67010373611179 139.74097039347743 26.614 35.670101590656316 139.74104068305388 26.614 35.670100548349346 139.7410449701874 26.614 35.67009957675516 139.741047434613 26.614 35.67009548958723 139.74105404495708 26.614 35.67009413259517 139.741059370797 26.614 35.67009339067383 139.7411027832954 26.614 35.6701051267869 139.74110309013557 26.614 35.67010585134962 139.74106055030228 26.614 35.67010665053209 139.74105658378892 26.614 35.67010749562959 139.74105372184482 26.614 35.67010982579026 139.7410479861736 26.614 35.67011085944766 139.74104417403714 26.614 35.67011145457701 139.74100918996552 26.614 35.670178067363416 139.74101090275133 26.614 35.670178300061856 139.74099698423146 26.614 35.67011204783268 139.7409952820882 26.614 35.67011223734993 139.74098382693714 26.614 35.67012756099287 139.74098421799764 26.614 35.67012744018854 139.7409912435357 26.614 35.67019827308311 139.74099514964726 26.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6510860-1f7c-4a48-970b-a0ceb5e3212b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6510860-1f7c-4a48-970b-a0ceb5e3212b_0">
											<gml:posList>35.670100548349346 139.7410449701874 23.716 35.670100548349346 139.7410449701874 26.614 35.670101590656316 139.74104068305388 26.614 35.670101590656316 139.74104068305388 23.716 35.670100548349346 139.7410449701874 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9161d32-3772-42a5-85f3-dbb4e88c7e98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9161d32-3772-42a5-85f3-dbb4e88c7e98_0">
											<gml:posList>35.67011085944766 139.74104417403714 23.716 35.67011085944766 139.74104417403714 26.614 35.67010982579026 139.7410479861736 26.614 35.67010982579026 139.7410479861736 23.716 35.67011085944766 139.74104417403714 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49034c98-8024-4fa3-8d1e-5a6e3f9eb107">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49034c98-8024-4fa3-8d1e-5a6e3f9eb107_0">
											<gml:posList>35.67009957675516 139.741047434613 26.614 35.670100548349346 139.7410449701874 26.614 35.670100548349346 139.7410449701874 23.716 35.67009957675516 139.741047434613 23.716 35.67009957675516 139.741047434613 26.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55839555-330e-4da6-8c05-79366ea935bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55839555-330e-4da6-8c05-79366ea935bf_0">
											<gml:posList>35.67009548958723 139.74105404495708 23.716 35.67009548958723 139.74105404495708 26.614 35.67009957675516 139.741047434613 26.614 35.67009957675516 139.741047434613 23.716 35.67009548958723 139.74105404495708 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f49efa1f-0a49-496d-8a74-97a0011e95db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f49efa1f-0a49-496d-8a74-97a0011e95db_0">
											<gml:posList>35.67010982579026 139.7410479861736 23.716 35.67010982579026 139.7410479861736 26.614 35.67010749562959 139.74105372184482 26.614 35.67010749562959 139.74105372184482 23.716 35.67010982579026 139.7410479861736 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9684d03c-3ede-4297-9cd1-2c38b4cbdf1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9684d03c-3ede-4297-9cd1-2c38b4cbdf1a_0">
											<gml:posList>35.67010749562959 139.74105372184482 23.716 35.67010749562959 139.74105372184482 26.614 35.67010665053209 139.74105658378892 26.614 35.67010665053209 139.74105658378892 23.716 35.67010749562959 139.74105372184482 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-415d52ee-30e2-4649-8008-99e79c18f890">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-415d52ee-30e2-4649-8008-99e79c18f890_0">
											<gml:posList>35.67009413259517 139.741059370797 23.716 35.67009413259517 139.741059370797 26.614 35.67009548958723 139.74105404495708 26.614 35.67009548958723 139.74105404495708 23.716 35.67009413259517 139.741059370797 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7b422a2-60cc-4a17-b034-c336161baad6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7b422a2-60cc-4a17-b034-c336161baad6_0">
											<gml:posList>35.67010665053209 139.74105658378892 23.716 35.67010665053209 139.74105658378892 26.614 35.67010585134962 139.74106055030228 26.614 35.67010585134962 139.74106055030228 23.716 35.67010665053209 139.74105658378892 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5857e82d-36a8-450b-a1a8-d5bb586d0775">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5857e82d-36a8-450b-a1a8-d5bb586d0775_0">
											<gml:posList>35.67009339067383 139.7411027832954 26.614 35.67009413259517 139.741059370797 26.614 35.67009413259517 139.741059370797 23.716 35.67009347705436 139.74109787867434 23.716 35.67009347705436 139.74109787867434 23.947 35.67009339067383 139.7411027832954 23.947 35.67009339067383 139.7411027832954 26.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89e018ca-6a79-4d2b-9b10-f8f15cc0e7a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89e018ca-6a79-4d2b-9b10-f8f15cc0e7a0_0">
											<gml:posList>35.67010521316744 139.74109818551378 23.947 35.67010521316744 139.74109818551378 23.716 35.67010585134962 139.74106055030228 23.716 35.67010585134962 139.74106055030228 26.614 35.6701051267869 139.74110309013557 26.614 35.6701051267869 139.74110309013557 23.947 35.67010521316744 139.74109818551378 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6c874ea-95d1-4d40-8696-7b09fac1ba0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6c874ea-95d1-4d40-8696-7b09fac1ba0d_0">
											<gml:posList>35.6701051267869 139.74110309013557 23.947 35.6701051267869 139.74110309013557 26.614 35.67009339067383 139.7411027832954 26.614 35.67009339067383 139.7411027832954 23.947 35.6701051267869 139.74110309013557 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_825e8e35-efdd-4b55-ac01-f9db951ea7fe_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9f03bf8-96ed-483d-a237-59021e866c13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67008665721454 139.74100842319152 23.947 35.67008576483899 139.74100840212665 23.947 35.67008637524021 139.7409698390732 23.947 35.67008736624985 139.74096918620467 23.947 35.67008665721454 139.74100842319152 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58ac4b33-d6d1-41c8-9b23-dc526b371611">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67017825883337 139.74102550564913 23.716 35.670177573746564 139.74104896863375 23.716 35.67012778923483 139.7410467835516 23.716 35.67012847432124 139.74102332058155 23.716 35.67017825883337 139.74102550564913 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d8c8c77-6b4e-4ea2-8cd2-ba01ca00740e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670135687594595 139.7410615874493 23.716 35.67014373712876 139.7410619427111 23.716 35.67014285870866 139.74109190108913 23.716 35.67013480917458 139.7410915458243 23.716 35.670135687594595 139.7410615874493 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e444270-419a-4760-ad18-3ae4ffec968a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670245477363544 139.74095907349204 23.716 35.67012148922085 139.74095350544258 23.716 35.67009026364573 139.74097438563632 23.716 35.67008973095345 139.7410084969757 23.716 35.67008665721454 139.74100842319152 23.716 35.67008736624985 139.74096918620467 23.716 35.670119565128225 139.74094807291746 23.716 35.67025081858618 139.74095396397468 23.716 35.67025030017345 139.74097142867996 23.716 35.670245117104784 139.7409712026796 23.716 35.670245477363544 139.74095907349204 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f342867-2b3d-4454-89e1-3598dfc4feb7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67020771341406 139.7410107581525 23.716 35.6701856645261 139.74100906032882 23.716 35.670185594332295 139.74099980366665 23.716 35.67021710567298 139.74099893891022 23.716 35.670216359624035 139.741013421386 23.716 35.67020761578756 139.74101274658733 23.716 35.67020771341406 139.7410107581525 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4deb905a-8e43-4702-8d14-b7ccc2ffc892">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6701882283398 139.74104944240466 23.716 35.67018891341823 139.74102596837068 23.716 35.670238292303814 139.7410281428622 23.716 35.67023760721653 139.74105160586439 23.716 35.6701882283398 139.74104944240466 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4850ee44-cd5b-4e82-8349-e8fca980b962">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670227998402055 139.74098083262726 23.716 35.67022164367648 139.74098077366946 23.716 35.67022174891675 139.74096520939935 23.716 35.67022810364235 139.7409652683559 23.716 35.670227998402055 139.74098083262726 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01f7b185-2f27-43d2-9e95-40cca011e22a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670246858853034 139.74100919974262 23.716 35.670240900451795 139.7410087758003 23.716 35.67024218662059 139.7409816226602 23.716 35.67024814502193 139.7409820466005 23.716 35.670246858853034 139.74100919974262 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3aef9bc1-1d3e-4f60-b6d0-98eafb0df1a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3aef9bc1-1d3e-4f60-b6d0-98eafb0df1a6_0">
											<gml:posList>35.67012778923483 139.7410467835516 26.45 35.670177573746564 139.74104896863375 26.45 35.67017825883337 139.74102550564913 26.45 35.67012847432124 139.74102332058155 26.45 35.67012778923483 139.7410467835516 26.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c45cab1d-68a6-4095-9a6f-99c14d3dc916">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c45cab1d-68a6-4095-9a6f-99c14d3dc916_0">
											<gml:posList>35.670177573746564 139.74104896863375 23.716 35.67017825883337 139.74102550564913 23.716 35.67017825883337 139.74102550564913 26.45 35.670177573746564 139.74104896863375 26.45 35.670177573746564 139.74104896863375 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33103d64-954a-448d-8af9-13c6cba4eadd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33103d64-954a-448d-8af9-13c6cba4eadd_0">
											<gml:posList>35.6701882283398 139.74104944240466 23.716 35.6701882283398 139.74104944240466 26.45 35.67018891341823 139.74102596837068 26.45 35.67018891341823 139.74102596837068 23.716 35.6701882283398 139.74104944240466 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-244a451d-3de3-4656-a2b3-43a53c465c7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-244a451d-3de3-4656-a2b3-43a53c465c7a_0">
											<gml:posList>35.6701882283398 139.74104944240466 26.45 35.67023760721653 139.74105160586439 26.45 35.670238292303814 139.7410281428622 26.45 35.67018891341823 139.74102596837068 26.45 35.6701882283398 139.74104944240466 26.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6ce5707-9002-400b-8238-f6e772da4f90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6ce5707-9002-400b-8238-f6e772da4f90_0">
											<gml:posList>35.67023760721653 139.74105160586439 23.716 35.670238292303814 139.7410281428622 23.716 35.670238292303814 139.7410281428622 26.45 35.67023760721653 139.74105160586439 26.45 35.67023760721653 139.74105160586439 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-517263ce-0a12-4e97-80be-88a186cdd1c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-517263ce-0a12-4e97-80be-88a186cdd1c9_0">
											<gml:posList>35.67012778923483 139.7410467835516 23.716 35.670177573746564 139.74104896863375 23.716 35.670177573746564 139.74104896863375 26.45 35.67012778923483 139.7410467835516 26.45 35.67012778923483 139.7410467835516 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bf33e21-3758-451a-a0c8-dabd08173106">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7bf33e21-3758-451a-a0c8-dabd08173106_0">
											<gml:posList>35.6701882283398 139.74104944240466 23.716 35.67023760721653 139.74105160586439 23.716 35.67023760721653 139.74105160586439 26.45 35.6701882283398 139.74104944240466 26.45 35.6701882283398 139.74104944240466 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3c05083-74a0-49b1-833e-9bc06bcba53d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3c05083-74a0-49b1-833e-9bc06bcba53d_0">
											<gml:posList>35.67014373712876 139.7410619427111 23.716 35.670135687594595 139.7410615874493 23.716 35.670135687594595 139.7410615874493 26.373 35.67014373712876 139.7410619427111 26.373 35.67014373712876 139.7410619427111 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afdc3d8c-5bba-446a-b4a3-ce0e569ad639">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afdc3d8c-5bba-446a-b4a3-ce0e569ad639_0">
											<gml:posList>35.670135687594595 139.7410615874493 23.716 35.67013480917458 139.7410915458243 23.716 35.67013480917458 139.7410915458243 26.373 35.670135687594595 139.7410615874493 26.373 35.670135687594595 139.7410615874493 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bc7fd84-cd51-4aa3-8d23-29795cca62fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1bc7fd84-cd51-4aa3-8d23-29795cca62fd_0">
											<gml:posList>35.670135687594595 139.7410615874493 26.373 35.67013480917458 139.7410915458243 26.373 35.67014285870866 139.74109190108913 26.373 35.67014373712876 139.7410619427111 26.373 35.670135687594595 139.7410615874493 26.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd0ae027-2efb-42b1-8f43-3d0a12d463d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd0ae027-2efb-42b1-8f43-3d0a12d463d7_0">
											<gml:posList>35.67014285870866 139.74109190108913 23.716 35.67014373712876 139.7410619427111 23.716 35.67014373712876 139.7410619427111 26.373 35.67014285870866 139.74109190108913 26.373 35.67014285870866 139.74109190108913 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a2a58e0-e46f-4da5-9e51-b57f638a6da9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a2a58e0-e46f-4da5-9e51-b57f638a6da9_0">
											<gml:posList>35.67013480917458 139.7410915458243 23.716 35.67014285870866 139.74109190108913 23.716 35.67014285870866 139.74109190108913 26.373 35.67013480917458 139.7410915458243 26.373 35.67013480917458 139.7410915458243 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b0fdf1a-bd23-4efa-9611-300ec2a9b777">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b0fdf1a-bd23-4efa-9611-300ec2a9b777_0">
											<gml:posList>35.67025081858618 139.74095396397468 23.716 35.670119565128225 139.74094807291746 23.716 35.670119565128225 139.74094807291746 26.16 35.67025081858618 139.74095396397468 26.16 35.67025081858618 139.74095396397468 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-070725ad-9504-456c-b767-5fbb83548a83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-070725ad-9504-456c-b767-5fbb83548a83_0">
											<gml:posList>35.670245477363544 139.74095907349204 23.716 35.670245477363544 139.74095907349204 26.16 35.67012148922085 139.74095350544258 26.16 35.67012148922085 139.74095350544258 23.716 35.670245477363544 139.74095907349204 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3dddc4e-ac68-4a68-8c83-a139435513f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3dddc4e-ac68-4a68-8c83-a139435513f3_0">
											<gml:posList>35.67008736624985 139.74096918620467 23.947 35.67008637524021 139.7409698390732 23.947 35.67008637524021 139.7409698390732 26.16 35.670119565128225 139.74094807291746 26.16 35.670119565128225 139.74094807291746 23.716 35.67008736624985 139.74096918620467 23.716 35.67008736624985 139.74096918620467 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-454358c9-17a9-4db3-9583-8a3cd1e80f00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-454358c9-17a9-4db3-9583-8a3cd1e80f00_0">
											<gml:posList>35.67025030017345 139.74097142867996 23.716 35.67025081858618 139.74095396397468 23.716 35.67025081858618 139.74095396397468 26.16 35.67025030017345 139.74097142867996 26.16 35.67025030017345 139.74097142867996 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a5834d0-879e-4a3d-babf-1ccee1991a0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a5834d0-879e-4a3d-babf-1ccee1991a0c_0">
											<gml:posList>35.67009026364573 139.74097438563632 23.716 35.67012148922085 139.74095350544258 23.716 35.67012148922085 139.74095350544258 26.16 35.67009026364573 139.74097438563632 26.16 35.67009026364573 139.74097438563632 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc1184ca-feb2-419a-a76a-15c82093ce1d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc1184ca-feb2-419a-a76a-15c82093ce1d_0">
											<gml:posList>35.670245477363544 139.74095907349204 23.716 35.670245117104784 139.7409712026796 23.716 35.670245117104784 139.7409712026796 26.16 35.670245477363544 139.74095907349204 26.16 35.670245477363544 139.74095907349204 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01132889-eee4-410f-af42-efaa72ed774e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01132889-eee4-410f-af42-efaa72ed774e_0">
											<gml:posList>35.67022810364235 139.7409652683559 23.716 35.67022174891675 139.74096520939935 23.716 35.67022174891675 139.74096520939935 24.508 35.67022810364235 139.7409652683559 24.508 35.67022810364235 139.7409652683559 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b1cdf68-6f21-432a-9c0e-72afc593f6a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b1cdf68-6f21-432a-9c0e-72afc593f6a3_0">
											<gml:posList>35.670245117104784 139.7409712026796 23.716 35.67025030017345 139.74097142867996 23.716 35.67025030017345 139.74097142867996 26.16 35.670245117104784 139.7409712026796 26.16 35.670245117104784 139.7409712026796 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f08a033-c1a1-4147-9305-f3f1be8264ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f08a033-c1a1-4147-9305-f3f1be8264ea_0">
											<gml:posList>35.67022174891675 139.74096520939935 23.716 35.67022164367648 139.74098077366946 23.716 35.67022164367648 139.74098077366946 24.508 35.67022174891675 139.74096520939935 24.508 35.67022174891675 139.74096520939935 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc95be4b-4afb-480c-a811-9c6c1814e3d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc95be4b-4afb-480c-a811-9c6c1814e3d1_0">
											<gml:posList>35.67022174891675 139.74096520939935 24.508 35.67022164367648 139.74098077366946 24.508 35.670227998402055 139.74098083262726 24.508 35.67022810364235 139.7409652683559 24.508 35.67022174891675 139.74096520939935 24.508</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10ec4622-8cde-45e2-8ff6-ce64b71c5147">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10ec4622-8cde-45e2-8ff6-ce64b71c5147_0">
											<gml:posList>35.670227998402055 139.74098083262726 23.716 35.67022810364235 139.7409652683559 23.716 35.67022810364235 139.7409652683559 24.508 35.670227998402055 139.74098083262726 24.508 35.670227998402055 139.74098083262726 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74dcdd3a-7d18-419a-92ff-b2eef48a1e22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74dcdd3a-7d18-419a-92ff-b2eef48a1e22_0">
											<gml:posList>35.67025030017345 139.74097142867996 26.16 35.67025081858618 139.74095396397468 26.16 35.670119565128225 139.74094807291746 26.16 35.67008637524021 139.7409698390732 26.16 35.67008576483899 139.74100840212665 26.16 35.67008973095345 139.7410084969757 26.16 35.67009026364573 139.74097438563632 26.16 35.67012148922085 139.74095350544258 26.16 35.670245477363544 139.74095907349204 26.16 35.670245117104784 139.7409712026796 26.16 35.67025030017345 139.74097142867996 26.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4138a1b-3032-4758-8f6b-5d9a0abbb42f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4138a1b-3032-4758-8f6b-5d9a0abbb42f_0">
											<gml:posList>35.67022164367648 139.74098077366946 23.716 35.670227998402055 139.74098083262726 23.716 35.670227998402055 139.74098083262726 24.508 35.67022164367648 139.74098077366946 24.508 35.67022164367648 139.74098077366946 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-103e2e4b-4e45-41e0-ba3a-8a3d5ccfbc7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-103e2e4b-4e45-41e0-ba3a-8a3d5ccfbc7f_0">
											<gml:posList>35.67024814502193 139.7409820466005 23.716 35.67024218662059 139.7409816226602 23.716 35.67024218662059 139.7409816226602 25.981 35.67024814502193 139.7409820466005 25.981 35.67024814502193 139.7409820466005 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-236dd939-0405-4e48-9205-2e7a6d7a00f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-236dd939-0405-4e48-9205-2e7a6d7a00f6_0">
											<gml:posList>35.67008736624985 139.74096918620467 23.716 35.67008665721454 139.74100842319152 23.716 35.67008665721454 139.74100842319152 23.947 35.67008736624985 139.74096918620467 23.947 35.67008736624985 139.74096918620467 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26042116-8cb6-491f-994e-e6b8fd099f92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26042116-8cb6-491f-994e-e6b8fd099f92_0">
											<gml:posList>35.67008637524021 139.7409698390732 23.947 35.67008576483899 139.74100840212665 23.947 35.67008576483899 139.74100840212665 26.16 35.67008637524021 139.7409698390732 26.16 35.67008637524021 139.7409698390732 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-357a03c9-52c1-48e6-b6b3-f64b16502fc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-357a03c9-52c1-48e6-b6b3-f64b16502fc6_0">
											<gml:posList>35.67008973095345 139.7410084969757 23.716 35.67009026364573 139.74097438563632 23.716 35.67009026364573 139.74097438563632 26.16 35.67008973095345 139.7410084969757 26.16 35.67008973095345 139.7410084969757 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2104e918-c601-4ffe-9943-935f81f1064f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2104e918-c601-4ffe-9943-935f81f1064f_0">
											<gml:posList>35.67024218662059 139.7409816226602 23.716 35.670240900451795 139.7410087758003 23.716 35.670240900451795 139.7410087758003 25.981 35.67024218662059 139.7409816226602 25.981 35.67024218662059 139.7409816226602 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ed79b31-0fc3-4ad3-93b3-ec17b72e09f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ed79b31-0fc3-4ad3-93b3-ec17b72e09f1_0">
											<gml:posList>35.67024218662059 139.7409816226602 25.981 35.670240900451795 139.7410087758003 25.981 35.670246858853034 139.74100919974262 25.981 35.67024814502193 139.7409820466005 25.981 35.67024218662059 139.7409816226602 25.981</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b53ca1e9-4024-4540-b111-7478156ca101">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b53ca1e9-4024-4540-b111-7478156ca101_0">
											<gml:posList>35.670246858853034 139.74100919974262 23.716 35.67024814502193 139.7409820466005 23.716 35.67024814502193 139.7409820466005 25.981 35.670246858853034 139.74100919974262 25.981 35.670246858853034 139.74100919974262 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fed95942-ebb0-46a2-8748-0552799f9970">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fed95942-ebb0-46a2-8748-0552799f9970_0">
											<gml:posList>35.67021710567298 139.74099893891022 23.716 35.670185594332295 139.74099980366665 23.716 35.670185594332295 139.74099980366665 25.984 35.67021710567298 139.74099893891022 25.984 35.67021710567298 139.74099893891022 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6948c0a-0b62-4ff4-b9ff-7f66fe2a47de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6948c0a-0b62-4ff4-b9ff-7f66fe2a47de_0">
											<gml:posList>35.670185594332295 139.74099980366665 23.716 35.6701856645261 139.74100906032882 23.716 35.6701856645261 139.74100906032882 25.984 35.670185594332295 139.74099980366665 25.984 35.670185594332295 139.74099980366665 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74d5816a-797b-4a10-9650-1421981ca9d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74d5816a-797b-4a10-9650-1421981ca9d6_0">
											<gml:posList>35.670216359624035 139.741013421386 25.984 35.67021710567298 139.74099893891022 25.984 35.670185594332295 139.74099980366665 25.984 35.6701856645261 139.74100906032882 25.984 35.67020771341406 139.7410107581525 25.984 35.67020761578756 139.74101274658733 25.984 35.670216359624035 139.741013421386 25.984</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6dc4189d-9d00-4671-a5e5-f7c45ac3aaa1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6dc4189d-9d00-4671-a5e5-f7c45ac3aaa1_0">
											<gml:posList>35.670216359624035 139.741013421386 23.716 35.67021710567298 139.74099893891022 23.716 35.67021710567298 139.74099893891022 25.984 35.670216359624035 139.741013421386 25.984 35.670216359624035 139.741013421386 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0215946-0ba9-4459-91d7-de08943b7208">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0215946-0ba9-4459-91d7-de08943b7208_0">
											<gml:posList>35.67008973095345 139.7410084969757 23.716 35.67008973095345 139.7410084969757 26.16 35.67008576483899 139.74100840212665 26.16 35.67008576483899 139.74100840212665 23.947 35.67008665721454 139.74100842319152 23.947 35.67008665721454 139.74100842319152 23.716 35.67008973095345 139.7410084969757 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfb94298-2b7a-4fa5-a88a-778519da2efa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfb94298-2b7a-4fa5-a88a-778519da2efa_0">
											<gml:posList>35.670240900451795 139.7410087758003 23.716 35.670246858853034 139.74100919974262 23.716 35.670246858853034 139.74100919974262 25.981 35.670240900451795 139.7410087758003 25.981 35.670240900451795 139.7410087758003 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0602821-0026-4180-b3e8-ba7432898595">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0602821-0026-4180-b3e8-ba7432898595_0">
											<gml:posList>35.6701856645261 139.74100906032882 23.716 35.67020771341406 139.7410107581525 23.716 35.67020771341406 139.7410107581525 25.984 35.6701856645261 139.74100906032882 25.984 35.6701856645261 139.74100906032882 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9620b5d-a50c-48c9-9d19-9ffed9345e66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9620b5d-a50c-48c9-9d19-9ffed9345e66_0">
											<gml:posList>35.67020771341406 139.7410107581525 23.716 35.67020761578756 139.74101274658733 23.716 35.67020761578756 139.74101274658733 25.984 35.67020771341406 139.7410107581525 25.984 35.67020771341406 139.7410107581525 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e95f4aa1-f6b5-4299-a61b-6be956c4eaba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e95f4aa1-f6b5-4299-a61b-6be956c4eaba_0">
											<gml:posList>35.67020761578756 139.74101274658733 23.716 35.670216359624035 139.741013421386 23.716 35.670216359624035 139.741013421386 25.984 35.67020761578756 139.74101274658733 25.984 35.67020761578756 139.74101274658733 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2aa77fad-8afb-4794-bfc7-f27ae9ab893c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2aa77fad-8afb-4794-bfc7-f27ae9ab893c_0">
											<gml:posList>35.67012847432124 139.74102332058155 23.716 35.67012847432124 139.74102332058155 26.45 35.67017825883337 139.74102550564913 26.45 35.67017825883337 139.74102550564913 23.716 35.67012847432124 139.74102332058155 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51087a69-ee0f-451f-8008-3ec87f090583">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51087a69-ee0f-451f-8008-3ec87f090583_0">
											<gml:posList>35.670238292303814 139.7410281428622 23.716 35.67018891341823 139.74102596837068 23.716 35.67018891341823 139.74102596837068 26.45 35.670238292303814 139.7410281428622 26.45 35.670238292303814 139.7410281428622 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1ea4da6-5f88-4164-93a3-9128ef83f4bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1ea4da6-5f88-4164-93a3-9128ef83f4bd_0">
											<gml:posList>35.67012847432124 139.74102332058155 23.716 35.67012778923483 139.7410467835516 23.716 35.67012778923483 139.7410467835516 26.45 35.67012847432124 139.74102332058155 26.45 35.67012847432124 139.74102332058155 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6968f712-633d-4ff8-893a-4d1d8c70068c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6968f712-633d-4ff8-893a-4d1d8c70068c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6968f712-633d-4ff8-893a-4d1d8c70068c">
											<gml:posList>35.67011922998029 139.74093418820064 8.91 35.67025642172785 139.74093778581994 8.91 35.67025599036433 139.74096297174964 8.91 35.67032206230941 139.7409646630304 8.91 35.67032085442877 139.74103513950539 8.91 35.67033266257515 139.74103534683726 8.91 35.670331715334484 139.74109311982997 8.91 35.67031837477067 139.74109280379005 8.91 35.67031819898082 139.7410986585053 8.91 35.67025365945494 139.74109707581374 8.91 35.67025348671071 139.74110690716788 8.91 35.67008096049557 139.74110246620748 8.91 35.67008355445113 139.74095875191918 8.91 35.67011922998029 139.74093418820064 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08bed4c6-1b34-4394-adb6-c41752df62ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08bed4c6-1b34-4394-adb6-c41752df62ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08bed4c6-1b34-4394-adb6-c41752df62ff">
											<gml:posList>35.67011922998029 139.74093418820064 23.947 35.67012023429237 139.74093912470522 23.947 35.670252324170846 139.74094259565706 23.947 35.67025642172785 139.74093778581994 23.947 35.67011922998029 139.74093418820064 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b5b86f2c-b2de-42d3-a3ab-248d4ccd03cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5b86f2c-b2de-42d3-a3ab-248d4ccd03cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5b86f2c-b2de-42d3-a3ab-248d4ccd03cf">
											<gml:posList>35.67011922998029 139.74093418820064 23.947 35.67008355445113 139.74095875191918 23.947 35.67008750469903 139.7409616635699 23.947 35.67012023429237 139.74093912470522 23.947 35.67011922998029 139.74093418820064 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa197f43-8ca8-45f5-b2cc-4445bd8d1bab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa197f43-8ca8-45f5-b2cc-4445bd8d1bab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa197f43-8ca8-45f5-b2cc-4445bd8d1bab">
											<gml:posList>35.67025599036433 139.74096297174964 23.947 35.67025642172785 139.74093778581994 23.947 35.670252324170846 139.74094259565706 23.947 35.67025197917285 139.7409628659084 23.947 35.67025599036433 139.74096297174964 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-15f36365-f3a1-4b9d-8b05-03c2a9c7abc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15f36365-f3a1-4b9d-8b05-03c2a9c7abc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15f36365-f3a1-4b9d-8b05-03c2a9c7abc9">
											<gml:posList>35.67025599036433 139.74096297174964 34.638 35.67026215277862 139.74097084062154 34.638 35.67031563229845 139.74097221502726 34.638 35.67032206230941 139.7409646630304 34.638 35.67025599036433 139.74096297174964 34.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-73e7c839-777c-45ff-9b88-ed34a09e2d59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73e7c839-777c-45ff-9b88-ed34a09e2d59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73e7c839-777c-45ff-9b88-ed34a09e2d59">
											<gml:posList>35.67032085442877 139.74103513950539 34.638 35.67032206230941 139.7409646630304 34.638 35.67031563229845 139.74097221502726 34.638 35.67031455352316 139.74103473804755 34.638 35.67032085442877 139.74103513950539 34.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e9683f82-af0f-47c9-829f-f59b54a893b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9683f82-af0f-47c9-829f-f59b54a893b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9683f82-af0f-47c9-829f-f59b54a893b2">
											<gml:posList>35.670249648255115 139.7410969589195 23.716 35.67025197917285 139.7409628659084 23.716 35.670252324170846 139.74094259565706 23.716 35.67012023429237 139.74093912470522 23.716 35.67008750469903 139.7409616635699 23.716 35.67008504905384 139.74109766744536 23.716 35.67024956190002 139.74110189668883 23.716 35.670249648255115 139.7410969589195 23.716</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67e3f2db-b022-4b74-8d98-406c4ad6b79a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67e3f2db-b022-4b74-8d98-406c4ad6b79a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67e3f2db-b022-4b74-8d98-406c4ad6b79a">
											<gml:posList>35.67025599036433 139.74096297174964 23.947 35.67025197917285 139.7409628659084 23.947 35.670249648255115 139.7410969589195 23.947 35.67025365945494 139.74109707581374 23.947 35.67025599036433 139.74096297174964 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-db900e36-d356-46dc-abaa-e31394ea8636">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db900e36-d356-46dc-abaa-e31394ea8636">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db900e36-d356-46dc-abaa-e31394ea8636">
											<gml:posList>35.67025365945494 139.74109707581374 34.638 35.67026009847909 139.7410895127761 34.638 35.67026215277862 139.74097084062154 34.638 35.67025599036433 139.74096297174964 34.638 35.67025365945494 139.74109707581374 34.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c7e6ff5f-6cd1-4578-9091-674c92544e6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7e6ff5f-6cd1-4578-9091-674c92544e6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7e6ff5f-6cd1-4578-9091-674c92544e6a">
											<gml:posList>35.67008355445113 139.74095875191918 23.947 35.67008096049557 139.74110246620748 23.947 35.67008504905384 139.74109766744536 23.947 35.67008750469903 139.7409616635699 23.947 35.67008355445113 139.74095875191918 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b4e6cd35-0fcb-42f2-8714-27db84461142">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4e6cd35-0fcb-42f2-8714-27db84461142">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4e6cd35-0fcb-42f2-8714-27db84461142">
											<gml:posList>35.67031455352316 139.74103473804755 34.18 35.67031563229845 139.74097221502726 34.18 35.67026215277862 139.74097084062154 34.18 35.67026009847909 139.7410895127761 34.18 35.67031214473959 139.74109078949363 34.18 35.67031455352316 139.74103473804755 34.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-15945293-4782-46a4-9666-4eafbbf8dc69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15945293-4782-46a4-9666-4eafbbf8dc69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15945293-4782-46a4-9666-4eafbbf8dc69">
											<gml:posList>35.67032085442877 139.74103513950539 34.638 35.67031455352316 139.74103473804755 34.638 35.67031214473959 139.74109078949363 34.638 35.67031837477067 139.74109280379005 34.638 35.67032085442877 139.74103513950539 34.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-477f7dd9-c61b-4779-a183-ecf749046037">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-477f7dd9-c61b-4779-a183-ecf749046037">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-477f7dd9-c61b-4779-a183-ecf749046037">
											<gml:posList>35.67032085442877 139.74103513950539 19.576 35.67031837477067 139.74109280379005 19.576 35.670331715334484 139.74109311982997 19.576 35.67033266257515 139.74103534683726 19.576 35.67032085442877 139.74103513950539 19.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bda7df46-0c12-4e34-8167-656e9a95cc1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bda7df46-0c12-4e34-8167-656e9a95cc1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bda7df46-0c12-4e34-8167-656e9a95cc1e">
											<gml:posList>35.67031819898082 139.7410986585053 34.638 35.67031214473959 139.74109078949363 34.638 35.67026009847909 139.7410895127761 34.638 35.67025365945494 139.74109707581374 34.638 35.67031819898082 139.7410986585053 34.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f7c3e850-6810-4ff4-a399-17aa8ea02389">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7c3e850-6810-4ff4-a399-17aa8ea02389">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7c3e850-6810-4ff4-a399-17aa8ea02389">
											<gml:posList>35.67031819898082 139.7410986585053 34.638 35.67031837477067 139.74109280379005 34.638 35.67031214473959 139.74109078949363 34.638 35.67031819898082 139.7410986585053 34.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-120c5acd-b3d6-41c6-9c30-5947008141c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-120c5acd-b3d6-41c6-9c30-5947008141c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-120c5acd-b3d6-41c6-9c30-5947008141c8">
											<gml:posList>35.67025365945494 139.74109707581374 23.947 35.670249648255115 139.7410969589195 23.947 35.67024956190002 139.74110189668883 23.947 35.67025348671071 139.74110690716788 23.947 35.67025365945494 139.74109707581374 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0c17838c-6a3b-45f9-b360-302a1617135b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c17838c-6a3b-45f9-b360-302a1617135b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c17838c-6a3b-45f9-b360-302a1617135b">
											<gml:posList>35.67025348671071 139.74110690716788 23.947 35.67024956190002 139.74110189668883 23.947 35.67008504905384 139.74109766744536 23.947 35.67008096049557 139.74110246620748 23.947 35.67025348671071 139.74110690716788 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c46056a-8f4b-4f08-9af9-0a144e437484">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c46056a-8f4b-4f08-9af9-0a144e437484">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c46056a-8f4b-4f08-9af9-0a144e437484">
											<gml:posList>35.67008355445113 139.74095875191918 8.91 35.67008096049557 139.74110246620748 8.91 35.67008096049557 139.74110246620748 23.947 35.67008355445113 139.74095875191918 23.947 35.67008355445113 139.74095875191918 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f589db91-0e4d-4850-8ff9-2d18b2fd9fb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f589db91-0e4d-4850-8ff9-2d18b2fd9fb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f589db91-0e4d-4850-8ff9-2d18b2fd9fb3">
											<gml:posList>35.67008504905384 139.74109766744536 23.947 35.67008504905384 139.74109766744536 23.716 35.67008750469903 139.7409616635699 23.716 35.67008750469903 139.7409616635699 23.947 35.67008504905384 139.74109766744536 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0dfe9945-46b1-480d-93bd-9e40c903be65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dfe9945-46b1-480d-93bd-9e40c903be65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dfe9945-46b1-480d-93bd-9e40c903be65">
											<gml:posList>35.67011922998029 139.74093418820064 8.91 35.67008355445113 139.74095875191918 8.91 35.67008355445113 139.74095875191918 23.947 35.67011922998029 139.74093418820064 23.947 35.67011922998029 139.74093418820064 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3e6b3c9-8f4e-435b-b55c-49e4e1a4e52c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3e6b3c9-8f4e-435b-b55c-49e4e1a4e52c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3e6b3c9-8f4e-435b-b55c-49e4e1a4e52c">
											<gml:posList>35.67008750469903 139.7409616635699 23.947 35.67008750469903 139.7409616635699 23.716 35.67012023429237 139.74093912470522 23.716 35.67012023429237 139.74093912470522 23.947 35.67008750469903 139.7409616635699 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-117edbeb-4383-42bd-a269-a4c2b33d188a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-117edbeb-4383-42bd-a269-a4c2b33d188a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-117edbeb-4383-42bd-a269-a4c2b33d188a">
											<gml:posList>35.67008096049557 139.74110246620748 8.91 35.67025348671071 139.74110690716788 8.91 35.67025348671071 139.74110690716788 23.947 35.67008096049557 139.74110246620748 23.947 35.67008096049557 139.74110246620748 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5bc9cb50-c9fd-4698-b59a-98ddb9ec013c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bc9cb50-c9fd-4698-b59a-98ddb9ec013c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bc9cb50-c9fd-4698-b59a-98ddb9ec013c">
											<gml:posList>35.67024956190002 139.74110189668883 23.947 35.67024956190002 139.74110189668883 23.716 35.67008504905384 139.74109766744536 23.716 35.67008504905384 139.74109766744536 23.947 35.67024956190002 139.74110189668883 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c6faa56-7e0d-4a21-a98c-80a28d243e8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c6faa56-7e0d-4a21-a98c-80a28d243e8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c6faa56-7e0d-4a21-a98c-80a28d243e8e">
											<gml:posList>35.67012023429237 139.74093912470522 23.947 35.67012023429237 139.74093912470522 23.716 35.670252324170846 139.74094259565706 23.716 35.670252324170846 139.74094259565706 23.947 35.67012023429237 139.74093912470522 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85879de5-12ed-46b0-95da-93e8696989ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85879de5-12ed-46b0-95da-93e8696989ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85879de5-12ed-46b0-95da-93e8696989ce">
											<gml:posList>35.67025642172785 139.74093778581994 8.91 35.67011922998029 139.74093418820064 8.91 35.67011922998029 139.74093418820064 23.947 35.67025642172785 139.74093778581994 23.947 35.67025642172785 139.74093778581994 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c906f23e-f515-489c-a403-14cbb4d1e592">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c906f23e-f515-489c-a403-14cbb4d1e592">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c906f23e-f515-489c-a403-14cbb4d1e592">
											<gml:posList>35.670249648255115 139.7410969589195 23.947 35.670249648255115 139.7410969589195 23.716 35.67024956190002 139.74110189668883 23.716 35.67024956190002 139.74110189668883 23.947 35.670249648255115 139.7410969589195 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8ebc6f4-6594-41e8-844d-5f9295b47527">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8ebc6f4-6594-41e8-844d-5f9295b47527">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8ebc6f4-6594-41e8-844d-5f9295b47527">
											<gml:posList>35.67025197917285 139.7409628659084 23.947 35.67025197917285 139.7409628659084 23.716 35.670249648255115 139.7410969589195 23.716 35.670249648255115 139.7410969589195 23.947 35.67025197917285 139.7409628659084 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b387520-7ef1-4fa0-8628-dc59dca74878">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b387520-7ef1-4fa0-8628-dc59dca74878">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b387520-7ef1-4fa0-8628-dc59dca74878">
											<gml:posList>35.670252324170846 139.74094259565706 23.947 35.670252324170846 139.74094259565706 23.716 35.67025197917285 139.7409628659084 23.716 35.67025197917285 139.7409628659084 23.947 35.670252324170846 139.74094259565706 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a88b7ce-f3e4-4469-b0fe-4b984da62b1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a88b7ce-f3e4-4469-b0fe-4b984da62b1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a88b7ce-f3e4-4469-b0fe-4b984da62b1a">
											<gml:posList>35.67025348671071 139.74110690716788 8.91 35.67025365945494 139.74109707581374 8.91 35.67025365945494 139.74109707581374 23.947 35.67025348671071 139.74110690716788 23.947 35.67025348671071 139.74110690716788 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c31048be-a903-49a7-a0cf-7106fecac7aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c31048be-a903-49a7-a0cf-7106fecac7aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c31048be-a903-49a7-a0cf-7106fecac7aa">
											<gml:posList>35.67025365945494 139.74109707581374 23.947 35.67025365945494 139.74109707581374 34.638 35.67025599036433 139.74096297174964 34.638 35.67025599036433 139.74096297174964 23.947 35.67025365945494 139.74109707581374 23.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96273f97-8828-4129-8f6b-2e3247c105fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96273f97-8828-4129-8f6b-2e3247c105fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96273f97-8828-4129-8f6b-2e3247c105fc">
											<gml:posList>35.67025599036433 139.74096297174964 8.91 35.67025642172785 139.74093778581994 8.91 35.67025642172785 139.74093778581994 23.947 35.67025599036433 139.74096297174964 23.947 35.67025599036433 139.74096297174964 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd0d5d67-fc35-4c87-9905-f6f02d936f1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd0d5d67-fc35-4c87-9905-f6f02d936f1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd0d5d67-fc35-4c87-9905-f6f02d936f1d">
											<gml:posList>35.67026009847909 139.7410895127761 34.638 35.67026009847909 139.7410895127761 34.18 35.67026215277862 139.74097084062154 34.18 35.67026215277862 139.74097084062154 34.638 35.67026009847909 139.7410895127761 34.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed24eb2a-5463-4141-8c55-fd99d5b7e427">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed24eb2a-5463-4141-8c55-fd99d5b7e427">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed24eb2a-5463-4141-8c55-fd99d5b7e427">
											<gml:posList>35.67031819898082 139.7410986585053 34.638 35.67025365945494 139.74109707581374 34.638 35.67025365945494 139.74109707581374 23.947 35.67025365945494 139.74109707581374 8.91 35.67031819898082 139.7410986585053 8.91 35.67031819898082 139.7410986585053 34.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be91e1be-9022-4538-ab28-2bd0f520ba92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be91e1be-9022-4538-ab28-2bd0f520ba92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be91e1be-9022-4538-ab28-2bd0f520ba92">
											<gml:posList>35.67031214473959 139.74109078949363 34.638 35.67031214473959 139.74109078949363 34.18 35.67026009847909 139.7410895127761 34.18 35.67026009847909 139.7410895127761 34.638 35.67031214473959 139.74109078949363 34.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38eee15b-2060-4e98-961c-9d74d2096f09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38eee15b-2060-4e98-961c-9d74d2096f09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38eee15b-2060-4e98-961c-9d74d2096f09">
											<gml:posList>35.67026215277862 139.74097084062154 34.638 35.67026215277862 139.74097084062154 34.18 35.67031563229845 139.74097221502726 34.18 35.67031563229845 139.74097221502726 34.638 35.67026215277862 139.74097084062154 34.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8409ea42-51b6-4188-9ee6-840338323365">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8409ea42-51b6-4188-9ee6-840338323365">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8409ea42-51b6-4188-9ee6-840338323365">
											<gml:posList>35.67032206230941 139.7409646630304 34.638 35.67032206230941 139.7409646630304 8.91 35.67025599036433 139.74096297174964 8.91 35.67025599036433 139.74096297174964 23.947 35.67025599036433 139.74096297174964 34.638 35.67032206230941 139.7409646630304 34.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c42fe94-dbcf-4b63-a3fc-09b241f11642">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c42fe94-dbcf-4b63-a3fc-09b241f11642">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c42fe94-dbcf-4b63-a3fc-09b241f11642">
											<gml:posList>35.67031455352316 139.74103473804755 34.638 35.67031455352316 139.74103473804755 34.18 35.67031214473959 139.74109078949363 34.18 35.67031214473959 139.74109078949363 34.638 35.67031455352316 139.74103473804755 34.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e09796ae-2eea-461e-98a9-3e511c6a82ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e09796ae-2eea-461e-98a9-3e511c6a82ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e09796ae-2eea-461e-98a9-3e511c6a82ce">
											<gml:posList>35.67031563229845 139.74097221502726 34.638 35.67031563229845 139.74097221502726 34.18 35.67031455352316 139.74103473804755 34.18 35.67031455352316 139.74103473804755 34.638 35.67031563229845 139.74097221502726 34.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2840ee0-069d-497d-957d-ff1fc3b87f98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2840ee0-069d-497d-957d-ff1fc3b87f98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2840ee0-069d-497d-957d-ff1fc3b87f98">
											<gml:posList>35.67031819898082 139.7410986585053 8.91 35.67031837477067 139.74109280379005 8.91 35.67031837477067 139.74109280379005 19.576 35.67031837477067 139.74109280379005 34.638 35.67031819898082 139.7410986585053 34.638 35.67031819898082 139.7410986585053 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97dba5f6-72a2-4ac5-b05d-71aebaa1302c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97dba5f6-72a2-4ac5-b05d-71aebaa1302c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97dba5f6-72a2-4ac5-b05d-71aebaa1302c">
											<gml:posList>35.67032085442877 139.74103513950539 34.638 35.67031837477067 139.74109280379005 34.638 35.67031837477067 139.74109280379005 19.576 35.67032085442877 139.74103513950539 19.576 35.67032085442877 139.74103513950539 34.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dccff67b-ede5-4eab-b1fa-1e1b9ecaff9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dccff67b-ede5-4eab-b1fa-1e1b9ecaff9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dccff67b-ede5-4eab-b1fa-1e1b9ecaff9b">
											<gml:posList>35.67032206230941 139.7409646630304 8.91 35.67032206230941 139.7409646630304 34.638 35.67032085442877 139.74103513950539 34.638 35.67032085442877 139.74103513950539 19.576 35.67032085442877 139.74103513950539 8.91 35.67032206230941 139.7409646630304 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-952d275f-1c86-496d-9604-5950aa56b008">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-952d275f-1c86-496d-9604-5950aa56b008">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-952d275f-1c86-496d-9604-5950aa56b008">
											<gml:posList>35.67031837477067 139.74109280379005 8.91 35.670331715334484 139.74109311982997 8.91 35.670331715334484 139.74109311982997 19.576 35.67031837477067 139.74109280379005 19.576 35.67031837477067 139.74109280379005 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f1f62aa-cc42-4693-b4f1-eeddb6aabe85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f1f62aa-cc42-4693-b4f1-eeddb6aabe85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f1f62aa-cc42-4693-b4f1-eeddb6aabe85">
											<gml:posList>35.67033266257515 139.74103534683726 8.91 35.67032085442877 139.74103513950539 8.91 35.67032085442877 139.74103513950539 19.576 35.67033266257515 139.74103534683726 19.576 35.67033266257515 139.74103534683726 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8a85e9f-ece0-47f8-9b9f-f474c989b82d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8a85e9f-ece0-47f8-9b9f-f474c989b82d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8a85e9f-ece0-47f8-9b9f-f474c989b82d">
											<gml:posList>35.670331715334484 139.74109311982997 8.91 35.67033266257515 139.74103534683726 8.91 35.67033266257515 139.74103534683726 19.576 35.670331715334484 139.74109311982997 19.576 35.670331715334484 139.74109311982997 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2291</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">288.6455</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>