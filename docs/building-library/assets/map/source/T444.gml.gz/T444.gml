<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_82e3d2c5-61f5-4068-ada8-8ce4068067cf">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">21.3</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671347569928855 139.74000290934626 0 35.67129594482699 139.7400798633323 0 35.671317856263634 139.74010193062372 0 35.67130580088209 139.74012001653136 0 35.67134826162181 139.74016280507658 0 35.67146566512175 139.73998781503482 0 35.67139138803438 139.7399129737917 0 35.67133771923922 139.73999297906113 0 35.671347569928855 139.74000290934626 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671347569928855 139.74000290934626 9.44 35.67133771923922 139.73999297906113 9.44 35.67139138803438 139.7399129737917 9.44 35.67146566512175 139.73998781503482 9.44 35.67134826162181 139.74016280507658 9.44 35.67130580088209 139.74012001653136 9.44 35.671317856263634 139.74010193062372 9.44 35.67129594482699 139.7400798633323 9.44 35.671347569928855 139.74000290934626 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671347569928855 139.74000290934626 9.44 35.67129594482699 139.7400798633323 9.44 35.67129594482699 139.7400798633323 30.78 35.671347569928855 139.74000290934626 30.78 35.671347569928855 139.74000290934626 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67129594482699 139.7400798633323 9.44 35.671317856263634 139.74010193062372 9.44 35.671317856263634 139.74010193062372 30.78 35.67129594482699 139.7400798633323 30.78 35.67129594482699 139.7400798633323 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671317856263634 139.74010193062372 9.44 35.67130580088209 139.74012001653136 9.44 35.67130580088209 139.74012001653136 30.78 35.671317856263634 139.74010193062372 30.78 35.671317856263634 139.74010193062372 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67130580088209 139.74012001653136 9.44 35.67134826162181 139.74016280507658 9.44 35.67134826162181 139.74016280507658 30.78 35.67130580088209 139.74012001653136 30.78 35.67130580088209 139.74012001653136 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67134826162181 139.74016280507658 9.44 35.67146566512175 139.73998781503482 9.44 35.67146566512175 139.73998781503482 30.78 35.67134826162181 139.74016280507658 30.78 35.67134826162181 139.74016280507658 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67146566512175 139.73998781503482 9.44 35.67139138803438 139.7399129737917 9.44 35.67139138803438 139.7399129737917 30.78 35.67146566512175 139.73998781503482 30.78 35.67146566512175 139.73998781503482 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67139138803438 139.7399129737917 9.44 35.67133771923922 139.73999297906113 9.44 35.67133771923922 139.73999297906113 30.78 35.67139138803438 139.7399129737917 30.78 35.67139138803438 139.7399129737917 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67133771923922 139.73999297906113 9.44 35.671347569928855 139.74000290934626 9.44 35.671347569928855 139.74000290934626 30.78 35.67133771923922 139.73999297906113 30.78 35.67133771923922 139.73999297906113 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671347569928855 139.74000290934626 30.78 35.67129594482699 139.7400798633323 30.78 35.671317856263634 139.74010193062372 30.78 35.67130580088209 139.74012001653136 30.78 35.67134826162181 139.74016280507658 30.78 35.67146566512175 139.73998781503482 30.78 35.67139138803438 139.7399129737917 30.78 35.67133771923922 139.73999297906113 30.78 35.671347569928855 139.74000290934626 30.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-af414452-0458-4934-af8a-4089d9b24688"/>
							<gml:surfaceMember xlink:href="#poly-712661ac-7bf7-4151-a29c-2552ae87e467"/>
							<gml:surfaceMember xlink:href="#poly-c22b443d-e83e-430a-a730-4abfc1e78ea3"/>
							<gml:surfaceMember xlink:href="#poly-1dd1be11-dfdb-4eed-a92f-8b32ff301657"/>
							<gml:surfaceMember xlink:href="#poly-8de2f60d-f3ec-4359-8cac-8ac01ba3cb78"/>
							<gml:surfaceMember xlink:href="#poly-79444ac3-c431-4322-9bb7-5f076e2e70cf"/>
							<gml:surfaceMember xlink:href="#poly-bc5dfb29-6ce7-49fa-a5c5-e50f1fc19769"/>
							<gml:surfaceMember xlink:href="#poly-713c779f-5c68-4928-8a8e-84707ba6cb28"/>
							<gml:surfaceMember xlink:href="#poly-839701f6-37e5-4f16-91a3-5b7447095c01"/>
							<gml:surfaceMember xlink:href="#poly-d73f9f00-7e70-44bf-8062-57c95b27311e"/>
							<gml:surfaceMember xlink:href="#poly-2939726a-8b86-4778-a562-11da23a7ad75"/>
							<gml:surfaceMember xlink:href="#poly-e1f45c60-6cda-4f9b-98f8-cf45a0420114"/>
							<gml:surfaceMember xlink:href="#poly-1198567f-3b6f-430c-b16b-b0a2dbdfdd87"/>
							<gml:surfaceMember xlink:href="#poly-928facc0-786b-4333-892a-b5deb47150b0"/>
							<gml:surfaceMember xlink:href="#poly-bfb73761-815c-4684-8411-62f2b1ff5687"/>
							<gml:surfaceMember xlink:href="#poly-f0e1a14d-dee4-444d-aca3-1f1f2d59293f"/>
							<gml:surfaceMember xlink:href="#poly-1d8c82a7-6856-4c75-b6dc-cf76b38234ac"/>
							<gml:surfaceMember xlink:href="#poly-ed0ffc7f-d80e-452a-b491-e7a6efbec5d8"/>
							<gml:surfaceMember xlink:href="#poly-8017ea1b-a8e0-4eac-b64f-fe5295b3c462"/>
							<gml:surfaceMember xlink:href="#poly-af21a8b1-c496-4ac6-8130-ebff01598e21"/>
							<gml:surfaceMember xlink:href="#poly-2a34ba01-c4d2-4583-a6b4-b17d59c82277"/>
							<gml:surfaceMember xlink:href="#poly-1f14bc3f-e705-484f-9134-cd22b019cbb5"/>
							<gml:surfaceMember xlink:href="#poly-6bbaf215-b1a2-4e66-a974-a877b277e7df"/>
							<gml:surfaceMember xlink:href="#poly-132d65fc-bdbe-4f62-bb7e-c6b599cc7d10"/>
							<gml:surfaceMember xlink:href="#poly-f50a01d1-2021-4c8e-8c49-579b02d64ddd"/>
							<gml:surfaceMember xlink:href="#poly-a0d0e827-729e-45e1-8cb8-95597f6d8833"/>
							<gml:surfaceMember xlink:href="#poly-9f9b5d41-0f57-41d9-a0d6-06db6ea0ccad"/>
							<gml:surfaceMember xlink:href="#poly-dfdbedc0-295f-4d2b-8c03-f08416c32a9a"/>
							<gml:surfaceMember xlink:href="#poly-a99b6839-2c0d-4bf1-ad4f-19ef7f3f0f75"/>
							<gml:surfaceMember xlink:href="#poly-ff3d13c8-f1c2-4211-869f-0d5e7284df30"/>
							<gml:surfaceMember xlink:href="#poly-19c04f4d-0347-45ac-a76a-77b845e50dd6"/>
							<gml:surfaceMember xlink:href="#poly-e0e3c80a-db28-4f7d-9d45-44b1c7a4e599"/>
							<gml:surfaceMember xlink:href="#poly-0db92479-1176-4569-b3a3-f9bab6ca3d4f"/>
							<gml:surfaceMember xlink:href="#poly-e70331bd-da55-4f3f-af47-a4380c1dbebe"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_82e3d2c5-61f5-4068-ada8-8ce4068067cf_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-152cc4f3-1737-4ab4-80fd-87190d54c461">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67131491835937 139.74007938836178 30.896 35.6713332670267 139.74005187255332 30.896 35.67134587800653 139.74006450600007 30.896 35.671327538350084 139.74009202179948 30.896 35.67131491835937 139.74007938836178 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-404972c5-87bd-4d01-b2aa-433bda6d8b78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-404972c5-87bd-4d01-b2aa-433bda6d8b78_0">
											<gml:posList>35.6713332670267 139.74005187255332 30.896 35.6713332670267 139.74005187255332 33.739 35.67134587800653 139.74006450600007 33.739 35.67134587800653 139.74006450600007 30.896 35.6713332670267 139.74005187255332 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c58c40dd-65d4-44af-8397-3ab5e40c02df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c58c40dd-65d4-44af-8397-3ab5e40c02df_0">
											<gml:posList>35.67131491835937 139.74007938836178 30.896 35.67131491835937 139.74007938836178 33.739 35.6713332670267 139.74005187255332 33.739 35.6713332670267 139.74005187255332 30.896 35.67131491835937 139.74007938836178 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4aa451a9-241f-44c1-9704-ea471c81d5bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4aa451a9-241f-44c1-9704-ea471c81d5bd_0">
											<gml:posList>35.67134587800653 139.74006450600007 33.739 35.6713332670267 139.74005187255332 33.739 35.67131491835937 139.74007938836178 33.739 35.671327538350084 139.74009202179948 33.739 35.67134587800653 139.74006450600007 33.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8022ea78-1388-4efc-82c2-5c127f42903f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8022ea78-1388-4efc-82c2-5c127f42903f_0">
											<gml:posList>35.67134587800653 139.74006450600007 30.896 35.67134587800653 139.74006450600007 33.739 35.671327538350084 139.74009202179948 33.739 35.671327538350084 139.74009202179948 30.896 35.67134587800653 139.74006450600007 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46b149b1-33a0-48fe-85b6-e69441d9cb4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46b149b1-33a0-48fe-85b6-e69441d9cb4e_0">
											<gml:posList>35.671327538350084 139.74009202179948 30.896 35.671327538350084 139.74009202179948 33.739 35.67131491835937 139.74007938836178 33.739 35.67131491835937 139.74007938836178 30.896 35.671327538350084 139.74009202179948 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_82e3d2c5-61f5-4068-ada8-8ce4068067cf_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28caa873-7125-4f87-933c-844418fb2b2f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67128385335106 139.74009789404838 9.44 35.67129594482698 139.7400798633323 9.44 35.671317856272154 139.74010194167008 9.44 35.67130580088207 139.74012001653136 9.44 35.67128385335106 139.74009789404838 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d9c6ead-8945-4304-abe2-373f0930475d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d9c6ead-8945-4304-abe2-373f0930475d_0">
											<gml:posList>35.67129594482698 139.7400798633323 31.39 35.67129594482698 139.7400798633323 9.44 35.67128385335106 139.74009789404838 9.44 35.67128385335106 139.74009789404838 31.39 35.67129594482698 139.7400798633323 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc448fc9-b831-44d7-a1cc-e1583a57bd64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc448fc9-b831-44d7-a1cc-e1583a57bd64_0">
											<gml:posList>35.671317856272154 139.74010194167008 31.39 35.671317856272154 139.74010194167008 9.44 35.67129594482698 139.7400798633323 9.44 35.67129594482698 139.7400798633323 31.39 35.671317856272154 139.74010194167008 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1dd7df1a-6fb0-4dcd-ab4b-79538f309fa3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1dd7df1a-6fb0-4dcd-ab4b-79538f309fa3_0">
											<gml:posList>35.67130580088207 139.74012001653136 31.39 35.671317856272154 139.74010194167008 31.39 35.67129594482698 139.7400798633323 31.39 35.67128385335106 139.74009789404838 31.39 35.67130580088207 139.74012001653136 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2f4936a-e644-4a1f-9310-2fb5f2913681">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2f4936a-e644-4a1f-9310-2fb5f2913681_0">
											<gml:posList>35.67128385335106 139.74009789404838 31.39 35.67128385335106 139.74009789404838 9.44 35.67130580088207 139.74012001653136 9.44 35.67130580088207 139.74012001653136 31.39 35.67128385335106 139.74009789404838 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f77e8a9-f675-4e42-8ba4-8064afee4875">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f77e8a9-f675-4e42-8ba4-8064afee4875_0">
											<gml:posList>35.67130580088207 139.74012001653136 31.39 35.67130580088207 139.74012001653136 9.44 35.671317856272154 139.74010194167008 9.44 35.671317856272154 139.74010194167008 31.39 35.67130580088207 139.74012001653136 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_82e3d2c5-61f5-4068-ada8-8ce4068067cf_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66ba5b02-469f-4cfe-be44-50bffaa99bc7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67134803811151 139.74000222392488 31.39 35.67135022113585 139.74000441961584 31.39 35.671335806802055 139.74002589953295 31.39 35.671333623778104 139.74002370384179 31.39 35.67134803811151 139.74000222392488 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bada194-be2c-4917-b135-9da582930d2e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67134595517291 139.74003612772808 30.896 35.671335806802055 139.74002589953295 30.896 35.67135022113585 139.74000441961584 30.896 35.6713603695085 139.74001464781009 30.896 35.67134595517291 139.74003612772808 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac8c951b-ceec-431a-b424-cc629f6ab7b1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67135439372571 139.74004995903954 30.896 35.67134860250941 139.74004427688533 30.896 35.671354067367865 139.74003591945305 30.896 35.671359858576 139.74004159056065 30.896 35.67135439372571 139.74004995903954 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94513cef-1e6c-4d3f-aea1-16ecea41fe18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6713713828551 139.74002443314438 30.896 35.67136616992802 139.74003220482714 30.896 35.671359882442644 139.74002586046728 30.896 35.67136508636416 139.7400180998416 30.896 35.6713713828551 139.74002443314438 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90d66922-c2ac-4c10-a8ef-0e2ad7197e2a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67137658677652 139.74001667251747 30.896 35.67137029929889 139.74001033920436 30.896 35.6713762144814 139.74000151729462 30.896 35.67138250196805 139.74000786165388 30.896 35.67137658677652 139.74001667251747 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2be56e4-a35d-429a-84f8-144c44434f52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67138153545127 139.73999359083354 30.896 35.67138727958593 139.7399850452804 30.896 35.67139356706486 139.73999137859286 30.896 35.67138783195203 139.73999993518208 30.896 35.67138153545127 139.73999359083354 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d6f8d81-70fd-47d4-90dd-bd405b0390c3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67139765141964 139.73996959033772 30.896 35.671403938899374 139.73997592364978 30.896 35.671399248163254 139.73998291043645 30.896 35.671392960683875 139.73997657712422 30.896 35.67139765141964 139.73996959033772 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-654f2f2d-81d8-4a61-b057-f3653e4cdc97">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671415931334266 139.73995805869964 30.896 35.67141027724455 139.7399664826425 30.896 35.67140398975576 139.73996013828432 30.896 35.67140964385361 139.7399517253881 30.896 35.671415931334266 139.73995805869964 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d780289a-d77d-4131-87bb-93f62beed526">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d780289a-d77d-4131-87bb-93f62beed526_0">
											<gml:posList>35.671415931334266 139.73995805869964 30.896 35.67140964385361 139.7399517253881 30.896 35.67140964385361 139.7399517253881 34.258 35.671415931334266 139.73995805869964 34.258 35.671415931334266 139.73995805869964 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f3d190f-9a65-4bf7-a8a9-9b28f64adf7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f3d190f-9a65-4bf7-a8a9-9b28f64adf7e_0">
											<gml:posList>35.67140964385361 139.7399517253881 30.896 35.67140398975576 139.73996013828432 30.896 35.67140398975576 139.73996013828432 34.258 35.67140964385361 139.7399517253881 34.258 35.67140964385361 139.7399517253881 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7883e6cc-6ce0-4e14-af5d-ea43c3aa5ff6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7883e6cc-6ce0-4e14-af5d-ea43c3aa5ff6_0">
											<gml:posList>35.67140398975576 139.73996013828432 34.258 35.67141027724455 139.7399664826425 34.258 35.671415931334266 139.73995805869964 34.258 35.67140964385361 139.7399517253881 34.258 35.67140398975576 139.73996013828432 34.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62c8d003-b9f1-488f-bfa3-4392813c51d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62c8d003-b9f1-488f-bfa3-4392813c51d1_0">
											<gml:posList>35.67141027724455 139.7399664826425 30.896 35.671415931334266 139.73995805869964 30.896 35.671415931334266 139.73995805869964 34.258 35.67141027724455 139.7399664826425 34.258 35.67141027724455 139.7399664826425 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-894d66db-35d1-4f72-8bb6-75e6c1e344cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-894d66db-35d1-4f72-8bb6-75e6c1e344cd_0">
											<gml:posList>35.67140398975576 139.73996013828432 30.896 35.67141027724455 139.7399664826425 30.896 35.67141027724455 139.7399664826425 34.258 35.67140398975576 139.73996013828432 34.258 35.67140398975576 139.73996013828432 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5b9cdf2-9fbe-48c5-ac46-de8bfe7beb27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5b9cdf2-9fbe-48c5-ac46-de8bfe7beb27_0">
											<gml:posList>35.671403938899374 139.73997592364978 30.896 35.67139765141964 139.73996959033772 30.896 35.67139765141964 139.73996959033772 34.258 35.671403938899374 139.73997592364978 34.258 35.671403938899374 139.73997592364978 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07a5561b-0e3d-4564-bb41-f47be7a6bbe3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07a5561b-0e3d-4564-bb41-f47be7a6bbe3_0">
											<gml:posList>35.671392960683875 139.73997657712422 30.896 35.671392960683875 139.73997657712422 34.258 35.67139765141964 139.73996959033772 34.258 35.67139765141964 139.73996959033772 30.896 35.671392960683875 139.73997657712422 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25dde949-949e-425f-919d-7ce84fa75553">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25dde949-949e-425f-919d-7ce84fa75553_0">
											<gml:posList>35.67139765141964 139.73996959033772 34.258 35.671392960683875 139.73997657712422 34.258 35.671399248163254 139.73998291043645 34.258 35.671403938899374 139.73997592364978 34.258 35.67139765141964 139.73996959033772 34.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21fdc3f7-4f67-4b98-8e22-484afb9b4ab1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21fdc3f7-4f67-4b98-8e22-484afb9b4ab1_0">
											<gml:posList>35.671399248163254 139.73998291043645 30.896 35.671403938899374 139.73997592364978 30.896 35.671403938899374 139.73997592364978 34.258 35.671399248163254 139.73998291043645 34.258 35.671399248163254 139.73998291043645 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41b6ec9f-b60f-4d35-83b9-eeda8fdaf85a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41b6ec9f-b60f-4d35-83b9-eeda8fdaf85a_0">
											<gml:posList>35.671399248163254 139.73998291043645 30.896 35.671399248163254 139.73998291043645 34.258 35.671392960683875 139.73997657712422 34.258 35.671392960683875 139.73997657712422 30.896 35.671399248163254 139.73998291043645 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-549afefe-3fbb-48bb-8876-6ee700aa867d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-549afefe-3fbb-48bb-8876-6ee700aa867d_0">
											<gml:posList>35.67139356706486 139.73999137859286 30.896 35.67138727958593 139.7399850452804 30.896 35.67138727958593 139.7399850452804 34.258 35.67139356706486 139.73999137859286 34.258 35.67139356706486 139.73999137859286 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7dd36c13-c938-4d29-87c3-14bea7ba0add">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7dd36c13-c938-4d29-87c3-14bea7ba0add_0">
											<gml:posList>35.67138727958593 139.7399850452804 30.896 35.67138153545127 139.73999359083354 30.896 35.67138153545127 139.73999359083354 34.258 35.67138727958593 139.7399850452804 34.258 35.67138727958593 139.7399850452804 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df00406d-78f4-4e35-8e78-28ba42c2b750">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df00406d-78f4-4e35-8e78-28ba42c2b750_0">
											<gml:posList>35.67138153545127 139.73999359083354 34.258 35.67138783195203 139.73999993518208 34.258 35.67139356706486 139.73999137859286 34.258 35.67138727958593 139.7399850452804 34.258 35.67138153545127 139.73999359083354 34.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e86f4cc-ed77-4215-81dd-2776a39b3718">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e86f4cc-ed77-4215-81dd-2776a39b3718_0">
											<gml:posList>35.67138783195203 139.73999993518208 30.896 35.67139356706486 139.73999137859286 30.896 35.67139356706486 139.73999137859286 34.258 35.67138783195203 139.73999993518208 34.258 35.67138783195203 139.73999993518208 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78f5c020-b7fa-458a-b346-44a04a35013f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78f5c020-b7fa-458a-b346-44a04a35013f_0">
											<gml:posList>35.67138153545127 139.73999359083354 30.896 35.67138783195203 139.73999993518208 30.896 35.67138783195203 139.73999993518208 34.258 35.67138153545127 139.73999359083354 34.258 35.67138153545127 139.73999359083354 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59c9230e-b13c-4e39-a910-2f83d3794001">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59c9230e-b13c-4e39-a910-2f83d3794001_0">
											<gml:posList>35.67138250196805 139.74000786165388 30.896 35.6713762144814 139.74000151729462 30.896 35.6713762144814 139.74000151729462 34.258 35.67138250196805 139.74000786165388 34.258 35.67138250196805 139.74000786165388 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71152afd-8492-4f12-879e-5bf6139fd000">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71152afd-8492-4f12-879e-5bf6139fd000_0">
											<gml:posList>35.6713762144814 139.74000151729462 30.896 35.67137029929889 139.74001033920436 30.896 35.67137029929889 139.74001033920436 34.258 35.6713762144814 139.74000151729462 34.258 35.6713762144814 139.74000151729462 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2af12351-2014-42a2-a232-3d7dbf88c073">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2af12351-2014-42a2-a232-3d7dbf88c073_0">
											<gml:posList>35.67134803811151 139.74000222392488 32.178 35.6713603695085 139.74001464781009 32.178 35.6713603695085 139.74001464781009 30.896 35.67135022113585 139.74000441961584 30.896 35.67135022113585 139.74000441961584 31.39 35.67134803811151 139.74000222392488 31.39 35.67134803811151 139.74000222392488 32.178</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-851593fe-7432-44e1-9102-2dd8dc881f79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-851593fe-7432-44e1-9102-2dd8dc881f79_0">
											<gml:posList>35.6713762144814 139.74000151729462 34.258 35.67137029929889 139.74001033920436 34.258 35.67137658677652 139.74001667251747 34.258 35.67138250196805 139.74000786165388 34.258 35.6713762144814 139.74000151729462 34.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-451d8167-bf6c-4f8e-9635-5c71eb82291a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-451d8167-bf6c-4f8e-9635-5c71eb82291a_0">
											<gml:posList>35.67137658677652 139.74001667251747 30.896 35.67138250196805 139.74000786165388 30.896 35.67138250196805 139.74000786165388 34.258 35.67137658677652 139.74001667251747 34.258 35.67137658677652 139.74001667251747 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa79751f-a8e5-40c7-9d89-89b370dfb197">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa79751f-a8e5-40c7-9d89-89b370dfb197_0">
											<gml:posList>35.67134803811151 139.74000222392488 31.39 35.671333623778104 139.74002370384179 31.39 35.671333623778104 139.74002370384179 32.178 35.67134803811151 139.74000222392488 32.178 35.67134803811151 139.74000222392488 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31ac303e-9290-4d2a-8843-1e85b3c444bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31ac303e-9290-4d2a-8843-1e85b3c444bd_0">
											<gml:posList>35.67137029929889 139.74001033920436 30.896 35.67137658677652 139.74001667251747 30.896 35.67137658677652 139.74001667251747 34.258 35.67137029929889 139.74001033920436 34.258 35.67137029929889 139.74001033920436 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cb2ea89-7703-4105-80dc-ae6e4cc09aba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cb2ea89-7703-4105-80dc-ae6e4cc09aba_0">
											<gml:posList>35.67135022113585 139.74000441961584 31.39 35.67135022113585 139.74000441961584 30.896 35.671335806802055 139.74002589953295 30.896 35.671335806802055 139.74002589953295 31.39 35.67135022113585 139.74000441961584 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc6f98ea-c52d-4f83-ba4b-e2a41df4e12c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc6f98ea-c52d-4f83-ba4b-e2a41df4e12c_0">
											<gml:posList>35.67134595517291 139.74003612772808 32.178 35.6713603695085 139.74001464781009 32.178 35.67134803811151 139.74000222392488 32.178 35.671333623778104 139.74002370384179 32.178 35.67134595517291 139.74003612772808 32.178</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cc12c61-873b-485a-b0df-d0ac2cad1776">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cc12c61-873b-485a-b0df-d0ac2cad1776_0">
											<gml:posList>35.6713713828551 139.74002443314438 30.896 35.67136508636416 139.7400180998416 30.896 35.67136508636416 139.7400180998416 34.258 35.6713713828551 139.74002443314438 34.258 35.6713713828551 139.74002443314438 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0908d8f-c650-4e8f-9e0f-659e69a461b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0908d8f-c650-4e8f-9e0f-659e69a461b3_0">
											<gml:posList>35.67136508636416 139.7400180998416 30.896 35.671359882442644 139.74002586046728 30.896 35.671359882442644 139.74002586046728 34.258 35.67136508636416 139.7400180998416 34.258 35.67136508636416 139.7400180998416 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02f0d902-3420-448a-aa23-16aaf2ab7f17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02f0d902-3420-448a-aa23-16aaf2ab7f17_0">
											<gml:posList>35.671359882442644 139.74002586046728 34.258 35.67136616992802 139.74003220482714 34.258 35.6713713828551 139.74002443314438 34.258 35.67136508636416 139.7400180998416 34.258 35.671359882442644 139.74002586046728 34.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abf41f90-aa1e-47db-a34c-7a3d3e515065">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abf41f90-aa1e-47db-a34c-7a3d3e515065_0">
											<gml:posList>35.67134595517291 139.74003612772808 30.896 35.6713603695085 139.74001464781009 30.896 35.6713603695085 139.74001464781009 32.178 35.67134595517291 139.74003612772808 32.178 35.67134595517291 139.74003612772808 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08c8c88f-a549-448c-bac5-572775700f66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08c8c88f-a549-448c-bac5-572775700f66_0">
											<gml:posList>35.67136616992802 139.74003220482714 30.896 35.6713713828551 139.74002443314438 30.896 35.6713713828551 139.74002443314438 34.258 35.67136616992802 139.74003220482714 34.258 35.67136616992802 139.74003220482714 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e29cab59-68c7-48cf-aec7-ae63c99c8e22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e29cab59-68c7-48cf-aec7-ae63c99c8e22_0">
											<gml:posList>35.671359882442644 139.74002586046728 30.896 35.67136616992802 139.74003220482714 30.896 35.67136616992802 139.74003220482714 34.258 35.671359882442644 139.74002586046728 34.258 35.671359882442644 139.74002586046728 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0088f15f-8884-4d2d-b7b5-b404ffa4238d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0088f15f-8884-4d2d-b7b5-b404ffa4238d_0">
											<gml:posList>35.67134595517291 139.74003612772808 30.896 35.67134595517291 139.74003612772808 32.178 35.671333623778104 139.74002370384179 32.178 35.671333623778104 139.74002370384179 31.39 35.671335806802055 139.74002589953295 31.39 35.671335806802055 139.74002589953295 30.896 35.67134595517291 139.74003612772808 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c41b028-87a0-42ce-a0ab-00b9d6ef2d92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c41b028-87a0-42ce-a0ab-00b9d6ef2d92_0">
											<gml:posList>35.671359858576 139.74004159056065 30.896 35.671354067367865 139.74003591945305 30.896 35.671354067367865 139.74003591945305 33.329 35.671359858576 139.74004159056065 33.329 35.671359858576 139.74004159056065 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cabea514-7d42-4bd6-88f8-102a146722fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cabea514-7d42-4bd6-88f8-102a146722fa_0">
											<gml:posList>35.671354067367865 139.74003591945305 30.896 35.67134860250941 139.74004427688533 30.896 35.67134860250941 139.74004427688533 33.329 35.671354067367865 139.74003591945305 33.329 35.671354067367865 139.74003591945305 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a2b934c-11d2-4d4b-990f-f1ef92332057">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a2b934c-11d2-4d4b-990f-f1ef92332057_0">
											<gml:posList>35.671354067367865 139.74003591945305 33.329 35.67134860250941 139.74004427688533 33.329 35.67135439372571 139.74004995903954 33.329 35.671359858576 139.74004159056065 33.329 35.671354067367865 139.74003591945305 33.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3f571e0-b966-4a02-a8c2-fe9e4be9e27e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3f571e0-b966-4a02-a8c2-fe9e4be9e27e_0">
											<gml:posList>35.67135439372571 139.74004995903954 30.896 35.671359858576 139.74004159056065 30.896 35.671359858576 139.74004159056065 33.329 35.67135439372571 139.74004995903954 33.329 35.67135439372571 139.74004995903954 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a12a30db-4f8b-4be0-b9ed-46bbe00f7034">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a12a30db-4f8b-4be0-b9ed-46bbe00f7034_0">
											<gml:posList>35.67134860250941 139.74004427688533 30.896 35.67135439372571 139.74004995903954 30.896 35.67135439372571 139.74004995903954 33.329 35.67134860250941 139.74004427688533 33.329 35.67134860250941 139.74004427688533 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-af414452-0458-4934-af8a-4089d9b24688">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af414452-0458-4934-af8a-4089d9b24688">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af414452-0458-4934-af8a-4089d9b24688">
											<gml:posList>35.6713178562636 139.74010193062372 9.44 35.67129594482698 139.7400798633323 9.44 35.671347569928855 139.74000290934623 9.44 35.67133771923919 139.73999297906113 9.44 35.67139138803437 139.7399129737917 9.44 35.67146566512174 139.73998781503482 9.44 35.6713482616218 139.74016280507658 9.44 35.67130580088207 139.74012001653136 9.44 35.6713178562636 139.74010193062372 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-712661ac-7bf7-4151-a29c-2552ae87e467">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-712661ac-7bf7-4151-a29c-2552ae87e467">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-712661ac-7bf7-4151-a29c-2552ae87e467">
											<gml:posList>35.6713178562636 139.74010193062372 31.39 35.67132184896576 139.74010143993968 31.39 35.67129994654278 139.74007937263684 31.39 35.67129594482698 139.7400798633323 31.39 35.6713178562636 139.74010193062372 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c22b443d-e83e-430a-a730-4abfc1e78ea3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c22b443d-e83e-430a-a730-4abfc1e78ea3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c22b443d-e83e-430a-a730-4abfc1e78ea3">
											<gml:posList>35.671318150311556 139.7401324625 31.39 35.67131776793892 139.74012755834792 31.39 35.67130979357576 139.7401195148019 31.39 35.67130580088207 139.74012001653136 31.39 35.671318150311556 139.7401324625 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1dd1be11-dfdb-4eed-a92f-8b32ff301657">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1dd1be11-dfdb-4eed-a92f-8b32ff301657">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1dd1be11-dfdb-4eed-a92f-8b32ff301657">
											<gml:posList>35.6713178562636 139.74010193062372 31.39 35.67130580088207 139.74012001653136 31.39 35.67130979357576 139.7401195148019 31.39 35.67132184896576 139.74010143993968 31.39 35.6713178562636 139.74010193062372 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8de2f60d-f3ec-4359-8cac-8ac01ba3cb78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8de2f60d-f3ec-4359-8cac-8ac01ba3cb78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8de2f60d-f3ec-4359-8cac-8ac01ba3cb78">
											<gml:posList>35.671347569928855 139.74000290934623 31.39 35.67129594482698 139.7400798633323 31.39 35.67129994654278 139.74007937263684 31.39 35.67135155362543 139.74000242971394 31.39 35.671347569928855 139.74000290934623 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79444ac3-c431-4322-9bb7-5f076e2e70cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79444ac3-c431-4322-9bb7-5f076e2e70cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79444ac3-c431-4322-9bb7-5f076e2e70cf">
											<gml:posList>35.671330881039864 139.74011349209493 31.39 35.67133017454881 139.74010907436025 31.39 35.67131776793892 139.74012755834792 31.39 35.671318150311556 139.7401324625 31.39 35.671330881039864 139.74011349209493 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc5dfb29-6ce7-49fa-a5c5-e50f1fc19769">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc5dfb29-6ce7-49fa-a5c5-e50f1fc19769">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc5dfb29-6ce7-49fa-a5c5-e50f1fc19769">
											<gml:posList>35.671330881039864 139.74011349209493 31.39 35.671336319084475 139.7401170648028 31.39 35.67133558553528 139.7401126250065 31.39 35.67133017454881 139.74010907436025 31.39 35.671330881039864 139.74011349209493 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-713c779f-5c68-4928-8a8e-84707ba6cb28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-713c779f-5c68-4928-8a8e-84707ba6cb28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-713c779f-5c68-4928-8a8e-84707ba6cb28">
											<gml:posList>35.6713482616218 139.74016280507658 26.27 35.67136175764057 139.74014269600104 26.27 35.671330881039864 139.74011349209493 31.39 35.671318150311556 139.7401324625 31.39 35.6713482616218 139.74016280507658 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-839701f6-37e5-4f16-91a3-5b7447095c01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-839701f6-37e5-4f16-91a3-5b7447095c01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-839701f6-37e5-4f16-91a3-5b7447095c01">
											<gml:posList>35.671347569928855 139.74000290934623 31.39 35.67135155362543 139.74000242971394 31.39 35.67134172096317 139.7399924994074 31.39 35.67133771923919 139.73999297906113 31.39 35.671347569928855 139.74000290934623 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d73f9f00-7e70-44bf-8062-57c95b27311e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d73f9f00-7e70-44bf-8062-57c95b27311e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d73f9f00-7e70-44bf-8062-57c95b27311e">
											<gml:posList>35.67136175764057 139.74014269600104 26.27 35.671336319084475 139.7401170648028 31.39 35.671330881039864 139.74011349209493 31.39 35.67136175764057 139.74014269600104 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2939726a-8b86-4778-a562-11da23a7ad75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2939726a-8b86-4778-a562-11da23a7ad75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2939726a-8b86-4778-a562-11da23a7ad75">
											<gml:posList>35.67133771923919 139.73999297906113 31.39 35.67134172096317 139.7399924994074 31.39 35.67139177942089 139.7399178668903 31.39 35.67139138803437 139.7399129737917 31.39 35.67133771923919 139.73999297906113 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e1f45c60-6cda-4f9b-98f8-cf45a0420114">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1f45c60-6cda-4f9b-98f8-cf45a0420114">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1f45c60-6cda-4f9b-98f8-cf45a0420114">
											<gml:posList>35.671434601071844 139.7399610305316 30.896 35.67139177942089 139.7399178668903 30.896 35.67134172096317 139.7399924994074 30.896 35.67135155362543 139.74000242971394 30.896 35.67129994654278 139.74007937263684 30.896 35.67132184896576 139.74010143993968 30.896 35.67130979357576 139.7401195148019 30.896 35.67131776793892 139.74012755834792 30.896 35.67133017454881 139.74010907436025 30.896 35.67133558553528 139.7401126250065 30.896 35.671434601071844 139.7399610305316 30.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1198567f-3b6f-430c-b16b-b0a2dbdfdd87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1198567f-3b6f-430c-b16b-b0a2dbdfdd87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1198567f-3b6f-430c-b16b-b0a2dbdfdd87">
											<gml:posList>35.67143856671505 139.7399605177785 31.39 35.671434601071844 139.7399610305316 31.39 35.67133558553528 139.7401126250065 31.39 35.671336319084475 139.7401170648028 31.39 35.67143856671505 139.7399605177785 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-928facc0-786b-4333-892a-b5deb47150b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-928facc0-786b-4333-892a-b5deb47150b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-928facc0-786b-4333-892a-b5deb47150b0">
											<gml:posList>35.67146566512174 139.73998781503482 26.27 35.67143856671505 139.7399605177785 31.39 35.671336319084475 139.7401170648028 31.39 35.67146566512174 139.73998781503482 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bfb73761-815c-4684-8411-62f2b1ff5687">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfb73761-815c-4684-8411-62f2b1ff5687">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfb73761-815c-4684-8411-62f2b1ff5687">
											<gml:posList>35.671336319084475 139.7401170648028 31.39 35.67136175764057 139.74014269600104 26.27 35.67146566512174 139.73998781503482 26.27 35.671336319084475 139.7401170648028 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0e1a14d-dee4-444d-aca3-1f1f2d59293f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0e1a14d-dee4-444d-aca3-1f1f2d59293f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0e1a14d-dee4-444d-aca3-1f1f2d59293f">
											<gml:posList>35.67139138803437 139.7399129737917 31.39 35.67139177942089 139.7399178668903 31.39 35.671434601071844 139.7399610305316 31.39 35.67143856671505 139.7399605177785 31.39 35.67139138803437 139.7399129737917 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d8c82a7-6856-4c75-b6dc-cf76b38234ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d8c82a7-6856-4c75-b6dc-cf76b38234ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d8c82a7-6856-4c75-b6dc-cf76b38234ac">
											<gml:posList>35.671434601071844 139.7399610305316 31.39 35.671434601071844 139.7399610305316 30.896 35.67133558553528 139.7401126250065 30.896 35.67133558553528 139.7401126250065 31.39 35.671434601071844 139.7399610305316 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed0ffc7f-d80e-452a-b491-e7a6efbec5d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed0ffc7f-d80e-452a-b491-e7a6efbec5d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed0ffc7f-d80e-452a-b491-e7a6efbec5d8">
											<gml:posList>35.67129594482698 139.7400798633323 9.44 35.6713178562636 139.74010193062372 9.44 35.6713178562636 139.74010193062372 31.39 35.67129594482698 139.7400798633323 31.39 35.67129594482698 139.7400798633323 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8017ea1b-a8e0-4eac-b64f-fe5295b3c462">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8017ea1b-a8e0-4eac-b64f-fe5295b3c462">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8017ea1b-a8e0-4eac-b64f-fe5295b3c462">
											<gml:posList>35.67132184896576 139.74010143993968 31.39 35.67132184896576 139.74010143993968 30.896 35.67129994654278 139.74007937263684 30.896 35.67129994654278 139.74007937263684 31.39 35.67132184896576 139.74010143993968 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af21a8b1-c496-4ac6-8130-ebff01598e21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af21a8b1-c496-4ac6-8130-ebff01598e21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af21a8b1-c496-4ac6-8130-ebff01598e21">
											<gml:posList>35.6713178562636 139.74010193062372 9.44 35.67130580088207 139.74012001653136 9.44 35.67130580088207 139.74012001653136 31.39 35.6713178562636 139.74010193062372 31.39 35.6713178562636 139.74010193062372 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a34ba01-c4d2-4583-a6b4-b17d59c82277">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a34ba01-c4d2-4583-a6b4-b17d59c82277">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a34ba01-c4d2-4583-a6b4-b17d59c82277">
											<gml:posList>35.67131776793892 139.74012755834792 31.39 35.67131776793892 139.74012755834792 30.896 35.67130979357576 139.7401195148019 30.896 35.67130979357576 139.7401195148019 31.39 35.67131776793892 139.74012755834792 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f14bc3f-e705-484f-9134-cd22b019cbb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f14bc3f-e705-484f-9134-cd22b019cbb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f14bc3f-e705-484f-9134-cd22b019cbb5">
											<gml:posList>35.67130979357576 139.7401195148019 31.39 35.67130979357576 139.7401195148019 30.896 35.67132184896576 139.74010143993968 30.896 35.67132184896576 139.74010143993968 31.39 35.67130979357576 139.7401195148019 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6bbaf215-b1a2-4e66-a974-a877b277e7df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bbaf215-b1a2-4e66-a974-a877b277e7df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bbaf215-b1a2-4e66-a974-a877b277e7df">
											<gml:posList>35.671347569928855 139.74000290934623 9.44 35.67129594482698 139.7400798633323 9.44 35.67129594482698 139.7400798633323 31.39 35.671347569928855 139.74000290934623 31.39 35.671347569928855 139.74000290934623 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-132d65fc-bdbe-4f62-bb7e-c6b599cc7d10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-132d65fc-bdbe-4f62-bb7e-c6b599cc7d10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-132d65fc-bdbe-4f62-bb7e-c6b599cc7d10">
											<gml:posList>35.67133017454881 139.74010907436025 31.39 35.67133017454881 139.74010907436025 30.896 35.67131776793892 139.74012755834792 30.896 35.67131776793892 139.74012755834792 31.39 35.67133017454881 139.74010907436025 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f50a01d1-2021-4c8e-8c49-579b02d64ddd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f50a01d1-2021-4c8e-8c49-579b02d64ddd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f50a01d1-2021-4c8e-8c49-579b02d64ddd">
											<gml:posList>35.67129994654278 139.74007937263684 31.39 35.67129994654278 139.74007937263684 30.896 35.67135155362543 139.74000242971394 30.896 35.67135155362543 139.74000242971394 31.39 35.67129994654278 139.74007937263684 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0d0e827-729e-45e1-8cb8-95597f6d8833">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0d0e827-729e-45e1-8cb8-95597f6d8833">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0d0e827-729e-45e1-8cb8-95597f6d8833">
											<gml:posList>35.671318150311556 139.7401324625 31.39 35.67130580088207 139.74012001653136 31.39 35.67130580088207 139.74012001653136 9.44 35.6713482616218 139.74016280507658 9.44 35.6713482616218 139.74016280507658 26.27 35.671318150311556 139.7401324625 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f9b5d41-0f57-41d9-a0d6-06db6ea0ccad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f9b5d41-0f57-41d9-a0d6-06db6ea0ccad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f9b5d41-0f57-41d9-a0d6-06db6ea0ccad">
											<gml:posList>35.67133558553528 139.7401126250065 31.39 35.67133558553528 139.7401126250065 30.896 35.67133017454881 139.74010907436025 30.896 35.67133017454881 139.74010907436025 31.39 35.67133558553528 139.7401126250065 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dfdbedc0-295f-4d2b-8c03-f08416c32a9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfdbedc0-295f-4d2b-8c03-f08416c32a9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfdbedc0-295f-4d2b-8c03-f08416c32a9a">
											<gml:posList>35.67133771923919 139.73999297906113 9.44 35.671347569928855 139.74000290934623 9.44 35.671347569928855 139.74000290934623 31.39 35.67133771923919 139.73999297906113 31.39 35.67133771923919 139.73999297906113 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a99b6839-2c0d-4bf1-ad4f-19ef7f3f0f75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a99b6839-2c0d-4bf1-ad4f-19ef7f3f0f75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a99b6839-2c0d-4bf1-ad4f-19ef7f3f0f75">
											<gml:posList>35.67135155362543 139.74000242971394 31.39 35.67135155362543 139.74000242971394 30.896 35.67134172096317 139.7399924994074 30.896 35.67134172096317 139.7399924994074 31.39 35.67135155362543 139.74000242971394 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff3d13c8-f1c2-4211-869f-0d5e7284df30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff3d13c8-f1c2-4211-869f-0d5e7284df30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff3d13c8-f1c2-4211-869f-0d5e7284df30">
											<gml:posList>35.67139138803437 139.7399129737917 9.44 35.67133771923919 139.73999297906113 9.44 35.67133771923919 139.73999297906113 31.39 35.67139138803437 139.7399129737917 31.39 35.67139138803437 139.7399129737917 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19c04f4d-0347-45ac-a76a-77b845e50dd6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19c04f4d-0347-45ac-a76a-77b845e50dd6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19c04f4d-0347-45ac-a76a-77b845e50dd6">
											<gml:posList>35.67134172096317 139.7399924994074 31.39 35.67134172096317 139.7399924994074 30.896 35.67139177942089 139.7399178668903 30.896 35.67139177942089 139.7399178668903 31.39 35.67134172096317 139.7399924994074 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0e3c80a-db28-4f7d-9d45-44b1c7a4e599">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0e3c80a-db28-4f7d-9d45-44b1c7a4e599">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0e3c80a-db28-4f7d-9d45-44b1c7a4e599">
											<gml:posList>35.6713482616218 139.74016280507658 9.44 35.67146566512174 139.73998781503482 9.44 35.67146566512174 139.73998781503482 26.27 35.67136175764057 139.74014269600104 26.27 35.6713482616218 139.74016280507658 26.27 35.6713482616218 139.74016280507658 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0db92479-1176-4569-b3a3-f9bab6ca3d4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0db92479-1176-4569-b3a3-f9bab6ca3d4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0db92479-1176-4569-b3a3-f9bab6ca3d4f">
											<gml:posList>35.67139177942089 139.7399178668903 31.39 35.67139177942089 139.7399178668903 30.896 35.671434601071844 139.7399610305316 30.896 35.671434601071844 139.7399610305316 31.39 35.67139177942089 139.7399178668903 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e70331bd-da55-4f3f-af47-a4380c1dbebe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e70331bd-da55-4f3f-af47-a4380c1dbebe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e70331bd-da55-4f3f-af47-a4380c1dbebe">
											<gml:posList>35.67139138803437 139.7399129737917 31.39 35.67143856671505 139.7399605177785 31.39 35.67146566512174 139.73998781503482 26.27 35.67146566512174 139.73998781503482 9.44 35.67139138803437 139.7399129737917 9.44 35.67139138803437 139.7399129737917 31.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7869</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>