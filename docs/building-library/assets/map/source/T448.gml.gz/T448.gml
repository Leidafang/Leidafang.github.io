<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_83464e36-5d31-41c0-8e58-0584176bd054">
			<core:creationDate>2023-08-22</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">17.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667646544414566 139.74917892010885 0 35.66759452826676 139.74934075260705 0 35.66761535339921 139.7493508013215 0 35.6676612821199 139.74937296538963 0 35.66771047129233 139.7493966923776 0 35.66776249112031 139.74923486078214 0 35.667646544414566 139.74917892010885 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667646544414566 139.74917892010885 5.354 35.66776249112031 139.74923486078214 5.354 35.66771047129233 139.7493966923776 5.354 35.6676612821199 139.74937296538963 5.354 35.66761535339921 139.7493508013215 5.354 35.66759452826676 139.74934075260705 5.354 35.667646544414566 139.74917892010885 5.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667646544414566 139.74917892010885 5.354 35.66759452826676 139.74934075260705 5.354 35.66759452826676 139.74934075260705 19.330000000000002 35.667646544414566 139.74917892010885 19.330000000000002 35.667646544414566 139.74917892010885 5.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66759452826676 139.74934075260705 5.354 35.66761535339921 139.7493508013215 5.354 35.66761535339921 139.7493508013215 19.330000000000002 35.66759452826676 139.74934075260705 19.330000000000002 35.66759452826676 139.74934075260705 5.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66761535339921 139.7493508013215 5.354 35.6676612821199 139.74937296538963 5.354 35.6676612821199 139.74937296538963 19.330000000000002 35.66761535339921 139.7493508013215 19.330000000000002 35.66761535339921 139.7493508013215 5.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6676612821199 139.74937296538963 5.354 35.66771047129233 139.7493966923776 5.354 35.66771047129233 139.7493966923776 19.330000000000002 35.6676612821199 139.74937296538963 19.330000000000002 35.6676612821199 139.74937296538963 5.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66771047129233 139.7493966923776 5.354 35.66776249112031 139.74923486078214 5.354 35.66776249112031 139.74923486078214 19.330000000000002 35.66771047129233 139.7493966923776 19.330000000000002 35.66771047129233 139.7493966923776 5.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66776249112031 139.74923486078214 5.354 35.667646544414566 139.74917892010885 5.354 35.667646544414566 139.74917892010885 19.330000000000002 35.66776249112031 139.74923486078214 19.330000000000002 35.66776249112031 139.74923486078214 5.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667646544414566 139.74917892010885 19.330000000000002 35.66759452826676 139.74934075260705 19.330000000000002 35.66761535339921 139.7493508013215 19.330000000000002 35.6676612821199 139.74937296538963 19.330000000000002 35.66771047129233 139.7493966923776 19.330000000000002 35.66776249112031 139.74923486078214 19.330000000000002 35.667646544414566 139.74917892010885 19.330000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly_TMmnt0154_p953_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0154_p953_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0154_p953_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0154_p953_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0154_p953_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0154_p950_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0154_p950_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0154_b_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0154_p952_0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gnd_TMmnt0154_b_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0154_b_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0154_b_0">
											<gml:posList>35.66776249098477 139.74923486056844 5.43543943 35.66771049329445 139.74939669862718 5.43458069 35.667594565933356 139.74934076385227 5.42898503 35.66764656354943 139.74917892599112 5.42984372 35.66776249098477 139.74923486056844 5.43543943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0154_p953_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0154_p953_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0154_p953_0">
											<gml:posList>35.66759452838938 139.749340752406 15.97054134 35.667615365475115 139.7493508062552 15.9715449 35.66765013167783 139.74918065457527 15.97157362 35.667646525919274 139.74917891481206 15.97140003 35.66759452838938 139.749340752406 15.97054134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0154_p950_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0154_p950_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0154_p950_0">
											<gml:posList>35.667713279233965 139.74921112765256 22.9596191 35.6676501243869 139.74918065240908 18.01370224 35.66761535338909 139.74935080256859 19.36192156 35.66766128171855 139.74937296518314 22.95876038 35.667713279233965 139.74921112765256 22.9596191</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0154_p950_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0154_p950_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0154_p950_1">
											<gml:posList>35.66766128171855 139.74937296518314 22.95876038 35.66771044925801 139.74939668516208 17.73613684 35.66776244684759 139.7492348474152 17.73699558 35.667713279233965 139.74921112765256 22.9596191 35.66766128171855 139.74937296518314 22.95876038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0154_p953_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0154_p953_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0154_p953_3">
											<gml:posList>35.66771049329445 139.74939669862718 5.43458069 35.66771044925801 139.74939668516208 17.73613684 35.66766128171855 139.74937296518314 22.95876038 35.66761535338909 139.74935080256859 19.36192156 35.667615365475115 139.7493508062552 15.9715449 35.66759452838938 139.749340752406 15.97054134 35.667594565933356 139.74934076385227 5.42898503 35.66771049329445 139.74939669862718 5.43458069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0154_p953_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0154_p953_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0154_p953_1">
											<gml:posList>35.66765013167783 139.74918065457527 15.97157362 35.6676501243869 139.74918065240908 18.01370224 35.667713279233965 139.74921112765256 22.9596191 35.66776244684759 139.7492348474152 17.73699558 35.66776249098477 139.74923486056844 5.43543943 35.66764656354943 139.74917892599112 5.42984372 35.667646525919274 139.74917891481206 15.97140003 35.66765013167783 139.74918065457527 15.97157362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0154_p952_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0154_p952_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0154_p952_0">
											<gml:posList>35.6676501243869 139.74918065240908 18.01370224 35.66765013167783 139.74918065457527 15.97157362 35.667615365475115 139.7493508062552 15.9715449 35.66761535338909 139.74935080256859 19.36192156 35.6676501243869 139.74918065240908 18.01370224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0154_p953_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0154_p953_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0154_p953_2">
											<gml:posList>35.66776249098477 139.74923486056844 5.43543943 35.66776244684759 139.7492348474152 17.73699558 35.66771044925801 139.74939668516208 17.73613684 35.66771049329445 139.74939669862718 5.43458069 35.66776249098477 139.74923486056844 5.43543943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0154_p953_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0154_p953_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0154_p953_4">
											<gml:posList>35.66759452838938 139.749340752406 15.97054134 35.667646525919274 139.74917891481206 15.97140003 35.66764656354943 139.74917892599112 5.42984372 35.667594565933356 139.74934076385227 5.42898503 35.66759452838938 139.749340752406 15.97054134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">278.24964</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">9</uro:districtsAndZonesType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2741800000</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>