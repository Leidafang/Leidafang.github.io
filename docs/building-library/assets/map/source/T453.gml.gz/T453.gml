<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8495a5d6-bd75-4658-9eba-da94d11055b2">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">34.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67429853936186 139.73839059597486 0 35.674243594112724 139.7382109297495 0 35.67411303264703 139.7382709581815 0 35.674167977720344 139.73845051368812 0 35.67429853936186 139.73839059597486 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67429853936186 139.73839059597486 7.97 35.674167977720344 139.73845051368812 7.97 35.67411303264703 139.7382709581815 7.97 35.674243594112724 139.7382109297495 7.97 35.67429853936186 139.73839059597486 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67429853936186 139.73839059597486 7.97 35.674243594112724 139.7382109297495 7.97 35.674243594112724 139.7382109297495 39.69 35.67429853936186 139.73839059597486 39.69 35.67429853936186 139.73839059597486 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674243594112724 139.7382109297495 7.97 35.67411303264703 139.7382709581815 7.97 35.67411303264703 139.7382709581815 39.69 35.674243594112724 139.7382109297495 39.69 35.674243594112724 139.7382109297495 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67411303264703 139.7382709581815 7.97 35.674167977720344 139.73845051368812 7.97 35.674167977720344 139.73845051368812 39.69 35.67411303264703 139.7382709581815 39.69 35.67411303264703 139.7382709581815 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674167977720344 139.73845051368812 7.97 35.67429853936186 139.73839059597486 7.97 35.67429853936186 139.73839059597486 39.69 35.674167977720344 139.73845051368812 39.69 35.674167977720344 139.73845051368812 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67429853936186 139.73839059597486 39.69 35.674243594112724 139.7382109297495 39.69 35.67411303264703 139.7382709581815 39.69 35.674167977720344 139.73845051368812 39.69 35.67429853936186 139.73839059597486 39.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6f344c65-6a3c-4d65-83be-729c84a18b1a"/>
							<gml:surfaceMember xlink:href="#poly-d1cf7649-b9e9-41f6-98ed-28bbdacf9a47"/>
							<gml:surfaceMember xlink:href="#poly-6d623f9d-b0b5-4a1b-90c5-8a4ef9ed650f"/>
							<gml:surfaceMember xlink:href="#poly-484d9c5a-4355-40c2-bac7-668f82962d52"/>
							<gml:surfaceMember xlink:href="#poly-7b82fbc0-010e-45e6-b71a-9f87f4110d37"/>
							<gml:surfaceMember xlink:href="#poly-df21033e-81ac-4ead-94a3-6454a47abd56"/>
							<gml:surfaceMember xlink:href="#poly-4eb5350e-9f8e-4476-91e0-205db4536fa9"/>
							<gml:surfaceMember xlink:href="#poly-cc22a34a-b2a9-4b76-b931-8c74ff5e337e"/>
							<gml:surfaceMember xlink:href="#poly-769f2bd0-0630-4cec-a722-a9eb8b8c0a37"/>
							<gml:surfaceMember xlink:href="#poly-55ab1da9-a3e1-4d66-b997-03e94aaa5d79"/>
							<gml:surfaceMember xlink:href="#poly-78988d7e-d416-46d4-8ea6-ada4adf1ff1b"/>
							<gml:surfaceMember xlink:href="#poly-fbd002e9-0190-4fef-a691-dadeec1d889a"/>
							<gml:surfaceMember xlink:href="#poly-93dbc305-6766-4fee-9cc3-9da44d068374"/>
							<gml:surfaceMember xlink:href="#poly-6234fa3b-8119-427b-92c5-f9dab9626b5e"/>
							<gml:surfaceMember xlink:href="#poly-0b87a65f-1b3d-4183-983d-c791287838cc"/>
							<gml:surfaceMember xlink:href="#poly-01f425b6-9682-4901-8030-b9b569e00ad7"/>
							<gml:surfaceMember xlink:href="#poly-bc13a5cf-2180-4cf0-a56d-188e797db623"/>
							<gml:surfaceMember xlink:href="#poly-d88998ad-0d23-4f94-8b2d-43f1934e3b2d"/>
							<gml:surfaceMember xlink:href="#poly-0fa22004-c6fb-4cd7-9fb2-1b26df85129f"/>
							<gml:surfaceMember xlink:href="#poly-4535f6b9-c564-4996-9e2b-dbf0b4f62abf"/>
							<gml:surfaceMember xlink:href="#poly-544702f5-e350-4189-8795-23925059f1aa"/>
							<gml:surfaceMember xlink:href="#poly-0bce6622-9904-454b-978a-34e28bcd8053"/>
							<gml:surfaceMember xlink:href="#poly-f6da3ab5-1122-48f9-9ca3-dc80707d3fa0"/>
							<gml:surfaceMember xlink:href="#poly-a5b03fe7-faa3-47df-96a3-e01c28b3c725"/>
							<gml:surfaceMember xlink:href="#poly-13d3887d-e6b8-4039-b7be-ae99bd7bf018"/>
							<gml:surfaceMember xlink:href="#poly-75541011-72d7-4a67-be0e-202c3d8552c1"/>
							<gml:surfaceMember xlink:href="#poly-48cd21fb-ac6e-4efa-ba63-13d16c227828"/>
							<gml:surfaceMember xlink:href="#poly-63414717-49bc-47b1-b493-9c01daf5d7a4"/>
							<gml:surfaceMember xlink:href="#poly-a468e7d5-189c-4ccc-91bd-fd0c07465fae"/>
							<gml:surfaceMember xlink:href="#poly-629f0376-67af-4bf6-af9a-abd1c3fe4046"/>
							<gml:surfaceMember xlink:href="#poly-efb2f785-a22c-4ff2-8cbd-fcfdf607c722"/>
							<gml:surfaceMember xlink:href="#poly-56d5184e-4277-4bd5-99e1-4a7df8ca732c"/>
							<gml:surfaceMember xlink:href="#poly-d0c5cd5f-1ea5-45fd-9e0c-3e2cc3e8d2ea"/>
							<gml:surfaceMember xlink:href="#poly-ff69fc67-951f-45d2-983e-da5f2103a677"/>
							<gml:surfaceMember xlink:href="#poly-c4d22d6f-1c95-4740-88a0-e03b68d14231"/>
							<gml:surfaceMember xlink:href="#poly-350d4060-0e67-40f3-a8cf-7b6d6cff047e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8495a5d6-bd75-4658-9eba-da94d11055b2_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-040f6407-0b40-4b4e-befc-7bc319cc60e0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67412389982102 139.73828951492393 48.526 35.674119742802795 139.73827595441335 48.526 35.67412015727678 139.73827575507994 48.526 35.67412430529002 139.73828932664804 48.526 35.67412389982102 139.73828951492393 48.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f861b595-a7b5-4bf4-9a8a-914369792a7f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67412015727678 139.73827575507994 48.231 35.67413693474684 139.73826804662934 48.231 35.67414108276095 139.73828161819986 48.231 35.67412430529002 139.73828932664804 48.231 35.67412015727678 139.73827575507994 48.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6809700-32cc-43f0-8071-bedcf344a0c4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67414716971484 139.7382621907465 48.231 35.6741521762216 139.738278534042 48.231 35.6741500858068 139.7382795086372 48.231 35.67414482699461 139.73826326506224 48.231 35.67414716971484 139.7382621907465 48.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-872d43d5-0a87-4a9f-9f1c-20662e9f00ad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67414482699461 139.73826326506224 48.526 35.67414306501974 139.73825782109037 48.526 35.67414996699695 139.73825460933898 48.526 35.674156987784585 139.73827629688736 48.526 35.674152167207886 139.73827853405268 48.526 35.67414716971484 139.7382621907465 48.526 35.67414482699461 139.73826326506224 48.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccf27e8f-48d3-4251-a387-96319bc3fe29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674186818227426 139.73825856456844 39.446 35.67420230771111 139.73830918466473 39.446 35.67418863885495 139.73831547544026 39.446 35.674173149373864 139.73826485535136 39.446 35.674186818227426 139.73825856456844 39.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7fbc857-772d-4fd9-b708-c59c67ad28e6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67425047477071 139.7383634115087 39.446 35.67425324911723 139.73837245554537 39.446 35.674186067263946 139.7384034992602 39.446 35.67418329292845 139.73839446627676 39.446 35.67425047477071 139.7383634115087 39.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0bb5ce0-ae9e-4b28-a603-6323c9a2d39b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67425928575096 139.73839206750034 39.446 35.67419210390137 139.73842312224784 39.446 35.674189438001896 139.73841443158494 39.446 35.674256610835556 139.73838337684188 39.446 35.67425928575096 139.73839206750034 39.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17c84d2a-1c3e-46c1-862b-8a1db65555ed">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67427249080448 139.73834628498759 39.446 35.674266516950176 139.7383491310921 39.446 35.674260941621455 139.73833156224885 39.446 35.67426692448906 139.73832871613251 39.446 35.67427249080448 139.73834628498759 39.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c602ae3b-7204-4683-b4d3-c7e9f9924b50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c602ae3b-7204-4683-b4d3-c7e9f9924b50_0">
											<gml:posList>35.6741521762216 139.738278534042 48.231 35.67414716971484 139.7382621907465 48.231 35.67414716971484 139.7382621907465 48.526 35.674152167207886 139.73827853405268 48.526 35.6741521762216 139.738278534042 48.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea273c3f-d705-46f3-924e-a17c5c620696">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea273c3f-d705-46f3-924e-a17c5c620696_0">
											<gml:posList>35.67425324911723 139.73837245554537 41.653 35.674186067263946 139.7384034992602 41.653 35.674186067263946 139.7384034992602 39.446 35.67425324911723 139.73837245554537 39.446 35.67425324911723 139.73837245554537 41.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91d8655c-5189-433b-a989-409af470c158">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91d8655c-5189-433b-a989-409af470c158_0">
											<gml:posList>35.674189438001896 139.73841443158494 41.653 35.674256610835556 139.73838337684188 41.653 35.674256610835556 139.73838337684188 39.446 35.674189438001896 139.73841443158494 39.446 35.674189438001896 139.73841443158494 41.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3276af3-99e9-4cb6-ae0e-e62eae48f1cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3276af3-99e9-4cb6-ae0e-e62eae48f1cd_0">
											<gml:posList>35.67412389982102 139.73828951492393 50.481 35.674119742802795 139.73827595441335 50.481 35.674119742802795 139.73827595441335 48.526 35.67412389982102 139.73828951492393 48.526 35.67412389982102 139.73828951492393 50.481</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9feacb21-7db2-486e-a6f2-52e3ee0d9943">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9feacb21-7db2-486e-a6f2-52e3ee0d9943_0">
											<gml:posList>35.67412430529002 139.73828932664804 48.526 35.67412015727678 139.73827575507994 48.526 35.67412015727678 139.73827575507994 48.231 35.67412430529002 139.73828932664804 48.231 35.67412430529002 139.73828932664804 48.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8decd31e-0b58-4eb9-8b5c-af234084d5ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8decd31e-0b58-4eb9-8b5c-af234084d5ff_0">
											<gml:posList>35.67412015727678 139.73827575507994 48.526 35.674119742802795 139.73827595441335 48.526 35.674119742802795 139.73827595441335 50.481 35.67413693474684 139.73826804662934 50.481 35.67413693474684 139.73826804662934 48.231 35.67412015727678 139.73827575507994 48.231 35.67412015727678 139.73827575507994 48.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-350ca6ab-d0ae-4655-847c-56edd6c16107">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-350ca6ab-d0ae-4655-847c-56edd6c16107_0">
											<gml:posList>35.67414108276095 139.73828161819986 50.481 35.67413693474684 139.73826804662934 50.481 35.674119742802795 139.73827595441335 50.481 35.67412389982102 139.73828951492393 50.481 35.67414108276095 139.73828161819986 50.481</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f49f325-69b1-4798-8759-ddf652b465f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f49f325-69b1-4798-8759-ddf652b465f8_0">
											<gml:posList>35.67412389982102 139.73828951492393 50.481 35.67412389982102 139.73828951492393 48.526 35.67412430529002 139.73828932664804 48.526 35.67412430529002 139.73828932664804 48.231 35.67414108276095 139.73828161819986 48.231 35.67414108276095 139.73828161819986 50.481 35.67412389982102 139.73828951492393 50.481</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb2a9f5c-0f19-49f6-9249-c2d7c62b1bbc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb2a9f5c-0f19-49f6-9249-c2d7c62b1bbc_0">
											<gml:posList>35.67413693474684 139.73826804662934 50.481 35.67414108276095 139.73828161819986 50.481 35.67414108276095 139.73828161819986 48.231 35.67413693474684 139.73826804662934 48.231 35.67413693474684 139.73826804662934 50.481</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0495a405-683a-4937-8f52-f4c6798fb5aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0495a405-683a-4937-8f52-f4c6798fb5aa_0">
											<gml:posList>35.67414482699461 139.73826326506224 48.526 35.67414716971484 139.7382621907465 48.526 35.67414716971484 139.7382621907465 48.231 35.67414482699461 139.73826326506224 48.231 35.67414482699461 139.73826326506224 48.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fe31551-e0c0-4ae7-b35f-e9b67b06e8d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fe31551-e0c0-4ae7-b35f-e9b67b06e8d5_0">
											<gml:posList>35.67414306501974 139.73825782109037 50.049 35.67414996699695 139.73825460933898 50.049 35.67414996699695 139.73825460933898 48.526 35.67414306501974 139.73825782109037 48.526 35.67414306501974 139.73825782109037 50.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a23e70e6-df4c-4a46-bf6c-b8a19cd257f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a23e70e6-df4c-4a46-bf6c-b8a19cd257f2_0">
											<gml:posList>35.67414482699461 139.73826326506224 48.231 35.6741500858068 139.7382795086372 48.231 35.6741500858068 139.7382795086372 50.049 35.67414306501974 139.73825782109037 50.049 35.67414306501974 139.73825782109037 48.526 35.67414482699461 139.73826326506224 48.526 35.67414482699461 139.73826326506224 48.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0782a470-9a41-44cb-8c20-f744a92d002b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0782a470-9a41-44cb-8c20-f744a92d002b_0">
											<gml:posList>35.67414996699695 139.73825460933898 50.049 35.67414306501974 139.73825782109037 50.049 35.6741500858068 139.7382795086372 50.049 35.674156987784585 139.73827629688736 50.049 35.67414996699695 139.73825460933898 50.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a8f70c8-30ab-4961-8a7b-01b09ba68f21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a8f70c8-30ab-4961-8a7b-01b09ba68f21_0">
											<gml:posList>35.674156987784585 139.73827629688736 50.049 35.674156987784585 139.73827629688736 48.526 35.67414996699695 139.73825460933898 48.526 35.67414996699695 139.73825460933898 50.049 35.674156987784585 139.73827629688736 50.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e583b95-1840-4746-ae43-4a6117d606e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e583b95-1840-4746-ae43-4a6117d606e4_0">
											<gml:posList>35.6741500858068 139.7382795086372 48.231 35.6741521762216 139.738278534042 48.231 35.674152167207886 139.73827853405268 48.526 35.674156987784585 139.73827629688736 48.526 35.674156987784585 139.73827629688736 50.049 35.6741500858068 139.7382795086372 50.049 35.6741500858068 139.7382795086372 48.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0537e0d-f38d-4768-b425-e81d867bc7c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0537e0d-f38d-4768-b425-e81d867bc7c8_0">
											<gml:posList>35.674173149373864 139.73826485535136 41.897 35.674186818227426 139.73825856456844 41.897 35.674186818227426 139.73825856456844 39.446 35.674173149373864 139.73826485535136 39.446 35.674173149373864 139.73826485535136 41.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88ba6730-2fd0-41a5-ba06-436545ccaa5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88ba6730-2fd0-41a5-ba06-436545ccaa5b_0">
											<gml:posList>35.674173149373864 139.73826485535136 39.446 35.67418863885495 139.73831547544026 39.446 35.67418863885495 139.73831547544026 41.897 35.674173149373864 139.73826485535136 41.897 35.674173149373864 139.73826485535136 39.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5480ac23-0d5d-4824-a2c8-1f76db37e6fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5480ac23-0d5d-4824-a2c8-1f76db37e6fe_0">
											<gml:posList>35.674186067263946 139.7384034992602 41.653 35.67418329292845 139.73839446627676 41.653 35.67418329292845 139.73839446627676 39.446 35.674186067263946 139.7384034992602 39.446 35.674186067263946 139.7384034992602 41.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-598db206-6f07-45e2-9cb9-1206773e5644">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-598db206-6f07-45e2-9cb9-1206773e5644_0">
											<gml:posList>35.67418863885495 139.73831547544026 41.897 35.67420230771111 139.73830918466473 41.897 35.674186818227426 139.73825856456844 41.897 35.674173149373864 139.73826485535136 41.897 35.67418863885495 139.73831547544026 41.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-996be106-80a8-44f8-bb6d-ce16005946fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-996be106-80a8-44f8-bb6d-ce16005946fc_0">
											<gml:posList>35.67419210390137 139.73842312224784 41.653 35.674189438001896 139.73841443158494 41.653 35.674189438001896 139.73841443158494 39.446 35.67419210390137 139.73842312224784 39.446 35.67419210390137 139.73842312224784 41.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5794b94d-1731-4595-93e4-61ffd5af9675">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5794b94d-1731-4595-93e4-61ffd5af9675_0">
											<gml:posList>35.674186818227426 139.73825856456844 41.897 35.67420230771111 139.73830918466473 41.897 35.67420230771111 139.73830918466473 39.446 35.674186818227426 139.73825856456844 39.446 35.674186818227426 139.73825856456844 41.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0154feb3-37bb-4f0f-a8d4-7c1f51b9e0e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0154feb3-37bb-4f0f-a8d4-7c1f51b9e0e2_0">
											<gml:posList>35.67420230771111 139.73830918466473 41.897 35.67418863885495 139.73831547544026 41.897 35.67418863885495 139.73831547544026 39.446 35.67420230771111 139.73830918466473 39.446 35.67420230771111 139.73830918466473 41.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26b387e5-0844-4634-bc72-a3bf40742413">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26b387e5-0844-4634-bc72-a3bf40742413_0">
											<gml:posList>35.67425047477071 139.7383634115087 39.446 35.67418329292845 139.73839446627676 39.446 35.67418329292845 139.73839446627676 41.653 35.67425047477071 139.7383634115087 41.653 35.67425047477071 139.7383634115087 39.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-735e989d-6ab1-45f0-aa6c-28aba30631c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-735e989d-6ab1-45f0-aa6c-28aba30631c9_0">
											<gml:posList>35.67425047477071 139.7383634115087 41.653 35.67418329292845 139.73839446627676 41.653 35.674186067263946 139.7384034992602 41.653 35.67425324911723 139.73837245554537 41.653 35.67425047477071 139.7383634115087 41.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33a6cf49-4d35-4192-ba9c-c10551a410bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33a6cf49-4d35-4192-ba9c-c10551a410bc_0">
											<gml:posList>35.674189438001896 139.73841443158494 41.653 35.67419210390137 139.73842312224784 41.653 35.67425928575096 139.73839206750034 41.653 35.674256610835556 139.73838337684188 41.653 35.674189438001896 139.73841443158494 41.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec72ad0c-5d7f-4734-a9b9-2552751cbbab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec72ad0c-5d7f-4734-a9b9-2552751cbbab_0">
											<gml:posList>35.67425928575096 139.73839206750034 41.653 35.67419210390137 139.73842312224784 41.653 35.67419210390137 139.73842312224784 39.446 35.67425928575096 139.73839206750034 39.446 35.67425928575096 139.73839206750034 41.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7d27112-ceb5-4885-9e86-17241f8cc6a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7d27112-ceb5-4885-9e86-17241f8cc6a7_0">
											<gml:posList>35.67425047477071 139.7383634115087 41.653 35.67425324911723 139.73837245554537 41.653 35.67425324911723 139.73837245554537 39.446 35.67425047477071 139.7383634115087 39.446 35.67425047477071 139.7383634115087 41.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71c93605-6a03-4667-bd29-1929838fa020">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71c93605-6a03-4667-bd29-1929838fa020_0">
											<gml:posList>35.674256610835556 139.73838337684188 41.653 35.67425928575096 139.73839206750034 41.653 35.67425928575096 139.73839206750034 39.446 35.674256610835556 139.73838337684188 39.446 35.674256610835556 139.73838337684188 41.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f38c9d09-9afe-4e82-b8df-971b12068fe8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f38c9d09-9afe-4e82-b8df-971b12068fe8_0">
											<gml:posList>35.674266516950176 139.7383491310921 41.653 35.674260941621455 139.73833156224885 41.653 35.674260941621455 139.73833156224885 39.446 35.674266516950176 139.7383491310921 39.446 35.674266516950176 139.7383491310921 41.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-626196f3-4094-4502-b485-d4e8e495c3ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-626196f3-4094-4502-b485-d4e8e495c3ac_0">
											<gml:posList>35.674260941621455 139.73833156224885 41.653 35.67426692448906 139.73832871613251 41.653 35.67426692448906 139.73832871613251 39.446 35.674260941621455 139.73833156224885 39.446 35.674260941621455 139.73833156224885 41.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0573991a-2ee9-42a2-b468-5c96924e272a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0573991a-2ee9-42a2-b468-5c96924e272a_0">
											<gml:posList>35.674260941621455 139.73833156224885 41.653 35.674266516950176 139.7383491310921 41.653 35.67427249080448 139.73834628498759 41.653 35.67426692448906 139.73832871613251 41.653 35.674260941621455 139.73833156224885 41.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b05985f3-0e06-4d59-aed5-10e3f1f896df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b05985f3-0e06-4d59-aed5-10e3f1f896df_0">
											<gml:posList>35.67427249080448 139.73834628498759 41.653 35.674266516950176 139.7383491310921 41.653 35.674266516950176 139.7383491310921 39.446 35.67427249080448 139.73834628498759 39.446 35.67427249080448 139.73834628498759 41.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5af96a66-d078-4bd8-9e25-b739e3c05f90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5af96a66-d078-4bd8-9e25-b739e3c05f90_0">
											<gml:posList>35.67426692448906 139.73832871613251 41.653 35.67427249080448 139.73834628498759 41.653 35.67427249080448 139.73834628498759 39.446 35.67426692448906 139.73832871613251 39.446 35.67426692448906 139.73832871613251 41.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8495a5d6-bd75-4658-9eba-da94d11055b2_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c4f5cf9-49a4-4ce9-8a29-c655da5d8bd4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67415334543639 139.738263862533 39.446 35.674161806245905 139.73825996403264 39.446 35.674170120327965 139.7382871403016 39.446 35.67416165950886 139.73829102775272 39.446 35.67415334543639 139.738263862533 39.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7233f8d-2b12-4f38-95fb-9da690f508f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7233f8d-2b12-4f38-95fb-9da690f508f4_0">
											<gml:posList>35.67415334543639 139.738263862533 40.207 35.67415334543639 139.738263862533 39.446 35.67416165950886 139.73829102775272 39.446 35.67416165950886 139.73829102775272 40.207 35.67415334543639 139.738263862533 40.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb4f8117-381d-47d3-b14a-d113af036255">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb4f8117-381d-47d3-b14a-d113af036255_0">
											<gml:posList>35.674161806245905 139.73825996403264 40.207 35.674161806245905 139.73825996403264 39.446 35.67415334543639 139.738263862533 39.446 35.67415334543639 139.738263862533 40.207 35.674161806245905 139.73825996403264 40.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75be4466-aaf1-4794-aa2b-db4394c0b68d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75be4466-aaf1-4794-aa2b-db4394c0b68d_0">
											<gml:posList>35.67415334543639 139.738263862533 40.207 35.67416165950886 139.73829102775272 40.207 35.674170120327965 139.7382871403016 40.207 35.674161806245905 139.73825996403264 40.207 35.67415334543639 139.738263862533 40.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85b6452f-1100-4d06-a820-9adfc4099f7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85b6452f-1100-4d06-a820-9adfc4099f7c_0">
											<gml:posList>35.67416165950886 139.73829102775272 40.207 35.67416165950886 139.73829102775272 39.446 35.674170120327965 139.7382871403016 39.446 35.674170120327965 139.7382871403016 40.207 35.67416165950886 139.73829102775272 40.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b2a1b4f-0567-41b2-96e1-194da01f82b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b2a1b4f-0567-41b2-96e1-194da01f82b6_0">
											<gml:posList>35.674170120327965 139.7382871403016 40.207 35.674170120327965 139.7382871403016 39.446 35.674161806245905 139.73825996403264 39.446 35.674161806245905 139.73825996403264 40.207 35.674170120327965 139.7382871403016 40.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8495a5d6-bd75-4658-9eba-da94d11055b2_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04708043-0edc-45b0-a392-e0884282ad5f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67416738465085 139.7383956671221 39.446 35.67415913382868 139.7383686675163 39.446 35.67417891179174 139.73835958572565 39.446 35.67418717162094 139.7383865742797 39.446 35.67416738465085 139.7383956671221 39.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b78995c-1bd4-4cdb-9d49-5e748264ad4a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674202016822136 139.7383289256158 39.446 35.67423067957792 139.73831637563492 39.446 35.67423760284195 139.73834014012274 39.446 35.674208940083716 139.73835269009624 39.446 35.674202016822136 139.7383289256158 39.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ba6d6e2-e7f3-4871-9094-90d5af63da80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ba6d6e2-e7f3-4871-9094-90d5af63da80_0">
											<gml:posList>35.67416738465085 139.7383956671221 41.583 35.67415913382868 139.7383686675163 41.583 35.67415913382868 139.7383686675163 39.446 35.67416738465085 139.7383956671221 39.446 35.67416738465085 139.7383956671221 41.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a51ee4d-d540-4bc6-9e78-08ddd01ea9a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a51ee4d-d540-4bc6-9e78-08ddd01ea9a7_0">
											<gml:posList>35.67415913382868 139.7383686675163 41.583 35.67417891179174 139.73835958572565 41.583 35.67417891179174 139.73835958572565 39.446 35.67415913382868 139.7383686675163 39.446 35.67415913382868 139.7383686675163 41.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44b5524e-bfdc-4028-bd81-cea6dee1e11b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44b5524e-bfdc-4028-bd81-cea6dee1e11b_0">
											<gml:posList>35.67417891179174 139.73835958572565 41.583 35.67415913382868 139.7383686675163 41.583 35.67416738465085 139.7383956671221 41.583 35.67418717162094 139.7383865742797 41.583 35.67417891179174 139.73835958572565 41.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f542857e-58c5-4949-9c7b-880291b81ef0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f542857e-58c5-4949-9c7b-880291b81ef0_0">
											<gml:posList>35.67416738465085 139.7383956671221 41.583 35.67416738465085 139.7383956671221 39.446 35.67418717162094 139.7383865742797 39.446 35.67418717162094 139.7383865742797 41.583 35.67416738465085 139.7383956671221 41.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef02729d-1767-4b63-a362-a93944ad4d10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef02729d-1767-4b63-a362-a93944ad4d10_0">
											<gml:posList>35.67417891179174 139.73835958572565 41.583 35.67418717162094 139.7383865742797 41.583 35.67418717162094 139.7383865742797 39.446 35.67417891179174 139.73835958572565 39.446 35.67417891179174 139.73835958572565 41.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96b361a8-295b-498b-969e-ff1f9aba7601">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96b361a8-295b-498b-969e-ff1f9aba7601_0">
											<gml:posList>35.674208940083716 139.73835269009624 41.727 35.674202016822136 139.7383289256158 41.727 35.674202016822136 139.7383289256158 39.446 35.674208940083716 139.73835269009624 39.446 35.674208940083716 139.73835269009624 41.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df5e5e0d-6f5e-4c14-9cdb-89eceedb173c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df5e5e0d-6f5e-4c14-9cdb-89eceedb173c_0">
											<gml:posList>35.674202016822136 139.7383289256158 41.727 35.67423067957792 139.73831637563492 41.727 35.67423067957792 139.73831637563492 39.446 35.674202016822136 139.7383289256158 39.446 35.674202016822136 139.7383289256158 41.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cc112c4-47af-4149-ad3d-ea46a9a350be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4cc112c4-47af-4149-ad3d-ea46a9a350be_0">
											<gml:posList>35.67423760284195 139.73834014012274 41.727 35.67423067957792 139.73831637563492 41.727 35.674202016822136 139.7383289256158 41.727 35.674208940083716 139.73835269009624 41.727 35.67423760284195 139.73834014012274 41.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-967e28c1-fc39-4d9d-bfc1-dc3b6f95e377">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-967e28c1-fc39-4d9d-bfc1-dc3b6f95e377_0">
											<gml:posList>35.67423760284195 139.73834014012274 41.727 35.674208940083716 139.73835269009624 41.727 35.674208940083716 139.73835269009624 39.446 35.67423760284195 139.73834014012274 39.446 35.67423760284195 139.73834014012274 41.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8aee055a-dfbe-4536-91b7-dbb059f1b65b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8aee055a-dfbe-4536-91b7-dbb059f1b65b_0">
											<gml:posList>35.67423760284195 139.73834014012274 41.727 35.67423760284195 139.73834014012274 39.446 35.67423067957792 139.73831637563492 39.446 35.67423067957792 139.73831637563492 41.727 35.67423760284195 139.73834014012274 41.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8495a5d6-bd75-4658-9eba-da94d11055b2_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae399f4e-c702-4b78-987a-716e8c1d1edb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67418568190369 139.73840632769313 39.446 35.674187895985845 139.73841358280836 39.446 35.67416599155659 139.7384236502678 39.446 35.6741425766502 139.73834712381992 39.446 35.67416148960865 139.73833844073494 39.446 35.67416002560406 139.7383336481672 39.446 35.67416428754926 139.73833168783648 39.446 35.674166549172796 139.73833064675893 39.446 35.6741701187943 139.73834230792986 39.446 35.67415081839393 139.73835117926916 39.446 35.67416991360407 139.7384135820066 39.446 35.67418568190369 139.73840632769313 39.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b15587a-9d03-4579-b393-8fd2727ecd91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b15587a-9d03-4579-b393-8fd2727ecd91_0">
											<gml:posList>35.67416002560406 139.7383336481672 39.446 35.67416148960865 139.73833844073494 39.446 35.67416148960865 139.73833844073494 40.877 35.67416002560406 139.7383336481672 40.877 35.67416002560406 139.7383336481672 39.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2cac2937-cdd8-43cc-91d5-855f7bd03723">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2cac2937-cdd8-43cc-91d5-855f7bd03723_0">
											<gml:posList>35.67416002560406 139.7383336481672 40.877 35.67416294499358 139.73833230804718 40.877 35.67416428754926 139.73833168783648 39.446 35.67416002560406 139.7383336481672 39.446 35.67416002560406 139.7383336481672 40.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1ded45a-5e61-40a2-8985-365661c64271">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1ded45a-5e61-40a2-8985-365661c64271_0">
											<gml:posList>35.67416294499358 139.73833230804718 40.877 35.674166549172796 139.73833064675893 40.877 35.674166549172796 139.73833064675893 39.446 35.67416428754926 139.73833168783648 39.446 35.67416294499358 139.73833230804718 40.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b30789c-1d80-4b5c-b1cb-d372c95b931a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b30789c-1d80-4b5c-b1cb-d372c95b931a_0">
											<gml:posList>35.6741701187943 139.73834230792986 39.446 35.674166549172796 139.73833064675893 39.446 35.674166549172796 139.73833064675893 40.877 35.6741701187943 139.73834230792986 40.877 35.6741701187943 139.73834230792986 39.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9556426e-f692-4bab-b3e9-142ccdabe662">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9556426e-f692-4bab-b3e9-142ccdabe662_0">
											<gml:posList>35.67416148960865 139.73833844073494 40.877 35.67416148960865 139.73833844073494 39.446 35.6741425766502 139.73834712381992 39.446 35.6741425766502 139.73834712381992 40.877 35.67416148960865 139.73833844073494 40.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa8b39b5-78aa-4f48-87cf-1c4077e6e5f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa8b39b5-78aa-4f48-87cf-1c4077e6e5f1_0">
											<gml:posList>35.6741425766502 139.73834712381992 40.877 35.6741425766502 139.73834712381992 39.446 35.67416599155659 139.7384236502678 39.446 35.67416599155659 139.7384236502678 40.877 35.6741425766502 139.73834712381992 40.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-677d89ba-2706-4854-a979-5897dc67554d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-677d89ba-2706-4854-a979-5897dc67554d_0">
											<gml:posList>35.67416991360407 139.7384135820066 39.446 35.67415081839393 139.73835117926916 39.446 35.67415081839393 139.73835117926916 40.877 35.67416991360407 139.7384135820066 40.877 35.67416991360407 139.7384135820066 39.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ea8ad9a-56f9-4061-80b1-9f31015b1c02">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ea8ad9a-56f9-4061-80b1-9f31015b1c02_0">
											<gml:posList>35.67415081839393 139.73835117926916 39.446 35.6741701187943 139.73834230792986 39.446 35.6741701187943 139.73834230792986 40.877 35.67415081839393 139.73835117926916 40.877 35.67415081839393 139.73835117926916 39.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9db558e-fa50-447c-be86-dca4aa1bebc5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9db558e-fa50-447c-be86-dca4aa1bebc5_0">
											<gml:posList>35.67416599155659 139.7384236502678 40.877 35.674187895985845 139.73841358280836 40.877 35.67418568190369 139.73840632769313 40.877 35.67416991360407 139.7384135820066 40.877 35.67415081839393 139.73835117926916 40.877 35.6741701187943 139.73834230792986 40.877 35.674166549172796 139.73833064675893 40.877 35.67416294499358 139.73833230804718 40.877 35.67416002560406 139.7383336481672 40.877 35.67416148960865 139.73833844073494 40.877 35.6741425766502 139.73834712381992 40.877 35.67416599155659 139.7384236502678 40.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e2f1eec-4e99-4185-8c40-bb7452dfd0ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e2f1eec-4e99-4185-8c40-bb7452dfd0ee_0">
											<gml:posList>35.67416599155659 139.7384236502678 40.877 35.67416599155659 139.7384236502678 39.446 35.674187895985845 139.73841358280836 39.446 35.674187895985845 139.73841358280836 40.877 35.67416599155659 139.7384236502678 40.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d70aadf-7193-4204-a9b2-01066bef0340">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d70aadf-7193-4204-a9b2-01066bef0340_0">
											<gml:posList>35.67418568190369 139.73840632769313 40.877 35.67418568190369 139.73840632769313 39.446 35.67416991360407 139.7384135820066 39.446 35.67416991360407 139.7384135820066 40.877 35.67418568190369 139.73840632769313 40.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f8ecea9-3583-49e8-80aa-f13a11093f32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f8ecea9-3583-49e8-80aa-f13a11093f32_0">
											<gml:posList>35.674187895985845 139.73841358280836 40.877 35.674187895985845 139.73841358280836 39.446 35.67418568190369 139.73840632769313 39.446 35.67418568190369 139.73840632769313 40.877 35.674187895985845 139.73841358280836 40.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6f344c65-6a3c-4d65-83be-729c84a18b1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f344c65-6a3c-4d65-83be-729c84a18b1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f344c65-6a3c-4d65-83be-729c84a18b1a">
											<gml:posList>35.67429853936186 139.73839059597483 7.97 35.67416797772031 139.7384505136881 7.97 35.674113032646986 139.7382709581815 7.97 35.67424359411272 139.73821092974947 7.97 35.67429853936186 139.73839059597483 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1cf7649-b9e9-41f6-98ed-28bbdacf9a47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1cf7649-b9e9-41f6-98ed-28bbdacf9a47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1cf7649-b9e9-41f6-98ed-28bbdacf9a47">
											<gml:posList>35.67424139042973 139.7382168534444 38.822 35.67424359411272 139.73821092974947 38.822 35.674190549578846 139.73823531770915 38.822 35.67419196817851 139.73823967950617 38.822 35.67424139042973 139.7382168534444 38.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d623f9d-b0b5-4a1b-90c5-8a4ef9ed650f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d623f9d-b0b5-4a1b-90c5-8a4ef9ed650f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d623f9d-b0b5-4a1b-90c5-8a4ef9ed650f">
											<gml:posList>35.67424139042973 139.7382168534444 38.822 35.67426028693659 139.73827865992897 38.822 35.67426381002642 139.73827704291958 38.822 35.67424359411272 139.73821092974947 38.822 35.67424139042973 139.7382168534444 38.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-484d9c5a-4355-40c2-bac7-668f82962d52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-484d9c5a-4355-40c2-bac7-668f82962d52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-484d9c5a-4355-40c2-bac7-668f82962d52">
											<gml:posList>35.67418733873134 139.73824424731936 39.972 35.674190549578846 139.73823531770915 39.972 35.6741502728527 139.73825383570173 39.972 35.67415227003917 139.7382603619794 39.972 35.67418733873134 139.73824424731936 39.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b82fbc0-010e-45e6-b71a-9f87f4110d37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b82fbc0-010e-45e6-b71a-9f87f4110d37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b82fbc0-010e-45e6-b71a-9f87f4110d37">
											<gml:posList>35.67424139042973 139.7382168534444 38.555 35.67419196817851 139.73823967950617 38.555 35.674211891766596 139.73830088821398 38.555 35.67426028693659 139.73827865992897 38.555 35.67424139042973 139.7382168534444 38.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df21033e-81ac-4ead-94a3-6454a47abd56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df21033e-81ac-4ead-94a3-6454a47abd56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df21033e-81ac-4ead-94a3-6454a47abd56">
											<gml:posList>35.674135643307004 139.73834485639898 48.526 35.6741387374369 139.73833650136928 48.526 35.67411985002553 139.73827476123458 48.526 35.674113032646986 139.7382709581815 48.526 35.674135643307004 139.73834485639898 48.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4eb5350e-9f8e-4476-91e0-205db4536fa9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4eb5350e-9f8e-4476-91e0-205db4536fa9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4eb5350e-9f8e-4476-91e0-205db4536fa9">
											<gml:posList>35.674113032646986 139.7382709581815 48.526 35.67411985002553 139.73827476123458 48.526 35.67414716971484 139.7382621907465 48.526 35.6741502728527 139.73825383570173 48.526 35.674113032646986 139.7382709581815 48.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc22a34a-b2a9-4b76-b931-8c74ff5e337e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc22a34a-b2a9-4b76-b931-8c74ff5e337e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc22a34a-b2a9-4b76-b931-8c74ff5e337e">
											<gml:posList>35.674166057132595 139.73832393089927 48.231 35.67414716971484 139.7382621907465 48.231 35.67411985002553 139.73827476123458 48.231 35.6741387374369 139.73833650136928 48.231 35.674166057132595 139.73832393089927 48.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-769f2bd0-0630-4cec-a722-a9eb8b8c0a37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-769f2bd0-0630-4cec-a722-a9eb8b8c0a37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-769f2bd0-0630-4cec-a722-a9eb8b8c0a37">
											<gml:posList>35.674135643307004 139.73834485639898 39.972 35.67416797772031 139.7384505136881 39.972 35.674171314757764 139.73844156184538 39.972 35.67414071619928 139.73834253056492 39.972 35.674135643307004 139.73834485639898 39.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-55ab1da9-a3e1-4d66-b997-03e94aaa5d79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55ab1da9-a3e1-4d66-b997-03e94aaa5d79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55ab1da9-a3e1-4d66-b997-03e94aaa5d79">
											<gml:posList>35.67417288352312 139.73832773394864 48.526 35.674166057132595 139.73832393089927 48.526 35.6741387374369 139.73833650136928 48.526 35.674135643307004 139.73834485639898 48.526 35.67417288352312 139.73832773394864 48.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-78988d7e-d416-46d4-8ea6-ada4adf1ff1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78988d7e-d416-46d4-8ea6-ada4adf1ff1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78988d7e-d416-46d4-8ea6-ada4adf1ff1b">
											<gml:posList>35.6741502728527 139.73825383570173 48.526 35.67414716971484 139.7382621907465 48.526 35.674166057132595 139.73832393089927 48.526 35.67417288352312 139.73832773394864 48.526 35.6741502728527 139.73825383570173 48.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fbd002e9-0190-4fef-a691-dadeec1d889a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbd002e9-0190-4fef-a691-dadeec1d889a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbd002e9-0190-4fef-a691-dadeec1d889a">
											<gml:posList>35.674211891766596 139.73830088821398 39.972 35.674190549578846 139.73823531770915 39.972 35.67418733873134 139.73824424731936 39.972 35.67420867190054 139.73830981783465 39.972 35.674211891766596 139.73830088821398 39.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93dbc305-6766-4fee-9cc3-9da44d068374">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93dbc305-6766-4fee-9cc3-9da44d068374">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93dbc305-6766-4fee-9cc3-9da44d068374">
											<gml:posList>35.674171314757764 139.73844156184538 39.446 35.6742912260237 139.73838652836773 39.446 35.67426048203243 139.73828601686233 39.446 35.67420867190054 139.73830981783465 39.446 35.67418733873134 139.73824424731936 39.446 35.67415227003917 139.7382603619794 39.446 35.67417288352312 139.73832773394864 39.446 35.67414071619928 139.73834253056492 39.446 35.674171314757764 139.73844156184538 39.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6234fa3b-8119-427b-92c5-f9dab9626b5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6234fa3b-8119-427b-92c5-f9dab9626b5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6234fa3b-8119-427b-92c5-f9dab9626b5e">
											<gml:posList>35.67429853936186 139.73839059597483 39.972 35.6742912260237 139.73838652836773 39.972 35.674171314757764 139.73844156184538 39.972 35.67416797772031 139.7384505136881 39.972 35.67429853936186 139.73839059597483 39.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b87a65f-1b3d-4183-983d-c791287838cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b87a65f-1b3d-4183-983d-c791287838cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b87a65f-1b3d-4183-983d-c791287838cc">
											<gml:posList>35.674211891766596 139.73830088821398 39.972 35.67420867190054 139.73830981783465 39.972 35.67426048203243 139.73828601686233 39.972 35.67426381002642 139.73827704291958 39.972 35.674211891766596 139.73830088821398 39.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-01f425b6-9682-4901-8030-b9b569e00ad7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01f425b6-9682-4901-8030-b9b569e00ad7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01f425b6-9682-4901-8030-b9b569e00ad7">
											<gml:posList>35.67426381002642 139.73827704291958 39.972 35.67426048203243 139.73828601686233 39.972 35.6742912260237 139.73838652836773 39.972 35.67429853936186 139.73839059597483 39.972 35.67426381002642 139.73827704291958 39.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc13a5cf-2180-4cf0-a56d-188e797db623">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc13a5cf-2180-4cf0-a56d-188e797db623">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc13a5cf-2180-4cf0-a56d-188e797db623">
											<gml:posList>35.67414716971484 139.7382621907465 48.526 35.67414716971484 139.7382621907465 48.231 35.674166057132595 139.73832393089927 48.231 35.674166057132595 139.73832393089927 48.526 35.67414716971484 139.7382621907465 48.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d88998ad-0d23-4f94-8b2d-43f1934e3b2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d88998ad-0d23-4f94-8b2d-43f1934e3b2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d88998ad-0d23-4f94-8b2d-43f1934e3b2d">
											<gml:posList>35.67411985002553 139.73827476123458 48.526 35.67411985002553 139.73827476123458 48.231 35.67414716971484 139.7382621907465 48.231 35.67414716971484 139.7382621907465 48.526 35.67411985002553 139.73827476123458 48.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fa22004-c6fb-4cd7-9fb2-1b26df85129f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fa22004-c6fb-4cd7-9fb2-1b26df85129f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fa22004-c6fb-4cd7-9fb2-1b26df85129f">
											<gml:posList>35.6741387374369 139.73833650136928 48.526 35.6741387374369 139.73833650136928 48.231 35.67411985002553 139.73827476123458 48.231 35.67411985002553 139.73827476123458 48.526 35.6741387374369 139.73833650136928 48.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4535f6b9-c564-4996-9e2b-dbf0b4f62abf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4535f6b9-c564-4996-9e2b-dbf0b4f62abf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4535f6b9-c564-4996-9e2b-dbf0b4f62abf">
											<gml:posList>35.674166057132595 139.73832393089927 48.526 35.674166057132595 139.73832393089927 48.231 35.6741387374369 139.73833650136928 48.231 35.6741387374369 139.73833650136928 48.526 35.674166057132595 139.73832393089927 48.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-544702f5-e350-4189-8795-23925059f1aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-544702f5-e350-4189-8795-23925059f1aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-544702f5-e350-4189-8795-23925059f1aa">
											<gml:posList>35.67417288352312 139.73832773394864 39.446 35.67417288352312 139.73832773394864 48.526 35.674135643307004 139.73834485639898 48.526 35.674135643307004 139.73834485639898 39.972 35.67414071619928 139.73834253056492 39.972 35.67414071619928 139.73834253056492 39.446 35.67417288352312 139.73832773394864 39.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bce6622-9904-454b-978a-34e28bcd8053">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bce6622-9904-454b-978a-34e28bcd8053">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bce6622-9904-454b-978a-34e28bcd8053">
											<gml:posList>35.674113032646986 139.7382709581815 7.97 35.67416797772031 139.7384505136881 7.97 35.67416797772031 139.7384505136881 39.972 35.674135643307004 139.73834485639898 39.972 35.674135643307004 139.73834485639898 48.526 35.674113032646986 139.7382709581815 48.526 35.674113032646986 139.7382709581815 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6da3ab5-1122-48f9-9ca3-dc80707d3fa0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6da3ab5-1122-48f9-9ca3-dc80707d3fa0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6da3ab5-1122-48f9-9ca3-dc80707d3fa0">
											<gml:posList>35.674171314757764 139.73844156184538 39.972 35.674171314757764 139.73844156184538 39.446 35.67414071619928 139.73834253056492 39.446 35.67414071619928 139.73834253056492 39.972 35.674171314757764 139.73844156184538 39.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5b03fe7-faa3-47df-96a3-e01c28b3c725">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5b03fe7-faa3-47df-96a3-e01c28b3c725">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5b03fe7-faa3-47df-96a3-e01c28b3c725">
											<gml:posList>35.67419196817851 139.73823967950617 38.822 35.67419196817851 139.73823967950617 38.555 35.67424139042973 139.7382168534444 38.555 35.67424139042973 139.7382168534444 38.822 35.67419196817851 139.73823967950617 38.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13d3887d-e6b8-4039-b7be-ae99bd7bf018">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13d3887d-e6b8-4039-b7be-ae99bd7bf018">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13d3887d-e6b8-4039-b7be-ae99bd7bf018">
											<gml:posList>35.674190549578846 139.73823531770915 38.822 35.67424359411272 139.73821092974947 38.822 35.67424359411272 139.73821092974947 7.97 35.674113032646986 139.7382709581815 7.97 35.674113032646986 139.7382709581815 48.526 35.6741502728527 139.73825383570173 48.526 35.6741502728527 139.73825383570173 39.972 35.674190549578846 139.73823531770915 39.972 35.674190549578846 139.73823531770915 38.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75541011-72d7-4a67-be0e-202c3d8552c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75541011-72d7-4a67-be0e-202c3d8552c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75541011-72d7-4a67-be0e-202c3d8552c1">
											<gml:posList>35.67424139042973 139.7382168534444 38.822 35.67424139042973 139.7382168534444 38.555 35.67426028693659 139.73827865992897 38.555 35.67426028693659 139.73827865992897 38.822 35.67424139042973 139.7382168534444 38.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48cd21fb-ac6e-4efa-ba63-13d16c227828">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48cd21fb-ac6e-4efa-ba63-13d16c227828">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48cd21fb-ac6e-4efa-ba63-13d16c227828">
											<gml:posList>35.67415227003917 139.7382603619794 39.972 35.67415227003917 139.7382603619794 39.446 35.67418733873134 139.73824424731936 39.446 35.67418733873134 139.73824424731936 39.972 35.67415227003917 139.7382603619794 39.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63414717-49bc-47b1-b493-9c01daf5d7a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63414717-49bc-47b1-b493-9c01daf5d7a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63414717-49bc-47b1-b493-9c01daf5d7a4">
											<gml:posList>35.67419196817851 139.73823967950617 38.822 35.674190549578846 139.73823531770915 38.822 35.674190549578846 139.73823531770915 39.972 35.674211891766596 139.73830088821398 39.972 35.674211891766596 139.73830088821398 38.555 35.67419196817851 139.73823967950617 38.555 35.67419196817851 139.73823967950617 38.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a468e7d5-189c-4ccc-91bd-fd0c07465fae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a468e7d5-189c-4ccc-91bd-fd0c07465fae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a468e7d5-189c-4ccc-91bd-fd0c07465fae">
											<gml:posList>35.67418733873134 139.73824424731936 39.972 35.67418733873134 139.73824424731936 39.446 35.67420867190054 139.73830981783465 39.446 35.67420867190054 139.73830981783465 39.972 35.67418733873134 139.73824424731936 39.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-629f0376-67af-4bf6-af9a-abd1c3fe4046">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-629f0376-67af-4bf6-af9a-abd1c3fe4046">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-629f0376-67af-4bf6-af9a-abd1c3fe4046">
											<gml:posList>35.67426028693659 139.73827865992897 38.822 35.67426028693659 139.73827865992897 38.555 35.674211891766596 139.73830088821398 38.555 35.674211891766596 139.73830088821398 39.972 35.67426381002642 139.73827704291958 39.972 35.67426381002642 139.73827704291958 38.822 35.67426028693659 139.73827865992897 38.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-efb2f785-a22c-4ff2-8cbd-fcfdf607c722">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efb2f785-a22c-4ff2-8cbd-fcfdf607c722">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efb2f785-a22c-4ff2-8cbd-fcfdf607c722">
											<gml:posList>35.67415227003917 139.7382603619794 39.972 35.6741502728527 139.73825383570173 39.972 35.6741502728527 139.73825383570173 48.526 35.67417288352312 139.73832773394864 48.526 35.67417288352312 139.73832773394864 39.446 35.67415227003917 139.7382603619794 39.446 35.67415227003917 139.7382603619794 39.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56d5184e-4277-4bd5-99e1-4a7df8ca732c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56d5184e-4277-4bd5-99e1-4a7df8ca732c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56d5184e-4277-4bd5-99e1-4a7df8ca732c">
											<gml:posList>35.67420867190054 139.73830981783465 39.972 35.67420867190054 139.73830981783465 39.446 35.67426048203243 139.73828601686233 39.446 35.67426048203243 139.73828601686233 39.972 35.67420867190054 139.73830981783465 39.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0c5cd5f-1ea5-45fd-9e0c-3e2cc3e8d2ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0c5cd5f-1ea5-45fd-9e0c-3e2cc3e8d2ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0c5cd5f-1ea5-45fd-9e0c-3e2cc3e8d2ea">
											<gml:posList>35.67424359411272 139.73821092974947 7.97 35.67424359411272 139.73821092974947 38.822 35.67426381002642 139.73827704291958 38.822 35.67426381002642 139.73827704291958 39.972 35.67429853936186 139.73839059597483 39.972 35.67429853936186 139.73839059597483 7.97 35.67424359411272 139.73821092974947 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff69fc67-951f-45d2-983e-da5f2103a677">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff69fc67-951f-45d2-983e-da5f2103a677">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff69fc67-951f-45d2-983e-da5f2103a677">
											<gml:posList>35.67426048203243 139.73828601686233 39.972 35.67426048203243 139.73828601686233 39.446 35.6742912260237 139.73838652836773 39.446 35.6742912260237 139.73838652836773 39.972 35.67426048203243 139.73828601686233 39.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4d22d6f-1c95-4740-88a0-e03b68d14231">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4d22d6f-1c95-4740-88a0-e03b68d14231">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4d22d6f-1c95-4740-88a0-e03b68d14231">
											<gml:posList>35.6742912260237 139.73838652836773 39.972 35.6742912260237 139.73838652836773 39.446 35.674171314757764 139.73844156184538 39.446 35.674171314757764 139.73844156184538 39.972 35.6742912260237 139.73838652836773 39.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-350d4060-0e67-40f3-a8cf-7b6d6cff047e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-350d4060-0e67-40f3-a8cf-7b6d6cff047e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-350d4060-0e67-40f3-a8cf-7b6d6cff047e">
											<gml:posList>35.67416797772031 139.7384505136881 7.97 35.67429853936186 139.73839059597483 7.97 35.67429853936186 139.73839059597483 39.972 35.67416797772031 139.7384505136881 39.972 35.67416797772031 139.7384505136881 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-234</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">268.60305</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.41</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>