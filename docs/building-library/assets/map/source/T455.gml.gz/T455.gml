<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_85569249-8ea9-4048-8573-e69f675d009b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>6</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001006</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">18.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670360797389236 139.73745159949755 0 35.67034128220772 139.73746234874753 0 35.670336431319704 139.73744914322916 0 35.67025724439155 139.73749279326134 0 35.67033438870703 139.73770291123836 0 35.67043385667212 139.73764800311739 0 35.670439728230335 139.73766390273516 0 35.67049549885407 139.73763323800642 0 35.67041248282847 139.73740722007906 0 35.670355946491235 139.73743838293038 0 35.670360797389236 139.73745159949755 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670360797389236 139.73745159949755 15.216 35.670355946491235 139.73743838293038 15.216 35.67041248282847 139.73740722007906 15.216 35.67049549885407 139.73763323800642 15.216 35.670439728230335 139.73766390273516 15.216 35.67043385667212 139.73764800311739 15.216 35.67033438870703 139.73770291123836 15.216 35.67025724439155 139.73749279326134 15.216 35.670336431319704 139.73744914322916 15.216 35.67034128220772 139.73746234874753 15.216 35.670360797389236 139.73745159949755 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670360797389236 139.73745159949755 15.216 35.67034128220772 139.73746234874753 15.216 35.67034128220772 139.73746234874753 34.03 35.670360797389236 139.73745159949755 34.03 35.670360797389236 139.73745159949755 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67034128220772 139.73746234874753 15.216 35.670336431319704 139.73744914322916 15.216 35.670336431319704 139.73744914322916 34.03 35.67034128220772 139.73746234874753 34.03 35.67034128220772 139.73746234874753 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670336431319704 139.73744914322916 15.216 35.67025724439155 139.73749279326134 15.216 35.67025724439155 139.73749279326134 34.03 35.670336431319704 139.73744914322916 34.03 35.670336431319704 139.73744914322916 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67025724439155 139.73749279326134 15.216 35.67033438870703 139.73770291123836 15.216 35.67033438870703 139.73770291123836 34.03 35.67025724439155 139.73749279326134 34.03 35.67025724439155 139.73749279326134 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033438870703 139.73770291123836 15.216 35.67043385667212 139.73764800311739 15.216 35.67043385667212 139.73764800311739 34.03 35.67033438870703 139.73770291123836 34.03 35.67033438870703 139.73770291123836 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67043385667212 139.73764800311739 15.216 35.670439728230335 139.73766390273516 15.216 35.670439728230335 139.73766390273516 34.03 35.67043385667212 139.73764800311739 34.03 35.67043385667212 139.73764800311739 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670439728230335 139.73766390273516 15.216 35.67049549885407 139.73763323800642 15.216 35.67049549885407 139.73763323800642 34.03 35.670439728230335 139.73766390273516 34.03 35.670439728230335 139.73766390273516 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049549885407 139.73763323800642 15.216 35.67041248282847 139.73740722007906 15.216 35.67041248282847 139.73740722007906 34.03 35.67049549885407 139.73763323800642 34.03 35.67049549885407 139.73763323800642 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67041248282847 139.73740722007906 15.216 35.670355946491235 139.73743838293038 15.216 35.670355946491235 139.73743838293038 34.03 35.67041248282847 139.73740722007906 34.03 35.67041248282847 139.73740722007906 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670355946491235 139.73743838293038 15.216 35.670360797389236 139.73745159949755 15.216 35.670360797389236 139.73745159949755 34.03 35.670355946491235 139.73743838293038 34.03 35.670355946491235 139.73743838293038 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670360797389236 139.73745159949755 34.03 35.67034128220772 139.73746234874753 34.03 35.670336431319704 139.73744914322916 34.03 35.67025724439155 139.73749279326134 34.03 35.67033438870703 139.73770291123836 34.03 35.67043385667212 139.73764800311739 34.03 35.670439728230335 139.73766390273516 34.03 35.67049549885407 139.73763323800642 34.03 35.67041248282847 139.73740722007906 34.03 35.670355946491235 139.73743838293038 34.03 35.670360797389236 139.73745159949755 34.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-04e17b15-bf23-464e-a627-74d5f591922b"/>
							<gml:surfaceMember xlink:href="#poly-dbb42e55-130f-47ab-9f41-09024b160abd"/>
							<gml:surfaceMember xlink:href="#poly-1b5f282a-f98c-4915-b4b2-2900174d98c6"/>
							<gml:surfaceMember xlink:href="#poly-feab50be-942d-464b-8d6d-3bbfa6cbbdc2"/>
							<gml:surfaceMember xlink:href="#poly-42baf0c2-45f3-4519-b7d5-b83ed20ccfb7"/>
							<gml:surfaceMember xlink:href="#poly-4dd6b0fe-565e-4755-8f4b-1f571eca847c"/>
							<gml:surfaceMember xlink:href="#poly-8a12e215-1613-4b96-bd2e-5418cb7c76ff"/>
							<gml:surfaceMember xlink:href="#poly-b6d5d4bb-0220-44d8-a25d-7580c281fcda"/>
							<gml:surfaceMember xlink:href="#poly-784ae9b8-56b8-4ab2-a65f-d50f4efe5582"/>
							<gml:surfaceMember xlink:href="#poly-e73fe792-0a53-49cc-a80c-20ce6185c590"/>
							<gml:surfaceMember xlink:href="#poly-fe461a0e-5c17-49f6-bdeb-878a52ee0c4e"/>
							<gml:surfaceMember xlink:href="#poly-cd6b112e-9003-4625-8055-25247c311a0e"/>
							<gml:surfaceMember xlink:href="#poly-417f2bb8-5d48-4d78-8e6c-c5ed7b3b4ff0"/>
							<gml:surfaceMember xlink:href="#poly-f627df04-8ced-417a-ac0d-223952f2474b"/>
							<gml:surfaceMember xlink:href="#poly-bdfbd8dc-f1c6-4601-83b1-f91430d9bec5"/>
							<gml:surfaceMember xlink:href="#poly-d4d66f9a-b2df-44c7-96ba-614a1bb13472"/>
							<gml:surfaceMember xlink:href="#poly-2ff19b28-a203-4498-8280-7b00b8bee816"/>
							<gml:surfaceMember xlink:href="#poly-64cffccb-d808-4aef-afc3-bb0803591ad6"/>
							<gml:surfaceMember xlink:href="#poly-8071e62a-53e7-43af-b53a-b4dff3146f5a"/>
							<gml:surfaceMember xlink:href="#poly-ce93d00d-ced4-4be7-83be-59b03da5737d"/>
							<gml:surfaceMember xlink:href="#poly-b920fc7a-c20a-428e-b56d-df90bd56ef4e"/>
							<gml:surfaceMember xlink:href="#poly-a55c6f4b-8afe-4a3f-a9a4-440829d80098"/>
							<gml:surfaceMember xlink:href="#poly-44c01be7-dc7d-4e56-babc-6e5afc19b958"/>
							<gml:surfaceMember xlink:href="#poly-cdb69412-ab7b-444f-b759-6a597aad0cc3"/>
							<gml:surfaceMember xlink:href="#poly-8e8f0154-cf70-4af2-9e94-4b298e2cecd1"/>
							<gml:surfaceMember xlink:href="#poly-c8d8ec0b-b1c8-4ecb-90a2-110b89383048"/>
							<gml:surfaceMember xlink:href="#poly-a66e9e6d-837a-42ba-a27e-11f9148f0ee0"/>
							<gml:surfaceMember xlink:href="#poly-cb7dcf7c-930b-4c75-bab8-84aa80322c83"/>
							<gml:surfaceMember xlink:href="#poly-5a5e0bd9-e0dc-4325-b965-f8d7e2f69924"/>
							<gml:surfaceMember xlink:href="#poly-9c72d9fd-1192-4832-8305-5c365a0638d7"/>
							<gml:surfaceMember xlink:href="#poly-594678fc-f175-4a29-a7b7-4c2ae26419e3"/>
							<gml:surfaceMember xlink:href="#poly-8da1203e-ea1b-494e-8d55-d4bb8cb5007f"/>
							<gml:surfaceMember xlink:href="#poly-380ee720-e861-42e9-83f6-78e25a52d25f"/>
							<gml:surfaceMember xlink:href="#poly-54f47d1c-bd4c-4c98-955c-1b0633e4cdc8"/>
							<gml:surfaceMember xlink:href="#poly-2f38add0-d022-4808-85bf-83220010ce72"/>
							<gml:surfaceMember xlink:href="#poly-1b855be6-7c65-48da-9626-6a21063f7d3e"/>
							<gml:surfaceMember xlink:href="#poly-2956f2dc-ee3a-4ee9-a933-3cc3e2bac203"/>
							<gml:surfaceMember xlink:href="#poly-ec1446ee-76ac-4a0f-8ad0-a1cce16e17c0"/>
							<gml:surfaceMember xlink:href="#poly-ff8a9977-34b5-4e77-a104-ccf81ffeea85"/>
							<gml:surfaceMember xlink:href="#poly-a8665445-4edb-404b-980a-98ba00be3a32"/>
							<gml:surfaceMember xlink:href="#poly-fd8c2bbd-95d3-4aef-8813-46402a713a65"/>
							<gml:surfaceMember xlink:href="#poly-849a734b-a8b2-406e-8d5c-887be2a3bfc8"/>
							<gml:surfaceMember xlink:href="#poly-e4afb71f-7669-432c-a88d-294fcae6b45e"/>
							<gml:surfaceMember xlink:href="#poly-a6c40a3e-84ff-4265-aa16-72016c129574"/>
							<gml:surfaceMember xlink:href="#poly-b33764dd-1b46-4029-a32f-c4a3e83ff604"/>
							<gml:surfaceMember xlink:href="#poly-33c675a8-4e5d-41c3-860b-66fd9e81328f"/>
							<gml:surfaceMember xlink:href="#poly-80f19982-f25f-480e-8bd7-5369d05ec214"/>
							<gml:surfaceMember xlink:href="#poly-7e1a164b-e260-4e50-a37a-3cc15ea1e65d"/>
							<gml:surfaceMember xlink:href="#poly-ee750af3-f059-464a-b2c8-13c9e040cf08"/>
							<gml:surfaceMember xlink:href="#poly-4de6e450-3371-49c5-98d5-60fa0f5bf76f"/>
							<gml:surfaceMember xlink:href="#poly-da98db9d-09d4-4785-a598-27982b89a906"/>
							<gml:surfaceMember xlink:href="#poly-76ea50b3-3d7e-4282-82af-12f238da359f"/>
							<gml:surfaceMember xlink:href="#poly-82900fec-61b6-47bd-a90e-a74d4a06801e"/>
							<gml:surfaceMember xlink:href="#poly-e58fc453-432c-4f54-bbca-ccf1c5f05e1e"/>
							<gml:surfaceMember xlink:href="#poly-8e1c31d1-20ac-4394-96c1-8610ee91f3c4"/>
							<gml:surfaceMember xlink:href="#poly-21b789a9-d5cf-43f7-a4f5-e965c565d30a"/>
							<gml:surfaceMember xlink:href="#poly-febc0a31-21da-4e7d-876b-e3a0d5071840"/>
							<gml:surfaceMember xlink:href="#poly-df39361b-0cd8-4f1b-90fe-9284c47413c2"/>
							<gml:surfaceMember xlink:href="#poly-5776b9ea-661e-47e3-a51f-78692e7830a5"/>
							<gml:surfaceMember xlink:href="#poly-dd53ac24-4fe5-4770-85a1-bede16c8de45"/>
							<gml:surfaceMember xlink:href="#poly-753b9959-1ec4-4cf7-8126-a0bf6dfa3a14"/>
							<gml:surfaceMember xlink:href="#poly-d4295135-24d0-4607-bc06-4c02fda39df0"/>
							<gml:surfaceMember xlink:href="#poly-a34abb9c-4247-479f-85c2-211e0dd06a08"/>
							<gml:surfaceMember xlink:href="#poly-2b582a19-e0a4-4bde-84a1-3a795381df0f"/>
							<gml:surfaceMember xlink:href="#poly-79d0d9d3-4931-4fe3-9ae0-77363d68f201"/>
							<gml:surfaceMember xlink:href="#poly-db6fb750-6f6e-458e-8529-92e760e74b2e"/>
							<gml:surfaceMember xlink:href="#poly-c793b444-821f-41e1-96bd-afd7be69a7a2"/>
							<gml:surfaceMember xlink:href="#poly-25b5f4a2-6620-4233-87a7-092cc798c5a5"/>
							<gml:surfaceMember xlink:href="#poly-78231d9c-2662-4f09-9dd4-ab0728a65d45"/>
							<gml:surfaceMember xlink:href="#poly-19130c6a-ecac-4058-97ce-e4322e787127"/>
							<gml:surfaceMember xlink:href="#poly-91fd5d67-26bc-406f-a7ff-f2be5a6bb5ab"/>
							<gml:surfaceMember xlink:href="#poly-0c0e4be9-9053-4479-8ea7-bb46da90303e"/>
							<gml:surfaceMember xlink:href="#poly-f3e8b402-4e1e-4f4c-880c-dcf8447016d2"/>
							<gml:surfaceMember xlink:href="#poly-9601eada-7c60-423c-bfd1-ab227d0fa722"/>
							<gml:surfaceMember xlink:href="#poly-b1e44f7b-47c3-4ecb-a9a3-f422b7bf8a98"/>
							<gml:surfaceMember xlink:href="#poly-3f603560-3325-4a6d-9cf3-b41803cf392d"/>
							<gml:surfaceMember xlink:href="#poly-725e8548-c48c-4f10-8025-225e78522ad4"/>
							<gml:surfaceMember xlink:href="#poly-779935b5-1834-4532-b6ca-b18c6fc9d46f"/>
							<gml:surfaceMember xlink:href="#poly-221cc10f-1f6c-4c81-b8e4-3f354d95f145"/>
							<gml:surfaceMember xlink:href="#poly-50c49dcf-a40b-4806-9a57-3d6b175c71fc"/>
							<gml:surfaceMember xlink:href="#poly-85f52b1b-fae0-48df-94a6-49be8a34bd2d"/>
							<gml:surfaceMember xlink:href="#poly-1c273011-9823-40c1-9d00-a5756d8e9d57"/>
							<gml:surfaceMember xlink:href="#poly-c6461e33-145c-41e9-93f1-885ac4cb5566"/>
							<gml:surfaceMember xlink:href="#poly-834daa01-5ae4-4f3d-93c2-69a544558e85"/>
							<gml:surfaceMember xlink:href="#poly-044a3e1a-747c-487f-bcc7-593cf4eb43a2"/>
							<gml:surfaceMember xlink:href="#poly-c147f3d7-a91a-4aac-ac2c-04a67014d5f4"/>
							<gml:surfaceMember xlink:href="#poly-4f45bf23-c755-4ec9-b50a-41db80601bce"/>
							<gml:surfaceMember xlink:href="#poly-f23de579-be9d-4cd7-9ecc-d1528f44d564"/>
							<gml:surfaceMember xlink:href="#poly-8ebc8881-cacd-4be9-94d2-292777b19d89"/>
							<gml:surfaceMember xlink:href="#poly-0fdbd1c8-54f4-424a-ad19-beb0cadb9263"/>
							<gml:surfaceMember xlink:href="#poly-23d76861-5484-4ee8-80bb-c43e7490155d"/>
							<gml:surfaceMember xlink:href="#poly-f7ff298a-3c61-44ce-9990-9cb1283a3ded"/>
							<gml:surfaceMember xlink:href="#poly-737c07a3-ce3c-4df2-9dd3-00a5a77cbdf8"/>
							<gml:surfaceMember xlink:href="#poly-e2085935-2faa-4549-af4a-0c9c1e8d6e74"/>
							<gml:surfaceMember xlink:href="#poly-4659a123-9084-469f-9d1d-0203db521615"/>
							<gml:surfaceMember xlink:href="#poly-2489d258-a3ff-4de9-af6e-0826b6a6a4cb"/>
							<gml:surfaceMember xlink:href="#poly-3e1015b7-b995-4756-8993-6e2cae9ae872"/>
							<gml:surfaceMember xlink:href="#poly-7059b462-5f5c-4971-8eb8-1d2a21639eaa"/>
							<gml:surfaceMember xlink:href="#poly-28809786-9fd8-485a-a5aa-d8d4fe6a119d"/>
							<gml:surfaceMember xlink:href="#poly-e2a1c1a3-e29b-43a0-b4d8-79cc5c7de9bb"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_85569249-8ea9-4048-8573-e69f675d009b_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-deca8053-dd7f-4e21-b9ea-c37f96727b98">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67032892643262 139.7376802729366 31.602 35.67032156431236 139.73766022172774 31.602 35.6704160588878 139.73760809211294 31.602 35.67042307774894 139.73762720481778 31.602 35.67042383653459 139.73762925851736 31.602 35.67032892643262 139.7376802729366 31.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-379f0e38-653f-48f2-9073-f0accde30e09">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67032892643262 139.7376802729366 31.911 35.67042383653459 139.73762925851736 31.911 35.67042389977112 139.73762943518213 31.911 35.67032904478682 139.73768175299315 31.911 35.67032120392146 139.73766042099027 31.911 35.67032156431236 139.73766022172774 31.911 35.67032892643262 139.7376802729366 31.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc952fe3-7f64-4323-a022-32cc73b89df5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc952fe3-7f64-4323-a022-32cc73b89df5_0">
											<gml:posList>35.67042307774894 139.73762720481778 31.602 35.6704160588878 139.73760809211294 31.602 35.6704160588878 139.73760809211294 33.456 35.67042389977112 139.73762943518213 33.456 35.67042307774894 139.73762720481778 31.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edf49147-2367-4503-92bf-221650ca9451">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edf49147-2367-4503-92bf-221650ca9451_0">
											<gml:posList>35.67042307774894 139.73762720481778 31.602 35.67042389977112 139.73762943518213 33.456 35.67042389977112 139.73762943518213 31.911 35.67042383653459 139.73762925851736 31.911 35.67042383653459 139.73762925851736 31.602 35.67042307774894 139.73762720481778 31.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bba7321c-26ff-48d3-9a7f-6b9e9d3cfca9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bba7321c-26ff-48d3-9a7f-6b9e9d3cfca9_0">
											<gml:posList>35.67032156431236 139.73766022172774 31.911 35.67038574098117 139.73762481920872 33.456 35.6704160588878 139.73760809211294 33.456 35.6704160588878 139.73760809211294 31.602 35.67032156431236 139.73766022172774 31.602 35.67032156431236 139.73766022172774 31.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf4aa95f-1683-4723-b361-f15fed970041">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf4aa95f-1683-4723-b361-f15fed970041_0">
											<gml:posList>35.67032156431236 139.73766022172774 31.911 35.67032120392146 139.73766042099027 31.911 35.67032120392146 139.73766042099027 31.959 35.67038437149246 139.73762557198913 33.456 35.67038574098117 139.73762481920872 33.456 35.67032156431236 139.73766022172774 31.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ce25425-9dda-40de-b2e8-066b471eafb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ce25425-9dda-40de-b2e8-066b471eafb1_0">
											<gml:posList>35.67038437149246 139.73762557198913 33.456 35.67032120392146 139.73766042099027 31.959 35.67032120392146 139.73766042099027 33.456 35.67038437149246 139.73762557198913 33.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3060773-a036-454d-bbe4-9a81905de994">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3060773-a036-454d-bbe4-9a81905de994_0">
											<gml:posList>35.67032904478682 139.73768175299315 33.456 35.67042389977112 139.73762943518213 33.456 35.6704160588878 139.73760809211294 33.456 35.67038574098117 139.73762481920872 33.456 35.67038437149246 139.73762557198913 33.456 35.67032120392146 139.73766042099027 33.456 35.67032904478682 139.73768175299315 33.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09d8defc-c0ca-45de-ac04-fe6b4bd5ded8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09d8defc-c0ca-45de-ac04-fe6b4bd5ded8_0">
											<gml:posList>35.67032892643262 139.7376802729366 31.911 35.67032892643262 139.7376802729366 31.602 35.67042383653459 139.73762925851736 31.602 35.67042383653459 139.73762925851736 31.911 35.67032892643262 139.7376802729366 31.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd37d68f-bd48-4ba5-8c79-dfbd39474a64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd37d68f-bd48-4ba5-8c79-dfbd39474a64_0">
											<gml:posList>35.67032904478682 139.73768175299315 33.456 35.67032904478682 139.73768175299315 31.911 35.67042389977112 139.73762943518213 31.911 35.67042389977112 139.73762943518213 33.456 35.67032904478682 139.73768175299315 33.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8c94045-decd-4664-a123-f375ba2a6e61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8c94045-decd-4664-a123-f375ba2a6e61_0">
											<gml:posList>35.67032892643262 139.7376802729366 31.602 35.67032892643262 139.7376802729366 31.911 35.67032156431236 139.73766022172774 31.911 35.67032156431236 139.73766022172774 31.602 35.67032892643262 139.7376802729366 31.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4a03505-cff6-4fc0-ad0b-1008d801f3e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4a03505-cff6-4fc0-ad0b-1008d801f3e2_0">
											<gml:posList>35.67032904478682 139.73768175299315 31.911 35.67032904478682 139.73768175299315 33.456 35.67032120392146 139.73766042099027 33.456 35.67032120392146 139.73766042099027 31.959 35.67032120392146 139.73766042099027 31.911 35.67032904478682 139.73768175299315 31.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_85569249-8ea9-4048-8573-e69f675d009b_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aecb8e24-45f2-4060-9825-310231b470a8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67040386964899 139.73742349048229 34.033 35.67040849627882 139.73743805496878 34.033 35.6704092553228 139.7374404290075 34.033 35.67039422613486 139.7374476049597 34.033 35.67038959950619 139.73743304047528 34.033 35.670388840462046 139.7374306664372 34.033 35.67040386964899 139.73742349048229 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57362c25-9a6d-4bbf-b4c5-096445138053">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670355012902185 139.7374884898627 34.033 35.67035607884254 139.73749140479998 34.033 35.67035192533667 139.7374936963398 34.033 35.67035123157902 139.73749407274175 34.033 35.67034476375605 139.7374764948362 34.033 35.67034369781533 139.7374735798995 34.033 35.67034786033454 139.7374712883481 34.033 35.67034854507841 139.73747091195676 34.033 35.670355012902185 139.7374884898627 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-087f2f24-b131-479b-9b66-c18fbed32175">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67037339544209 139.73749294162263 38.043 35.67037259145362 139.7374907222858 38.043 35.670379898408044 139.73748672585168 38.043 35.67038075434234 139.7374862608856 38.043 35.670387610773645 139.73750511970152 38.043 35.670388414761845 139.7375073390389 38.043 35.67038026088608 139.73751180042666 38.043 35.67037339544209 139.73749294162263 38.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f58b8677-0dc7-41f7-8c3e-799fa92d99bf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670435066102904 139.73750265489667 38.079 35.67043521070046 139.7375031297133 38.079 35.6704272275494 139.73750691707784 38.079 35.67042683109509 139.73750710533818 38.079 35.670423650256204 139.73749704599234 38.079 35.67043202985246 139.7374930593203 38.079 35.670435066102904 139.73750265489667 38.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-faaa751b-c8de-47d8-a99c-27ee64216d35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67032565693414 139.7374793676124 34.033 35.67037176522989 139.73760785779314 34.033 35.670366034952714 139.73761094654037 34.033 35.67036574663655 139.7376111015322 34.033 35.67031963834422 139.7374826113592 34.033 35.67032565693414 139.7374793676124 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ec51349-5310-4632-b758-9d7660ad28dd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67036574663655 139.7376111015322 34.948 35.67031963834422 139.7374826113592 34.948 35.67031963834422 139.7374826113592 34.033 35.67036574663655 139.7376111015322 34.033 35.67036574663655 139.7376111015322 34.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd6a6205-72b8-4a7f-8beb-a3cacd15c57c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670360475347856 139.73761329498424 34.033 35.67035518657606 139.73761617332474 34.033 35.670309016019516 139.7374887215876 34.033 35.670314034490936 139.73748598716475 34.033 35.67031429577456 139.73748584325116 34.033 35.670360475347856 139.73761329498424 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c242e60b-460d-4c63-b621-acbbefbe96db">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67035518657606 139.73761617332474 34.033 35.67035518657606 139.73761617332474 34.948 35.670309016019516 139.7374887215876 34.948 35.670309016019516 139.7374887215876 34.033 35.67035518657606 139.73761617332474 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00a8a759-bfee-46d2-bfa9-93fa25162f51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67030507915072 139.73749139948595 34.033 35.67030507915072 139.73749139948595 34.948 35.67035105204354 139.73761965783095 34.948 35.67035105204354 139.73761965783095 34.033 35.67030507915072 139.73749139948595 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cff0add-0aaf-4df8-9c41-e359368d561f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67030086847431 139.73750113626392 34.033 35.67029861907271 139.73749487572996 34.033 35.67030476380234 139.73749156555664 34.033 35.67030507915072 139.73749139948595 34.033 35.67035105204354 139.73761965783095 34.033 35.67034491632415 139.73762296798563 34.033 35.670344600975575 139.73762313405587 34.033 35.67030086847431 139.73750113626392 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f3d01bf-fc91-444d-9d01-f5e465c1f2a8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670344600975575 139.73762313405587 34.948 35.67029861907271 139.73749487572996 34.948 35.67030086847431 139.73750113626392 34.033 35.670344600975575 139.73762313405587 34.033 35.670344600975575 139.73762313405587 34.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8e1b037-9b7b-418a-97db-682f90fcc09e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670293780796385 139.73749751052011 34.033 35.670293780796385 139.73749751052011 34.948 35.670339852025954 139.73762475247787 34.948 35.670339852025954 139.73762475247787 34.033 35.670293780796385 139.73749751052011 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94b2300f-d06b-480f-a5d8-359e30f3cf7d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670288365879166 139.73750044424784 34.033 35.67029351951275 139.73749765443364 34.033 35.670293780796385 139.73749751052011 34.033 35.670339852025954 139.73762475247787 34.033 35.67033469839826 139.73762755333175 34.033 35.67033443711445 139.73762769724493 34.033 35.670288365879166 139.73750044424784 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d247ff5-b184-439d-8ad7-954952c85b7e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67038163131245 139.7376028862434 34.033 35.67037559463912 139.73760606372727 34.033 35.67034723612515 139.7375250733081 34.033 35.67035298448033 139.73752205081135 34.033 35.670353272796376 139.73752189581927 34.033 35.67038163131245 139.7376028862434 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9f19286-0f3b-45cd-933d-ffb557647f0f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67028326452568 139.7375009695188 34.033 35.67028326452568 139.7375009695188 34.948 35.67033013898256 139.73762948082208 34.948 35.67033013898256 139.73762948082208 34.033 35.67028326452568 139.7375009695188 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65721b88-9b13-40ad-970f-e684edf5b662">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67034723612515 139.7375250733081 34.033 35.67037559463912 139.73760606372727 34.033 35.67037559463912 139.73760606372727 34.948 35.67034723612515 139.7375250733081 34.948 35.67034723612515 139.7375250733081 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6d16b28-9acc-4365-a93a-15c65a77c99d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6703862709554 139.737599831936 34.033 35.67036319008245 139.73753596794563 34.033 35.670369154600216 139.7375327353119 34.033 35.67039224447981 139.73759658824906 34.033 35.6703862709554 139.737599831936 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40dcd22a-2a1f-4d2c-b428-6d2723aae03c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67027783160729 139.73750393640614 34.033 35.6702829942283 139.73750111344305 34.033 35.67028326452568 139.7375009695188 34.033 35.67033013898256 139.73762948082208 34.033 35.67032497636735 139.73763231482482 34.033 35.67032470606981 139.73763245874875 34.033 35.67027783160729 139.73750393640614 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99dd5a9c-7f2d-4d6b-9852-6209d916c8a7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67036319008245 139.73753596794563 34.033 35.6703862709554 139.737599831936 34.033 35.6703862709554 139.737599831936 34.948 35.67036319008245 139.73753596794563 34.948 35.67036319008245 139.73753596794563 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7324db81-f537-4520-9458-cf5a4ced0e1f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67041866380952 139.73760803377152 31.602 35.67041823925132 139.7376068854669 31.602 35.670453999063 139.73758715832014 31.602 35.67045855184193 139.73759955784448 31.602 35.67042279202823 139.7376192849868 31.602 35.67041866380952 139.73760803377152 31.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ec65b04-4332-4f6c-af26-eeb2aa0b3c09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ec65b04-4332-4f6c-af26-eeb2aa0b3c09_0">
											<gml:posList>35.67035123157902 139.73749407274175 34.033 35.67035192533667 139.7374936963398 34.033 35.67035123157902 139.73749407274175 36.948 35.67035123157902 139.73749407274175 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12e10c2f-3cfc-4b46-bf18-836112384496">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12e10c2f-3cfc-4b46-bf18-836112384496_0">
											<gml:posList>35.67031429577456 139.73748584325116 34.033 35.67031429577456 139.73748584325116 34.948 35.670360475347856 139.73761329498424 34.948 35.670360475347856 139.73761329498424 34.033 35.67031429577456 139.73748584325116 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a8b577d-4550-46bf-828a-7740d7cc0166">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a8b577d-4550-46bf-828a-7740d7cc0166_0">
											<gml:posList>35.67033443711445 139.73762769724493 34.033 35.67033443711445 139.73762769724493 34.948 35.670288365879166 139.73750044424784 34.948 35.670288365879166 139.73750044424784 34.033 35.67033443711445 139.73762769724493 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf531bcb-2f63-41cc-8178-789e272436dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf531bcb-2f63-41cc-8178-789e272436dc_0">
											<gml:posList>35.67036574663655 139.7376111015322 34.033 35.670366034952714 139.73761094654037 34.033 35.67036574663655 139.7376111015322 34.948 35.67036574663655 139.7376111015322 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7edf8f59-4425-4692-9e01-4e913be86dce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7edf8f59-4425-4692-9e01-4e913be86dce_0">
											<gml:posList>35.670388840462046 139.7374306664372 36.879 35.67040386964899 139.73742349048229 36.879 35.67040386964899 139.73742349048229 34.033 35.670388840462046 139.7374306664372 34.033 35.670388840462046 139.7374306664372 36.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bd2ffd8-48a5-44ff-baae-fa3b0cc98b29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7bd2ffd8-48a5-44ff-baae-fa3b0cc98b29_0">
											<gml:posList>35.670388840462046 139.7374306664372 34.033 35.67038959950619 139.73743304047528 34.033 35.670388840462046 139.7374306664372 36.879 35.670388840462046 139.7374306664372 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2706bda3-a2d7-48cb-9615-b6029f9e0200">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2706bda3-a2d7-48cb-9615-b6029f9e0200_0">
											<gml:posList>35.67040849627882 139.73743805496878 34.033 35.67040386964899 139.73742349048229 34.033 35.67040386964899 139.73742349048229 36.879 35.6704092553228 139.7374404290075 36.879 35.67040849627882 139.73743805496878 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2a65dc0-4ac3-4a20-aafa-473e50ad4496">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2a65dc0-4ac3-4a20-aafa-473e50ad4496_0">
											<gml:posList>35.67039422613486 139.7374476049597 36.879 35.6704092553228 139.7374404290075 36.879 35.67040386964899 139.73742349048229 36.879 35.670388840462046 139.7374306664372 36.879 35.67039422613486 139.7374476049597 36.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c7914ca-ea0c-4fc2-a148-b219106648da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c7914ca-ea0c-4fc2-a148-b219106648da_0">
											<gml:posList>35.67038959950619 139.73743304047528 34.033 35.67039422613486 139.7374476049597 34.033 35.67039422613486 139.7374476049597 36.879 35.670388840462046 139.7374306664372 36.879 35.67038959950619 139.73743304047528 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ec7b0c1-535e-44c7-b35e-3647d3738fd7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ec7b0c1-535e-44c7-b35e-3647d3738fd7_0">
											<gml:posList>35.6704092553228 139.7374404290075 34.033 35.67040849627882 139.73743805496878 34.033 35.6704092553228 139.7374404290075 36.879 35.6704092553228 139.7374404290075 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-821b4b32-9baf-4acd-ad12-947808a3ffae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-821b4b32-9baf-4acd-ad12-947808a3ffae_0">
											<gml:posList>35.6704092553228 139.7374404290075 34.033 35.6704092553228 139.7374404290075 36.879 35.67039422613486 139.7374476049597 36.879 35.67039422613486 139.7374476049597 34.033 35.6704092553228 139.7374404290075 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41ba77a5-e253-408e-b384-4cc1be43d708">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41ba77a5-e253-408e-b384-4cc1be43d708_0">
											<gml:posList>35.67034854507841 139.73747091195676 34.033 35.67034786033454 139.7374712883481 34.033 35.67034854507841 139.73747091195676 36.948 35.67034854507841 139.73747091195676 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7203f1e-aef5-4f23-88a0-4f23ec19b90e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7203f1e-aef5-4f23-88a0-4f23ec19b90e_0">
											<gml:posList>35.67034786033454 139.7374712883481 34.033 35.67034369781533 139.7374735798995 34.033 35.67034369781533 139.7374735798995 36.948 35.67034854507841 139.73747091195676 36.948 35.67034786033454 139.7374712883481 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98bdb19b-7059-4c57-90b9-f3b98a32fb11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98bdb19b-7059-4c57-90b9-f3b98a32fb11_0">
											<gml:posList>35.67034369781533 139.7374735798995 34.033 35.67034476375605 139.7374764948362 34.033 35.67034369781533 139.7374735798995 36.948 35.67034369781533 139.7374735798995 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab7445ff-622c-4fb7-aa58-d37639d6a963">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab7445ff-622c-4fb7-aa58-d37639d6a963_0">
											<gml:posList>35.67032565693414 139.7374793676124 34.033 35.67031963834422 139.7374826113592 34.033 35.67031963834422 139.7374826113592 34.948 35.67032565693414 139.7374793676124 34.948 35.67032565693414 139.7374793676124 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0935b9c3-d004-474b-8d0a-ce5d85efae5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0935b9c3-d004-474b-8d0a-ce5d85efae5b_0">
											<gml:posList>35.670355012902185 139.7374884898627 34.033 35.67034854507841 139.73747091195676 34.033 35.67034854507841 139.73747091195676 36.948 35.67035607884254 139.73749140479998 36.948 35.670355012902185 139.7374884898627 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9e5b418-e876-44be-8d18-de6d242db34a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9e5b418-e876-44be-8d18-de6d242db34a_0">
											<gml:posList>35.67035123157902 139.73749407274175 36.948 35.67035607884254 139.73749140479998 36.948 35.67034854507841 139.73747091195676 36.948 35.67034369781533 139.7374735798995 36.948 35.67035123157902 139.73749407274175 36.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-187c9198-a5cd-4fd7-a0b1-4af665b64b63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-187c9198-a5cd-4fd7-a0b1-4af665b64b63_0">
											<gml:posList>35.67035123157902 139.73749407274175 36.948 35.67034369781533 139.7374735798995 36.948 35.67034476375605 139.7374764948362 34.033 35.67035123157902 139.73749407274175 34.033 35.67035123157902 139.73749407274175 36.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba1a387a-d037-48de-827e-7a3cb75181fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba1a387a-d037-48de-827e-7a3cb75181fd_0">
											<gml:posList>35.67031429577456 139.73748584325116 34.033 35.670314034490936 139.73748598716475 34.033 35.67031429577456 139.73748584325116 34.948 35.67031429577456 139.73748584325116 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d0226af-f9ea-4ca0-8487-a8a81de8c00e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d0226af-f9ea-4ca0-8487-a8a81de8c00e_0">
											<gml:posList>35.67038075434234 139.7374862608856 38.043 35.670379898408044 139.73748672585168 38.043 35.67038075434234 139.7374862608856 40.608 35.67038075434234 139.7374862608856 38.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d47d1bf9-0df7-4be9-bed0-9e86f66eb232">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d47d1bf9-0df7-4be9-bed0-9e86f66eb232_0">
											<gml:posList>35.670314034490936 139.73748598716475 34.033 35.670309016019516 139.7374887215876 34.033 35.670309016019516 139.7374887215876 34.948 35.67031429577456 139.73748584325116 34.948 35.670314034490936 139.73748598716475 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28dcaa7c-20dd-4180-b384-490d3aaf52fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28dcaa7c-20dd-4180-b384-490d3aaf52fb_0">
											<gml:posList>35.670379898408044 139.73748672585168 38.043 35.67037259145362 139.7374907222858 38.043 35.67037259145362 139.7374907222858 40.608 35.67038075434234 139.7374862608856 40.608 35.670379898408044 139.73748672585168 38.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48aaab1c-af5b-4abf-9d58-d0db34464ed0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48aaab1c-af5b-4abf-9d58-d0db34464ed0_0">
											<gml:posList>35.67035607884254 139.73749140479998 34.033 35.670355012902185 139.7374884898627 34.033 35.67035607884254 139.73749140479998 36.948 35.67035607884254 139.73749140479998 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23089210-4944-426c-9cfb-78717d9de6b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23089210-4944-426c-9cfb-78717d9de6b1_0">
											<gml:posList>35.67030507915072 139.73749139948595 34.033 35.67030476380234 139.73749156555664 34.033 35.67030507915072 139.73749139948595 34.948 35.67030507915072 139.73749139948595 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f085d64f-11d7-4d14-8bf3-11b760257d39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f085d64f-11d7-4d14-8bf3-11b760257d39_0">
											<gml:posList>35.67037259145362 139.7374907222858 38.043 35.67037339544209 139.73749294162263 38.043 35.67037259145362 139.7374907222858 40.608 35.67037259145362 139.7374907222858 38.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4f780e3-3c1d-410c-a4df-c470ff32449e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4f780e3-3c1d-410c-a4df-c470ff32449e_0">
											<gml:posList>35.67035192533667 139.7374936963398 34.033 35.67035607884254 139.73749140479998 34.033 35.67035607884254 139.73749140479998 36.948 35.67035123157902 139.73749407274175 36.948 35.67035192533667 139.7374936963398 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2186d2cf-11f8-4200-9723-3cc72d927188">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2186d2cf-11f8-4200-9723-3cc72d927188_0">
											<gml:posList>35.67030476380234 139.73749156555664 34.033 35.67029861907271 139.73749487572996 34.033 35.67029861907271 139.73749487572996 34.948 35.67030507915072 139.73749139948595 34.948 35.67030476380234 139.73749156555664 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63d34553-8669-40b8-a8dc-5e05fc03b160">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63d34553-8669-40b8-a8dc-5e05fc03b160_0">
											<gml:posList>35.67043202985246 139.7374930593203 38.079 35.670423650256204 139.73749704599234 38.079 35.670423650256204 139.73749704599234 39.167 35.67043202985246 139.7374930593203 39.167 35.67043202985246 139.7374930593203 38.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcb28742-520f-4afb-9b8b-abad0d2a9b30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcb28742-520f-4afb-9b8b-abad0d2a9b30_0">
											<gml:posList>35.67038075434234 139.7374862608856 40.608 35.670388414761845 139.7375073390389 40.608 35.670387610773645 139.73750511970152 38.043 35.67038075434234 139.7374862608856 38.043 35.67038075434234 139.7374862608856 40.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbb44c88-5861-4f16-aaed-e0c5d0205da9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbb44c88-5861-4f16-aaed-e0c5d0205da9_0">
											<gml:posList>35.670293780796385 139.73749751052011 34.033 35.67029351951275 139.73749765443364 34.033 35.670293780796385 139.73749751052011 34.948 35.670293780796385 139.73749751052011 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-584cf7f9-6e61-4cbb-ba8b-372215fd6128">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-584cf7f9-6e61-4cbb-ba8b-372215fd6128_0">
											<gml:posList>35.67029861907271 139.73749487572996 34.033 35.67030086847431 139.73750113626392 34.033 35.67029861907271 139.73749487572996 34.948 35.67029861907271 139.73749487572996 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af75b9e8-ce1c-49c3-8a30-4f520a7135bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af75b9e8-ce1c-49c3-8a30-4f520a7135bc_0">
											<gml:posList>35.670435066102904 139.73750265489667 38.079 35.67043202985246 139.7374930593203 38.079 35.67043202985246 139.7374930593203 39.167 35.67043521070046 139.7375031297133 39.167 35.670435066102904 139.73750265489667 38.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a9948a8-8bd5-43e0-82c0-d7261033c728">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a9948a8-8bd5-43e0-82c0-d7261033c728_0">
											<gml:posList>35.67029351951275 139.73749765443364 34.033 35.670288365879166 139.73750044424784 34.033 35.670288365879166 139.73750044424784 34.948 35.670293780796385 139.73749751052011 34.948 35.67029351951275 139.73749765443364 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0801d38-1575-4c6a-8479-a6195d96bcb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0801d38-1575-4c6a-8479-a6195d96bcb8_0">
											<gml:posList>35.670388414761845 139.7375073390389 40.608 35.67038075434234 139.7374862608856 40.608 35.67037259145362 139.7374907222858 40.608 35.67038026088608 139.73751180042666 40.608 35.670388414761845 139.7375073390389 40.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59176a9a-6081-45d7-8b1e-e2872d4e248f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59176a9a-6081-45d7-8b1e-e2872d4e248f_0">
											<gml:posList>35.670423650256204 139.73749704599234 39.167 35.67042683109509 139.73750710533818 39.167 35.67043521070046 139.7375031297133 39.167 35.67043202985246 139.7374930593203 39.167 35.670423650256204 139.73749704599234 39.167</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6260fe9-3a27-4abc-aecf-8ae02ed0c5d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6260fe9-3a27-4abc-aecf-8ae02ed0c5d1_0">
											<gml:posList>35.67028326452568 139.7375009695188 34.033 35.6702829942283 139.73750111344305 34.033 35.67028326452568 139.7375009695188 34.948 35.67028326452568 139.7375009695188 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9894dcfd-f3d1-48fa-b5a7-f868fb2cbf8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9894dcfd-f3d1-48fa-b5a7-f868fb2cbf8b_0">
											<gml:posList>35.67037339544209 139.73749294162263 38.043 35.67038026088608 139.73751180042666 38.043 35.67038026088608 139.73751180042666 40.608 35.67037259145362 139.7374907222858 40.608 35.67037339544209 139.73749294162263 38.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fbf8100-74d0-4b56-9bea-7d9549ecf0ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fbf8100-74d0-4b56-9bea-7d9549ecf0ce_0">
											<gml:posList>35.67042683109509 139.73750710533818 38.079 35.67042683109509 139.73750710533818 39.167 35.670423650256204 139.73749704599234 39.167 35.670423650256204 139.73749704599234 38.079 35.67042683109509 139.73750710533818 38.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1b0eba2-5e6a-48b0-b925-b98620e821e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1b0eba2-5e6a-48b0-b925-b98620e821e9_0">
											<gml:posList>35.67027783160729 139.73750393640614 34.948 35.67028326452568 139.7375009695188 34.948 35.6702829942283 139.73750111344305 34.033 35.67027783160729 139.73750393640614 34.033 35.67027783160729 139.73750393640614 34.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01f928d8-b399-4753-a822-c73ee13df435">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01f928d8-b399-4753-a822-c73ee13df435_0">
											<gml:posList>35.67043521070046 139.7375031297133 38.079 35.670435066102904 139.73750265489667 38.079 35.67043521070046 139.7375031297133 39.167 35.67043521070046 139.7375031297133 38.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bfd03e5-1339-410e-89c3-90baa0fe2e20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1bfd03e5-1339-410e-89c3-90baa0fe2e20_0">
											<gml:posList>35.6704272275494 139.73750691707784 38.079 35.67043521070046 139.7375031297133 38.079 35.67043521070046 139.7375031297133 39.167 35.67042683109509 139.73750710533818 39.167 35.6704272275494 139.73750691707784 38.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce661bb0-777a-43f7-aa23-cb600ee46b0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce661bb0-777a-43f7-aa23-cb600ee46b0a_0">
											<gml:posList>35.670388414761845 139.7375073390389 38.043 35.670387610773645 139.73750511970152 38.043 35.670388414761845 139.7375073390389 40.608 35.670388414761845 139.7375073390389 38.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c492d086-8566-4036-8ce7-7b63f6c5bc4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c492d086-8566-4036-8ce7-7b63f6c5bc4f_0">
											<gml:posList>35.67042683109509 139.73750710533818 38.079 35.6704272275494 139.73750691707784 38.079 35.67042683109509 139.73750710533818 39.167 35.67042683109509 139.73750710533818 38.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e66c9d87-ec85-4fbb-a149-57afaf08d85c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e66c9d87-ec85-4fbb-a149-57afaf08d85c_0">
											<gml:posList>35.670388414761845 139.7375073390389 38.043 35.670388414761845 139.7375073390389 40.608 35.67038026088608 139.73751180042666 40.608 35.67038026088608 139.73751180042666 38.043 35.670388414761845 139.7375073390389 38.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b50d3c6-147c-41b2-81f5-cc7f709c6e43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b50d3c6-147c-41b2-81f5-cc7f709c6e43_0">
											<gml:posList>35.670353272796376 139.73752189581927 34.033 35.67035298448033 139.73752205081135 34.033 35.670353272796376 139.73752189581927 34.948 35.670353272796376 139.73752189581927 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b045eed6-6abe-4cea-ad89-4ee9e774f801">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b045eed6-6abe-4cea-ad89-4ee9e774f801_0">
											<gml:posList>35.67035298448033 139.73752205081135 34.033 35.67034723612515 139.7375250733081 34.033 35.67034723612515 139.7375250733081 34.948 35.670353272796376 139.73752189581927 34.948 35.67035298448033 139.73752205081135 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ead5ac2-5180-4b96-bacb-167551652585">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ead5ac2-5180-4b96-bacb-167551652585_0">
											<gml:posList>35.670369154600216 139.7375327353119 34.033 35.67036319008245 139.73753596794563 34.033 35.67036319008245 139.73753596794563 34.948 35.670369154600216 139.7375327353119 34.948 35.670369154600216 139.7375327353119 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b674dc5-1e5f-4fb8-be4c-fc2de4cbeb49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b674dc5-1e5f-4fb8-be4c-fc2de4cbeb49_0">
											<gml:posList>35.67032565693414 139.7374793676124 34.033 35.67032565693414 139.7374793676124 34.948 35.67037176522989 139.73760785779314 34.948 35.67037176522989 139.73760785779314 34.033 35.67032565693414 139.7374793676124 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8251f67c-e25c-4635-9eac-7c51bd843828">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8251f67c-e25c-4635-9eac-7c51bd843828_0">
											<gml:posList>35.67032565693414 139.7374793676124 34.948 35.67031963834422 139.7374826113592 34.948 35.67036574663655 139.7376111015322 34.948 35.67037176522989 139.73760785779314 34.948 35.67032565693414 139.7374793676124 34.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-114dd953-9744-400d-86ba-60212ed03daf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-114dd953-9744-400d-86ba-60212ed03daf_0">
											<gml:posList>35.670360475347856 139.73761329498424 34.948 35.67031429577456 139.73748584325116 34.948 35.670309016019516 139.7374887215876 34.948 35.67035518657606 139.73761617332474 34.948 35.670360475347856 139.73761329498424 34.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e834382-fef0-4bda-8707-bd335ae192ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e834382-fef0-4bda-8707-bd335ae192ad_0">
											<gml:posList>35.67035105204354 139.73761965783095 34.948 35.67030507915072 139.73749139948595 34.948 35.67029861907271 139.73749487572996 34.948 35.670344600975575 139.73762313405587 34.948 35.67035105204354 139.73761965783095 34.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cc92988-a82b-4daf-88b7-62dad5658744">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cc92988-a82b-4daf-88b7-62dad5658744_0">
											<gml:posList>35.670353272796376 139.73752189581927 34.033 35.670353272796376 139.73752189581927 34.948 35.67038163131245 139.7376028862434 34.948 35.67038163131245 139.7376028862434 34.033 35.670353272796376 139.73752189581927 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d3660b3-e20e-4b81-b3a2-9d1cdf3f228a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d3660b3-e20e-4b81-b3a2-9d1cdf3f228a_0">
											<gml:posList>35.670293780796385 139.73749751052011 34.948 35.670288365879166 139.73750044424784 34.948 35.67033443711445 139.73762769724493 34.948 35.670339852025954 139.73762475247787 34.948 35.670293780796385 139.73749751052011 34.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-070e93b9-7bd9-4f7a-921b-1ee73c3fd3fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-070e93b9-7bd9-4f7a-921b-1ee73c3fd3fa_0">
											<gml:posList>35.67038163131245 139.7376028862434 34.948 35.670353272796376 139.73752189581927 34.948 35.67034723612515 139.7375250733081 34.948 35.67037559463912 139.73760606372727 34.948 35.67038163131245 139.7376028862434 34.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04c3d66a-f0fc-4550-859f-0261c33a00e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04c3d66a-f0fc-4550-859f-0261c33a00e0_0">
											<gml:posList>35.670369154600216 139.7375327353119 34.033 35.670369154600216 139.7375327353119 34.948 35.67039224447981 139.73759658824906 34.948 35.67039224447981 139.73759658824906 34.033 35.670369154600216 139.7375327353119 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99b21ad4-fe38-4f84-b681-0cfc6ef505e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99b21ad4-fe38-4f84-b681-0cfc6ef505e1_0">
											<gml:posList>35.670369154600216 139.7375327353119 34.948 35.67036319008245 139.73753596794563 34.948 35.6703862709554 139.737599831936 34.948 35.67039224447981 139.73759658824906 34.948 35.670369154600216 139.7375327353119 34.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e575a50-df32-404c-81ad-139c58776e54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e575a50-df32-404c-81ad-139c58776e54_0">
											<gml:posList>35.67032470606981 139.73763245874875 34.948 35.67033013898256 139.73762948082208 34.948 35.67028326452568 139.7375009695188 34.948 35.67027783160729 139.73750393640614 34.948 35.67032470606981 139.73763245874875 34.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d5fa3cd-7f43-460b-b18e-9930ea8b0711">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d5fa3cd-7f43-460b-b18e-9930ea8b0711_0">
											<gml:posList>35.67027783160729 139.73750393640614 34.033 35.67032470606981 139.73763245874875 34.033 35.67032470606981 139.73763245874875 34.948 35.67027783160729 139.73750393640614 34.948 35.67027783160729 139.73750393640614 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93cd902b-1bf2-447d-a1c6-43cd80d2bc0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93cd902b-1bf2-447d-a1c6-43cd80d2bc0b_0">
											<gml:posList>35.670453999063 139.73758715832014 31.602 35.670453999063 139.73758715832014 33.25 35.67045855184193 139.73759955784448 33.25 35.67045855184193 139.73759955784448 31.602 35.670453999063 139.73758715832014 31.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53696316-d699-45fc-8bfa-c9a09b114180">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53696316-d699-45fc-8bfa-c9a09b114180_0">
											<gml:posList>35.67041823925132 139.7376068854669 33.25 35.670453999063 139.73758715832014 33.25 35.670453999063 139.73758715832014 31.602 35.67041823925132 139.7376068854669 31.602 35.67041823925132 139.7376068854669 33.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a58363f-d386-44a6-9a0e-7471a4a0f1c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a58363f-d386-44a6-9a0e-7471a4a0f1c2_0">
											<gml:posList>35.6703862709554 139.737599831936 34.033 35.67039224447981 139.73759658824906 34.033 35.67039224447981 139.73759658824906 34.948 35.6703862709554 139.737599831936 34.948 35.6703862709554 139.737599831936 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c57319b6-568c-4fdf-969b-2afc05b2f3d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c57319b6-568c-4fdf-969b-2afc05b2f3d8_0">
											<gml:posList>35.67045855184193 139.73759955784448 33.25 35.670453999063 139.73758715832014 33.25 35.67041823925132 139.7376068854669 33.25 35.67042279202823 139.7376192849868 33.25 35.67045855184193 139.73759955784448 33.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49a081d7-848a-4ca2-8cb2-ec9418bdaf07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49a081d7-848a-4ca2-8cb2-ec9418bdaf07_0">
											<gml:posList>35.67037559463912 139.73760606372727 34.033 35.67038163131245 139.7376028862434 34.033 35.67038163131245 139.7376028862434 34.948 35.67037559463912 139.73760606372727 34.948 35.67037559463912 139.73760606372727 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd0eed4b-d0aa-4b1a-a7b9-ba01af82d53e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd0eed4b-d0aa-4b1a-a7b9-ba01af82d53e_0">
											<gml:posList>35.67041823925132 139.7376068854669 31.602 35.67041866380952 139.73760803377152 31.602 35.67041823925132 139.7376068854669 33.25 35.67041823925132 139.7376068854669 31.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67c629af-a517-40fa-a846-ba6680cf780f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67c629af-a517-40fa-a846-ba6680cf780f_0">
											<gml:posList>35.670366034952714 139.73761094654037 34.033 35.67037176522989 139.73760785779314 34.033 35.67037176522989 139.73760785779314 34.948 35.67036574663655 139.7376111015322 34.948 35.670366034952714 139.73761094654037 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1128767-596e-4814-8a94-95c75d86fe44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1128767-596e-4814-8a94-95c75d86fe44_0">
											<gml:posList>35.67045855184193 139.73759955784448 31.602 35.67045855184193 139.73759955784448 33.25 35.67042279202823 139.7376192849868 33.25 35.67042279202823 139.7376192849868 31.602 35.67045855184193 139.73759955784448 31.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02974326-2926-42ec-90dd-053c8b3c891b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02974326-2926-42ec-90dd-053c8b3c891b_0">
											<gml:posList>35.67042279202823 139.7376192849868 33.25 35.67041823925132 139.7376068854669 33.25 35.67041866380952 139.73760803377152 31.602 35.67042279202823 139.7376192849868 31.602 35.67042279202823 139.7376192849868 33.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-764744dc-ae23-4978-ac5c-623f275d166f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-764744dc-ae23-4978-ac5c-623f275d166f_0">
											<gml:posList>35.67035518657606 139.73761617332474 34.033 35.670360475347856 139.73761329498424 34.033 35.670360475347856 139.73761329498424 34.948 35.67035518657606 139.73761617332474 34.948 35.67035518657606 139.73761617332474 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14a8cd4c-3537-4c61-89b5-f44f375e7f3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14a8cd4c-3537-4c61-89b5-f44f375e7f3a_0">
											<gml:posList>35.67034491632415 139.73762296798563 34.033 35.67035105204354 139.73761965783095 34.033 35.67035105204354 139.73761965783095 34.948 35.670344600975575 139.73762313405587 34.948 35.67034491632415 139.73762296798563 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b8e88de-2653-417f-b42a-08f3f9dcdc52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b8e88de-2653-417f-b42a-08f3f9dcdc52_0">
											<gml:posList>35.670344600975575 139.73762313405587 34.033 35.67034491632415 139.73762296798563 34.033 35.670344600975575 139.73762313405587 34.948 35.670344600975575 139.73762313405587 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-631f086b-6ffc-4ed6-8161-446fe02fa70d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-631f086b-6ffc-4ed6-8161-446fe02fa70d_0">
											<gml:posList>35.67033469839826 139.73762755333175 34.033 35.670339852025954 139.73762475247787 34.033 35.670339852025954 139.73762475247787 34.948 35.67033443711445 139.73762769724493 34.948 35.67033469839826 139.73762755333175 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c71ba1b-c1e8-4015-8e6d-2096c4ab6fc1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c71ba1b-c1e8-4015-8e6d-2096c4ab6fc1_0">
											<gml:posList>35.67033443711445 139.73762769724493 34.033 35.67033469839826 139.73762755333175 34.033 35.67033443711445 139.73762769724493 34.948 35.67033443711445 139.73762769724493 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f5c74b4-4d9c-4413-a0ae-71a5839f7b15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f5c74b4-4d9c-4413-a0ae-71a5839f7b15_0">
											<gml:posList>35.67032497636735 139.73763231482482 34.033 35.67033013898256 139.73762948082208 34.033 35.67033013898256 139.73762948082208 34.948 35.67032470606981 139.73763245874875 34.948 35.67032497636735 139.73763231482482 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5063ed54-70cb-4fa4-a8fb-51334cecc9c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5063ed54-70cb-4fa4-a8fb-51334cecc9c9_0">
											<gml:posList>35.67032470606981 139.73763245874875 34.033 35.67032497636735 139.73763231482482 34.033 35.67032470606981 139.73763245874875 34.948 35.67032470606981 139.73763245874875 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-04e17b15-bf23-464e-a627-74d5f591922b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04e17b15-bf23-464e-a627-74d5f591922b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04e17b15-bf23-464e-a627-74d5f591922b">
											<gml:posList>35.67036079738924 139.73745159949755 15.216 35.67035594649123 139.73743838293038 15.216 35.67041248282845 139.73740722007906 15.216 35.670495498854045 139.73763323800642 15.216 35.67043972823033 139.73766390273514 15.216 35.6704338566721 139.73764800311739 15.216 35.670334388707026 139.73770291123836 15.216 35.67025724439152 139.73749279326134 15.216 35.67033643131969 139.73744914322916 15.216 35.670341282207744 139.7374623487475 15.216 35.67036079738924 139.73745159949755 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dbb42e55-130f-47ab-9f41-09024b160abd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbb42e55-130f-47ab-9f41-09024b160abd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbb42e55-130f-47ab-9f41-09024b160abd">
											<gml:posList>35.67041248282845 139.73740722007906 35.591 35.67035594649123 139.73743838293038 35.591 35.67036028370132 139.73744039920786 35.591 35.67041083755 139.73741253530017 35.591 35.67041248282845 139.73740722007906 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b5f282a-f98c-4915-b4b2-2900174d98c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b5f282a-f98c-4915-b4b2-2900174d98c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b5f282a-f98c-4915-b4b2-2900174d98c6">
											<gml:posList>35.67043793872248 139.7374765380878 35.591 35.67041248282845 139.73740722007906 35.591 35.67041083755 139.73741253530017 35.591 35.67043494747706 139.73747818755774 35.591 35.67043793872248 139.7374765380878 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-feab50be-942d-464b-8d6d-3bbfa6cbbdc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-feab50be-942d-464b-8d6d-3bbfa6cbbdc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-feab50be-942d-464b-8d6d-3bbfa6cbbdc2">
											<gml:posList>35.67035594649123 139.73743838293038 35.591 35.67036079738924 139.73745159949755 35.591 35.670365134599116 139.73745361577585 35.591 35.67036028370132 139.73744039920786 35.591 35.67035594649123 139.73743838293038 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-42baf0c2-45f3-4519-b7d5-b83ed20ccfb7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42baf0c2-45f3-4519-b7d5-b83ed20ccfb7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42baf0c2-45f3-4519-b7d5-b83ed20ccfb7">
											<gml:posList>35.670341282207744 139.7374623487475 35.591 35.67033643131969 139.73744914322916 35.591 35.67033478603935 139.73745445844435 35.591 35.67033963693561 139.73746767500901 35.591 35.670341282207744 139.7374623487475 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4dd6b0fe-565e-4755-8f4b-1f571eca847c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4dd6b0fe-565e-4755-8f4b-1f571eca847c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4dd6b0fe-565e-4755-8f4b-1f571eca847c">
											<gml:posList>35.67036079738924 139.73745159949755 35.591 35.670341282207744 139.7374623487475 35.591 35.67033963693561 139.73746767500901 35.591 35.670365134599116 139.73745361577585 35.591 35.67036079738924 139.73745159949755 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a12e215-1613-4b96-bd2e-5418cb7c76ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a12e215-1613-4b96-bd2e-5418cb7c76ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a12e215-1613-4b96-bd2e-5418cb7c76ff">
											<gml:posList>35.67033643131969 139.73744914322916 35.591 35.67025724439152 139.73749279326134 35.591 35.67026158160078 139.73749480953927 35.591 35.67033478603935 139.73745445844435 35.591 35.67033643131969 139.73744914322916 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6d5d4bb-0220-44d8-a25d-7580c281fcda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6d5d4bb-0220-44d8-a25d-7580c281fcda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6d5d4bb-0220-44d8-a25d-7580c281fcda">
											<gml:posList>35.670371178064826 139.73752692256247 38.043 35.67040275732515 139.73750949801072 38.043 35.67038890024143 139.73747178054666 38.043 35.67036417743066 139.73748543014045 38.043 35.6703629218151 139.73748202939436 38.043 35.67035607438478 139.7374858043536 38.043 35.670371178064826 139.73752692256247 38.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-784ae9b8-56b8-4ab2-a65f-d50f4efe5582">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-784ae9b8-56b8-4ab2-a65f-d50f4efe5582">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-784ae9b8-56b8-4ab2-a65f-d50f4efe5582">
											<gml:posList>35.670447378512854 139.73750222042227 38.079 35.67043793871369 139.73747652704157 38.079 35.6704248745502 139.7374837448255 38.079 35.67042669023861 139.73748868033562 38.079 35.67040326482181 139.73750159932663 38.079 35.67041088892005 139.73752234614284 38.079 35.670447378512854 139.73750222042227 38.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e73fe792-0a53-49cc-a80c-20ce6185c590">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e73fe792-0a53-49cc-a80c-20ce6185c590">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e73fe792-0a53-49cc-a80c-20ce6185c590">
											<gml:posList>35.67043391041268 139.7375568713542 37.418 35.67046179566799 139.7375414837278 37.418 35.670447378512854 139.73750222042227 37.418 35.6704194842488 139.73751760807028 37.418 35.67043391041268 139.7375568713542 37.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fe461a0e-5c17-49f6-bdeb-878a52ee0c4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe461a0e-5c17-49f6-bdeb-878a52ee0c4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe461a0e-5c17-49f6-bdeb-878a52ee0c4e">
											<gml:posList>35.67043391041268 139.7375568713542 34.033 35.6704194842488 139.73751760807028 34.033 35.67041088892005 139.73752234614284 34.033 35.67040326482181 139.73750159932663 34.033 35.67042669023861 139.73748868033562 34.033 35.6704248745502 139.7374837448255 34.033 35.67043494747706 139.73747818755774 34.033 35.67041083755 139.73741253530017 34.033 35.670360292715046 139.73744039919708 34.033 35.670365134599116 139.73745361577585 34.033 35.67033963693561 139.73746767500901 34.033 35.67033478603935 139.73745445844435 34.033 35.6702615906145 139.73749480952853 34.033 35.67035607438478 139.7374858043536 34.033 35.6703629218151 139.73748202939436 34.033 35.67036417743066 139.73748543014045 34.033 35.67038890024143 139.73747178054666 34.033 35.67040275732515 139.73750949801072 34.033 35.670371178064826 139.73752692256247 34.033 35.67032084001982 139.73765620175664 34.033 35.67047009603429 139.73757387252533 34.033 35.6704601503924 139.7375468099957 34.033 35.670458804430474 139.73754314424207 34.033 35.67043391041268 139.7375568713542 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd6b112e-9003-4625-8055-25247c311a0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd6b112e-9003-4625-8055-25247c311a0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd6b112e-9003-4625-8055-25247c311a0e">
											<gml:posList>35.67046179566799 139.7375414837278 35.591 35.670458804421685 139.73754313319583 35.591 35.6704601503924 139.7375468099957 35.591 35.67047009603429 139.73757387252533 35.591 35.67047443324205 139.73757588881298 35.591 35.67046179566799 139.7375414837278 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-417f2bb8-5d48-4d78-8e6c-c5ed7b3b4ff0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-417f2bb8-5d48-4d78-8e6c-c5ed7b3b4ff0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-417f2bb8-5d48-4d78-8e6c-c5ed7b3b4ff0">
											<gml:posList>35.6702615906145 139.73749480952853 34.033 35.67032084001982 139.73765620175664 34.033 35.670371178064826 139.73752692256247 34.033 35.67035607438478 139.7374858043536 34.033 35.6702615906145 139.73749480952853 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f627df04-8ced-417a-ac0d-223952f2474b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f627df04-8ced-417a-ac0d-223952f2474b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f627df04-8ced-417a-ac0d-223952f2474b">
											<gml:posList>35.67025724439152 139.73749279326134 35.591 35.67031919473909 139.73766152801284 35.591 35.67032084001982 139.73765620175664 35.591 35.67026158160078 139.73749480953927 35.591 35.67025724439152 139.73749279326134 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bdfbd8dc-f1c6-4601-83b1-f91430d9bec5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdfbd8dc-f1c6-4601-83b1-f91430d9bec5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdfbd8dc-f1c6-4601-83b1-f91430d9bec5">
											<gml:posList>35.670483520738365 139.73760064370452 31.911 35.67047443324205 139.73757588881298 31.911 35.67047206366977 139.7375771951031 31.911 35.67048008521937 139.73759902400448 31.911 35.670483520738365 139.73760064370452 31.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d4d66f9a-b2df-44c7-96ba-614a1bb13472">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4d66f9a-b2df-44c7-96ba-614a1bb13472">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4d66f9a-b2df-44c7-96ba-614a1bb13472">
											<gml:posList>35.67048962721277 139.7376172389635 29.335 35.670483520738365 139.73760064370452 29.335 35.670481151139484 139.73760191685525 29.335 35.67048619171156 139.7376156413551 29.335 35.67048962721277 139.7376172389635 29.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ff19b28-a203-4498-8280-7b00b8bee816">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ff19b28-a203-4498-8280-7b00b8bee816">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ff19b28-a203-4498-8280-7b00b8bee816">
											<gml:posList>35.67031919473909 139.73766152801284 35.591 35.67047443324205 139.73757588881298 35.591 35.67047009603429 139.73757387252533 35.591 35.67032084001982 139.73765620175664 35.591 35.67031919473909 139.73766152801284 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-64cffccb-d808-4aef-afc3-bb0803591ad6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64cffccb-d808-4aef-afc3-bb0803591ad6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64cffccb-d808-4aef-afc3-bb0803591ad6">
											<gml:posList>35.670495498854045 139.73763323800642 26.515 35.67048962721277 139.7376172389635 26.515 35.67048726665377 139.73761854524187 26.515 35.67049207236677 139.73763164038647 26.515 35.670495498854045 139.73763323800642 26.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8071e62a-53e7-43af-b53a-b4dff3146f5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8071e62a-53e7-43af-b53a-b4dff3146f5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8071e62a-53e7-43af-b53a-b4dff3146f5a">
											<gml:posList>35.67047206366977 139.7375771951031 31.602 35.67032156431236 139.73766022172774 31.602 35.67032892643262 139.7376802729366 31.602 35.67048008521937 139.73759902400448 31.602 35.67047206366977 139.7375771951031 31.602</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce93d00d-ced4-4be7-83be-59b03da5737d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce93d00d-ced4-4be7-83be-59b03da5737d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce93d00d-ced4-4be7-83be-59b03da5737d">
											<gml:posList>35.670396364223485 139.73766522479806 29.026 35.67048619171156 139.7376156413551 29.026 35.670481151139484 139.73760191685525 29.026 35.67037448315463 139.73765925278835 29.026 35.67037740095851 139.73766726889045 29.026 35.670396364223485 139.73766522479806 29.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b920fc7a-c20a-428e-b56d-df90bd56ef4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b920fc7a-c20a-428e-b56d-df90bd56ef4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b920fc7a-c20a-428e-b56d-df90bd56ef4e">
											<gml:posList>35.67043622624515 139.73764669683 26.206 35.67044102287118 139.73765970360867 26.206 35.67049207236677 139.73763164038647 26.206 35.67048726665377 139.73761854524187 26.206 35.67043622624515 139.73764669683 26.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a55c6f4b-8afe-4a3f-a9a4-440829d80098">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a55c6f4b-8afe-4a3f-a9a4-440829d80098">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a55c6f4b-8afe-4a3f-a9a4-440829d80098">
											<gml:posList>35.670327613746004 139.73768444998586 31.911 35.670483520738365 139.73760064370452 31.911 35.67048008521937 139.73759902400448 31.911 35.67032892643262 139.7376802729366 31.911 35.670327613746004 139.73768444998586 31.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44c01be7-dc7d-4e56-babc-6e5afc19b958">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44c01be7-dc7d-4e56-babc-6e5afc19b958">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44c01be7-dc7d-4e56-babc-6e5afc19b958">
											<gml:posList>35.67039702470004 139.73766833905572 29.335 35.67048962721277 139.7376172389635 29.335 35.67048619171156 139.7376156413551 29.335 35.670396364223485 139.73766522479806 29.335 35.67039702470004 139.73766833905572 29.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cdb69412-ab7b-444f-b759-6a597aad0cc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdb69412-ab7b-444f-b759-6a597aad0cc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdb69412-ab7b-444f-b759-6a597aad0cc3">
											<gml:posList>35.67043972823033 139.73766390273514 26.515 35.670495498854045 139.73763323800642 26.515 35.67049207236677 139.73763164038647 26.515 35.67044102287118 139.73765970360867 26.515 35.67043972823033 139.73766390273514 26.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e8f0154-cf70-4af2-9e94-4b298e2cecd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e8f0154-cf70-4af2-9e94-4b298e2cecd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e8f0154-cf70-4af2-9e94-4b298e2cecd1">
											<gml:posList>35.6704338566721 139.73764800311739 26.515 35.67043972823033 139.73766390273514 26.515 35.67044102287118 139.73765970360867 26.515 35.67043622624515 139.73764669683 26.515 35.6704338566721 139.73764800311739 26.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8d8ec0b-b1c8-4ecb-90a2-110b89383048">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8d8ec0b-b1c8-4ecb-90a2-110b89383048">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8d8ec0b-b1c8-4ecb-90a2-110b89383048">
											<gml:posList>35.67037210454136 139.73766052594635 29.335 35.67037578115642 139.73767062888578 29.335 35.67037740095851 139.73766726889045 29.335 35.67037448315463 139.73765925278835 29.335 35.67037210454136 139.73766052594635 29.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a66e9e6d-837a-42ba-a27e-11f9148f0ee0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a66e9e6d-837a-42ba-a27e-11f9148f0ee0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a66e9e6d-837a-42ba-a27e-11f9148f0ee0">
											<gml:posList>35.67037578115642 139.73767062888578 29.335 35.67039702470004 139.73766833905572 29.335 35.670396364223485 139.73766522479806 29.335 35.67037740095851 139.73766726889045 29.335 35.67037578115642 139.73767062888578 29.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb7dcf7c-930b-4c75-bab8-84aa80322c83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb7dcf7c-930b-4c75-bab8-84aa80322c83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb7dcf7c-930b-4c75-bab8-84aa80322c83">
											<gml:posList>35.67031919473909 139.73766152801284 31.911 35.670327613746004 139.73768444998586 31.911 35.67032892643262 139.7376802729366 31.911 35.67032156431236 139.73766022172774 31.911 35.67031919473909 139.73766152801284 31.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5a5e0bd9-e0dc-4325-b965-f8d7e2f69924">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a5e0bd9-e0dc-4325-b965-f8d7e2f69924">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a5e0bd9-e0dc-4325-b965-f8d7e2f69924">
											<gml:posList>35.67037210454136 139.73766052594635 25.28 35.67032946076933 139.73768345361972 25.28 35.67033540466083 139.7376996403357 25.28 35.67039090490061 139.737668998087 25.28 35.67037578115642 139.73767062888578 25.28 35.67037210454136 139.73766052594635 25.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c72d9fd-1192-4832-8305-5c365a0638d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c72d9fd-1192-4832-8305-5c365a0638d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c72d9fd-1192-4832-8305-5c365a0638d7">
											<gml:posList>35.670334388707026 139.73770291123836 25.665 35.67039702470004 139.73766833905572 25.665 35.67039090490061 139.737668998087 25.665 35.67033540466083 139.7376996403357 25.665 35.670334388707026 139.73770291123836 25.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-594678fc-f175-4a29-a7b7-4c2ae26419e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-594678fc-f175-4a29-a7b7-4c2ae26419e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-594678fc-f175-4a29-a7b7-4c2ae26419e3">
											<gml:posList>35.670327613746004 139.73768444998586 25.665 35.670334388707026 139.73770291123836 25.665 35.67033540466083 139.7376996403357 25.665 35.67032946076933 139.73768345361972 25.665 35.670327613746004 139.73768444998586 25.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8da1203e-ea1b-494e-8d55-d4bb8cb5007f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8da1203e-ea1b-494e-8d55-d4bb8cb5007f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8da1203e-ea1b-494e-8d55-d4bb8cb5007f">
											<gml:posList>35.67047206366977 139.7375771951031 31.911 35.67032156431236 139.73766022172774 31.911 35.67032156431236 139.73766022172774 31.602 35.67047206366977 139.7375771951031 31.602 35.67047206366977 139.7375771951031 31.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-380ee720-e861-42e9-83f6-78e25a52d25f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-380ee720-e861-42e9-83f6-78e25a52d25f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-380ee720-e861-42e9-83f6-78e25a52d25f">
											<gml:posList>35.67048726665377 139.73761854524187 26.515 35.67043622624515 139.73764669683 26.515 35.67043622624515 139.73764669683 26.206 35.67048726665377 139.73761854524187 26.206 35.67048726665377 139.73761854524187 26.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54f47d1c-bd4c-4c98-955c-1b0633e4cdc8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54f47d1c-bd4c-4c98-955c-1b0633e4cdc8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54f47d1c-bd4c-4c98-955c-1b0633e4cdc8">
											<gml:posList>35.67039090490061 139.737668998087 25.665 35.67037578115642 139.73767062888578 25.665 35.67037578115642 139.73767062888578 25.28 35.67039090490061 139.737668998087 25.28 35.67039090490061 139.737668998087 25.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f38add0-d022-4808-85bf-83220010ce72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f38add0-d022-4808-85bf-83220010ce72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f38add0-d022-4808-85bf-83220010ce72">
											<gml:posList>35.67037210454136 139.73766052594635 25.665 35.67032946076933 139.73768345361972 25.665 35.67032946076933 139.73768345361972 25.28 35.67037210454136 139.73766052594635 25.28 35.67037210454136 139.73766052594635 25.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b855be6-7c65-48da-9626-6a21063f7d3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b855be6-7c65-48da-9626-6a21063f7d3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b855be6-7c65-48da-9626-6a21063f7d3e">
											<gml:posList>35.67026158160078 139.73749480953927 35.591 35.67032084001982 139.73765620175664 35.591 35.67032084001982 139.73765620175664 34.033 35.6702615906145 139.73749480952853 34.033 35.67026158160078 139.73749480953927 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2956f2dc-ee3a-4ee9-a933-3cc3e2bac203">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2956f2dc-ee3a-4ee9-a933-3cc3e2bac203">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2956f2dc-ee3a-4ee9-a933-3cc3e2bac203">
											<gml:posList>35.67025724439152 139.73749279326134 35.591 35.67025724439152 139.73749279326134 15.216 35.670334388707026 139.73770291123836 15.216 35.670334388707026 139.73770291123836 25.665 35.670327613746004 139.73768444998586 25.665 35.670327613746004 139.73768444998586 31.911 35.67031919473909 139.73766152801284 31.911 35.67031919473909 139.73766152801284 35.591 35.67025724439152 139.73749279326134 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec1446ee-76ac-4a0f-8ad0-a1cce16e17c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec1446ee-76ac-4a0f-8ad0-a1cce16e17c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec1446ee-76ac-4a0f-8ad0-a1cce16e17c0">
											<gml:posList>35.67025724439152 139.73749279326134 15.216 35.67025724439152 139.73749279326134 35.591 35.67033643131969 139.73744914322916 35.591 35.67033643131969 139.73744914322916 15.216 35.67025724439152 139.73749279326134 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff8a9977-34b5-4e77-a104-ccf81ffeea85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff8a9977-34b5-4e77-a104-ccf81ffeea85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff8a9977-34b5-4e77-a104-ccf81ffeea85">
											<gml:posList>35.67033478603935 139.73745445844435 35.591 35.67026158160078 139.73749480953927 35.591 35.6702615906145 139.73749480952853 34.033 35.67033478603935 139.73745445844435 34.033 35.67033478603935 139.73745445844435 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8665445-4edb-404b-980a-98ba00be3a32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8665445-4edb-404b-980a-98ba00be3a32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8665445-4edb-404b-980a-98ba00be3a32">
											<gml:posList>35.67032156431236 139.73766022172774 31.911 35.67032892643262 139.7376802729366 31.911 35.67032892643262 139.7376802729366 31.602 35.67032156431236 139.73766022172774 31.602 35.67032156431236 139.73766022172774 31.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd8c2bbd-95d3-4aef-8813-46402a713a65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd8c2bbd-95d3-4aef-8813-46402a713a65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd8c2bbd-95d3-4aef-8813-46402a713a65">
											<gml:posList>35.67032946076933 139.73768345361972 25.665 35.67033540466083 139.7376996403357 25.665 35.67033540466083 139.7376996403357 25.28 35.67032946076933 139.73768345361972 25.28 35.67032946076933 139.73768345361972 25.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-849a734b-a8b2-406e-8d5c-887be2a3bfc8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-849a734b-a8b2-406e-8d5c-887be2a3bfc8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-849a734b-a8b2-406e-8d5c-887be2a3bfc8">
											<gml:posList>35.67033963693561 139.73746767500901 35.591 35.67033478603935 139.73745445844435 35.591 35.67033478603935 139.73745445844435 34.033 35.67033963693561 139.73746767500901 34.033 35.67033963693561 139.73746767500901 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4afb71f-7669-432c-a88d-294fcae6b45e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4afb71f-7669-432c-a88d-294fcae6b45e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4afb71f-7669-432c-a88d-294fcae6b45e">
											<gml:posList>35.67033643131969 139.73744914322916 15.216 35.67033643131969 139.73744914322916 35.591 35.670341282207744 139.7374623487475 35.591 35.670341282207744 139.7374623487475 15.216 35.67033643131969 139.73744914322916 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6c40a3e-84ff-4265-aa16-72016c129574">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6c40a3e-84ff-4265-aa16-72016c129574">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6c40a3e-84ff-4265-aa16-72016c129574">
											<gml:posList>35.670341282207744 139.7374623487475 15.216 35.670341282207744 139.7374623487475 35.591 35.67036079738924 139.73745159949755 35.591 35.67036079738924 139.73745159949755 15.216 35.670341282207744 139.7374623487475 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b33764dd-1b46-4029-a32f-c4a3e83ff604">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b33764dd-1b46-4029-a32f-c4a3e83ff604">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b33764dd-1b46-4029-a32f-c4a3e83ff604">
											<gml:posList>35.670365134599116 139.73745361577585 35.591 35.67033963693561 139.73746767500901 35.591 35.67033963693561 139.73746767500901 34.033 35.670365134599116 139.73745361577585 34.033 35.670365134599116 139.73745361577585 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33c675a8-4e5d-41c3-860b-66fd9e81328f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33c675a8-4e5d-41c3-860b-66fd9e81328f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33c675a8-4e5d-41c3-860b-66fd9e81328f">
											<gml:posList>35.67035594649123 139.73743838293038 35.591 35.67035594649123 139.73743838293038 15.216 35.67036079738924 139.73745159949755 15.216 35.67036079738924 139.73745159949755 35.591 35.67035594649123 139.73743838293038 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80f19982-f25f-480e-8bd7-5369d05ec214">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80f19982-f25f-480e-8bd7-5369d05ec214">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80f19982-f25f-480e-8bd7-5369d05ec214">
											<gml:posList>35.67035607438478 139.7374858043536 35.591 35.67035607438478 139.7374858043536 38.043 35.6703629218151 139.73748202939436 38.043 35.6703629218151 139.73748202939436 35.591 35.67035607438478 139.7374858043536 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e1a164b-e260-4e50-a37a-3cc15ea1e65d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e1a164b-e260-4e50-a37a-3cc15ea1e65d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e1a164b-e260-4e50-a37a-3cc15ea1e65d">
											<gml:posList>35.67035607438478 139.7374858043536 35.591 35.6703629218151 139.73748202939436 35.591 35.6703629218151 139.73748202939436 34.033 35.67035607438478 139.7374858043536 34.033 35.67035607438478 139.7374858043536 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee750af3-f059-464a-b2c8-13c9e040cf08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee750af3-f059-464a-b2c8-13c9e040cf08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee750af3-f059-464a-b2c8-13c9e040cf08">
											<gml:posList>35.67036028370132 139.73744039920786 35.591 35.670365134599116 139.73745361577585 35.591 35.670365134599116 139.73745361577585 34.033 35.670360292715046 139.73744039919708 34.033 35.67036028370132 139.73744039920786 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4de6e450-3371-49c5-98d5-60fa0f5bf76f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4de6e450-3371-49c5-98d5-60fa0f5bf76f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4de6e450-3371-49c5-98d5-60fa0f5bf76f">
											<gml:posList>35.67033540466083 139.7376996403357 25.665 35.67039090490061 139.737668998087 25.665 35.67039090490061 139.737668998087 25.28 35.67033540466083 139.7376996403357 25.28 35.67033540466083 139.7376996403357 25.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da98db9d-09d4-4785-a598-27982b89a906">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da98db9d-09d4-4785-a598-27982b89a906">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da98db9d-09d4-4785-a598-27982b89a906">
											<gml:posList>35.6703629218151 139.73748202939436 35.591 35.6703629218151 139.73748202939436 38.043 35.67036417743066 139.73748543014045 38.043 35.67036417743066 139.73748543014045 35.591 35.6703629218151 139.73748202939436 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76ea50b3-3d7e-4282-82af-12f238da359f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76ea50b3-3d7e-4282-82af-12f238da359f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76ea50b3-3d7e-4282-82af-12f238da359f">
											<gml:posList>35.6703629218151 139.73748202939436 35.591 35.67036417743066 139.73748543014045 35.591 35.67036417743066 139.73748543014045 34.033 35.6703629218151 139.73748202939436 34.033 35.6703629218151 139.73748202939436 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82900fec-61b6-47bd-a90e-a74d4a06801e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82900fec-61b6-47bd-a90e-a74d4a06801e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82900fec-61b6-47bd-a90e-a74d4a06801e">
											<gml:posList>35.670371178064826 139.73752692256247 38.043 35.67035607438478 139.7374858043536 38.043 35.67035607438478 139.7374858043536 35.591 35.670371178064826 139.73752692256247 35.591 35.670371178064826 139.73752692256247 38.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e58fc453-432c-4f54-bbca-ccf1c5f05e1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e58fc453-432c-4f54-bbca-ccf1c5f05e1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e58fc453-432c-4f54-bbca-ccf1c5f05e1e">
											<gml:posList>35.670371178064826 139.73752692256247 35.591 35.67035607438478 139.7374858043536 35.591 35.67035607438478 139.7374858043536 34.033 35.670371178064826 139.73752692256247 34.033 35.670371178064826 139.73752692256247 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e1c31d1-20ac-4394-96c1-8610ee91f3c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e1c31d1-20ac-4394-96c1-8610ee91f3c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e1c31d1-20ac-4394-96c1-8610ee91f3c4">
											<gml:posList>35.67037578115642 139.73767062888578 29.335 35.67037210454136 139.73766052594635 29.335 35.67037210454136 139.73766052594635 25.665 35.67037578115642 139.73767062888578 25.665 35.67037578115642 139.73767062888578 29.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21b789a9-d5cf-43f7-a4f5-e965c565d30a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21b789a9-d5cf-43f7-a4f5-e965c565d30a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21b789a9-d5cf-43f7-a4f5-e965c565d30a">
											<gml:posList>35.67037578115642 139.73767062888578 25.665 35.67037210454136 139.73766052594635 25.665 35.67037210454136 139.73766052594635 25.28 35.67037578115642 139.73767062888578 25.28 35.67037578115642 139.73767062888578 25.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-febc0a31-21da-4e7d-876b-e3a0d5071840">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-febc0a31-21da-4e7d-876b-e3a0d5071840">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-febc0a31-21da-4e7d-876b-e3a0d5071840">
											<gml:posList>35.67037448315463 139.73765925278835 29.335 35.67037740095851 139.73766726889045 29.335 35.67037740095851 139.73766726889045 29.026 35.67037448315463 139.73765925278835 29.026 35.67037448315463 139.73765925278835 29.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df39361b-0cd8-4f1b-90fe-9284c47413c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df39361b-0cd8-4f1b-90fe-9284c47413c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df39361b-0cd8-4f1b-90fe-9284c47413c2">
											<gml:posList>35.67036417743066 139.73748543014045 35.591 35.67038890024143 139.73747178054666 35.591 35.67038890024143 139.73747178054666 34.033 35.67036417743066 139.73748543014045 34.033 35.67036417743066 139.73748543014045 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5776b9ea-661e-47e3-a51f-78692e7830a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5776b9ea-661e-47e3-a51f-78692e7830a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5776b9ea-661e-47e3-a51f-78692e7830a5">
											<gml:posList>35.67036417743066 139.73748543014045 35.591 35.67036417743066 139.73748543014045 38.043 35.67038890024143 139.73747178054666 38.043 35.67038890024143 139.73747178054666 35.591 35.67036417743066 139.73748543014045 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd53ac24-4fe5-4770-85a1-bede16c8de45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd53ac24-4fe5-4770-85a1-bede16c8de45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd53ac24-4fe5-4770-85a1-bede16c8de45">
											<gml:posList>35.67041248282845 139.73740722007906 15.216 35.67035594649123 139.73743838293038 15.216 35.67035594649123 139.73743838293038 35.591 35.67041248282845 139.73740722007906 35.591 35.67041248282845 139.73740722007906 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-753b9959-1ec4-4cf7-8126-a0bf6dfa3a14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-753b9959-1ec4-4cf7-8126-a0bf6dfa3a14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-753b9959-1ec4-4cf7-8126-a0bf6dfa3a14">
											<gml:posList>35.67041083755 139.73741253530017 35.591 35.67036028370132 139.73744039920786 35.591 35.670360292715046 139.73744039919708 34.033 35.67041083755 139.73741253530017 34.033 35.67041083755 139.73741253530017 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4295135-24d0-4607-bc06-4c02fda39df0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4295135-24d0-4607-bc06-4c02fda39df0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4295135-24d0-4607-bc06-4c02fda39df0">
											<gml:posList>35.67039702470004 139.73766833905572 29.335 35.67037578115642 139.73767062888578 29.335 35.67037578115642 139.73767062888578 25.665 35.67039090490061 139.737668998087 25.665 35.67039702470004 139.73766833905572 25.665 35.67039702470004 139.73766833905572 29.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a34abb9c-4247-479f-85c2-211e0dd06a08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a34abb9c-4247-479f-85c2-211e0dd06a08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a34abb9c-4247-479f-85c2-211e0dd06a08">
											<gml:posList>35.67037740095851 139.73766726889045 29.335 35.670396364223485 139.73766522479806 29.335 35.670396364223485 139.73766522479806 29.026 35.67037740095851 139.73766726889045 29.026 35.67037740095851 139.73766726889045 29.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b582a19-e0a4-4bde-84a1-3a795381df0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b582a19-e0a4-4bde-84a1-3a795381df0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b582a19-e0a4-4bde-84a1-3a795381df0f">
											<gml:posList>35.67040275732515 139.73750949801072 35.591 35.67040275732515 139.73750949801072 38.043 35.670371178064826 139.73752692256247 38.043 35.670371178064826 139.73752692256247 35.591 35.67040275732515 139.73750949801072 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79d0d9d3-4931-4fe3-9ae0-77363d68f201">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79d0d9d3-4931-4fe3-9ae0-77363d68f201">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79d0d9d3-4931-4fe3-9ae0-77363d68f201">
											<gml:posList>35.67040275732515 139.73750949801072 35.591 35.670371178064826 139.73752692256247 35.591 35.670371178064826 139.73752692256247 34.033 35.67040275732515 139.73750949801072 34.033 35.67040275732515 139.73750949801072 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db6fb750-6f6e-458e-8529-92e760e74b2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db6fb750-6f6e-458e-8529-92e760e74b2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db6fb750-6f6e-458e-8529-92e760e74b2e">
											<gml:posList>35.67032084001982 139.73765620175664 35.591 35.67047009603429 139.73757387252533 35.591 35.67047009603429 139.73757387252533 34.033 35.67032084001982 139.73765620175664 34.033 35.67032084001982 139.73765620175664 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c793b444-821f-41e1-96bd-afd7be69a7a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c793b444-821f-41e1-96bd-afd7be69a7a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c793b444-821f-41e1-96bd-afd7be69a7a2">
											<gml:posList>35.67038890024143 139.73747178054666 35.591 35.67040275732515 139.73750949801072 35.591 35.67040275732515 139.73750949801072 34.033 35.67038890024143 139.73747178054666 34.033 35.67038890024143 139.73747178054666 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25b5f4a2-6620-4233-87a7-092cc798c5a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25b5f4a2-6620-4233-87a7-092cc798c5a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25b5f4a2-6620-4233-87a7-092cc798c5a5">
											<gml:posList>35.67038890024143 139.73747178054666 35.591 35.67038890024143 139.73747178054666 38.043 35.67040275732515 139.73750949801072 38.043 35.67040275732515 139.73750949801072 35.591 35.67038890024143 139.73747178054666 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78231d9c-2662-4f09-9dd4-ab0728a65d45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78231d9c-2662-4f09-9dd4-ab0728a65d45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78231d9c-2662-4f09-9dd4-ab0728a65d45">
											<gml:posList>35.67047443324205 139.73757588881298 35.591 35.67031919473909 139.73766152801284 35.591 35.67031919473909 139.73766152801284 31.911 35.67032156431236 139.73766022172774 31.911 35.67047206366977 139.7375771951031 31.911 35.67047443324205 139.73757588881298 31.911 35.67047443324205 139.73757588881298 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19130c6a-ecac-4058-97ce-e4322e787127">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19130c6a-ecac-4058-97ce-e4322e787127">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19130c6a-ecac-4058-97ce-e4322e787127">
											<gml:posList>35.67032892643262 139.7376802729366 31.911 35.67048008521937 139.73759902400448 31.911 35.67048008521937 139.73759902400448 31.602 35.67032892643262 139.7376802729366 31.602 35.67032892643262 139.7376802729366 31.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91fd5d67-26bc-406f-a7ff-f2be5a6bb5ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91fd5d67-26bc-406f-a7ff-f2be5a6bb5ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91fd5d67-26bc-406f-a7ff-f2be5a6bb5ab">
											<gml:posList>35.670327613746004 139.73768444998586 31.911 35.670327613746004 139.73768444998586 25.665 35.67032946076933 139.73768345361972 25.665 35.67037210454136 139.73766052594635 25.665 35.67037210454136 139.73766052594635 29.335 35.67037448315463 139.73765925278835 29.335 35.670481151139484 139.73760191685525 29.335 35.670483520738365 139.73760064370452 29.335 35.670483520738365 139.73760064370452 31.911 35.670327613746004 139.73768444998586 31.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c0e4be9-9053-4479-8ea7-bb46da90303e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c0e4be9-9053-4479-8ea7-bb46da90303e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c0e4be9-9053-4479-8ea7-bb46da90303e">
											<gml:posList>35.67041088892005 139.73752234614284 35.591 35.67041088892005 139.73752234614284 38.079 35.67040326482181 139.73750159932663 38.079 35.67040326482181 139.73750159932663 35.591 35.67041088892005 139.73752234614284 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3e8b402-4e1e-4f4c-880c-dcf8447016d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3e8b402-4e1e-4f4c-880c-dcf8447016d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3e8b402-4e1e-4f4c-880c-dcf8447016d2">
											<gml:posList>35.67041088892005 139.73752234614284 35.591 35.67040326482181 139.73750159932663 35.591 35.67040326482181 139.73750159932663 34.033 35.67041088892005 139.73752234614284 34.033 35.67041088892005 139.73752234614284 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9601eada-7c60-423c-bfd1-ab227d0fa722">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9601eada-7c60-423c-bfd1-ab227d0fa722">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9601eada-7c60-423c-bfd1-ab227d0fa722">
											<gml:posList>35.67048726665377 139.73761854524187 26.515 35.67048962721277 139.7376172389635 26.515 35.67048962721277 139.7376172389635 29.335 35.67039702470004 139.73766833905572 29.335 35.67039702470004 139.73766833905572 25.665 35.670334388707026 139.73770291123836 25.665 35.670334388707026 139.73770291123836 15.216 35.6704338566721 139.73764800311739 15.216 35.6704338566721 139.73764800311739 26.515 35.67043622624515 139.73764669683 26.515 35.67048726665377 139.73761854524187 26.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1e44f7b-47c3-4ecb-a9a3-f422b7bf8a98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1e44f7b-47c3-4ecb-a9a3-f422b7bf8a98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1e44f7b-47c3-4ecb-a9a3-f422b7bf8a98">
											<gml:posList>35.67040326482181 139.73750159932663 35.591 35.67042669023861 139.73748868033562 35.591 35.67042669023861 139.73748868033562 34.033 35.67040326482181 139.73750159932663 34.033 35.67040326482181 139.73750159932663 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f603560-3325-4a6d-9cf3-b41803cf392d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f603560-3325-4a6d-9cf3-b41803cf392d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f603560-3325-4a6d-9cf3-b41803cf392d">
											<gml:posList>35.67040326482181 139.73750159932663 35.591 35.67040326482181 139.73750159932663 38.079 35.67042669023861 139.73748868033562 38.079 35.67042669023861 139.73748868033562 35.591 35.67040326482181 139.73750159932663 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-725e8548-c48c-4f10-8025-225e78522ad4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-725e8548-c48c-4f10-8025-225e78522ad4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-725e8548-c48c-4f10-8025-225e78522ad4">
											<gml:posList>35.6704194842488 139.73751760807028 35.591 35.67041088892005 139.73752234614284 35.591 35.67041088892005 139.73752234614284 34.033 35.6704194842488 139.73751760807028 34.033 35.6704194842488 139.73751760807028 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-779935b5-1834-4532-b6ca-b18c6fc9d46f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-779935b5-1834-4532-b6ca-b18c6fc9d46f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-779935b5-1834-4532-b6ca-b18c6fc9d46f">
											<gml:posList>35.67043494747706 139.73747818755774 35.591 35.67041083755 139.73741253530017 35.591 35.67041083755 139.73741253530017 34.033 35.67043494747706 139.73747818755774 34.033 35.67043494747706 139.73747818755774 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-221cc10f-1f6c-4c81-b8e4-3f354d95f145">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-221cc10f-1f6c-4c81-b8e4-3f354d95f145">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-221cc10f-1f6c-4c81-b8e4-3f354d95f145">
											<gml:posList>35.67042669023861 139.73748868033562 35.591 35.6704248745502 139.7374837448255 35.591 35.6704248745502 139.7374837448255 34.033 35.67042669023861 139.73748868033562 34.033 35.67042669023861 139.73748868033562 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50c49dcf-a40b-4806-9a57-3d6b175c71fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50c49dcf-a40b-4806-9a57-3d6b175c71fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50c49dcf-a40b-4806-9a57-3d6b175c71fc">
											<gml:posList>35.67042669023861 139.73748868033562 35.591 35.67042669023861 139.73748868033562 38.079 35.6704248745502 139.7374837448255 38.079 35.6704248745502 139.7374837448255 35.591 35.67042669023861 139.73748868033562 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85f52b1b-fae0-48df-94a6-49be8a34bd2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85f52b1b-fae0-48df-94a6-49be8a34bd2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85f52b1b-fae0-48df-94a6-49be8a34bd2d">
											<gml:posList>35.67043391041268 139.7375568713542 35.591 35.67043391041268 139.7375568713542 37.418 35.6704194842488 139.73751760807028 37.418 35.6704194842488 139.73751760807028 35.591 35.67043391041268 139.7375568713542 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c273011-9823-40c1-9d00-a5756d8e9d57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c273011-9823-40c1-9d00-a5756d8e9d57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c273011-9823-40c1-9d00-a5756d8e9d57">
											<gml:posList>35.67043391041268 139.7375568713542 35.591 35.6704194842488 139.73751760807028 35.591 35.6704194842488 139.73751760807028 34.033 35.67043391041268 139.7375568713542 34.033 35.67043391041268 139.7375568713542 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6461e33-145c-41e9-93f1-885ac4cb5566">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6461e33-145c-41e9-93f1-885ac4cb5566">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6461e33-145c-41e9-93f1-885ac4cb5566">
											<gml:posList>35.670481151139484 139.73760191685525 29.335 35.67037448315463 139.73765925278835 29.335 35.67037448315463 139.73765925278835 29.026 35.670481151139484 139.73760191685525 29.026 35.670481151139484 139.73760191685525 29.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-834daa01-5ae4-4f3d-93c2-69a544558e85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-834daa01-5ae4-4f3d-93c2-69a544558e85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-834daa01-5ae4-4f3d-93c2-69a544558e85">
											<gml:posList>35.67041088892005 139.73752234614284 38.079 35.67041088892005 139.73752234614284 35.591 35.6704194842488 139.73751760807028 35.591 35.6704194842488 139.73751760807028 37.418 35.670447378512854 139.73750222042227 37.418 35.670447378512854 139.73750222042227 38.079 35.67041088892005 139.73752234614284 38.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-044a3e1a-747c-487f-bcc7-593cf4eb43a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-044a3e1a-747c-487f-bcc7-593cf4eb43a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-044a3e1a-747c-487f-bcc7-593cf4eb43a2">
											<gml:posList>35.6704248745502 139.7374837448255 35.591 35.67043494747706 139.73747818755774 35.591 35.67043494747706 139.73747818755774 34.033 35.6704248745502 139.7374837448255 34.033 35.6704248745502 139.7374837448255 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c147f3d7-a91a-4aac-ac2c-04a67014d5f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c147f3d7-a91a-4aac-ac2c-04a67014d5f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c147f3d7-a91a-4aac-ac2c-04a67014d5f4">
											<gml:posList>35.67043793871369 139.73747652704157 38.079 35.67043793872248 139.7374765380878 35.591 35.67043494747706 139.73747818755774 35.591 35.6704248745502 139.7374837448255 35.591 35.6704248745502 139.7374837448255 38.079 35.67043793871369 139.73747652704157 38.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f45bf23-c755-4ec9-b50a-41db80601bce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f45bf23-c755-4ec9-b50a-41db80601bce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f45bf23-c755-4ec9-b50a-41db80601bce">
											<gml:posList>35.6704338566721 139.73764800311739 15.216 35.67043972823033 139.73766390273514 15.216 35.67043972823033 139.73766390273514 26.515 35.6704338566721 139.73764800311739 26.515 35.6704338566721 139.73764800311739 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f23de579-be9d-4cd7-9ecc-d1528f44d564">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f23de579-be9d-4cd7-9ecc-d1528f44d564">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f23de579-be9d-4cd7-9ecc-d1528f44d564">
											<gml:posList>35.67043622624515 139.73764669683 26.515 35.67044102287118 139.73765970360867 26.515 35.67044102287118 139.73765970360867 26.206 35.67043622624515 139.73764669683 26.206 35.67043622624515 139.73764669683 26.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ebc8881-cacd-4be9-94d2-292777b19d89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ebc8881-cacd-4be9-94d2-292777b19d89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ebc8881-cacd-4be9-94d2-292777b19d89">
											<gml:posList>35.670396364223485 139.73766522479806 29.335 35.67048619171156 139.7376156413551 29.335 35.67048619171156 139.7376156413551 29.026 35.670396364223485 139.73766522479806 29.026 35.670396364223485 139.73766522479806 29.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fdbd1c8-54f4-424a-ad19-beb0cadb9263">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fdbd1c8-54f4-424a-ad19-beb0cadb9263">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fdbd1c8-54f4-424a-ad19-beb0cadb9263">
											<gml:posList>35.670458804421685 139.73754313319583 35.591 35.67043391041268 139.7375568713542 35.591 35.67043391041268 139.7375568713542 34.033 35.670458804430474 139.73754314424207 34.033 35.670458804421685 139.73754313319583 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23d76861-5484-4ee8-80bb-c43e7490155d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23d76861-5484-4ee8-80bb-c43e7490155d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23d76861-5484-4ee8-80bb-c43e7490155d">
											<gml:posList>35.67046179566799 139.7375414837278 35.591 35.67046179566799 139.7375414837278 37.418 35.67043391041268 139.7375568713542 37.418 35.67043391041268 139.7375568713542 35.591 35.670458804421685 139.73754313319583 35.591 35.67046179566799 139.7375414837278 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7ff298a-3c61-44ce-9990-9cb1283a3ded">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7ff298a-3c61-44ce-9990-9cb1283a3ded">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7ff298a-3c61-44ce-9990-9cb1283a3ded">
											<gml:posList>35.67043793872248 139.7374765380878 35.591 35.67043793871369 139.73747652704157 38.079 35.670447378512854 139.73750222042227 38.079 35.670447378512854 139.73750222042227 37.418 35.67046179566799 139.7375414837278 37.418 35.67046179566799 139.7375414837278 35.591 35.67043793872248 139.7374765380878 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-737c07a3-ce3c-4df2-9dd3-00a5a77cbdf8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-737c07a3-ce3c-4df2-9dd3-00a5a77cbdf8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-737c07a3-ce3c-4df2-9dd3-00a5a77cbdf8">
											<gml:posList>35.67047443324205 139.73757588881298 31.911 35.670483520738365 139.73760064370452 31.911 35.670483520738365 139.73760064370452 29.335 35.67048962721277 139.7376172389635 29.335 35.67048962721277 139.7376172389635 26.515 35.670495498854045 139.73763323800642 26.515 35.670495498854045 139.73763323800642 15.216 35.67041248282845 139.73740722007906 15.216 35.67041248282845 139.73740722007906 35.591 35.67043793872248 139.7374765380878 35.591 35.67046179566799 139.7375414837278 35.591 35.67047443324205 139.73757588881298 35.591 35.67047443324205 139.73757588881298 31.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2085935-2faa-4549-af4a-0c9c1e8d6e74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2085935-2faa-4549-af4a-0c9c1e8d6e74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2085935-2faa-4549-af4a-0c9c1e8d6e74">
											<gml:posList>35.6704601503924 139.7375468099957 35.591 35.670458804421685 139.73754313319583 35.591 35.670458804430474 139.73754314424207 34.033 35.6704601503924 139.7375468099957 34.033 35.6704601503924 139.7375468099957 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4659a123-9084-469f-9d1d-0203db521615">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4659a123-9084-469f-9d1d-0203db521615">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4659a123-9084-469f-9d1d-0203db521615">
											<gml:posList>35.67047009603429 139.73757387252533 35.591 35.6704601503924 139.7375468099957 35.591 35.6704601503924 139.7375468099957 34.033 35.67047009603429 139.73757387252533 34.033 35.67047009603429 139.73757387252533 35.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2489d258-a3ff-4de9-af6e-0826b6a6a4cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2489d258-a3ff-4de9-af6e-0826b6a6a4cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2489d258-a3ff-4de9-af6e-0826b6a6a4cb">
											<gml:posList>35.67044102287118 139.73765970360867 26.515 35.67049207236677 139.73763164038647 26.515 35.67049207236677 139.73763164038647 26.206 35.67044102287118 139.73765970360867 26.206 35.67044102287118 139.73765970360867 26.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e1015b7-b995-4756-8993-6e2cae9ae872">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e1015b7-b995-4756-8993-6e2cae9ae872">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e1015b7-b995-4756-8993-6e2cae9ae872">
											<gml:posList>35.67043972823033 139.73766390273514 15.216 35.670495498854045 139.73763323800642 15.216 35.670495498854045 139.73763323800642 26.515 35.67043972823033 139.73766390273514 26.515 35.67043972823033 139.73766390273514 15.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7059b462-5f5c-4971-8eb8-1d2a21639eaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7059b462-5f5c-4971-8eb8-1d2a21639eaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7059b462-5f5c-4971-8eb8-1d2a21639eaa">
											<gml:posList>35.67048008521937 139.73759902400448 31.911 35.67047206366977 139.7375771951031 31.911 35.67047206366977 139.7375771951031 31.602 35.67048008521937 139.73759902400448 31.602 35.67048008521937 139.73759902400448 31.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28809786-9fd8-485a-a5aa-d8d4fe6a119d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28809786-9fd8-485a-a5aa-d8d4fe6a119d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28809786-9fd8-485a-a5aa-d8d4fe6a119d">
											<gml:posList>35.67048619171156 139.7376156413551 29.335 35.670481151139484 139.73760191685525 29.335 35.670481151139484 139.73760191685525 29.026 35.67048619171156 139.7376156413551 29.026 35.67048619171156 139.7376156413551 29.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2a1c1a3-e29b-43a0-b4d8-79cc5c7de9bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2a1c1a3-e29b-43a0-b4d8-79cc5c7de9bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2a1c1a3-e29b-43a0-b4d8-79cc5c7de9bb">
											<gml:posList>35.67049207236677 139.73763164038647 26.515 35.67048726665377 139.73761854524187 26.515 35.67048726665377 139.73761854524187 26.206 35.67049207236677 139.73763164038647 26.206 35.67049207236677 139.73763164038647 26.515</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂六丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6207</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">404.59035</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>