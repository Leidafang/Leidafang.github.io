<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_85b4fdbc-b537-4dba-a25d-968359ccf599">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">6.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66665569644735 139.73758016199437 0 35.66668412955454 139.73763027574728 0 35.666746819434834 139.73757276298346 0 35.6667481705277 139.7375715463365 0 35.666718656891554 139.73752286980368 0 35.66665569644735 139.73758016199437 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66665569644735 139.73758016199437 13.95 35.666718656891554 139.73752286980368 13.95 35.6667481705277 139.7375715463365 13.95 35.666746819434834 139.73757276298346 13.95 35.66668412955454 139.73763027574728 13.95 35.66665569644735 139.73758016199437 13.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66665569644735 139.73758016199437 13.95 35.66668412955454 139.73763027574728 13.95 35.66668412955454 139.73763027574728 20.75 35.66665569644735 139.73758016199437 20.75 35.66665569644735 139.73758016199437 13.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66668412955454 139.73763027574728 13.95 35.666746819434834 139.73757276298346 13.95 35.666746819434834 139.73757276298346 20.75 35.66668412955454 139.73763027574728 20.75 35.66668412955454 139.73763027574728 13.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666746819434834 139.73757276298346 13.95 35.6667481705277 139.7375715463365 13.95 35.6667481705277 139.7375715463365 20.75 35.666746819434834 139.73757276298346 20.75 35.666746819434834 139.73757276298346 13.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6667481705277 139.7375715463365 13.95 35.666718656891554 139.73752286980368 13.95 35.666718656891554 139.73752286980368 20.75 35.6667481705277 139.7375715463365 20.75 35.6667481705277 139.7375715463365 13.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666718656891554 139.73752286980368 13.95 35.66665569644735 139.73758016199437 13.95 35.66665569644735 139.73758016199437 20.75 35.666718656891554 139.73752286980368 20.75 35.666718656891554 139.73752286980368 13.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66665569644735 139.73758016199437 20.75 35.66668412955454 139.73763027574728 20.75 35.666746819434834 139.73757276298346 20.75 35.6667481705277 139.7375715463365 20.75 35.666718656891554 139.73752286980368 20.75 35.66665569644735 139.73758016199437 20.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3546907e-8a8e-4d54-9720-8aabf2ed6666"/>
							<gml:surfaceMember xlink:href="#poly-1f0ebc4b-55ea-4486-b9e7-8da236d0c6c9"/>
							<gml:surfaceMember xlink:href="#poly-fb1381b7-dd5b-4310-9978-5a16ee8fd43f"/>
							<gml:surfaceMember xlink:href="#poly-74dac5a7-f73a-456f-a980-949e44f2f1b9"/>
							<gml:surfaceMember xlink:href="#poly-5f5a5ce3-717e-448f-8ca0-dc5a5a0df4a6"/>
							<gml:surfaceMember xlink:href="#poly-d0e4e5d3-021b-4531-a7a1-b4f57051fa51"/>
							<gml:surfaceMember xlink:href="#poly-2fc63ee2-ba06-40e2-8d53-0750db4b40d0"/>
							<gml:surfaceMember xlink:href="#poly-f27ee9eb-e1b4-4a95-98ab-94b5b403f924"/>
							<gml:surfaceMember xlink:href="#poly-c13b69a1-0c88-42d4-afcc-209516759b22"/>
							<gml:surfaceMember xlink:href="#poly-84da910d-66de-4463-9731-786375a1e020"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3546907e-8a8e-4d54-9720-8aabf2ed6666">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3546907e-8a8e-4d54-9720-8aabf2ed6666">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3546907e-8a8e-4d54-9720-8aabf2ed6666">
											<gml:posList>35.666718656891554 139.73752286980366 13.95 35.6667481705277 139.7375715463365 13.95 35.66674681943481 139.73757276298346 13.95 35.66668412955451 139.73763027574728 13.95 35.666655696447314 139.73758016199437 13.95 35.666718656891554 139.73752286980366 13.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f0ebc4b-55ea-4486-b9e7-8da236d0c6c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f0ebc4b-55ea-4486-b9e7-8da236d0c6c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f0ebc4b-55ea-4486-b9e7-8da236d0c6c9">
											<gml:posList>35.6667481705277 139.7375715463365 20.705 35.666718656891554 139.73752286980366 20.705 35.666703419927124 139.73757481409217 21.457 35.6667481705277 139.7375715463365 20.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb1381b7-dd5b-4310-9978-5a16ee8fd43f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb1381b7-dd5b-4310-9978-5a16ee8fd43f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb1381b7-dd5b-4310-9978-5a16ee8fd43f">
											<gml:posList>35.666703419927124 139.73757481409217 21.457 35.666718656891554 139.73752286980366 20.705 35.666655696447314 139.73758016199437 20.705 35.666703419927124 139.73757481409217 21.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74dac5a7-f73a-456f-a980-949e44f2f1b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74dac5a7-f73a-456f-a980-949e44f2f1b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74dac5a7-f73a-456f-a980-949e44f2f1b9">
											<gml:posList>35.666703419927124 139.73757481409217 21.457 35.66668412955451 139.73763027574728 20.705 35.66674681943481 139.73757276298346 20.705 35.6667481705277 139.7375715463365 20.705 35.666703419927124 139.73757481409217 21.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f5a5ce3-717e-448f-8ca0-dc5a5a0df4a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f5a5ce3-717e-448f-8ca0-dc5a5a0df4a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f5a5ce3-717e-448f-8ca0-dc5a5a0df4a6">
											<gml:posList>35.666655696447314 139.73758016199437 20.705 35.66668412955451 139.73763027574728 20.705 35.666703419927124 139.73757481409217 21.457 35.666655696447314 139.73758016199437 20.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0e4e5d3-021b-4531-a7a1-b4f57051fa51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0e4e5d3-021b-4531-a7a1-b4f57051fa51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0e4e5d3-021b-4531-a7a1-b4f57051fa51">
											<gml:posList>35.6667481705277 139.7375715463365 13.95 35.666718656891554 139.73752286980366 13.95 35.666718656891554 139.73752286980366 20.705 35.6667481705277 139.7375715463365 20.705 35.6667481705277 139.7375715463365 13.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2fc63ee2-ba06-40e2-8d53-0750db4b40d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fc63ee2-ba06-40e2-8d53-0750db4b40d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fc63ee2-ba06-40e2-8d53-0750db4b40d0">
											<gml:posList>35.666718656891554 139.73752286980366 13.95 35.666655696447314 139.73758016199437 13.95 35.666655696447314 139.73758016199437 20.705 35.666718656891554 139.73752286980366 20.705 35.666718656891554 139.73752286980366 13.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f27ee9eb-e1b4-4a95-98ab-94b5b403f924">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f27ee9eb-e1b4-4a95-98ab-94b5b403f924">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f27ee9eb-e1b4-4a95-98ab-94b5b403f924">
											<gml:posList>35.66674681943481 139.73757276298346 13.95 35.6667481705277 139.7375715463365 13.95 35.6667481705277 139.7375715463365 20.705 35.66674681943481 139.73757276298346 20.705 35.66674681943481 139.73757276298346 13.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c13b69a1-0c88-42d4-afcc-209516759b22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c13b69a1-0c88-42d4-afcc-209516759b22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c13b69a1-0c88-42d4-afcc-209516759b22">
											<gml:posList>35.66668412955451 139.73763027574728 13.95 35.66674681943481 139.73757276298346 13.95 35.66674681943481 139.73757276298346 20.705 35.66668412955451 139.73763027574728 20.705 35.66668412955451 139.73763027574728 13.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84da910d-66de-4463-9731-786375a1e020">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84da910d-66de-4463-9731-786375a1e020">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84da910d-66de-4463-9731-786375a1e020">
											<gml:posList>35.666655696447314 139.73758016199437 13.95 35.66668412955451 139.73763027574728 13.95 35.66668412955451 139.73763027574728 20.705 35.666655696447314 139.73758016199437 20.705 35.666655696447314 139.73758016199437 13.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3087</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">48.378</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">5</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">2</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>