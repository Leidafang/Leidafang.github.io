<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_85bff174-02f2-4eba-8e0e-ceb158cda2a2">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>赤坂一丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">5.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669532789310814 139.74353377842053 0 35.66953194270206 139.74354678067888 0 35.66951541932554 139.74354516435312 0 35.669512184834446 139.7435954610514 0 35.66950748833809 139.74359500236986 0 35.66950927078789 139.7435677716404 0 35.66947788266768 139.74356468072457 0 35.66947610021031 139.74359190039732 0 35.66946008163582 139.7435903276829 0 35.66945410999479 139.74368102311192 0 35.669479079822025 139.7436834253421 0 35.66947337597578 139.74377069618484 0 35.66955216168174 139.7437783404817 0 35.669567837250874 139.74353719661198 0 35.669532789310814 139.74353377842053 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669532789310814 139.74353377842053 10.367 35.669567837250874 139.74353719661198 10.367 35.66955216168174 139.7437783404817 10.367 35.66947337597578 139.74377069618484 10.367 35.669479079822025 139.7436834253421 10.367 35.66945410999479 139.74368102311192 10.367 35.66946008163582 139.7435903276829 10.367 35.66947610021031 139.74359190039732 10.367 35.66947788266768 139.74356468072457 10.367 35.66950927078789 139.7435677716404 10.367 35.66950748833809 139.74359500236986 10.367 35.669512184834446 139.7435954610514 10.367 35.66951541932554 139.74354516435312 10.367 35.66953194270206 139.74354678067888 10.367 35.669532789310814 139.74353377842053 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669532789310814 139.74353377842053 10.367 35.66953194270206 139.74354678067888 10.367 35.66953194270206 139.74354678067888 15.6 35.669532789310814 139.74353377842053 15.6 35.669532789310814 139.74353377842053 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66953194270206 139.74354678067888 10.367 35.66951541932554 139.74354516435312 10.367 35.66951541932554 139.74354516435312 15.6 35.66953194270206 139.74354678067888 15.6 35.66953194270206 139.74354678067888 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66951541932554 139.74354516435312 10.367 35.669512184834446 139.7435954610514 10.367 35.669512184834446 139.7435954610514 15.6 35.66951541932554 139.74354516435312 15.6 35.66951541932554 139.74354516435312 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669512184834446 139.7435954610514 10.367 35.66950748833809 139.74359500236986 10.367 35.66950748833809 139.74359500236986 15.6 35.669512184834446 139.7435954610514 15.6 35.669512184834446 139.7435954610514 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66950748833809 139.74359500236986 10.367 35.66950927078789 139.7435677716404 10.367 35.66950927078789 139.7435677716404 15.6 35.66950748833809 139.74359500236986 15.6 35.66950748833809 139.74359500236986 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66950927078789 139.7435677716404 10.367 35.66947788266768 139.74356468072457 10.367 35.66947788266768 139.74356468072457 15.6 35.66950927078789 139.7435677716404 15.6 35.66950927078789 139.7435677716404 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66947788266768 139.74356468072457 10.367 35.66947610021031 139.74359190039732 10.367 35.66947610021031 139.74359190039732 15.6 35.66947788266768 139.74356468072457 15.6 35.66947788266768 139.74356468072457 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66947610021031 139.74359190039732 10.367 35.66946008163582 139.7435903276829 10.367 35.66946008163582 139.7435903276829 15.6 35.66947610021031 139.74359190039732 15.6 35.66947610021031 139.74359190039732 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66946008163582 139.7435903276829 10.367 35.66945410999479 139.74368102311192 10.367 35.66945410999479 139.74368102311192 15.6 35.66946008163582 139.7435903276829 15.6 35.66946008163582 139.7435903276829 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66945410999479 139.74368102311192 10.367 35.669479079822025 139.7436834253421 10.367 35.669479079822025 139.7436834253421 15.6 35.66945410999479 139.74368102311192 15.6 35.66945410999479 139.74368102311192 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669479079822025 139.7436834253421 10.367 35.66947337597578 139.74377069618484 10.367 35.66947337597578 139.74377069618484 15.6 35.669479079822025 139.7436834253421 15.6 35.669479079822025 139.7436834253421 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66947337597578 139.74377069618484 10.367 35.66955216168174 139.7437783404817 10.367 35.66955216168174 139.7437783404817 15.6 35.66947337597578 139.74377069618484 15.6 35.66947337597578 139.74377069618484 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66955216168174 139.7437783404817 10.367 35.669567837250874 139.74353719661198 10.367 35.669567837250874 139.74353719661198 15.6 35.66955216168174 139.7437783404817 15.6 35.66955216168174 139.7437783404817 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669567837250874 139.74353719661198 10.367 35.669532789310814 139.74353377842053 10.367 35.669532789310814 139.74353377842053 15.6 35.669567837250874 139.74353719661198 15.6 35.669567837250874 139.74353719661198 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669532789310814 139.74353377842053 15.6 35.66953194270206 139.74354678067888 15.6 35.66951541932554 139.74354516435312 15.6 35.669512184834446 139.7435954610514 15.6 35.66950748833809 139.74359500236986 15.6 35.66950927078789 139.7435677716404 15.6 35.66947788266768 139.74356468072457 15.6 35.66947610021031 139.74359190039732 15.6 35.66946008163582 139.7435903276829 15.6 35.66945410999479 139.74368102311192 15.6 35.669479079822025 139.7436834253421 15.6 35.66947337597578 139.74377069618484 15.6 35.66955216168174 139.7437783404817 15.6 35.669567837250874 139.74353719661198 15.6 35.669532789310814 139.74353377842053 15.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-eb78e8bc-207a-435b-a9ba-514b4ee98181"/>
							<gml:surfaceMember xlink:href="#poly-c12c4f4a-aa32-4177-ad3d-0479dae53cc8"/>
							<gml:surfaceMember xlink:href="#poly-ae915944-ba22-4036-a836-cbc28ce955b0"/>
							<gml:surfaceMember xlink:href="#poly-996ee944-612f-461d-9add-2cdde1ef68a7"/>
							<gml:surfaceMember xlink:href="#poly-af5cb256-92d6-469d-8479-b6a2fe38b910"/>
							<gml:surfaceMember xlink:href="#poly-9a6bd342-7356-4608-84ee-8850414d6da9"/>
							<gml:surfaceMember xlink:href="#poly-8d854f0b-4c07-45b2-b888-77e077fea458"/>
							<gml:surfaceMember xlink:href="#poly-be59cd88-2008-48a6-897e-c14ef541d40f"/>
							<gml:surfaceMember xlink:href="#poly-f7ac724f-6aa9-41d3-bb1e-3b43d68c35df"/>
							<gml:surfaceMember xlink:href="#poly-9a5d28ca-07bf-4497-bbf1-f7eb70805dd5"/>
							<gml:surfaceMember xlink:href="#poly-de662ecf-9a8f-4da1-9297-c7ec9e3d108e"/>
							<gml:surfaceMember xlink:href="#poly-dbff7b34-a709-4749-a635-cdefab5c4d1e"/>
							<gml:surfaceMember xlink:href="#poly-d4e66b8a-6b01-4f38-aa82-fac20a116420"/>
							<gml:surfaceMember xlink:href="#poly-6e76c452-e329-4755-9b16-eb81578acb42"/>
							<gml:surfaceMember xlink:href="#poly-b41869b1-b55c-4229-a64d-6c27645c6e72"/>
							<gml:surfaceMember xlink:href="#poly-773b4237-b0ba-4a5a-ba6b-e5acc20e5381"/>
							<gml:surfaceMember xlink:href="#poly-1cbfb744-33c1-4b13-a08f-5cd793049a7c"/>
							<gml:surfaceMember xlink:href="#poly-3dfb6497-9666-421c-8c67-cabbecdeb37b"/>
							<gml:surfaceMember xlink:href="#poly-932d6522-7cb4-4a28-9ec8-d87a074c92e1"/>
							<gml:surfaceMember xlink:href="#poly-f60dfb51-da1c-4d20-9c97-512782846085"/>
							<gml:surfaceMember xlink:href="#poly-63df4f2f-c2a6-4c2c-ae38-93a607b682ad"/>
							<gml:surfaceMember xlink:href="#poly-e706e93d-b99c-4738-a3d7-3803b9812f74"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-eb78e8bc-207a-435b-a9ba-514b4ee98181">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb78e8bc-207a-435b-a9ba-514b4ee98181">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb78e8bc-207a-435b-a9ba-514b4ee98181">
											<gml:posList>35.669479079822 139.7436834253421 10.367 35.669454109994795 139.74368102311192 10.367 35.66946008163578 139.7435903276829 10.367 35.66947610021031 139.74359190039732 10.367 35.669477882667664 139.74356468072457 10.367 35.66950927078787 139.74356777164041 10.367 35.66950748833808 139.74359500236986 10.367 35.66951218483444 139.7435954610514 10.367 35.669515419325535 139.74354516435312 10.367 35.66953194270203 139.74354678067886 10.367 35.66953278931081 139.74353377842053 10.367 35.66956783725085 139.74353719661198 10.367 35.66955216168172 139.74377834048167 10.367 35.66947337597577 139.7437706961848 10.367 35.669479079822 139.7436834253421 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c12c4f4a-aa32-4177-ad3d-0479dae53cc8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c12c4f4a-aa32-4177-ad3d-0479dae53cc8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c12c4f4a-aa32-4177-ad3d-0479dae53cc8">
											<gml:posList>35.66951218483444 139.7435954610514 13.4 35.66952775268136 139.74359697904157 13.4 35.66953102323622 139.74354669333937 13.4 35.669515419325535 139.74354516435312 13.4 35.66951218483444 139.7435954610514 13.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ae915944-ba22-4036-a836-cbc28ce955b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae915944-ba22-4036-a836-cbc28ce955b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae915944-ba22-4036-a836-cbc28ce955b0">
											<gml:posList>35.66950927078787 139.74356777164041 13.6 35.669477882667664 139.74356468072457 13.6 35.66947610021031 139.74359190039732 13.6 35.66950748833808 139.74359500236986 13.6 35.66950927078787 139.74356777164041 13.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-996ee944-612f-461d-9add-2cdde1ef68a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-996ee944-612f-461d-9add-2cdde1ef68a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-996ee944-612f-461d-9add-2cdde1ef68a7">
											<gml:posList>35.669479079822 139.7436834253421 15.1 35.66947337597577 139.7437706961848 15.1 35.66955216168172 139.74377834048167 15.1 35.66956783725085 139.74353719661198 15.1 35.66953278931081 139.74353377842053 15.1 35.66953194270203 139.74354678067886 15.1 35.66953102323622 139.74354669333937 15.1 35.669529740009835 139.7435664784177 15.1 35.66956224589746 139.74356965645399 15.1 35.66955920704809 139.7436163961025 15.1 35.66952670116165 139.7436132180474 15.1 35.66952775268136 139.74359697904157 15.1 35.66946008163578 139.7435903276829 15.1 35.669454109994795 139.74368102311192 15.1 35.669479079822 139.7436834253421 15.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af5cb256-92d6-469d-8479-b6a2fe38b910">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af5cb256-92d6-469d-8479-b6a2fe38b910">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af5cb256-92d6-469d-8479-b6a2fe38b910">
											<gml:posList>35.66956224589746 139.74356965645399 17.64 35.669529740009835 139.7435664784177 17.64 35.66952670116165 139.7436132180474 17.64 35.66955920704809 139.7436163961025 17.64 35.66956224589746 139.74356965645399 17.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a6bd342-7356-4608-84ee-8850414d6da9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a6bd342-7356-4608-84ee-8850414d6da9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a6bd342-7356-4608-84ee-8850414d6da9">
											<gml:posList>35.66956783725085 139.74353719661198 10.367 35.66953278931081 139.74353377842053 10.367 35.66953278931081 139.74353377842053 15.1 35.66956783725085 139.74353719661198 15.1 35.66956783725085 139.74353719661198 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d854f0b-4c07-45b2-b888-77e077fea458">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d854f0b-4c07-45b2-b888-77e077fea458">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d854f0b-4c07-45b2-b888-77e077fea458">
											<gml:posList>35.66953278931081 139.74353377842053 10.367 35.66953194270203 139.74354678067886 10.367 35.66953194270203 139.74354678067886 15.1 35.66953278931081 139.74353377842053 15.1 35.66953278931081 139.74353377842053 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be59cd88-2008-48a6-897e-c14ef541d40f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be59cd88-2008-48a6-897e-c14ef541d40f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be59cd88-2008-48a6-897e-c14ef541d40f">
											<gml:posList>35.66953102323622 139.74354669333937 13.4 35.66953102323622 139.74354669333937 15.1 35.66953194270203 139.74354678067886 15.1 35.66953194270203 139.74354678067886 10.367 35.669515419325535 139.74354516435312 10.367 35.669515419325535 139.74354516435312 13.4 35.66953102323622 139.74354669333937 13.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7ac724f-6aa9-41d3-bb1e-3b43d68c35df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7ac724f-6aa9-41d3-bb1e-3b43d68c35df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7ac724f-6aa9-41d3-bb1e-3b43d68c35df">
											<gml:posList>35.66950927078787 139.74356777164041 10.367 35.669477882667664 139.74356468072457 10.367 35.669477882667664 139.74356468072457 13.6 35.66950927078787 139.74356777164041 13.6 35.66950927078787 139.74356777164041 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a5d28ca-07bf-4497-bbf1-f7eb70805dd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a5d28ca-07bf-4497-bbf1-f7eb70805dd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a5d28ca-07bf-4497-bbf1-f7eb70805dd5">
											<gml:posList>35.669529740009835 139.7435664784177 15.1 35.669529740009835 139.7435664784177 17.64 35.66956224589746 139.74356965645399 17.64 35.66956224589746 139.74356965645399 15.1 35.669529740009835 139.7435664784177 15.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de662ecf-9a8f-4da1-9297-c7ec9e3d108e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de662ecf-9a8f-4da1-9297-c7ec9e3d108e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de662ecf-9a8f-4da1-9297-c7ec9e3d108e">
											<gml:posList>35.669515419325535 139.74354516435312 10.367 35.66951218483444 139.7435954610514 10.367 35.66951218483444 139.7435954610514 13.4 35.669515419325535 139.74354516435312 13.4 35.669515419325535 139.74354516435312 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbff7b34-a709-4749-a635-cdefab5c4d1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbff7b34-a709-4749-a635-cdefab5c4d1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbff7b34-a709-4749-a635-cdefab5c4d1e">
											<gml:posList>35.669477882667664 139.74356468072457 10.367 35.66947610021031 139.74359190039732 10.367 35.66947610021031 139.74359190039732 13.6 35.669477882667664 139.74356468072457 13.6 35.669477882667664 139.74356468072457 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4e66b8a-6b01-4f38-aa82-fac20a116420">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4e66b8a-6b01-4f38-aa82-fac20a116420">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4e66b8a-6b01-4f38-aa82-fac20a116420">
											<gml:posList>35.669529740009835 139.7435664784177 15.1 35.66953102323622 139.74354669333937 15.1 35.66953102323622 139.74354669333937 13.4 35.66952775268136 139.74359697904157 13.4 35.66952775268136 139.74359697904157 15.1 35.66952670116165 139.7436132180474 15.1 35.66952670116165 139.7436132180474 17.64 35.669529740009835 139.7435664784177 17.64 35.669529740009835 139.7435664784177 15.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e76c452-e329-4755-9b16-eb81578acb42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e76c452-e329-4755-9b16-eb81578acb42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e76c452-e329-4755-9b16-eb81578acb42">
											<gml:posList>35.66950748833808 139.74359500236986 10.367 35.66950927078787 139.74356777164041 10.367 35.66950927078787 139.74356777164041 13.6 35.66950748833808 139.74359500236986 13.6 35.66950748833808 139.74359500236986 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b41869b1-b55c-4229-a64d-6c27645c6e72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b41869b1-b55c-4229-a64d-6c27645c6e72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b41869b1-b55c-4229-a64d-6c27645c6e72">
											<gml:posList>35.66956224589746 139.74356965645399 15.1 35.66956224589746 139.74356965645399 17.64 35.66955920704809 139.7436163961025 17.64 35.66955920704809 139.7436163961025 15.1 35.66956224589746 139.74356965645399 15.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-773b4237-b0ba-4a5a-ba6b-e5acc20e5381">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-773b4237-b0ba-4a5a-ba6b-e5acc20e5381">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-773b4237-b0ba-4a5a-ba6b-e5acc20e5381">
											<gml:posList>35.66951218483444 139.7435954610514 13.4 35.66951218483444 139.7435954610514 10.367 35.66950748833808 139.74359500236986 10.367 35.66950748833808 139.74359500236986 13.6 35.66947610021031 139.74359190039732 13.6 35.66947610021031 139.74359190039732 10.367 35.66946008163578 139.7435903276829 10.367 35.66946008163578 139.7435903276829 15.1 35.66952775268136 139.74359697904157 15.1 35.66952775268136 139.74359697904157 13.4 35.66951218483444 139.7435954610514 13.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1cbfb744-33c1-4b13-a08f-5cd793049a7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cbfb744-33c1-4b13-a08f-5cd793049a7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cbfb744-33c1-4b13-a08f-5cd793049a7c">
											<gml:posList>35.66955920704809 139.7436163961025 15.1 35.66955920704809 139.7436163961025 17.64 35.66952670116165 139.7436132180474 17.64 35.66952670116165 139.7436132180474 15.1 35.66955920704809 139.7436163961025 15.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3dfb6497-9666-421c-8c67-cabbecdeb37b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3dfb6497-9666-421c-8c67-cabbecdeb37b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3dfb6497-9666-421c-8c67-cabbecdeb37b">
											<gml:posList>35.66946008163578 139.7435903276829 10.367 35.669454109994795 139.74368102311192 10.367 35.669454109994795 139.74368102311192 15.1 35.66946008163578 139.7435903276829 15.1 35.66946008163578 139.7435903276829 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-932d6522-7cb4-4a28-9ec8-d87a074c92e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-932d6522-7cb4-4a28-9ec8-d87a074c92e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-932d6522-7cb4-4a28-9ec8-d87a074c92e1">
											<gml:posList>35.66955216168172 139.74377834048167 10.367 35.66956783725085 139.74353719661198 10.367 35.66956783725085 139.74353719661198 15.1 35.66955216168172 139.74377834048167 15.1 35.66955216168172 139.74377834048167 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f60dfb51-da1c-4d20-9c97-512782846085">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f60dfb51-da1c-4d20-9c97-512782846085">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f60dfb51-da1c-4d20-9c97-512782846085">
											<gml:posList>35.669454109994795 139.74368102311192 10.367 35.669479079822 139.7436834253421 10.367 35.669479079822 139.7436834253421 15.1 35.669454109994795 139.74368102311192 15.1 35.669454109994795 139.74368102311192 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63df4f2f-c2a6-4c2c-ae38-93a607b682ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63df4f2f-c2a6-4c2c-ae38-93a607b682ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63df4f2f-c2a6-4c2c-ae38-93a607b682ad">
											<gml:posList>35.669479079822 139.7436834253421 10.367 35.66947337597577 139.7437706961848 10.367 35.66947337597577 139.7437706961848 15.1 35.669479079822 139.7436834253421 15.1 35.669479079822 139.7436834253421 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e706e93d-b99c-4738-a3d7-3803b9812f74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e706e93d-b99c-4738-a3d7-3803b9812f74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e706e93d-b99c-4738-a3d7-3803b9812f74">
											<gml:posList>35.66947337597577 139.7437706961848 10.367 35.66955216168172 139.74377834048167 10.367 35.66955216168172 139.74377834048167 15.1 35.66947337597577 139.7437706961848 15.1 35.66947337597577 139.7437706961848 10.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1661</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">181.77085</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>