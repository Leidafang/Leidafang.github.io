<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_85df5be5-dd41-4f5f-90e3-95a147f0366f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">12.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67252536532049 139.73943294997252 0 35.672595327709665 139.73933775710836 0 35.67250204535474 139.73923480214887 0 35.67243217318304 139.73932999488608 0 35.67252536532049 139.73943294997252 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67252536532049 139.73943294997252 7.76 35.67243217318304 139.73932999488608 7.76 35.67250204535474 139.73923480214887 7.76 35.672595327709665 139.73933775710836 7.76 35.67252536532049 139.73943294997252 7.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67252536532049 139.73943294997252 7.76 35.672595327709665 139.73933775710836 7.76 35.672595327709665 139.73933775710836 20.68 35.67252536532049 139.73943294997252 20.68 35.67252536532049 139.73943294997252 7.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672595327709665 139.73933775710836 7.76 35.67250204535474 139.73923480214887 7.76 35.67250204535474 139.73923480214887 20.68 35.672595327709665 139.73933775710836 20.68 35.672595327709665 139.73933775710836 7.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67250204535474 139.73923480214887 7.76 35.67243217318304 139.73932999488608 7.76 35.67243217318304 139.73932999488608 20.68 35.67250204535474 139.73923480214887 20.68 35.67250204535474 139.73923480214887 7.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67243217318304 139.73932999488608 7.76 35.67252536532049 139.73943294997252 7.76 35.67252536532049 139.73943294997252 20.68 35.67243217318304 139.73932999488608 20.68 35.67243217318304 139.73932999488608 7.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67252536532049 139.73943294997252 20.68 35.672595327709665 139.73933775710836 20.68 35.67250204535474 139.73923480214887 20.68 35.67243217318304 139.73932999488608 20.68 35.67252536532049 139.73943294997252 20.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-cdd12d41-8b7e-4ed6-abab-3d5564e43dbc"/>
							<gml:surfaceMember xlink:href="#poly-d481f201-5d62-4a9a-bac3-c3a14f1da9f4"/>
							<gml:surfaceMember xlink:href="#poly-dd71fc0a-6cee-4049-bd9e-aa9ee5ae95a9"/>
							<gml:surfaceMember xlink:href="#poly-572e98bf-3556-412d-88a6-641308bd1018"/>
							<gml:surfaceMember xlink:href="#poly-5205707a-e0e0-4f15-b221-a7d33898e407"/>
							<gml:surfaceMember xlink:href="#poly-f852e041-3128-45d5-95f3-dc3c5cee6901"/>
							<gml:surfaceMember xlink:href="#poly-7f4cfdf7-45c5-4c1d-a3f9-aab8b2fa36af"/>
							<gml:surfaceMember xlink:href="#poly-cde9deab-cf04-4d1e-91d4-b075671dbe3e"/>
							<gml:surfaceMember xlink:href="#poly-a1343500-8437-40b2-b7c0-8fd3fbb85424"/>
							<gml:surfaceMember xlink:href="#poly-036dfeec-146c-4ef0-a7bc-1f009904aed7"/>
							<gml:surfaceMember xlink:href="#poly-09519543-0105-40cc-ab85-4c9266ac2c49"/>
							<gml:surfaceMember xlink:href="#poly-10ab8716-2729-43f8-af5a-c04de944b6f0"/>
							<gml:surfaceMember xlink:href="#poly-17d66783-87a7-4737-a411-dfb1f7781eee"/>
							<gml:surfaceMember xlink:href="#poly-3ef42062-5969-4628-bce7-b312499cb7ae"/>
							<gml:surfaceMember xlink:href="#poly-b768c1ac-bebb-4ad9-b0a6-d5aab1932d42"/>
							<gml:surfaceMember xlink:href="#poly-c6c67b48-8e07-49ee-8be4-facd3b737b2e"/>
							<gml:surfaceMember xlink:href="#poly-1c49f7e7-6a3d-4cb8-9f6e-4881bbeaf938"/>
							<gml:surfaceMember xlink:href="#poly-c83f2f0d-5322-44e8-bdd0-9ce91910ae9b"/>
							<gml:surfaceMember xlink:href="#poly-0860330e-b47c-4eb4-b5b6-0444d9ad6567"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_85df5be5-dd41-4f5f-90e3-95a147f0366f_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5cc9001-ea16-4c48-a8a7-ed8678787499">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672497258361304 139.73930313068547 24.768 35.672504742084826 139.73929457187677 24.768 35.67252092931119 139.73931582855312 24.768 35.67251344558618 139.73932438736156 24.768 35.672497258361304 139.73930313068547 24.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4283a509-92f5-4ed8-b834-9a09975ffebc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4283a509-92f5-4ed8-b834-9a09975ffebc_0">
											<gml:posList>35.672497258361304 139.73930313068547 27.098 35.672504742084826 139.73929457187677 27.098 35.672504742084826 139.73929457187677 24.768 35.672497258361304 139.73930313068547 24.768 35.672497258361304 139.73930313068547 27.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f3ec34e-d3cc-48a2-8163-34b29e221ef0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f3ec34e-d3cc-48a2-8163-34b29e221ef0_0">
											<gml:posList>35.67251344558618 139.73932438736156 27.098 35.672497258361304 139.73930313068547 27.098 35.672497258361304 139.73930313068547 24.768 35.67251344558618 139.73932438736156 24.768 35.67251344558618 139.73932438736156 27.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-500d0677-71f0-4616-a95a-30d373f631ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-500d0677-71f0-4616-a95a-30d373f631ee_0">
											<gml:posList>35.672497258361304 139.73930313068547 27.098 35.67251344558618 139.73932438736156 27.098 35.67252092931119 139.73931582855312 27.098 35.672504742084826 139.73929457187677 27.098 35.672497258361304 139.73930313068547 27.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa693420-56a4-40c4-8656-c9a77f58a269">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa693420-56a4-40c4-8656-c9a77f58a269_0">
											<gml:posList>35.672504742084826 139.73929457187677 27.098 35.67252092931119 139.73931582855312 27.098 35.67252092931119 139.73931582855312 24.768 35.672504742084826 139.73929457187677 24.768 35.672504742084826 139.73929457187677 27.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-660f1223-b710-4838-8182-08e2560d2315">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-660f1223-b710-4838-8182-08e2560d2315_0">
											<gml:posList>35.67252092931119 139.73931582855312 27.098 35.67251344558618 139.73932438736156 27.098 35.67251344558618 139.73932438736156 24.768 35.67252092931119 139.73931582855312 24.768 35.67252092931119 139.73931582855312 27.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-cdd12d41-8b7e-4ed6-abab-3d5564e43dbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdd12d41-8b7e-4ed6-abab-3d5564e43dbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdd12d41-8b7e-4ed6-abab-3d5564e43dbc">
											<gml:posList>35.67252536532049 139.73943294997252 7.76 35.67243217318304 139.73932999488605 7.76 35.67250204535475 139.73923480214887 7.76 35.67259532770966 139.73933775710836 7.76 35.67252536532049 139.73943294997252 7.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d481f201-5d62-4a9a-bac3-c3a14f1da9f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d481f201-5d62-4a9a-bac3-c3a14f1da9f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d481f201-5d62-4a9a-bac3-c3a14f1da9f4">
											<gml:posList>35.67248000558184 139.73938331572418 25.577 35.672480009346366 139.73937658837164 25.577 35.67243788761375 139.7393296457429 25.577 35.67243217318304 139.73932999488605 25.577 35.67248000558184 139.73938331572418 25.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd71fc0a-6cee-4049-bd9e-aa9ee5ae95a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd71fc0a-6cee-4049-bd9e-aa9ee5ae95a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd71fc0a-6cee-4049-bd9e-aa9ee5ae95a9">
											<gml:posList>35.67243217318304 139.73932999488605 25.577 35.67243788761375 139.7393296457429 25.577 35.67248624889169 139.73926376264916 25.577 35.672486234078356 139.7392563393853 25.577 35.67243217318304 139.73932999488605 25.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-572e98bf-3556-412d-88a6-641308bd1018">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-572e98bf-3556-412d-88a6-641308bd1018">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-572e98bf-3556-412d-88a6-641308bd1018">
											<gml:posList>35.67252917250802 139.73932178402617 24.768 35.67248624889169 139.73926376264916 24.768 35.67243788761375 139.7393296457429 24.768 35.672480009346366 139.73937658837164 24.768 35.67252917250802 139.73932178402617 24.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5205707a-e0e0-4f15-b221-a7d33898e407">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5205707a-e0e0-4f15-b221-a7d33898e407">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5205707a-e0e0-4f15-b221-a7d33898e407">
											<gml:posList>35.67253488747334 139.73932211976782 25.577 35.67248000558184 139.73938331572418 25.577 35.67252536532049 139.73943294997252 15.507 35.67253488747334 139.73932211976782 25.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f852e041-3128-45d5-95f3-dc3c5cee6901">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f852e041-3128-45d5-95f3-dc3c5cee6901">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f852e041-3128-45d5-95f3-dc3c5cee6901">
											<gml:posList>35.67253488747334 139.73932211976782 25.577 35.67252917250802 139.73932178402617 25.577 35.672480009346366 139.73937658837164 25.577 35.67248000558184 139.73938331572418 25.577 35.67253488747334 139.73932211976782 25.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f4cfdf7-45c5-4c1d-a3f9-aab8b2fa36af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f4cfdf7-45c5-4c1d-a3f9-aab8b2fa36af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f4cfdf7-45c5-4c1d-a3f9-aab8b2fa36af">
											<gml:posList>35.67253488747334 139.73932211976782 25.577 35.672486234078356 139.7392563393853 25.577 35.67248624889169 139.73926376264916 25.577 35.67252917250802 139.73932178402617 25.577 35.67253488747334 139.73932211976782 25.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cde9deab-cf04-4d1e-91d4-b075671dbe3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cde9deab-cf04-4d1e-91d4-b075671dbe3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cde9deab-cf04-4d1e-91d4-b075671dbe3e">
											<gml:posList>35.67253488747334 139.73932211976782 15.305 35.67257460012291 139.739365961189 15.305 35.67259532770966 139.73933775710836 15.305 35.67250204535475 139.73923480214887 15.305 35.672486234078356 139.7392563393853 15.305 35.67253488747334 139.73932211976782 15.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a1343500-8437-40b2-b7c0-8fd3fbb85424">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1343500-8437-40b2-b7c0-8fd3fbb85424">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1343500-8437-40b2-b7c0-8fd3fbb85424">
											<gml:posList>35.67252536532049 139.73943294997252 15.507 35.67257460012291 139.739365961189 15.507 35.67253488747334 139.73932211976782 25.577 35.67252536532049 139.73943294997252 15.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-036dfeec-146c-4ef0-a7bc-1f009904aed7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-036dfeec-146c-4ef0-a7bc-1f009904aed7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-036dfeec-146c-4ef0-a7bc-1f009904aed7">
											<gml:posList>35.67252917250802 139.73932178402617 25.577 35.67252917250802 139.73932178402617 24.768 35.672480009346366 139.73937658837164 24.768 35.672480009346366 139.73937658837164 25.577 35.67252917250802 139.73932178402617 25.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09519543-0105-40cc-ab85-4c9266ac2c49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09519543-0105-40cc-ab85-4c9266ac2c49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09519543-0105-40cc-ab85-4c9266ac2c49">
											<gml:posList>35.67243217318304 139.73932999488605 7.76 35.67243217318304 139.73932999488605 25.577 35.672486234078356 139.7392563393853 25.577 35.672486234078356 139.7392563393853 15.305 35.67250204535475 139.73923480214887 15.305 35.67250204535475 139.73923480214887 7.76 35.67243217318304 139.73932999488605 7.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10ab8716-2729-43f8-af5a-c04de944b6f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10ab8716-2729-43f8-af5a-c04de944b6f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10ab8716-2729-43f8-af5a-c04de944b6f0">
											<gml:posList>35.67259532770966 139.73933775710836 7.76 35.67250204535475 139.73923480214887 7.76 35.67250204535475 139.73923480214887 15.305 35.67259532770966 139.73933775710836 15.305 35.67259532770966 139.73933775710836 7.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17d66783-87a7-4737-a411-dfb1f7781eee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17d66783-87a7-4737-a411-dfb1f7781eee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17d66783-87a7-4737-a411-dfb1f7781eee">
											<gml:posList>35.672486234078356 139.7392563393853 15.305 35.672486234078356 139.7392563393853 25.577 35.67253488747334 139.73932211976782 25.577 35.67253488747334 139.73932211976782 15.305 35.672486234078356 139.7392563393853 15.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ef42062-5969-4628-bce7-b312499cb7ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ef42062-5969-4628-bce7-b312499cb7ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ef42062-5969-4628-bce7-b312499cb7ae">
											<gml:posList>35.67248624889169 139.73926376264916 25.577 35.67248624889169 139.73926376264916 24.768 35.67252917250802 139.73932178402617 24.768 35.67252917250802 139.73932178402617 25.577 35.67248624889169 139.73926376264916 25.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b768c1ac-bebb-4ad9-b0a6-d5aab1932d42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b768c1ac-bebb-4ad9-b0a6-d5aab1932d42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b768c1ac-bebb-4ad9-b0a6-d5aab1932d42">
											<gml:posList>35.67243788761375 139.7393296457429 25.577 35.67243788761375 139.7393296457429 24.768 35.67248624889169 139.73926376264916 24.768 35.67248624889169 139.73926376264916 25.577 35.67243788761375 139.7393296457429 25.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6c67b48-8e07-49ee-8be4-facd3b737b2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6c67b48-8e07-49ee-8be4-facd3b737b2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6c67b48-8e07-49ee-8be4-facd3b737b2e">
											<gml:posList>35.67253488747334 139.73932211976782 15.305 35.67253488747334 139.73932211976782 25.577 35.67257460012291 139.739365961189 15.507 35.67257460012291 139.739365961189 15.305 35.67253488747334 139.73932211976782 15.305</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c49f7e7-6a3d-4cb8-9f6e-4881bbeaf938">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c49f7e7-6a3d-4cb8-9f6e-4881bbeaf938">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c49f7e7-6a3d-4cb8-9f6e-4881bbeaf938">
											<gml:posList>35.672480009346366 139.73937658837164 25.577 35.672480009346366 139.73937658837164 24.768 35.67243788761375 139.7393296457429 24.768 35.67243788761375 139.7393296457429 25.577 35.672480009346366 139.73937658837164 25.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c83f2f0d-5322-44e8-bdd0-9ce91910ae9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c83f2f0d-5322-44e8-bdd0-9ce91910ae9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c83f2f0d-5322-44e8-bdd0-9ce91910ae9b">
											<gml:posList>35.67252536532049 139.73943294997252 15.507 35.67248000558184 139.73938331572418 25.577 35.67243217318304 139.73932999488605 25.577 35.67243217318304 139.73932999488605 7.76 35.67252536532049 139.73943294997252 7.76 35.67252536532049 139.73943294997252 15.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0860330e-b47c-4eb4-b5b6-0444d9ad6567">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0860330e-b47c-4eb4-b5b6-0444d9ad6567">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0860330e-b47c-4eb4-b5b6-0444d9ad6567">
											<gml:posList>35.67252536532049 139.73943294997252 15.507 35.67252536532049 139.73943294997252 7.76 35.67259532770966 139.73933775710836 7.76 35.67259532770966 139.73933775710836 15.305 35.67257460012291 139.739365961189 15.305 35.67257460012291 139.739365961189 15.507 35.67252536532049 139.73943294997252 15.507</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3128</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">161.63569</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.25</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>