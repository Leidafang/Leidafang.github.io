<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_87b06cd5-b73f-40bd-a759-819e2c7a5e3a">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">29.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67361808867365 139.73772411455596 0 35.67359411217135 139.73773547706685 0 35.673689627240876 139.7380382309576 0 35.67373409330415 139.738017167237 0 35.673725581016505 139.73799019022044 0 35.673757504666305 139.737975062428 0 35.67367031200947 139.7376986558817 0 35.67364421808461 139.7377110261838 0 35.67361808867365 139.73772411455596 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67361808867365 139.73772411455596 9.01 35.67364421808461 139.7377110261838 9.01 35.67367031200947 139.7376986558817 9.01 35.673757504666305 139.737975062428 9.01 35.673725581016505 139.73799019022044 9.01 35.67373409330415 139.738017167237 9.01 35.673689627240876 139.7380382309576 9.01 35.67359411217135 139.73773547706685 9.01 35.67361808867365 139.73772411455596 9.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67361808867365 139.73772411455596 9.01 35.67359411217135 139.73773547706685 9.01 35.67359411217135 139.73773547706685 38.5 35.67361808867365 139.73772411455596 38.5 35.67361808867365 139.73772411455596 9.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67359411217135 139.73773547706685 9.01 35.673689627240876 139.7380382309576 9.01 35.673689627240876 139.7380382309576 38.5 35.67359411217135 139.73773547706685 38.5 35.67359411217135 139.73773547706685 9.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673689627240876 139.7380382309576 9.01 35.67373409330415 139.738017167237 9.01 35.67373409330415 139.738017167237 38.5 35.673689627240876 139.7380382309576 38.5 35.673689627240876 139.7380382309576 9.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67373409330415 139.738017167237 9.01 35.673725581016505 139.73799019022044 9.01 35.673725581016505 139.73799019022044 38.5 35.67373409330415 139.738017167237 38.5 35.67373409330415 139.738017167237 9.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673725581016505 139.73799019022044 9.01 35.673757504666305 139.737975062428 9.01 35.673757504666305 139.737975062428 38.5 35.673725581016505 139.73799019022044 38.5 35.673725581016505 139.73799019022044 9.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673757504666305 139.737975062428 9.01 35.67367031200947 139.7376986558817 9.01 35.67367031200947 139.7376986558817 38.5 35.673757504666305 139.737975062428 38.5 35.673757504666305 139.737975062428 9.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67367031200947 139.7376986558817 9.01 35.67364421808461 139.7377110261838 9.01 35.67364421808461 139.7377110261838 38.5 35.67367031200947 139.7376986558817 38.5 35.67367031200947 139.7376986558817 9.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67364421808461 139.7377110261838 9.01 35.67361808867365 139.73772411455596 9.01 35.67361808867365 139.73772411455596 38.5 35.67364421808461 139.7377110261838 38.5 35.67364421808461 139.7377110261838 9.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67361808867365 139.73772411455596 38.5 35.67359411217135 139.73773547706685 38.5 35.673689627240876 139.7380382309576 38.5 35.67373409330415 139.738017167237 38.5 35.673725581016505 139.73799019022044 38.5 35.673757504666305 139.737975062428 38.5 35.67367031200947 139.7376986558817 38.5 35.67364421808461 139.7377110261838 38.5 35.67361808867365 139.73772411455596 38.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0708b1b5-a086-467a-ba1c-0d555b171df9"/>
							<gml:surfaceMember xlink:href="#poly-dc42b53b-acde-4a14-bf31-a48055f390af"/>
							<gml:surfaceMember xlink:href="#poly-ca77f565-817d-4453-b9b0-fb4417846bbf"/>
							<gml:surfaceMember xlink:href="#poly-8b22f2c7-c7de-4270-bf55-5b67997f88d0"/>
							<gml:surfaceMember xlink:href="#poly-fb70b997-e886-45e9-a6e8-1304114cf58b"/>
							<gml:surfaceMember xlink:href="#poly-861f5d3c-149a-4cad-b0c5-f7ccdcaea1ea"/>
							<gml:surfaceMember xlink:href="#poly-436994d9-a935-4916-b95b-7af46d83003e"/>
							<gml:surfaceMember xlink:href="#poly-3d057461-bf7b-46e1-88a0-fc9051dfb88b"/>
							<gml:surfaceMember xlink:href="#poly-5e5308bf-4654-4da5-8d6c-2bcb4474f78d"/>
							<gml:surfaceMember xlink:href="#poly-838a8442-8b49-4ae6-836c-fc973f0b731a"/>
							<gml:surfaceMember xlink:href="#poly-ba19e4ab-7b74-48c0-927d-500384bc7596"/>
							<gml:surfaceMember xlink:href="#poly-f4575971-b12c-4f13-843f-c51293adf5f6"/>
							<gml:surfaceMember xlink:href="#poly-795913a8-b95b-4ce7-8bc5-e854b09b1bd0"/>
							<gml:surfaceMember xlink:href="#poly-18d724eb-1d38-42bb-b082-9bd4d07d53f6"/>
							<gml:surfaceMember xlink:href="#poly-059215fd-257d-441d-a6be-424b888bebee"/>
							<gml:surfaceMember xlink:href="#poly-dbcc292c-2bd3-4b7b-aeea-e71219419123"/>
							<gml:surfaceMember xlink:href="#poly-bb9dcaec-f114-4841-8443-1d8b873a65db"/>
							<gml:surfaceMember xlink:href="#poly-5970baf0-7909-462e-bed2-033cd6b56d9b"/>
							<gml:surfaceMember xlink:href="#poly-e4c46129-442f-420b-8ffc-4a891d8587db"/>
							<gml:surfaceMember xlink:href="#poly-4174f214-603c-4609-86f5-02e8bc0e86d6"/>
							<gml:surfaceMember xlink:href="#poly-939c71fb-02b1-4186-a889-6c2f3863bda9"/>
							<gml:surfaceMember xlink:href="#poly-ecaccd21-b52a-4b05-bf99-f858d252af88"/>
							<gml:surfaceMember xlink:href="#poly-159dc89b-2f87-4869-a348-afcf9d21f39e"/>
							<gml:surfaceMember xlink:href="#poly-a232a6b9-a66e-4738-b295-7821903881a5"/>
							<gml:surfaceMember xlink:href="#poly-794f7cc1-1346-4196-9c3d-9465ca46c7e0"/>
							<gml:surfaceMember xlink:href="#poly-0269e06d-b504-4d96-a26b-4eee6dbb853b"/>
							<gml:surfaceMember xlink:href="#poly-491da33e-32e8-4e04-bf46-015c842804d0"/>
							<gml:surfaceMember xlink:href="#poly-c271f5ee-2d20-4e3a-9067-c045ef6189fc"/>
							<gml:surfaceMember xlink:href="#poly-e72a3822-6483-4e91-bb29-c73c41815a9c"/>
							<gml:surfaceMember xlink:href="#poly-30029f4d-146b-45d2-b198-47e103a5cc11"/>
							<gml:surfaceMember xlink:href="#poly-7e3f7d79-b0e5-4814-9f76-2b99b8367e24"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_87b06cd5-b73f-40bd-a759-819e2c7a5e3a_BuildingInstallation_1000">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b74454e3-a118-4555-b7e7-e74466c167f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b74454e3-a118-4555-b7e7-e74466c167f6_0">
											<gml:posList>35.67361808867365 139.73772411455596 33.523 35.67361487169381 139.737713922284 33.523 35.67361487169381 139.737713922284 9.24 35.67361808867365 139.73772411455596 9.24 35.67361808867365 139.73772411455596 33.523</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96baf17c-87e5-46f9-a987-d95fcb0ee603">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96baf17c-87e5-46f9-a987-d95fcb0ee603_0">
											<gml:posList>35.67361487169381 139.737713922284 33.523 35.673641199887996 139.7377014412409 33.523 35.673641199887996 139.7377014412409 9.24 35.67361487169381 139.737713922284 9.24 35.67361487169381 139.737713922284 33.523</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ece5fd4-6d92-4bba-8933-dcc76f31ed07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ece5fd4-6d92-4bba-8933-dcc76f31ed07_0">
											<gml:posList>35.673641199887996 139.7377014412409 33.523 35.67364421808461 139.7377110261838 33.523 35.67364421808461 139.7377110261838 9.24 35.673641199887996 139.7377014412409 9.24 35.673641199887996 139.7377014412409 33.523</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e157a19-4e60-4a1a-83a7-ab4d1abdd9bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e157a19-4e60-4a1a-83a7-ab4d1abdd9bc_0">
											<gml:posList>35.67364421808461 139.7377110261838 33.523 35.67361808867365 139.73772411455596 33.523 35.67361808867365 139.73772411455596 9.24 35.67364421808461 139.7377110261838 9.24 35.67364421808461 139.7377110261838 33.523</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bdea4b0-e78b-40ad-bbbe-e6d022cbd746">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1bdea4b0-e78b-40ad-bbbe-e6d022cbd746_0">
											<gml:posList>35.67361487169381 139.737713922284 33.523 35.67361808867365 139.73772411455596 33.523 35.67364421808461 139.7377110261838 33.523 35.673641199887996 139.7377014412409 33.523 35.67361487169381 139.737713922284 33.523</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b71c1a04-ffcd-4875-b2b2-49123bc603ff">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67361808867365 139.73772411455596 9.24 35.67361487169381 139.737713922284 9.24 35.673641199887996 139.7377014412409 9.24 35.67364421808461 139.7377110261838 9.24 35.67361808867365 139.73772411455596 9.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_87b06cd5-b73f-40bd-a759-819e2c7a5e3a_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb9ffd41-ed21-4150-832b-a624c9889740">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67371720614039 139.7378750049952 37.08 35.67368193966607 139.73789171647977 37.08 35.67365539059647 139.73780755006 37.08 35.673690648045515 139.73779083855476 37.08 35.67371720614039 139.7378750049952 37.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74f8b306-e05e-46b6-a58e-20497a762e3b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67370462294762 139.73800011300446 36.856 35.67368653918669 139.7380086846664 36.856 35.67367656296572 139.7379770256015 36.856 35.67369463771945 139.73796846499093 36.856 35.67370462294762 139.73800011300446 36.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b36095dd-01a2-40b4-bb16-38e531fcbbce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67368653918669 139.7380086846664 36.856 35.67370462294762 139.73800011300446 36.856 35.67370563502903 139.73800332639567 36.592 35.673687560272846 139.73801188699957 36.592 35.67368653918669 139.7380086846664 36.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dba1464f-f9b5-4925-aa99-2a412dead249">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673711334039645 139.73794936744727 37.08 35.67370284961825 139.73792345089728 37.08 35.6737138602576 139.73791823478876 37.08 35.6737223446801 139.73794415134176 37.08 35.673711334039645 139.73794936744727 37.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00c8c498-09ff-4bfc-a80d-0e9d1fc0b958">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6737223446801 139.73794415134176 41.674 35.673723203057264 139.737946768393 41.674 35.673712192416694 139.73795198449818 41.674 35.673711334039645 139.73794936744727 41.674 35.6737223446801 139.73794415134176 41.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c03049e-ab54-4a24-b22b-8429ce30ea03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c03049e-ab54-4a24-b22b-8429ce30ea03_0">
											<gml:posList>35.67365539059647 139.73780755006 45.086 35.67365539059647 139.73780755006 37.08 35.67368193966607 139.73789171647977 37.08 35.67368193966607 139.73789171647977 45.086 35.67365539059647 139.73780755006 45.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c8d60fc-5771-4490-9843-b49fb944fab8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c8d60fc-5771-4490-9843-b49fb944fab8_0">
											<gml:posList>35.67365539059647 139.73780755006 45.086 35.673690648045515 139.73779083855476 45.086 35.673690648045515 139.73779083855476 37.08 35.67365539059647 139.73780755006 37.08 35.67365539059647 139.73780755006 45.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2df36c2d-14fe-4be8-982a-45b247095627">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2df36c2d-14fe-4be8-982a-45b247095627_0">
											<gml:posList>35.67368653918669 139.7380086846664 36.856 35.673687560272846 139.73801188699957 36.592 35.673687560272846 139.73801188699957 38.853 35.67367656296572 139.7379770256015 38.853 35.67367656296572 139.7379770256015 36.856 35.67368653918669 139.7380086846664 36.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35af26d1-18f2-4abe-8814-0a23d02f9301">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35af26d1-18f2-4abe-8814-0a23d02f9301_0">
											<gml:posList>35.67367656296572 139.7379770256015 38.853 35.67369463771945 139.73796846499093 38.853 35.67369463771945 139.73796846499093 36.856 35.67367656296572 139.7379770256015 36.856 35.67367656296572 139.7379770256015 38.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bee810c6-6a93-466b-a80c-7f6d65d5c593">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bee810c6-6a93-466b-a80c-7f6d65d5c593_0">
											<gml:posList>35.67371720614039 139.7378750049952 45.086 35.673690648045515 139.73779083855476 45.086 35.67365539059647 139.73780755006 45.086 35.67368193966607 139.73789171647977 45.086 35.67371720614039 139.7378750049952 45.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9fd03c4-cf1e-4cf7-a9dd-4de1951536eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9fd03c4-cf1e-4cf7-a9dd-4de1951536eb_0">
											<gml:posList>35.67370563502903 139.73800332639567 38.853 35.67369463771945 139.73796846499093 38.853 35.67367656296572 139.7379770256015 38.853 35.673687560272846 139.73801188699957 38.853 35.67370563502903 139.73800332639567 38.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a9c7e25-4432-4d9e-ba73-335be2a035f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a9c7e25-4432-4d9e-ba73-335be2a035f9_0">
											<gml:posList>35.673687560272846 139.73801188699957 38.853 35.673687560272846 139.73801188699957 36.592 35.67370563502903 139.73800332639567 36.592 35.67370563502903 139.73800332639567 38.853 35.673687560272846 139.73801188699957 38.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cf5a7c2-6b0d-472e-aebb-e8ca837c5c7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cf5a7c2-6b0d-472e-aebb-e8ca837c5c7a_0">
											<gml:posList>35.67371720614039 139.7378750049952 45.086 35.67368193966607 139.73789171647977 45.086 35.67368193966607 139.73789171647977 37.08 35.67371720614039 139.7378750049952 37.08 35.67371720614039 139.7378750049952 45.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92473467-087a-4f63-a988-610a93a17a0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92473467-087a-4f63-a988-610a93a17a0b_0">
											<gml:posList>35.67370462294762 139.73800011300446 36.856 35.67369463771945 139.73796846499093 36.856 35.67369463771945 139.73796846499093 38.853 35.67370563502903 139.73800332639567 38.853 35.67370563502903 139.73800332639567 36.592 35.67370462294762 139.73800011300446 36.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1e7b31a-544f-4dc3-b8fd-f1598a4de36d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1e7b31a-544f-4dc3-b8fd-f1598a4de36d_0">
											<gml:posList>35.673690648045515 139.73779083855476 45.086 35.67371720614039 139.7378750049952 45.086 35.67371720614039 139.7378750049952 37.08 35.673690648045515 139.73779083855476 37.08 35.673690648045515 139.73779083855476 45.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6def068c-b876-4325-96c0-690f53ab6fcb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6def068c-b876-4325-96c0-690f53ab6fcb_0">
											<gml:posList>35.67370284961825 139.73792345089728 37.08 35.673711334039645 139.73794936744727 37.08 35.673711334039645 139.73794936744727 41.674 35.673712192416694 139.73795198449818 41.674 35.673712192416694 139.73795198449818 42.479 35.67370284961825 139.73792345089728 42.479 35.67370284961825 139.73792345089728 37.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ea723c9-ea87-487f-87cf-1960185d190b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ea723c9-ea87-487f-87cf-1960185d190b_0">
											<gml:posList>35.6737138602576 139.73791823478876 42.479 35.6737138602576 139.73791823478876 37.08 35.67370284961825 139.73792345089728 37.08 35.67370284961825 139.73792345089728 42.479 35.6737138602576 139.73791823478876 42.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b53f68b-dd66-49e4-b3fc-214aed00d5ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b53f68b-dd66-49e4-b3fc-214aed00d5ee_0">
											<gml:posList>35.673712192416694 139.73795198449818 42.479 35.673723203057264 139.737946768393 42.479 35.6737138602576 139.73791823478876 42.479 35.67370284961825 139.73792345089728 42.479 35.673712192416694 139.73795198449818 42.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78af36d5-536c-4218-8afe-ccd13a767652">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78af36d5-536c-4218-8afe-ccd13a767652_0">
											<gml:posList>35.673711334039645 139.73794936744727 37.08 35.6737223446801 139.73794415134176 37.08 35.6737223446801 139.73794415134176 41.674 35.673711334039645 139.73794936744727 41.674 35.673711334039645 139.73794936744727 37.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4004b306-faed-4c60-893b-e0792e5121b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4004b306-faed-4c60-893b-e0792e5121b5_0">
											<gml:posList>35.673723203057264 139.737946768393 42.479 35.673712192416694 139.73795198449818 42.479 35.673712192416694 139.73795198449818 41.674 35.673723203057264 139.737946768393 41.674 35.673723203057264 139.737946768393 42.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6d78e5f-14a4-4f7f-8a10-94f3598237b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6d78e5f-14a4-4f7f-8a10-94f3598237b7_0">
											<gml:posList>35.6737223446801 139.73794415134176 37.08 35.6737138602576 139.73791823478876 37.08 35.6737138602576 139.73791823478876 42.479 35.673723203057264 139.737946768393 42.479 35.673723203057264 139.737946768393 41.674 35.6737223446801 139.73794415134176 41.674 35.6737223446801 139.73794415134176 37.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_87b06cd5-b73f-40bd-a759-819e2c7a5e3a_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02a92179-97e7-4ce9-b5dc-e327f0683bdb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673647719553124 139.73787528657587 37.08 35.67362514619262 139.73780332206977 37.08 35.67363279599003 139.73779972277418 37.08 35.673655360338955 139.73787168729686 37.08 35.673647719553124 139.73787528657587 37.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b44bf4d-93f6-4872-9980-511529f4923d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b44bf4d-93f6-4872-9980-511529f4923d_0">
											<gml:posList>35.67363279599003 139.73779972277418 38.06 35.67363279599003 139.73779972277418 37.08 35.67362514619262 139.73780332206977 37.08 35.67362514619262 139.73780332206977 38.06 35.67363279599003 139.73779972277418 38.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-784bd0f3-36ca-4269-aa5e-e75a1ee51ef9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-784bd0f3-36ca-4269-aa5e-e75a1ee51ef9_0">
											<gml:posList>35.67362514619262 139.73780332206977 38.06 35.67362514619262 139.73780332206977 37.08 35.673647719553124 139.73787528657587 37.08 35.673647719553124 139.73787528657587 38.06 35.67362514619262 139.73780332206977 38.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb98fad1-e32e-40c1-b66e-0ee9bfda0187">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb98fad1-e32e-40c1-b66e-0ee9bfda0187_0">
											<gml:posList>35.67363279599003 139.73779972277418 38.06 35.67362514619262 139.73780332206977 38.06 35.673647719553124 139.73787528657587 38.06 35.673655360338955 139.73787168729686 38.06 35.67363279599003 139.73779972277418 38.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7ef2c06-ca5f-4d8f-bd0e-473009a1837f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7ef2c06-ca5f-4d8f-bd0e-473009a1837f_0">
											<gml:posList>35.673655360338955 139.73787168729686 38.06 35.673655360338955 139.73787168729686 37.08 35.67363279599003 139.73779972277418 37.08 35.67363279599003 139.73779972277418 38.06 35.673655360338955 139.73787168729686 38.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4720e8f2-f294-4034-b855-21810bed7b0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4720e8f2-f294-4034-b855-21810bed7b0a_0">
											<gml:posList>35.673647719553124 139.73787528657587 38.06 35.673647719553124 139.73787528657587 37.08 35.673655360338955 139.73787168729686 37.08 35.673655360338955 139.73787168729686 38.06 35.673647719553124 139.73787528657587 38.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_87b06cd5-b73f-40bd-a759-819e2c7a5e3a_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd17d650-05d9-45a3-9a28-16e4a11e3548">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67367765172934 139.73792911470989 37.08 35.67366517240497 139.73793502850512 37.08 35.67366232594196 139.73792601777583 37.08 35.6736748052659 139.73792010397943 37.08 35.67367765172934 139.73792911470989 37.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82cc9f2d-4ea8-44f1-8de4-4cb4963254e2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67368295610174 139.73794592149648 37.08 35.67367047677654 139.7379518352895 37.08 35.6736673772831 139.7379420074034 37.08 35.67367985660783 139.7379360936091 37.08 35.67368295610174 139.73794592149648 37.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99b5b1ce-1d70-4e7d-82f0-17591227e390">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67371256062009 139.73789339226607 37.08 35.67368790832725 139.73790507589896 37.08 35.67368492631479 139.7378956345077 37.08 35.67370957860672 139.73788395087234 37.08 35.67371256062009 139.73789339226607 37.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97ad29ba-0adc-4f09-ad57-48e7cceb3b8a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67372416186492 139.7379054967065 37.08 35.673702771319725 139.73791564096157 37.08 35.673699807370554 139.73790624373353 37.08 35.673721197923705 139.73789611052305 37.08 35.67372416186492 139.7379054967065 37.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14059748-4f89-4040-9b61-6833cd5a401e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14059748-4f89-4040-9b61-6833cd5a401e_0">
											<gml:posList>35.67371256062009 139.73789339226607 43.028 35.67371256062009 139.73789339226607 37.08 35.67370957860672 139.73788395087234 37.08 35.67370957860672 139.73788395087234 43.028 35.67371256062009 139.73789339226607 43.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e49f7574-64f8-4ae6-8055-abd5afcd56cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e49f7574-64f8-4ae6-8055-abd5afcd56cc_0">
											<gml:posList>35.67370957860672 139.73788395087234 43.028 35.67370957860672 139.73788395087234 37.08 35.67368492631479 139.7378956345077 37.08 35.67368492631479 139.7378956345077 43.028 35.67370957860672 139.73788395087234 43.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2803cfc8-cf0c-4608-9d0d-8928a8f5728c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2803cfc8-cf0c-4608-9d0d-8928a8f5728c_0">
											<gml:posList>35.67368492631479 139.7378956345077 43.028 35.67368790832725 139.73790507589896 43.028 35.67371256062009 139.73789339226607 43.028 35.67370957860672 139.73788395087234 43.028 35.67368492631479 139.7378956345077 43.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3a53473-9f4f-4c8e-beb3-bc713abec866">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3a53473-9f4f-4c8e-beb3-bc713abec866_0">
											<gml:posList>35.67371256062009 139.73789339226607 43.028 35.67368790832725 139.73790507589896 43.028 35.67368790832725 139.73790507589896 37.08 35.67371256062009 139.73789339226607 37.08 35.67371256062009 139.73789339226607 43.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4470583-42f1-467a-8c51-8fcf1fb1922a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4470583-42f1-467a-8c51-8fcf1fb1922a_0">
											<gml:posList>35.67368492631479 139.7378956345077 43.028 35.67368492631479 139.7378956345077 37.08 35.67368790832725 139.73790507589896 37.08 35.67368790832725 139.73790507589896 43.028 35.67368492631479 139.7378956345077 43.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21dbd48d-8393-49fc-aca4-fa863b6a4967">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21dbd48d-8393-49fc-aca4-fa863b6a4967_0">
											<gml:posList>35.673721197923705 139.73789611052305 43.028 35.67372416186492 139.7379054967065 43.028 35.67372416186492 139.7379054967065 37.08 35.673721197923705 139.73789611052305 37.08 35.673721197923705 139.73789611052305 43.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fbff3a6-b56e-446b-91d2-7424e366abc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fbff3a6-b56e-446b-91d2-7424e366abc6_0">
											<gml:posList>35.673721197923705 139.73789611052305 43.028 35.673721197923705 139.73789611052305 37.08 35.673699807370554 139.73790624373353 37.08 35.673699807370554 139.73790624373353 43.028 35.673721197923705 139.73789611052305 43.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f473a75b-c569-49dd-a02b-22d9daed0366">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f473a75b-c569-49dd-a02b-22d9daed0366_0">
											<gml:posList>35.67366232594196 139.73792601777583 42.615 35.67366232594196 139.73792601777583 37.08 35.67366517240497 139.73793502850512 37.08 35.67366517240497 139.73793502850512 42.615 35.67366232594196 139.73792601777583 42.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acd95f33-9cba-415c-ba99-289a303cd492">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acd95f33-9cba-415c-ba99-289a303cd492_0">
											<gml:posList>35.67366232594196 139.73792601777583 42.615 35.6736748052659 139.73792010397943 42.615 35.6736748052659 139.73792010397943 37.08 35.67366232594196 139.73792601777583 37.08 35.67366232594196 139.73792601777583 42.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86f55775-67e6-4d43-af1a-e95e8170e98b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86f55775-67e6-4d43-af1a-e95e8170e98b_0">
											<gml:posList>35.67367047677654 139.7379518352895 42.615 35.6736673772831 139.7379420074034 42.615 35.6736673772831 139.7379420074034 37.08 35.67367047677654 139.7379518352895 37.08 35.67367047677654 139.7379518352895 42.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-933e2f63-d086-43bd-b47c-4513b2deba0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-933e2f63-d086-43bd-b47c-4513b2deba0e_0">
											<gml:posList>35.67366232594196 139.73792601777583 42.615 35.67366517240497 139.73793502850512 42.615 35.67367765172934 139.73792911470989 42.615 35.6736748052659 139.73792010397943 42.615 35.67366232594196 139.73792601777583 42.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e30677a2-5dce-4f4d-88a6-bc7c63e56b0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e30677a2-5dce-4f4d-88a6-bc7c63e56b0e_0">
											<gml:posList>35.67367765172934 139.73792911470989 42.615 35.67366517240497 139.73793502850512 42.615 35.67366517240497 139.73793502850512 37.08 35.67367765172934 139.73792911470989 37.08 35.67367765172934 139.73792911470989 42.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a9973d2-3193-4af0-94b6-f5639d685a60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a9973d2-3193-4af0-94b6-f5639d685a60_0">
											<gml:posList>35.6736673772831 139.7379420074034 42.615 35.67367985660783 139.7379360936091 42.615 35.67367985660783 139.7379360936091 37.08 35.6736673772831 139.7379420074034 37.08 35.6736673772831 139.7379420074034 42.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b88f8d56-88d5-4f2f-bd43-a4ae9f656fc0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b88f8d56-88d5-4f2f-bd43-a4ae9f656fc0_0">
											<gml:posList>35.6736673772831 139.7379420074034 42.615 35.67367047677654 139.7379518352895 42.615 35.67368295610174 139.73794592149648 42.615 35.67367985660783 139.7379360936091 42.615 35.6736673772831 139.7379420074034 42.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8eb0fde6-25dc-43dc-94da-1accdf0c7be9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8eb0fde6-25dc-43dc-94da-1accdf0c7be9_0">
											<gml:posList>35.67367765172934 139.73792911470989 42.615 35.67367765172934 139.73792911470989 37.08 35.6736748052659 139.73792010397943 37.08 35.6736748052659 139.73792010397943 42.615 35.67367765172934 139.73792911470989 42.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d762c219-faa1-4489-9ce7-c0833a91ce37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d762c219-faa1-4489-9ce7-c0833a91ce37_0">
											<gml:posList>35.67368295610174 139.73794592149648 42.615 35.67367047677654 139.7379518352895 42.615 35.67367047677654 139.7379518352895 37.08 35.67368295610174 139.73794592149648 37.08 35.67368295610174 139.73794592149648 42.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9079b6d-1106-4314-912e-22d527eb9dfc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9079b6d-1106-4314-912e-22d527eb9dfc_0">
											<gml:posList>35.67367985660783 139.7379360936091 42.615 35.67368295610174 139.73794592149648 42.615 35.67368295610174 139.73794592149648 37.08 35.67367985660783 139.7379360936091 37.08 35.67367985660783 139.7379360936091 42.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9af4b35a-3477-42b2-9f96-12c9de926017">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9af4b35a-3477-42b2-9f96-12c9de926017_0">
											<gml:posList>35.673699807370554 139.73790624373353 43.028 35.673699807370554 139.73790624373353 37.08 35.673702771319725 139.73791564096157 37.08 35.673702771319725 139.73791564096157 43.028 35.673699807370554 139.73790624373353 43.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5073d125-1fc0-43f9-9490-e3834ad0edc1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5073d125-1fc0-43f9-9490-e3834ad0edc1_0">
											<gml:posList>35.673699807370554 139.73790624373353 43.028 35.673702771319725 139.73791564096157 43.028 35.67372416186492 139.7379054967065 43.028 35.673721197923705 139.73789611052305 43.028 35.673699807370554 139.73790624373353 43.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb616301-cabc-4611-9013-5e0b93971450">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb616301-cabc-4611-9013-5e0b93971450_0">
											<gml:posList>35.673702771319725 139.73791564096157 43.028 35.673702771319725 139.73791564096157 37.08 35.67372416186492 139.7379054967065 37.08 35.67372416186492 139.7379054967065 43.028 35.673702771319725 139.73791564096157 43.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0708b1b5-a086-467a-ba1c-0d555b171df9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0708b1b5-a086-467a-ba1c-0d555b171df9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0708b1b5-a086-467a-ba1c-0d555b171df9">
											<gml:posList>35.67372558101646 139.73799019022044 9.01 35.67373409330413 139.73801716723696 9.01 35.673689627240876 139.73803823095759 9.01 35.67359411217135 139.73773547706685 9.01 35.67361808867365 139.73772411455596 9.01 35.67364421808461 139.7377110261838 9.01 35.67367031200946 139.7376986558817 9.01 35.67375750466632 139.737975062428 9.01 35.67372558101646 139.73799019022044 9.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc42b53b-acde-4a14-bf31-a48055f390af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc42b53b-acde-4a14-bf31-a48055f390af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc42b53b-acde-4a14-bf31-a48055f390af">
											<gml:posList>35.67360305039661 139.73775391440267 38.156 35.673599290045544 139.7377518641992 38.156 35.67361372127298 139.7377976134909 38.156 35.67361644239884 139.73779632883037 38.156 35.67360305039661 139.73775391440267 38.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca77f565-817d-4453-b9b0-fb4417846bbf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca77f565-817d-4453-b9b0-fb4417846bbf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca77f565-817d-4453-b9b0-fb4417846bbf">
											<gml:posList>35.67367578813957 139.73771604792242 35.928 35.67367031200946 139.7376986558817 35.928 35.67364421808461 139.7377110261838 35.928 35.67361808867365 139.73772411455596 35.928 35.67359411217135 139.73773547706685 35.928 35.673599290045544 139.7377518641992 35.928 35.67367578813957 139.73771604792242 35.928</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b22f2c7-c7de-4270-bf55-5b67997f88d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b22f2c7-c7de-4270-bf55-5b67997f88d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b22f2c7-c7de-4270-bf55-5b67997f88d0">
											<gml:posList>35.673599290045544 139.7377518641992 38.156 35.67360305039661 139.73775391440267 38.156 35.673674115237375 139.73772064535032 38.156 35.67367578813957 139.73771604792242 38.156 35.673599290045544 139.7377518641992 38.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb70b997-e886-45e9-a6e8-1304114cf58b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb70b997-e886-45e9-a6e8-1304114cf58b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb70b997-e886-45e9-a6e8-1304114cf58b">
											<gml:posList>35.673674115237375 139.73772064535032 38.156 35.67368739880604 139.7377627064444 38.156 35.67369011091776 139.73776142179224 38.156 35.67367578813957 139.73771604792242 38.156 35.673674115237375 139.73772064535032 38.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-861f5d3c-149a-4cad-b0c5-f7ccdcaea1ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-861f5d3c-149a-4cad-b0c5-f7ccdcaea1ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-861f5d3c-149a-4cad-b0c5-f7ccdcaea1ea">
											<gml:posList>35.67361644239884 139.73779632883037 37.841 35.67368739880604 139.7377627064444 37.841 35.673674115237375 139.73772064535032 37.841 35.67360305039661 139.73775391440267 37.841 35.67361644239884 139.73779632883037 37.841</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-436994d9-a935-4916-b95b-7af46d83003e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-436994d9-a935-4916-b95b-7af46d83003e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-436994d9-a935-4916-b95b-7af46d83003e">
											<gml:posList>35.67361372127298 139.7377976134909 41.674 35.673618004637966 139.73779993924126 41.674 35.67368821318821 139.73776667124423 41.674 35.67369011091776 139.73776142179224 41.674 35.67361372127298 139.7377976134909 41.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d057461-bf7b-46e1-88a0-fc9051dfb88b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d057461-bf7b-46e1-88a0-fc9051dfb88b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d057461-bf7b-46e1-88a0-fc9051dfb88b">
											<gml:posList>35.67369011091776 139.73776142179224 41.674 35.67368821318821 139.73776667124423 41.674 35.673741365512775 139.73793513667746 41.674 35.67374564888379 139.73793747348554 41.674 35.67369011091776 139.73776142179224 41.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e5308bf-4654-4da5-8d6c-2bcb4474f78d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e5308bf-4654-4da5-8d6c-2bcb4474f78d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e5308bf-4654-4da5-8d6c-2bcb4474f78d">
											<gml:posList>35.673741365512775 139.73793513667746 37.08 35.67368821318821 139.73776667124423 37.08 35.673618004637966 139.73779993924126 37.08 35.67367115691642 139.7379684045492 37.08 35.673741365512775 139.73793513667746 37.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-838a8442-8b49-4ae6-836c-fc973f0b731a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-838a8442-8b49-4ae6-836c-fc973f0b731a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-838a8442-8b49-4ae6-836c-fc973f0b731a">
											<gml:posList>35.673669259186575 139.73797366504178 41.674 35.67367115691642 139.7379684045492 41.674 35.673618004637966 139.73779993924126 41.674 35.67361372127298 139.7377976134909 41.674 35.673669259186575 139.73797366504178 41.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba19e4ab-7b74-48c0-927d-500384bc7596">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba19e4ab-7b74-48c0-927d-500384bc7596">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba19e4ab-7b74-48c0-927d-500384bc7596">
											<gml:posList>35.67374564888379 139.73793747348554 41.674 35.673741365512775 139.73793513667746 41.674 35.67367115691642 139.7379684045492 41.674 35.673669259186575 139.73797366504178 41.674 35.67374564888379 139.73793747348554 41.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4575971-b12c-4f13-843f-c51293adf5f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4575971-b12c-4f13-843f-c51293adf5f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4575971-b12c-4f13-843f-c51293adf5f6">
											<gml:posList>35.6736811149579 139.7380112539538 36.856 35.67372558101646 139.73799019022044 36.856 35.67375750466632 139.737975062428 36.856 35.67374564888379 139.73793747348554 36.856 35.673669259186575 139.73797366504178 36.856 35.6736811149579 139.7380112539538 36.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-795913a8-b95b-4ce7-8bc5-e854b09b1bd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-795913a8-b95b-4ce7-8bc5-e854b09b1bd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-795913a8-b95b-4ce7-8bc5-e854b09b1bd0">
											<gml:posList>35.673689627240876 139.73803823095759 34.638 35.67373409330413 139.73801716723696 34.638 35.67372558101646 139.73799019022044 36.856 35.6736811149579 139.7380112539538 36.856 35.673689627240876 139.73803823095759 34.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18d724eb-1d38-42bb-b082-9bd4d07d53f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18d724eb-1d38-42bb-b082-9bd4d07d53f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18d724eb-1d38-42bb-b082-9bd4d07d53f6">
											<gml:posList>35.67367115691642 139.7379684045492 41.674 35.67367115691642 139.7379684045492 37.08 35.673618004637966 139.73779993924126 37.08 35.673618004637966 139.73779993924126 41.674 35.67367115691642 139.7379684045492 41.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-059215fd-257d-441d-a6be-424b888bebee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-059215fd-257d-441d-a6be-424b888bebee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-059215fd-257d-441d-a6be-424b888bebee">
											<gml:posList>35.673674115237375 139.73772064535032 38.156 35.673674115237375 139.73772064535032 37.841 35.67368739880604 139.7377627064444 37.841 35.67368739880604 139.7377627064444 38.156 35.673674115237375 139.73772064535032 38.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbcc292c-2bd3-4b7b-aeea-e71219419123">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbcc292c-2bd3-4b7b-aeea-e71219419123">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbcc292c-2bd3-4b7b-aeea-e71219419123">
											<gml:posList>35.67368821318821 139.73776667124423 41.674 35.67368821318821 139.73776667124423 37.08 35.673741365512775 139.73793513667746 37.08 35.673741365512775 139.73793513667746 41.674 35.67368821318821 139.73776667124423 41.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb9dcaec-f114-4841-8443-1d8b873a65db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb9dcaec-f114-4841-8443-1d8b873a65db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb9dcaec-f114-4841-8443-1d8b873a65db">
											<gml:posList>35.67367031200946 139.7376986558817 9.01 35.67364421808461 139.7377110261838 9.01 35.67364421808461 139.7377110261838 35.928 35.67367031200946 139.7376986558817 35.928 35.67367031200946 139.7376986558817 9.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5970baf0-7909-462e-bed2-033cd6b56d9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5970baf0-7909-462e-bed2-033cd6b56d9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5970baf0-7909-462e-bed2-033cd6b56d9b">
											<gml:posList>35.67364421808461 139.7377110261838 9.01 35.67361808867365 139.73772411455596 9.01 35.67361808867365 139.73772411455596 35.928 35.67364421808461 139.7377110261838 35.928 35.67364421808461 139.7377110261838 9.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4c46129-442f-420b-8ffc-4a891d8587db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4c46129-442f-420b-8ffc-4a891d8587db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4c46129-442f-420b-8ffc-4a891d8587db">
											<gml:posList>35.67361808867365 139.73772411455596 9.01 35.67359411217135 139.73773547706685 9.01 35.67359411217135 139.73773547706685 35.928 35.67361808867365 139.73772411455596 35.928 35.67361808867365 139.73772411455596 9.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4174f214-603c-4609-86f5-02e8bc0e86d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4174f214-603c-4609-86f5-02e8bc0e86d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4174f214-603c-4609-86f5-02e8bc0e86d6">
											<gml:posList>35.673599290045544 139.7377518641992 35.928 35.673599290045544 139.7377518641992 38.156 35.67367578813957 139.73771604792242 38.156 35.67367578813957 139.73771604792242 35.928 35.673599290045544 139.7377518641992 35.928</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-939c71fb-02b1-4186-a889-6c2f3863bda9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-939c71fb-02b1-4186-a889-6c2f3863bda9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-939c71fb-02b1-4186-a889-6c2f3863bda9">
											<gml:posList>35.67360305039661 139.73775391440267 38.156 35.67360305039661 139.73775391440267 37.841 35.673674115237375 139.73772064535032 37.841 35.673674115237375 139.73772064535032 38.156 35.67360305039661 139.73775391440267 38.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecaccd21-b52a-4b05-bf99-f858d252af88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecaccd21-b52a-4b05-bf99-f858d252af88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecaccd21-b52a-4b05-bf99-f858d252af88">
											<gml:posList>35.67361644239884 139.73779632883037 38.156 35.67361644239884 139.73779632883037 37.841 35.67360305039661 139.73775391440267 37.841 35.67360305039661 139.73775391440267 38.156 35.67361644239884 139.73779632883037 38.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-159dc89b-2f87-4869-a348-afcf9d21f39e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-159dc89b-2f87-4869-a348-afcf9d21f39e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-159dc89b-2f87-4869-a348-afcf9d21f39e">
											<gml:posList>35.67361372127298 139.7377976134909 41.674 35.67369011091776 139.73776142179224 41.674 35.67369011091776 139.73776142179224 38.156 35.67368739880604 139.7377627064444 38.156 35.67368739880604 139.7377627064444 37.841 35.67361644239884 139.73779632883037 37.841 35.67361644239884 139.73779632883037 38.156 35.67361372127298 139.7377976134909 38.156 35.67361372127298 139.7377976134909 41.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a232a6b9-a66e-4738-b295-7821903881a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a232a6b9-a66e-4738-b295-7821903881a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a232a6b9-a66e-4738-b295-7821903881a5">
											<gml:posList>35.673618004637966 139.73779993924126 41.674 35.673618004637966 139.73779993924126 37.08 35.67368821318821 139.73776667124423 37.08 35.67368821318821 139.73776667124423 41.674 35.673618004637966 139.73779993924126 41.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-794f7cc1-1346-4196-9c3d-9465ca46c7e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-794f7cc1-1346-4196-9c3d-9465ca46c7e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-794f7cc1-1346-4196-9c3d-9465ca46c7e0">
											<gml:posList>35.67369011091776 139.73776142179224 38.156 35.67369011091776 139.73776142179224 41.674 35.67374564888379 139.73793747348554 41.674 35.67374564888379 139.73793747348554 36.856 35.67375750466632 139.737975062428 36.856 35.67375750466632 139.737975062428 9.01 35.67367031200946 139.7376986558817 9.01 35.67367031200946 139.7376986558817 35.928 35.67367578813957 139.73771604792242 35.928 35.67367578813957 139.73771604792242 38.156 35.67369011091776 139.73776142179224 38.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0269e06d-b504-4d96-a26b-4eee6dbb853b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0269e06d-b504-4d96-a26b-4eee6dbb853b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0269e06d-b504-4d96-a26b-4eee6dbb853b">
											<gml:posList>35.673599290045544 139.7377518641992 35.928 35.67359411217135 139.73773547706685 35.928 35.67359411217135 139.73773547706685 9.01 35.673689627240876 139.73803823095759 9.01 35.673689627240876 139.73803823095759 34.638 35.6736811149579 139.7380112539538 36.856 35.673669259186575 139.73797366504178 36.856 35.673669259186575 139.73797366504178 41.674 35.67361372127298 139.7377976134909 41.674 35.67361372127298 139.7377976134909 38.156 35.673599290045544 139.7377518641992 38.156 35.673599290045544 139.7377518641992 35.928</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-491da33e-32e8-4e04-bf46-015c842804d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-491da33e-32e8-4e04-bf46-015c842804d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-491da33e-32e8-4e04-bf46-015c842804d0">
											<gml:posList>35.673741365512775 139.73793513667746 41.674 35.673741365512775 139.73793513667746 37.08 35.67367115691642 139.7379684045492 37.08 35.67367115691642 139.7379684045492 41.674 35.673741365512775 139.73793513667746 41.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c271f5ee-2d20-4e3a-9067-c045ef6189fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c271f5ee-2d20-4e3a-9067-c045ef6189fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c271f5ee-2d20-4e3a-9067-c045ef6189fc">
											<gml:posList>35.67374564888379 139.73793747348554 36.856 35.67374564888379 139.73793747348554 41.674 35.673669259186575 139.73797366504178 41.674 35.673669259186575 139.73797366504178 36.856 35.67374564888379 139.73793747348554 36.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e72a3822-6483-4e91-bb29-c73c41815a9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e72a3822-6483-4e91-bb29-c73c41815a9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e72a3822-6483-4e91-bb29-c73c41815a9c">
											<gml:posList>35.67372558101646 139.73799019022044 9.01 35.67375750466632 139.737975062428 9.01 35.67375750466632 139.737975062428 36.856 35.67372558101646 139.73799019022044 36.856 35.67372558101646 139.73799019022044 9.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30029f4d-146b-45d2-b198-47e103a5cc11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30029f4d-146b-45d2-b198-47e103a5cc11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30029f4d-146b-45d2-b198-47e103a5cc11">
											<gml:posList>35.67373409330413 139.73801716723696 34.638 35.67373409330413 139.73801716723696 9.01 35.67372558101646 139.73799019022044 9.01 35.67372558101646 139.73799019022044 36.856 35.67373409330413 139.73801716723696 34.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e3f7d79-b0e5-4814-9f76-2b99b8367e24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e3f7d79-b0e5-4814-9f76-2b99b8367e24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e3f7d79-b0e5-4814-9f76-2b99b8367e24">
											<gml:posList>35.673689627240876 139.73803823095759 9.01 35.67373409330413 139.73801716723696 9.01 35.67373409330413 139.73801716723696 34.638 35.673689627240876 139.73803823095759 34.638 35.673689627240876 139.73803823095759 9.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3117</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">570.39703</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>