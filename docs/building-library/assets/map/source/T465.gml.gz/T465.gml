<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_87ff84f6-33ac-4aae-ac1c-3df5f03eb7bf">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">24.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67339786801387 139.73854838181992 0 35.67338713365998 139.73851529867744 0 35.67340601041293 139.7385064058703 0 35.6733968753743 139.73847826974801 0 35.673374284755184 139.73840682451072 0 35.67339672028991 139.73839586173702 0 35.67337756128451 139.73833258699375 0 35.673274662618496 139.73838087235853 0 35.673336922554455 139.7385780920835 0 35.67339786801387 139.73854838181992 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67339786801387 139.73854838181992 7.953 35.673336922554455 139.7385780920835 7.953 35.673274662618496 139.73838087235853 7.953 35.67337756128451 139.73833258699375 7.953 35.67339672028991 139.73839586173702 7.953 35.673374284755184 139.73840682451072 7.953 35.6733968753743 139.73847826974801 7.953 35.67340601041293 139.7385064058703 7.953 35.67338713365998 139.73851529867744 7.953 35.67339786801387 139.73854838181992 7.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67339786801387 139.73854838181992 7.953 35.67338713365998 139.73851529867744 7.953 35.67338713365998 139.73851529867744 31.07 35.67339786801387 139.73854838181992 31.07 35.67339786801387 139.73854838181992 7.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67338713365998 139.73851529867744 7.953 35.67340601041293 139.7385064058703 7.953 35.67340601041293 139.7385064058703 31.07 35.67338713365998 139.73851529867744 31.07 35.67338713365998 139.73851529867744 7.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67340601041293 139.7385064058703 7.953 35.6733968753743 139.73847826974801 7.953 35.6733968753743 139.73847826974801 31.07 35.67340601041293 139.7385064058703 31.07 35.67340601041293 139.7385064058703 7.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6733968753743 139.73847826974801 7.953 35.673374284755184 139.73840682451072 7.953 35.673374284755184 139.73840682451072 31.07 35.6733968753743 139.73847826974801 31.07 35.6733968753743 139.73847826974801 7.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673374284755184 139.73840682451072 7.953 35.67339672028991 139.73839586173702 7.953 35.67339672028991 139.73839586173702 31.07 35.673374284755184 139.73840682451072 31.07 35.673374284755184 139.73840682451072 7.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67339672028991 139.73839586173702 7.953 35.67337756128451 139.73833258699375 7.953 35.67337756128451 139.73833258699375 31.07 35.67339672028991 139.73839586173702 31.07 35.67339672028991 139.73839586173702 7.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67337756128451 139.73833258699375 7.953 35.673274662618496 139.73838087235853 7.953 35.673274662618496 139.73838087235853 31.07 35.67337756128451 139.73833258699375 31.07 35.67337756128451 139.73833258699375 7.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673274662618496 139.73838087235853 7.953 35.673336922554455 139.7385780920835 7.953 35.673336922554455 139.7385780920835 31.07 35.673274662618496 139.73838087235853 31.07 35.673274662618496 139.73838087235853 7.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673336922554455 139.7385780920835 7.953 35.67339786801387 139.73854838181992 7.953 35.67339786801387 139.73854838181992 31.07 35.673336922554455 139.7385780920835 31.07 35.673336922554455 139.7385780920835 7.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67339786801387 139.73854838181992 31.07 35.67338713365998 139.73851529867744 31.07 35.67340601041293 139.7385064058703 31.07 35.6733968753743 139.73847826974801 31.07 35.673374284755184 139.73840682451072 31.07 35.67339672028991 139.73839586173702 31.07 35.67337756128451 139.73833258699375 31.07 35.673274662618496 139.73838087235853 31.07 35.673336922554455 139.7385780920835 31.07 35.67339786801387 139.73854838181992 31.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6ff5d53c-6521-4819-bffb-b761c08834cb"/>
							<gml:surfaceMember xlink:href="#poly-28d4820d-144a-48af-ab1f-de6a77dacf26"/>
							<gml:surfaceMember xlink:href="#poly-a79a734d-c09e-4c43-a3cc-405ebff18e7b"/>
							<gml:surfaceMember xlink:href="#poly-1ba7045e-c12d-48bd-be35-90824b60c62c"/>
							<gml:surfaceMember xlink:href="#poly-f22fdb1f-40ad-47a3-9c61-3d884ce76eea"/>
							<gml:surfaceMember xlink:href="#poly-3520692a-6186-4b83-8049-0f445e7eaf1f"/>
							<gml:surfaceMember xlink:href="#poly-669592a5-76cd-4be9-b71d-a320a4ae8aff"/>
							<gml:surfaceMember xlink:href="#poly-24a6510c-4db6-4eda-80b3-b8e55d2480b1"/>
							<gml:surfaceMember xlink:href="#poly-dd055f69-9a0f-49fa-af84-e0a590673787"/>
							<gml:surfaceMember xlink:href="#poly-ccc55d7a-5386-41c6-8117-6797908f5d90"/>
							<gml:surfaceMember xlink:href="#poly-ce1b8870-e5d5-4376-8fba-27e8bd6e7d9d"/>
							<gml:surfaceMember xlink:href="#poly-488cfe85-0ec9-4cbd-abc6-139f9e1e6a24"/>
							<gml:surfaceMember xlink:href="#poly-7cd3344c-eb90-4cca-908e-fc759caa0bdf"/>
							<gml:surfaceMember xlink:href="#poly-fba8cd12-e211-4874-9f59-398efa10b5ac"/>
							<gml:surfaceMember xlink:href="#poly-47d3a42d-1944-4973-8fde-7983ea9c765a"/>
							<gml:surfaceMember xlink:href="#poly-20a1eb17-4a52-4340-8288-55f5f33d80b2"/>
							<gml:surfaceMember xlink:href="#poly-73c90753-3256-468b-9bf3-859129cba44d"/>
							<gml:surfaceMember xlink:href="#poly-a25a2bd9-1248-4907-8be6-b2e9f90fb6d1"/>
							<gml:surfaceMember xlink:href="#poly-21c017b3-7e35-4386-a4d8-b862e91adad7"/>
							<gml:surfaceMember xlink:href="#poly-899cf360-8652-482b-a595-9449ca6c0598"/>
							<gml:surfaceMember xlink:href="#poly-3ba8fc67-90ce-4c8b-84e2-e891717d2fb6"/>
							<gml:surfaceMember xlink:href="#poly-f48823b8-a6f4-41e6-893f-7aa98c1ce276"/>
							<gml:surfaceMember xlink:href="#poly-cfd9849c-5fa2-4012-bbcc-64ac799a1d03"/>
							<gml:surfaceMember xlink:href="#poly-e6532762-2f73-4d1d-b4b3-87bec165b0b3"/>
							<gml:surfaceMember xlink:href="#poly-d1f25d4d-2fc9-4cf9-9836-d83913342ae0"/>
							<gml:surfaceMember xlink:href="#poly-204845fa-8b04-4e67-8d02-9a573f45980b"/>
							<gml:surfaceMember xlink:href="#poly-9e6a4eaf-488c-4e71-a962-734533c0bdae"/>
							<gml:surfaceMember xlink:href="#poly-fa62b00d-4e3d-4448-9529-72277f47ff56"/>
							<gml:surfaceMember xlink:href="#poly-14c4b153-93ff-4be2-b58e-24232d34ed1d"/>
							<gml:surfaceMember xlink:href="#poly-d0a7c26f-74c0-454c-8f94-79c64e5e0b4e"/>
							<gml:surfaceMember xlink:href="#poly-84d3c1b7-c369-4716-992d-2959f794eaec"/>
							<gml:surfaceMember xlink:href="#poly-4d5a120a-7432-4262-b457-6f16e362ac99"/>
							<gml:surfaceMember xlink:href="#poly-3a3d89bb-c830-4659-930b-c23916e9ffa0"/>
							<gml:surfaceMember xlink:href="#poly-0a27438c-07df-46d5-b5cc-b64a04317d8f"/>
							<gml:surfaceMember xlink:href="#poly-0b4a81aa-bce8-4cc4-9221-560d711ab6a7"/>
							<gml:surfaceMember xlink:href="#poly-7a9fcdd4-463f-4a7d-991b-463a4ef289a7"/>
							<gml:surfaceMember xlink:href="#poly-04c171a3-bc5c-4489-bf85-ed489c094b87"/>
							<gml:surfaceMember xlink:href="#poly-e66b8c92-c1a9-420a-ab7e-a9f11853af19"/>
							<gml:surfaceMember xlink:href="#poly-4fe6f97b-0836-4325-9f32-c9f78991efe3"/>
							<gml:surfaceMember xlink:href="#poly-46401cd7-0a12-4830-9a88-25fbff715f20"/>
							<gml:surfaceMember xlink:href="#poly-669067a5-907a-4abb-990a-2c79e256ae10"/>
							<gml:surfaceMember xlink:href="#poly-284ece9d-e87c-4e1a-997e-462c521b6c09"/>
							<gml:surfaceMember xlink:href="#poly-091b1798-bd02-4150-864c-7b217511131a"/>
							<gml:surfaceMember xlink:href="#poly-dc9c08ef-bf40-4f2d-8a5f-d7d35e72297c"/>
							<gml:surfaceMember xlink:href="#poly-c7628676-d482-4c96-8ad0-b8a32fcd9cde"/>
							<gml:surfaceMember xlink:href="#poly-070a9afa-3846-4ca4-a4f9-1fd7e05ec64e"/>
							<gml:surfaceMember xlink:href="#poly-db1d1eae-f85b-41b9-b59b-a46faa0e4f60"/>
							<gml:surfaceMember xlink:href="#poly-4ec6f049-2483-4b62-931e-f875bcd9f1d2"/>
							<gml:surfaceMember xlink:href="#poly-fd4a4ae1-137c-43b3-b8ea-bef9a39202fd"/>
							<gml:surfaceMember xlink:href="#poly-ecb3ad46-2d73-421d-8641-8a5b8a5481ff"/>
							<gml:surfaceMember xlink:href="#poly-c0fc1411-ccbf-452c-a04f-c232636d8c69"/>
							<gml:surfaceMember xlink:href="#poly-bb23d989-aa09-4a8a-9379-fceea6b18e11"/>
							<gml:surfaceMember xlink:href="#poly-bf38422f-fe31-43f8-bbfa-f39725494df7"/>
							<gml:surfaceMember xlink:href="#poly-0291c404-cd38-4f6c-bc5a-96b3276c3711"/>
							<gml:surfaceMember xlink:href="#poly-96db6b94-52ff-4dfc-ba05-edf786190e97"/>
							<gml:surfaceMember xlink:href="#poly-b410e3f9-9477-4d7c-8dec-140062f1be01"/>
							<gml:surfaceMember xlink:href="#poly-6400d705-b768-41a3-b835-f7b5ecbf64b2"/>
							<gml:surfaceMember xlink:href="#poly-2096e652-1b3a-477b-8aaf-5a5b4bc3c57f"/>
							<gml:surfaceMember xlink:href="#poly-504f2e57-29b6-4ac4-80e6-49f6875a31a6"/>
							<gml:surfaceMember xlink:href="#poly-21101a88-3cb4-4488-9af5-b9e3354288bb"/>
							<gml:surfaceMember xlink:href="#poly-a955cee3-bb37-43d8-b088-81516e01cc33"/>
							<gml:surfaceMember xlink:href="#poly-a43a2ed1-cf89-480f-bfcd-af5982101036"/>
							<gml:surfaceMember xlink:href="#poly-1b22494e-1f73-492c-8615-b1532c5a1e66"/>
							<gml:surfaceMember xlink:href="#poly-ef251f88-d7c0-48aa-ac7c-cf05dd2dd276"/>
							<gml:surfaceMember xlink:href="#poly-c669e1c4-3511-402c-bc70-a3f56b7605ed"/>
							<gml:surfaceMember xlink:href="#poly-3ee02720-107c-47c1-a0f4-162976e19dfc"/>
							<gml:surfaceMember xlink:href="#poly-2aac5622-f27c-4da7-a1d2-df0ac632d9ff"/>
							<gml:surfaceMember xlink:href="#poly-6a3e92df-d8b6-4522-a17a-e879cf044d08"/>
							<gml:surfaceMember xlink:href="#poly-27be2398-3dcc-4a17-bac2-ec5a0782dd19"/>
							<gml:surfaceMember xlink:href="#poly-4088b8b8-0516-4789-997d-7d742c7c315e"/>
							<gml:surfaceMember xlink:href="#poly-f1812c99-23ce-41f9-9c13-3ae1db2c9760"/>
							<gml:surfaceMember xlink:href="#poly-24143432-e12a-4ac3-b5d1-0dcf8fe5d2b0"/>
							<gml:surfaceMember xlink:href="#poly-8bc12bfe-2f88-4629-8279-fbc963895f0b"/>
							<gml:surfaceMember xlink:href="#poly-95f3b622-6773-4e31-a9fa-625de816607f"/>
							<gml:surfaceMember xlink:href="#poly-df93dcbc-16df-4594-b9d3-81563caaa1d4"/>
							<gml:surfaceMember xlink:href="#poly-ef18fd60-0108-469b-be1e-99a17294d1af"/>
							<gml:surfaceMember xlink:href="#poly-19006095-eb57-481f-8893-c0f4cd3d04c1"/>
							<gml:surfaceMember xlink:href="#poly-d171f696-8cd2-4037-af72-dccc3a7572d1"/>
							<gml:surfaceMember xlink:href="#poly-e048c870-0428-4e52-8eda-6b164a1ee1f6"/>
							<gml:surfaceMember xlink:href="#poly-375b3638-6890-4e64-816c-51e948f7e122"/>
							<gml:surfaceMember xlink:href="#poly-18329c31-a7b2-4bdc-83ab-05256a543acd"/>
							<gml:surfaceMember xlink:href="#poly-9201a065-dd84-42c7-a5fa-96c6d3a8d63f"/>
							<gml:surfaceMember xlink:href="#poly-32f38365-de51-424d-a810-1c78fdfde107"/>
							<gml:surfaceMember xlink:href="#poly-35afa2de-04ff-4375-b5d8-ee22fd1b1e59"/>
							<gml:surfaceMember xlink:href="#poly-9679e074-aa99-468f-b168-2fd2bba516d9"/>
							<gml:surfaceMember xlink:href="#poly-030bf9ff-5f33-4716-a8d7-a6a5c04735b9"/>
							<gml:surfaceMember xlink:href="#poly-57191465-d3b5-45b4-a905-18eafa526c66"/>
							<gml:surfaceMember xlink:href="#poly-7e160b36-340a-4c28-82ab-3af71cd26be5"/>
							<gml:surfaceMember xlink:href="#poly-5242d9da-03df-4ab1-9231-80cf13cf62df"/>
							<gml:surfaceMember xlink:href="#poly-aa34fc25-32db-407c-9804-7ccb4dd088c9"/>
							<gml:surfaceMember xlink:href="#poly-201e4fdf-366e-42d7-b343-84642617fbc6"/>
							<gml:surfaceMember xlink:href="#poly-17e2fb71-ad16-4a9e-9882-d6dd10776119"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_87ff84f6-33ac-4aae-ac1c-3df5f03eb7bf_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4855d28-53cc-406b-bdb5-daaee1d33177">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673353303913494 139.73846795952608 31.583 35.673358683040284 139.73846533510013 31.583 35.673361158899816 139.73847307588596 31.583 35.67335253607894 139.7384772838231 31.583 35.673344194978625 139.73847296339864 31.583 35.67333708393191 139.73845107731952 31.583 35.67334389569105 139.7384477552573 31.583 35.67335003088957 139.7384666377989 31.583 35.673353303913494 139.73846795952608 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-723dd761-1735-4bea-996f-f799d971016a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67337416000264 139.73846583597896 33.966 35.67337519005559 139.7384689941082 33.966 35.67336863054076 139.73847213912472 33.966 35.67336840464083 139.73847143240505 33.966 35.67336624068716 139.73847059541865 33.966 35.673361158899816 139.73847307588596 33.966 35.673358683040284 139.73846533510013 33.966 35.67336699050248 139.73846128218796 33.966 35.67336913645489 139.73846215233542 33.966 35.67337261741232 139.73846425813036 33.966 35.67337416000264 139.73846583597896 33.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-624c5158-b91f-44f0-93e2-cd1734520d86">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67337519005559 139.7384689941082 31.583 35.67338020483489 139.73848443142248 31.583 35.673373663381895 139.73848762060322 31.583 35.67336863054076 139.73847213912472 31.583 35.67337519005559 139.7384689941082 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-052b7b56-7178-438a-be8e-22f7eb5807d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-052b7b56-7178-438a-be8e-22f7eb5807d4_0">
											<gml:posList>35.67333708393191 139.73845107731952 31.583 35.67333708393191 139.73845107731952 36.066 35.67334389569105 139.7384477552573 36.066 35.67334389569105 139.7384477552573 31.583 35.67333708393191 139.73845107731952 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce84d138-af24-4cfb-b9d4-cb370801cde7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce84d138-af24-4cfb-b9d4-cb370801cde7_0">
											<gml:posList>35.67333708393191 139.73845107731952 36.066 35.67333708393191 139.73845107731952 31.583 35.673344194978625 139.73847296339864 31.583 35.673344194978625 139.73847296339864 36.066 35.67333708393191 139.73845107731952 36.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e5f7302-25ea-45a6-bf2f-19a04d3d4b47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e5f7302-25ea-45a6-bf2f-19a04d3d4b47_0">
											<gml:posList>35.67335003088957 139.7384666377989 31.583 35.67334389569105 139.7384477552573 31.583 35.67334389569105 139.7384477552573 36.066 35.67335003088957 139.7384666377989 36.066 35.67335003088957 139.7384666377989 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da0ec469-2cdb-4ebe-9ad5-01089d551029">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da0ec469-2cdb-4ebe-9ad5-01089d551029_0">
											<gml:posList>35.673344194978625 139.73847296339864 36.066 35.673344194978625 139.73847296339864 31.583 35.67335253607894 139.7384772838231 31.583 35.67335253607894 139.7384772838231 36.066 35.673344194978625 139.73847296339864 36.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25090977-b831-46c2-98ab-da5803cbe6b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25090977-b831-46c2-98ab-da5803cbe6b6_0">
											<gml:posList>35.67335003088957 139.7384666377989 31.583 35.67335003088957 139.7384666377989 36.066 35.673353303913494 139.73846795952608 36.066 35.673353303913494 139.73846795952608 31.583 35.67335003088957 139.7384666377989 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8dca27fa-0d70-4c47-a664-b918a46348b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8dca27fa-0d70-4c47-a664-b918a46348b4_0">
											<gml:posList>35.673373663381895 139.73848762060322 36.066 35.67338020483489 139.73848443142248 36.066 35.67337416000264 139.73846583597896 36.066 35.67337261741232 139.73846425813036 36.066 35.67336913645489 139.73846215233542 36.066 35.67336699050248 139.73846128218796 36.066 35.673353303913494 139.73846795952608 36.066 35.67335003088957 139.7384666377989 36.066 35.67334389569105 139.7384477552573 36.066 35.67333708393191 139.73845107731952 36.066 35.673344194978625 139.73847296339864 36.066 35.67335253607894 139.7384772838231 36.066 35.67336624068716 139.73847059541865 36.066 35.67336840464083 139.73847143240505 36.066 35.673373663381895 139.73848762060322 36.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad0f33d4-03c2-464f-afb8-c46b9d8b9e7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad0f33d4-03c2-464f-afb8-c46b9d8b9e7a_0">
											<gml:posList>35.673361158899816 139.73847307588596 33.966 35.67336624068716 139.73847059541865 33.966 35.67336624068716 139.73847059541865 36.066 35.67335253607894 139.7384772838231 36.066 35.67335253607894 139.7384772838231 31.583 35.673361158899816 139.73847307588596 31.583 35.673361158899816 139.73847307588596 33.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30ae940b-4ed6-439d-a366-8abe9845e386">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30ae940b-4ed6-439d-a366-8abe9845e386_0">
											<gml:posList>35.673361158899816 139.73847307588596 31.583 35.673358683040284 139.73846533510013 31.583 35.673358683040284 139.73846533510013 33.966 35.673361158899816 139.73847307588596 33.966 35.673361158899816 139.73847307588596 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c732cfe-b220-4f02-a35e-a5482d6799cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c732cfe-b220-4f02-a35e-a5482d6799cc_0">
											<gml:posList>35.673358683040284 139.73846533510013 33.966 35.673358683040284 139.73846533510013 31.583 35.673353303913494 139.73846795952608 31.583 35.673353303913494 139.73846795952608 36.066 35.67336699050248 139.73846128218796 36.066 35.67336699050248 139.73846128218796 33.966 35.673358683040284 139.73846533510013 33.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8a14211-bc89-46d9-aa10-490186d9cf76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8a14211-bc89-46d9-aa10-490186d9cf76_0">
											<gml:posList>35.67336840464083 139.73847143240505 33.966 35.67336840464083 139.73847143240505 36.066 35.67336624068716 139.73847059541865 36.066 35.67336624068716 139.73847059541865 33.966 35.67336840464083 139.73847143240505 33.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2eb9a48d-34e6-49b5-b824-a8289860e683">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2eb9a48d-34e6-49b5-b824-a8289860e683_0">
											<gml:posList>35.67336699050248 139.73846128218796 33.966 35.67336699050248 139.73846128218796 36.066 35.67336913645489 139.73846215233542 36.066 35.67336913645489 139.73846215233542 33.966 35.67336699050248 139.73846128218796 33.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10a83d8b-6297-49ef-b0b3-7e941bec6a62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10a83d8b-6297-49ef-b0b3-7e941bec6a62_0">
											<gml:posList>35.67337261741232 139.73846425813036 36.066 35.67337261741232 139.73846425813036 33.966 35.67336913645489 139.73846215233542 33.966 35.67336913645489 139.73846215233542 36.066 35.67337261741232 139.73846425813036 36.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8bd3083-00c8-41c3-b111-3e8729188a2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8bd3083-00c8-41c3-b111-3e8729188a2a_0">
											<gml:posList>35.67336863054076 139.73847213912472 33.966 35.67336863054076 139.73847213912472 31.583 35.673373663381895 139.73848762060322 31.583 35.673373663381895 139.73848762060322 36.066 35.67336840464083 139.73847143240505 36.066 35.67336840464083 139.73847143240505 33.966 35.67336863054076 139.73847213912472 33.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f15062f9-46cd-488f-b3d6-0737c695c024">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f15062f9-46cd-488f-b3d6-0737c695c024_0">
											<gml:posList>35.67336863054076 139.73847213912472 31.583 35.67336863054076 139.73847213912472 33.966 35.67337519005559 139.7384689941082 33.966 35.67337519005559 139.7384689941082 31.583 35.67336863054076 139.73847213912472 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-451029d9-6b31-4840-bbe4-c1cc6b799b55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-451029d9-6b31-4840-bbe4-c1cc6b799b55_0">
											<gml:posList>35.67337261741232 139.73846425813036 33.966 35.67337261741232 139.73846425813036 36.066 35.67337416000264 139.73846583597896 36.066 35.67337416000264 139.73846583597896 33.966 35.67337261741232 139.73846425813036 33.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45288539-c671-46e0-bd15-04fd77060b41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45288539-c671-46e0-bd15-04fd77060b41_0">
											<gml:posList>35.67338020483489 139.73848443142248 36.066 35.673373663381895 139.73848762060322 36.066 35.673373663381895 139.73848762060322 31.583 35.67338020483489 139.73848443142248 31.583 35.67338020483489 139.73848443142248 36.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44f8922d-71eb-4f12-81bf-106ac08656e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44f8922d-71eb-4f12-81bf-106ac08656e8_0">
											<gml:posList>35.67337519005559 139.7384689941082 33.966 35.67337416000264 139.73846583597896 33.966 35.67337416000264 139.73846583597896 36.066 35.67338020483489 139.73848443142248 36.066 35.67338020483489 139.73848443142248 31.583 35.67337519005559 139.7384689941082 31.583 35.67337519005559 139.7384689941082 33.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_87ff84f6-33ac-4aae-ac1c-3df5f03eb7bf_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a95131b-2ca8-4241-9087-cd27c15091cf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673350318758246 139.73850024142376 30.717 35.67335754508014 139.7384968305014 30.717 35.6733664278087 139.73852506633045 30.717 35.673359192480994 139.73852848830796 30.717 35.673350318758246 139.73850024142376 30.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8e73278-0af7-47ff-b51a-777358cab2f5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67339786801386 139.73854838181992 8.09 35.673387133668655 139.73851530972408 8.09 35.67340601041294 139.7385064058703 8.09 35.67341666343709 139.73853922399533 8.09 35.67339786801386 139.73854838181992 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de598c72-2166-4398-9c0d-586600007fde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de598c72-2166-4398-9c0d-586600007fde_0">
											<gml:posList>35.673350318758246 139.73850024142376 31.934 35.67335754508014 139.7384968305014 31.934 35.67335754508014 139.7384968305014 30.717 35.673350318758246 139.73850024142376 30.717 35.673350318758246 139.73850024142376 31.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f6c05a6-e466-48cb-b5b6-7a032732f3a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f6c05a6-e466-48cb-b5b6-7a032732f3a6_0">
											<gml:posList>35.673359192480994 139.73852848830796 31.934 35.673350318758246 139.73850024142376 31.934 35.673350318758246 139.73850024142376 30.717 35.673359192480994 139.73852848830796 30.717 35.673359192480994 139.73852848830796 31.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89611b28-82f7-4b8a-afb0-52b73e43b2dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89611b28-82f7-4b8a-afb0-52b73e43b2dc_0">
											<gml:posList>35.67335754508014 139.7384968305014 31.934 35.673350318758246 139.73850024142376 31.934 35.673359192480994 139.73852848830796 31.934 35.6733664278087 139.73852506633045 31.934 35.67335754508014 139.7384968305014 31.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eeaf0e3b-bc53-443a-a996-767c6d52451f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eeaf0e3b-bc53-443a-a996-767c6d52451f_0">
											<gml:posList>35.67335754508014 139.7384968305014 31.934 35.6733664278087 139.73852506633045 31.934 35.6733664278087 139.73852506633045 30.717 35.67335754508014 139.7384968305014 30.717 35.67335754508014 139.7384968305014 31.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-003e4f7b-2ee3-4a49-8fe6-8fc881e2520d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-003e4f7b-2ee3-4a49-8fe6-8fc881e2520d_0">
											<gml:posList>35.6733664278087 139.73852506633045 31.934 35.673359192480994 139.73852848830796 31.934 35.673359192480994 139.73852848830796 30.717 35.6733664278087 139.73852506633045 30.717 35.6733664278087 139.73852506633045 31.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce666dad-2f01-4132-8312-16791d9c1455">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce666dad-2f01-4132-8312-16791d9c1455_0">
											<gml:posList>35.67339786801386 139.73854838181992 30.953 35.673387133668655 139.73851530972408 30.953 35.673387133668655 139.73851530972408 8.09 35.67339786801386 139.73854838181992 8.09 35.67339786801386 139.73854838181992 30.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-068cf63b-9f68-4eed-92ad-fc46240bb213">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-068cf63b-9f68-4eed-92ad-fc46240bb213_0">
											<gml:posList>35.673387133668655 139.73851530972408 30.953 35.67340601041294 139.7385064058703 30.953 35.67340601041294 139.7385064058703 8.09 35.673387133668655 139.73851530972408 8.09 35.673387133668655 139.73851530972408 30.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-742bfa44-5e9f-47a1-b58b-92a918d9818f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-742bfa44-5e9f-47a1-b58b-92a918d9818f_0">
											<gml:posList>35.673387133668655 139.73851530972408 30.953 35.67339786801386 139.73854838181992 30.953 35.67341666343709 139.73853922399533 30.953 35.67340601041294 139.7385064058703 30.953 35.673387133668655 139.73851530972408 30.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a02149c-7cbe-45ae-b3c2-d9a1f665fee1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a02149c-7cbe-45ae-b3c2-d9a1f665fee1_0">
											<gml:posList>35.67341666343709 139.73853922399533 30.953 35.67339786801386 139.73854838181992 30.953 35.67339786801386 139.73854838181992 8.09 35.67341666343709 139.73853922399533 8.09 35.67341666343709 139.73853922399533 30.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe8fc67f-fb7b-43ab-b477-7bb4618bf1dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe8fc67f-fb7b-43ab-b477-7bb4618bf1dc_0">
											<gml:posList>35.67340601041294 139.7385064058703 30.953 35.67341666343709 139.73853922399533 30.953 35.67341666343709 139.73853922399533 8.09 35.67340601041294 139.7385064058703 8.09 35.67340601041294 139.7385064058703 30.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_87ff84f6-33ac-4aae-ac1c-3df5f03eb7bf_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f67fef02-9700-4039-a3d2-27dacec9801a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673317095543005 139.7383761825019 33.336 35.673325771637536 139.73840524704787 33.336 35.67330701168697 139.7384136536784 33.336 35.67329834460816 139.73838458912763 33.336 35.673317095543005 139.7383761825019 33.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe6d9591-0d24-4878-99ff-b56e12de7d5e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673323748739165 139.7384575774944 31.583 35.673316429869175 139.73843505096175 31.583 35.67333787428959 139.73842458647724 31.583 35.67334519316151 139.73844711301496 31.583 35.673323748739165 139.7384575774944 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07723602-378a-43c5-ae61-372c8e1665c0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673355908987716 139.7384566557008 31.583 35.67337343406182 139.73844825053672 31.583 35.673379406891485 139.73846697862402 31.583 35.67336188180738 139.73847537273795 31.583 35.673355908987716 139.7384566557008 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c4f50f1-51eb-4b3c-8f4f-346731e8f779">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c4f50f1-51eb-4b3c-8f4f-346731e8f779_0">
											<gml:posList>35.67329834460816 139.73838458912763 36.054 35.67329834460816 139.73838458912763 33.336 35.67330701168697 139.7384136536784 33.336 35.67330701168697 139.7384136536784 36.054 35.67329834460816 139.73838458912763 36.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f95496b-c1ef-4e86-a695-f1ed7437fbaa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f95496b-c1ef-4e86-a695-f1ed7437fbaa_0">
											<gml:posList>35.67329834460816 139.73838458912763 36.054 35.673317095543005 139.7383761825019 36.054 35.673317095543005 139.7383761825019 33.336 35.67329834460816 139.73838458912763 33.336 35.67329834460816 139.73838458912763 36.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7623ae3a-ad05-49e8-adf5-89e52e4400b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7623ae3a-ad05-49e8-adf5-89e52e4400b3_0">
											<gml:posList>35.673317095543005 139.7383761825019 36.054 35.67329834460816 139.73838458912763 36.054 35.67330701168697 139.7384136536784 36.054 35.673325771637536 139.73840524704787 36.054 35.673317095543005 139.7383761825019 36.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-575a02a6-d780-4040-92de-944876a497f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-575a02a6-d780-4040-92de-944876a497f8_0">
											<gml:posList>35.67330701168697 139.7384136536784 36.054 35.67330701168697 139.7384136536784 33.336 35.673325771637536 139.73840524704787 33.336 35.673325771637536 139.73840524704787 36.054 35.67330701168697 139.7384136536784 36.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a6688b6-0c8a-4535-8908-c9be99b7f3a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a6688b6-0c8a-4535-8908-c9be99b7f3a4_0">
											<gml:posList>35.673316429869175 139.73843505096175 36.312 35.673316429869175 139.73843505096175 31.583 35.673323748739165 139.7384575774944 31.583 35.673323748739165 139.7384575774944 36.312 35.673316429869175 139.73843505096175 36.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6547ceb7-f3ff-4fd1-aa20-1f46d19ab754">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6547ceb7-f3ff-4fd1-aa20-1f46d19ab754_0">
											<gml:posList>35.673317095543005 139.7383761825019 36.054 35.673325771637536 139.73840524704787 36.054 35.673325771637536 139.73840524704787 33.336 35.673317095543005 139.7383761825019 33.336 35.673317095543005 139.7383761825019 36.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b77b569b-7f67-4e96-9446-173be9b5882a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b77b569b-7f67-4e96-9446-173be9b5882a_0">
											<gml:posList>35.673316429869175 139.73843505096175 36.312 35.67333787428959 139.73842458647724 36.312 35.67333787428959 139.73842458647724 31.583 35.673316429869175 139.73843505096175 31.583 35.673316429869175 139.73843505096175 36.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53684514-12a4-4aa9-bcc8-2d367a77296b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53684514-12a4-4aa9-bcc8-2d367a77296b_0">
											<gml:posList>35.673316429869175 139.73843505096175 36.312 35.673323748739165 139.7384575774944 36.312 35.67334519316151 139.73844711301496 36.312 35.67333787428959 139.73842458647724 36.312 35.673316429869175 139.73843505096175 36.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f45412ff-5f16-4650-98d5-65d8e97b8fe4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f45412ff-5f16-4650-98d5-65d8e97b8fe4_0">
											<gml:posList>35.67334519316151 139.73844711301496 31.583 35.67334519316151 139.73844711301496 36.312 35.673323748739165 139.7384575774944 36.312 35.673323748739165 139.7384575774944 31.583 35.67334519316151 139.73844711301496 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-223944c8-7566-459f-ac96-fe27d586bb38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-223944c8-7566-459f-ac96-fe27d586bb38_0">
											<gml:posList>35.67333787428959 139.73842458647724 36.312 35.67334519316151 139.73844711301496 36.312 35.67334519316151 139.73844711301496 31.583 35.67333787428959 139.73842458647724 31.583 35.67333787428959 139.73842458647724 36.312</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b8916cc-e3e5-4c55-b782-16918ad68c4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b8916cc-e3e5-4c55-b782-16918ad68c4c_0">
											<gml:posList>35.673355908987716 139.7384566557008 31.583 35.67336188180738 139.73847537273795 31.583 35.67336188180738 139.73847537273795 33.966 35.673355908987716 139.7384566557008 33.966 35.673355908987716 139.7384566557008 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11f33ab8-e187-46c2-83dd-fd4c612067c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11f33ab8-e187-46c2-83dd-fd4c612067c4_0">
											<gml:posList>35.673355908987716 139.7384566557008 33.966 35.67337343406182 139.73844825053672 33.966 35.67337343406182 139.73844825053672 31.583 35.673355908987716 139.7384566557008 31.583 35.673355908987716 139.7384566557008 33.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-379822e4-eba1-49a3-8bc6-f7b20b6318da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-379822e4-eba1-49a3-8bc6-f7b20b6318da_0">
											<gml:posList>35.673355908987716 139.7384566557008 33.966 35.67336188180738 139.73847537273795 33.966 35.673379406891485 139.73846697862402 33.966 35.67337343406182 139.73844825053672 33.966 35.673355908987716 139.7384566557008 33.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19d1c2fa-9b55-41c2-8786-0c015fd6d40c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19d1c2fa-9b55-41c2-8786-0c015fd6d40c_0">
											<gml:posList>35.67336188180738 139.73847537273795 33.966 35.67336188180738 139.73847537273795 31.583 35.673379406891485 139.73846697862402 31.583 35.673379406891485 139.73846697862402 33.966 35.67336188180738 139.73847537273795 33.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-899b2f3a-8f61-461d-8d51-ec88b35899ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-899b2f3a-8f61-461d-8d51-ec88b35899ec_0">
											<gml:posList>35.673379406891485 139.73846697862402 33.966 35.673379406891485 139.73846697862402 31.583 35.67337343406182 139.73844825053672 31.583 35.67337343406182 139.73844825053672 33.966 35.673379406891485 139.73846697862402 33.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_87ff84f6-33ac-4aae-ac1c-3df5f03eb7bf_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41bdb184-7f2f-4a7e-ae55-9a7dcfa375a9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67333841102375 139.73846514920243 31.583 35.67334169095785 139.73847524197498 31.583 35.673332626638725 139.73847967136658 31.583 35.673329346705 139.73846957859496 31.583 35.67333841102375 139.73846514920243 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4dadc27-df3a-44d1-b9d8-6c6157f968aa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67333427311346 139.73854449125616 30.717 35.673349554526006 139.73853703878012 30.717 35.67335653003831 139.7385585273504 30.717 35.673341239610735 139.73856597983365 30.717 35.67333427311346 139.73854449125616 30.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-278721d9-130f-4dd9-90f1-8d8c08c3e8d5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67336145605731 139.73841551133694 38.441 35.673362222223304 139.73841551042983 38.441 35.67335773511607 139.73841770298299 38.441 35.67335788818382 139.73841749291503 38.441 35.67335895104492 139.73841653059642 38.441 35.673360158351905 139.73841585532017 38.441 35.67336145605731 139.73841551133694 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bf3b3b2-3108-4443-b8d6-3d62e5665d78">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67335700578863 139.73841869804673 38.182 35.67335773511607 139.73841770298299 38.182 35.67336223123702 139.73841551041914 38.182 35.67336277205138 139.73841549873217 38.182 35.67336407028797 139.73841582859518 38.182 35.673365287662335 139.73841648995406 38.182 35.673366361034915 139.73841742765026 38.182 35.67336725434211 139.73841863067975 38.182 35.6733679224631 139.73842003281595 38.182 35.67336833830446 139.73842156781086 38.182 35.67336848379523 139.7384231804526 38.182 35.67336834986942 139.73842480447178 38.182 35.673367954476134 139.7384263404271 38.182 35.67336729758924 139.73842775517863 38.182 35.67336641520266 139.738428971357 38.182 35.673365352341456 139.73842993367555 38.182 35.67336414502568 139.738430597905 38.182 35.673362847320234 139.73843094188797 38.182 35.67336152231245 139.73843095450317 38.182 35.67336022407589 139.7384306246399 38.182 35.67335901572403 139.73842997431683 38.182 35.67335794234285 139.7384290255739 38.182 35.67335704903576 139.73842782254445 38.182 35.67335638091485 139.7384264204084 38.182 35.673355965073554 139.73842488541365 38.182 35.67335581958282 139.7384232727722 38.182 35.67335594450359 139.73842165981057 38.182 35.67335634890182 139.7384201127981 38.182 35.67335700578863 139.73841869804673 38.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf28aeea-3549-4af9-b0d0-5627a7f2da7b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67336141906222 139.73840288503692 33.336 35.67335536408865 139.7383828756423 33.336 35.67336627579813 139.7383779138102 33.336 35.67337233977752 139.73839791214982 33.336 35.67336141906222 139.73840288503692 33.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf22c829-da9c-442c-a710-2a3cc75463cb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673370607083086 139.73853258417114 30.717 35.6733740858177 139.7385433174224 30.717 35.67335835389285 139.7385509913656 30.717 35.67335486614521 139.73854025812673 30.717 35.673370607083086 139.73853258417114 30.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d5309a2-ba26-49c5-82e5-9eed160a4aa9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67339090071943 139.73838861096382 37.078 35.67337744804702 139.73839472465906 37.078 35.67337245947851 139.73837824893278 37.078 35.67338591215009 139.73837213523518 37.078 35.67339090071943 139.73838861096382 37.078</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43db17de-d0f2-4fef-8d3f-dda2544ae295">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673393785515046 139.7385035040084 35.026 35.67338127009812 139.7385094066892 35.026 35.67337683323534 139.7384952832435 35.026 35.67338934864288 139.73848936951413 35.026 35.673393785515046 139.7385035040084 35.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db62a928-125b-485b-b613-b35473c4a38b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db62a928-125b-485b-b613-b35473c4a38b_0">
											<gml:posList>35.67335835389285 139.7385509913656 32.733 35.67335486614521 139.73854025812673 32.733 35.67335486614521 139.73854025812673 30.717 35.67335835389285 139.7385509913656 30.717 35.67335835389285 139.7385509913656 32.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5071afc2-a251-4c0d-91b0-7573047f0b31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5071afc2-a251-4c0d-91b0-7573047f0b31_0">
											<gml:posList>35.673329346705 139.73846957859496 33.756 35.673329346705 139.73846957859496 31.583 35.673332626638725 139.73847967136658 31.583 35.673332626638725 139.73847967136658 33.756 35.673329346705 139.73846957859496 33.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aaa30189-96bf-4c2f-bac0-cbafe305b2e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aaa30189-96bf-4c2f-bac0-cbafe305b2e7_0">
											<gml:posList>35.67333841102375 139.73846514920243 33.756 35.67333841102375 139.73846514920243 31.583 35.673329346705 139.73846957859496 31.583 35.673329346705 139.73846957859496 33.756 35.67333841102375 139.73846514920243 33.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-012a4ded-2c9e-4e12-991a-4ebc73a6ea9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-012a4ded-2c9e-4e12-991a-4ebc73a6ea9d_0">
											<gml:posList>35.67333841102375 139.73846514920243 33.756 35.673329346705 139.73846957859496 33.756 35.673332626638725 139.73847967136658 33.756 35.67334169095785 139.73847524197498 33.756 35.67333841102375 139.73846514920243 33.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82721864-94b5-4472-aca8-57db9c5db386">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82721864-94b5-4472-aca8-57db9c5db386_0">
											<gml:posList>35.673332626638725 139.73847967136658 33.756 35.673332626638725 139.73847967136658 31.583 35.67334169095785 139.73847524197498 31.583 35.67334169095785 139.73847524197498 33.756 35.673332626638725 139.73847967136658 33.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fa05e0e-f741-4a05-8d64-4032ce2d9f59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fa05e0e-f741-4a05-8d64-4032ce2d9f59_0">
											<gml:posList>35.673341239610735 139.73856597983365 32.733 35.67333427311346 139.73854449125616 32.733 35.67333427311346 139.73854449125616 30.717 35.673341239610735 139.73856597983365 30.717 35.673341239610735 139.73856597983365 32.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a32e600-7b73-4b9b-97ef-4a91679a9fff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a32e600-7b73-4b9b-97ef-4a91679a9fff_0">
											<gml:posList>35.67334169095785 139.73847524197498 33.756 35.67334169095785 139.73847524197498 31.583 35.67333841102375 139.73846514920243 31.583 35.67333841102375 139.73846514920243 33.756 35.67334169095785 139.73847524197498 33.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf692996-631b-4e86-b582-2db1d7f78cd5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf692996-631b-4e86-b582-2db1d7f78cd5_0">
											<gml:posList>35.67333427311346 139.73854449125616 32.733 35.673349554526006 139.73853703878012 32.733 35.673349554526006 139.73853703878012 30.717 35.67333427311346 139.73854449125616 30.717 35.67333427311346 139.73854449125616 32.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d54b2aa4-7fc7-47ac-ae0c-94df64177dc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d54b2aa4-7fc7-47ac-ae0c-94df64177dc3_0">
											<gml:posList>35.67335653003831 139.7385585273504 32.733 35.673349554526006 139.73853703878012 32.733 35.67333427311346 139.73854449125616 32.733 35.673341239610735 139.73856597983365 32.733 35.67335653003831 139.7385585273504 32.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a40f008-b908-49f1-989b-44b4535ce1c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a40f008-b908-49f1-989b-44b4535ce1c4_0">
											<gml:posList>35.67335653003831 139.7385585273504 32.733 35.673341239610735 139.73856597983365 32.733 35.673341239610735 139.73856597983365 30.717 35.67335653003831 139.7385585273504 30.717 35.67335653003831 139.7385585273504 32.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4bd8e98-6e95-4589-9c7c-738055a3ec23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4bd8e98-6e95-4589-9c7c-738055a3ec23_0">
											<gml:posList>35.67335653003831 139.7385585273504 32.733 35.67335653003831 139.7385585273504 30.717 35.673349554526006 139.73853703878012 30.717 35.673349554526006 139.73853703878012 32.733 35.67335653003831 139.7385585273504 32.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fc323bc-4638-4cf5-8d8f-997d55478926">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fc323bc-4638-4cf5-8d8f-997d55478926_0">
											<gml:posList>35.67335581958282 139.7384232727722 40.009 35.67335594450359 139.73842165981057 40.009 35.67335594450359 139.73842165981057 38.182 35.67335581958282 139.7384232727722 38.182 35.67335581958282 139.7384232727722 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e251787-a5df-482a-9fcd-475e377a6ea4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e251787-a5df-482a-9fcd-475e377a6ea4_0">
											<gml:posList>35.673355965073554 139.73842488541365 40.009 35.67335581958282 139.7384232727722 40.009 35.67335581958282 139.7384232727722 38.182 35.673355965073554 139.73842488541365 38.182 35.673355965073554 139.73842488541365 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81a98035-c1bd-4fd6-882e-67850b8344ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81a98035-c1bd-4fd6-882e-67850b8344ef_0">
											<gml:posList>35.67335594450359 139.73842165981057 40.009 35.67335634890182 139.7384201127981 40.009 35.67335634890182 139.7384201127981 38.182 35.67335594450359 139.73842165981057 38.182 35.67335594450359 139.73842165981057 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d80f3d8-207f-4bca-a45a-2e5748c36e3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d80f3d8-207f-4bca-a45a-2e5748c36e3e_0">
											<gml:posList>35.67335638091485 139.7384264204084 40.009 35.673355965073554 139.73842488541365 40.009 35.673355965073554 139.73842488541365 38.182 35.67335638091485 139.7384264204084 38.182 35.67335638091485 139.7384264204084 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c9ee386-eb37-4042-b605-063c9521ea62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c9ee386-eb37-4042-b605-063c9521ea62_0">
											<gml:posList>35.67335634890182 139.7384201127981 40.009 35.67335700578863 139.73841869804673 40.009 35.67335700578863 139.73841869804673 38.182 35.67335634890182 139.7384201127981 38.182 35.67335634890182 139.7384201127981 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4657ffb5-c0b5-42a6-896b-041b7e2ddcfe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4657ffb5-c0b5-42a6-896b-041b7e2ddcfe_0">
											<gml:posList>35.67335704903576 139.73842782254445 40.009 35.67335638091485 139.7384264204084 40.009 35.67335638091485 139.7384264204084 38.182 35.67335704903576 139.73842782254445 38.182 35.67335704903576 139.73842782254445 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80ba4292-d8fd-40e0-a6b3-b4d4a1b263f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80ba4292-d8fd-40e0-a6b3-b4d4a1b263f7_0">
											<gml:posList>35.67335773511607 139.73841770298299 38.182 35.67335700578863 139.73841869804673 38.182 35.67335700578863 139.73841869804673 40.009 35.67335788818382 139.73841749291503 40.009 35.67335788818382 139.73841749291503 38.441 35.67335773511607 139.73841770298299 38.441 35.67335773511607 139.73841770298299 38.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00643710-bb6a-44be-b84e-0372b6be69da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00643710-bb6a-44be-b84e-0372b6be69da_0">
											<gml:posList>35.67335794234285 139.7384290255739 40.009 35.67335704903576 139.73842782254445 40.009 35.67335704903576 139.73842782254445 38.182 35.67335794234285 139.7384290255739 38.182 35.67335794234285 139.7384290255739 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da777dc1-544e-44f3-a9b6-8282353e041a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da777dc1-544e-44f3-a9b6-8282353e041a_0">
											<gml:posList>35.67336141906222 139.73840288503692 35.216 35.67335536408865 139.7383828756423 35.216 35.67335536408865 139.7383828756423 33.336 35.67336141906222 139.73840288503692 33.336 35.67336141906222 139.73840288503692 35.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ddd7de1-9112-4637-bdc2-6307d46a0f94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ddd7de1-9112-4637-bdc2-6307d46a0f94_0">
											<gml:posList>35.67335788818382 139.73841749291503 40.009 35.67335895104492 139.73841653059642 40.009 35.67335895104492 139.73841653059642 38.441 35.67335788818382 139.73841749291503 38.441 35.67335788818382 139.73841749291503 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb7b427f-9c27-4c63-a463-a928204a273c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb7b427f-9c27-4c63-a463-a928204a273c_0">
											<gml:posList>35.67335794234285 139.7384290255739 40.009 35.67335794234285 139.7384290255739 38.182 35.67335901572403 139.73842997431683 38.182 35.67335901572403 139.73842997431683 40.009 35.67335794234285 139.7384290255739 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9a14a06-5b30-437f-b505-efa769d1f53f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9a14a06-5b30-437f-b505-efa769d1f53f_0">
											<gml:posList>35.67335895104492 139.73841653059642 40.009 35.673360158351905 139.73841585532017 40.009 35.673360158351905 139.73841585532017 38.441 35.67335895104492 139.73841653059642 38.441 35.67335895104492 139.73841653059642 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-977ef950-835a-4f04-bfd3-21a3048d801b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-977ef950-835a-4f04-bfd3-21a3048d801b_0">
											<gml:posList>35.67336022407589 139.7384306246399 40.009 35.67335901572403 139.73842997431683 40.009 35.67335901572403 139.73842997431683 38.182 35.67336022407589 139.7384306246399 38.182 35.67336022407589 139.7384306246399 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed2e3f4a-1d20-46fd-a2ed-f9cdd93b4fee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed2e3f4a-1d20-46fd-a2ed-f9cdd93b4fee_0">
											<gml:posList>35.67335773511607 139.73841770298299 38.441 35.673362222223304 139.73841551042983 38.441 35.67336223123702 139.73841551041914 38.182 35.67335773511607 139.73841770298299 38.182 35.67335773511607 139.73841770298299 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a849dac-01dd-47d0-8b02-83f6fa779fa5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a849dac-01dd-47d0-8b02-83f6fa779fa5_0">
											<gml:posList>35.673360158351905 139.73841585532017 40.009 35.67336145605731 139.73841551133694 40.009 35.67336145605731 139.73841551133694 38.441 35.673360158351905 139.73841585532017 38.441 35.673360158351905 139.73841585532017 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f8a19ad-6b80-4ef4-a9c3-2f6a48e75bf9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f8a19ad-6b80-4ef4-a9c3-2f6a48e75bf9_0">
											<gml:posList>35.67336627579813 139.7383779138102 35.216 35.67336627579813 139.7383779138102 33.336 35.67335536408865 139.7383828756423 33.336 35.67335536408865 139.7383828756423 35.216 35.67336627579813 139.7383779138102 35.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1f47775-f4c3-41dd-8971-6d4b267d236e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1f47775-f4c3-41dd-8971-6d4b267d236e_0">
											<gml:posList>35.67336152231245 139.73843095450317 40.009 35.67336022407589 139.7384306246399 40.009 35.67336022407589 139.7384306246399 38.182 35.67336152231245 139.73843095450317 38.182 35.67336152231245 139.73843095450317 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-492d53bc-07e1-4271-91d4-2ba15fbe1b87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-492d53bc-07e1-4271-91d4-2ba15fbe1b87_0">
											<gml:posList>35.67336277205138 139.73841549873217 38.182 35.67336223123702 139.73841551041914 38.182 35.673362222223304 139.73841551042983 38.441 35.67336145605731 139.73841551133694 38.441 35.67336145605731 139.73841551133694 40.009 35.67336277205138 139.73841549873217 40.009 35.67336277205138 139.73841549873217 38.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d76cbe3a-ccbc-4823-b62e-4a238d8c193d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d76cbe3a-ccbc-4823-b62e-4a238d8c193d_0">
											<gml:posList>35.673367954476134 139.7384263404271 40.009 35.67336834986942 139.73842480447178 40.009 35.67336848379523 139.7384231804526 40.009 35.67336833830446 139.73842156781086 40.009 35.6733679224631 139.73842003281595 40.009 35.67336725434211 139.73841863067975 40.009 35.673366361034915 139.73841742765026 40.009 35.673365287662335 139.73841648995406 40.009 35.67336407028797 139.73841582859518 40.009 35.67336277205138 139.73841549873217 40.009 35.67336145605731 139.73841551133694 40.009 35.673360158351905 139.73841585532017 40.009 35.67335895104492 139.73841653059642 40.009 35.67335788818382 139.73841749291503 40.009 35.67335700578863 139.73841869804673 40.009 35.67335634890182 139.7384201127981 40.009 35.67335594450359 139.73842165981057 40.009 35.67335581958282 139.7384232727722 40.009 35.673355965073554 139.73842488541365 40.009 35.67335638091485 139.7384264204084 40.009 35.67335704903576 139.73842782254445 40.009 35.67335794234285 139.7384290255739 40.009 35.67335901572403 139.73842997431683 40.009 35.67336022407589 139.7384306246399 40.009 35.67336152231245 139.73843095450317 40.009 35.673362847320234 139.73843094188797 40.009 35.67336414502568 139.738430597905 40.009 35.673365352341456 139.73842993367555 40.009 35.67336641520266 139.738428971357 40.009 35.67336729758924 139.73842775517863 40.009 35.673367954476134 139.7384263404271 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c20743f-5f51-4e4b-8aac-7ba1bd354c8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c20743f-5f51-4e4b-8aac-7ba1bd354c8a_0">
											<gml:posList>35.673362847320234 139.73843094188797 40.009 35.67336152231245 139.73843095450317 40.009 35.67336152231245 139.73843095450317 38.182 35.673362847320234 139.73843094188797 38.182 35.673362847320234 139.73843094188797 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31b0dc71-9fca-42a1-b3f0-10ee63c0274b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31b0dc71-9fca-42a1-b3f0-10ee63c0274b_0">
											<gml:posList>35.673370607083086 139.73853258417114 32.733 35.673370607083086 139.73853258417114 30.717 35.67335486614521 139.73854025812673 30.717 35.67335486614521 139.73854025812673 32.733 35.673370607083086 139.73853258417114 32.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dc37a6a-70f2-4073-b1c1-21299286dc28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dc37a6a-70f2-4073-b1c1-21299286dc28_0">
											<gml:posList>35.67336277205138 139.73841549873217 40.009 35.67336407028797 139.73841582859518 40.009 35.67336407028797 139.73841582859518 38.182 35.67336277205138 139.73841549873217 38.182 35.67336277205138 139.73841549873217 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7a4a3c1-83d9-4358-8e89-7512c9cb5cdc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7a4a3c1-83d9-4358-8e89-7512c9cb5cdc_0">
											<gml:posList>35.67336414502568 139.738430597905 40.009 35.673362847320234 139.73843094188797 40.009 35.673362847320234 139.73843094188797 38.182 35.67336414502568 139.738430597905 38.182 35.67336414502568 139.738430597905 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34b82e03-fa79-4807-901b-33da4120fd14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34b82e03-fa79-4807-901b-33da4120fd14_0">
											<gml:posList>35.67336627579813 139.7383779138102 35.216 35.67335536408865 139.7383828756423 35.216 35.67336141906222 139.73840288503692 35.216 35.67337233977752 139.73839791214982 35.216 35.67336627579813 139.7383779138102 35.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a7872cc-af43-4479-8216-43a301d55e8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a7872cc-af43-4479-8216-43a301d55e8e_0">
											<gml:posList>35.673370607083086 139.73853258417114 32.733 35.67335486614521 139.73854025812673 32.733 35.67335835389285 139.7385509913656 32.733 35.6733740858177 139.7385433174224 32.733 35.673370607083086 139.73853258417114 32.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50e6fc15-8574-4548-8bfd-41e7df9dd896">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50e6fc15-8574-4548-8bfd-41e7df9dd896_0">
											<gml:posList>35.67336407028797 139.73841582859518 40.009 35.673365287662335 139.73841648995406 40.009 35.673365287662335 139.73841648995406 38.182 35.67336407028797 139.73841582859518 38.182 35.67336407028797 139.73841582859518 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebaef031-71a1-454f-b7b7-d275eeb8e253">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebaef031-71a1-454f-b7b7-d275eeb8e253_0">
											<gml:posList>35.67336414502568 139.738430597905 40.009 35.67336414502568 139.738430597905 38.182 35.673365352341456 139.73842993367555 38.182 35.673365352341456 139.73842993367555 40.009 35.67336414502568 139.738430597905 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1454a741-9527-463d-8130-8841752923bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1454a741-9527-463d-8130-8841752923bc_0">
											<gml:posList>35.673365287662335 139.73841648995406 40.009 35.673366361034915 139.73841742765026 40.009 35.673366361034915 139.73841742765026 38.182 35.673365287662335 139.73841648995406 38.182 35.673365287662335 139.73841648995406 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8ca602a-7d66-4629-9e5b-5d6df4afcf21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8ca602a-7d66-4629-9e5b-5d6df4afcf21_0">
											<gml:posList>35.67336641520266 139.738428971357 40.009 35.673365352341456 139.73842993367555 40.009 35.673365352341456 139.73842993367555 38.182 35.67336641520266 139.738428971357 38.182 35.67336641520266 139.738428971357 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4b72e22-1e36-4e54-8261-25f2c5d147ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4b72e22-1e36-4e54-8261-25f2c5d147ca_0">
											<gml:posList>35.6733740858177 139.7385433174224 32.733 35.67335835389285 139.7385509913656 32.733 35.67335835389285 139.7385509913656 30.717 35.6733740858177 139.7385433174224 30.717 35.6733740858177 139.7385433174224 32.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd4b72a9-a2ad-4903-af5d-8210f425b237">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd4b72a9-a2ad-4903-af5d-8210f425b237_0">
											<gml:posList>35.673366361034915 139.73841742765026 40.009 35.67336725434211 139.73841863067975 40.009 35.67336725434211 139.73841863067975 38.182 35.673366361034915 139.73841742765026 38.182 35.673366361034915 139.73841742765026 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7a2c80a-c335-4b65-9492-a84ded5843a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7a2c80a-c335-4b65-9492-a84ded5843a3_0">
											<gml:posList>35.67336729758924 139.73842775517863 40.009 35.67336641520266 139.738428971357 40.009 35.67336641520266 139.738428971357 38.182 35.67336729758924 139.73842775517863 38.182 35.67336729758924 139.73842775517863 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18bbca83-d52d-41ee-93ba-9db32d224294">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18bbca83-d52d-41ee-93ba-9db32d224294_0">
											<gml:posList>35.67337233977752 139.73839791214982 35.216 35.67336141906222 139.73840288503692 35.216 35.67336141906222 139.73840288503692 33.336 35.67337233977752 139.73839791214982 33.336 35.67337233977752 139.73839791214982 35.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e0a47ce-ff5e-416e-9121-846d11d43f17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e0a47ce-ff5e-416e-9121-846d11d43f17_0">
											<gml:posList>35.67336725434211 139.73841863067975 40.009 35.6733679224631 139.73842003281595 40.009 35.6733679224631 139.73842003281595 38.182 35.67336725434211 139.73841863067975 38.182 35.67336725434211 139.73841863067975 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5188fe4-e6b8-4bb1-9877-c07e480bacfa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5188fe4-e6b8-4bb1-9877-c07e480bacfa_0">
											<gml:posList>35.673367954476134 139.7384263404271 40.009 35.67336729758924 139.73842775517863 40.009 35.67336729758924 139.73842775517863 38.182 35.673367954476134 139.7384263404271 38.182 35.673367954476134 139.7384263404271 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc03313e-2014-4113-b403-0db2bcc1cd72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc03313e-2014-4113-b403-0db2bcc1cd72_0">
											<gml:posList>35.6733679224631 139.73842003281595 40.009 35.67336833830446 139.73842156781086 40.009 35.67336833830446 139.73842156781086 38.182 35.6733679224631 139.73842003281595 38.182 35.6733679224631 139.73842003281595 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2caa9d22-a0c3-48e7-a695-aaa7e03a7851">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2caa9d22-a0c3-48e7-a695-aaa7e03a7851_0">
											<gml:posList>35.67336834986942 139.73842480447178 40.009 35.673367954476134 139.7384263404271 40.009 35.673367954476134 139.7384263404271 38.182 35.67336834986942 139.73842480447178 38.182 35.67336834986942 139.73842480447178 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9c001c9-23ef-4252-896b-9cdb3a4b63bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9c001c9-23ef-4252-896b-9cdb3a4b63bd_0">
											<gml:posList>35.67336833830446 139.73842156781086 40.009 35.67336848379523 139.7384231804526 40.009 35.67336848379523 139.7384231804526 38.182 35.67336833830446 139.73842156781086 38.182 35.67336833830446 139.73842156781086 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-133b0015-810d-4629-ab2a-aa6b9338d27a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-133b0015-810d-4629-ab2a-aa6b9338d27a_0">
											<gml:posList>35.67336848379523 139.7384231804526 40.009 35.67336834986942 139.73842480447178 40.009 35.67336834986942 139.73842480447178 38.182 35.67336848379523 139.7384231804526 38.182 35.67336848379523 139.7384231804526 40.009</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e6e8563-adb0-4eda-a978-d18432861eb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e6e8563-adb0-4eda-a978-d18432861eb2_0">
											<gml:posList>35.67336627579813 139.7383779138102 35.216 35.67337233977752 139.73839791214982 35.216 35.67337233977752 139.73839791214982 33.336 35.67336627579813 139.7383779138102 33.336 35.67336627579813 139.7383779138102 35.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58611112-58bc-4881-94f5-f8de02ead050">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58611112-58bc-4881-94f5-f8de02ead050_0">
											<gml:posList>35.6733740858177 139.7385433174224 32.733 35.6733740858177 139.7385433174224 30.717 35.673370607083086 139.73853258417114 30.717 35.673370607083086 139.73853258417114 32.733 35.6733740858177 139.7385433174224 32.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e71e94e4-d7a1-478a-bc7e-16419d0f90d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e71e94e4-d7a1-478a-bc7e-16419d0f90d2_0">
											<gml:posList>35.67337744804702 139.73839472465906 39.6 35.67337245947851 139.73837824893278 39.6 35.67337245947851 139.73837824893278 37.078 35.67337744804702 139.73839472465906 37.078 35.67337744804702 139.73839472465906 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a53116eb-b408-49a0-bd1a-1af6d987f0b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a53116eb-b408-49a0-bd1a-1af6d987f0b1_0">
											<gml:posList>35.67338127009812 139.7385094066892 36.683 35.67337683323534 139.7384952832435 36.683 35.67337683323534 139.7384952832435 35.026 35.67338127009812 139.7385094066892 35.026 35.67338127009812 139.7385094066892 36.683</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7720def5-ed71-446f-957a-51f141fbb71a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7720def5-ed71-446f-957a-51f141fbb71a_0">
											<gml:posList>35.67338591215009 139.73837213523518 39.6 35.67338591215009 139.73837213523518 37.078 35.67337245947851 139.73837824893278 37.078 35.67337245947851 139.73837824893278 39.6 35.67338591215009 139.73837213523518 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4fd852e-42c4-44c3-9536-2a0732b45336">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4fd852e-42c4-44c3-9536-2a0732b45336_0">
											<gml:posList>35.67339090071943 139.73838861096382 39.6 35.67338591215009 139.73837213523518 39.6 35.67337245947851 139.73837824893278 39.6 35.67337744804702 139.73839472465906 39.6 35.67339090071943 139.73838861096382 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-661b6307-c6db-430a-a0f1-87f2c0a4aadc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-661b6307-c6db-430a-a0f1-87f2c0a4aadc_0">
											<gml:posList>35.67337683323534 139.7384952832435 36.683 35.67338934864288 139.73848936951413 36.683 35.67338934864288 139.73848936951413 35.026 35.67337683323534 139.7384952832435 35.026 35.67337683323534 139.7384952832435 36.683</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95005a62-a769-4102-8592-706d89e3399a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95005a62-a769-4102-8592-706d89e3399a_0">
											<gml:posList>35.67339090071943 139.73838861096382 39.6 35.67337744804702 139.73839472465906 39.6 35.67337744804702 139.73839472465906 37.078 35.67339090071943 139.73838861096382 37.078 35.67339090071943 139.73838861096382 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25bd7402-93df-415b-b03e-5c52419b1cd6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25bd7402-93df-415b-b03e-5c52419b1cd6_0">
											<gml:posList>35.67337683323534 139.7384952832435 36.683 35.67338127009812 139.7385094066892 36.683 35.673393785515046 139.7385035040084 36.683 35.67338934864288 139.73848936951413 36.683 35.67337683323534 139.7384952832435 36.683</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b3429cd-75a8-487e-b69d-6f2e1f771f21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b3429cd-75a8-487e-b69d-6f2e1f771f21_0">
											<gml:posList>35.673393785515046 139.7385035040084 36.683 35.67338127009812 139.7385094066892 36.683 35.67338127009812 139.7385094066892 35.026 35.673393785515046 139.7385035040084 35.026 35.673393785515046 139.7385035040084 36.683</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdf057a6-570a-41c3-867b-ef58211405e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdf057a6-570a-41c3-867b-ef58211405e3_0">
											<gml:posList>35.67338591215009 139.73837213523518 39.6 35.67339090071943 139.73838861096382 39.6 35.67339090071943 139.73838861096382 37.078 35.67338591215009 139.73837213523518 37.078 35.67338591215009 139.73837213523518 39.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-527aaae8-1c68-458d-bbda-7ce63e3b98d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-527aaae8-1c68-458d-bbda-7ce63e3b98d3_0">
											<gml:posList>35.673393785515046 139.7385035040084 36.683 35.673393785515046 139.7385035040084 35.026 35.67338934864288 139.73848936951413 35.026 35.67338934864288 139.73848936951413 36.683 35.673393785515046 139.7385035040084 36.683</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6ff5d53c-6521-4819-bffb-b761c08834cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ff5d53c-6521-4819-bffb-b761c08834cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ff5d53c-6521-4819-bffb-b761c08834cb">
											<gml:posList>35.67339687537427 139.73847826974801 7.953 35.67340601041294 139.7385064058703 7.953 35.67338713365995 139.7385152986774 7.953 35.67339786801386 139.73854838181992 7.953 35.67333692255446 139.7385780920835 7.953 35.673274662618475 139.73838087235853 7.953 35.67337756128449 139.73833258699375 7.953 35.673396720289894 139.73839586173702 7.953 35.67337428475517 139.73840682451072 7.953 35.67339687537427 139.73847826974801 7.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28d4820d-144a-48af-ab1f-de6a77dacf26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28d4820d-144a-48af-ab1f-de6a77dacf26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28d4820d-144a-48af-ab1f-de6a77dacf26">
											<gml:posList>35.673295084563854 139.7384454711367 34.814 35.67329753088023 139.73843859721796 34.814 35.673280244514046 139.73838391462513 34.814 35.673274662618475 139.73838087235853 34.814 35.673295084563854 139.7384454711367 34.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a79a734d-c09e-4c43-a3cc-405ebff18e7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a79a734d-c09e-4c43-a3cc-405ebff18e7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a79a734d-c09e-4c43-a3cc-405ebff18e7b">
											<gml:posList>35.673319283483295 139.73851039688034 31.937 35.67329823815504 139.73844393191817 31.937 35.673295084563854 139.7384454711367 31.937 35.673317313741634 139.73851581207543 31.937 35.673319283483295 139.73851039688034 31.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ba7045e-c12d-48bd-be35-90824b60c62c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ba7045e-c12d-48bd-be35-90824b60c62c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ba7045e-c12d-48bd-be35-90824b60c62c">
											<gml:posList>35.6733378833033 139.73842458646655 34.814 35.6733363020366 139.73841968361862 34.814 35.67329753088023 139.73843859721796 34.814 35.673295084563854 139.7384454711367 34.814 35.6733378833033 139.73842458646655 34.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f22fdb1f-40ad-47a3-9c61-3d884ce76eea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f22fdb1f-40ad-47a3-9c61-3d884ce76eea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f22fdb1f-40ad-47a3-9c61-3d884ce76eea">
											<gml:posList>35.673274662618475 139.73838087235853 34.814 35.673280244514046 139.73838391462513 34.814 35.67337503382461 139.73833942787869 34.814 35.67337756128449 139.73833258699375 34.814 35.673274662618475 139.73838087235853 34.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3520692a-6186-4b83-8049-0f445e7eaf1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3520692a-6186-4b83-8049-0f445e7eaf1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3520692a-6186-4b83-8049-0f445e7eaf1f">
											<gml:posList>35.67333847851116 139.73857374890434 30.953 35.673319854670574 139.7385146160305 30.953 35.673317313741634 139.73851581207543 30.953 35.67333692255446 139.7385780920835 30.953 35.67333847851116 139.73857374890434 30.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-669592a5-76cd-4be9-b71d-a320a4ae8aff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-669592a5-76cd-4be9-b71d-a320a4ae8aff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-669592a5-76cd-4be9-b71d-a320a4ae8aff">
											<gml:posList>35.67337503382461 139.73833942787869 33.336 35.673280244514046 139.73838391462513 33.336 35.67329753088023 139.73843859721796 33.336 35.6733363020366 139.73841968361862 33.336 35.67333712197144 139.7384192849679 33.336 35.673338712243165 139.73842417675854 33.336 35.67337358195517 139.73840716778972 33.336 35.67337217227935 139.73840268451025 33.336 35.67337358691048 139.73840202003484 33.336 35.67336277836791 139.73836635208903 33.336 35.67338070924465 139.73835818945057 33.336 35.67337503382461 139.73833942787869 33.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-24a6510c-4db6-4eda-80b3-b8e55d2480b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24a6510c-4db6-4eda-80b3-b8e55d2480b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24a6510c-4db6-4eda-80b3-b8e55d2480b1">
											<gml:posList>35.67335754508014 139.7384968305014 31.937 35.673356325148184 139.73849292142359 31.937 35.673319283483295 139.73851039688034 31.937 35.673317313741634 139.73851581207543 31.937 35.67335754508014 139.7384968305014 31.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd055f69-9a0f-49fa-af84-e0a590673787">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd055f69-9a0f-49fa-af84-e0a590673787">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd055f69-9a0f-49fa-af84-e0a590673787">
											<gml:posList>35.6733363020366 139.73841968361862 34.814 35.6733378833033 139.73842458646655 34.814 35.673338712243165 139.73842417675854 34.814 35.67333712197144 139.7384192849679 34.814 35.6733363020366 139.73841968361862 34.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ccc55d7a-5386-41c6-8117-6797908f5d90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccc55d7a-5386-41c6-8117-6797908f5d90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccc55d7a-5386-41c6-8117-6797908f5d90">
											<gml:posList>35.67334520217523 139.73844711300427 38.441 35.67334638931345 139.73844372027213 38.441 35.67334064265027 139.73842604135996 38.441 35.6733378833033 139.73842458646655 38.441 35.67334520217523 139.73844711300427 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce1b8870-e5d5-4376-8fba-27e8bd6e7d9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce1b8870-e5d5-4376-8fba-27e8bd6e7d9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce1b8870-e5d5-4376-8fba-27e8bd6e7d9d">
											<gml:posList>35.6733719611087 139.73844353535137 31.583 35.67336930462467 139.73843535291238 31.583 35.67334520217523 139.73844711300427 31.583 35.6733378833033 139.73842458646655 31.583 35.67329823815504 139.73844393191817 31.583 35.673319283483295 139.73851039688034 31.583 35.673356325148184 139.73849292142359 31.583 35.673357658682455 139.73849229018586 31.583 35.67335888762815 139.73849619925304 31.583 35.673393676688 139.7384797758804 31.583 35.67338208318285 139.738443103597 31.583 35.67338081819797 139.7384392166655 31.583 35.6733719611087 139.73844353535137 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-488cfe85-0ec9-4cbd-abc6-139f9e1e6a24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-488cfe85-0ec9-4cbd-abc6-139f9e1e6a24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-488cfe85-0ec9-4cbd-abc6-139f9e1e6a24">
											<gml:posList>35.6733378833033 139.73842458646655 38.441 35.67334064265027 139.73842604135996 38.441 35.67337307057685 139.7384102172766 38.441 35.67337428475517 139.73840682451072 38.441 35.6733378833033 139.73842458646655 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7cd3344c-eb90-4cca-908e-fc759caa0bdf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cd3344c-eb90-4cca-908e-fc759caa0bdf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cd3344c-eb90-4cca-908e-fc759caa0bdf">
											<gml:posList>35.6733664278087 139.73852506633045 30.717 35.67335754508014 139.7384968305014 30.717 35.673319854670574 139.7385146160305 30.717 35.67333847851116 139.73857374890434 30.717 35.67339434217194 139.73854650805393 30.717 35.67338462877722 139.73851648363404 30.717 35.6733664278087 139.73852506633045 30.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fba8cd12-e211-4874-9f59-398efa10b5ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fba8cd12-e211-4874-9f59-398efa10b5ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fba8cd12-e211-4874-9f59-398efa10b5ac">
											<gml:posList>35.673356325148184 139.73849292142359 31.937 35.67335754508014 139.7384968305014 31.937 35.67335888762815 139.73849619925304 31.937 35.673357658682455 139.73849229018586 31.937 35.673356325148184 139.73849292142359 31.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-47d3a42d-1944-4973-8fde-7983ea9c765a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47d3a42d-1944-4973-8fde-7983ea9c765a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47d3a42d-1944-4973-8fde-7983ea9c765a">
											<gml:posList>35.67336930462467 139.73843535291238 38.441 35.67337049176256 139.73843196017904 38.441 35.67334638931345 139.73844372027213 38.441 35.67334520217523 139.73844711300427 38.441 35.67336930462467 139.73843535291238 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20a1eb17-4a52-4340-8288-55f5f33d80b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20a1eb17-4a52-4340-8288-55f5f33d80b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20a1eb17-4a52-4340-8288-55f5f33d80b2">
											<gml:posList>35.67337307057685 139.7384102172766 38.182 35.67334064265027 139.73842604135996 38.182 35.67334638931345 139.73844372027213 38.182 35.67337049176256 139.73843196017904 38.182 35.673373139233085 139.7384401426287 38.182 35.67337977078717 139.73843690915075 38.182 35.673377141404806 139.7384288040058 38.182 35.673378700177196 139.73842803994015 38.182 35.67337307057685 139.7384102172766 38.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-73c90753-3256-468b-9bf3-859129cba44d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73c90753-3256-468b-9bf3-859129cba44d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73c90753-3256-468b-9bf3-859129cba44d">
											<gml:posList>35.6733664278087 139.73852506633045 35.356 35.673368262623335 139.73852000478527 35.356 35.67336166611533 139.7384990681004 35.356 35.67335754508014 139.7384968305014 35.356 35.6733664278087 139.73852506633045 35.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a25a2bd9-1248-4907-8be6-b2e9f90fb6d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a25a2bd9-1248-4907-8be6-b2e9f90fb6d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a25a2bd9-1248-4907-8be6-b2e9f90fb6d1">
											<gml:posList>35.67339786801386 139.73854838181992 30.953 35.67339434217194 139.73854650805393 30.953 35.67333847851116 139.73857374890434 30.953 35.67333692255446 139.7385780920835 30.953 35.67339786801386 139.73854838181992 30.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21c017b3-7e35-4386-a4d8-b862e91adad7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21c017b3-7e35-4386-a4d8-b862e91adad7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21c017b3-7e35-4386-a4d8-b862e91adad7">
											<gml:posList>35.67337358691048 139.73840202003484 37.247 35.67337481022422 139.73839878191143 37.247 35.6733654295858 139.73836785129564 37.247 35.67336277836791 139.73836635208903 37.247 35.67337358691048 139.73840202003484 37.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-899cf360-8652-482b-a595-9449ca6c0598">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-899cf360-8652-482b-a595-9449ca6c0598">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-899cf360-8652-482b-a595-9449ca6c0598">
											<gml:posList>35.67336930462467 139.73843535291238 38.441 35.6733719611087 139.73844353535137 38.441 35.673373139233085 139.7384401426287 38.441 35.67337049176256 139.73843196017904 38.441 35.67336930462467 139.73843535291238 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ba8fc67-90ce-4c8b-84e2-e891717d2fb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ba8fc67-90ce-4c8b-84e2-e891717d2fb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ba8fc67-90ce-4c8b-84e2-e891717d2fb6">
											<gml:posList>35.67336277836791 139.73836635208903 37.247 35.6733654295858 139.73836785129564 37.247 35.67338354066729 139.73835960007034 37.247 35.67338475495744 139.7383563509099 37.247 35.67336277836791 139.73836635208903 37.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f48823b8-a6f4-41e6-893f-7aa98c1ce276">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f48823b8-a6f4-41e6-893f-7aa98c1ce276">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f48823b8-a6f4-41e6-893f-7aa98c1ce276">
											<gml:posList>35.67335754508014 139.7384968305014 35.356 35.67336166611533 139.7384990681004 35.356 35.673395067585155 139.73848330917062 35.356 35.67339687537427 139.73847826974801 35.356 35.67335754508014 139.7384968305014 35.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cfd9849c-5fa2-4012-bbcc-64ac799a1d03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfd9849c-5fa2-4012-bbcc-64ac799a1d03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfd9849c-5fa2-4012-bbcc-64ac799a1d03">
											<gml:posList>35.67338253014268 139.73843837509196 38.441 35.67337977078717 139.73843690915075 38.441 35.673373139233085 139.7384401426287 38.441 35.6733719611087 139.73844353535137 38.441 35.67338253014268 139.73843837509196 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6532762-2f73-4d1d-b4b3-87bec165b0b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6532762-2f73-4d1d-b4b3-87bec165b0b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6532762-2f73-4d1d-b4b3-87bec165b0b3">
											<gml:posList>35.67337428475517 139.73840682451072 38.441 35.67337307057685 139.7384102172766 38.441 35.673378700177196 139.73842803994015 38.441 35.67338145051908 139.73842950589167 38.441 35.67337428475517 139.73840682451072 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1f25d4d-2fc9-4cf9-9836-d83913342ae0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1f25d4d-2fc9-4cf9-9836-d83913342ae0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1f25d4d-2fc9-4cf9-9836-d83913342ae0">
											<gml:posList>35.673392921316506 139.73839054173882 37.078 35.67338354066729 139.73835960007034 37.078 35.6733654295858 139.73836785129564 37.078 35.67337481022422 139.73839878191143 37.078 35.673392921316506 139.73839054173882 37.078</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-204845fa-8b04-4e67-8d02-9a573f45980b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-204845fa-8b04-4e67-8d02-9a573f45980b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-204845fa-8b04-4e67-8d02-9a573f45980b">
											<gml:posList>35.673379900751705 139.73843025890002 38.441 35.67338145051908 139.73842950589167 38.441 35.673378700177196 139.73842803994015 38.441 35.673377141404806 139.7384288040058 38.441 35.673379900751705 139.73843025890002 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e6a4eaf-488c-4e71-a962-734533c0bdae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e6a4eaf-488c-4e71-a962-734533c0bdae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e6a4eaf-488c-4e71-a962-734533c0bdae">
											<gml:posList>35.673379900751705 139.73843025890002 38.441 35.673377141404806 139.7384288040058 38.441 35.67337977078717 139.73843690915075 38.441 35.67338253014268 139.73843837509196 38.441 35.673379900751705 139.73843025890002 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa62b00d-4e3d-4448-9529-72277f47ff56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa62b00d-4e3d-4448-9529-72277f47ff56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa62b00d-4e3d-4448-9529-72277f47ff56">
											<gml:posList>35.67337503382461 139.73833942787869 34.814 35.67338070924465 139.73835818945057 34.814 35.67338475495744 139.7383563509099 34.814 35.67337756128449 139.73833258699375 34.814 35.67337503382461 139.73833942787869 34.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-14c4b153-93ff-4be2-b58e-24232d34ed1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14c4b153-93ff-4be2-b58e-24232d34ed1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14c4b153-93ff-4be2-b58e-24232d34ed1d">
											<gml:posList>35.673368262623335 139.73852000478527 35.026 35.67340184430932 139.738504168323 35.026 35.673395067585155 139.73848330917062 35.026 35.67336166611533 139.7384990681004 35.026 35.673368262623335 139.73852000478527 35.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0a7c26f-74c0-454c-8f94-79c64e5e0b4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0a7c26f-74c0-454c-8f94-79c64e5e0b4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0a7c26f-74c0-454c-8f94-79c64e5e0b4e">
											<gml:posList>35.67337428475517 139.73840682451072 34.814 35.673396720289894 139.73839586173702 34.814 35.67339556351166 139.73839202991076 34.814 35.67337358691048 139.73840202003484 34.814 35.67337217227935 139.73840268451025 34.814 35.67337358195517 139.73840716778972 34.814 35.67337428475517 139.73840682451072 34.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-84d3c1b7-c369-4716-992d-2959f794eaec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84d3c1b7-c369-4716-992d-2959f794eaec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84d3c1b7-c369-4716-992d-2959f794eaec">
											<gml:posList>35.67339556351166 139.73839202991076 37.247 35.673392921316506 139.73839054173882 37.247 35.67337481022422 139.73839878191143 37.247 35.67337358691048 139.73840202003484 37.247 35.67339556351166 139.73839202991076 37.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d5a120a-7432-4262-b457-6f16e362ac99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d5a120a-7432-4262-b457-6f16e362ac99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d5a120a-7432-4262-b457-6f16e362ac99">
											<gml:posList>35.67340601041294 139.7385064058703 35.356 35.67340184430932 139.738504168323 35.356 35.673368262623335 139.73852000478527 35.356 35.6733664278087 139.73852506633045 35.356 35.67340601041294 139.7385064058703 35.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a3d89bb-c830-4659-930b-c23916e9ffa0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a3d89bb-c830-4659-930b-c23916e9ffa0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a3d89bb-c830-4659-930b-c23916e9ffa0">
											<gml:posList>35.67338253014268 139.73843837509196 31.937 35.67338081819797 139.7384392166655 31.937 35.67338208318285 139.738443103597 31.937 35.673393676688 139.7384797758804 31.937 35.67339687537427 139.73847826974801 31.937 35.67338145051908 139.73842950589167 31.937 35.673379900751705 139.73843025890002 31.937 35.67338253014268 139.73843837509196 31.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a27438c-07df-46d5-b5cc-b64a04317d8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a27438c-07df-46d5-b5cc-b64a04317d8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a27438c-07df-46d5-b5cc-b64a04317d8f">
											<gml:posList>35.67338475495744 139.7383563509099 37.247 35.67338354066729 139.73835960007034 37.247 35.673392921316506 139.73839054173882 37.247 35.67339556351166 139.73839202991076 37.247 35.67338475495744 139.7383563509099 37.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b4a81aa-bce8-4cc4-9221-560d711ab6a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b4a81aa-bce8-4cc4-9221-560d711ab6a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b4a81aa-bce8-4cc4-9221-560d711ab6a7">
											<gml:posList>35.67339434217194 139.73854650805393 30.953 35.67339786801386 139.73854838181992 30.953 35.67338713365995 139.7385152986774 30.953 35.67338462877722 139.73851648363404 30.953 35.67339434217194 139.73854650805393 30.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a9fcdd4-463f-4a7d-991b-463a4ef289a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a9fcdd4-463f-4a7d-991b-463a4ef289a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a9fcdd4-463f-4a7d-991b-463a4ef289a7">
											<gml:posList>35.67339687537427 139.73847826974801 35.356 35.673395067585155 139.73848330917062 35.356 35.67340184430932 139.738504168323 35.356 35.67340601041294 139.7385064058703 35.356 35.67339687537427 139.73847826974801 35.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04c171a3-bc5c-4489-bf85-ed489c094b87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04c171a3-bc5c-4489-bf85-ed489c094b87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04c171a3-bc5c-4489-bf85-ed489c094b87">
											<gml:posList>35.67337481022422 139.73839878191143 37.247 35.67337481022422 139.73839878191143 37.078 35.6733654295858 139.73836785129564 37.078 35.6733654295858 139.73836785129564 37.247 35.67337481022422 139.73839878191143 37.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e66b8c92-c1a9-420a-ab7e-a9f11853af19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e66b8c92-c1a9-420a-ab7e-a9f11853af19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e66b8c92-c1a9-420a-ab7e-a9f11853af19">
											<gml:posList>35.67337503382461 139.73833942787869 34.814 35.67337503382461 139.73833942787869 33.336 35.67338070924465 139.73835818945057 33.336 35.67338070924465 139.73835818945057 34.814 35.67337503382461 139.73833942787869 34.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fe6f97b-0836-4325-9f32-c9f78991efe3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fe6f97b-0836-4325-9f32-c9f78991efe3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fe6f97b-0836-4325-9f32-c9f78991efe3">
											<gml:posList>35.67337756128449 139.73833258699375 7.953 35.673274662618475 139.73838087235853 7.953 35.673274662618475 139.73838087235853 34.814 35.67337756128449 139.73833258699375 34.814 35.67337756128449 139.73833258699375 7.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46401cd7-0a12-4830-9a88-25fbff715f20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46401cd7-0a12-4830-9a88-25fbff715f20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46401cd7-0a12-4830-9a88-25fbff715f20">
											<gml:posList>35.67338070924465 139.73835818945057 34.814 35.67338070924465 139.73835818945057 33.336 35.67336277836791 139.73836635208903 33.336 35.67336277836791 139.73836635208903 37.247 35.67338475495744 139.7383563509099 37.247 35.67338475495744 139.7383563509099 34.814 35.67338070924465 139.73835818945057 34.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-669067a5-907a-4abb-990a-2c79e256ae10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-669067a5-907a-4abb-990a-2c79e256ae10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-669067a5-907a-4abb-990a-2c79e256ae10">
											<gml:posList>35.673280244514046 139.73838391462513 34.814 35.673280244514046 139.73838391462513 33.336 35.67337503382461 139.73833942787869 33.336 35.67337503382461 139.73833942787869 34.814 35.673280244514046 139.73838391462513 34.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-284ece9d-e87c-4e1a-997e-462c521b6c09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-284ece9d-e87c-4e1a-997e-462c521b6c09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-284ece9d-e87c-4e1a-997e-462c521b6c09">
											<gml:posList>35.6733654295858 139.73836785129564 37.247 35.6733654295858 139.73836785129564 37.078 35.67338354066729 139.73835960007034 37.078 35.67338354066729 139.73835960007034 37.247 35.6733654295858 139.73836785129564 37.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-091b1798-bd02-4150-864c-7b217511131a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-091b1798-bd02-4150-864c-7b217511131a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-091b1798-bd02-4150-864c-7b217511131a">
											<gml:posList>35.67339556351166 139.73839202991076 34.814 35.673396720289894 139.73839586173702 34.814 35.673396720289894 139.73839586173702 7.953 35.67337756128449 139.73833258699375 7.953 35.67337756128449 139.73833258699375 34.814 35.67338475495744 139.7383563509099 34.814 35.67338475495744 139.7383563509099 37.247 35.67339556351166 139.73839202991076 37.247 35.67339556351166 139.73839202991076 34.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc9c08ef-bf40-4f2d-8a5f-d7d35e72297c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc9c08ef-bf40-4f2d-8a5f-d7d35e72297c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc9c08ef-bf40-4f2d-8a5f-d7d35e72297c">
											<gml:posList>35.67338354066729 139.73835960007034 37.247 35.67338354066729 139.73835960007034 37.078 35.673392921316506 139.73839054173882 37.078 35.673392921316506 139.73839054173882 37.247 35.67338354066729 139.73835960007034 37.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7628676-d482-4c96-8ad0-b8a32fcd9cde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7628676-d482-4c96-8ad0-b8a32fcd9cde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7628676-d482-4c96-8ad0-b8a32fcd9cde">
											<gml:posList>35.67336277836791 139.73836635208903 37.247 35.67336277836791 139.73836635208903 33.336 35.67337358691048 139.73840202003484 33.336 35.67337358691048 139.73840202003484 34.814 35.67337358691048 139.73840202003484 37.247 35.67336277836791 139.73836635208903 37.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-070a9afa-3846-4ca4-a4f9-1fd7e05ec64e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-070a9afa-3846-4ca4-a4f9-1fd7e05ec64e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-070a9afa-3846-4ca4-a4f9-1fd7e05ec64e">
											<gml:posList>35.673392921316506 139.73839054173882 37.247 35.673392921316506 139.73839054173882 37.078 35.67337481022422 139.73839878191143 37.078 35.67337481022422 139.73839878191143 37.247 35.673392921316506 139.73839054173882 37.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db1d1eae-f85b-41b9-b59b-a46faa0e4f60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db1d1eae-f85b-41b9-b59b-a46faa0e4f60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db1d1eae-f85b-41b9-b59b-a46faa0e4f60">
											<gml:posList>35.67339556351166 139.73839202991076 34.814 35.67339556351166 139.73839202991076 37.247 35.67337358691048 139.73840202003484 37.247 35.67337358691048 139.73840202003484 34.814 35.67339556351166 139.73839202991076 34.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ec6f049-2483-4b62-931e-f875bcd9f1d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ec6f049-2483-4b62-931e-f875bcd9f1d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ec6f049-2483-4b62-931e-f875bcd9f1d2">
											<gml:posList>35.67337428475517 139.73840682451072 7.953 35.673396720289894 139.73839586173702 7.953 35.673396720289894 139.73839586173702 34.814 35.67337428475517 139.73840682451072 34.814 35.67337428475517 139.73840682451072 7.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd4a4ae1-137c-43b3-b8ea-bef9a39202fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd4a4ae1-137c-43b3-b8ea-bef9a39202fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd4a4ae1-137c-43b3-b8ea-bef9a39202fd">
											<gml:posList>35.67337358691048 139.73840202003484 34.814 35.67337358691048 139.73840202003484 33.336 35.67337217227935 139.73840268451025 33.336 35.67337217227935 139.73840268451025 34.814 35.67337358691048 139.73840202003484 34.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecb3ad46-2d73-421d-8641-8a5b8a5481ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecb3ad46-2d73-421d-8641-8a5b8a5481ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecb3ad46-2d73-421d-8641-8a5b8a5481ff">
											<gml:posList>35.67337217227935 139.73840268451025 34.814 35.67337217227935 139.73840268451025 33.336 35.67337358195517 139.73840716778972 33.336 35.67337358195517 139.73840716778972 34.814 35.67337217227935 139.73840268451025 34.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0fc1411-ccbf-452c-a04f-c232636d8c69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0fc1411-ccbf-452c-a04f-c232636d8c69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0fc1411-ccbf-452c-a04f-c232636d8c69">
											<gml:posList>35.67329753088023 139.73843859721796 34.814 35.67329753088023 139.73843859721796 33.336 35.673280244514046 139.73838391462513 33.336 35.673280244514046 139.73838391462513 34.814 35.67329753088023 139.73843859721796 34.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb23d989-aa09-4a8a-9379-fceea6b18e11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb23d989-aa09-4a8a-9379-fceea6b18e11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb23d989-aa09-4a8a-9379-fceea6b18e11">
											<gml:posList>35.6733378833033 139.73842458646655 38.441 35.67337428475517 139.73840682451072 38.441 35.67337428475517 139.73840682451072 34.814 35.67337358195517 139.73840716778972 34.814 35.67337358195517 139.73840716778972 33.336 35.673338712243165 139.73842417675854 33.336 35.673338712243165 139.73842417675854 34.814 35.6733378833033 139.73842458646655 34.814 35.6733378833033 139.73842458646655 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf38422f-fe31-43f8-bbfa-f39725494df7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf38422f-fe31-43f8-bbfa-f39725494df7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf38422f-fe31-43f8-bbfa-f39725494df7">
											<gml:posList>35.67334064265027 139.73842604135996 38.441 35.67334064265027 139.73842604135996 38.182 35.67337307057685 139.7384102172766 38.182 35.67337307057685 139.7384102172766 38.441 35.67334064265027 139.73842604135996 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0291c404-cd38-4f6c-bc5a-96b3276c3711">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0291c404-cd38-4f6c-bc5a-96b3276c3711">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0291c404-cd38-4f6c-bc5a-96b3276c3711">
											<gml:posList>35.67337307057685 139.7384102172766 38.441 35.67337307057685 139.7384102172766 38.182 35.673378700177196 139.73842803994015 38.182 35.673378700177196 139.73842803994015 38.441 35.67337307057685 139.7384102172766 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96db6b94-52ff-4dfc-ba05-edf786190e97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96db6b94-52ff-4dfc-ba05-edf786190e97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96db6b94-52ff-4dfc-ba05-edf786190e97">
											<gml:posList>35.67333712197144 139.7384192849679 34.814 35.67333712197144 139.7384192849679 33.336 35.6733363020366 139.73841968361862 33.336 35.6733363020366 139.73841968361862 34.814 35.67333712197144 139.7384192849679 34.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b410e3f9-9477-4d7c-8dec-140062f1be01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b410e3f9-9477-4d7c-8dec-140062f1be01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b410e3f9-9477-4d7c-8dec-140062f1be01">
											<gml:posList>35.673338712243165 139.73842417675854 34.814 35.673338712243165 139.73842417675854 33.336 35.67333712197144 139.7384192849679 33.336 35.67333712197144 139.7384192849679 34.814 35.673338712243165 139.73842417675854 34.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6400d705-b768-41a3-b835-f7b5ecbf64b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6400d705-b768-41a3-b835-f7b5ecbf64b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6400d705-b768-41a3-b835-f7b5ecbf64b2">
											<gml:posList>35.673378700177196 139.73842803994015 38.441 35.673378700177196 139.73842803994015 38.182 35.673377141404806 139.7384288040058 38.182 35.673377141404806 139.7384288040058 38.441 35.673378700177196 139.73842803994015 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2096e652-1b3a-477b-8aaf-5a5b4bc3c57f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2096e652-1b3a-477b-8aaf-5a5b4bc3c57f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2096e652-1b3a-477b-8aaf-5a5b4bc3c57f">
											<gml:posList>35.6733363020366 139.73841968361862 34.814 35.6733363020366 139.73841968361862 33.336 35.67329753088023 139.73843859721796 33.336 35.67329753088023 139.73843859721796 34.814 35.6733363020366 139.73841968361862 34.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-504f2e57-29b6-4ac4-80e6-49f6875a31a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-504f2e57-29b6-4ac4-80e6-49f6875a31a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-504f2e57-29b6-4ac4-80e6-49f6875a31a6">
											<gml:posList>35.67338145051908 139.73842950589167 38.441 35.673379900751705 139.73843025890002 38.441 35.673379900751705 139.73843025890002 31.937 35.67338145051908 139.73842950589167 31.937 35.67338145051908 139.73842950589167 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21101a88-3cb4-4488-9af5-b9e3354288bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21101a88-3cb4-4488-9af5-b9e3354288bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21101a88-3cb4-4488-9af5-b9e3354288bb">
											<gml:posList>35.673377141404806 139.7384288040058 38.441 35.673377141404806 139.7384288040058 38.182 35.67337977078717 139.73843690915075 38.182 35.67337977078717 139.73843690915075 38.441 35.673377141404806 139.7384288040058 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a955cee3-bb37-43d8-b088-81516e01cc33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a955cee3-bb37-43d8-b088-81516e01cc33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a955cee3-bb37-43d8-b088-81516e01cc33">
											<gml:posList>35.673379900751705 139.73843025890002 38.441 35.67338253014268 139.73843837509196 38.441 35.67338253014268 139.73843837509196 31.937 35.673379900751705 139.73843025890002 31.937 35.673379900751705 139.73843025890002 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a43a2ed1-cf89-480f-bfcd-af5982101036">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a43a2ed1-cf89-480f-bfcd-af5982101036">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a43a2ed1-cf89-480f-bfcd-af5982101036">
											<gml:posList>35.67334638931345 139.73844372027213 38.441 35.67334638931345 139.73844372027213 38.182 35.67334064265027 139.73842604135996 38.182 35.67334064265027 139.73842604135996 38.441 35.67334638931345 139.73844372027213 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b22494e-1f73-492c-8615-b1532c5a1e66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b22494e-1f73-492c-8615-b1532c5a1e66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b22494e-1f73-492c-8615-b1532c5a1e66">
											<gml:posList>35.6733378833033 139.73842458646655 31.583 35.6733378833033 139.73842458646655 34.814 35.673295084563854 139.7384454711367 34.814 35.673295084563854 139.7384454711367 31.937 35.67329823815504 139.73844393191817 31.937 35.67329823815504 139.73844393191817 31.583 35.6733378833033 139.73842458646655 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef251f88-d7c0-48aa-ac7c-cf05dd2dd276">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef251f88-d7c0-48aa-ac7c-cf05dd2dd276">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef251f88-d7c0-48aa-ac7c-cf05dd2dd276">
											<gml:posList>35.67334520217523 139.73844711300427 31.583 35.67334520217523 139.73844711300427 38.441 35.6733378833033 139.73842458646655 38.441 35.6733378833033 139.73842458646655 34.814 35.6733378833033 139.73842458646655 31.583 35.67334520217523 139.73844711300427 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c669e1c4-3511-402c-bc70-a3f56b7605ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c669e1c4-3511-402c-bc70-a3f56b7605ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c669e1c4-3511-402c-bc70-a3f56b7605ed">
											<gml:posList>35.673373139233085 139.7384401426287 38.441 35.673373139233085 139.7384401426287 38.182 35.67337049176256 139.73843196017904 38.182 35.67337049176256 139.73843196017904 38.441 35.673373139233085 139.7384401426287 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ee02720-107c-47c1-a0f4-162976e19dfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ee02720-107c-47c1-a0f4-162976e19dfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ee02720-107c-47c1-a0f4-162976e19dfc">
											<gml:posList>35.67337049176256 139.73843196017904 38.441 35.67337049176256 139.73843196017904 38.182 35.67334638931345 139.73844372027213 38.182 35.67334638931345 139.73844372027213 38.441 35.67337049176256 139.73843196017904 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2aac5622-f27c-4da7-a1d2-df0ac632d9ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2aac5622-f27c-4da7-a1d2-df0ac632d9ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2aac5622-f27c-4da7-a1d2-df0ac632d9ff">
											<gml:posList>35.67337977078717 139.73843690915075 38.441 35.67337977078717 139.73843690915075 38.182 35.673373139233085 139.7384401426287 38.182 35.673373139233085 139.7384401426287 38.441 35.67337977078717 139.73843690915075 38.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a3e92df-d8b6-4522-a17a-e879cf044d08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a3e92df-d8b6-4522-a17a-e879cf044d08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a3e92df-d8b6-4522-a17a-e879cf044d08">
											<gml:posList>35.67336930462467 139.73843535291238 31.583 35.6733719611087 139.73844353535137 31.583 35.6733719611087 139.73844353535137 38.441 35.67336930462467 139.73843535291238 38.441 35.67336930462467 139.73843535291238 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27be2398-3dcc-4a17-bac2-ec5a0782dd19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27be2398-3dcc-4a17-bac2-ec5a0782dd19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27be2398-3dcc-4a17-bac2-ec5a0782dd19">
											<gml:posList>35.67338081819797 139.7384392166655 31.937 35.67338253014268 139.73843837509196 31.937 35.67338253014268 139.73843837509196 38.441 35.6733719611087 139.73844353535137 38.441 35.6733719611087 139.73844353535137 31.583 35.67338081819797 139.7384392166655 31.583 35.67338081819797 139.7384392166655 31.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4088b8b8-0516-4789-997d-7d742c7c315e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4088b8b8-0516-4789-997d-7d742c7c315e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4088b8b8-0516-4789-997d-7d742c7c315e">
											<gml:posList>35.67338081819797 139.7384392166655 31.937 35.67338081819797 139.7384392166655 31.583 35.67338208318285 139.738443103597 31.583 35.67338208318285 139.738443103597 31.937 35.67338081819797 139.7384392166655 31.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1812c99-23ce-41f9-9c13-3ae1db2c9760">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1812c99-23ce-41f9-9c13-3ae1db2c9760">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1812c99-23ce-41f9-9c13-3ae1db2c9760">
											<gml:posList>35.67334520217523 139.73844711300427 31.583 35.67336930462467 139.73843535291238 31.583 35.67336930462467 139.73843535291238 38.441 35.67334520217523 139.73844711300427 38.441 35.67334520217523 139.73844711300427 31.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24143432-e12a-4ac3-b5d1-0dcf8fe5d2b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24143432-e12a-4ac3-b5d1-0dcf8fe5d2b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24143432-e12a-4ac3-b5d1-0dcf8fe5d2b0">
											<gml:posList>35.67339687537427 139.73847826974801 7.953 35.67337428475517 139.73840682451072 7.953 35.67337428475517 139.73840682451072 34.814 35.67337428475517 139.73840682451072 38.441 35.67338145051908 139.73842950589167 38.441 35.67338145051908 139.73842950589167 31.937 35.67339687537427 139.73847826974801 31.937 35.67339687537427 139.73847826974801 7.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8bc12bfe-2f88-4629-8279-fbc963895f0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bc12bfe-2f88-4629-8279-fbc963895f0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bc12bfe-2f88-4629-8279-fbc963895f0b">
											<gml:posList>35.67338208318285 139.738443103597 31.937 35.67338208318285 139.738443103597 31.583 35.673393676688 139.7384797758804 31.583 35.673393676688 139.7384797758804 31.937 35.67338208318285 139.738443103597 31.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95f3b622-6773-4e31-a9fa-625de816607f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95f3b622-6773-4e31-a9fa-625de816607f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95f3b622-6773-4e31-a9fa-625de816607f">
											<gml:posList>35.673319283483295 139.73851039688034 31.937 35.673319283483295 139.73851039688034 31.583 35.67329823815504 139.73844393191817 31.583 35.67329823815504 139.73844393191817 31.937 35.673319283483295 139.73851039688034 31.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df93dcbc-16df-4594-b9d3-81563caaa1d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df93dcbc-16df-4594-b9d3-81563caaa1d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df93dcbc-16df-4594-b9d3-81563caaa1d4">
											<gml:posList>35.673317313741634 139.73851581207543 30.953 35.673317313741634 139.73851581207543 31.937 35.673295084563854 139.7384454711367 31.937 35.673295084563854 139.7384454711367 34.814 35.673274662618475 139.73838087235853 34.814 35.673274662618475 139.73838087235853 7.953 35.67333692255446 139.7385780920835 7.953 35.67333692255446 139.7385780920835 30.953 35.673317313741634 139.73851581207543 30.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef18fd60-0108-469b-be1e-99a17294d1af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef18fd60-0108-469b-be1e-99a17294d1af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef18fd60-0108-469b-be1e-99a17294d1af">
											<gml:posList>35.67335754508014 139.7384968305014 35.356 35.67339687537427 139.73847826974801 35.356 35.67339687537427 139.73847826974801 31.937 35.673393676688 139.7384797758804 31.937 35.673393676688 139.7384797758804 31.583 35.67335888762815 139.73849619925304 31.583 35.67335888762815 139.73849619925304 31.937 35.67335754508014 139.7384968305014 31.937 35.67335754508014 139.7384968305014 35.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19006095-eb57-481f-8893-c0f4cd3d04c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19006095-eb57-481f-8893-c0f4cd3d04c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19006095-eb57-481f-8893-c0f4cd3d04c1">
											<gml:posList>35.67336166611533 139.7384990681004 35.356 35.67336166611533 139.7384990681004 35.026 35.673395067585155 139.73848330917062 35.026 35.673395067585155 139.73848330917062 35.356 35.67336166611533 139.7384990681004 35.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d171f696-8cd2-4037-af72-dccc3a7572d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d171f696-8cd2-4037-af72-dccc3a7572d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d171f696-8cd2-4037-af72-dccc3a7572d1">
											<gml:posList>35.67340601041294 139.7385064058703 35.356 35.67340601041294 139.7385064058703 7.953 35.67339687537427 139.73847826974801 7.953 35.67339687537427 139.73847826974801 31.937 35.67339687537427 139.73847826974801 35.356 35.67340601041294 139.7385064058703 35.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e048c870-0428-4e52-8eda-6b164a1ee1f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e048c870-0428-4e52-8eda-6b164a1ee1f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e048c870-0428-4e52-8eda-6b164a1ee1f6">
											<gml:posList>35.673357658682455 139.73849229018586 31.937 35.673357658682455 139.73849229018586 31.583 35.673356325148184 139.73849292142359 31.583 35.673356325148184 139.73849292142359 31.937 35.673357658682455 139.73849229018586 31.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-375b3638-6890-4e64-816c-51e948f7e122">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-375b3638-6890-4e64-816c-51e948f7e122">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-375b3638-6890-4e64-816c-51e948f7e122">
											<gml:posList>35.673395067585155 139.73848330917062 35.356 35.673395067585155 139.73848330917062 35.026 35.67340184430932 139.738504168323 35.026 35.67340184430932 139.738504168323 35.356 35.673395067585155 139.73848330917062 35.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18329c31-a7b2-4bdc-83ab-05256a543acd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18329c31-a7b2-4bdc-83ab-05256a543acd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18329c31-a7b2-4bdc-83ab-05256a543acd">
											<gml:posList>35.67335888762815 139.73849619925304 31.937 35.67335888762815 139.73849619925304 31.583 35.673357658682455 139.73849229018586 31.583 35.673357658682455 139.73849229018586 31.937 35.67335888762815 139.73849619925304 31.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9201a065-dd84-42c7-a5fa-96c6d3a8d63f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9201a065-dd84-42c7-a5fa-96c6d3a8d63f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9201a065-dd84-42c7-a5fa-96c6d3a8d63f">
											<gml:posList>35.673356325148184 139.73849292142359 31.937 35.673356325148184 139.73849292142359 31.583 35.673319283483295 139.73851039688034 31.583 35.673319283483295 139.73851039688034 31.937 35.673356325148184 139.73849292142359 31.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32f38365-de51-424d-a810-1c78fdfde107">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32f38365-de51-424d-a810-1c78fdfde107">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32f38365-de51-424d-a810-1c78fdfde107">
											<gml:posList>35.67335754508014 139.7384968305014 30.717 35.67335754508014 139.7384968305014 31.937 35.673317313741634 139.73851581207543 31.937 35.673317313741634 139.73851581207543 30.953 35.673319854670574 139.7385146160305 30.953 35.673319854670574 139.7385146160305 30.717 35.67335754508014 139.7384968305014 30.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35afa2de-04ff-4375-b5d8-ee22fd1b1e59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35afa2de-04ff-4375-b5d8-ee22fd1b1e59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35afa2de-04ff-4375-b5d8-ee22fd1b1e59">
											<gml:posList>35.673368262623335 139.73852000478527 35.356 35.673368262623335 139.73852000478527 35.026 35.67336166611533 139.7384990681004 35.026 35.67336166611533 139.7384990681004 35.356 35.673368262623335 139.73852000478527 35.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9679e074-aa99-468f-b168-2fd2bba516d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9679e074-aa99-468f-b168-2fd2bba516d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9679e074-aa99-468f-b168-2fd2bba516d9">
											<gml:posList>35.6733664278087 139.73852506633045 30.717 35.6733664278087 139.73852506633045 35.356 35.67335754508014 139.7384968305014 35.356 35.67335754508014 139.7384968305014 31.937 35.67335754508014 139.7384968305014 30.717 35.6733664278087 139.73852506633045 30.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-030bf9ff-5f33-4716-a8d7-a6a5c04735b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-030bf9ff-5f33-4716-a8d7-a6a5c04735b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-030bf9ff-5f33-4716-a8d7-a6a5c04735b9">
											<gml:posList>35.67340184430932 139.738504168323 35.356 35.67340184430932 139.738504168323 35.026 35.673368262623335 139.73852000478527 35.026 35.673368262623335 139.73852000478527 35.356 35.67340184430932 139.738504168323 35.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57191465-d3b5-45b4-a905-18eafa526c66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57191465-d3b5-45b4-a905-18eafa526c66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57191465-d3b5-45b4-a905-18eafa526c66">
											<gml:posList>35.6733664278087 139.73852506633045 30.717 35.67338462877722 139.73851648363404 30.717 35.67338462877722 139.73851648363404 30.953 35.67338713365995 139.7385152986774 30.953 35.67338713365995 139.7385152986774 7.953 35.67340601041294 139.7385064058703 7.953 35.67340601041294 139.7385064058703 35.356 35.6733664278087 139.73852506633045 35.356 35.6733664278087 139.73852506633045 30.717</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e160b36-340a-4c28-82ab-3af71cd26be5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e160b36-340a-4c28-82ab-3af71cd26be5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e160b36-340a-4c28-82ab-3af71cd26be5">
											<gml:posList>35.67338462877722 139.73851648363404 30.953 35.67338462877722 139.73851648363404 30.717 35.67339434217194 139.73854650805393 30.717 35.67339434217194 139.73854650805393 30.953 35.67338462877722 139.73851648363404 30.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5242d9da-03df-4ab1-9231-80cf13cf62df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5242d9da-03df-4ab1-9231-80cf13cf62df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5242d9da-03df-4ab1-9231-80cf13cf62df">
											<gml:posList>35.67339786801386 139.73854838181992 7.953 35.67338713365995 139.7385152986774 7.953 35.67338713365995 139.7385152986774 30.953 35.67339786801386 139.73854838181992 30.953 35.67339786801386 139.73854838181992 7.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa34fc25-32db-407c-9804-7ccb4dd088c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa34fc25-32db-407c-9804-7ccb4dd088c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa34fc25-32db-407c-9804-7ccb4dd088c9">
											<gml:posList>35.67333847851116 139.73857374890434 30.953 35.67333847851116 139.73857374890434 30.717 35.673319854670574 139.7385146160305 30.717 35.673319854670574 139.7385146160305 30.953 35.67333847851116 139.73857374890434 30.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-201e4fdf-366e-42d7-b343-84642617fbc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-201e4fdf-366e-42d7-b343-84642617fbc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-201e4fdf-366e-42d7-b343-84642617fbc6">
											<gml:posList>35.67339434217194 139.73854650805393 30.953 35.67339434217194 139.73854650805393 30.717 35.67333847851116 139.73857374890434 30.717 35.67333847851116 139.73857374890434 30.953 35.67339434217194 139.73854650805393 30.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17e2fb71-ad16-4a9e-9882-d6dd10776119">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17e2fb71-ad16-4a9e-9882-d6dd10776119">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17e2fb71-ad16-4a9e-9882-d6dd10776119">
											<gml:posList>35.67333692255446 139.7385780920835 7.953 35.67339786801386 139.73854838181992 7.953 35.67339786801386 139.73854838181992 30.953 35.67333692255446 139.7385780920835 30.953 35.67333692255446 139.7385780920835 7.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9394</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">75.39676</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.1</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>