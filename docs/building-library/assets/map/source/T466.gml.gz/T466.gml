<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_880d7ebd-feb7-46db-949f-f51765853308">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">8</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67042113173787 139.74437588968735 0 35.670407983199674 139.7444280868253 0 35.67039993168525 139.74442503593858 0 35.67036373039883 139.7445687437079 0 35.67037372941142 139.7445725215048 0 35.670404975675886 139.74457886060742 0 35.670444474812754 139.74438472289552 0 35.67042113173787 139.74437588968735 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67042113173787 139.74437588968735 7.7 35.670444474812754 139.74438472289552 7.7 35.670404975675886 139.74457886060742 7.7 35.67037372941142 139.7445725215048 7.7 35.67036373039883 139.7445687437079 7.7 35.67039993168525 139.74442503593858 7.7 35.670407983199674 139.7444280868253 7.7 35.67042113173787 139.74437588968735 7.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67042113173787 139.74437588968735 7.7 35.670407983199674 139.7444280868253 7.7 35.670407983199674 139.7444280868253 15.73 35.67042113173787 139.74437588968735 15.73 35.67042113173787 139.74437588968735 7.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670407983199674 139.7444280868253 7.7 35.67039993168525 139.74442503593858 7.7 35.67039993168525 139.74442503593858 15.73 35.670407983199674 139.7444280868253 15.73 35.670407983199674 139.7444280868253 7.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67039993168525 139.74442503593858 7.7 35.67036373039883 139.7445687437079 7.7 35.67036373039883 139.7445687437079 15.73 35.67039993168525 139.74442503593858 15.73 35.67039993168525 139.74442503593858 7.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67036373039883 139.7445687437079 7.7 35.67037372941142 139.7445725215048 7.7 35.67037372941142 139.7445725215048 15.73 35.67036373039883 139.7445687437079 15.73 35.67036373039883 139.7445687437079 7.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67037372941142 139.7445725215048 7.7 35.670404975675886 139.74457886060742 7.7 35.670404975675886 139.74457886060742 15.73 35.67037372941142 139.7445725215048 15.73 35.67037372941142 139.7445725215048 7.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670404975675886 139.74457886060742 7.7 35.670444474812754 139.74438472289552 7.7 35.670444474812754 139.74438472289552 15.73 35.670404975675886 139.74457886060742 15.73 35.670404975675886 139.74457886060742 7.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670444474812754 139.74438472289552 7.7 35.67042113173787 139.74437588968735 7.7 35.67042113173787 139.74437588968735 15.73 35.670444474812754 139.74438472289552 15.73 35.670444474812754 139.74438472289552 7.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67042113173787 139.74437588968735 15.73 35.670407983199674 139.7444280868253 15.73 35.67039993168525 139.74442503593858 15.73 35.67036373039883 139.7445687437079 15.73 35.67037372941142 139.7445725215048 15.73 35.670404975675886 139.74457886060742 15.73 35.670444474812754 139.74438472289552 15.73 35.67042113173787 139.74437588968735 15.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fbbe3c9c-ca1e-4e65-84f3-a23a2c12facd"/>
							<gml:surfaceMember xlink:href="#poly-fe26ca56-9075-4105-9bf9-de901dc31012"/>
							<gml:surfaceMember xlink:href="#poly-004d91cb-71d3-4a3d-86b7-68725c2ed063"/>
							<gml:surfaceMember xlink:href="#poly-56c6f16d-8e18-4791-8906-5830ff369e6c"/>
							<gml:surfaceMember xlink:href="#poly-ad3a9d9c-6916-4eeb-bbf1-e15c35da7d2a"/>
							<gml:surfaceMember xlink:href="#poly-d1489540-d235-46d0-b915-aa318eadea34"/>
							<gml:surfaceMember xlink:href="#poly-06fc088b-caad-4203-9d4c-cb8c36f58323"/>
							<gml:surfaceMember xlink:href="#poly-b3d05231-3440-465d-887f-39f99b298f82"/>
							<gml:surfaceMember xlink:href="#poly-d351f4d0-c31b-409e-9895-368132f2a09b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_880d7ebd-feb7-46db-949f-f51765853308_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81275578-376c-4603-a700-dc0ef7dc48b9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67038481487476 139.74448503389584 15.4 35.67041790858024 139.7445152971282 15.4 35.67040497567589 139.74457886060742 15.4 35.67037372039769 139.74457252151478 15.4 35.67036373039882 139.74456874370787 15.4 35.67038481487476 139.74448503389584 15.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8061bd89-2d29-477b-aabc-69f91fd53c47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8061bd89-2d29-477b-aabc-69f91fd53c47_0">
											<gml:posList>35.67041790858024 139.7445152971282 22.763 35.67041790858024 139.7445152971282 15.4 35.67038481487476 139.74448503389584 15.4 35.67038481487476 139.74448503389584 22.763 35.67041790858024 139.7445152971282 22.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b3fd331-c130-47a6-9661-f513e4daba4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b3fd331-c130-47a6-9661-f513e4daba4e_0">
											<gml:posList>35.67038481487476 139.74448503389584 22.763 35.67038481487476 139.74448503389584 15.4 35.67036373039882 139.74456874370787 15.4 35.67036373039882 139.74456874370787 22.763 35.67038481487476 139.74448503389584 22.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7643e61c-02e3-4570-b51d-3902ffe42774">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7643e61c-02e3-4570-b51d-3902ffe42774_0">
											<gml:posList>35.67038481487476 139.74448503389584 22.763 35.67036373039882 139.74456874370787 22.763 35.67037372039769 139.74457252151478 22.763 35.67040497567589 139.74457886060742 22.763 35.67041790858024 139.7445152971282 22.763 35.67038481487476 139.74448503389584 22.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6782fd61-2f20-421a-96d0-037f5abe2414">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6782fd61-2f20-421a-96d0-037f5abe2414_0">
											<gml:posList>35.67040497567589 139.74457886060742 22.763 35.67040497567589 139.74457886060742 15.4 35.67041790858024 139.7445152971282 15.4 35.67041790858024 139.7445152971282 22.763 35.67040497567589 139.74457886060742 22.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d5a6336-3018-4e6b-9dd9-965ad462af12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d5a6336-3018-4e6b-9dd9-965ad462af12_0">
											<gml:posList>35.67036373039882 139.74456874370787 22.763 35.67036373039882 139.74456874370787 15.4 35.67037372039769 139.74457252151478 15.4 35.67037372039769 139.74457252151478 22.763 35.67036373039882 139.74456874370787 22.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f580344-be9a-4e82-b256-126167680457">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f580344-be9a-4e82-b256-126167680457_0">
											<gml:posList>35.67037372039769 139.74457252151478 22.763 35.67037372039769 139.74457252151478 15.4 35.67040497567589 139.74457886060742 15.4 35.67040497567589 139.74457886060742 22.763 35.67037372039769 139.74457252151478 22.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fbbe3c9c-ca1e-4e65-84f3-a23a2c12facd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbbe3c9c-ca1e-4e65-84f3-a23a2c12facd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbbe3c9c-ca1e-4e65-84f3-a23a2c12facd">
											<gml:posList>35.67040798319965 139.74442808682528 7.7 35.67042113173784 139.74437588968735 7.7 35.67044447481274 139.74438472289552 7.7 35.67040497567589 139.74457886060742 7.7 35.67037372941141 139.7445725215048 7.7 35.67036373039882 139.74456874370787 7.7 35.670399931685225 139.74442503593855 7.7 35.67040798319965 139.74442808682528 7.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fe26ca56-9075-4105-9bf9-de901dc31012">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe26ca56-9075-4105-9bf9-de901dc31012">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe26ca56-9075-4105-9bf9-de901dc31012">
											<gml:posList>35.67040497567589 139.74457886060742 15.4 35.67044447481274 139.74438472289552 15.4 35.67042113173784 139.74437588968735 15.4 35.67040798319965 139.74442808682528 15.4 35.670399931685225 139.74442503593855 15.4 35.67036373039882 139.74456874370787 15.4 35.67037372941141 139.7445725215048 15.4 35.67040497567589 139.74457886060742 15.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-004d91cb-71d3-4a3d-86b7-68725c2ed063">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-004d91cb-71d3-4a3d-86b7-68725c2ed063">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-004d91cb-71d3-4a3d-86b7-68725c2ed063">
											<gml:posList>35.67044447481274 139.74438472289552 7.7 35.67042113173784 139.74437588968735 7.7 35.67042113173784 139.74437588968735 15.4 35.67044447481274 139.74438472289552 15.4 35.67044447481274 139.74438472289552 7.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56c6f16d-8e18-4791-8906-5830ff369e6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56c6f16d-8e18-4791-8906-5830ff369e6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56c6f16d-8e18-4791-8906-5830ff369e6c">
											<gml:posList>35.67042113173784 139.74437588968735 7.7 35.67040798319965 139.74442808682528 7.7 35.67040798319965 139.74442808682528 15.4 35.67042113173784 139.74437588968735 15.4 35.67042113173784 139.74437588968735 7.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad3a9d9c-6916-4eeb-bbf1-e15c35da7d2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad3a9d9c-6916-4eeb-bbf1-e15c35da7d2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad3a9d9c-6916-4eeb-bbf1-e15c35da7d2a">
											<gml:posList>35.67040798319965 139.74442808682528 7.7 35.670399931685225 139.74442503593855 7.7 35.670399931685225 139.74442503593855 15.4 35.67040798319965 139.74442808682528 15.4 35.67040798319965 139.74442808682528 7.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1489540-d235-46d0-b915-aa318eadea34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1489540-d235-46d0-b915-aa318eadea34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1489540-d235-46d0-b915-aa318eadea34">
											<gml:posList>35.67044447481274 139.74438472289552 15.4 35.67040497567589 139.74457886060742 15.4 35.67040497567589 139.74457886060742 7.7 35.67044447481274 139.74438472289552 7.7 35.67044447481274 139.74438472289552 15.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06fc088b-caad-4203-9d4c-cb8c36f58323">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06fc088b-caad-4203-9d4c-cb8c36f58323">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06fc088b-caad-4203-9d4c-cb8c36f58323">
											<gml:posList>35.67036373039882 139.74456874370787 15.4 35.670399931685225 139.74442503593855 15.4 35.670399931685225 139.74442503593855 7.7 35.67036373039882 139.74456874370787 7.7 35.67036373039882 139.74456874370787 15.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3d05231-3440-465d-887f-39f99b298f82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3d05231-3440-465d-887f-39f99b298f82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3d05231-3440-465d-887f-39f99b298f82">
											<gml:posList>35.67036373039882 139.74456874370787 7.7 35.67037372941141 139.7445725215048 7.7 35.67037372941141 139.7445725215048 15.4 35.67036373039882 139.74456874370787 15.4 35.67036373039882 139.74456874370787 7.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d351f4d0-c31b-409e-9895-368132f2a09b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d351f4d0-c31b-409e-9895-368132f2a09b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d351f4d0-c31b-409e-9895-368132f2a09b">
											<gml:posList>35.67037372941141 139.7445725215048 7.7 35.67040497567589 139.74457886060742 7.7 35.67040497567589 139.74457886060742 15.4 35.67037372941141 139.7445725215048 15.4 35.67037372941141 139.7445725215048 7.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5527</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>