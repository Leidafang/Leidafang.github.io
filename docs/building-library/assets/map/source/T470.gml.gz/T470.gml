<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8a9b42b7-f967-4dbf-b663-580f898e18db">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">26.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6715404267746 139.7381935023128 0 35.67168418238931 139.7381423855463 0 35.67165795487323 139.73803151047653 0 35.67151473995367 139.7380824058543 0 35.6715404267746 139.7381935023128 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715404267746 139.7381935023128 10.59 35.67151473995367 139.7380824058543 10.59 35.67165795487323 139.73803151047653 10.59 35.67168418238931 139.7381423855463 10.59 35.6715404267746 139.7381935023128 10.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715404267746 139.7381935023128 10.59 35.67168418238931 139.7381423855463 10.59 35.67168418238931 139.7381423855463 37.3 35.6715404267746 139.7381935023128 37.3 35.6715404267746 139.7381935023128 10.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67168418238931 139.7381423855463 10.59 35.67165795487323 139.73803151047653 10.59 35.67165795487323 139.73803151047653 37.3 35.67168418238931 139.7381423855463 37.3 35.67168418238931 139.7381423855463 10.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67165795487323 139.73803151047653 10.59 35.67151473995367 139.7380824058543 10.59 35.67151473995367 139.7380824058543 37.3 35.67165795487323 139.73803151047653 37.3 35.67165795487323 139.73803151047653 10.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67151473995367 139.7380824058543 10.59 35.6715404267746 139.7381935023128 10.59 35.6715404267746 139.7381935023128 37.3 35.67151473995367 139.7380824058543 37.3 35.67151473995367 139.7380824058543 10.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715404267746 139.7381935023128 37.3 35.67168418238931 139.7381423855463 37.3 35.67165795487323 139.73803151047653 37.3 35.67151473995367 139.7380824058543 37.3 35.6715404267746 139.7381935023128 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a2f23071-f305-43c9-ad45-5555d69fa961"/>
							<gml:surfaceMember xlink:href="#poly-aad1b438-27f8-4ce0-9e05-5ee1862ccd30"/>
							<gml:surfaceMember xlink:href="#poly-6a1aa7da-a846-46e8-9d2f-ae82f49cc0bf"/>
							<gml:surfaceMember xlink:href="#poly-aa0fc82e-fc1c-40a6-a593-fd32f85101a3"/>
							<gml:surfaceMember xlink:href="#poly-719b592b-c070-4fad-b9b9-7e925f978847"/>
							<gml:surfaceMember xlink:href="#poly-d1e5f394-5fbc-4207-a569-b165729d2e7e"/>
							<gml:surfaceMember xlink:href="#poly-4920854c-6193-4ccf-b658-7ec1ee2c0166"/>
							<gml:surfaceMember xlink:href="#poly-50b365b9-ac63-4939-8701-463f9cd196de"/>
							<gml:surfaceMember xlink:href="#poly-31b4ae7c-1d27-450c-80b8-c0dea3869234"/>
							<gml:surfaceMember xlink:href="#poly-1f380fe8-5d25-4898-b366-9df99feb8d19"/>
							<gml:surfaceMember xlink:href="#poly-9738170a-921e-47f4-b7f6-620cea2ccb80"/>
							<gml:surfaceMember xlink:href="#poly-dae52b9a-1c3f-4475-97d4-c6b0f5817b1e"/>
							<gml:surfaceMember xlink:href="#poly-a8ebdc13-e26b-4eaf-980a-b6cd2d0cd1ee"/>
							<gml:surfaceMember xlink:href="#poly-a0fb268b-9ef1-418a-bc01-b4a986fbbba8"/>
							<gml:surfaceMember xlink:href="#poly-5251b003-d718-43df-a390-c8c60377c666"/>
							<gml:surfaceMember xlink:href="#poly-4930abad-d99b-4b12-a269-aa0e06c373ec"/>
							<gml:surfaceMember xlink:href="#poly-7d5a5f8b-56cc-4743-a185-54c3b5283236"/>
							<gml:surfaceMember xlink:href="#poly-cacb3d7f-626b-4750-945c-a4f2b5cb0825"/>
							<gml:surfaceMember xlink:href="#poly-55766362-ff13-4a08-aaa7-076a4c1c1206"/>
							<gml:surfaceMember xlink:href="#poly-e523a9b1-7736-4fcf-b03d-0ff3e3b3878a"/>
							<gml:surfaceMember xlink:href="#poly-0801e3ae-4ba8-408d-a94c-76ec1d68cb98"/>
							<gml:surfaceMember xlink:href="#poly-8cb11f26-8f3c-4a6f-ace0-3364338029e5"/>
							<gml:surfaceMember xlink:href="#poly-cb07c12d-d58b-4a76-ad75-a70cbbf8b940"/>
							<gml:surfaceMember xlink:href="#poly-2f0b8f32-390e-448f-865c-b95a32cb259e"/>
							<gml:surfaceMember xlink:href="#poly-e3e050aa-9faa-4ef8-8d1c-435e76e70822"/>
							<gml:surfaceMember xlink:href="#poly-47043f2f-5dea-416e-b608-257c3f791bf3"/>
							<gml:surfaceMember xlink:href="#poly-8bf1ba0c-5674-4c14-98da-8c29c89ee62d"/>
							<gml:surfaceMember xlink:href="#poly-a54cf7be-88b1-41dc-827c-bad0cec96349"/>
							<gml:surfaceMember xlink:href="#poly-6645c1fb-92e4-49c2-b1f1-2b5636ef6156"/>
							<gml:surfaceMember xlink:href="#poly-129f43dd-ad69-4e80-b2d2-d3fda57849ee"/>
							<gml:surfaceMember xlink:href="#poly-c60e51f2-5c3a-49ce-9875-49515dadb02e"/>
							<gml:surfaceMember xlink:href="#poly-d23836ac-8f85-420d-ac07-51e91529344d"/>
							<gml:surfaceMember xlink:href="#poly-62c335f9-fd39-4f81-915c-8b5ad7356d10"/>
							<gml:surfaceMember xlink:href="#poly-338e5549-1c45-4223-8609-32368fb67183"/>
							<gml:surfaceMember xlink:href="#poly-93bbca5e-b395-40d2-b13c-421fcff0a734"/>
							<gml:surfaceMember xlink:href="#poly-aa21386c-c613-448b-8244-83ab824cbebb"/>
							<gml:surfaceMember xlink:href="#poly-7674e004-b041-4718-b9dd-ddaf8c7c7815"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8a9b42b7-f967-4dbf-b663-580f898e18db_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d404ca5-086c-4d2b-89d7-26ed561e6aa9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67157452632658 139.73808026914375 37.875 35.671598461139865 139.73807312680825 37.875 35.67160416249305 139.73810182970004 37.875 35.67158022767807 139.73810897202748 37.875 35.67157452632658 139.73808026914375 37.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2684b846-0add-4e32-baa8-ea6996094466">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2684b846-0add-4e32-baa8-ea6996094466_0">
											<gml:posList>35.67157452632658 139.73808026914375 37.875 35.67157452632658 139.73808026914375 40.638 35.671598461139865 139.73807312680825 40.638 35.671598461139865 139.73807312680825 37.875 35.67157452632658 139.73808026914375 37.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c14ed5d0-cd47-4a67-b5ca-50a04a6dd919">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c14ed5d0-cd47-4a67-b5ca-50a04a6dd919_0">
											<gml:posList>35.671598461139865 139.73807312680825 40.638 35.67160416249305 139.73810182970004 40.638 35.67160416249305 139.73810182970004 37.875 35.671598461139865 139.73807312680825 37.875 35.671598461139865 139.73807312680825 40.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-682a646e-54ae-4cc1-9ec3-b3df3d4b4c62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-682a646e-54ae-4cc1-9ec3-b3df3d4b4c62_0">
											<gml:posList>35.67157452632658 139.73808026914375 40.638 35.67158022767807 139.73810897202748 40.638 35.67160416249305 139.73810182970004 40.638 35.671598461139865 139.73807312680825 40.638 35.67157452632658 139.73808026914375 40.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a27021a2-dfde-4871-8fb2-c4a610b56dc1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a27021a2-dfde-4871-8fb2-c4a610b56dc1_0">
											<gml:posList>35.67158022767807 139.73810897202748 37.875 35.67158022767807 139.73810897202748 40.638 35.67157452632658 139.73808026914375 40.638 35.67157452632658 139.73808026914375 37.875 35.67158022767807 139.73810897202748 37.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f099bf9-a176-4546-b991-37290bf11ef5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f099bf9-a176-4546-b991-37290bf11ef5_0">
											<gml:posList>35.67160416249305 139.73810182970004 37.875 35.67160416249305 139.73810182970004 40.638 35.67158022767807 139.73810897202748 40.638 35.67158022767807 139.73810897202748 37.875 35.67160416249305 139.73810182970004 37.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8a9b42b7-f967-4dbf-b663-580f898e18db_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-599fc8a8-cd06-476e-8d9c-ecfa7bafc389">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67153935146468 139.73808750215295 42.589 35.67154468780187 139.73811056073765 42.589 35.67153437892734 139.7381141409746 42.589 35.671529042582094 139.7380910713462 42.589 35.67153935146468 139.73808750215295 42.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5730b18c-24b1-4242-b2ee-ef3d1e1ff68a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67162630462792 139.73810741498622 37.875 35.671617436935534 139.7381097121297 37.875 35.671614865244855 139.73809480250455 37.875 35.67162374195067 139.7380925053488 37.875 35.67162630462792 139.73810741498622 37.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79369fb6-b214-4f00-8781-5da1ff1700c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79369fb6-b214-4f00-8781-5da1ff1700c5_0">
											<gml:posList>35.67153437892734 139.7381141409746 42.589 35.67153437892734 139.7381141409746 44.831 35.671529042582094 139.7380910713462 44.831 35.671529042582094 139.7380910713462 42.589 35.67153437892734 139.7381141409746 42.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0823140b-9a34-430d-8b62-8456ab072e26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0823140b-9a34-430d-8b62-8456ab072e26_0">
											<gml:posList>35.67153935146468 139.73808750215295 42.589 35.671529042582094 139.7380910713462 42.589 35.671529042582094 139.7380910713462 44.831 35.67153935146468 139.73808750215295 44.831 35.67153935146468 139.73808750215295 42.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffa2beb3-e390-41a7-a1fc-0ce531488b9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffa2beb3-e390-41a7-a1fc-0ce531488b9c_0">
											<gml:posList>35.67153437892734 139.7381141409746 44.831 35.67154468780187 139.73811056073765 44.831 35.67153935146468 139.73808750215295 44.831 35.671529042582094 139.7380910713462 44.831 35.67153437892734 139.7381141409746 44.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eaa4b874-33f0-4213-b789-25a4f5b355b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eaa4b874-33f0-4213-b789-25a4f5b355b6_0">
											<gml:posList>35.67153437892734 139.7381141409746 42.589 35.67154468780187 139.73811056073765 42.589 35.67154468780187 139.73811056073765 44.831 35.67153437892734 139.7381141409746 44.831 35.67153437892734 139.7381141409746 42.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f68c114-e916-4bd5-9ef6-398a58504678">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f68c114-e916-4bd5-9ef6-398a58504678_0">
											<gml:posList>35.67154468780187 139.73811056073765 42.589 35.67153935146468 139.73808750215295 42.589 35.67153935146468 139.73808750215295 44.831 35.67154468780187 139.73811056073765 44.831 35.67154468780187 139.73811056073765 42.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-931bab5d-e8dd-4288-bcb1-fc27514daa42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-931bab5d-e8dd-4288-bcb1-fc27514daa42_0">
											<gml:posList>35.671614865244855 139.73809480250455 37.875 35.671617436935534 139.7381097121297 37.875 35.671617436935534 139.7381097121297 38.553 35.671614865244855 139.73809480250455 38.553 35.671614865244855 139.73809480250455 37.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22d67440-0db3-4199-9c0d-317c555ca292">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22d67440-0db3-4199-9c0d-317c555ca292_0">
											<gml:posList>35.67162374195067 139.7380925053488 37.875 35.671614865244855 139.73809480250455 37.875 35.671614865244855 139.73809480250455 38.553 35.67162374195067 139.7380925053488 38.553 35.67162374195067 139.7380925053488 37.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8647d0bc-250e-47c3-a5d1-c7f2611e20fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8647d0bc-250e-47c3-a5d1-c7f2611e20fb_0">
											<gml:posList>35.67162630462792 139.73810741498622 38.553 35.67162374195067 139.7380925053488 38.553 35.671614865244855 139.73809480250455 38.553 35.671617436935534 139.7381097121297 38.553 35.67162630462792 139.73810741498622 38.553</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8dc7311-1aa2-410c-b3ab-ad49e1499a0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8dc7311-1aa2-410c-b3ab-ad49e1499a0c_0">
											<gml:posList>35.671617436935534 139.7381097121297 37.875 35.67162630462792 139.73810741498622 37.875 35.67162630462792 139.73810741498622 38.553 35.671617436935534 139.7381097121297 38.553 35.671617436935534 139.7381097121297 37.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a83e183-73ff-4522-8eec-af3f3a500223">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a83e183-73ff-4522-8eec-af3f3a500223_0">
											<gml:posList>35.67162630462792 139.73810741498622 37.875 35.67162374195067 139.7380925053488 37.875 35.67162374195067 139.7380925053488 38.553 35.67162630462792 139.73810741498622 38.553 35.67162630462792 139.73810741498622 37.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8a9b42b7-f967-4dbf-b663-580f898e18db_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8dbcd9e1-ee72-4fa6-8fc0-4d49e22772d1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67152522488745 139.73819891100385 10.66 35.67149890728582 139.7380880362423 10.66 35.67151473995368 139.7380824058543 10.66 35.67154042677459 139.7381935023128 10.66 35.67152522488745 139.73819891100385 10.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a847cec4-21f6-41a7-8b02-48d9c866b8cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a847cec4-21f6-41a7-8b02-48d9c866b8cc_0">
											<gml:posList>35.67151473995368 139.7380824058543 38.268 35.67151473995368 139.7380824058543 10.66 35.67149890728582 139.7380880362423 10.66 35.67149890728582 139.7380880362423 38.268 35.67151473995368 139.7380824058543 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e95ae11c-ae06-4a2c-82b7-457999f57fc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e95ae11c-ae06-4a2c-82b7-457999f57fc6_0">
											<gml:posList>35.67149890728582 139.7380880362423 38.268 35.67149890728582 139.7380880362423 10.66 35.67152522488745 139.73819891100385 10.66 35.67152522488745 139.73819891100385 38.268 35.67149890728582 139.7380880362423 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ceec8ec4-0c90-4624-a3aa-74ea3d3c300c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ceec8ec4-0c90-4624-a3aa-74ea3d3c300c_0">
											<gml:posList>35.67154042677459 139.7381935023128 38.268 35.67151473995368 139.7380824058543 38.268 35.67149890728582 139.7380880362423 38.268 35.67152522488745 139.73819891100385 38.268 35.67154042677459 139.7381935023128 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3fa53aa-8449-4eb7-be10-3a4103895124">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3fa53aa-8449-4eb7-be10-3a4103895124_0">
											<gml:posList>35.67154042677459 139.7381935023128 38.268 35.67154042677459 139.7381935023128 10.66 35.67151473995368 139.7380824058543 10.66 35.67151473995368 139.7380824058543 38.268 35.67154042677459 139.7381935023128 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51a4c486-24cb-468b-ba15-8ec90fc603d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51a4c486-24cb-468b-ba15-8ec90fc603d4_0">
											<gml:posList>35.67152522488745 139.73819891100385 38.268 35.67152522488745 139.73819891100385 10.66 35.67154042677459 139.7381935023128 10.66 35.67154042677459 139.7381935023128 38.268 35.67152522488745 139.73819891100385 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a2f23071-f305-43c9-ad45-5555d69fa961">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2f23071-f305-43c9-ad45-5555d69fa961">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2f23071-f305-43c9-ad45-5555d69fa961">
											<gml:posList>35.67154042677459 139.7381935023128 10.59 35.67151473995368 139.7380824058543 10.59 35.67165795487323 139.73803151047653 10.59 35.67168418238932 139.7381423855463 10.59 35.67154042677459 139.7381935023128 10.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aad1b438-27f8-4ce0-9e05-5ee1862ccd30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aad1b438-27f8-4ce0-9e05-5ee1862ccd30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aad1b438-27f8-4ce0-9e05-5ee1862ccd30">
											<gml:posList>35.67152723283816 139.7381278138798 43.091 35.67152888849789 139.73812418868883 43.091 35.67152054932459 139.73808813204255 43.091 35.671517591225296 139.7380861140626 43.091 35.67152723283816 139.7381278138798 43.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a1aa7da-a846-46e8-9d2f-ae82f49cc0bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a1aa7da-a846-46e8-9d2f-ae82f49cc0bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a1aa7da-a846-46e8-9d2f-ae82f49cc0bf">
											<gml:posList>35.671517591225296 139.7380861140626 38.268 35.671547625732444 139.73807568370017 38.268 35.67151473995368 139.7380824058543 38.268 35.67154042677459 139.7381935023128 38.268 35.671542739268276 139.7381883961229 38.268 35.671528629580514 139.73812732617884 38.268 35.67152723283816 139.7381278138798 38.268 35.671517591225296 139.7380861140626 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa0fc82e-fc1c-40a6-a593-fd32f85101a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa0fc82e-fc1c-40a6-a593-fd32f85101a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa0fc82e-fc1c-40a6-a593-fd32f85101a3">
											<gml:posList>35.671517591225296 139.7380861140626 43.091 35.67152054932459 139.73808813204255 43.091 35.67154597907917 139.73807929783592 43.091 35.671547625732444 139.73807568370017 43.091 35.671517591225296 139.7380861140626 43.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-719b592b-c070-4fad-b9b9-7e925f978847">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-719b592b-c070-4fad-b9b9-7e925f978847">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-719b592b-c070-4fad-b9b9-7e925f978847">
											<gml:posList>35.67155431825509 139.7381153544927 42.589 35.67154597907917 139.73807929783592 42.589 35.67152054932459 139.73808813204255 42.589 35.67152888849789 139.73812418868883 42.589 35.67155431825509 139.7381153544927 42.589</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1e5f394-5fbc-4207-a569-b165729d2e7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1e5f394-5fbc-4207-a569-b165729d2e7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1e5f394-5fbc-4207-a569-b165729d2e7e">
											<gml:posList>35.67155726734889 139.73811738353177 43.091 35.67155431825509 139.7381153544927 43.091 35.67152888849789 139.73812418868883 43.091 35.67152723283816 139.7381278138798 43.091 35.67155726734889 139.73811738353177 43.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4920854c-6193-4ccf-b658-7ec1ee2c0166">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4920854c-6193-4ccf-b658-7ec1ee2c0166">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4920854c-6193-4ccf-b658-7ec1ee2c0166">
											<gml:posList>35.671547625732444 139.73807568370017 43.091 35.67154597907917 139.73807929783592 43.091 35.67155431825509 139.7381153544927 43.091 35.67155726734889 139.73811738353177 43.091 35.671547625732444 139.73807568370017 43.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50b365b9-ac63-4939-8701-463f9cd196de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50b365b9-ac63-4939-8701-463f9cd196de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50b365b9-ac63-4939-8701-463f9cd196de">
											<gml:posList>35.67161961223811 139.7380451321165 38.268 35.67151473995368 139.7380824058543 38.268 35.671547625732444 139.73807568370017 38.268 35.671617191638354 139.7380503047225 38.268 35.67161961223811 139.7380451321165 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-31b4ae7c-1d27-450c-80b8-c0dea3869234">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31b4ae7c-1d27-450c-80b8-c0dea3869234">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31b4ae7c-1d27-450c-80b8-c0dea3869234">
											<gml:posList>35.671617191638354 139.7380503047225 37.875 35.671547625732444 139.73807568370017 37.875 35.67155726734889 139.73811738353177 37.875 35.671528629580514 139.73812732617884 37.875 35.671542739268276 139.7381883961229 37.875 35.67156641410051 139.73817163269695 37.875 35.671556773114226 139.73813070610282 37.875 35.67160280237518 139.73811443528956 37.875 35.67161243435325 139.73815536191586 37.875 35.67163833018646 139.7381545910628 37.875 35.671617191638354 139.7380503047225 37.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f380fe8-5d25-4898-b366-9df99feb8d19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f380fe8-5d25-4898-b366-9df99feb8d19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f380fe8-5d25-4898-b366-9df99feb8d19">
											<gml:posList>35.67160280237518 139.73811443528956 35.729 35.671556773114226 139.73813070610282 35.729 35.67156641410051 139.73817163269695 35.729 35.67161243435325 139.73815536191586 35.729 35.67160280237518 139.73811443528956 35.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9738170a-921e-47f4-b7f6-620cea2ccb80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9738170a-921e-47f4-b7f6-620cea2ccb80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9738170a-921e-47f4-b7f6-620cea2ccb80">
											<gml:posList>35.67156641410051 139.73817163269695 37.875 35.671542739268276 139.7381883961229 37.875 35.67163833018646 139.7381545910628 37.875 35.67161243435325 139.73815536191586 37.875 35.67156641410051 139.73817163269695 37.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dae52b9a-1c3f-4475-97d4-c6b0f5817b1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dae52b9a-1c3f-4475-97d4-c6b0f5817b1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dae52b9a-1c3f-4475-97d4-c6b0f5817b1e">
											<gml:posList>35.67154042677459 139.7381935023128 38.268 35.67164246055714 139.7381572262569 38.268 35.67163833018646 139.7381545910628 38.268 35.671542739268276 139.7381883961229 38.268 35.67154042677459 139.7381935023128 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a8ebdc13-e26b-4eaf-980a-b6cd2d0cd1ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8ebdc13-e26b-4eaf-980a-b6cd2d0cd1ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8ebdc13-e26b-4eaf-980a-b6cd2d0cd1ee">
											<gml:posList>35.67164246055714 139.7381572262569 38.268 35.67161961223811 139.7380451321165 38.268 35.671617191638354 139.7380503047225 38.268 35.67163833018646 139.7381545910628 38.268 35.67164246055714 139.7381572262569 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a0fb268b-9ef1-418a-bc01-b4a986fbbba8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0fb268b-9ef1-418a-bc01-b4a986fbbba8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0fb268b-9ef1-418a-bc01-b4a986fbbba8">
											<gml:posList>35.67161961223811 139.7380451321165 38.268 35.67164246055714 139.7381572262569 38.268 35.67168418238932 139.7381423855463 31.768 35.67161961223811 139.7380451321165 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5251b003-d718-43df-a390-c8c60377c666">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5251b003-d718-43df-a390-c8c60377c666">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5251b003-d718-43df-a390-c8c60377c666">
											<gml:posList>35.67168418238932 139.7381423855463 31.768 35.67165795487323 139.73803151047653 31.768 35.67161961223811 139.7380451321165 38.268 35.67168418238932 139.7381423855463 31.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4930abad-d99b-4b12-a269-aa0e06c373ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4930abad-d99b-4b12-a269-aa0e06c373ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4930abad-d99b-4b12-a269-aa0e06c373ec">
											<gml:posList>35.67152723283816 139.7381278138798 43.091 35.671517591225296 139.7380861140626 43.091 35.671517591225296 139.7380861140626 38.268 35.67152723283816 139.7381278138798 38.268 35.67152723283816 139.7381278138798 43.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d5a5f8b-56cc-4743-a185-54c3b5283236">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d5a5f8b-56cc-4743-a185-54c3b5283236">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d5a5f8b-56cc-4743-a185-54c3b5283236">
											<gml:posList>35.67152888849789 139.73812418868883 43.091 35.67152888849789 139.73812418868883 42.589 35.67152054932459 139.73808813204255 42.589 35.67152054932459 139.73808813204255 43.091 35.67152888849789 139.73812418868883 43.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cacb3d7f-626b-4750-945c-a4f2b5cb0825">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cacb3d7f-626b-4750-945c-a4f2b5cb0825">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cacb3d7f-626b-4750-945c-a4f2b5cb0825">
											<gml:posList>35.67151473995368 139.7380824058543 10.59 35.67154042677459 139.7381935023128 10.59 35.67154042677459 139.7381935023128 38.268 35.67151473995368 139.7380824058543 38.268 35.67151473995368 139.7380824058543 10.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55766362-ff13-4a08-aaa7-076a4c1c1206">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55766362-ff13-4a08-aaa7-076a4c1c1206">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55766362-ff13-4a08-aaa7-076a4c1c1206">
											<gml:posList>35.671517591225296 139.7380861140626 43.091 35.671547625732444 139.73807568370017 43.091 35.671547625732444 139.73807568370017 38.268 35.671517591225296 139.7380861140626 38.268 35.671517591225296 139.7380861140626 43.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e523a9b1-7736-4fcf-b03d-0ff3e3b3878a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e523a9b1-7736-4fcf-b03d-0ff3e3b3878a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e523a9b1-7736-4fcf-b03d-0ff3e3b3878a">
											<gml:posList>35.67152054932459 139.73808813204255 43.091 35.67152054932459 139.73808813204255 42.589 35.67154597907917 139.73807929783592 42.589 35.67154597907917 139.73807929783592 43.091 35.67152054932459 139.73808813204255 43.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0801e3ae-4ba8-408d-a94c-76ec1d68cb98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0801e3ae-4ba8-408d-a94c-76ec1d68cb98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0801e3ae-4ba8-408d-a94c-76ec1d68cb98">
											<gml:posList>35.671528629580514 139.73812732617884 38.268 35.671542739268276 139.7381883961229 38.268 35.671542739268276 139.7381883961229 37.875 35.671528629580514 139.73812732617884 37.875 35.671528629580514 139.73812732617884 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cb11f26-8f3c-4a6f-ace0-3364338029e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cb11f26-8f3c-4a6f-ace0-3364338029e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cb11f26-8f3c-4a6f-ace0-3364338029e5">
											<gml:posList>35.67155431825509 139.7381153544927 43.091 35.67155431825509 139.7381153544927 42.589 35.67152888849789 139.73812418868883 42.589 35.67152888849789 139.73812418868883 43.091 35.67155431825509 139.7381153544927 43.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb07c12d-d58b-4a76-ad75-a70cbbf8b940">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb07c12d-d58b-4a76-ad75-a70cbbf8b940">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb07c12d-d58b-4a76-ad75-a70cbbf8b940">
											<gml:posList>35.67155726734889 139.73811738353177 43.091 35.67152723283816 139.7381278138798 43.091 35.67152723283816 139.7381278138798 38.268 35.671528629580514 139.73812732617884 38.268 35.67155726734889 139.73811738353177 38.268 35.67155726734889 139.73811738353177 43.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f0b8f32-390e-448f-865c-b95a32cb259e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f0b8f32-390e-448f-865c-b95a32cb259e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f0b8f32-390e-448f-865c-b95a32cb259e">
											<gml:posList>35.67155726734889 139.73811738353177 38.268 35.671528629580514 139.73812732617884 38.268 35.671528629580514 139.73812732617884 37.875 35.67155726734889 139.73811738353177 37.875 35.67155726734889 139.73811738353177 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3e050aa-9faa-4ef8-8d1c-435e76e70822">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3e050aa-9faa-4ef8-8d1c-435e76e70822">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3e050aa-9faa-4ef8-8d1c-435e76e70822">
											<gml:posList>35.67154597907917 139.73807929783592 43.091 35.67154597907917 139.73807929783592 42.589 35.67155431825509 139.7381153544927 42.589 35.67155431825509 139.7381153544927 43.091 35.67154597907917 139.73807929783592 43.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47043f2f-5dea-416e-b608-257c3f791bf3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47043f2f-5dea-416e-b608-257c3f791bf3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47043f2f-5dea-416e-b608-257c3f791bf3">
											<gml:posList>35.671547625732444 139.73807568370017 43.091 35.67155726734889 139.73811738353177 43.091 35.67155726734889 139.73811738353177 38.268 35.671547625732444 139.73807568370017 38.268 35.671547625732444 139.73807568370017 43.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8bf1ba0c-5674-4c14-98da-8c29c89ee62d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bf1ba0c-5674-4c14-98da-8c29c89ee62d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bf1ba0c-5674-4c14-98da-8c29c89ee62d">
											<gml:posList>35.671547625732444 139.73807568370017 38.268 35.67155726734889 139.73811738353177 38.268 35.67155726734889 139.73811738353177 37.875 35.671547625732444 139.73807568370017 37.875 35.671547625732444 139.73807568370017 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a54cf7be-88b1-41dc-827c-bad0cec96349">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a54cf7be-88b1-41dc-827c-bad0cec96349">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a54cf7be-88b1-41dc-827c-bad0cec96349">
											<gml:posList>35.67156641410051 139.73817163269695 37.875 35.67156641410051 139.73817163269695 35.729 35.671556773114226 139.73813070610282 35.729 35.671556773114226 139.73813070610282 37.875 35.67156641410051 139.73817163269695 37.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6645c1fb-92e4-49c2-b1f1-2b5636ef6156">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6645c1fb-92e4-49c2-b1f1-2b5636ef6156">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6645c1fb-92e4-49c2-b1f1-2b5636ef6156">
											<gml:posList>35.671556773114226 139.73813070610282 37.875 35.671556773114226 139.73813070610282 35.729 35.67160280237518 139.73811443528956 35.729 35.67160280237518 139.73811443528956 37.875 35.671556773114226 139.73813070610282 37.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-129f43dd-ad69-4e80-b2d2-d3fda57849ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-129f43dd-ad69-4e80-b2d2-d3fda57849ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-129f43dd-ad69-4e80-b2d2-d3fda57849ee">
											<gml:posList>35.671617191638354 139.7380503047225 38.268 35.671547625732444 139.73807568370017 38.268 35.671547625732444 139.73807568370017 37.875 35.671617191638354 139.7380503047225 37.875 35.671617191638354 139.7380503047225 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c60e51f2-5c3a-49ce-9875-49515dadb02e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c60e51f2-5c3a-49ce-9875-49515dadb02e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c60e51f2-5c3a-49ce-9875-49515dadb02e">
											<gml:posList>35.67151473995368 139.7380824058543 38.268 35.67161961223811 139.7380451321165 38.268 35.67165795487323 139.73803151047653 31.768 35.67165795487323 139.73803151047653 10.59 35.67151473995368 139.7380824058543 10.59 35.67151473995368 139.7380824058543 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d23836ac-8f85-420d-ac07-51e91529344d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d23836ac-8f85-420d-ac07-51e91529344d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d23836ac-8f85-420d-ac07-51e91529344d">
											<gml:posList>35.67156641410051 139.73817163269695 37.875 35.67161243435325 139.73815536191586 37.875 35.67161243435325 139.73815536191586 35.729 35.67156641410051 139.73817163269695 35.729 35.67156641410051 139.73817163269695 37.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62c335f9-fd39-4f81-915c-8b5ad7356d10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62c335f9-fd39-4f81-915c-8b5ad7356d10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62c335f9-fd39-4f81-915c-8b5ad7356d10">
											<gml:posList>35.671542739268276 139.7381883961229 38.268 35.67163833018646 139.7381545910628 38.268 35.67163833018646 139.7381545910628 37.875 35.671542739268276 139.7381883961229 37.875 35.671542739268276 139.7381883961229 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-338e5549-1c45-4223-8609-32368fb67183">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-338e5549-1c45-4223-8609-32368fb67183">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-338e5549-1c45-4223-8609-32368fb67183">
											<gml:posList>35.67160280237518 139.73811443528956 37.875 35.67160280237518 139.73811443528956 35.729 35.67161243435325 139.73815536191586 35.729 35.67161243435325 139.73815536191586 37.875 35.67160280237518 139.73811443528956 37.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-93bbca5e-b395-40d2-b13c-421fcff0a734">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93bbca5e-b395-40d2-b13c-421fcff0a734">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93bbca5e-b395-40d2-b13c-421fcff0a734">
											<gml:posList>35.67168418238932 139.7381423855463 31.768 35.67164246055714 139.7381572262569 38.268 35.67154042677459 139.7381935023128 38.268 35.67154042677459 139.7381935023128 10.59 35.67168418238932 139.7381423855463 10.59 35.67168418238932 139.7381423855463 31.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa21386c-c613-448b-8244-83ab824cbebb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa21386c-c613-448b-8244-83ab824cbebb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa21386c-c613-448b-8244-83ab824cbebb">
											<gml:posList>35.67163833018646 139.7381545910628 38.268 35.671617191638354 139.7380503047225 38.268 35.671617191638354 139.7380503047225 37.875 35.67163833018646 139.7381545910628 37.875 35.67163833018646 139.7381545910628 38.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7674e004-b041-4718-b9dd-ddaf8c7c7815">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7674e004-b041-4718-b9dd-ddaf8c7c7815">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7674e004-b041-4718-b9dd-ddaf8c7c7815">
											<gml:posList>35.67168418238932 139.7381423855463 10.59 35.67165795487323 139.73803151047653 10.59 35.67165795487323 139.73803151047653 31.768 35.67168418238932 139.7381423855463 31.768 35.67168418238932 139.7381423855463 10.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9373</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">191.9713</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>