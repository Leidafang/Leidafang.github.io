<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8b8b4d84-1e94-4c36-8d8a-f39d67b58f73">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">20</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66851640893469 139.7389019470069 0 35.668534360409225 139.73891998608363 0 35.668552142091364 139.73889391866064 0 35.668684028884314 139.73902918759802 0 35.66868962901069 139.73902099590606 0 35.66870889782017 139.73904075667969 0 35.66872861528971 139.7390118923035 0 35.6687093464669 139.73899212048593 0 35.66875704649222 139.73892228655552 0 35.66862461841044 139.73878657646878 0 35.66859355669687 139.73883201220886 0 35.668495317956264 139.73873116755382 0 35.66841491775426 139.73884890218972 0 35.668488889820836 139.73892470103544 0 35.668480966748874 139.7389361982017 0 35.66848830986114 139.73894376711198 0 35.66851640893469 139.7389019470069 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66851640893469 139.7389019470069 12.7 35.66848830986114 139.73894376711198 12.7 35.668480966748874 139.7389361982017 12.7 35.668488889820836 139.73892470103544 12.7 35.66841491775426 139.73884890218972 12.7 35.668495317956264 139.73873116755382 12.7 35.66859355669687 139.73883201220886 12.7 35.66862461841044 139.73878657646878 12.7 35.66875704649222 139.73892228655552 12.7 35.6687093464669 139.73899212048593 12.7 35.66872861528971 139.7390118923035 12.7 35.66870889782017 139.73904075667969 12.7 35.66868962901069 139.73902099590606 12.7 35.668684028884314 139.73902918759802 12.7 35.668552142091364 139.73889391866064 12.7 35.668534360409225 139.73891998608363 12.7 35.66851640893469 139.7389019470069 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66851640893469 139.7389019470069 12.7 35.668534360409225 139.73891998608363 12.7 35.668534360409225 139.73891998608363 32.72 35.66851640893469 139.7389019470069 32.72 35.66851640893469 139.7389019470069 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668534360409225 139.73891998608363 12.7 35.668552142091364 139.73889391866064 12.7 35.668552142091364 139.73889391866064 32.72 35.668534360409225 139.73891998608363 32.72 35.668534360409225 139.73891998608363 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668552142091364 139.73889391866064 12.7 35.668684028884314 139.73902918759802 12.7 35.668684028884314 139.73902918759802 32.72 35.668552142091364 139.73889391866064 32.72 35.668552142091364 139.73889391866064 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668684028884314 139.73902918759802 12.7 35.66868962901069 139.73902099590606 12.7 35.66868962901069 139.73902099590606 32.72 35.668684028884314 139.73902918759802 32.72 35.668684028884314 139.73902918759802 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868962901069 139.73902099590606 12.7 35.66870889782017 139.73904075667969 12.7 35.66870889782017 139.73904075667969 32.72 35.66868962901069 139.73902099590606 32.72 35.66868962901069 139.73902099590606 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66870889782017 139.73904075667969 12.7 35.66872861528971 139.7390118923035 12.7 35.66872861528971 139.7390118923035 32.72 35.66870889782017 139.73904075667969 32.72 35.66870889782017 139.73904075667969 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872861528971 139.7390118923035 12.7 35.6687093464669 139.73899212048593 12.7 35.6687093464669 139.73899212048593 32.72 35.66872861528971 139.7390118923035 32.72 35.66872861528971 139.7390118923035 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6687093464669 139.73899212048593 12.7 35.66875704649222 139.73892228655552 12.7 35.66875704649222 139.73892228655552 32.72 35.6687093464669 139.73899212048593 32.72 35.6687093464669 139.73899212048593 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66875704649222 139.73892228655552 12.7 35.66862461841044 139.73878657646878 12.7 35.66862461841044 139.73878657646878 32.72 35.66875704649222 139.73892228655552 32.72 35.66875704649222 139.73892228655552 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862461841044 139.73878657646878 12.7 35.66859355669687 139.73883201220886 12.7 35.66859355669687 139.73883201220886 32.72 35.66862461841044 139.73878657646878 32.72 35.66862461841044 139.73878657646878 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66859355669687 139.73883201220886 12.7 35.668495317956264 139.73873116755382 12.7 35.668495317956264 139.73873116755382 32.72 35.66859355669687 139.73883201220886 32.72 35.66859355669687 139.73883201220886 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668495317956264 139.73873116755382 12.7 35.66841491775426 139.73884890218972 12.7 35.66841491775426 139.73884890218972 32.72 35.668495317956264 139.73873116755382 32.72 35.668495317956264 139.73873116755382 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66841491775426 139.73884890218972 12.7 35.668488889820836 139.73892470103544 12.7 35.668488889820836 139.73892470103544 32.72 35.66841491775426 139.73884890218972 32.72 35.66841491775426 139.73884890218972 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668488889820836 139.73892470103544 12.7 35.668480966748874 139.7389361982017 12.7 35.668480966748874 139.7389361982017 32.72 35.668488889820836 139.73892470103544 32.72 35.668488889820836 139.73892470103544 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668480966748874 139.7389361982017 12.7 35.66848830986114 139.73894376711198 12.7 35.66848830986114 139.73894376711198 32.72 35.668480966748874 139.7389361982017 32.72 35.668480966748874 139.7389361982017 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848830986114 139.73894376711198 12.7 35.66851640893469 139.7389019470069 12.7 35.66851640893469 139.7389019470069 32.72 35.66848830986114 139.73894376711198 32.72 35.66848830986114 139.73894376711198 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66851640893469 139.7389019470069 32.72 35.668534360409225 139.73891998608363 32.72 35.668552142091364 139.73889391866064 32.72 35.668684028884314 139.73902918759802 32.72 35.66868962901069 139.73902099590606 32.72 35.66870889782017 139.73904075667969 32.72 35.66872861528971 139.7390118923035 32.72 35.6687093464669 139.73899212048593 32.72 35.66875704649222 139.73892228655552 32.72 35.66862461841044 139.73878657646878 32.72 35.66859355669687 139.73883201220886 32.72 35.668495317956264 139.73873116755382 32.72 35.66841491775426 139.73884890218972 32.72 35.668488889820836 139.73892470103544 32.72 35.668480966748874 139.7389361982017 32.72 35.66848830986114 139.73894376711198 32.72 35.66851640893469 139.7389019470069 32.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-30074343-bab6-480e-bac4-3dd615e7470a"/>
							<gml:surfaceMember xlink:href="#poly-b2910f23-2b1a-4690-b6c8-c95270c3bd48"/>
							<gml:surfaceMember xlink:href="#poly-c36d3db5-c2bb-45fb-9a42-9615bfa33397"/>
							<gml:surfaceMember xlink:href="#poly-cac2ec24-b0bb-4acb-a5a9-aa2ee134441b"/>
							<gml:surfaceMember xlink:href="#poly-0daac21d-cadb-4429-bb48-1b8852132a63"/>
							<gml:surfaceMember xlink:href="#poly-ebd02b6c-6a69-4313-b2cb-142f485a644e"/>
							<gml:surfaceMember xlink:href="#poly-e95eedea-8fea-4052-8d10-638145191a43"/>
							<gml:surfaceMember xlink:href="#poly-c8f4c2b3-3ed4-46a1-a42d-285482e84035"/>
							<gml:surfaceMember xlink:href="#poly-1dc628be-6372-491e-bea4-bb26400f9e49"/>
							<gml:surfaceMember xlink:href="#poly-3fe1e76b-248e-47cd-aa77-fda7963f8f72"/>
							<gml:surfaceMember xlink:href="#poly-4cb7a9b5-9eb4-4373-ba75-49ef8b0baf9a"/>
							<gml:surfaceMember xlink:href="#poly-786d30ba-62c1-4fc0-a9ea-2c9bc1a2e3ca"/>
							<gml:surfaceMember xlink:href="#poly-84470677-d0f2-4b5f-904c-4435dd3e709d"/>
							<gml:surfaceMember xlink:href="#poly-9c4ddce1-6683-4e6e-98b4-c9524a86fa25"/>
							<gml:surfaceMember xlink:href="#poly-d68416a4-2910-4ca1-8dc4-f91e8fa270fd"/>
							<gml:surfaceMember xlink:href="#poly-55ce9bd9-bb3d-49bc-8a45-ac31168eb137"/>
							<gml:surfaceMember xlink:href="#poly-48cf3596-0855-40ab-8c20-97301558f6aa"/>
							<gml:surfaceMember xlink:href="#poly-0abdb268-8061-4252-a380-aad55f8d3a87"/>
							<gml:surfaceMember xlink:href="#poly-f7cbe541-93f5-448a-a12d-7b5c5f1b5262"/>
							<gml:surfaceMember xlink:href="#poly-958f960e-dd28-4044-9590-1859a6803122"/>
							<gml:surfaceMember xlink:href="#poly-85db3faa-6b02-4a3d-9a18-fe1fd075a0e8"/>
							<gml:surfaceMember xlink:href="#poly-47ddab44-7c3e-4979-b9c1-255a4d37130a"/>
							<gml:surfaceMember xlink:href="#poly-51ff5c33-0063-4652-8105-d3cf7d2cd0db"/>
							<gml:surfaceMember xlink:href="#poly-9821427e-8f7a-4f37-87fb-c269257e7ef7"/>
							<gml:surfaceMember xlink:href="#poly-40fb2dcc-da65-485a-800b-89910bb6ec28"/>
							<gml:surfaceMember xlink:href="#poly-73295802-1601-4772-8893-5a8c470deab9"/>
							<gml:surfaceMember xlink:href="#poly-44e474e0-0daa-4aea-ad60-ea4b893430e6"/>
							<gml:surfaceMember xlink:href="#poly-5d72481f-5630-4d4a-b621-54cdc85e0e74"/>
							<gml:surfaceMember xlink:href="#poly-dba105da-7cea-4594-afd5-a7a51cb6908a"/>
							<gml:surfaceMember xlink:href="#poly-5ecb1fce-f29a-4d66-a880-13f0b1a6553f"/>
							<gml:surfaceMember xlink:href="#poly-17c2b642-5696-4929-957f-e9c24c46d821"/>
							<gml:surfaceMember xlink:href="#poly-beb2d4f4-102b-434a-ba43-ba0806227386"/>
							<gml:surfaceMember xlink:href="#poly-483cb41e-1b3a-487e-8a75-09828abe4457"/>
							<gml:surfaceMember xlink:href="#poly-71f1c8d4-8171-422d-957f-fff37a151258"/>
							<gml:surfaceMember xlink:href="#poly-749cffaa-5b7d-4d2c-9005-2ad218b4c7a1"/>
							<gml:surfaceMember xlink:href="#poly-ee8b9997-4a6a-4bf9-8028-c4c89fdecd82"/>
							<gml:surfaceMember xlink:href="#poly-76c832a2-75dc-49db-8d5d-347774459df8"/>
							<gml:surfaceMember xlink:href="#poly-66f59e91-e7d3-4c27-8490-97a4f199e54d"/>
							<gml:surfaceMember xlink:href="#poly-c5e90919-e118-4102-868e-3471b89de5b3"/>
							<gml:surfaceMember xlink:href="#poly-6151691d-569b-4cef-8acb-c5e892435a76"/>
							<gml:surfaceMember xlink:href="#poly-d15bd3ce-e9c2-46e8-9a56-446e1f681ea3"/>
							<gml:surfaceMember xlink:href="#poly-ef05fc78-01b9-4752-b7e0-a51851c777dd"/>
							<gml:surfaceMember xlink:href="#poly-c9c0124d-9f11-4b19-bba5-bd69f358ca88"/>
							<gml:surfaceMember xlink:href="#poly-d2fad424-4433-46d2-bd74-174d699be87a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8b8b4d84-1e94-4c36-8d8a-f39d67b58f73_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6295570c-7a2c-49a0-906f-2e2feb69e0af">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668490838425456 139.7388233737924 34.318 35.668484577906376 139.7388170186766 34.318 35.66849236575239 139.73880551061146 34.318 35.66849862628075 139.73881187677296 34.318 35.668490838425456 139.7388233737924 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa871668-52cd-4859-a571-41774efa4ef1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66851200436852 139.73882553595294 34.318 35.668519837231926 139.73881396155562 34.318 35.66852561061984 139.73881982017798 34.318 35.66851777775589 139.73883139457556 34.318 35.66851200436852 139.73882553595294 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-581794b1-69e4-4b6b-ad40-8338855a46e3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66847528974405 139.73884635674668 34.318 35.66846902922617 139.73884000163034 34.318 35.66847649295308 139.73882896892954 34.318 35.66848275347154 139.73883532404562 34.318 35.66847528974405 139.73884635674668 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30b73693-2710-40e5-bd5d-5e84c2ee7249">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66850178563201 139.73884063683394 34.318 35.668507322667004 139.73883246731384 34.318 35.668513087040296 139.73883832594723 34.318 35.66850755001358 139.7388465065135 34.318 35.66850178563201 139.73884063683394 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-777e07a1-3a82-49c3-84d3-fc65a2e773ff">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848792056408 139.73886113245476 34.318 35.66849604153212 139.73884912693092 34.318 35.668501805913294 139.73885499661068 34.318 35.66849368493602 139.73886699108883 34.318 35.66848792056408 139.73886113245476 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04561473-2cb0-49c7-be65-1ecba8b04273">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6685145236195 139.73890010454485 34.318 35.66850887667886 139.7388945661026 34.318 35.66852612684907 139.73886888591858 34.318 35.668531773912186 139.73887457900412 34.318 35.6685145236195 139.73890010454485 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a02c8d34-9d94-4d5a-bd58-f8bbe4540c98">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668531773912186 139.73887457900412 34.462 35.668533578078225 139.73887638842356 34.462 35.66851639992961 139.7389019580635 34.462 35.6685145236195 139.73890010454485 34.462 35.668531773912186 139.73887457900412 34.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd4d69fc-3740-4c6e-81be-2b9457f3192e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862495282083 139.7389140913001 32.486 35.66861796667518 139.73892494671486 32.486 35.66861241903397 139.7389195959291 32.486 35.66861941418421 139.738908729458 32.486 35.66862495282083 139.7389140913001 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a78c0041-9315-4fc0-97bf-adc4d508c853">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66864039114398 139.73893427629054 32.486 35.6686348723115 139.73894267776217 32.486 35.66862920731082 139.73893709514584 32.486 35.668634735148 139.7389286826178 32.486 35.66864039114398 139.73893427629054 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb15e59a-22ba-4561-8030-bf4bff26dea8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668657763267596 139.7389376690591 32.486 35.668663554720126 139.7389435829093 32.486 35.66865635201737 139.73895415138506 32.486 35.66865056957908 139.73894823752403 32.486 35.668657763267596 139.7389376690591 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48468a54-3dab-400a-ad3b-9cdc59752b32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686647572826 139.73897135119537 32.486 35.668675020541116 139.7389555322563 32.486 35.66868079374022 139.73896115893388 32.486 35.66867053048964 139.7389769889194 32.486 35.6686647572826 139.73897135119537 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-999a7801-4e4f-4651-83aa-d3774e7946ec">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868932480708 139.73897786153094 32.486 35.668695179007486 139.73898333347145 32.486 35.66868782405451 139.7389951613739 32.486 35.668681969863286 139.7389897004791 32.486 35.66868932480708 139.73897786153094 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ff59024-ba9e-4c0b-b0bf-e85348dc4290">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ff59024-ba9e-4c0b-b0bf-e85348dc4290_0">
											<gml:posList>35.668531773912186 139.73887457900412 34.462 35.6685145236195 139.73890010454485 34.462 35.6685145236195 139.73890010454485 34.318 35.668531773912186 139.73887457900412 34.318 35.668531773912186 139.73887457900412 34.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b60bc90e-d823-4348-abef-6ef1b6611d4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b60bc90e-d823-4348-abef-6ef1b6611d4f_0">
											<gml:posList>35.66849236575239 139.73880551061146 34.318 35.66849236575239 139.73880551061146 36.126 35.66849862628075 139.73881187677296 36.126 35.66849862628075 139.73881187677296 34.318 35.66849236575239 139.73880551061146 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7d05fdc-186b-457c-a29c-bb041b0b1661">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7d05fdc-186b-457c-a29c-bb041b0b1661_0">
											<gml:posList>35.66849236575239 139.73880551061146 34.318 35.668484577906376 139.7388170186766 34.318 35.668484577906376 139.7388170186766 36.126 35.66849236575239 139.73880551061146 36.126 35.66849236575239 139.73880551061146 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10744759-45b3-4b04-a9b2-86a9dc892899">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10744759-45b3-4b04-a9b2-86a9dc892899_0">
											<gml:posList>35.66849236575239 139.73880551061146 36.126 35.668484577906376 139.7388170186766 36.126 35.668490838425456 139.7388233737924 36.126 35.66849862628075 139.73881187677296 36.126 35.66849236575239 139.73880551061146 36.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7f6faa5-1c59-4c63-b8e7-6f7cb06b6b16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7f6faa5-1c59-4c63-b8e7-6f7cb06b6b16_0">
											<gml:posList>35.66852561061984 139.73881982017798 34.318 35.668519837231926 139.73881396155562 34.318 35.668519837231926 139.73881396155562 36.126 35.66852561061984 139.73881982017798 36.126 35.66852561061984 139.73881982017798 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1cc6a1c-df04-4460-abe1-f76522788e0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1cc6a1c-df04-4460-abe1-f76522788e0b_0">
											<gml:posList>35.668490838425456 139.7388233737924 34.318 35.66849862628075 139.73881187677296 34.318 35.66849862628075 139.73881187677296 36.126 35.668490838425456 139.7388233737924 36.126 35.668490838425456 139.7388233737924 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81315d47-dbb0-4734-900f-1097c518c8ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81315d47-dbb0-4734-900f-1097c518c8ff_0">
											<gml:posList>35.668519837231926 139.73881396155562 34.318 35.66851200436852 139.73882553595294 34.318 35.66851200436852 139.73882553595294 36.126 35.668519837231926 139.73881396155562 36.126 35.668519837231926 139.73881396155562 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5625248-5472-484e-8ef2-0f244fa95310">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5625248-5472-484e-8ef2-0f244fa95310_0">
											<gml:posList>35.668484577906376 139.7388170186766 34.318 35.668490838425456 139.7388233737924 34.318 35.668490838425456 139.7388233737924 36.126 35.668484577906376 139.7388170186766 36.126 35.668484577906376 139.7388170186766 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b674a2d7-eafa-444b-b565-be9a44293466">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b674a2d7-eafa-444b-b565-be9a44293466_0">
											<gml:posList>35.66852561061984 139.73881982017798 36.126 35.668519837231926 139.73881396155562 36.126 35.66851200436852 139.73882553595294 36.126 35.66851777775589 139.73883139457556 36.126 35.66852561061984 139.73881982017798 36.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e307945-18b0-4da3-9863-ad6d918723a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e307945-18b0-4da3-9863-ad6d918723a7_0">
											<gml:posList>35.66851777775589 139.73883139457556 34.318 35.66852561061984 139.73881982017798 34.318 35.66852561061984 139.73881982017798 36.126 35.66851777775589 139.73883139457556 36.126 35.66851777775589 139.73883139457556 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61a22556-0802-4950-ab4a-4a9193548825">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61a22556-0802-4950-ab4a-4a9193548825_0">
											<gml:posList>35.66851200436852 139.73882553595294 34.318 35.66851777775589 139.73883139457556 34.318 35.66851777775589 139.73883139457556 36.126 35.66851200436852 139.73882553595294 36.126 35.66851200436852 139.73882553595294 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e84c686-aea0-4cdf-a33a-304a46749751">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e84c686-aea0-4cdf-a33a-304a46749751_0">
											<gml:posList>35.66848275347154 139.73883532404562 34.318 35.66847649295308 139.73882896892954 34.318 35.66847649295308 139.73882896892954 36.126 35.66848275347154 139.73883532404562 36.126 35.66848275347154 139.73883532404562 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db9afc96-01db-42f0-9db0-bef5802d49d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db9afc96-01db-42f0-9db0-bef5802d49d7_0">
											<gml:posList>35.66847649295308 139.73882896892954 34.318 35.66846902922617 139.73884000163034 34.318 35.66846902922617 139.73884000163034 36.126 35.66847649295308 139.73882896892954 36.126 35.66847649295308 139.73882896892954 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1e8ee64-3b87-49be-8953-f22cb4a43912">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1e8ee64-3b87-49be-8953-f22cb4a43912_0">
											<gml:posList>35.668513087040296 139.73883832594723 34.318 35.668507322667004 139.73883246731384 34.318 35.668507322667004 139.73883246731384 36.126 35.668513087040296 139.73883832594723 36.126 35.668513087040296 139.73883832594723 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f62310a9-4a26-4131-accb-6c1c8505f397">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f62310a9-4a26-4131-accb-6c1c8505f397_0">
											<gml:posList>35.668507322667004 139.73883246731384 34.318 35.66850178563201 139.73884063683394 34.318 35.66850178563201 139.73884063683394 36.126 35.668507322667004 139.73883246731384 36.126 35.668507322667004 139.73883246731384 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2dfe895-b495-4cb6-8244-7d4673ddea08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2dfe895-b495-4cb6-8244-7d4673ddea08_0">
											<gml:posList>35.66847528974405 139.73884635674668 36.126 35.66848275347154 139.73883532404562 36.126 35.66847649295308 139.73882896892954 36.126 35.66846902922617 139.73884000163034 36.126 35.66847528974405 139.73884635674668 36.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11ed63f0-5ba1-4eff-91e2-c67d33e36288">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11ed63f0-5ba1-4eff-91e2-c67d33e36288_0">
											<gml:posList>35.668513087040296 139.73883832594723 36.126 35.668507322667004 139.73883246731384 36.126 35.66850178563201 139.73884063683394 36.126 35.66850755001358 139.7388465065135 36.126 35.668513087040296 139.73883832594723 36.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62e7836d-9bf8-444d-8591-d68d0f33530d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62e7836d-9bf8-444d-8591-d68d0f33530d_0">
											<gml:posList>35.66847528974405 139.73884635674668 34.318 35.66848275347154 139.73883532404562 34.318 35.66848275347154 139.73883532404562 36.126 35.66847528974405 139.73884635674668 36.126 35.66847528974405 139.73884635674668 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-873dbd88-3d52-43b9-872c-aea1065d79ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-873dbd88-3d52-43b9-872c-aea1065d79ef_0">
											<gml:posList>35.66850755001358 139.7388465065135 34.318 35.668513087040296 139.73883832594723 34.318 35.668513087040296 139.73883832594723 36.126 35.66850755001358 139.7388465065135 36.126 35.66850755001358 139.7388465065135 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46f9af78-c736-4bfb-a2cf-27b943983f6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46f9af78-c736-4bfb-a2cf-27b943983f6b_0">
											<gml:posList>35.66846902922617 139.73884000163034 34.318 35.66847528974405 139.73884635674668 34.318 35.66847528974405 139.73884635674668 36.126 35.66846902922617 139.73884000163034 36.126 35.66846902922617 139.73884000163034 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a786d91-98b4-4823-9b1a-c2f73f0a8e64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a786d91-98b4-4823-9b1a-c2f73f0a8e64_0">
											<gml:posList>35.66850755001358 139.7388465065135 34.318 35.66850755001358 139.7388465065135 36.126 35.66850178563201 139.73884063683394 36.126 35.66850178563201 139.73884063683394 34.318 35.66850755001358 139.7388465065135 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d29cd747-add7-406b-807e-4bd9a8016447">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d29cd747-add7-406b-807e-4bd9a8016447_0">
											<gml:posList>35.668501805913294 139.73885499661068 34.318 35.66849604153212 139.73884912693092 34.318 35.66849604153212 139.73884912693092 36.126 35.668501805913294 139.73885499661068 36.126 35.668501805913294 139.73885499661068 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b87b68a7-8484-4460-ada7-72711e463207">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b87b68a7-8484-4460-ada7-72711e463207_0">
											<gml:posList>35.66848792056408 139.73886113245476 34.318 35.66848792056408 139.73886113245476 36.126 35.66849604153212 139.73884912693092 36.126 35.66849604153212 139.73884912693092 34.318 35.66848792056408 139.73886113245476 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f3c62b2-7f4a-49e4-bd83-5f4c3e75fd10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f3c62b2-7f4a-49e4-bd83-5f4c3e75fd10_0">
											<gml:posList>35.668501805913294 139.73885499661068 36.126 35.66849604153212 139.73884912693092 36.126 35.66848792056408 139.73886113245476 36.126 35.66849368493602 139.73886699108883 36.126 35.668501805913294 139.73885499661068 36.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c7d9489-5f70-4640-9308-ab4e869fd8ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c7d9489-5f70-4640-9308-ab4e869fd8ca_0">
											<gml:posList>35.668501805913294 139.73885499661068 34.318 35.668501805913294 139.73885499661068 36.126 35.66849368493602 139.73886699108883 36.126 35.66849368493602 139.73886699108883 34.318 35.668501805913294 139.73885499661068 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ed5f878-bcc1-4881-8ef5-9ef8247a3691">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ed5f878-bcc1-4881-8ef5-9ef8247a3691_0">
											<gml:posList>35.66848792056408 139.73886113245476 34.318 35.66849368493602 139.73886699108883 34.318 35.66849368493602 139.73886699108883 36.126 35.66848792056408 139.73886113245476 36.126 35.66848792056408 139.73886113245476 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99257208-e809-47bf-9239-6c9c77f32802">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99257208-e809-47bf-9239-6c9c77f32802_0">
											<gml:posList>35.668531773912186 139.73887457900412 34.462 35.668531773912186 139.73887457900412 34.318 35.66852612684907 139.73886888591858 34.318 35.668531773912186 139.73887457900412 34.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac581cef-80a8-445a-9167-e67080893754">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac581cef-80a8-445a-9167-e67080893754_0">
											<gml:posList>35.668533578078225 139.73887638842356 34.462 35.668531773912186 139.73887457900412 34.462 35.66852612684907 139.73886888591858 34.318 35.66852612684907 139.73886888591858 36.157 35.668533578078225 139.73887638842356 36.157 35.668533578078225 139.73887638842356 34.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3090c8ae-1e77-458e-8a61-84bd1bfe7da7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3090c8ae-1e77-458e-8a61-84bd1bfe7da7_0">
											<gml:posList>35.66852612684907 139.73886888591858 34.318 35.66850887667886 139.7388945661026 34.318 35.66850887667886 139.7388945661026 36.157 35.66852612684907 139.73886888591858 36.157 35.66852612684907 139.73886888591858 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cff1d4a-25b7-4086-aaa6-7eb3b999363b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cff1d4a-25b7-4086-aaa6-7eb3b999363b_0">
											<gml:posList>35.66851640893467 139.7389019470069 36.157 35.66850887667886 139.7388945661026 36.157 35.66850887667886 139.7388945661026 34.318 35.6685145236195 139.73890010454485 34.318 35.6685145236195 139.73890010454485 34.462 35.66851639992961 139.7389019580635 34.462 35.66851640893467 139.7389019470069 36.157</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4de2ae9-8c68-4f0a-8e7d-7645cda8dcb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4de2ae9-8c68-4f0a-8e7d-7645cda8dcb0_0">
											<gml:posList>35.66852612684907 139.73886888591858 36.157 35.66850887667886 139.7388945661026 36.157 35.66851640893467 139.7389019470069 36.157 35.668533578078225 139.73887638842356 36.157 35.66852612684907 139.73886888591858 36.157</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e48caffc-7ac9-4e8e-a345-286cfcb7a920">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e48caffc-7ac9-4e8e-a345-286cfcb7a920_0">
											<gml:posList>35.66851640893467 139.7389019470069 36.157 35.66851639992961 139.7389019580635 34.462 35.668533578078225 139.73887638842356 34.462 35.668533578078225 139.73887638842356 36.157 35.66851640893467 139.7389019470069 36.157</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-160ad1b4-f5e0-414e-9c7a-bf5369209aef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-160ad1b4-f5e0-414e-9c7a-bf5369209aef_0">
											<gml:posList>35.66861241903397 139.7389195959291 32.486 35.66861796667518 139.73892494671486 32.486 35.66861796667518 139.73892494671486 34.22 35.66861241903397 139.7389195959291 34.22 35.66861241903397 139.7389195959291 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fda954d5-1188-41a1-b593-9bc991efad09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fda954d5-1188-41a1-b593-9bc991efad09_0">
											<gml:posList>35.66861941418421 139.738908729458 32.486 35.66861241903397 139.7389195959291 32.486 35.66861241903397 139.7389195959291 34.22 35.66861941418421 139.738908729458 34.22 35.66861941418421 139.738908729458 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6f2e81c-bd0d-4549-96a6-e127cd6cc3b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6f2e81c-bd0d-4549-96a6-e127cd6cc3b2_0">
											<gml:posList>35.66861241903397 139.7389195959291 34.22 35.66861796667518 139.73892494671486 34.22 35.66862495282083 139.7389140913001 34.22 35.66861941418421 139.738908729458 34.22 35.66861241903397 139.7389195959291 34.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1294679-d7d1-4ca5-81b4-d95b8f274b90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1294679-d7d1-4ca5-81b4-d95b8f274b90_0">
											<gml:posList>35.66861796667518 139.73892494671486 32.486 35.66862495282083 139.7389140913001 32.486 35.66862495282083 139.7389140913001 34.22 35.66861796667518 139.73892494671486 34.22 35.66861796667518 139.73892494671486 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a68e5ba-a2d3-4cd2-8e34-c0d8243bed13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a68e5ba-a2d3-4cd2-8e34-c0d8243bed13_0">
											<gml:posList>35.66862495282083 139.7389140913001 32.486 35.66861941418421 139.738908729458 32.486 35.66861941418421 139.738908729458 34.22 35.66862495282083 139.7389140913001 34.22 35.66862495282083 139.7389140913001 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7e9e1a3-6ba5-4d62-b96a-8ef0289ba4d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7e9e1a3-6ba5-4d62-b96a-8ef0289ba4d9_0">
											<gml:posList>35.668634735148 139.7389286826178 32.486 35.66862920731082 139.73893709514584 32.486 35.66862920731082 139.73893709514584 34.22 35.668634735148 139.7389286826178 34.22 35.668634735148 139.7389286826178 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c564f98f-8eb6-4707-ac8c-5fbe3f66b6f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c564f98f-8eb6-4707-ac8c-5fbe3f66b6f6_0">
											<gml:posList>35.66862920731082 139.73893709514584 32.486 35.6686348723115 139.73894267776217 32.486 35.6686348723115 139.73894267776217 34.22 35.66862920731082 139.73893709514584 34.22 35.66862920731082 139.73893709514584 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-425cdc7a-8d0d-422a-b5e1-07cf49eaaf89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-425cdc7a-8d0d-422a-b5e1-07cf49eaaf89_0">
											<gml:posList>35.66862920731082 139.73893709514584 34.22 35.6686348723115 139.73894267776217 34.22 35.66864039114398 139.73893427629054 34.22 35.668634735148 139.7389286826178 34.22 35.66862920731082 139.73893709514584 34.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46ee1ef7-bc50-4021-b793-b55ebf4f01ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46ee1ef7-bc50-4021-b793-b55ebf4f01ad_0">
											<gml:posList>35.66864039114398 139.73893427629054 32.486 35.668634735148 139.7389286826178 32.486 35.668634735148 139.7389286826178 34.22 35.66864039114398 139.73893427629054 34.22 35.66864039114398 139.73893427629054 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-494d40c2-188d-4ae3-a242-f6147938a15c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-494d40c2-188d-4ae3-a242-f6147938a15c_0">
											<gml:posList>35.6686348723115 139.73894267776217 32.486 35.66864039114398 139.73893427629054 32.486 35.66864039114398 139.73893427629054 34.22 35.6686348723115 139.73894267776217 34.22 35.6686348723115 139.73894267776217 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-784570db-b385-433f-b39f-b1152377dff6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-784570db-b385-433f-b39f-b1152377dff6_0">
											<gml:posList>35.66865056957908 139.73894823752403 32.486 35.66865635201737 139.73895415138506 32.486 35.66865635201737 139.73895415138506 34.22 35.66865056957908 139.73894823752403 34.22 35.66865056957908 139.73894823752403 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cae3bf3d-5d0e-4b50-8094-bf526668f524">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cae3bf3d-5d0e-4b50-8094-bf526668f524_0">
											<gml:posList>35.668657763267596 139.7389376690591 32.486 35.66865056957908 139.73894823752403 32.486 35.66865056957908 139.73894823752403 34.22 35.668657763267596 139.7389376690591 34.22 35.668657763267596 139.7389376690591 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0b3ec5c-56ef-44f1-8d22-6ce0c06e9f73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0b3ec5c-56ef-44f1-8d22-6ce0c06e9f73_0">
											<gml:posList>35.66865635201737 139.73895415138506 34.22 35.668663554720126 139.7389435829093 34.22 35.668657763267596 139.7389376690591 34.22 35.66865056957908 139.73894823752403 34.22 35.66865635201737 139.73895415138506 34.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3f1f840-1303-48e2-b547-b509cd37f9c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3f1f840-1303-48e2-b547-b509cd37f9c5_0">
											<gml:posList>35.66865635201737 139.73895415138506 32.486 35.668663554720126 139.7389435829093 32.486 35.668663554720126 139.7389435829093 34.22 35.66865635201737 139.73895415138506 34.22 35.66865635201737 139.73895415138506 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-402102e3-0e31-49a8-a218-07b057d106a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-402102e3-0e31-49a8-a218-07b057d106a5_0">
											<gml:posList>35.668663554720126 139.7389435829093 32.486 35.668657763267596 139.7389376690591 32.486 35.668657763267596 139.7389376690591 34.22 35.668663554720126 139.7389435829093 34.22 35.668663554720126 139.7389435829093 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93c0d450-f7a1-45c9-a1bc-4b65f4830ca2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93c0d450-f7a1-45c9-a1bc-4b65f4830ca2_0">
											<gml:posList>35.6686647572826 139.73897135119537 32.486 35.66867053048964 139.7389769889194 32.486 35.66867053048964 139.7389769889194 34.22 35.6686647572826 139.73897135119537 34.22 35.6686647572826 139.73897135119537 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e28dce3-7dff-4552-a17c-ebd1d57a90c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e28dce3-7dff-4552-a17c-ebd1d57a90c0_0">
											<gml:posList>35.668675020541116 139.7389555322563 32.486 35.6686647572826 139.73897135119537 32.486 35.6686647572826 139.73897135119537 34.22 35.668675020541116 139.7389555322563 34.22 35.668675020541116 139.7389555322563 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da7ecf71-5d22-4d9e-8b21-db16f9b21c91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da7ecf71-5d22-4d9e-8b21-db16f9b21c91_0">
											<gml:posList>35.6686647572826 139.73897135119537 34.22 35.66867053048964 139.7389769889194 34.22 35.66868079374022 139.73896115893388 34.22 35.668675020541116 139.7389555322563 34.22 35.6686647572826 139.73897135119537 34.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ab3e664-fe89-4787-adcf-32dc017e12aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ab3e664-fe89-4787-adcf-32dc017e12aa_0">
											<gml:posList>35.66867053048964 139.7389769889194 32.486 35.66868079374022 139.73896115893388 32.486 35.66868079374022 139.73896115893388 34.22 35.66867053048964 139.7389769889194 34.22 35.66867053048964 139.7389769889194 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05914a16-de9b-4bfa-b88d-269de598d9a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05914a16-de9b-4bfa-b88d-269de598d9a0_0">
											<gml:posList>35.66868079374022 139.73896115893388 32.486 35.668675020541116 139.7389555322563 32.486 35.668675020541116 139.7389555322563 34.22 35.66868079374022 139.73896115893388 34.22 35.66868079374022 139.73896115893388 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04df0a5c-f207-43f1-ab77-e8bab303b004">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04df0a5c-f207-43f1-ab77-e8bab303b004_0">
											<gml:posList>35.668681969863286 139.7389897004791 32.486 35.66868782405451 139.7389951613739 32.486 35.66868782405451 139.7389951613739 34.22 35.668681969863286 139.7389897004791 34.22 35.668681969863286 139.7389897004791 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0ebbc65-f9b6-431e-b450-2b0385f2499a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0ebbc65-f9b6-431e-b450-2b0385f2499a_0">
											<gml:posList>35.66868932480708 139.73897786153094 32.486 35.668681969863286 139.7389897004791 32.486 35.668681969863286 139.7389897004791 34.22 35.66868932480708 139.73897786153094 34.22 35.66868932480708 139.73897786153094 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3237c276-81a6-49bf-90ee-e5d5f7e2d19a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3237c276-81a6-49bf-90ee-e5d5f7e2d19a_0">
											<gml:posList>35.66868782405451 139.7389951613739 34.22 35.668695179007486 139.73898333347145 34.22 35.66868932480708 139.73897786153094 34.22 35.668681969863286 139.7389897004791 34.22 35.66868782405451 139.7389951613739 34.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33cf0bd2-4b5f-45f5-83a7-6c70a6602e74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33cf0bd2-4b5f-45f5-83a7-6c70a6602e74_0">
											<gml:posList>35.66868782405451 139.7389951613739 32.486 35.668695179007486 139.73898333347145 32.486 35.668695179007486 139.73898333347145 34.22 35.66868782405451 139.7389951613739 34.22 35.66868782405451 139.7389951613739 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25ffeb8f-c53c-46a4-948c-c89529bb4918">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25ffeb8f-c53c-46a4-948c-c89529bb4918_0">
											<gml:posList>35.668695179007486 139.73898333347145 32.486 35.66868932480708 139.73897786153094 32.486 35.66868932480708 139.73897786153094 34.22 35.668695179007486 139.73898333347145 34.22 35.668695179007486 139.73898333347145 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8b8b4d84-1e94-4c36-8d8a-f39d67b58f73_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa120ed6-f68e-47a1-a623-bb6e9b6ad32e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862154739961 139.73885888731718 32.486 35.66862242070829 139.7388575828582 32.486 35.66860892549793 139.73884399006818 32.486 35.66862361873292 139.7388221016391 32.486 35.66863710494065 139.73883570548452 32.486 35.66863963484134 139.7388319358103 32.486 35.66864898046313 139.73884135809755 32.486 35.668630893010665 139.73886829855942 32.486 35.66862154739961 139.73885888731718 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35342463-c653-460a-a4f6-711da7f57182">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858168599432 139.73886696473377 32.486 35.668563003758855 139.7388481091147 32.486 35.668578768396934 139.73882465090256 32.486 35.66859745062735 139.73884349547382 32.486 35.66858168599432 139.73886696473377 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8de899f7-1668-45be-bbfe-630e22192316">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868053891251 139.73888906182776 32.486 35.6686722921471 139.73890157564048 32.486 35.66864398507255 139.73887355208694 32.486 35.66865223183508 139.73886103827576 32.486 35.66868053891251 139.73888906182776 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d15fb5a3-e67f-4bc2-b3e6-596982d4591f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858178103635 139.73891919016427 32.486 35.66860237939643 139.73888723188247 32.486 35.668611932139044 139.7388964109155 32.486 35.66859105465419 139.73892875613785 32.486 35.66858178103635 139.73891919016427 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52101d18-40e1-4b2f-8d71-a50a64621204">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52101d18-40e1-4b2f-8d71-a50a64621204_0">
											<gml:posList>35.66863710494065 139.73883570548452 33.921 35.66863710494065 139.73883570548452 32.486 35.66862361873292 139.7388221016391 32.486 35.66862361873292 139.7388221016391 34.673 35.66863710494065 139.73883570548452 34.673 35.66863710494065 139.73883570548452 33.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f1d0c58-c33d-49dc-ba89-9dbe2a9121f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f1d0c58-c33d-49dc-ba89-9dbe2a9121f4_0">
											<gml:posList>35.66862361873292 139.7388221016391 32.486 35.66860892549793 139.73884399006818 32.486 35.66860892549793 139.73884399006818 34.673 35.66862361873292 139.7388221016391 34.673 35.66862361873292 139.7388221016391 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34c40fde-b393-4fb0-87fd-9d3241184110">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34c40fde-b393-4fb0-87fd-9d3241184110_0">
											<gml:posList>35.66863963484134 139.7388319358103 32.486 35.66863710494065 139.73883570548452 32.486 35.66863710494065 139.73883570548452 33.921 35.66863963484134 139.7388319358103 33.921 35.66863963484134 139.7388319358103 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4af550a6-1ede-4579-b978-78024e8639c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4af550a6-1ede-4579-b978-78024e8639c1_0">
											<gml:posList>35.66859745062735 139.73884349547382 32.486 35.668578768396934 139.73882465090256 32.486 35.668578768396934 139.73882465090256 34.725 35.66859745062735 139.73884349547382 34.725 35.66859745062735 139.73884349547382 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a378e023-cefd-4cec-97f7-2e9a998069fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a378e023-cefd-4cec-97f7-2e9a998069fe_0">
											<gml:posList>35.668563003758855 139.7388481091147 32.486 35.668563003758855 139.7388481091147 34.725 35.668578768396934 139.73882465090256 34.725 35.668578768396934 139.73882465090256 32.486 35.668563003758855 139.7388481091147 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20692376-06fc-49c7-9a62-d51b4275d459">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20692376-06fc-49c7-9a62-d51b4275d459_0">
											<gml:posList>35.66864898046313 139.73884135809755 32.486 35.66863963484134 139.7388319358103 32.486 35.66863963484134 139.7388319358103 33.921 35.66864898046313 139.73884135809755 33.921 35.66864898046313 139.73884135809755 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b2f206c-8b21-423e-9366-2aa4af255654">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b2f206c-8b21-423e-9366-2aa4af255654_0">
											<gml:posList>35.66862361873292 139.7388221016391 34.673 35.66860892549793 139.73884399006818 34.673 35.66862242070829 139.7388575828582 34.673 35.66863710494065 139.73883570548452 34.673 35.66862361873292 139.7388221016391 34.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d5a50e8-24fe-4e99-ad64-bbb466ed9425">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d5a50e8-24fe-4e99-ad64-bbb466ed9425_0">
											<gml:posList>35.66858168599432 139.73886696473377 34.725 35.66859745062735 139.73884349547382 34.725 35.668578768396934 139.73882465090256 34.725 35.668563003758855 139.7388481091147 34.725 35.66858168599432 139.73886696473377 34.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d137ab4-3804-4c3d-96c9-bff7395b01b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d137ab4-3804-4c3d-96c9-bff7395b01b0_0">
											<gml:posList>35.66863710494065 139.73883570548452 33.921 35.66863710494065 139.73883570548452 34.673 35.66862242070829 139.7388575828582 34.673 35.66862242070829 139.7388575828582 33.921 35.66863710494065 139.73883570548452 33.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51a1aee0-2399-4c01-9c1d-811ae09d0d90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51a1aee0-2399-4c01-9c1d-811ae09d0d90_0">
											<gml:posList>35.66864898046313 139.73884135809755 33.921 35.66863963484134 139.7388319358103 33.921 35.66863710494065 139.73883570548452 33.921 35.66862242070829 139.7388575828582 33.921 35.66862154739961 139.73885888731718 33.921 35.668630893010665 139.73886829855942 33.921 35.66864898046313 139.73884135809755 33.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6aca8aec-611f-4e2f-bcc7-f1cc4e165d6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6aca8aec-611f-4e2f-bcc7-f1cc4e165d6b_0">
											<gml:posList>35.66860892549793 139.73884399006818 34.673 35.66860892549793 139.73884399006818 32.486 35.66862242070829 139.7388575828582 32.486 35.66862242070829 139.7388575828582 33.921 35.66862242070829 139.7388575828582 34.673 35.66860892549793 139.73884399006818 34.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14282f6e-99c8-473b-b670-e16347ab2ed1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14282f6e-99c8-473b-b670-e16347ab2ed1_0">
											<gml:posList>35.66864898046313 139.73884135809755 32.486 35.66864898046313 139.73884135809755 33.921 35.668630893010665 139.73886829855942 33.921 35.668630893010665 139.73886829855942 32.486 35.66864898046313 139.73884135809755 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78a79597-7fd9-4a5d-9fca-f044de2c90ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78a79597-7fd9-4a5d-9fca-f044de2c90ef_0">
											<gml:posList>35.66859745062735 139.73884349547382 32.486 35.66859745062735 139.73884349547382 34.725 35.66858168599432 139.73886696473377 34.725 35.66858168599432 139.73886696473377 32.486 35.66859745062735 139.73884349547382 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e9164f5-0bfb-40b9-bdef-8f7af21c8c86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e9164f5-0bfb-40b9-bdef-8f7af21c8c86_0">
											<gml:posList>35.66858168599432 139.73886696473377 32.486 35.66858168599432 139.73886696473377 34.725 35.668563003758855 139.7388481091147 34.725 35.668563003758855 139.7388481091147 32.486 35.66858168599432 139.73886696473377 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-826736b1-8106-4c64-b20c-e0a7ea31e51f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-826736b1-8106-4c64-b20c-e0a7ea31e51f_0">
											<gml:posList>35.66862242070829 139.7388575828582 32.486 35.66862154739961 139.73885888731718 32.486 35.66862154739961 139.73885888731718 33.921 35.66862242070829 139.7388575828582 33.921 35.66862242070829 139.7388575828582 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c3ff3eb-8f4d-42f0-98ed-c92b8620eb02">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c3ff3eb-8f4d-42f0-98ed-c92b8620eb02_0">
											<gml:posList>35.66862154739961 139.73885888731718 32.486 35.668630893010665 139.73886829855942 32.486 35.668630893010665 139.73886829855942 33.921 35.66862154739961 139.73885888731718 33.921 35.66862154739961 139.73885888731718 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91c01976-6c5d-40fd-8977-4e1cab597d7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91c01976-6c5d-40fd-8977-4e1cab597d7a_0">
											<gml:posList>35.66865223183508 139.73886103827576 32.486 35.66864398507255 139.73887355208694 32.486 35.66864398507255 139.73887355208694 35.201 35.66865223183508 139.73886103827576 35.201 35.66865223183508 139.73886103827576 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-479b123e-cb9e-45ec-b90d-01d809a4e6c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-479b123e-cb9e-45ec-b90d-01d809a4e6c2_0">
											<gml:posList>35.66865223183508 139.73886103827576 35.201 35.66868053891251 139.73888906182776 35.201 35.66868053891251 139.73888906182776 32.486 35.66865223183508 139.73886103827576 32.486 35.66865223183508 139.73886103827576 35.201</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d675c462-e431-4e6e-aa9c-457ff268a8dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d675c462-e431-4e6e-aa9c-457ff268a8dc_0">
											<gml:posList>35.66864398507255 139.73887355208694 35.201 35.6686722921471 139.73890157564048 35.201 35.66868053891251 139.73888906182776 35.201 35.66865223183508 139.73886103827576 35.201 35.66864398507255 139.73887355208694 35.201</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6cc951d7-f197-49af-bad4-d0f8edc381e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6cc951d7-f197-49af-bad4-d0f8edc381e0_0">
											<gml:posList>35.66864398507255 139.73887355208694 32.486 35.6686722921471 139.73890157564048 32.486 35.6686722921471 139.73890157564048 35.201 35.66864398507255 139.73887355208694 35.201 35.66864398507255 139.73887355208694 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e549653-66f4-4f59-a511-929ff25b47a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e549653-66f4-4f59-a511-929ff25b47a8_0">
											<gml:posList>35.66860237939643 139.73888723188247 32.486 35.66860237939643 139.73888723188247 33.877 35.668611932139044 139.7388964109155 33.877 35.668611932139044 139.7388964109155 32.486 35.66860237939643 139.73888723188247 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04e7823a-0d09-4d2a-812b-9480a1c36f5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04e7823a-0d09-4d2a-812b-9480a1c36f5c_0">
											<gml:posList>35.6686722921471 139.73890157564048 32.486 35.66868053891251 139.73888906182776 32.486 35.66868053891251 139.73888906182776 35.201 35.6686722921471 139.73890157564048 35.201 35.6686722921471 139.73890157564048 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8f1519c-5c5f-434e-bc14-d95aedf6f863">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8f1519c-5c5f-434e-bc14-d95aedf6f863_0">
											<gml:posList>35.66858178103635 139.73891919016427 33.877 35.66860237939643 139.73888723188247 33.877 35.66860237939643 139.73888723188247 32.486 35.66858178103635 139.73891919016427 32.486 35.66858178103635 139.73891919016427 33.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32c8bb56-58b6-41a1-a516-b9d8be9b476e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32c8bb56-58b6-41a1-a516-b9d8be9b476e_0">
											<gml:posList>35.66858178103635 139.73891919016427 33.877 35.66859105465419 139.73892875613785 33.877 35.668611932139044 139.7388964109155 33.877 35.66860237939643 139.73888723188247 33.877 35.66858178103635 139.73891919016427 33.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7209331c-6eb0-4069-9792-f9360e0b5bdd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7209331c-6eb0-4069-9792-f9360e0b5bdd_0">
											<gml:posList>35.66859105465419 139.73892875613785 32.486 35.668611932139044 139.7388964109155 32.486 35.668611932139044 139.7388964109155 33.877 35.66859105465419 139.73892875613785 33.877 35.66859105465419 139.73892875613785 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c05ae6ac-c652-459a-8801-0ac00f52df75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c05ae6ac-c652-459a-8801-0ac00f52df75_0">
											<gml:posList>35.66859105465419 139.73892875613785 33.877 35.66858178103635 139.73891919016427 33.877 35.66858178103635 139.73891919016427 32.486 35.66859105465419 139.73892875613785 32.486 35.66859105465419 139.73892875613785 33.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8b8b4d84-1e94-4c36-8d8a-f39d67b58f73_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e479c656-5f4e-42eb-a09b-66f73915b2c1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848830986113 139.73894376711198 12.7 35.66851640893467 139.7389019470069 12.7 35.66853436040057 139.73891997503765 12.7 35.66851630860402 139.73894642937717 12.7 35.66850476168432 139.73893451328854 12.7 35.668494227661505 139.7389498796294 12.7 35.66848830986113 139.73894376711198 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73cc4470-2de6-4564-99fe-fbf3750d0b6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73cc4470-2de6-4564-99fe-fbf3750d0b6b_0">
											<gml:posList>35.66848830986113 139.73894376711198 12.7 35.668494227661505 139.7389498796294 12.7 35.668494227661505 139.7389498796294 33.622 35.66848830986113 139.73894376711198 33.622 35.66848830986113 139.73894376711198 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34d8f2f1-5897-43bd-8624-07c8afb0978a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34d8f2f1-5897-43bd-8624-07c8afb0978a_0">
											<gml:posList>35.668494227661505 139.7389498796294 12.7 35.66850476168432 139.73893451328854 12.7 35.66850476168432 139.73893451328854 33.622 35.668494227661505 139.7389498796294 33.622 35.668494227661505 139.7389498796294 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81432a2a-7b67-4006-b204-0fe003dd69d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81432a2a-7b67-4006-b204-0fe003dd69d5_0">
											<gml:posList>35.66851640893467 139.7389019470069 12.7 35.66848830986113 139.73894376711198 12.7 35.66848830986113 139.73894376711198 33.622 35.66851640893467 139.7389019470069 33.622 35.66851640893467 139.7389019470069 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13ea605a-ad0c-4346-87e3-b1e52ff86a63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13ea605a-ad0c-4346-87e3-b1e52ff86a63_0">
											<gml:posList>35.66850476168432 139.73893451328854 12.7 35.66851630860402 139.73894642937717 12.7 35.66851630860402 139.73894642937717 33.622 35.66850476168432 139.73893451328854 33.622 35.66850476168432 139.73893451328854 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c6584b8-8f69-43f1-a18b-090136ea28ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c6584b8-8f69-43f1-a18b-090136ea28ca_0">
											<gml:posList>35.66850476168432 139.73893451328854 33.622 35.66851630860402 139.73894642937717 33.622 35.66853436040057 139.73891997503765 33.622 35.66851640893467 139.7389019470069 33.622 35.66848830986113 139.73894376711198 33.622 35.668494227661505 139.7389498796294 33.622 35.66850476168432 139.73893451328854 33.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e53ae5d4-7fb6-4d1f-b758-a35580661d14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e53ae5d4-7fb6-4d1f-b758-a35580661d14_0">
											<gml:posList>35.66851630860402 139.73894642937717 12.7 35.66853436040057 139.73891997503765 12.7 35.66853436040057 139.73891997503765 33.622 35.66851630860402 139.73894642937717 33.622 35.66851630860402 139.73894642937717 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26170126-bfc6-4552-8dd7-14e984d061ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26170126-bfc6-4552-8dd7-14e984d061ea_0">
											<gml:posList>35.66851640893467 139.7389019470069 12.7 35.66851640893467 139.7389019470069 33.622 35.66853436040057 139.73891997503765 33.622 35.66853436040057 139.73891997503765 12.7 35.66851640893467 139.7389019470069 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-30074343-bab6-480e-bac4-3dd615e7470a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30074343-bab6-480e-bac4-3dd615e7470a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30074343-bab6-480e-bac4-3dd615e7470a">
											<gml:posList>35.66859355669688 139.7388320122089 12.7 35.66862461841044 139.73878657646878 12.7 35.66875704649219 139.73892228655552 12.7 35.66870934646688 139.73899212048593 12.7 35.66872861528971 139.7390118923035 12.7 35.66870889782017 139.73904075667969 12.7 35.66868962901067 139.73902099590606 12.7 35.66868402888429 139.73902918759802 12.7 35.66855214209137 139.73889391866064 12.7 35.668534360409225 139.73891998608363 12.7 35.66851640893467 139.7389019470069 12.7 35.66848830986113 139.73894376711198 12.7 35.66848096674887 139.73893619820174 12.7 35.66848888982083 139.73892470103544 12.7 35.66841491775427 139.73884890218972 12.7 35.66849531795624 139.7387311675538 12.7 35.66859355669688 139.7388320122089 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b2910f23-2b1a-4690-b6c8-c95270c3bd48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2910f23-2b1a-4690-b6c8-c95270c3bd48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2910f23-2b1a-4690-b6c8-c95270c3bd48">
											<gml:posList>35.66848888982083 139.73892470103544 34.462 35.6684904294011 139.73892244583897 34.462 35.66841828860148 139.7388485337 34.462 35.66841491775427 139.73884890218972 34.462 35.66848888982083 139.73892470103544 34.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c36d3db5-c2bb-45fb-9a42-9615bfa33397">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c36d3db5-c2bb-45fb-9a42-9615bfa33397">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c36d3db5-c2bb-45fb-9a42-9615bfa33397">
											<gml:posList>35.66841491775427 139.73884890218972 34.462 35.66841828860148 139.7388485337 34.462 35.66849561864602 139.7387352873569 34.462 35.66849531795624 139.7387311675538 34.462 35.66841491775427 139.73884890218972 34.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cac2ec24-b0bb-4acb-a5a9-aa2ee134441b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cac2ec24-b0bb-4acb-a5a9-aa2ee134441b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cac2ec24-b0bb-4acb-a5a9-aa2ee134441b">
											<gml:posList>35.66848096674887 139.73893619820174 34.462 35.66848830986113 139.73894376711198 34.462 35.66849614267532 139.73893211540766 34.462 35.66848888982083 139.73892470103544 34.462 35.66848096674887 139.73893619820174 34.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0daac21d-cadb-4429-bb48-1b8852132a63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0daac21d-cadb-4429-bb48-1b8852132a63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0daac21d-cadb-4429-bb48-1b8852132a63">
											<gml:posList>35.66848888982083 139.73892470103544 34.462 35.66849614267532 139.73893211540766 34.462 35.668495823947524 139.738927973533 34.462 35.6684904294011 139.73892244583897 34.462 35.66848888982083 139.73892470103544 34.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ebd02b6c-6a69-4313-b2cb-142f485a644e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebd02b6c-6a69-4313-b2cb-142f485a644e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebd02b6c-6a69-4313-b2cb-142f485a644e">
											<gml:posList>35.6684904294011 139.73892244583897 34.318 35.668495823947524 139.738927973533 34.318 35.66857236033769 139.7388140653317 34.318 35.66849561864602 139.7387352873569 34.318 35.66841828860148 139.7388485337 34.318 35.6684904294011 139.73892244583897 34.318</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e95eedea-8fea-4052-8d10-638145191a43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e95eedea-8fea-4052-8d10-638145191a43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e95eedea-8fea-4052-8d10-638145191a43">
											<gml:posList>35.66853394156864 139.73891461821842 33.622 35.668518398646356 139.73889898433487 33.622 35.66851640893467 139.7389019470069 33.622 35.668534360409225 139.73891998608363 33.622 35.66853394156864 139.73891461821842 33.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8f4c2b3-3ed4-46a1-a42d-285482e84035">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8f4c2b3-3ed4-46a1-a42d-285482e84035">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8f4c2b3-3ed4-46a1-a42d-285482e84035">
											<gml:posList>35.66849531795624 139.7387311675538 34.462 35.66849561864602 139.7387352873569 34.462 35.66857236033769 139.7388140653317 34.462 35.66857570413487 139.7388136858257 34.462 35.66849531795624 139.7387311675538 34.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1dc628be-6372-491e-bea4-bb26400f9e49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1dc628be-6372-491e-bea4-bb26400f9e49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1dc628be-6372-491e-bea4-bb26400f9e49">
											<gml:posList>35.66857570413487 139.7388136858257 34.462 35.66857236033769 139.7388140653317 34.462 35.668495823947524 139.738927973533 34.462 35.66849614267532 139.73893211540766 34.462 35.66857570413487 139.7388136858257 34.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3fe1e76b-248e-47cd-aa77-fda7963f8f72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fe1e76b-248e-47cd-aa77-fda7963f8f72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fe1e76b-248e-47cd-aa77-fda7963f8f72">
											<gml:posList>35.66855214209137 139.73889391866064 33.622 35.66855175025614 139.73888850657852 33.622 35.66853394156864 139.73891461821842 33.622 35.668534360409225 139.73891998608363 33.622 35.66855214209137 139.73889391866064 33.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4cb7a9b5-9eb4-4373-ba75-49ef8b0baf9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cb7a9b5-9eb4-4373-ba75-49ef8b0baf9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cb7a9b5-9eb4-4373-ba75-49ef8b0baf9a">
											<gml:posList>35.66859355669688 139.7388320122089 33.622 35.66857570413487 139.7388136858257 33.622 35.66857369641519 139.7388166706152 33.622 35.66859394853465 139.73883742429354 33.622 35.66859355669688 139.7388320122089 33.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-786d30ba-62c1-4fc0-a9ea-2c9bc1a2e3ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-786d30ba-62c1-4fc0-a9ea-2c9bc1a2e3ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-786d30ba-62c1-4fc0-a9ea-2c9bc1a2e3ca">
											<gml:posList>35.66859355669688 139.7388320122089 33.622 35.66859394853465 139.73883742429354 33.622 35.66862500123654 139.73879198856594 33.622 35.66862461841044 139.73878657646878 33.622 35.66859355669688 139.7388320122089 33.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-84470677-d0f2-4b5f-904c-4435dd3e709d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84470677-d0f2-4b5f-904c-4435dd3e709d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84470677-d0f2-4b5f-904c-4435dd3e709d">
											<gml:posList>35.66855214209137 139.73889391866064 33.622 35.66868402888429 139.73902918759802 33.622 35.66868362804141 139.73902377551693 33.622 35.66855175025614 139.73888850657852 33.622 35.66855214209137 139.73889391866064 33.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c4ddce1-6683-4e6e-98b4-c9524a86fa25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c4ddce1-6683-4e6e-98b4-c9524a86fa25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c4ddce1-6683-4e6e-98b4-c9524a86fa25">
											<gml:posList>35.66855175025614 139.73888850657852 32.486 35.66868362804141 139.73902377551693 32.486 35.668752630139466 139.7389227667351 32.486 35.66862500123654 139.73879198856594 32.486 35.66859394853465 139.73883742429354 32.486 35.66857369641519 139.7388166706152 32.486 35.668518398646356 139.73889898433487 32.486 35.66853394156864 139.73891461821842 32.486 35.66855175025614 139.73888850657852 32.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d68416a4-2910-4ca1-8dc4-f91e8fa270fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d68416a4-2910-4ca1-8dc4-f91e8fa270fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d68416a4-2910-4ca1-8dc4-f91e8fa270fd">
											<gml:posList>35.66862461841044 139.73878657646878 33.622 35.66862500123654 139.73879198856594 33.622 35.668752630139466 139.7389227667351 33.622 35.66875704649219 139.73892228655552 33.622 35.66862461841044 139.73878657646878 33.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-55ce9bd9-bb3d-49bc-8a45-ac31168eb137">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55ce9bd9-bb3d-49bc-8a45-ac31168eb137">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55ce9bd9-bb3d-49bc-8a45-ac31168eb137">
											<gml:posList>35.66868962901067 139.73902099590606 16.513 35.66870889782017 139.73904075667969 16.513 35.66872861528971 139.7390118923035 16.513 35.66870934646688 139.73899212048593 16.513 35.66868962901067 139.73902099590606 16.513</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-48cf3596-0855-40ab-8c20-97301558f6aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48cf3596-0855-40ab-8c20-97301558f6aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48cf3596-0855-40ab-8c20-97301558f6aa">
											<gml:posList>35.66875704649219 139.73892228655552 33.622 35.668752630139466 139.7389227667351 33.622 35.66868362804141 139.73902377551693 33.622 35.66868402888429 139.73902918759802 33.622 35.66875704649219 139.73892228655552 33.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0abdb268-8061-4252-a380-aad55f8d3a87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0abdb268-8061-4252-a380-aad55f8d3a87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0abdb268-8061-4252-a380-aad55f8d3a87">
											<gml:posList>35.66841828860148 139.7388485337 34.462 35.66841828860148 139.7388485337 34.318 35.66849561864602 139.7387352873569 34.318 35.66849561864602 139.7387352873569 34.462 35.66841828860148 139.7388485337 34.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7cbe541-93f5-448a-a12d-7b5c5f1b5262">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7cbe541-93f5-448a-a12d-7b5c5f1b5262">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7cbe541-93f5-448a-a12d-7b5c5f1b5262">
											<gml:posList>35.66862500123654 139.73879198856594 33.622 35.66862500123654 139.73879198856594 32.486 35.668752630139466 139.7389227667351 32.486 35.668752630139466 139.7389227667351 33.622 35.66862500123654 139.73879198856594 33.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-958f960e-dd28-4044-9590-1859a6803122">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-958f960e-dd28-4044-9590-1859a6803122">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-958f960e-dd28-4044-9590-1859a6803122">
											<gml:posList>35.66857236033769 139.7388140653317 34.462 35.66857236033769 139.7388140653317 34.318 35.668495823947524 139.738927973533 34.318 35.668495823947524 139.738927973533 34.462 35.66857236033769 139.7388140653317 34.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85db3faa-6b02-4a3d-9a18-fe1fd075a0e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85db3faa-6b02-4a3d-9a18-fe1fd075a0e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85db3faa-6b02-4a3d-9a18-fe1fd075a0e8">
											<gml:posList>35.66841491775427 139.73884890218972 12.7 35.66848888982083 139.73892470103544 12.7 35.66848888982083 139.73892470103544 34.462 35.66841491775427 139.73884890218972 34.462 35.66841491775427 139.73884890218972 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47ddab44-7c3e-4979-b9c1-255a4d37130a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47ddab44-7c3e-4979-b9c1-255a4d37130a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47ddab44-7c3e-4979-b9c1-255a4d37130a">
											<gml:posList>35.6684904294011 139.73892244583897 34.462 35.6684904294011 139.73892244583897 34.318 35.66841828860148 139.7388485337 34.318 35.66841828860148 139.7388485337 34.462 35.6684904294011 139.73892244583897 34.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51ff5c33-0063-4652-8105-d3cf7d2cd0db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51ff5c33-0063-4652-8105-d3cf7d2cd0db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51ff5c33-0063-4652-8105-d3cf7d2cd0db">
											<gml:posList>35.66849531795624 139.7387311675538 12.7 35.66841491775427 139.73884890218972 12.7 35.66841491775427 139.73884890218972 34.462 35.66849531795624 139.7387311675538 34.462 35.66849531795624 139.7387311675538 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9821427e-8f7a-4f37-87fb-c269257e7ef7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9821427e-8f7a-4f37-87fb-c269257e7ef7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9821427e-8f7a-4f37-87fb-c269257e7ef7">
											<gml:posList>35.66848096674887 139.73893619820174 12.7 35.66848830986113 139.73894376711198 12.7 35.66848830986113 139.73894376711198 34.462 35.66848096674887 139.73893619820174 34.462 35.66848096674887 139.73893619820174 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40fb2dcc-da65-485a-800b-89910bb6ec28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40fb2dcc-da65-485a-800b-89910bb6ec28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40fb2dcc-da65-485a-800b-89910bb6ec28">
											<gml:posList>35.66848888982083 139.73892470103544 12.7 35.66848096674887 139.73893619820174 12.7 35.66848096674887 139.73893619820174 34.462 35.66848888982083 139.73892470103544 34.462 35.66848888982083 139.73892470103544 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73295802-1601-4772-8893-5a8c470deab9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73295802-1601-4772-8893-5a8c470deab9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73295802-1601-4772-8893-5a8c470deab9">
											<gml:posList>35.668495823947524 139.738927973533 34.462 35.668495823947524 139.738927973533 34.318 35.6684904294011 139.73892244583897 34.318 35.6684904294011 139.73892244583897 34.462 35.668495823947524 139.738927973533 34.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44e474e0-0daa-4aea-ad60-ea4b893430e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44e474e0-0daa-4aea-ad60-ea4b893430e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44e474e0-0daa-4aea-ad60-ea4b893430e6">
											<gml:posList>35.66849561864602 139.7387352873569 34.462 35.66849561864602 139.7387352873569 34.318 35.66857236033769 139.7388140653317 34.318 35.66857236033769 139.7388140653317 34.462 35.66849561864602 139.7387352873569 34.462</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d72481f-5630-4d4a-b621-54cdc85e0e74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d72481f-5630-4d4a-b621-54cdc85e0e74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d72481f-5630-4d4a-b621-54cdc85e0e74">
											<gml:posList>35.66849531795624 139.7387311675538 12.7 35.66849531795624 139.7387311675538 34.462 35.66857570413487 139.7388136858257 34.462 35.66857570413487 139.7388136858257 33.622 35.66859355669688 139.7388320122089 33.622 35.66859355669688 139.7388320122089 12.7 35.66849531795624 139.7387311675538 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dba105da-7cea-4594-afd5-a7a51cb6908a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dba105da-7cea-4594-afd5-a7a51cb6908a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dba105da-7cea-4594-afd5-a7a51cb6908a">
											<gml:posList>35.66862461841044 139.73878657646878 12.7 35.66859355669688 139.7388320122089 12.7 35.66859355669688 139.7388320122089 33.622 35.66862461841044 139.73878657646878 33.622 35.66862461841044 139.73878657646878 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ecb1fce-f29a-4d66-a880-13f0b1a6553f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ecb1fce-f29a-4d66-a880-13f0b1a6553f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ecb1fce-f29a-4d66-a880-13f0b1a6553f">
											<gml:posList>35.66859394853465 139.73883742429354 33.622 35.66859394853465 139.73883742429354 32.486 35.66862500123654 139.73879198856594 32.486 35.66862500123654 139.73879198856594 33.622 35.66859394853465 139.73883742429354 33.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17c2b642-5696-4929-957f-e9c24c46d821">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17c2b642-5696-4929-957f-e9c24c46d821">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17c2b642-5696-4929-957f-e9c24c46d821">
											<gml:posList>35.66857369641519 139.7388166706152 33.622 35.66857369641519 139.7388166706152 32.486 35.66859394853465 139.73883742429354 32.486 35.66859394853465 139.73883742429354 33.622 35.66857369641519 139.7388166706152 33.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-beb2d4f4-102b-434a-ba43-ba0806227386">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-beb2d4f4-102b-434a-ba43-ba0806227386">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-beb2d4f4-102b-434a-ba43-ba0806227386">
											<gml:posList>35.66875704649219 139.73892228655552 12.7 35.66862461841044 139.73878657646878 12.7 35.66862461841044 139.73878657646878 33.622 35.66875704649219 139.73892228655552 33.622 35.66875704649219 139.73892228655552 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-483cb41e-1b3a-487e-8a75-09828abe4457">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-483cb41e-1b3a-487e-8a75-09828abe4457">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-483cb41e-1b3a-487e-8a75-09828abe4457">
											<gml:posList>35.66857369641519 139.7388166706152 33.622 35.66857570413487 139.7388136858257 33.622 35.66857570413487 139.7388136858257 34.462 35.66849614267532 139.73893211540766 34.462 35.66848830986113 139.73894376711198 34.462 35.66848830986113 139.73894376711198 12.7 35.66851640893467 139.7389019470069 12.7 35.66851640893467 139.7389019470069 33.622 35.668518398646356 139.73889898433487 33.622 35.668518398646356 139.73889898433487 32.486 35.66857369641519 139.7388166706152 32.486 35.66857369641519 139.7388166706152 33.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71f1c8d4-8171-422d-957f-fff37a151258">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71f1c8d4-8171-422d-957f-fff37a151258">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71f1c8d4-8171-422d-957f-fff37a151258">
											<gml:posList>35.66855175025614 139.73888850657852 33.622 35.66855175025614 139.73888850657852 32.486 35.66853394156864 139.73891461821842 32.486 35.66853394156864 139.73891461821842 33.622 35.66855175025614 139.73888850657852 33.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-749cffaa-5b7d-4d2c-9005-2ad218b4c7a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-749cffaa-5b7d-4d2c-9005-2ad218b4c7a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-749cffaa-5b7d-4d2c-9005-2ad218b4c7a1">
											<gml:posList>35.66853394156864 139.73891461821842 33.622 35.66853394156864 139.73891461821842 32.486 35.668518398646356 139.73889898433487 32.486 35.668518398646356 139.73889898433487 33.622 35.66853394156864 139.73891461821842 33.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee8b9997-4a6a-4bf9-8028-c4c89fdecd82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee8b9997-4a6a-4bf9-8028-c4c89fdecd82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee8b9997-4a6a-4bf9-8028-c4c89fdecd82">
											<gml:posList>35.668534360409225 139.73891998608363 12.7 35.66855214209137 139.73889391866064 12.7 35.66855214209137 139.73889391866064 33.622 35.668534360409225 139.73891998608363 33.622 35.668534360409225 139.73891998608363 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76c832a2-75dc-49db-8d5d-347774459df8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76c832a2-75dc-49db-8d5d-347774459df8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76c832a2-75dc-49db-8d5d-347774459df8">
											<gml:posList>35.66851640893467 139.7389019470069 12.7 35.668534360409225 139.73891998608363 12.7 35.668534360409225 139.73891998608363 33.622 35.66851640893467 139.7389019470069 33.622 35.66851640893467 139.7389019470069 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66f59e91-e7d3-4c27-8490-97a4f199e54d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66f59e91-e7d3-4c27-8490-97a4f199e54d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66f59e91-e7d3-4c27-8490-97a4f199e54d">
											<gml:posList>35.66868362804141 139.73902377551693 33.622 35.66868362804141 139.73902377551693 32.486 35.66855175025614 139.73888850657852 32.486 35.66855175025614 139.73888850657852 33.622 35.66868362804141 139.73902377551693 33.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5e90919-e118-4102-868e-3471b89de5b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5e90919-e118-4102-868e-3471b89de5b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5e90919-e118-4102-868e-3471b89de5b3">
											<gml:posList>35.66855214209137 139.73889391866064 12.7 35.66868402888429 139.73902918759802 12.7 35.66868402888429 139.73902918759802 33.622 35.66855214209137 139.73889391866064 33.622 35.66855214209137 139.73889391866064 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6151691d-569b-4cef-8acb-c5e892435a76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6151691d-569b-4cef-8acb-c5e892435a76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6151691d-569b-4cef-8acb-c5e892435a76">
											<gml:posList>35.668752630139466 139.7389227667351 33.622 35.668752630139466 139.7389227667351 32.486 35.66868362804141 139.73902377551693 32.486 35.66868362804141 139.73902377551693 33.622 35.668752630139466 139.7389227667351 33.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d15bd3ce-e9c2-46e8-9a56-446e1f681ea3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d15bd3ce-e9c2-46e8-9a56-446e1f681ea3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d15bd3ce-e9c2-46e8-9a56-446e1f681ea3">
											<gml:posList>35.66868402888429 139.73902918759802 33.622 35.66868402888429 139.73902918759802 12.7 35.66868962901067 139.73902099590606 12.7 35.66868962901067 139.73902099590606 16.513 35.66870934646688 139.73899212048593 16.513 35.66870934646688 139.73899212048593 12.7 35.66875704649219 139.73892228655552 12.7 35.66875704649219 139.73892228655552 33.622 35.66868402888429 139.73902918759802 33.622</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef05fc78-01b9-4752-b7e0-a51851c777dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef05fc78-01b9-4752-b7e0-a51851c777dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef05fc78-01b9-4752-b7e0-a51851c777dd">
											<gml:posList>35.66872861528971 139.7390118923035 12.7 35.66870934646688 139.73899212048593 12.7 35.66870934646688 139.73899212048593 16.513 35.66872861528971 139.7390118923035 16.513 35.66872861528971 139.7390118923035 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9c0124d-9f11-4b19-bba5-bd69f358ca88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9c0124d-9f11-4b19-bba5-bd69f358ca88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9c0124d-9f11-4b19-bba5-bd69f358ca88">
											<gml:posList>35.66870889782017 139.73904075667969 12.7 35.66872861528971 139.7390118923035 12.7 35.66872861528971 139.7390118923035 16.513 35.66870889782017 139.73904075667969 16.513 35.66870889782017 139.73904075667969 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2fad424-4433-46d2-bd74-174d699be87a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2fad424-4433-46d2-bd74-174d699be87a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2fad424-4433-46d2-bd74-174d699be87a">
											<gml:posList>35.66868962901067 139.73902099590606 12.7 35.66870889782017 139.73904075667969 12.7 35.66870889782017 139.73904075667969 16.513 35.66868962901067 139.73902099590606 16.513 35.66868962901067 139.73902099590606 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7726</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">441.5353</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>