<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8ca5b131-c6c9-42e6-b31a-6c919f1170cc">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66687404877402 139.7383129541944 0 35.66688639983588 139.7383272217496 0 35.66690436381415 139.73830387177782 0 35.66689201274953 139.73828960422304 0 35.66687404877402 139.7383129541944 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66687404877402 139.7383129541944 12.842 35.66689201274953 139.73828960422304 12.842 35.66690436381415 139.73830387177782 12.842 35.66688639983588 139.7383272217496 12.842 35.66687404877402 139.7383129541944 12.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66687404877402 139.7383129541944 12.842 35.66688639983588 139.7383272217496 12.842 35.66688639983588 139.7383272217496 15.842 35.66687404877402 139.7383129541944 15.842 35.66687404877402 139.7383129541944 12.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66688639983588 139.7383272217496 12.842 35.66690436381415 139.73830387177782 12.842 35.66690436381415 139.73830387177782 15.842 35.66688639983588 139.7383272217496 15.842 35.66688639983588 139.7383272217496 12.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66690436381415 139.73830387177782 12.842 35.66689201274953 139.73828960422304 12.842 35.66689201274953 139.73828960422304 15.842 35.66690436381415 139.73830387177782 15.842 35.66690436381415 139.73830387177782 12.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66689201274953 139.73828960422304 12.842 35.66687404877402 139.7383129541944 12.842 35.66687404877402 139.7383129541944 15.842 35.66689201274953 139.73828960422304 15.842 35.66689201274953 139.73828960422304 12.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66687404877402 139.7383129541944 15.842 35.66688639983588 139.7383272217496 15.842 35.66690436381415 139.73830387177782 15.842 35.66689201274953 139.73828960422304 15.842 35.66687404877402 139.7383129541944 15.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-dac5e8af-5e2f-4312-a5d3-59ff7ad09a73"/>
							<gml:surfaceMember xlink:href="#poly-20479701-6e7e-4662-806b-9b9956838e86"/>
							<gml:surfaceMember xlink:href="#poly-bdf07748-2ccd-45e3-94d1-c177151011a6"/>
							<gml:surfaceMember xlink:href="#poly-18629992-7325-4b50-a063-ce8ac117055e"/>
							<gml:surfaceMember xlink:href="#poly-2704ee8d-e6eb-4f87-a81e-05b870de074f"/>
							<gml:surfaceMember xlink:href="#poly-ff63fa2c-0361-4f1a-b8ac-d206b3af753f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-dac5e8af-5e2f-4312-a5d3-59ff7ad09a73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dac5e8af-5e2f-4312-a5d3-59ff7ad09a73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dac5e8af-5e2f-4312-a5d3-59ff7ad09a73">
											<gml:posList>35.66687404877402 139.7383129541944 12.842 35.66689201274953 139.73828960422304 12.842 35.6669043638141 139.73830387177782 12.842 35.66688639983585 139.7383272217496 12.842 35.66687404877402 139.7383129541944 12.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20479701-6e7e-4662-806b-9b9956838e86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20479701-6e7e-4662-806b-9b9956838e86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20479701-6e7e-4662-806b-9b9956838e86">
											<gml:posList>35.66689201274953 139.73828960422304 15.613 35.66687404877402 139.7383129541944 15.613 35.66688639983585 139.7383272217496 15.613 35.6669043638141 139.73830387177782 15.613 35.66689201274953 139.73828960422304 15.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bdf07748-2ccd-45e3-94d1-c177151011a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdf07748-2ccd-45e3-94d1-c177151011a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdf07748-2ccd-45e3-94d1-c177151011a6">
											<gml:posList>35.66687404877402 139.7383129541944 12.842 35.66688639983585 139.7383272217496 12.842 35.66688639983585 139.7383272217496 15.613 35.66687404877402 139.7383129541944 15.613 35.66687404877402 139.7383129541944 12.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18629992-7325-4b50-a063-ce8ac117055e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18629992-7325-4b50-a063-ce8ac117055e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18629992-7325-4b50-a063-ce8ac117055e">
											<gml:posList>35.6669043638141 139.73830387177782 12.842 35.66689201274953 139.73828960422304 12.842 35.66689201274953 139.73828960422304 15.613 35.6669043638141 139.73830387177782 15.613 35.6669043638141 139.73830387177782 12.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2704ee8d-e6eb-4f87-a81e-05b870de074f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2704ee8d-e6eb-4f87-a81e-05b870de074f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2704ee8d-e6eb-4f87-a81e-05b870de074f">
											<gml:posList>35.66689201274953 139.73828960422304 12.842 35.66687404877402 139.7383129541944 12.842 35.66687404877402 139.7383129541944 15.613 35.66689201274953 139.73828960422304 15.613 35.66689201274953 139.73828960422304 12.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff63fa2c-0361-4f1a-b8ac-d206b3af753f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff63fa2c-0361-4f1a-b8ac-d206b3af753f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff63fa2c-0361-4f1a-b8ac-d206b3af753f">
											<gml:posList>35.66688639983585 139.7383272217496 12.842 35.6669043638141 139.73830387177782 12.842 35.6669043638141 139.73830387177782 15.613 35.66688639983585 139.7383272217496 15.613 35.66688639983585 139.7383272217496 12.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8661</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>