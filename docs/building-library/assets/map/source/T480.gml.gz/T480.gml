<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8dc18e5d-9659-4800-b88d-7bb8adb220e4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66893642573549 139.74016822560694 0 35.66889661822707 139.74023444877585 0 35.66891279114211 139.74024905497737 0 35.668952607672175 139.74018283179186 0 35.66893642573549 139.74016822560694 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66893642573549 139.74016822560694 11.27 35.668952607672175 139.74018283179186 11.27 35.66891279114211 139.74024905497737 11.27 35.66889661822707 139.74023444877585 11.27 35.66893642573549 139.74016822560694 11.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66893642573549 139.74016822560694 11.27 35.66889661822707 139.74023444877585 11.27 35.66889661822707 139.74023444877585 14.27 35.66893642573549 139.74016822560694 14.27 35.66893642573549 139.74016822560694 11.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66889661822707 139.74023444877585 11.27 35.66891279114211 139.74024905497737 11.27 35.66891279114211 139.74024905497737 14.27 35.66889661822707 139.74023444877585 14.27 35.66889661822707 139.74023444877585 11.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66891279114211 139.74024905497737 11.27 35.668952607672175 139.74018283179186 11.27 35.668952607672175 139.74018283179186 14.27 35.66891279114211 139.74024905497737 14.27 35.66891279114211 139.74024905497737 11.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668952607672175 139.74018283179186 11.27 35.66893642573549 139.74016822560694 11.27 35.66893642573549 139.74016822560694 14.27 35.668952607672175 139.74018283179186 14.27 35.668952607672175 139.74018283179186 11.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66893642573549 139.74016822560694 14.27 35.66889661822707 139.74023444877585 14.27 35.66891279114211 139.74024905497737 14.27 35.668952607672175 139.74018283179186 14.27 35.66893642573549 139.74016822560694 14.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e94b5652-2bcb-43d6-b7bb-baf11da53653"/>
							<gml:surfaceMember xlink:href="#poly-7561eafe-cdc3-468a-9731-51bfe82228fb"/>
							<gml:surfaceMember xlink:href="#poly-7cb7a6a7-232e-451c-b8fd-26e761ae8c63"/>
							<gml:surfaceMember xlink:href="#poly-906a3186-1dc9-4f2b-9151-0b67ae2a570c"/>
							<gml:surfaceMember xlink:href="#poly-5d348c73-848e-4e09-b29b-fd46cbcd3cff"/>
							<gml:surfaceMember xlink:href="#poly-03f2cb8f-394c-4e87-b72e-1508674f1184"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e94b5652-2bcb-43d6-b7bb-baf11da53653">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e94b5652-2bcb-43d6-b7bb-baf11da53653">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e94b5652-2bcb-43d6-b7bb-baf11da53653">
											<gml:posList>35.66893642573547 139.74016822560694 11.27 35.66895260767217 139.74018283179183 11.27 35.668912791142105 139.74024905497734 11.27 35.66889661822706 139.74023444877585 11.27 35.66893642573547 139.74016822560694 11.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7561eafe-cdc3-468a-9731-51bfe82228fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7561eafe-cdc3-468a-9731-51bfe82228fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7561eafe-cdc3-468a-9731-51bfe82228fb">
											<gml:posList>35.66895260767217 139.74018283179183 13.505 35.66893642573547 139.74016822560694 13.505 35.66889661822706 139.74023444877585 13.505 35.668912791142105 139.74024905497734 13.505 35.66895260767217 139.74018283179183 13.505</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7cb7a6a7-232e-451c-b8fd-26e761ae8c63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cb7a6a7-232e-451c-b8fd-26e761ae8c63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cb7a6a7-232e-451c-b8fd-26e761ae8c63">
											<gml:posList>35.668912791142105 139.74024905497734 11.27 35.66895260767217 139.74018283179183 11.27 35.66895260767217 139.74018283179183 13.505 35.668912791142105 139.74024905497734 13.505 35.668912791142105 139.74024905497734 11.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-906a3186-1dc9-4f2b-9151-0b67ae2a570c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-906a3186-1dc9-4f2b-9151-0b67ae2a570c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-906a3186-1dc9-4f2b-9151-0b67ae2a570c">
											<gml:posList>35.66895260767217 139.74018283179183 11.27 35.66893642573547 139.74016822560694 11.27 35.66893642573547 139.74016822560694 13.505 35.66895260767217 139.74018283179183 13.505 35.66895260767217 139.74018283179183 11.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d348c73-848e-4e09-b29b-fd46cbcd3cff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d348c73-848e-4e09-b29b-fd46cbcd3cff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d348c73-848e-4e09-b29b-fd46cbcd3cff">
											<gml:posList>35.66893642573547 139.74016822560694 11.27 35.66889661822706 139.74023444877585 11.27 35.66889661822706 139.74023444877585 13.505 35.66893642573547 139.74016822560694 13.505 35.66893642573547 139.74016822560694 11.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03f2cb8f-394c-4e87-b72e-1508674f1184">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03f2cb8f-394c-4e87-b72e-1508674f1184">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03f2cb8f-394c-4e87-b72e-1508674f1184">
											<gml:posList>35.66889661822706 139.74023444877585 11.27 35.668912791142105 139.74024905497734 11.27 35.668912791142105 139.74024905497734 13.505 35.66889661822706 139.74023444877585 13.505 35.66889661822706 139.74023444877585 11.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7052</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>