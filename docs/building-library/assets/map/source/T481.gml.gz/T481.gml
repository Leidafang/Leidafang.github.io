<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8de38290-cc04-4ad2-989a-bb0db03200da">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>霞が関三丁目南地区</gen:value>
			</gen:stringAttribute>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67071673539177 139.74902152772705 0 35.67067211063548 139.74899896287627 0 35.670661874296684 139.74902936201218 0 35.67070649904731 139.749051926877 0 35.67071673539177 139.74902152772705 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67071673539177 139.74902152772705 6.69 35.67070649904731 139.749051926877 6.69 35.670661874296684 139.74902936201218 6.69 35.67067211063548 139.74899896287627 6.69 35.67071673539177 139.74902152772705 6.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67071673539177 139.74902152772705 6.69 35.67067211063548 139.74899896287627 6.69 35.67067211063548 139.74899896287627 9.690000000000001 35.67071673539177 139.74902152772705 9.690000000000001 35.67071673539177 139.74902152772705 6.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67067211063548 139.74899896287627 6.69 35.670661874296684 139.74902936201218 6.69 35.670661874296684 139.74902936201218 9.690000000000001 35.67067211063548 139.74899896287627 9.690000000000001 35.67067211063548 139.74899896287627 6.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670661874296684 139.74902936201218 6.69 35.67070649904731 139.749051926877 6.69 35.67070649904731 139.749051926877 9.690000000000001 35.670661874296684 139.74902936201218 9.690000000000001 35.670661874296684 139.74902936201218 6.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67070649904731 139.749051926877 6.69 35.67071673539177 139.74902152772705 6.69 35.67071673539177 139.74902152772705 9.690000000000001 35.67070649904731 139.749051926877 9.690000000000001 35.67070649904731 139.749051926877 6.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67071673539177 139.74902152772705 9.690000000000001 35.67067211063548 139.74899896287627 9.690000000000001 35.670661874296684 139.74902936201218 9.690000000000001 35.67070649904731 139.749051926877 9.690000000000001 35.67071673539177 139.74902152772705 9.690000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-31371ac8-be3a-4722-ad0a-e067073548ab"/>
							<gml:surfaceMember xlink:href="#poly-f17b0e8f-a82e-4389-ba4e-f98cff0e8e16"/>
							<gml:surfaceMember xlink:href="#poly-6c810fcc-6356-43ad-aca1-18063273e12d"/>
							<gml:surfaceMember xlink:href="#poly-4cddbd5f-cb2f-4fca-811b-8a9015d25ae5"/>
							<gml:surfaceMember xlink:href="#poly-a88e1e08-bcdc-4ff8-a991-c7dd644fb718"/>
							<gml:surfaceMember xlink:href="#poly-7c46066e-a424-41ed-861c-6df68fbb6721"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-31371ac8-be3a-4722-ad0a-e067073548ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31371ac8-be3a-4722-ad0a-e067073548ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31371ac8-be3a-4722-ad0a-e067073548ab">
											<gml:posList>35.67071673539175 139.74902152772702 6.69 35.67070649904731 139.749051926877 6.69 35.67066187429665 139.74902936201218 6.69 35.670672110635486 139.74899896287624 6.69 35.67071673539175 139.74902152772702 6.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f17b0e8f-a82e-4389-ba4e-f98cff0e8e16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f17b0e8f-a82e-4389-ba4e-f98cff0e8e16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f17b0e8f-a82e-4389-ba4e-f98cff0e8e16">
											<gml:posList>35.67070649904731 139.749051926877 7.636 35.67071673539175 139.74902152772702 7.636 35.670672110635486 139.74899896287624 7.636 35.67066187429665 139.74902936201218 7.636 35.67070649904731 139.749051926877 7.636</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c810fcc-6356-43ad-aca1-18063273e12d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c810fcc-6356-43ad-aca1-18063273e12d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c810fcc-6356-43ad-aca1-18063273e12d">
											<gml:posList>35.670672110635486 139.74899896287624 6.69 35.67066187429665 139.74902936201218 6.69 35.67066187429665 139.74902936201218 7.636 35.670672110635486 139.74899896287624 7.636 35.670672110635486 139.74899896287624 6.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cddbd5f-cb2f-4fca-811b-8a9015d25ae5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cddbd5f-cb2f-4fca-811b-8a9015d25ae5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cddbd5f-cb2f-4fca-811b-8a9015d25ae5">
											<gml:posList>35.67066187429665 139.74902936201218 6.69 35.67070649904731 139.749051926877 6.69 35.67070649904731 139.749051926877 7.636 35.67066187429665 139.74902936201218 7.636 35.67066187429665 139.74902936201218 6.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a88e1e08-bcdc-4ff8-a991-c7dd644fb718">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a88e1e08-bcdc-4ff8-a991-c7dd644fb718">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a88e1e08-bcdc-4ff8-a991-c7dd644fb718">
											<gml:posList>35.67071673539175 139.74902152772702 6.69 35.670672110635486 139.74899896287624 6.69 35.670672110635486 139.74899896287624 7.636 35.67071673539175 139.74902152772702 7.636 35.67071673539175 139.74902152772702 6.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c46066e-a424-41ed-861c-6df68fbb6721">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c46066e-a424-41ed-861c-6df68fbb6721">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c46066e-a424-41ed-861c-6df68fbb6721">
											<gml:posList>35.67070649904731 139.749051926877 6.69 35.67071673539175 139.74902152772702 6.69 35.67071673539175 139.74902152772702 7.636 35.67070649904731 139.749051926877 7.636 35.67070649904731 139.749051926877 6.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-897</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>