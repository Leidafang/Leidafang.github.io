<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8de7eef2-9bf1-4757-b4e9-9f9b4f832d17">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">15</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67201823804407 139.7399933797999 0 35.671968270957656 139.74006965867295 0 35.672013103362815 139.74011379245766 0 35.67206307047683 139.74003751356932 0 35.67201823804407 139.7399933797999 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67201823804407 139.7399933797999 7.97 35.67206307047683 139.74003751356932 7.97 35.672013103362815 139.74011379245766 7.97 35.671968270957656 139.74006965867295 7.97 35.67201823804407 139.7399933797999 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67201823804407 139.7399933797999 7.97 35.671968270957656 139.74006965867295 7.97 35.671968270957656 139.74006965867295 22.94 35.67201823804407 139.7399933797999 22.94 35.67201823804407 139.7399933797999 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671968270957656 139.74006965867295 7.97 35.672013103362815 139.74011379245766 7.97 35.672013103362815 139.74011379245766 22.94 35.671968270957656 139.74006965867295 22.94 35.671968270957656 139.74006965867295 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672013103362815 139.74011379245766 7.97 35.67206307047683 139.74003751356932 7.97 35.67206307047683 139.74003751356932 22.94 35.672013103362815 139.74011379245766 22.94 35.672013103362815 139.74011379245766 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67206307047683 139.74003751356932 7.97 35.67201823804407 139.7399933797999 7.97 35.67201823804407 139.7399933797999 22.94 35.67206307047683 139.74003751356932 22.94 35.67206307047683 139.74003751356932 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67201823804407 139.7399933797999 22.94 35.671968270957656 139.74006965867295 22.94 35.672013103362815 139.74011379245766 22.94 35.67206307047683 139.74003751356932 22.94 35.67201823804407 139.7399933797999 22.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8898132a-44a0-4fa6-a66d-cc201c34b2ea"/>
							<gml:surfaceMember xlink:href="#poly-5368b83b-a660-4ea1-920e-e3687c048b31"/>
							<gml:surfaceMember xlink:href="#poly-d9be7881-a0ef-459a-8a77-d0844410d29d"/>
							<gml:surfaceMember xlink:href="#poly-d27b827b-12d2-433c-94e0-f64cc3198fd7"/>
							<gml:surfaceMember xlink:href="#poly-fbfcf585-e2e4-494b-8847-b27436abee2c"/>
							<gml:surfaceMember xlink:href="#poly-c6f4e477-2fcb-4917-8a0b-83255595667e"/>
							<gml:surfaceMember xlink:href="#poly-18f3bdae-d5b3-44f9-bace-387d39c6983e"/>
							<gml:surfaceMember xlink:href="#poly-83f4196c-596a-4357-8137-2f1883e34d4e"/>
							<gml:surfaceMember xlink:href="#poly-b28f0d86-45f8-4891-ab43-b716059e4e0e"/>
							<gml:surfaceMember xlink:href="#poly-581256ff-0330-4c40-9de8-9818a17566b1"/>
							<gml:surfaceMember xlink:href="#poly-ed79d285-0d25-4cb0-9bd1-755f372432e0"/>
							<gml:surfaceMember xlink:href="#poly-98600917-643c-438c-a715-270178f634fe"/>
							<gml:surfaceMember xlink:href="#poly-f2968975-c01b-4226-bf1d-1be3c4386b61"/>
							<gml:surfaceMember xlink:href="#poly-3171142a-d697-4a3d-acd8-90aaf928c495"/>
							<gml:surfaceMember xlink:href="#poly-d5129be0-f244-4a89-ad7d-ce1bc14d409c"/>
							<gml:surfaceMember xlink:href="#poly-3cc9ba99-298a-4cea-949d-502514da6332"/>
							<gml:surfaceMember xlink:href="#poly-d2babf1f-df8b-49f9-b1df-87d147a9e721"/>
							<gml:surfaceMember xlink:href="#poly-07291b3e-e0f0-4c92-8301-1ba424072716"/>
							<gml:surfaceMember xlink:href="#poly-e91a2c0d-d877-4751-81c8-3565acbca676"/>
							<gml:surfaceMember xlink:href="#poly-cfb50f6d-689b-42e8-8101-5726a23b504e"/>
							<gml:surfaceMember xlink:href="#poly-13fabc2b-192d-4c32-85ff-3243755c3a14"/>
							<gml:surfaceMember xlink:href="#poly-b210bc3c-224c-47d6-a487-64c81ccab069"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8de7eef2-9bf1-4757-b4e9-9f9b4f832d17_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-269174d7-d2fe-4834-bca5-9bd178ba6f31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671989479573874 139.74006877237576 24.79 35.67199477498253 139.74007438887492 24.79 35.67199040810209 139.7400805578911 24.79 35.67198511269371 139.74007494139187 24.79 35.671989479573874 139.74006877237576 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4610a74-1df0-451d-adb9-9cd6ceb1de82">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671983007264316 139.74005655145135 24.79 35.67198771634826 139.74004997331645 24.79 35.672005010042604 139.74006853337957 24.79 35.67200030997138 139.74007511150432 24.79 35.671983007264316 139.74005655145135 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-948a89fb-7916-428d-8d00-fcca2e35609c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-948a89fb-7916-428d-8d00-fcca2e35609c_0">
											<gml:posList>35.67199477498253 139.74007438887492 24.79 35.671989479573874 139.74006877237576 24.79 35.671989479573874 139.74006877237576 25.383 35.67199477498253 139.74007438887492 25.383 35.67199477498253 139.74007438887492 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7055b522-6936-4fef-bea0-6f6d83758f8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7055b522-6936-4fef-bea0-6f6d83758f8f_0">
											<gml:posList>35.67198771634826 139.74004997331645 24.79 35.671983007264316 139.74005655145135 24.79 35.671983007264316 139.74005655145135 25.677 35.67198771634826 139.74004997331645 25.677 35.67198771634826 139.74004997331645 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f59038de-923d-437b-9581-604c3c23accd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f59038de-923d-437b-9581-604c3c23accd_0">
											<gml:posList>35.67198771634826 139.74004997331645 24.79 35.67198771634826 139.74004997331645 25.677 35.672005010042604 139.74006853337957 25.677 35.672005010042604 139.74006853337957 24.79 35.67198771634826 139.74004997331645 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f741b2f-40a0-4062-96c3-81edc2e0950e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f741b2f-40a0-4062-96c3-81edc2e0950e_0">
											<gml:posList>35.671983007264316 139.74005655145135 25.677 35.67200030997138 139.74007511150432 25.677 35.672005010042604 139.74006853337957 25.677 35.67198771634826 139.74004997331645 25.677 35.671983007264316 139.74005655145135 25.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48661442-35e8-4d19-a012-64317e9dc5da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48661442-35e8-4d19-a012-64317e9dc5da_0">
											<gml:posList>35.671983007264316 139.74005655145135 24.79 35.67200030997138 139.74007511150432 24.79 35.67200030997138 139.74007511150432 25.677 35.671983007264316 139.74005655145135 25.677 35.671983007264316 139.74005655145135 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a95cbaa8-b5ab-4f81-b52a-9a78ac3e56ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a95cbaa8-b5ab-4f81-b52a-9a78ac3e56ce_0">
											<gml:posList>35.67200030997138 139.74007511150432 24.79 35.672005010042604 139.74006853337957 24.79 35.672005010042604 139.74006853337957 25.677 35.67200030997138 139.74007511150432 25.677 35.67200030997138 139.74007511150432 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27f20209-0522-4b0a-ad02-eb3634c7cf0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27f20209-0522-4b0a-ad02-eb3634c7cf0d_0">
											<gml:posList>35.671989479573874 139.74006877237576 24.79 35.67198511269371 139.74007494139187 24.79 35.67198511269371 139.74007494139187 25.383 35.671989479573874 139.74006877237576 25.383 35.671989479573874 139.74006877237576 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6edcead3-3b5a-4007-8767-fb98e6d3041b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6edcead3-3b5a-4007-8767-fb98e6d3041b_0">
											<gml:posList>35.671989479573874 139.74006877237576 25.383 35.67198511269371 139.74007494139187 25.383 35.67199040810209 139.7400805578911 25.383 35.67199477498253 139.74007438887492 25.383 35.671989479573874 139.74006877237576 25.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f826d81-3410-4b83-8745-cb220f7c78a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f826d81-3410-4b83-8745-cb220f7c78a6_0">
											<gml:posList>35.67199040810209 139.7400805578911 24.79 35.67199477498253 139.74007438887492 24.79 35.67199477498253 139.74007438887492 25.383 35.67199040810209 139.7400805578911 25.383 35.67199040810209 139.7400805578911 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d12028b3-eb14-4cce-9dee-05e9edb43e7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d12028b3-eb14-4cce-9dee-05e9edb43e7a_0">
											<gml:posList>35.67198511269371 139.74007494139187 24.79 35.67199040810209 139.7400805578911 24.79 35.67199040810209 139.7400805578911 25.383 35.67198511269371 139.74007494139187 25.383 35.67198511269371 139.74007494139187 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8898132a-44a0-4fa6-a66d-cc201c34b2ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8898132a-44a0-4fa6-a66d-cc201c34b2ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8898132a-44a0-4fa6-a66d-cc201c34b2ea">
											<gml:posList>35.67201823804407 139.7399933797999 7.97 35.67206307047682 139.74003751356932 7.97 35.67201310336281 139.74011379245763 7.97 35.67196827095762 139.74006965867292 7.97 35.67201823804407 139.7399933797999 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5368b83b-a660-4ea1-920e-e3687c048b31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5368b83b-a660-4ea1-920e-e3687c048b31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5368b83b-a660-4ea1-920e-e3687c048b31">
											<gml:posList>35.67201310336281 139.74011379245763 23.156 35.672012612328714 139.74010824769346 23.156 35.67197278636086 139.74006904586392 23.156 35.67196827095762 139.74006965867292 23.156 35.67201310336281 139.74011379245763 23.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d9be7881-a0ef-459a-8a77-d0844410d29d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9be7881-a0ef-459a-8a77-d0844410d29d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9be7881-a0ef-459a-8a77-d0844410d29d">
											<gml:posList>35.67200976885048 139.74006796447298 24.79 35.67198907433913 139.74004599500321 24.79 35.67197369573699 139.74006774132152 24.79 35.67199439024442 139.74008971079272 24.79 35.67200976885048 139.74006796447298 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d27b827b-12d2-433c-94e0-f64cc3198fd7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d27b827b-12d2-433c-94e0-f64cc3198fd7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d27b827b-12d2-433c-94e0-f64cc3198fd7">
											<gml:posList>35.67197278636086 139.74006904586392 22.944 35.672012612328714 139.74010824769346 22.944 35.67199439024442 139.74008971079272 22.944 35.67197369573699 139.74006774132152 22.944 35.67197278636086 139.74006904586392 22.944</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fbfcf585-e2e4-494b-8847-b27436abee2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbfcf585-e2e4-494b-8847-b27436abee2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbfcf585-e2e4-494b-8847-b27436abee2c">
											<gml:posList>35.67201872908345 139.73999892456376 23.156 35.67201823804407 139.7399933797999 23.156 35.67196827095762 139.74006965867292 23.156 35.67197278636086 139.74006904586392 23.156 35.67201872908345 139.73999892456376 23.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c6f4e477-2fcb-4917-8a0b-83255595667e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6f4e477-2fcb-4917-8a0b-83255595667e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6f4e477-2fcb-4917-8a0b-83255595667e">
											<gml:posList>35.67201872908345 139.73999892456376 22.944 35.67197278636086 139.74006904586392 22.944 35.67197369573699 139.74006774132152 22.944 35.67198907433913 139.74004599500321 22.944 35.67201872908345 139.73999892456376 22.944</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18f3bdae-d5b3-44f9-bace-387d39c6983e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18f3bdae-d5b3-44f9-bace-387d39c6983e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18f3bdae-d5b3-44f9-bace-387d39c6983e">
											<gml:posList>35.67201872908345 139.73999892456376 22.944 35.67198907433913 139.74004599500321 22.944 35.67200976885048 139.74006796447298 22.944 35.67205855507381 139.74003812638085 22.944 35.67201872908345 139.73999892456376 22.944</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-83f4196c-596a-4357-8137-2f1883e34d4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83f4196c-596a-4357-8137-2f1883e34d4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83f4196c-596a-4357-8137-2f1883e34d4e">
											<gml:posList>35.672012612328714 139.74010824769346 22.944 35.67205855507381 139.74003812638085 22.944 35.67200976885048 139.74006796447298 22.944 35.67199439024442 139.74008971079272 22.944 35.672012612328714 139.74010824769346 22.944</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b28f0d86-45f8-4891-ab43-b716059e4e0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b28f0d86-45f8-4891-ab43-b716059e4e0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b28f0d86-45f8-4891-ab43-b716059e4e0e">
											<gml:posList>35.672012612328714 139.74010824769346 23.156 35.67201310336281 139.74011379245763 23.156 35.67206307047682 139.74003751356932 23.156 35.67205855507381 139.74003812638085 23.156 35.672012612328714 139.74010824769346 23.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-581256ff-0330-4c40-9de8-9818a17566b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-581256ff-0330-4c40-9de8-9818a17566b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-581256ff-0330-4c40-9de8-9818a17566b1">
											<gml:posList>35.67201823804407 139.7399933797999 23.156 35.67201872908345 139.73999892456376 23.156 35.67205855507381 139.74003812638085 23.156 35.67206307047682 139.74003751356932 23.156 35.67201823804407 139.7399933797999 23.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed79d285-0d25-4cb0-9bd1-755f372432e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed79d285-0d25-4cb0-9bd1-755f372432e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed79d285-0d25-4cb0-9bd1-755f372432e0">
											<gml:posList>35.67201872908345 139.73999892456376 23.156 35.67197278636086 139.74006904586392 23.156 35.67197278636086 139.74006904586392 22.944 35.67201872908345 139.73999892456376 22.944 35.67201872908345 139.73999892456376 23.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98600917-643c-438c-a715-270178f634fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98600917-643c-438c-a715-270178f634fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98600917-643c-438c-a715-270178f634fe">
											<gml:posList>35.67205855507381 139.74003812638085 22.944 35.672012612328714 139.74010824769346 22.944 35.672012612328714 139.74010824769346 23.156 35.67205855507381 139.74003812638085 23.156 35.67205855507381 139.74003812638085 22.944</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2968975-c01b-4226-bf1d-1be3c4386b61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2968975-c01b-4226-bf1d-1be3c4386b61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2968975-c01b-4226-bf1d-1be3c4386b61">
											<gml:posList>35.67206307047682 139.74003751356932 23.156 35.67206307047682 139.74003751356932 7.97 35.67201823804407 139.7399933797999 7.97 35.67201823804407 139.7399933797999 23.156 35.67206307047682 139.74003751356932 23.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3171142a-d697-4a3d-acd8-90aaf928c495">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3171142a-d697-4a3d-acd8-90aaf928c495">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3171142a-d697-4a3d-acd8-90aaf928c495">
											<gml:posList>35.67201872908345 139.73999892456376 22.944 35.67205855507381 139.74003812638085 22.944 35.67205855507381 139.74003812638085 23.156 35.67201872908345 139.73999892456376 23.156 35.67201872908345 139.73999892456376 22.944</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5129be0-f244-4a89-ad7d-ce1bc14d409c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5129be0-f244-4a89-ad7d-ce1bc14d409c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5129be0-f244-4a89-ad7d-ce1bc14d409c">
											<gml:posList>35.67201823804407 139.7399933797999 23.156 35.67201823804407 139.7399933797999 7.97 35.67196827095762 139.74006965867292 7.97 35.67196827095762 139.74006965867292 23.156 35.67201823804407 139.7399933797999 23.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cc9ba99-298a-4cea-949d-502514da6332">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cc9ba99-298a-4cea-949d-502514da6332">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cc9ba99-298a-4cea-949d-502514da6332">
											<gml:posList>35.67198907433913 139.74004599500321 22.944 35.67197369573699 139.74006774132152 22.944 35.67197369573699 139.74006774132152 24.79 35.67198907433913 139.74004599500321 24.79 35.67198907433913 139.74004599500321 22.944</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2babf1f-df8b-49f9-b1df-87d147a9e721">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2babf1f-df8b-49f9-b1df-87d147a9e721">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2babf1f-df8b-49f9-b1df-87d147a9e721">
											<gml:posList>35.67200976885048 139.74006796447298 22.944 35.67198907433913 139.74004599500321 22.944 35.67198907433913 139.74004599500321 24.79 35.67200976885048 139.74006796447298 24.79 35.67200976885048 139.74006796447298 22.944</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07291b3e-e0f0-4c92-8301-1ba424072716">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07291b3e-e0f0-4c92-8301-1ba424072716">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07291b3e-e0f0-4c92-8301-1ba424072716">
											<gml:posList>35.67201310336281 139.74011379245763 23.156 35.67201310336281 139.74011379245763 7.97 35.67206307047682 139.74003751356932 7.97 35.67206307047682 139.74003751356932 23.156 35.67201310336281 139.74011379245763 23.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e91a2c0d-d877-4751-81c8-3565acbca676">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e91a2c0d-d877-4751-81c8-3565acbca676">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e91a2c0d-d877-4751-81c8-3565acbca676">
											<gml:posList>35.67199439024442 139.74008971079272 24.79 35.67197369573699 139.74006774132152 24.79 35.67197369573699 139.74006774132152 22.944 35.67199439024442 139.74008971079272 22.944 35.67199439024442 139.74008971079272 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfb50f6d-689b-42e8-8101-5726a23b504e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfb50f6d-689b-42e8-8101-5726a23b504e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfb50f6d-689b-42e8-8101-5726a23b504e">
											<gml:posList>35.67199439024442 139.74008971079272 22.944 35.67200976885048 139.74006796447298 22.944 35.67200976885048 139.74006796447298 24.79 35.67199439024442 139.74008971079272 24.79 35.67199439024442 139.74008971079272 22.944</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13fabc2b-192d-4c32-85ff-3243755c3a14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13fabc2b-192d-4c32-85ff-3243755c3a14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13fabc2b-192d-4c32-85ff-3243755c3a14">
											<gml:posList>35.67197278636086 139.74006904586392 23.156 35.672012612328714 139.74010824769346 23.156 35.672012612328714 139.74010824769346 22.944 35.67197278636086 139.74006904586392 22.944 35.67197278636086 139.74006904586392 23.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b210bc3c-224c-47d6-a487-64c81ccab069">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b210bc3c-224c-47d6-a487-64c81ccab069">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b210bc3c-224c-47d6-a487-64c81ccab069">
											<gml:posList>35.67196827095762 139.74006965867292 23.156 35.67196827095762 139.74006965867292 7.97 35.67201310336281 139.74011379245763 7.97 35.67201310336281 139.74011379245763 23.156 35.67196827095762 139.74006965867292 23.156</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-713</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">56.493</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>