<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8e35fa0c-93dc-4a48-8351-3d146b80cb8d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">13.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670749690045604 139.74169388964455 0 35.67083259547564 139.74178492704144 0 35.67093803630949 139.74164043102743 0 35.67085504071864 139.74154950422704 0 35.670749690045604 139.74169388964455 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670749690045604 139.74169388964455 8.27 35.67085504071864 139.74154950422704 8.27 35.67093803630949 139.74164043102743 8.27 35.67083259547564 139.74178492704144 8.27 35.670749690045604 139.74169388964455 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670749690045604 139.74169388964455 8.27 35.67083259547564 139.74178492704144 8.27 35.67083259547564 139.74178492704144 22.2 35.670749690045604 139.74169388964455 22.2 35.670749690045604 139.74169388964455 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67083259547564 139.74178492704144 8.27 35.67093803630949 139.74164043102743 8.27 35.67093803630949 139.74164043102743 22.2 35.67083259547564 139.74178492704144 22.2 35.67083259547564 139.74178492704144 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67093803630949 139.74164043102743 8.27 35.67085504071864 139.74154950422704 8.27 35.67085504071864 139.74154950422704 22.2 35.67093803630949 139.74164043102743 22.2 35.67093803630949 139.74164043102743 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67085504071864 139.74154950422704 8.27 35.670749690045604 139.74169388964455 8.27 35.670749690045604 139.74169388964455 22.2 35.67085504071864 139.74154950422704 22.2 35.67085504071864 139.74154950422704 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670749690045604 139.74169388964455 22.2 35.67083259547564 139.74178492704144 22.2 35.67093803630949 139.74164043102743 22.2 35.67085504071864 139.74154950422704 22.2 35.670749690045604 139.74169388964455 22.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-eb8f249a-f86b-49a1-b795-2054fdeae325"/>
							<gml:surfaceMember xlink:href="#poly-58697e02-472d-4f49-84ae-3709a5abac84"/>
							<gml:surfaceMember xlink:href="#poly-9b3d0725-43ce-44a6-b300-1aa4613fd3bf"/>
							<gml:surfaceMember xlink:href="#poly-ccebe243-1036-4772-ab0a-ddd1e04c8222"/>
							<gml:surfaceMember xlink:href="#poly-096eee34-cdb6-4306-83f6-4ac29db7b69b"/>
							<gml:surfaceMember xlink:href="#poly-6b741a58-e290-461e-b402-3ef7dda17700"/>
							<gml:surfaceMember xlink:href="#poly-3805010a-7162-4dc4-b20a-458cd4e883c6"/>
							<gml:surfaceMember xlink:href="#poly-0ba8b305-c10f-4bde-a00a-7bf66c426bd0"/>
							<gml:surfaceMember xlink:href="#poly-6b839d62-819c-4a67-a4d5-e88083faebb0"/>
							<gml:surfaceMember xlink:href="#poly-5d8e6845-1ffa-48a7-ba97-79fb00918d67"/>
							<gml:surfaceMember xlink:href="#poly-fab94d20-1f13-465d-bbea-e0b20db93958"/>
							<gml:surfaceMember xlink:href="#poly-4a4053f3-0d9c-4f24-9aea-1964c6763bae"/>
							<gml:surfaceMember xlink:href="#poly-e8b19177-049c-4739-9b4c-94f3fb5a3397"/>
							<gml:surfaceMember xlink:href="#poly-580ff978-f28a-4c93-8c8c-1252b2a46f8b"/>
							<gml:surfaceMember xlink:href="#poly-64614dc2-2baf-4e64-924d-ca93dd6752e1"/>
							<gml:surfaceMember xlink:href="#poly-19fef719-2dc8-49f8-8fe1-9b1e22117d1f"/>
							<gml:surfaceMember xlink:href="#poly-201206ee-640b-4dc7-8fa4-c51bf73cc887"/>
							<gml:surfaceMember xlink:href="#poly-fe07eb1e-0ffb-4901-ba0b-f86ee230e0f0"/>
							<gml:surfaceMember xlink:href="#poly-b83349f4-7eac-4993-b44c-21ec92945d0f"/>
							<gml:surfaceMember xlink:href="#poly-6a6a33f0-502d-437c-abba-6fb4a6c21c68"/>
							<gml:surfaceMember xlink:href="#poly-67844651-1b82-4fe9-807c-14ce5ceb72af"/>
							<gml:surfaceMember xlink:href="#poly-8a1abed3-495a-470b-bba0-ba5731d2280e"/>
							<gml:surfaceMember xlink:href="#poly-11b16497-35d0-4a90-a95b-9b1d60140c6e"/>
							<gml:surfaceMember xlink:href="#poly-3bd1d150-8553-4e76-a4c1-b81f7ea93ecd"/>
							<gml:surfaceMember xlink:href="#poly-557da690-5515-4dcc-beac-a90981e55f09"/>
							<gml:surfaceMember xlink:href="#poly-0132b6e9-733f-458e-9b7b-9db1756e5279"/>
							<gml:surfaceMember xlink:href="#poly-d3a541d6-c1d1-466d-991c-f99793c06ade"/>
							<gml:surfaceMember xlink:href="#poly-dcdca504-fcbc-49d2-ba8c-6b2704440739"/>
							<gml:surfaceMember xlink:href="#poly-9fb4b97d-f41d-46e3-a59e-125c86fbd4bf"/>
							<gml:surfaceMember xlink:href="#poly-3f9a3543-08e8-47e8-b11b-5d09faa382a2"/>
							<gml:surfaceMember xlink:href="#poly-52d5ed14-cfcb-44eb-8f29-ed957a057bfa"/>
							<gml:surfaceMember xlink:href="#poly-a0469a87-e3e3-4255-91e2-6ab998049bfa"/>
							<gml:surfaceMember xlink:href="#poly-ec2b0a09-26ae-4898-9757-84c10a5c210e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8e35fa0c-93dc-4a48-8351-3d146b80cb8d_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b997a397-06aa-49a9-8a36-0f7098eb86b0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670865045384105 139.7416078947014 22.497 35.670844088952116 139.74158487604578 22.497 35.67085567755886 139.74156904444703 22.497 35.67087663398541 139.74159205205547 22.497 35.670865045384105 139.7416078947014 22.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e332c2cd-e066-4fa3-a2ce-84eb21762d6a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67080832351914 139.7416572593136 22.497 35.67082256818692 139.74167300612515 22.497 35.67080891750055 139.74169156850007 22.497 35.67079466382985 139.7416758327445 22.497 35.67080832351914 139.7416572593136 22.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae3207a9-9bd0-47b0-96b7-28b86ea8ab4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae3207a9-9bd0-47b0-96b7-28b86ea8ab4e_0">
											<gml:posList>35.67085567755886 139.74156904444703 22.497 35.670844088952116 139.74158487604578 22.497 35.670844088952116 139.74158487604578 24.839 35.67085567755886 139.74156904444703 24.839 35.67085567755886 139.74156904444703 22.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67dc18f7-1ffb-4627-b5a6-61ba375cfb58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67dc18f7-1ffb-4627-b5a6-61ba375cfb58_0">
											<gml:posList>35.67087663398541 139.74159205205547 22.497 35.67085567755886 139.74156904444703 22.497 35.67085567755886 139.74156904444703 24.839 35.67087663398541 139.74159205205547 24.839 35.67087663398541 139.74159205205547 22.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e51c182-7bcf-4295-b07f-7e92efd8ea77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e51c182-7bcf-4295-b07f-7e92efd8ea77_0">
											<gml:posList>35.67085567755886 139.74156904444703 24.839 35.670844088952116 139.74158487604578 24.839 35.670865045384105 139.7416078947014 24.839 35.67087663398541 139.74159205205547 24.839 35.67085567755886 139.74156904444703 24.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca96940e-92c5-4122-a00b-fe51a5506cff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca96940e-92c5-4122-a00b-fe51a5506cff_0">
											<gml:posList>35.670844088952116 139.74158487604578 22.497 35.670865045384105 139.7416078947014 22.497 35.670865045384105 139.7416078947014 24.839 35.670844088952116 139.74158487604578 24.839 35.670844088952116 139.74158487604578 22.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68afa5f2-7d01-4127-a869-81208dc27810">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68afa5f2-7d01-4127-a869-81208dc27810_0">
											<gml:posList>35.670865045384105 139.7416078947014 22.497 35.67087663398541 139.74159205205547 22.497 35.67087663398541 139.74159205205547 24.839 35.670865045384105 139.7416078947014 24.839 35.670865045384105 139.7416078947014 22.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1c1b508-f274-4191-85bd-973315246d1d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1c1b508-f274-4191-85bd-973315246d1d_0">
											<gml:posList>35.67082256818692 139.74167300612515 22.497 35.67080832351914 139.7416572593136 22.497 35.67080832351914 139.7416572593136 24.896 35.67082256818692 139.74167300612515 24.896 35.67082256818692 139.74167300612515 22.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4658dff7-bc62-4a3b-a1c5-2eec17ccda03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4658dff7-bc62-4a3b-a1c5-2eec17ccda03_0">
											<gml:posList>35.67079466382985 139.7416758327445 22.497 35.67079466382985 139.7416758327445 24.896 35.67080832351914 139.7416572593136 24.896 35.67080832351914 139.7416572593136 22.497 35.67079466382985 139.7416758327445 22.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47cfc948-8094-4860-bc4f-7bba5d155211">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47cfc948-8094-4860-bc4f-7bba5d155211_0">
											<gml:posList>35.67080832351914 139.7416572593136 24.896 35.67079466382985 139.7416758327445 24.896 35.67080891750055 139.74169156850007 24.896 35.67082256818692 139.74167300612515 24.896 35.67080832351914 139.7416572593136 24.896</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28007e00-f729-4a12-a5a2-d30133908a4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28007e00-f729-4a12-a5a2-d30133908a4a_0">
											<gml:posList>35.67080891750055 139.74169156850007 22.497 35.67082256818692 139.74167300612515 22.497 35.67082256818692 139.74167300612515 24.896 35.67080891750055 139.74169156850007 24.896 35.67080891750055 139.74169156850007 22.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-298706cc-1b7a-4878-ab25-935d83178a79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-298706cc-1b7a-4878-ab25-935d83178a79_0">
											<gml:posList>35.67079466382985 139.7416758327445 22.497 35.67080891750055 139.74169156850007 22.497 35.67080891750055 139.74169156850007 24.896 35.67079466382985 139.7416758327445 24.896 35.67079466382985 139.7416758327445 22.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-eb8f249a-f86b-49a1-b795-2054fdeae325">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb8f249a-f86b-49a1-b795-2054fdeae325">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb8f249a-f86b-49a1-b795-2054fdeae325">
											<gml:posList>35.67074969004558 139.74169388964455 8.27 35.67085504071863 139.74154950422704 8.27 35.67093803630945 139.74164043102743 8.27 35.670832595475645 139.74178492704144 8.27 35.67074969004558 139.74169388964455 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-58697e02-472d-4f49-84ae-3709a5abac84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58697e02-472d-4f49-84ae-3709a5abac84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58697e02-472d-4f49-84ae-3709a5abac84">
											<gml:posList>35.67085504071863 139.74154950422704 22.972 35.670855416511756 139.74155767807738 22.972 35.670904762814565 139.74161174861777 22.972 35.670911432624 139.74161128808782 22.972 35.67085504071863 139.74154950422704 22.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b3d0725-43ce-44a6-b300-1aa4613fd3bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b3d0725-43ce-44a6-b300-1aa4613fd3bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b3d0725-43ce-44a6-b300-1aa4613fd3bf">
											<gml:posList>35.670855416511756 139.74155767807738 22.972 35.67085504071863 139.74154950422704 22.972 35.67076435810592 139.7416737796369 22.972 35.670767849359436 139.74167764185518 22.972 35.670855416511756 139.74155767807738 22.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ccebe243-1036-4772-ab0a-ddd1e04c8222">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccebe243-1036-4772-ab0a-ddd1e04c8222">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccebe243-1036-4772-ab0a-ddd1e04c8222">
											<gml:posList>35.670929464705495 139.74164102628606 16.396 35.67093803630945 139.74164043102743 16.396 35.670911432624 139.74161128808782 16.396 35.670907380664474 139.74161682693574 16.396 35.670929464705495 139.74164102628606 16.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-096eee34-cdb6-4306-83f6-4ac29db7b69b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-096eee34-cdb6-4306-83f6-4ac29db7b69b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-096eee34-cdb6-4306-83f6-4ac29db7b69b">
											<gml:posList>35.670904762814565 139.74161174861777 22.497 35.670855416511756 139.74155767807738 22.497 35.670767849359436 139.74167764185518 22.497 35.670804683382265 139.74171832752202 22.497 35.67079332002318 139.74173405941494 22.497 35.67080554380919 139.74174744463355 22.497 35.670904762814565 139.74161174861777 22.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6b741a58-e290-461e-b402-3ef7dda17700">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b741a58-e290-461e-b402-3ef7dda17700">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b741a58-e290-461e-b402-3ef7dda17700">
											<gml:posList>35.670911432624 139.74161128808782 22.972 35.670904762814565 139.74161174861777 22.972 35.67080554380919 139.74174744463355 22.972 35.670805901561444 139.74175561850035 22.972 35.670911432624 139.74161128808782 22.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3805010a-7162-4dc4-b20a-458cd4e883c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3805010a-7162-4dc4-b20a-458cd4e883c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3805010a-7162-4dc4-b20a-458cd4e883c6">
											<gml:posList>35.67074969004558 139.74169388964455 25.727 35.67075261936247 139.7416936985091 25.727 35.67076451408875 139.74167739160276 25.727 35.67076435810592 139.7416737796369 25.727 35.67074969004558 139.74169388964455 25.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ba8b305-c10f-4bde-a00a-7bf66c426bd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ba8b305-c10f-4bde-a00a-7bf66c426bd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ba8b305-c10f-4bde-a00a-7bf66c426bd0">
											<gml:posList>35.670907380664474 139.74161682693574 15.986 35.67080994451372 139.74175007967676 15.986 35.67083212779687 139.74177443356967 15.986 35.670929464705495 139.74164102628606 15.986 35.670907380664474 139.74161682693574 15.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6b839d62-819c-4a67-a4d5-e88083faebb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b839d62-819c-4a67-a4d5-e88083faebb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b839d62-819c-4a67-a4d5-e88083faebb0">
											<gml:posList>35.67076435810592 139.7416737796369 25.727 35.67076451408875 139.74167739160276 25.727 35.67080175407377 139.74171852970298 25.727 35.670804683382265 139.74171832752202 25.727 35.67076435810592 139.7416737796369 25.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d8e6845-1ffa-48a7-ba97-79fb00918d67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d8e6845-1ffa-48a7-ba97-79fb00918d67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d8e6845-1ffa-48a7-ba97-79fb00918d67">
											<gml:posList>35.67080175407377 139.74171852970298 24.886 35.67076451408875 139.74167739160276 24.886 35.67075261936247 139.7416936985091 24.886 35.67079001252486 139.7417347701579 24.886 35.67080175407377 139.74171852970298 24.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fab94d20-1f13-465d-bbea-e0b20db93958">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fab94d20-1f13-465d-bbea-e0b20db93958">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fab94d20-1f13-465d-bbea-e0b20db93958">
											<gml:posList>35.67093803630945 139.74164043102743 16.396 35.670929464705495 139.74164102628606 16.396 35.67083212779687 139.74177443356967 16.396 35.670832595475645 139.74178492704144 16.396 35.67093803630945 139.74164043102743 16.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a4053f3-0d9c-4f24-9aea-1964c6763bae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a4053f3-0d9c-4f24-9aea-1964c6763bae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a4053f3-0d9c-4f24-9aea-1964c6763bae">
											<gml:posList>35.67079019553863 139.74173837104786 25.727 35.67079001252486 139.7417347701579 25.727 35.67075261936247 139.7416936985091 25.727 35.67074969004558 139.74169388964455 25.727 35.67079019553863 139.74173837104786 25.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e8b19177-049c-4739-9b4c-94f3fb5a3397">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8b19177-049c-4739-9b4c-94f3fb5a3397">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8b19177-049c-4739-9b4c-94f3fb5a3397">
											<gml:posList>35.670804683382265 139.74171832752202 25.727 35.67080175407377 139.74171852970298 25.727 35.67079001252486 139.7417347701579 25.727 35.67079019553863 139.74173837104786 25.727 35.670804683382265 139.74171832752202 25.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-580ff978-f28a-4c93-8c8c-1252b2a46f8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-580ff978-f28a-4c93-8c8c-1252b2a46f8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-580ff978-f28a-4c93-8c8c-1252b2a46f8b">
											<gml:posList>35.67080554380919 139.74174744463355 22.972 35.67079332002318 139.74173405941494 22.972 35.67079019553863 139.74173837104786 22.972 35.670805901561444 139.74175561850035 22.972 35.67080554380919 139.74174744463355 22.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-64614dc2-2baf-4e64-924d-ca93dd6752e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64614dc2-2baf-4e64-924d-ca93dd6752e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64614dc2-2baf-4e64-924d-ca93dd6752e1">
											<gml:posList>35.67083212779687 139.74177443356967 16.396 35.67080994451372 139.74175007967676 16.396 35.670805901561444 139.74175561850035 16.396 35.670832595475645 139.74178492704144 16.396 35.67083212779687 139.74177443356967 16.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19fef719-2dc8-49f8-8fe1-9b1e22117d1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19fef719-2dc8-49f8-8fe1-9b1e22117d1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19fef719-2dc8-49f8-8fe1-9b1e22117d1f">
											<gml:posList>35.670767849359436 139.74167764185518 22.972 35.670767849359436 139.74167764185518 22.497 35.670855416511756 139.74155767807738 22.497 35.670855416511756 139.74155767807738 22.972 35.670767849359436 139.74167764185518 22.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-201206ee-640b-4dc7-8fa4-c51bf73cc887">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-201206ee-640b-4dc7-8fa4-c51bf73cc887">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-201206ee-640b-4dc7-8fa4-c51bf73cc887">
											<gml:posList>35.670904762814565 139.74161174861777 22.972 35.670904762814565 139.74161174861777 22.497 35.67080554380919 139.74174744463355 22.497 35.67080554380919 139.74174744463355 22.972 35.670904762814565 139.74161174861777 22.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe07eb1e-0ffb-4901-ba0b-f86ee230e0f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe07eb1e-0ffb-4901-ba0b-f86ee230e0f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe07eb1e-0ffb-4901-ba0b-f86ee230e0f0">
											<gml:posList>35.67076451408875 139.74167739160276 24.886 35.67080175407377 139.74171852970298 24.886 35.67080175407377 139.74171852970298 25.727 35.67076451408875 139.74167739160276 25.727 35.67076451408875 139.74167739160276 24.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b83349f4-7eac-4993-b44c-21ec92945d0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b83349f4-7eac-4993-b44c-21ec92945d0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b83349f4-7eac-4993-b44c-21ec92945d0f">
											<gml:posList>35.670929464705495 139.74164102628606 16.396 35.670929464705495 139.74164102628606 15.986 35.67083212779687 139.74177443356967 15.986 35.67083212779687 139.74177443356967 16.396 35.670929464705495 139.74164102628606 16.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a6a33f0-502d-437c-abba-6fb4a6c21c68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a6a33f0-502d-437c-abba-6fb4a6c21c68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a6a33f0-502d-437c-abba-6fb4a6c21c68">
											<gml:posList>35.67075261936247 139.7416936985091 25.727 35.67079001252486 139.7417347701579 25.727 35.67079001252486 139.7417347701579 24.886 35.67075261936247 139.7416936985091 24.886 35.67075261936247 139.7416936985091 25.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67844651-1b82-4fe9-807c-14ce5ceb72af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67844651-1b82-4fe9-807c-14ce5ceb72af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67844651-1b82-4fe9-807c-14ce5ceb72af">
											<gml:posList>35.67075261936247 139.7416936985091 24.886 35.67076451408875 139.74167739160276 24.886 35.67076451408875 139.74167739160276 25.727 35.67075261936247 139.7416936985091 25.727 35.67075261936247 139.7416936985091 24.886</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a1abed3-495a-470b-bba0-ba5731d2280e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a1abed3-495a-470b-bba0-ba5731d2280e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a1abed3-495a-470b-bba0-ba5731d2280e">
											<gml:posList>35.670767849359436 139.74167764185518 22.972 35.67076435810592 139.7416737796369 22.972 35.67076435810592 139.7416737796369 25.727 35.670804683382265 139.74171832752202 25.727 35.670804683382265 139.74171832752202 22.497 35.670767849359436 139.74167764185518 22.497 35.670767849359436 139.74167764185518 22.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11b16497-35d0-4a90-a95b-9b1d60140c6e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11b16497-35d0-4a90-a95b-9b1d60140c6e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11b16497-35d0-4a90-a95b-9b1d60140c6e">
											<gml:posList>35.670832595475645 139.74178492704144 8.27 35.670832595475645 139.74178492704144 16.396 35.670805901561444 139.74175561850035 16.396 35.670805901561444 139.74175561850035 22.972 35.67079019553863 139.74173837104786 22.972 35.67079019553863 139.74173837104786 25.727 35.67074969004558 139.74169388964455 25.727 35.67074969004558 139.74169388964455 8.27 35.670832595475645 139.74178492704144 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3bd1d150-8553-4e76-a4c1-b81f7ea93ecd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bd1d150-8553-4e76-a4c1-b81f7ea93ecd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bd1d150-8553-4e76-a4c1-b81f7ea93ecd">
											<gml:posList>35.67079001252486 139.7417347701579 25.727 35.67080175407377 139.74171852970298 25.727 35.67080175407377 139.74171852970298 24.886 35.67079001252486 139.7417347701579 24.886 35.67079001252486 139.7417347701579 25.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-557da690-5515-4dcc-beac-a90981e55f09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-557da690-5515-4dcc-beac-a90981e55f09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-557da690-5515-4dcc-beac-a90981e55f09">
											<gml:posList>35.67079019553863 139.74173837104786 25.727 35.67079019553863 139.74173837104786 22.972 35.67079332002318 139.74173405941494 22.972 35.67079332002318 139.74173405941494 22.497 35.670804683382265 139.74171832752202 22.497 35.670804683382265 139.74171832752202 25.727 35.67079019553863 139.74173837104786 25.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0132b6e9-733f-458e-9b7b-9db1756e5279">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0132b6e9-733f-458e-9b7b-9db1756e5279">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0132b6e9-733f-458e-9b7b-9db1756e5279">
											<gml:posList>35.67080554380919 139.74174744463355 22.972 35.67080554380919 139.74174744463355 22.497 35.67079332002318 139.74173405941494 22.497 35.67079332002318 139.74173405941494 22.972 35.67080554380919 139.74174744463355 22.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3a541d6-c1d1-466d-991c-f99793c06ade">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3a541d6-c1d1-466d-991c-f99793c06ade">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3a541d6-c1d1-466d-991c-f99793c06ade">
											<gml:posList>35.67074969004558 139.74169388964455 8.27 35.67074969004558 139.74169388964455 25.727 35.67076435810592 139.7416737796369 25.727 35.67076435810592 139.7416737796369 22.972 35.67085504071863 139.74154950422704 22.972 35.67085504071863 139.74154950422704 8.27 35.67074969004558 139.74169388964455 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dcdca504-fcbc-49d2-ba8c-6b2704440739">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcdca504-fcbc-49d2-ba8c-6b2704440739">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcdca504-fcbc-49d2-ba8c-6b2704440739">
											<gml:posList>35.67083212779687 139.74177443356967 16.396 35.67083212779687 139.74177443356967 15.986 35.67080994451372 139.74175007967676 15.986 35.67080994451372 139.74175007967676 16.396 35.67083212779687 139.74177443356967 16.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9fb4b97d-f41d-46e3-a59e-125c86fbd4bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fb4b97d-f41d-46e3-a59e-125c86fbd4bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fb4b97d-f41d-46e3-a59e-125c86fbd4bf">
											<gml:posList>35.67080994451372 139.74175007967676 16.396 35.67080994451372 139.74175007967676 15.986 35.670907380664474 139.74161682693574 15.986 35.670907380664474 139.74161682693574 16.396 35.670911432624 139.74161128808782 16.396 35.670911432624 139.74161128808782 22.972 35.670805901561444 139.74175561850035 22.972 35.670805901561444 139.74175561850035 16.396 35.67080994451372 139.74175007967676 16.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f9a3543-08e8-47e8-b11b-5d09faa382a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f9a3543-08e8-47e8-b11b-5d09faa382a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f9a3543-08e8-47e8-b11b-5d09faa382a2">
											<gml:posList>35.670855416511756 139.74155767807738 22.972 35.670855416511756 139.74155767807738 22.497 35.670904762814565 139.74161174861777 22.497 35.670904762814565 139.74161174861777 22.972 35.670855416511756 139.74155767807738 22.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52d5ed14-cfcb-44eb-8f29-ed957a057bfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52d5ed14-cfcb-44eb-8f29-ed957a057bfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52d5ed14-cfcb-44eb-8f29-ed957a057bfa">
											<gml:posList>35.670832595475645 139.74178492704144 8.27 35.67093803630945 139.74164043102743 8.27 35.67093803630945 139.74164043102743 16.396 35.670832595475645 139.74178492704144 16.396 35.670832595475645 139.74178492704144 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0469a87-e3e3-4255-91e2-6ab998049bfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0469a87-e3e3-4255-91e2-6ab998049bfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0469a87-e3e3-4255-91e2-6ab998049bfa">
											<gml:posList>35.67093803630945 139.74164043102743 8.27 35.67085504071863 139.74154950422704 8.27 35.67085504071863 139.74154950422704 22.972 35.670911432624 139.74161128808782 22.972 35.670911432624 139.74161128808782 16.396 35.67093803630945 139.74164043102743 16.396 35.67093803630945 139.74164043102743 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec2b0a09-26ae-4898-9757-84c10a5c210e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec2b0a09-26ae-4898-9757-84c10a5c210e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec2b0a09-26ae-4898-9757-84c10a5c210e">
											<gml:posList>35.670907380664474 139.74161682693574 16.396 35.670907380664474 139.74161682693574 15.986 35.670929464705495 139.74164102628606 15.986 35.670929464705495 139.74164102628606 16.396 35.670907380664474 139.74161682693574 16.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10794</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">216.6404</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>