<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8eb524b4-6874-4b3a-82f3-7ef3ffb22ff0">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670686800328156 139.74914969631521 0 35.67070590290318 139.74908880007027 0 35.67067493954833 139.74907421834854 0 35.670680722470884 139.74905577599364 0 35.6706544117325 139.7490433876111 0 35.67062952624252 139.74912271512238 0 35.670686800328156 139.74914969631521 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670686800328156 139.74914969631521 6.673 35.67062952624252 139.74912271512238 6.673 35.6706544117325 139.7490433876111 6.673 35.670680722470884 139.74905577599364 6.673 35.67067493954833 139.74907421834854 6.673 35.67070590290318 139.74908880007027 6.673 35.670686800328156 139.74914969631521 6.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670686800328156 139.74914969631521 6.673 35.67070590290318 139.74908880007027 6.673 35.67070590290318 139.74908880007027 9.673 35.670686800328156 139.74914969631521 9.673 35.670686800328156 139.74914969631521 6.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67070590290318 139.74908880007027 6.673 35.67067493954833 139.74907421834854 6.673 35.67067493954833 139.74907421834854 9.673 35.67070590290318 139.74908880007027 9.673 35.67070590290318 139.74908880007027 6.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67067493954833 139.74907421834854 6.673 35.670680722470884 139.74905577599364 6.673 35.670680722470884 139.74905577599364 9.673 35.67067493954833 139.74907421834854 9.673 35.67067493954833 139.74907421834854 6.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670680722470884 139.74905577599364 6.673 35.6706544117325 139.7490433876111 6.673 35.6706544117325 139.7490433876111 9.673 35.670680722470884 139.74905577599364 9.673 35.670680722470884 139.74905577599364 6.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6706544117325 139.7490433876111 6.673 35.67062952624252 139.74912271512238 6.673 35.67062952624252 139.74912271512238 9.673 35.6706544117325 139.7490433876111 9.673 35.6706544117325 139.7490433876111 6.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67062952624252 139.74912271512238 6.673 35.670686800328156 139.74914969631521 6.673 35.670686800328156 139.74914969631521 9.673 35.67062952624252 139.74912271512238 9.673 35.67062952624252 139.74912271512238 6.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670686800328156 139.74914969631521 9.673 35.67070590290318 139.74908880007027 9.673 35.67067493954833 139.74907421834854 9.673 35.670680722470884 139.74905577599364 9.673 35.6706544117325 139.7490433876111 9.673 35.67062952624252 139.74912271512238 9.673 35.670686800328156 139.74914969631521 9.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3c2c97de-0d9c-4f83-ab17-90ffa3730f62"/>
							<gml:surfaceMember xlink:href="#poly-5210efb6-363a-4870-b1dd-2cd8138c1b5c"/>
							<gml:surfaceMember xlink:href="#poly-a8a7865c-d467-41ad-910a-8d381f2d3731"/>
							<gml:surfaceMember xlink:href="#poly-6f01127c-96a4-4d47-aa53-7530b5599be8"/>
							<gml:surfaceMember xlink:href="#poly-fbae6132-f5ba-489a-b1be-025841cfd08f"/>
							<gml:surfaceMember xlink:href="#poly-43646f92-ac92-461e-a968-7163346545b4"/>
							<gml:surfaceMember xlink:href="#poly-ed49d163-963f-4218-9da7-c8ae999e0a3f"/>
							<gml:surfaceMember xlink:href="#poly-39d4dc49-89ab-407f-916f-ef25c1d266ae"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3c2c97de-0d9c-4f83-ab17-90ffa3730f62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c2c97de-0d9c-4f83-ab17-90ffa3730f62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c2c97de-0d9c-4f83-ab17-90ffa3730f62">
											<gml:posList>35.670629526242486 139.74912271512238 6.673 35.6706544117325 139.74904338761112 6.673 35.67068072247086 139.74905577599364 6.673 35.67067493954833 139.74907421834854 6.673 35.67070590290316 139.74908880007024 6.673 35.67068680032814 139.74914969631521 6.673 35.670629526242486 139.74912271512238 6.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5210efb6-363a-4870-b1dd-2cd8138c1b5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5210efb6-363a-4870-b1dd-2cd8138c1b5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5210efb6-363a-4870-b1dd-2cd8138c1b5c">
											<gml:posList>35.670629526242486 139.74912271512238 9.396 35.67068680032814 139.74914969631521 9.396 35.67070590290316 139.74908880007024 9.396 35.67067493954833 139.74907421834854 9.396 35.67068072247086 139.74905577599364 9.396 35.6706544117325 139.74904338761112 9.396 35.670629526242486 139.74912271512238 9.396</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8a7865c-d467-41ad-910a-8d381f2d3731">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8a7865c-d467-41ad-910a-8d381f2d3731">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8a7865c-d467-41ad-910a-8d381f2d3731">
											<gml:posList>35.6706544117325 139.74904338761112 6.673 35.670629526242486 139.74912271512238 6.673 35.670629526242486 139.74912271512238 9.396 35.6706544117325 139.74904338761112 9.396 35.6706544117325 139.74904338761112 6.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f01127c-96a4-4d47-aa53-7530b5599be8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f01127c-96a4-4d47-aa53-7530b5599be8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f01127c-96a4-4d47-aa53-7530b5599be8">
											<gml:posList>35.670629526242486 139.74912271512238 6.673 35.67068680032814 139.74914969631521 6.673 35.67068680032814 139.74914969631521 9.396 35.670629526242486 139.74912271512238 9.396 35.670629526242486 139.74912271512238 6.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fbae6132-f5ba-489a-b1be-025841cfd08f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbae6132-f5ba-489a-b1be-025841cfd08f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbae6132-f5ba-489a-b1be-025841cfd08f">
											<gml:posList>35.67068072247086 139.74905577599364 6.673 35.6706544117325 139.74904338761112 6.673 35.6706544117325 139.74904338761112 9.396 35.67068072247086 139.74905577599364 9.396 35.67068072247086 139.74905577599364 6.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43646f92-ac92-461e-a968-7163346545b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43646f92-ac92-461e-a968-7163346545b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43646f92-ac92-461e-a968-7163346545b4">
											<gml:posList>35.67067493954833 139.74907421834854 6.673 35.67068072247086 139.74905577599364 6.673 35.67068072247086 139.74905577599364 9.396 35.67067493954833 139.74907421834854 9.396 35.67067493954833 139.74907421834854 6.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed49d163-963f-4218-9da7-c8ae999e0a3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed49d163-963f-4218-9da7-c8ae999e0a3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed49d163-963f-4218-9da7-c8ae999e0a3f">
											<gml:posList>35.67070590290316 139.74908880007024 6.673 35.67067493954833 139.74907421834854 6.673 35.67067493954833 139.74907421834854 9.396 35.67070590290316 139.74908880007024 9.396 35.67070590290316 139.74908880007024 6.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39d4dc49-89ab-407f-916f-ef25c1d266ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39d4dc49-89ab-407f-916f-ef25c1d266ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39d4dc49-89ab-407f-916f-ef25c1d266ae">
											<gml:posList>35.67068680032814 139.74914969631521 6.673 35.67070590290316 139.74908880007024 6.673 35.67070590290316 139.74908880007024 9.396 35.67068680032814 139.74914969631521 9.396 35.67068680032814 139.74914969631521 6.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7749</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>8</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>