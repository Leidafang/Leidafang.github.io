<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8f4d5ba0-d836-4367-9843-df28815a6864">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">10.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66926425576515 139.7388731527445 0 35.66924788219854 139.73885576337526 0 35.669213668171274 139.7389044065235 0 35.66931326158434 139.73900878545467 0 35.66936962109924 139.73892399541234 0 35.66928886298962 139.73883835060406 0 35.66926425576515 139.7388731527445 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66926425576515 139.7388731527445 15.31 35.66928886298962 139.73883835060406 15.31 35.66936962109924 139.73892399541234 15.31 35.66931326158434 139.73900878545467 15.31 35.669213668171274 139.7389044065235 15.31 35.66924788219854 139.73885576337526 15.31 35.66926425576515 139.7388731527445 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66926425576515 139.7388731527445 15.31 35.66924788219854 139.73885576337526 15.31 35.66924788219854 139.73885576337526 26.04 35.66926425576515 139.7388731527445 26.04 35.66926425576515 139.7388731527445 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924788219854 139.73885576337526 15.31 35.669213668171274 139.7389044065235 15.31 35.669213668171274 139.7389044065235 26.04 35.66924788219854 139.73885576337526 26.04 35.66924788219854 139.73885576337526 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669213668171274 139.7389044065235 15.31 35.66931326158434 139.73900878545467 15.31 35.66931326158434 139.73900878545467 26.04 35.669213668171274 139.7389044065235 26.04 35.669213668171274 139.7389044065235 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66931326158434 139.73900878545467 15.31 35.66936962109924 139.73892399541234 15.31 35.66936962109924 139.73892399541234 26.04 35.66931326158434 139.73900878545467 26.04 35.66931326158434 139.73900878545467 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66936962109924 139.73892399541234 15.31 35.66928886298962 139.73883835060406 15.31 35.66928886298962 139.73883835060406 26.04 35.66936962109924 139.73892399541234 26.04 35.66936962109924 139.73892399541234 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66928886298962 139.73883835060406 15.31 35.66926425576515 139.7388731527445 15.31 35.66926425576515 139.7388731527445 26.04 35.66928886298962 139.73883835060406 26.04 35.66928886298962 139.73883835060406 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66926425576515 139.7388731527445 26.04 35.66924788219854 139.73885576337526 26.04 35.669213668171274 139.7389044065235 26.04 35.66931326158434 139.73900878545467 26.04 35.66936962109924 139.73892399541234 26.04 35.66928886298962 139.73883835060406 26.04 35.66926425576515 139.7388731527445 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-95ddc498-223f-4d67-abda-5f0c935191c3"/>
							<gml:surfaceMember xlink:href="#poly-14aacf2d-3b1d-4e37-a7e0-7c85c781d346"/>
							<gml:surfaceMember xlink:href="#poly-77458f46-526c-4113-a5e2-4deff99a1c9f"/>
							<gml:surfaceMember xlink:href="#poly-3f56196f-2eca-4701-91e0-6b873cc7464b"/>
							<gml:surfaceMember xlink:href="#poly-8954e048-cbc9-4cc1-ac17-517b403c708c"/>
							<gml:surfaceMember xlink:href="#poly-f76be80c-c1e7-4a28-90b1-13d7d83feba4"/>
							<gml:surfaceMember xlink:href="#poly-e144b2e2-8e63-4a07-939f-b209aa6aa7f5"/>
							<gml:surfaceMember xlink:href="#poly-b3075757-268c-4450-b70c-d070026cbbe3"/>
							<gml:surfaceMember xlink:href="#poly-cb5dbc37-3761-4577-94ee-e85e89303d38"/>
							<gml:surfaceMember xlink:href="#poly-1fb624db-6ad5-4119-ab89-9eeb037434e6"/>
							<gml:surfaceMember xlink:href="#poly-8590b333-3a70-49d0-a8d7-b074c6d9cf41"/>
							<gml:surfaceMember xlink:href="#poly-faecaf5d-9ccb-4c07-a9a6-a7866e206209"/>
							<gml:surfaceMember xlink:href="#poly-99cfcb88-f5f0-45af-b589-ccc1709afd99"/>
							<gml:surfaceMember xlink:href="#poly-8b7439a2-ea49-4af3-a787-ea1374ef3f17"/>
							<gml:surfaceMember xlink:href="#poly-74dc209e-c4c8-4f36-86a8-c74e5da0a647"/>
							<gml:surfaceMember xlink:href="#poly-894b6363-8799-44b3-99e4-7df58bc879af"/>
							<gml:surfaceMember xlink:href="#poly-a3665e2c-f50c-4094-ab01-6b19574f35ac"/>
							<gml:surfaceMember xlink:href="#poly-00829150-6f26-478d-a6fc-4738635b260f"/>
							<gml:surfaceMember xlink:href="#poly-b510e251-a4a2-4940-8348-fcb3d7d700de"/>
							<gml:surfaceMember xlink:href="#poly-effdcb5b-7c3e-406c-93bf-79eb43b5257f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8f4d5ba0-d836-4367-9843-df28815a6864_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32231288-3217-467e-b201-ba49ab18dbcf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66928886298962 139.73883835060406 15.31 35.66926425576514 139.7388731527445 15.31 35.66924788219855 139.73885576337523 15.31 35.669282636431014 139.7388063573671 15.31 35.66931348910743 139.73883911690163 15.31 35.669304153993075 139.73885457036647 15.31 35.66928886298962 139.73883835060406 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cb56894-f090-4d0e-bba8-c7d6f108265f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4cb56894-f090-4d0e-bba8-c7d6f108265f_0">
											<gml:posList>35.66924788219855 139.73885576337523 23.815 35.66926425576514 139.7388731527445 23.815 35.66926425576514 139.7388731527445 25.339 35.66924788219855 139.73885576337523 25.339 35.66924788219855 139.73885576337523 23.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-625d9cb0-e76f-494a-83a8-eeacf912461e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-625d9cb0-e76f-494a-83a8-eeacf912461e_0">
											<gml:posList>35.66926425576514 139.7388731527445 23.815 35.66924788219855 139.73885576337523 23.815 35.66924788219855 139.73885576337523 15.31 35.66926425576514 139.7388731527445 15.31 35.66926425576514 139.7388731527445 23.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c27903b-20ea-4cfd-b0bc-d8492d924fc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c27903b-20ea-4cfd-b0bc-d8492d924fc8_0">
											<gml:posList>35.66927240824254 139.73882089505565 23.815 35.669282636431014 139.7388063573671 23.815 35.669282636431014 139.7388063573671 15.31 35.66924788219855 139.73885576337523 15.31 35.66924788219855 139.73885576337523 23.815 35.66924788219855 139.73885576337523 25.339 35.66927240824254 139.73882089505565 25.339 35.66927240824254 139.73882089505565 23.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4841b33-f753-4e3a-85ff-c9b1a23c7c44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4841b33-f753-4e3a-85ff-c9b1a23c7c44_0">
											<gml:posList>35.66927240824254 139.73882089505565 25.339 35.66924788219855 139.73885576337523 25.339 35.66926425576514 139.7388731527445 25.339 35.66928886298962 139.73883835060406 25.339 35.66927240824254 139.73882089505565 25.339</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c273a30-5930-418e-ac2f-6ba53434fb89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c273a30-5930-418e-ac2f-6ba53434fb89_0">
											<gml:posList>35.66926425576514 139.7388731527445 23.815 35.66928886298962 139.73883835060406 24.682 35.66928886298962 139.73883835060406 25.339 35.66926425576514 139.7388731527445 25.339 35.66926425576514 139.7388731527445 23.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1c9953b-3b65-4f44-b0f8-3dd10c67ce8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1c9953b-3b65-4f44-b0f8-3dd10c67ce8d_0">
											<gml:posList>35.66926425576514 139.7388731527445 15.31 35.66928886298962 139.73883835060406 15.31 35.66928886298962 139.73883835060406 24.682 35.66926425576514 139.7388731527445 23.815 35.66926425576514 139.7388731527445 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4567f00-360e-42f9-b8af-6cf0fbefe73b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4567f00-360e-42f9-b8af-6cf0fbefe73b_0">
											<gml:posList>35.66928886298962 139.73883835060406 24.682 35.66927240824254 139.73882089505565 23.815 35.66927240824254 139.73882089505565 25.339 35.66928886298962 139.73883835060406 25.339 35.66928886298962 139.73883835060406 24.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-804b3898-0765-495c-bfd0-07f6811d7f55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-804b3898-0765-495c-bfd0-07f6811d7f55_0">
											<gml:posList>35.669305532362735 139.7388306649576 25.059 35.669282636431014 139.7388063573671 23.815 35.66927240824254 139.73882089505565 23.815 35.66928886298962 139.73883835060406 24.682 35.66929617921334 139.738846107397 25.059 35.669305532362735 139.7388306649576 25.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f1f1592-2a19-4a5c-afec-a7a288881339">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f1f1592-2a19-4a5c-afec-a7a288881339_0">
											<gml:posList>35.66928886298962 139.73883835060406 15.31 35.669304153993075 139.73885457036647 15.31 35.669304153993075 139.73885457036647 25.059 35.66929617921334 139.738846107397 25.059 35.66928886298962 139.73883835060406 24.682 35.66928886298962 139.73883835060406 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5d9d74e-612d-4adf-8021-0c862cfcbafe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5d9d74e-612d-4adf-8021-0c862cfcbafe_0">
											<gml:posList>35.669282636431014 139.7388063573671 15.31 35.669282636431014 139.7388063573671 23.815 35.669305532362735 139.7388306649576 25.059 35.66931348910743 139.73883911690163 25.059 35.66931348910743 139.73883911690163 15.31 35.669282636431014 139.7388063573671 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b8ac3cb-cfde-469e-8a45-b8cf56db6196">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b8ac3cb-cfde-469e-8a45-b8cf56db6196_0">
											<gml:posList>35.66931348910743 139.73883911690163 25.059 35.669305532362735 139.7388306649576 25.059 35.66929617921334 139.738846107397 25.059 35.669304153993075 139.73885457036647 25.059 35.66931348910743 139.73883911690163 25.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ad94eba-965d-41f8-a114-00c8c9b24508">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ad94eba-965d-41f8-a114-00c8c9b24508_0">
											<gml:posList>35.669304153993075 139.73885457036647 25.059 35.669304153993075 139.73885457036647 15.31 35.66931348910743 139.73883911690163 15.31 35.66931348910743 139.73883911690163 25.059 35.669304153993075 139.73885457036647 25.059</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8f4d5ba0-d836-4367-9843-df28815a6864_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecd047a8-fa2b-4d5c-acd4-995a057e1c3d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669313608346876 139.73892218352591 26.04 35.66931495120988 139.73892194997637 26.04 35.66931630336372 139.73892206989146 26.04 35.669317610717435 139.73892253228883 26.04 35.669318801143895 139.73892331516117 26.04 35.66931983856222 139.7389243854126 26.04 35.66932067786914 139.73892569891186 26.04 35.669321264930325 139.73892718944595 26.04 35.66932159970249 139.7389288017843 26.04 35.66932163705639 139.73893045865736 26.04 35.66932140398123 139.73893209375657 26.04 35.669320891411324 139.7389336408159 26.04 35.66932013533231 139.7389350114241 26.04 35.669319153745654 139.73893617242163 26.04 35.669318009686805 139.73893704641148 26.04 35.66931673017964 139.7389376112696 26.04 35.66931538731662 139.73893784481888 26.04 35.66931403516278 139.7389377249035 26.04 35.66931272780913 139.7389372625059 26.04 35.66931153738276 139.73893647963345 26.04 35.66931049996454 139.73893540938195 26.04 35.669309660666386 139.73893410692887 26.04 35.6693090645829 139.73893260535945 26.04 35.6693087388245 139.7389309930107 26.04 35.66930870147061 139.73892933613791 26.04 35.66930893454574 139.73892770103896 26.04 35.669309447115566 139.73892615397983 26.04 35.669310203194485 139.73892478337171 26.04 35.669311184781044 139.7389236223742 26.04 35.66931232883979 139.73892274838423 26.04 35.669313608346876 139.73892218352591 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1708888a-d0be-4b15-a1f4-7622677f04ec">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66930730333674 139.73899706149356 26.04 35.669295512213296 139.73898407409504 26.04 35.66931072915948 139.73896332263703 26.04 35.66932252929885 139.73897631002433 26.04 35.66930730333674 139.73899706149356 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfc8c9f7-6ceb-4c05-913d-d6fd64e14e1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfc8c9f7-6ceb-4c05-913d-d6fd64e14e1f_0">
											<gml:posList>35.669295512213296 139.73898407409504 26.04 35.66930730333674 139.73899706149356 26.04 35.66930730333674 139.73899706149356 27.684 35.669295512213296 139.73898407409504 27.684 35.669295512213296 139.73898407409504 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23628995-dcdd-4fe2-b611-298c533ee70a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23628995-dcdd-4fe2-b611-298c533ee70a_0">
											<gml:posList>35.669295512213296 139.73898407409504 27.684 35.66931072915948 139.73896332263703 27.684 35.66931072915948 139.73896332263703 26.04 35.669295512213296 139.73898407409504 26.04 35.669295512213296 139.73898407409504 27.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9415f8c2-2aef-4fbc-af04-d155fe887eb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9415f8c2-2aef-4fbc-af04-d155fe887eb0_0">
											<gml:posList>35.66930870147061 139.73892933613791 26.04 35.6693087388245 139.7389309930107 26.04 35.6693087388245 139.7389309930107 30.526 35.66930870147061 139.73892933613791 30.526 35.66930870147061 139.73892933613791 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b06782c2-2cad-4119-a750-e0666023df65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b06782c2-2cad-4119-a750-e0666023df65_0">
											<gml:posList>35.66930893454574 139.73892770103896 26.04 35.66930870147061 139.73892933613791 26.04 35.66930870147061 139.73892933613791 30.526 35.66930893454574 139.73892770103896 30.526 35.66930893454574 139.73892770103896 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d5f7fe8-f0b9-49b1-bff4-09fbbb9e0cb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d5f7fe8-f0b9-49b1-bff4-09fbbb9e0cb1_0">
											<gml:posList>35.6693087388245 139.7389309930107 26.04 35.6693090645829 139.73893260535945 26.04 35.6693090645829 139.73893260535945 30.526 35.6693087388245 139.7389309930107 30.526 35.6693087388245 139.7389309930107 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76f3280a-2ae3-4c9b-b75f-02cac2321938">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76f3280a-2ae3-4c9b-b75f-02cac2321938_0">
											<gml:posList>35.66930730333674 139.73899706149356 27.684 35.66932252929885 139.73897631002433 27.684 35.66931072915948 139.73896332263703 27.684 35.669295512213296 139.73898407409504 27.684 35.66930730333674 139.73899706149356 27.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c7cbefc-34c4-4f07-9a15-34c7efd59f65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c7cbefc-34c4-4f07-9a15-34c7efd59f65_0">
											<gml:posList>35.669309447115566 139.73892615397983 26.04 35.66930893454574 139.73892770103896 26.04 35.66930893454574 139.73892770103896 30.526 35.669309447115566 139.73892615397983 30.526 35.669309447115566 139.73892615397983 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37403bfe-a2e2-4626-91f2-1afd9fc117a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37403bfe-a2e2-4626-91f2-1afd9fc117a5_0">
											<gml:posList>35.6693090645829 139.73893260535945 26.04 35.669309660666386 139.73893410692887 26.04 35.669309660666386 139.73893410692887 30.526 35.6693090645829 139.73893260535945 30.526 35.6693090645829 139.73893260535945 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6af954c5-d600-46f1-8261-9594ce2a5777">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6af954c5-d600-46f1-8261-9594ce2a5777_0">
											<gml:posList>35.669309447115566 139.73892615397983 26.04 35.669309447115566 139.73892615397983 30.526 35.669310203194485 139.73892478337171 30.526 35.669310203194485 139.73892478337171 26.04 35.669309447115566 139.73892615397983 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15083c1d-6e55-4ff5-ab78-d9b11483c9ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15083c1d-6e55-4ff5-ab78-d9b11483c9ea_0">
											<gml:posList>35.669309660666386 139.73893410692887 26.04 35.66931049996454 139.73893540938195 26.04 35.66931049996454 139.73893540938195 30.526 35.669309660666386 139.73893410692887 30.526 35.669309660666386 139.73893410692887 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a34f7f4-165c-419d-b90a-a9d40aed6bdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a34f7f4-165c-419d-b90a-a9d40aed6bdf_0">
											<gml:posList>35.669310203194485 139.73892478337171 26.04 35.669310203194485 139.73892478337171 30.526 35.669311184781044 139.7389236223742 30.526 35.669311184781044 139.7389236223742 26.04 35.669310203194485 139.73892478337171 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a17a8f4b-1a8b-4f04-ac84-897609076a4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a17a8f4b-1a8b-4f04-ac84-897609076a4e_0">
											<gml:posList>35.66931049996454 139.73893540938195 26.04 35.66931153738276 139.73893647963345 26.04 35.66931153738276 139.73893647963345 30.526 35.66931049996454 139.73893540938195 30.526 35.66931049996454 139.73893540938195 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ae16283-cca5-45c0-870e-d68d6ce177e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ae16283-cca5-45c0-870e-d68d6ce177e8_0">
											<gml:posList>35.66931232883979 139.73892274838423 26.04 35.669311184781044 139.7389236223742 26.04 35.669311184781044 139.7389236223742 30.526 35.66931232883979 139.73892274838423 30.526 35.66931232883979 139.73892274838423 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df5d9a39-7bf7-491f-8d7e-bd0c6472e143">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df5d9a39-7bf7-491f-8d7e-bd0c6472e143_0">
											<gml:posList>35.66931272780913 139.7389372625059 26.04 35.66931272780913 139.7389372625059 30.526 35.66931153738276 139.73893647963345 30.526 35.66931153738276 139.73893647963345 26.04 35.66931272780913 139.7389372625059 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2cafa5b-8430-442c-b26a-77b6e7a3e2c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2cafa5b-8430-442c-b26a-77b6e7a3e2c2_0">
											<gml:posList>35.669313608346876 139.73892218352591 26.04 35.66931232883979 139.73892274838423 26.04 35.66931232883979 139.73892274838423 30.526 35.669313608346876 139.73892218352591 30.526 35.669313608346876 139.73892218352591 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-860578e4-a5d1-4da0-953f-eef21e87211f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-860578e4-a5d1-4da0-953f-eef21e87211f_0">
											<gml:posList>35.66931272780913 139.7389372625059 26.04 35.66931403516278 139.7389377249035 26.04 35.66931403516278 139.7389377249035 30.526 35.66931272780913 139.7389372625059 30.526 35.66931272780913 139.7389372625059 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c27ea98f-57f2-474f-bb97-f0d536625d29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c27ea98f-57f2-474f-bb97-f0d536625d29_0">
											<gml:posList>35.66931495120988 139.73892194997637 26.04 35.669313608346876 139.73892218352591 26.04 35.669313608346876 139.73892218352591 30.526 35.66931495120988 139.73892194997637 30.526 35.66931495120988 139.73892194997637 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab24f4fb-ae29-45a6-aa9e-2f52a49a29c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab24f4fb-ae29-45a6-aa9e-2f52a49a29c8_0">
											<gml:posList>35.66931538731662 139.73893784481888 26.04 35.66931538731662 139.73893784481888 30.526 35.66931403516278 139.7389377249035 30.526 35.66931403516278 139.7389377249035 26.04 35.66931538731662 139.73893784481888 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db08791a-c850-4194-a512-41292ee617b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db08791a-c850-4194-a512-41292ee617b0_0">
											<gml:posList>35.66930730333674 139.73899706149356 26.04 35.66932252929885 139.73897631002433 26.04 35.66932252929885 139.73897631002433 27.684 35.66930730333674 139.73899706149356 27.684 35.66930730333674 139.73899706149356 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-243d3cc7-28d9-41f4-b48b-1d7277283875">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-243d3cc7-28d9-41f4-b48b-1d7277283875_0">
											<gml:posList>35.669311184781044 139.7389236223742 30.526 35.669310203194485 139.73892478337171 30.526 35.669309447115566 139.73892615397983 30.526 35.66930893454574 139.73892770103896 30.526 35.66930870147061 139.73892933613791 30.526 35.6693087388245 139.7389309930107 30.526 35.6693090645829 139.73893260535945 30.526 35.669309660666386 139.73893410692887 30.526 35.66931049996454 139.73893540938195 30.526 35.66931153738276 139.73893647963345 30.526 35.66931272780913 139.7389372625059 30.526 35.66931403516278 139.7389377249035 30.526 35.66931538731662 139.73893784481888 30.526 35.66931673017964 139.7389376112696 30.526 35.669318009686805 139.73893704641148 30.526 35.669319153745654 139.73893617242163 30.526 35.66932013533231 139.7389350114241 30.526 35.669320891411324 139.7389336408159 30.526 35.66932140398123 139.73893209375657 30.526 35.66932163705639 139.73893045865736 30.526 35.66932159970249 139.7389288017843 30.526 35.669321264930325 139.73892718944595 30.526 35.66932067786914 139.73892569891186 30.526 35.66931983856222 139.7389243854126 30.526 35.669318801143895 139.73892331516117 30.526 35.669317610717435 139.73892253228883 30.526 35.66931630336372 139.73892206989146 30.526 35.66931495120988 139.73892194997637 30.526 35.669313608346876 139.73892218352591 30.526 35.66931232883979 139.73892274838423 30.526 35.669311184781044 139.7389236223742 30.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6027b577-1b6b-46f3-8964-4a76d91e5be1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6027b577-1b6b-46f3-8964-4a76d91e5be1_0">
											<gml:posList>35.66931495120988 139.73892194997637 26.04 35.66931495120988 139.73892194997637 30.526 35.66931630336372 139.73892206989146 30.526 35.66931630336372 139.73892206989146 26.04 35.66931495120988 139.73892194997637 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d958b1cc-6f8f-4d47-b4aa-82fed12e71d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d958b1cc-6f8f-4d47-b4aa-82fed12e71d5_0">
											<gml:posList>35.66931538731662 139.73893784481888 26.04 35.66931673017964 139.7389376112696 26.04 35.66931673017964 139.7389376112696 30.526 35.66931538731662 139.73893784481888 30.526 35.66931538731662 139.73893784481888 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58f2001a-7034-437b-8587-e2a6e12ea9a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58f2001a-7034-437b-8587-e2a6e12ea9a6_0">
											<gml:posList>35.66932252929885 139.73897631002433 26.04 35.66931072915948 139.73896332263703 26.04 35.66931072915948 139.73896332263703 27.684 35.66932252929885 139.73897631002433 27.684 35.66932252929885 139.73897631002433 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-621bcee3-d4a3-42b2-8bcf-7830caa3830d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-621bcee3-d4a3-42b2-8bcf-7830caa3830d_0">
											<gml:posList>35.669317610717435 139.73892253228883 26.04 35.66931630336372 139.73892206989146 26.04 35.66931630336372 139.73892206989146 30.526 35.669317610717435 139.73892253228883 30.526 35.669317610717435 139.73892253228883 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c4cd6e0-8240-4566-8843-ff32be255258">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c4cd6e0-8240-4566-8843-ff32be255258_0">
											<gml:posList>35.66931673017964 139.7389376112696 26.04 35.669318009686805 139.73893704641148 26.04 35.669318009686805 139.73893704641148 30.526 35.66931673017964 139.7389376112696 30.526 35.66931673017964 139.7389376112696 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19386a43-557d-420c-9a4d-a9cb15d16c85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19386a43-557d-420c-9a4d-a9cb15d16c85_0">
											<gml:posList>35.669318801143895 139.73892331516117 26.04 35.669317610717435 139.73892253228883 26.04 35.669317610717435 139.73892253228883 30.526 35.669318801143895 139.73892331516117 30.526 35.669318801143895 139.73892331516117 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8ec997f-7548-459f-938f-f8c5a01df061">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8ec997f-7548-459f-938f-f8c5a01df061_0">
											<gml:posList>35.669318009686805 139.73893704641148 26.04 35.669319153745654 139.73893617242163 26.04 35.669319153745654 139.73893617242163 30.526 35.669318009686805 139.73893704641148 30.526 35.669318009686805 139.73893704641148 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f8e0692-3769-4376-bb1a-51fab1633612">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f8e0692-3769-4376-bb1a-51fab1633612_0">
											<gml:posList>35.66931983856222 139.7389243854126 26.04 35.669318801143895 139.73892331516117 26.04 35.669318801143895 139.73892331516117 30.526 35.66931983856222 139.7389243854126 30.526 35.66931983856222 139.7389243854126 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec3df84b-83a4-4ce2-b38d-1431a31fe7ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec3df84b-83a4-4ce2-b38d-1431a31fe7ca_0">
											<gml:posList>35.669319153745654 139.73893617242163 26.04 35.66932013533231 139.7389350114241 26.04 35.66932013533231 139.7389350114241 30.526 35.669319153745654 139.73893617242163 30.526 35.669319153745654 139.73893617242163 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69a05f79-5290-4133-8cd1-4a8b4899b2b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69a05f79-5290-4133-8cd1-4a8b4899b2b4_0">
											<gml:posList>35.66932067786914 139.73892569891186 26.04 35.66931983856222 139.7389243854126 26.04 35.66931983856222 139.7389243854126 30.526 35.66932067786914 139.73892569891186 30.526 35.66932067786914 139.73892569891186 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75ea9a6f-e669-412f-a79a-793db44f06ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75ea9a6f-e669-412f-a79a-793db44f06ee_0">
											<gml:posList>35.66932013533231 139.7389350114241 26.04 35.669320891411324 139.7389336408159 26.04 35.669320891411324 139.7389336408159 30.526 35.66932013533231 139.7389350114241 30.526 35.66932013533231 139.7389350114241 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e94870ac-9be5-4d7d-8b60-dfeedb9f0b22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e94870ac-9be5-4d7d-8b60-dfeedb9f0b22_0">
											<gml:posList>35.669321264930325 139.73892718944595 26.04 35.66932067786914 139.73892569891186 26.04 35.66932067786914 139.73892569891186 30.526 35.669321264930325 139.73892718944595 30.526 35.669321264930325 139.73892718944595 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c150a1f-6fcd-45a5-b2de-90ff44433874">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c150a1f-6fcd-45a5-b2de-90ff44433874_0">
											<gml:posList>35.669320891411324 139.7389336408159 26.04 35.66932140398123 139.73893209375657 26.04 35.66932140398123 139.73893209375657 30.526 35.669320891411324 139.7389336408159 30.526 35.669320891411324 139.7389336408159 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f002a8a4-332c-4018-b2ea-d85c824fa20a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f002a8a4-332c-4018-b2ea-d85c824fa20a_0">
											<gml:posList>35.66932159970249 139.7389288017843 26.04 35.669321264930325 139.73892718944595 26.04 35.669321264930325 139.73892718944595 30.526 35.66932159970249 139.7389288017843 30.526 35.66932159970249 139.7389288017843 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15895f06-b446-4306-8182-2d46f442e645">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15895f06-b446-4306-8182-2d46f442e645_0">
											<gml:posList>35.66932140398123 139.73893209375657 26.04 35.66932163705639 139.73893045865736 26.04 35.66932163705639 139.73893045865736 30.526 35.66932140398123 139.73893209375657 30.526 35.66932140398123 139.73893209375657 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5ffe4f6-638d-48b8-b426-d2142b0620fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5ffe4f6-638d-48b8-b426-d2142b0620fd_0">
											<gml:posList>35.66932163705639 139.73893045865736 26.04 35.66932159970249 139.7389288017843 26.04 35.66932159970249 139.7389288017843 30.526 35.66932163705639 139.73893045865736 30.526 35.66932163705639 139.73893045865736 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8f4d5ba0-d836-4367-9843-df28815a6864_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02318392-b1b4-440f-9634-86676b68e95a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669344691556375 139.73895010464722 26.04 35.66933042877118 139.73893470106034 26.04 35.66934803142658 139.73891022423308 26.04 35.669362294223525 139.73892563886508 26.04 35.669344691556375 139.73895010464722 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6eb631cf-f215-475c-86fc-81a13caa0414">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6eb631cf-f215-475c-86fc-81a13caa0414_0">
											<gml:posList>35.66934803142658 139.73891022423308 28.538 35.669362294223525 139.73892563886508 28.538 35.669362294223525 139.73892563886508 26.04 35.66934803142658 139.73891022423308 26.04 35.66934803142658 139.73891022423308 28.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f9d631e-7396-42b8-a5c0-082fbb565bb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f9d631e-7396-42b8-a5c0-082fbb565bb8_0">
											<gml:posList>35.66933042877118 139.73893470106034 28.538 35.66934803142658 139.73891022423308 28.538 35.66934803142658 139.73891022423308 26.04 35.66933042877118 139.73893470106034 26.04 35.66933042877118 139.73893470106034 28.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e11e928d-ab57-4ba0-b36f-b10bbbbcf4c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e11e928d-ab57-4ba0-b36f-b10bbbbcf4c8_0">
											<gml:posList>35.66934803142658 139.73891022423308 28.538 35.66933042877118 139.73893470106034 28.538 35.669344691556375 139.73895010464722 28.538 35.669362294223525 139.73892563886508 28.538 35.66934803142658 139.73891022423308 28.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ab4bd91-04ff-4e9b-be95-84cc0b92887b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ab4bd91-04ff-4e9b-be95-84cc0b92887b_0">
											<gml:posList>35.669362294223525 139.73892563886508 26.04 35.669362294223525 139.73892563886508 28.538 35.669344691556375 139.73895010464722 28.538 35.669344691556375 139.73895010464722 26.04 35.669362294223525 139.73892563886508 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ca12a8b-880e-4712-a826-25a65f27b913">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ca12a8b-880e-4712-a826-25a65f27b913_0">
											<gml:posList>35.669344691556375 139.73895010464722 26.04 35.669344691556375 139.73895010464722 28.538 35.66933042877118 139.73893470106034 28.538 35.66933042877118 139.73893470106034 26.04 35.669344691556375 139.73895010464722 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-95ddc498-223f-4d67-abda-5f0c935191c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95ddc498-223f-4d67-abda-5f0c935191c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95ddc498-223f-4d67-abda-5f0c935191c3">
											<gml:posList>35.66926425576514 139.7388731527445 15.31 35.66928886298962 139.73883835060406 15.31 35.66936962109924 139.73892399541234 15.31 35.66931326158433 139.73900878545467 15.31 35.66921366817129 139.7389044065235 15.31 35.66924788219855 139.73885576337523 15.31 35.66926425576514 139.7388731527445 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-14aacf2d-3b1d-4e37-a7e0-7c85c781d346">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14aacf2d-3b1d-4e37-a7e0-7c85c781d346">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14aacf2d-3b1d-4e37-a7e0-7c85c781d346">
											<gml:posList>35.66926425576514 139.7388731527445 26.691 35.66926440181307 139.73887548330072 26.691 35.66928900001582 139.73884067012546 26.691 35.66928886298962 139.73883835060406 26.691 35.66926425576514 139.7388731527445 26.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-77458f46-526c-4113-a5e2-4deff99a1c9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77458f46-526c-4113-a5e2-4deff99a1c9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77458f46-526c-4113-a5e2-4deff99a1c9f">
											<gml:posList>35.66926425576514 139.7388731527445 26.691 35.66924788219855 139.73885576337523 26.691 35.66924802823813 139.73885808288483 26.691 35.66926440181307 139.73887548330072 26.691 35.66926425576514 139.7388731527445 26.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f56196f-2eca-4701-91e0-6b873cc7464b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f56196f-2eca-4701-91e0-6b873cc7464b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f56196f-2eca-4701-91e0-6b873cc7464b">
											<gml:posList>35.66921366817129 139.7389044065235 26.691 35.66921556992847 139.73890422754621 26.691 35.66924802823813 139.73885808288483 26.691 35.66924788219855 139.73885576337523 26.691 35.66921366817129 139.7389044065235 26.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8954e048-cbc9-4cc1-ac17-517b403c708c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8954e048-cbc9-4cc1-ac17-517b403c708c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8954e048-cbc9-4cc1-ac17-517b403c708c">
											<gml:posList>35.66928886298962 139.73883835060406 26.691 35.66928900001582 139.73884067012546 26.691 35.66936776441936 139.73892418538256 26.691 35.66936962109924 139.73892399541234 26.691 35.66928886298962 139.73883835060406 26.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f76be80c-c1e7-4a28-90b1-13d7d83feba4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f76be80c-c1e7-4a28-90b1-13d7d83feba4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f76be80c-c1e7-4a28-90b1-13d7d83feba4">
											<gml:posList>35.66931308848916 139.73900644388252 26.04 35.66936776441936 139.73892418538256 26.04 35.66928900001582 139.73884067012546 26.04 35.66926440181307 139.73887548330072 26.04 35.66924802823813 139.73885808288483 26.04 35.66921556992847 139.73890422754621 26.04 35.66931308848916 139.73900644388252 26.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e144b2e2-8e63-4a07-939f-b209aa6aa7f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e144b2e2-8e63-4a07-939f-b209aa6aa7f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e144b2e2-8e63-4a07-939f-b209aa6aa7f5">
											<gml:posList>35.66931326158433 139.73900878545467 26.691 35.66931308848916 139.73900644388252 26.691 35.66921556992847 139.73890422754621 26.691 35.66921366817129 139.7389044065235 26.691 35.66931326158433 139.73900878545467 26.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b3075757-268c-4450-b70c-d070026cbbe3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3075757-268c-4450-b70c-d070026cbbe3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3075757-268c-4450-b70c-d070026cbbe3">
											<gml:posList>35.66936962109924 139.73892399541234 26.691 35.66936776441936 139.73892418538256 26.691 35.66931308848916 139.73900644388252 26.691 35.66931326158433 139.73900878545467 26.691 35.66936962109924 139.73892399541234 26.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb5dbc37-3761-4577-94ee-e85e89303d38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb5dbc37-3761-4577-94ee-e85e89303d38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb5dbc37-3761-4577-94ee-e85e89303d38">
											<gml:posList>35.66936962109924 139.73892399541234 15.31 35.66928886298962 139.73883835060406 15.31 35.66928886298962 139.73883835060406 26.691 35.66936962109924 139.73892399541234 26.691 35.66936962109924 139.73892399541234 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1fb624db-6ad5-4119-ab89-9eeb037434e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1fb624db-6ad5-4119-ab89-9eeb037434e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1fb624db-6ad5-4119-ab89-9eeb037434e6">
											<gml:posList>35.66928900001582 139.73884067012546 26.691 35.66928900001582 139.73884067012546 26.04 35.66936776441936 139.73892418538256 26.04 35.66936776441936 139.73892418538256 26.691 35.66928900001582 139.73884067012546 26.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8590b333-3a70-49d0-a8d7-b074c6d9cf41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8590b333-3a70-49d0-a8d7-b074c6d9cf41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8590b333-3a70-49d0-a8d7-b074c6d9cf41">
											<gml:posList>35.66928886298962 139.73883835060406 15.31 35.66926425576514 139.7388731527445 15.31 35.66926425576514 139.7388731527445 26.691 35.66928886298962 139.73883835060406 26.691 35.66928886298962 139.73883835060406 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-faecaf5d-9ccb-4c07-a9a6-a7866e206209">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-faecaf5d-9ccb-4c07-a9a6-a7866e206209">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-faecaf5d-9ccb-4c07-a9a6-a7866e206209">
											<gml:posList>35.66926440181307 139.73887548330072 26.691 35.66926440181307 139.73887548330072 26.04 35.66928900001582 139.73884067012546 26.04 35.66928900001582 139.73884067012546 26.691 35.66926440181307 139.73887548330072 26.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99cfcb88-f5f0-45af-b589-ccc1709afd99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99cfcb88-f5f0-45af-b589-ccc1709afd99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99cfcb88-f5f0-45af-b589-ccc1709afd99">
											<gml:posList>35.66926425576514 139.7388731527445 15.31 35.66924788219855 139.73885576337523 15.31 35.66924788219855 139.73885576337523 26.691 35.66926425576514 139.7388731527445 26.691 35.66926425576514 139.7388731527445 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b7439a2-ea49-4af3-a787-ea1374ef3f17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b7439a2-ea49-4af3-a787-ea1374ef3f17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b7439a2-ea49-4af3-a787-ea1374ef3f17">
											<gml:posList>35.66924802823813 139.73885808288483 26.691 35.66924802823813 139.73885808288483 26.04 35.66926440181307 139.73887548330072 26.04 35.66926440181307 139.73887548330072 26.691 35.66924802823813 139.73885808288483 26.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74dc209e-c4c8-4f36-86a8-c74e5da0a647">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74dc209e-c4c8-4f36-86a8-c74e5da0a647">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74dc209e-c4c8-4f36-86a8-c74e5da0a647">
											<gml:posList>35.66924788219855 139.73885576337523 15.31 35.66921366817129 139.7389044065235 15.31 35.66921366817129 139.7389044065235 26.691 35.66924788219855 139.73885576337523 26.691 35.66924788219855 139.73885576337523 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-894b6363-8799-44b3-99e4-7df58bc879af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-894b6363-8799-44b3-99e4-7df58bc879af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-894b6363-8799-44b3-99e4-7df58bc879af">
											<gml:posList>35.66921556992847 139.73890422754621 26.691 35.66921556992847 139.73890422754621 26.04 35.66924802823813 139.73885808288483 26.04 35.66924802823813 139.73885808288483 26.691 35.66921556992847 139.73890422754621 26.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3665e2c-f50c-4094-ab01-6b19574f35ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3665e2c-f50c-4094-ab01-6b19574f35ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3665e2c-f50c-4094-ab01-6b19574f35ac">
											<gml:posList>35.66931308848916 139.73900644388252 26.691 35.66931308848916 139.73900644388252 26.04 35.66921556992847 139.73890422754621 26.04 35.66921556992847 139.73890422754621 26.691 35.66931308848916 139.73900644388252 26.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00829150-6f26-478d-a6fc-4738635b260f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00829150-6f26-478d-a6fc-4738635b260f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00829150-6f26-478d-a6fc-4738635b260f">
											<gml:posList>35.66921366817129 139.7389044065235 15.31 35.66931326158433 139.73900878545467 15.31 35.66931326158433 139.73900878545467 26.691 35.66921366817129 139.7389044065235 26.691 35.66921366817129 139.7389044065235 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b510e251-a4a2-4940-8348-fcb3d7d700de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b510e251-a4a2-4940-8348-fcb3d7d700de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b510e251-a4a2-4940-8348-fcb3d7d700de">
											<gml:posList>35.66936776441936 139.73892418538256 26.691 35.66936776441936 139.73892418538256 26.04 35.66931308848916 139.73900644388252 26.04 35.66931308848916 139.73900644388252 26.691 35.66936776441936 139.73892418538256 26.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-effdcb5b-7c3e-406c-93bf-79eb43b5257f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-effdcb5b-7c3e-406c-93bf-79eb43b5257f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-effdcb5b-7c3e-406c-93bf-79eb43b5257f">
											<gml:posList>35.66931326158433 139.73900878545467 15.31 35.66936962109924 139.73892399541234 15.31 35.66936962109924 139.73892399541234 26.691 35.66931326158433 139.73900878545467 26.691 35.66931326158433 139.73900878545467 15.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1742</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">159.23965</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>