<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8f6cc851-e6b5-44fe-8260-0629a1d3c794">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66766015866931 139.7423325369123 0 35.66768326136234 139.74234511405191 0 35.66769388444439 139.74231581934444 0 35.66770273957294 139.74232063634736 0 35.667724480445266 139.74226068769718 0 35.66769697729847 139.7422458069831 0 35.667691756278224 139.74224307353344 0 35.66766015866931 139.7423325369123 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66766015866931 139.7423325369123 28.709 35.667691756278224 139.74224307353344 28.709 35.66769697729847 139.7422458069831 28.709 35.667724480445266 139.74226068769718 28.709 35.66770273957294 139.74232063634736 28.709 35.66769388444439 139.74231581934444 28.709 35.66768326136234 139.74234511405191 28.709 35.66766015866931 139.7423325369123 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66766015866931 139.7423325369123 28.709 35.66768326136234 139.74234511405191 28.709 35.66768326136234 139.74234511405191 31.709 35.66766015866931 139.7423325369123 31.709 35.66766015866931 139.7423325369123 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66768326136234 139.74234511405191 28.709 35.66769388444439 139.74231581934444 28.709 35.66769388444439 139.74231581934444 31.709 35.66768326136234 139.74234511405191 31.709 35.66768326136234 139.74234511405191 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66769388444439 139.74231581934444 28.709 35.66770273957294 139.74232063634736 28.709 35.66770273957294 139.74232063634736 31.709 35.66769388444439 139.74231581934444 31.709 35.66769388444439 139.74231581934444 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66770273957294 139.74232063634736 28.709 35.667724480445266 139.74226068769718 28.709 35.667724480445266 139.74226068769718 31.709 35.66770273957294 139.74232063634736 31.709 35.66770273957294 139.74232063634736 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667724480445266 139.74226068769718 28.709 35.66769697729847 139.7422458069831 28.709 35.66769697729847 139.7422458069831 31.709 35.667724480445266 139.74226068769718 31.709 35.667724480445266 139.74226068769718 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66769697729847 139.7422458069831 28.709 35.667691756278224 139.74224307353344 28.709 35.667691756278224 139.74224307353344 31.709 35.66769697729847 139.7422458069831 31.709 35.66769697729847 139.7422458069831 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667691756278224 139.74224307353344 28.709 35.66766015866931 139.7423325369123 28.709 35.66766015866931 139.7423325369123 31.709 35.667691756278224 139.74224307353344 31.709 35.667691756278224 139.74224307353344 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66766015866931 139.7423325369123 31.709 35.66768326136234 139.74234511405191 31.709 35.66769388444439 139.74231581934444 31.709 35.66770273957294 139.74232063634736 31.709 35.667724480445266 139.74226068769718 31.709 35.66769697729847 139.7422458069831 31.709 35.667691756278224 139.74224307353344 31.709 35.66766015866931 139.7423325369123 31.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0203032c-3be0-4081-a874-ed34d450a3dd"/>
							<gml:surfaceMember xlink:href="#poly-d1343f5e-2276-436b-8a22-d61f76254edc"/>
							<gml:surfaceMember xlink:href="#poly-6351f479-ddf4-4a8d-995d-9be2d311b6bf"/>
							<gml:surfaceMember xlink:href="#poly-6d131983-25c5-4cad-a5ae-6fa1f818f576"/>
							<gml:surfaceMember xlink:href="#poly-2b80742f-e2ce-4254-b343-5253bf68f59e"/>
							<gml:surfaceMember xlink:href="#poly-cd55bc8e-f673-4ce3-837a-0a0f5c436d0d"/>
							<gml:surfaceMember xlink:href="#poly-1c6d0be5-96f5-48b2-a5ef-567528db1fc3"/>
							<gml:surfaceMember xlink:href="#poly-b973bb24-0293-41b3-9697-2c1c18f241dd"/>
							<gml:surfaceMember xlink:href="#poly-7786a6eb-c473-4da8-9d0f-43042820b03d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0203032c-3be0-4081-a874-ed34d450a3dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0203032c-3be0-4081-a874-ed34d450a3dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0203032c-3be0-4081-a874-ed34d450a3dd">
											<gml:posList>35.6676601586693 139.7423325369123 28.709 35.667691756278224 139.74224307353344 28.709 35.667696977298455 139.7422458069831 28.709 35.667724480445266 139.74226068769718 28.709 35.66770273957292 139.74232063634736 28.709 35.667693884444375 139.74231581934444 28.709 35.667683261362335 139.7423451140519 28.709 35.6676601586693 139.7423325369123 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1343f5e-2276-436b-8a22-d61f76254edc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1343f5e-2276-436b-8a22-d61f76254edc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1343f5e-2276-436b-8a22-d61f76254edc">
											<gml:posList>35.667693884444375 139.74231581934444 31.461 35.66770273957292 139.74232063634736 31.461 35.667724480445266 139.74226068769718 31.461 35.667696977298455 139.7422458069831 31.461 35.667691756278224 139.74224307353344 31.461 35.6676601586693 139.7423325369123 31.461 35.667683261362335 139.7423451140519 31.461 35.667693884444375 139.74231581934444 31.461</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6351f479-ddf4-4a8d-995d-9be2d311b6bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6351f479-ddf4-4a8d-995d-9be2d311b6bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6351f479-ddf4-4a8d-995d-9be2d311b6bf">
											<gml:posList>35.667696977298455 139.7422458069831 28.709 35.667691756278224 139.74224307353344 28.709 35.667691756278224 139.74224307353344 31.461 35.667696977298455 139.7422458069831 31.461 35.667696977298455 139.7422458069831 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d131983-25c5-4cad-a5ae-6fa1f818f576">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d131983-25c5-4cad-a5ae-6fa1f818f576">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d131983-25c5-4cad-a5ae-6fa1f818f576">
											<gml:posList>35.667724480445266 139.74226068769718 28.709 35.667696977298455 139.7422458069831 28.709 35.667696977298455 139.7422458069831 31.461 35.667724480445266 139.74226068769718 31.461 35.667724480445266 139.74226068769718 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b80742f-e2ce-4254-b343-5253bf68f59e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b80742f-e2ce-4254-b343-5253bf68f59e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b80742f-e2ce-4254-b343-5253bf68f59e">
											<gml:posList>35.667691756278224 139.74224307353344 28.709 35.6676601586693 139.7423325369123 28.709 35.6676601586693 139.7423325369123 31.461 35.667691756278224 139.74224307353344 31.461 35.667691756278224 139.74224307353344 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd55bc8e-f673-4ce3-837a-0a0f5c436d0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd55bc8e-f673-4ce3-837a-0a0f5c436d0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd55bc8e-f673-4ce3-837a-0a0f5c436d0d">
											<gml:posList>35.66770273957292 139.74232063634736 28.709 35.667724480445266 139.74226068769718 28.709 35.667724480445266 139.74226068769718 31.461 35.66770273957292 139.74232063634736 31.461 35.66770273957292 139.74232063634736 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c6d0be5-96f5-48b2-a5ef-567528db1fc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c6d0be5-96f5-48b2-a5ef-567528db1fc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c6d0be5-96f5-48b2-a5ef-567528db1fc3">
											<gml:posList>35.667693884444375 139.74231581934444 28.709 35.66770273957292 139.74232063634736 28.709 35.66770273957292 139.74232063634736 31.461 35.667693884444375 139.74231581934444 31.461 35.667693884444375 139.74231581934444 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b973bb24-0293-41b3-9697-2c1c18f241dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b973bb24-0293-41b3-9697-2c1c18f241dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b973bb24-0293-41b3-9697-2c1c18f241dd">
											<gml:posList>35.667683261362335 139.7423451140519 28.709 35.667693884444375 139.74231581934444 28.709 35.667693884444375 139.74231581934444 31.461 35.667683261362335 139.7423451140519 31.461 35.667683261362335 139.7423451140519 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7786a6eb-c473-4da8-9d0f-43042820b03d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7786a6eb-c473-4da8-9d0f-43042820b03d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7786a6eb-c473-4da8-9d0f-43042820b03d">
											<gml:posList>35.6676601586693 139.7423325369123 28.709 35.667683261362335 139.7423451140519 28.709 35.667683261362335 139.7423451140519 31.461 35.6676601586693 139.7423325369123 31.461 35.6676601586693 139.7423325369123 28.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6117</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>