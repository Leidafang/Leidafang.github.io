<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8fd20b4e-736f-4a2a-935b-9384118e7911">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>6</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001006</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">20.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668835881809514 139.7376221845219 0 35.66882532688392 139.73761104061563 0 35.668790662846824 139.73765990549546 0 35.66887943298275 139.73775435378334 0 35.668888256436624 139.7377417507644 0 35.66898108566151 139.73783995008583 0 35.66905446407217 139.73773470404615 0 35.66898842895829 139.73766596577823 0 35.66897639186865 139.73768392999693 0 35.66896297772934 139.7376704366626 0 35.66898760252038 139.73763549066462 0 35.668907123277506 139.73755030011745 0 35.668875791094194 139.73759507405612 0 35.668864153026085 139.73758205361278 0 35.668835881809514 139.7376221845219 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668835881809514 139.7376221845219 22.449 35.668864153026085 139.73758205361278 22.449 35.668875791094194 139.73759507405612 22.449 35.668907123277506 139.73755030011745 22.449 35.66898760252038 139.73763549066462 22.449 35.66896297772934 139.7376704366626 22.449 35.66897639186865 139.73768392999693 22.449 35.66898842895829 139.73766596577823 22.449 35.66905446407217 139.73773470404615 22.449 35.66898108566151 139.73783995008583 22.449 35.668888256436624 139.7377417507644 22.449 35.66887943298275 139.73775435378334 22.449 35.668790662846824 139.73765990549546 22.449 35.66882532688392 139.73761104061563 22.449 35.668835881809514 139.7376221845219 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668835881809514 139.7376221845219 22.449 35.66882532688392 139.73761104061563 22.449 35.66882532688392 139.73761104061563 43.03 35.668835881809514 139.7376221845219 43.03 35.668835881809514 139.7376221845219 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882532688392 139.73761104061563 22.449 35.668790662846824 139.73765990549546 22.449 35.668790662846824 139.73765990549546 43.03 35.66882532688392 139.73761104061563 43.03 35.66882532688392 139.73761104061563 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668790662846824 139.73765990549546 22.449 35.66887943298275 139.73775435378334 22.449 35.66887943298275 139.73775435378334 43.03 35.668790662846824 139.73765990549546 43.03 35.668790662846824 139.73765990549546 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887943298275 139.73775435378334 22.449 35.668888256436624 139.7377417507644 22.449 35.668888256436624 139.7377417507644 43.03 35.66887943298275 139.73775435378334 43.03 35.66887943298275 139.73775435378334 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668888256436624 139.7377417507644 22.449 35.66898108566151 139.73783995008583 22.449 35.66898108566151 139.73783995008583 43.03 35.668888256436624 139.7377417507644 43.03 35.668888256436624 139.7377417507644 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898108566151 139.73783995008583 22.449 35.66905446407217 139.73773470404615 22.449 35.66905446407217 139.73773470404615 43.03 35.66898108566151 139.73783995008583 43.03 35.66898108566151 139.73783995008583 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66905446407217 139.73773470404615 22.449 35.66898842895829 139.73766596577823 22.449 35.66898842895829 139.73766596577823 43.03 35.66905446407217 139.73773470404615 43.03 35.66905446407217 139.73773470404615 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898842895829 139.73766596577823 22.449 35.66897639186865 139.73768392999693 22.449 35.66897639186865 139.73768392999693 43.03 35.66898842895829 139.73766596577823 43.03 35.66898842895829 139.73766596577823 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66897639186865 139.73768392999693 22.449 35.66896297772934 139.7376704366626 22.449 35.66896297772934 139.7376704366626 43.03 35.66897639186865 139.73768392999693 43.03 35.66897639186865 139.73768392999693 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66896297772934 139.7376704366626 22.449 35.66898760252038 139.73763549066462 22.449 35.66898760252038 139.73763549066462 43.03 35.66896297772934 139.7376704366626 43.03 35.66896297772934 139.7376704366626 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898760252038 139.73763549066462 22.449 35.668907123277506 139.73755030011745 22.449 35.668907123277506 139.73755030011745 43.03 35.66898760252038 139.73763549066462 43.03 35.66898760252038 139.73763549066462 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668907123277506 139.73755030011745 22.449 35.668875791094194 139.73759507405612 22.449 35.668875791094194 139.73759507405612 43.03 35.668907123277506 139.73755030011745 43.03 35.668907123277506 139.73755030011745 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668875791094194 139.73759507405612 22.449 35.668864153026085 139.73758205361278 22.449 35.668864153026085 139.73758205361278 43.03 35.668875791094194 139.73759507405612 43.03 35.668875791094194 139.73759507405612 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668864153026085 139.73758205361278 22.449 35.668835881809514 139.7376221845219 22.449 35.668835881809514 139.7376221845219 43.03 35.668864153026085 139.73758205361278 43.03 35.668864153026085 139.73758205361278 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668835881809514 139.7376221845219 43.03 35.66882532688392 139.73761104061563 43.03 35.668790662846824 139.73765990549546 43.03 35.66887943298275 139.73775435378334 43.03 35.668888256436624 139.7377417507644 43.03 35.66898108566151 139.73783995008583 43.03 35.66905446407217 139.73773470404615 43.03 35.66898842895829 139.73766596577823 43.03 35.66897639186865 139.73768392999693 43.03 35.66896297772934 139.7376704366626 43.03 35.66898760252038 139.73763549066462 43.03 35.668907123277506 139.73755030011745 43.03 35.668875791094194 139.73759507405612 43.03 35.668864153026085 139.73758205361278 43.03 35.668835881809514 139.7376221845219 43.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-06f6d188-1951-457c-b4c3-04c385483cea"/>
							<gml:surfaceMember xlink:href="#poly-ee951256-0619-4d6d-b530-ea245959e12a"/>
							<gml:surfaceMember xlink:href="#poly-20801969-9974-45d1-af02-0a9493acdccb"/>
							<gml:surfaceMember xlink:href="#poly-cedf9e58-7a28-41ac-ab36-2469ebab12a8"/>
							<gml:surfaceMember xlink:href="#poly-2ac0eef3-89f3-4cb0-8821-f340d264e31e"/>
							<gml:surfaceMember xlink:href="#poly-33df184b-e480-4a80-a17e-6396757436fb"/>
							<gml:surfaceMember xlink:href="#poly-b7acd52f-713a-4dc7-9be3-190afe5548fa"/>
							<gml:surfaceMember xlink:href="#poly-03d1d21d-8b3b-4b87-820d-f01603b09463"/>
							<gml:surfaceMember xlink:href="#poly-135dc7e0-a05b-4548-bbb7-63fb62c98984"/>
							<gml:surfaceMember xlink:href="#poly-931c9563-ac21-4d95-b647-913fce91d030"/>
							<gml:surfaceMember xlink:href="#poly-178c5a18-379a-4350-b00b-f075a407a448"/>
							<gml:surfaceMember xlink:href="#poly-80372a54-ac66-400f-ac1f-f5c8329bdc3a"/>
							<gml:surfaceMember xlink:href="#poly-587ecfcc-d3af-458c-a14d-4e535541235d"/>
							<gml:surfaceMember xlink:href="#poly-40fb7db5-7494-4d3c-914a-ccf78d924fc4"/>
							<gml:surfaceMember xlink:href="#poly-89d93985-d5d9-439b-af3c-2cc5ddf57ae0"/>
							<gml:surfaceMember xlink:href="#poly-9991d18d-ea3f-4275-8cca-ed6e6dd3208b"/>
							<gml:surfaceMember xlink:href="#poly-e9272a07-c496-4f09-8769-7efc947adc88"/>
							<gml:surfaceMember xlink:href="#poly-ee182839-ef94-4e2d-a753-24af9a631da1"/>
							<gml:surfaceMember xlink:href="#poly-e10b08c3-ddc4-4ee1-bbd2-847258a01a73"/>
							<gml:surfaceMember xlink:href="#poly-3ef8b743-c4ae-4b76-a037-8f1a36881df5"/>
							<gml:surfaceMember xlink:href="#poly-69601887-65d2-4134-94b5-1ffbd5d43c7c"/>
							<gml:surfaceMember xlink:href="#poly-db6eba9d-d291-47aa-85e3-ddc7f4063854"/>
							<gml:surfaceMember xlink:href="#poly-5832fdaf-a3c6-4d7b-b3c2-52336ca81b1c"/>
							<gml:surfaceMember xlink:href="#poly-1b74e1cf-0bb9-44eb-b675-13bea9ca759f"/>
							<gml:surfaceMember xlink:href="#poly-d8a35d07-3be9-4198-b44b-34f3afc6424d"/>
							<gml:surfaceMember xlink:href="#poly-c0fd2ce4-9627-43df-a046-ac90b8b0dc50"/>
							<gml:surfaceMember xlink:href="#poly-2308ad01-ed0e-4761-bf1d-0ac7998b5926"/>
							<gml:surfaceMember xlink:href="#poly-a795fb12-4df4-4933-98bf-b382c530e17a"/>
							<gml:surfaceMember xlink:href="#poly-a4ac1587-6999-4d42-a651-17da3f0a8779"/>
							<gml:surfaceMember xlink:href="#poly-55131c17-a18a-4d96-99e5-8f5e736516f4"/>
							<gml:surfaceMember xlink:href="#poly-0632fc80-ea88-432f-9add-0fe2b857a8b6"/>
							<gml:surfaceMember xlink:href="#poly-c2898d05-ba15-49b3-a49f-bfea4f867063"/>
							<gml:surfaceMember xlink:href="#poly-5fcc723d-eb5b-4c9f-8c66-35f836599644"/>
							<gml:surfaceMember xlink:href="#poly-3582ad88-6f03-49f5-a4f4-4aa2e7ee6e59"/>
							<gml:surfaceMember xlink:href="#poly-4f50993c-1bf8-41e0-94d9-9ce28bba2aad"/>
							<gml:surfaceMember xlink:href="#poly-9251f488-7969-4c00-898d-875ecd2f97a3"/>
							<gml:surfaceMember xlink:href="#poly-7d4520b2-451e-4d15-9f6a-371866379da2"/>
							<gml:surfaceMember xlink:href="#poly-d2f3488e-356e-434f-9c04-05a54bd86732"/>
							<gml:surfaceMember xlink:href="#poly-0a389a15-ff65-4b19-bd47-a385c12c5c58"/>
							<gml:surfaceMember xlink:href="#poly-0c849b9d-5209-4b4b-8f51-b23e807f7673"/>
							<gml:surfaceMember xlink:href="#poly-fff125a4-e5df-44c7-9f63-e736b4233268"/>
							<gml:surfaceMember xlink:href="#poly-906428ee-b701-4226-a591-2615c0078677"/>
							<gml:surfaceMember xlink:href="#poly-69b5032d-9a52-4bf5-9707-321530f9de28"/>
							<gml:surfaceMember xlink:href="#poly-26a880d2-2c9c-4af6-b714-eefcca8f2697"/>
							<gml:surfaceMember xlink:href="#poly-85e1a7bd-8830-4a5d-93ee-0dba1465a145"/>
							<gml:surfaceMember xlink:href="#poly-482a3a5c-6b8b-4685-96b5-ef9fa52c6971"/>
							<gml:surfaceMember xlink:href="#poly-26eace4d-68d2-4fbc-a206-2f3496ed532f"/>
							<gml:surfaceMember xlink:href="#poly-ddfcc1ad-41d0-4855-8491-9fc012101265"/>
							<gml:surfaceMember xlink:href="#poly-9b586c02-fe8f-4670-a22c-236dc7a0e3e0"/>
							<gml:surfaceMember xlink:href="#poly-034471be-7451-42bd-825f-88f66ebe2d27"/>
							<gml:surfaceMember xlink:href="#poly-4a7263ac-872b-4f98-8071-f9be5b833df7"/>
							<gml:surfaceMember xlink:href="#poly-67d73a57-090a-4e38-9b79-32c13a1f3a6a"/>
							<gml:surfaceMember xlink:href="#poly-12f601d5-6304-475f-951f-f1a505a55ad1"/>
							<gml:surfaceMember xlink:href="#poly-07b174c9-a870-4f4c-bb3f-6f8521a00ea7"/>
							<gml:surfaceMember xlink:href="#poly-6270b4db-31b8-46b6-9de9-f3b6bb143d0c"/>
							<gml:surfaceMember xlink:href="#poly-e9c2fd95-1d5b-4243-ae11-be2472179b8b"/>
							<gml:surfaceMember xlink:href="#poly-f21aa04d-baf6-4587-a128-06633190f2d1"/>
							<gml:surfaceMember xlink:href="#poly-ddd3169f-7cfe-4859-a537-ac29693b8ec4"/>
							<gml:surfaceMember xlink:href="#poly-7913a0f0-f6ff-4232-adab-e5c1e50a91b4"/>
							<gml:surfaceMember xlink:href="#poly-1e62b3f0-8fb6-4fa7-aeb8-b9c8dcf18b6c"/>
							<gml:surfaceMember xlink:href="#poly-0af40bc0-6c6a-4ac2-a6e9-3b2934add7cb"/>
							<gml:surfaceMember xlink:href="#poly-dc292ce9-21cc-4058-95ed-d48045fcf904"/>
							<gml:surfaceMember xlink:href="#poly-89cafc5b-32cc-42f3-aecb-89e073936987"/>
							<gml:surfaceMember xlink:href="#poly-c0513755-4315-4e68-8215-fa4cd9ec53dd"/>
							<gml:surfaceMember xlink:href="#poly-0abec330-7785-4157-aa32-2913a788c3c7"/>
							<gml:surfaceMember xlink:href="#poly-7a362cba-043e-41ee-a849-1375d22ce030"/>
							<gml:surfaceMember xlink:href="#poly-667cfce0-108b-4938-959e-25b8e33c1edd"/>
							<gml:surfaceMember xlink:href="#poly-fddc5cc9-9a9e-42ac-b047-0d3220e4390a"/>
							<gml:surfaceMember xlink:href="#poly-0f6a4691-49d8-4788-ace9-705bda4c03b7"/>
							<gml:surfaceMember xlink:href="#poly-346aac5e-8052-45d0-8810-6c761644f557"/>
							<gml:surfaceMember xlink:href="#poly-a2d0a44e-77aa-4a91-a99e-291d1292fdbd"/>
							<gml:surfaceMember xlink:href="#poly-c7734812-e309-4d97-b913-cac1cdc72800"/>
							<gml:surfaceMember xlink:href="#poly-8b549882-e01b-4121-acbb-8c958841a449"/>
							<gml:surfaceMember xlink:href="#poly-99e7ce30-6120-4550-a55b-96579a75c4ac"/>
							<gml:surfaceMember xlink:href="#poly-fa55a8c2-6dbf-4e64-9c67-e8881338de0a"/>
							<gml:surfaceMember xlink:href="#poly-edbdd86c-4b97-4c42-a422-65a4edb402e3"/>
							<gml:surfaceMember xlink:href="#poly-48f3595c-d09a-4438-a376-411ff0a82057"/>
							<gml:surfaceMember xlink:href="#poly-7321a288-c871-45f9-8a87-87ca0967d739"/>
							<gml:surfaceMember xlink:href="#poly-2349f693-da5b-40a3-8f1a-24af7228a260"/>
							<gml:surfaceMember xlink:href="#poly-923d6c3a-2174-4d2e-bf41-89f109143f65"/>
							<gml:surfaceMember xlink:href="#poly-3f6058a2-8ab8-46c1-bef6-17ad2d3dc29f"/>
							<gml:surfaceMember xlink:href="#poly-1d5e97f9-6a9b-4327-b981-0afddeb18c22"/>
							<gml:surfaceMember xlink:href="#poly-78aba2b1-6b4b-4ced-833a-15af293d77c7"/>
							<gml:surfaceMember xlink:href="#poly-bfda7f3c-5e83-427e-910b-8353b5b3e700"/>
							<gml:surfaceMember xlink:href="#poly-fe8f2ddd-615c-4491-8153-98777f0e9474"/>
							<gml:surfaceMember xlink:href="#poly-9a5cf4e3-56c7-4c69-a1e5-3115ebb51170"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8fd20b4e-736f-4a2a-935b-9384118e7911_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa44ef64-db25-48df-820b-d1336afff78f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894816141442 139.73766193782592 45.697 35.66895625320153 139.7376700801654 45.697 35.66894985202533 139.7376796316002 45.697 35.66894176023885 139.73767148926035 45.697 35.66894816141442 139.73766193782592 45.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-400bfdde-651f-4d3d-9e48-3805874a87ba">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66895680314216 139.7376815563688 45.697 35.6689571362551 139.73768105889857 45.697 35.668966292511406 139.73769027143945 45.697 35.66896041350674 139.7376990379805 45.697 35.66895178046822 139.7376903550262 45.697 35.668951257251095 139.7376898254393 45.697 35.66895680314216 139.7376815563688 45.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-729a2618-8d36-4923-a9f7-0dd8ac014c9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-729a2618-8d36-4923-a9f7-0dd8ac014c9b_0">
											<gml:posList>35.66894816141442 139.73766193782592 45.697 35.66894816141442 139.73766193782592 47.082 35.66895625320153 139.7376700801654 47.082 35.66895625320153 139.7376700801654 45.697 35.66894816141442 139.73766193782592 45.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a33477b0-4c1d-475c-95ca-4e524387aa5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a33477b0-4c1d-475c-95ca-4e524387aa5e_0">
											<gml:posList>35.66894176023885 139.73767148926035 45.697 35.66894176023885 139.73767148926035 47.082 35.66894816141442 139.73766193782592 47.082 35.66894816141442 139.73766193782592 45.697 35.66894176023885 139.73767148926035 45.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6165f867-c93f-4a57-b3a8-d7620183bbce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6165f867-c93f-4a57-b3a8-d7620183bbce_0">
											<gml:posList>35.66894985202533 139.7376796316002 47.082 35.66895625320153 139.7376700801654 47.082 35.66894816141442 139.73766193782592 47.082 35.66894176023885 139.73767148926035 47.082 35.66894985202533 139.7376796316002 47.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de524ecd-c65a-4c72-8008-44456a25acca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de524ecd-c65a-4c72-8008-44456a25acca_0">
											<gml:posList>35.66895625320153 139.7376700801654 47.082 35.66894985202533 139.7376796316002 47.082 35.66894985202533 139.7376796316002 45.697 35.66895625320153 139.7376700801654 45.697 35.66895625320153 139.7376700801654 47.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9dbbd18f-e86c-4633-a592-886a23da71ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9dbbd18f-e86c-4633-a592-886a23da71ef_0">
											<gml:posList>35.66894985202533 139.7376796316002 45.697 35.66894985202533 139.7376796316002 47.082 35.66894176023885 139.73767148926035 47.082 35.66894176023885 139.73767148926035 45.697 35.66894985202533 139.7376796316002 45.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1e2cd6a-97a0-4fa7-949f-86fed2ed0f94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1e2cd6a-97a0-4fa7-949f-86fed2ed0f94_0">
											<gml:posList>35.6689571362551 139.73768105889857 45.697 35.66895680314216 139.7376815563688 45.697 35.6689571362551 139.73768105889857 47.082 35.6689571362551 139.73768105889857 45.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e1b4bc0-a845-4442-8eff-e0927f5d7e10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e1b4bc0-a845-4442-8eff-e0927f5d7e10_0">
											<gml:posList>35.66895680314216 139.7376815563688 45.697 35.668951257251095 139.7376898254393 45.697 35.668951257251095 139.7376898254393 47.082 35.6689571362551 139.73768105889857 47.082 35.66895680314216 139.7376815563688 45.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6527fe7-d65d-4871-ae46-a94e1d5f965d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6527fe7-d65d-4871-ae46-a94e1d5f965d_0">
											<gml:posList>35.668966292511406 139.73769027143945 45.697 35.6689571362551 139.73768105889857 45.697 35.6689571362551 139.73768105889857 47.082 35.668966292511406 139.73769027143945 47.082 35.668966292511406 139.73769027143945 45.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d7e338e-a620-4e74-a1ae-dd092c4b3ab4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d7e338e-a620-4e74-a1ae-dd092c4b3ab4_0">
											<gml:posList>35.6689571362551 139.73768105889857 47.082 35.668951257251095 139.7376898254393 47.082 35.66896041350674 139.7376990379805 47.082 35.668966292511406 139.73769027143945 47.082 35.6689571362551 139.73768105889857 47.082</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad3d3a6e-f848-4111-8d55-0f484c8886d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad3d3a6e-f848-4111-8d55-0f484c8886d5_0">
											<gml:posList>35.668951257251095 139.7376898254393 45.697 35.66895178046822 139.7376903550262 45.697 35.668951257251095 139.7376898254393 47.082 35.668951257251095 139.7376898254393 45.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7b48927-4202-46ba-a17c-742167e3483e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7b48927-4202-46ba-a17c-742167e3483e_0">
											<gml:posList>35.66895178046822 139.7376903550262 45.697 35.66896041350674 139.7376990379805 45.697 35.66896041350674 139.7376990379805 47.082 35.668951257251095 139.7376898254393 47.082 35.66895178046822 139.7376903550262 45.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-913f1c6e-2f53-42fd-88c3-b10db662411a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-913f1c6e-2f53-42fd-88c3-b10db662411a_0">
											<gml:posList>35.66896041350674 139.7376990379805 45.697 35.668966292511406 139.73769027143945 45.697 35.668966292511406 139.73769027143945 47.082 35.66896041350674 139.7376990379805 47.082 35.66896041350674 139.7376990379805 45.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8fd20b4e-736f-4a2a-935b-9384118e7911_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53435ae1-c448-485a-ab5c-162b23f08ad5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66896297772053 139.73767042561656 22.449 35.66898761153409 139.73763549065387 22.449 35.66900031355798 139.737648940652 22.449 35.66898842895828 139.73766596577823 22.449 35.66897639186864 139.73768392999693 22.449 35.66896297772053 139.73767042561656 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e5961e9-8ba8-48f9-ac8a-b03ba1ae6d81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e5961e9-8ba8-48f9-ac8a-b03ba1ae6d81_0">
											<gml:posList>35.66896297772053 139.73767042561656 46.29 35.66896297772053 139.73767042561656 22.449 35.66897639186864 139.73768392999693 22.449 35.66897639186864 139.73768392999693 46.29 35.66896297772053 139.73767042561656 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80429008-4a02-4bc6-93f0-5730816b4983">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80429008-4a02-4bc6-93f0-5730816b4983_0">
											<gml:posList>35.66898761153409 139.73763549065387 46.29 35.66898761153409 139.73763549065387 22.449 35.66896297772053 139.73767042561656 22.449 35.66896297772053 139.73767042561656 46.29 35.66898761153409 139.73763549065387 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4703d02d-6511-4a3b-b93e-7debb611249e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4703d02d-6511-4a3b-b93e-7debb611249e_0">
											<gml:posList>35.66896297772053 139.73767042561656 46.29 35.66897639186864 139.73768392999693 46.29 35.66898842895828 139.73766596577823 46.29 35.66900031355798 139.737648940652 46.29 35.66898761153409 139.73763549065387 46.29 35.66896297772053 139.73767042561656 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-724d20da-3c5b-43a9-b370-96e2afaf085a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-724d20da-3c5b-43a9-b370-96e2afaf085a_0">
											<gml:posList>35.66897639186864 139.73768392999693 46.29 35.66897639186864 139.73768392999693 22.449 35.66898842895828 139.73766596577823 22.449 35.66898842895828 139.73766596577823 46.29 35.66897639186864 139.73768392999693 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ec2b09c-6f4e-43bf-8f5b-955c47033bda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ec2b09c-6f4e-43bf-8f5b-955c47033bda_0">
											<gml:posList>35.66900031355798 139.737648940652 46.29 35.66900031355798 139.737648940652 22.449 35.66898761153409 139.73763549065387 22.449 35.66898761153409 139.73763549065387 46.29 35.66900031355798 139.737648940652 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-772aaea4-99d7-4fc2-a227-951ad4a6a11d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-772aaea4-99d7-4fc2-a227-951ad4a6a11d_0">
											<gml:posList>35.66898842895828 139.73766596577823 46.29 35.66898842895828 139.73766596577823 22.449 35.66900031355798 139.737648940652 22.449 35.66900031355798 139.737648940652 46.29 35.66898842895828 139.73766596577823 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-06f6d188-1951-457c-b4c3-04c385483cea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06f6d188-1951-457c-b4c3-04c385483cea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06f6d188-1951-457c-b4c3-04c385483cea">
											<gml:posList>35.66879066284681 139.73765990549546 22.449 35.66882532688392 139.73761104061563 22.449 35.6688358818095 139.7376221845219 22.449 35.66886415302608 139.73758205361275 22.449 35.668875791094194 139.73759507405612 22.449 35.668907123277506 139.73755030011745 22.449 35.66898760252037 139.7376354906646 22.449 35.6689629777293 139.7376704366626 22.449 35.66897639186864 139.73768392999693 22.449 35.66898842895828 139.73766596577823 22.449 35.669054464072154 139.73773470404618 22.449 35.668981085661514 139.73783995008583 22.449 35.668888256436624 139.7377417507644 22.449 35.66887943298275 139.73775435378332 22.449 35.66879066284681 139.73765990549546 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee951256-0619-4d6d-b530-ea245959e12a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee951256-0619-4d6d-b530-ea245959e12a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee951256-0619-4d6d-b530-ea245959e12a">
											<gml:posList>35.66883866420856 139.73762994657153 43.445 35.66886429394201 139.7376572770471 43.446 35.668851636925964 139.73764374969437 43.446 35.66883866420856 139.73762994657153 43.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20801969-9974-45d1-af02-0a9493acdccb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20801969-9974-45d1-af02-0a9493acdccb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20801969-9974-45d1-af02-0a9493acdccb">
											<gml:posList>35.66882532688392 139.73761104061563 40.496 35.66879066284681 139.73765990549546 40.496 35.66881761073178 139.73765590781147 43.874 35.66882532688392 139.73761104061563 40.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cedf9e58-7a28-41ac-ab36-2469ebab12a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cedf9e58-7a28-41ac-ab36-2469ebab12a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cedf9e58-7a28-41ac-ab36-2469ebab12a8">
											<gml:posList>35.66881761073178 139.73765590781147 43.874 35.66883831763975 139.73762485475763 43.874 35.66882532688392 139.73761104061563 40.496 35.66881761073178 139.73765590781147 43.874</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ac0eef3-89f3-4cb0-8821-f340d264e31e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ac0eef3-89f3-4cb0-8821-f340d264e31e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ac0eef3-89f3-4cb0-8821-f340d264e31e">
											<gml:posList>35.66883831763975 139.73762485475763 43.874 35.66881761073178 139.73765590781147 43.874 35.66882169355393 139.73765540586763 43.873 35.66883867322228 139.7376299465608 43.873 35.66883831763975 139.73762485475763 43.874</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-33df184b-e480-4a80-a17e-6396757436fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33df184b-e480-4a80-a17e-6396757436fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33df184b-e480-4a80-a17e-6396757436fb">
											<gml:posList>35.66879066284681 139.73765990549546 40.496 35.6688758064056 139.73775050303416 40.496 35.66881761073178 139.73765590781147 43.874 35.66879066284681 139.73765990549546 40.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b7acd52f-713a-4dc7-9be3-190afe5548fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7acd52f-713a-4dc7-9be3-190afe5548fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7acd52f-713a-4dc7-9be3-190afe5548fa">
											<gml:posList>35.66885354570245 139.73764106322656 43.874 35.66883831763975 139.73762485475763 43.874 35.66883867322228 139.7376299465608 43.873 35.668851636925964 139.73764374969437 43.874 35.66885354570245 139.73764106322656 43.874</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03d1d21d-8b3b-4b87-820d-f01603b09463">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03d1d21d-8b3b-4b87-820d-f01603b09463">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03d1d21d-8b3b-4b87-820d-f01603b09463">
											<gml:posList>35.66886415302608 139.73758205361275 40.496 35.6688358818095 139.7376221845219 40.496 35.66885354570245 139.73764106322656 43.874 35.66886618467379 139.73765456850865 46.29 35.66886415302608 139.73758205361275 40.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-135dc7e0-a05b-4548-bbb7-63fb62c98984">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-135dc7e0-a05b-4548-bbb7-63fb62c98984">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-135dc7e0-a05b-4548-bbb7-63fb62c98984">
											<gml:posList>35.6688758064056 139.73775050303416 40.496 35.668890797472464 139.73772934301638 43.874 35.66881761073178 139.73765590781147 43.874 35.6688758064056 139.73775050303416 40.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-931c9563-ac21-4d95-b647-913fce91d030">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-931c9563-ac21-4d95-b647-913fce91d030">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-931c9563-ac21-4d95-b647-913fce91d030">
											<gml:posList>35.66881761073178 139.73765590781147 43.874 35.668890797472464 139.73772934301638 43.874 35.66889026157579 139.73772419619425 43.874 35.66882169355393 139.73765540586763 43.873 35.66881761073178 139.73765590781147 43.874</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-178c5a18-379a-4350-b00b-f075a407a448">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-178c5a18-379a-4350-b00b-f075a407a448">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-178c5a18-379a-4350-b00b-f075a407a448">
											<gml:posList>35.66883866420856 139.73762994657153 43.445 35.66882169355393 139.73765540586763 43.445 35.668890252562065 139.737724196205 43.446 35.66883866420856 139.73762994657153 43.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-80372a54-ac66-400f-ac1f-f5c8329bdc3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80372a54-ac66-400f-ac1f-f5c8329bdc3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80372a54-ac66-400f-ac1f-f5c8329bdc3a">
											<gml:posList>35.66886618467379 139.73765456850865 43.874 35.66885354570245 139.73764106322656 43.874 35.668851636925964 139.73764374969437 43.874 35.66886430295572 139.73765727703636 43.874 35.66886618467379 139.73765456850865 43.874</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-587ecfcc-d3af-458c-a14d-4e535541235d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-587ecfcc-d3af-458c-a14d-4e535541235d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-587ecfcc-d3af-458c-a14d-4e535541235d">
											<gml:posList>35.66883866420856 139.73762994657153 43.445 35.668890252562065 139.737724196205 43.446 35.66886429394201 139.7376572770471 43.446 35.66883866420856 139.73762994657153 43.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-40fb7db5-7494-4d3c-914a-ccf78d924fc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40fb7db5-7494-4d3c-914a-ccf78d924fc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40fb7db5-7494-4d3c-914a-ccf78d924fc4">
											<gml:posList>35.668875791094194 139.73759507405612 40.496 35.66886415302608 139.73758205361275 40.496 35.66889784774398 139.73760646934102 46.29 35.668875791094194 139.73759507405612 40.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-89d93985-d5d9-439b-af3c-2cc5ddf57ae0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89d93985-d5d9-439b-af3c-2cc5ddf57ae0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89d93985-d5d9-439b-af3c-2cc5ddf57ae0">
											<gml:posList>35.66889784774398 139.73760646934102 46.29 35.66886415302608 139.73758205361275 40.496 35.66886618467379 139.73765456850865 46.29 35.66889784774398 139.73760646934102 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9991d18d-ea3f-4275-8cca-ed6e6dd3208b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9991d18d-ea3f-4275-8cca-ed6e6dd3208b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9991d18d-ea3f-4275-8cca-ed6e6dd3208b">
											<gml:posList>35.668890252562065 139.737724196205 43.446 35.668899155224025 139.73770918504658 43.418 35.66886429394201 139.7376572770471 43.446 35.668890252562065 139.737724196205 43.446</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e9272a07-c496-4f09-8769-7efc947adc88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9272a07-c496-4f09-8769-7efc947adc88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9272a07-c496-4f09-8769-7efc947adc88">
											<gml:posList>35.66889784774398 139.73760646934102 46.29 35.66886618467379 139.73765456850865 46.29 35.66887068209211 139.7376540218855 46.29 35.668898248861304 139.7376121465344 46.29 35.66889784774398 139.73760646934102 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee182839-ef94-4e2d-a753-24af9a631da1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee182839-ef94-4e2d-a753-24af9a631da1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee182839-ef94-4e2d-a753-24af9a631da1">
											<gml:posList>35.668899155224025 139.73770918504658 43.418 35.668905565232144 139.73769940164252 43.446 35.66886429394201 139.7376572770471 43.446 35.668899155224025 139.73770918504658 43.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e10b08c3-ddc4-4ee1-bbd2-847258a01a73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e10b08c3-ddc4-4ee1-bbd2-847258a01a73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e10b08c3-ddc4-4ee1-bbd2-847258a01a73">
											<gml:posList>35.66890962102203 139.73769891077862 43.874 35.66886618467379 139.73765456850865 43.874 35.66886430295572 139.73765727703636 43.874 35.66890556524092 139.73769941268856 43.874 35.66890962102203 139.73769891077862 43.874</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ef8b743-c4ae-4b76-a037-8f1a36881df5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ef8b743-c4ae-4b76-a037-8f1a36881df5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ef8b743-c4ae-4b76-a037-8f1a36881df5">
											<gml:posList>35.66886618467379 139.73765456850865 46.29 35.66890962102203 139.73769891077862 46.29 35.668911682752295 139.73769587065394 46.29 35.66887068209211 139.7376540218855 46.29 35.66886618467379 139.73765456850865 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-69601887-65d2-4134-94b5-1ffbd5d43c7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69601887-65d2-4134-94b5-1ffbd5d43c7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69601887-65d2-4134-94b5-1ffbd5d43c7c">
											<gml:posList>35.66887946903764 139.73775435374034 36.141 35.66890962102203 139.73769891077862 46.29 35.66890147347919 139.73771135835477 43.845 35.66887585147422 139.73775050298045 36.159 35.66887946903764 139.73775435374034 36.141</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-db6eba9d-d291-47aa-85e3-ddc7f4063854">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db6eba9d-d291-47aa-85e3-ddc7f4063854">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db6eba9d-d291-47aa-85e3-ddc7f4063854">
											<gml:posList>35.66889784774398 139.73760646934102 46.29 35.66890990036169 139.737619389884 46.29 35.668875791094194 139.73759507405612 40.496 35.66889784774398 139.73760646934102 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5832fdaf-a3c6-4d7b-b3c2-52336ca81b1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5832fdaf-a3c6-4d7b-b3c2-52336ca81b1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5832fdaf-a3c6-4d7b-b3c2-52336ca81b1c">
											<gml:posList>35.66890990036169 139.737619389884 46.29 35.668907123277506 139.73755030011745 40.496 35.668875791094194 139.73759507405612 40.496 35.66890990036169 139.737619389884 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b74e1cf-0bb9-44eb-b675-13bea9ca759f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b74e1cf-0bb9-44eb-b675-13bea9ca759f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b74e1cf-0bb9-44eb-b675-13bea9ca759f">
											<gml:posList>35.668899164246525 139.73770919608188 43.846 35.66889026157579 139.73772419619425 43.874 35.668890797472464 139.73772934301638 43.874 35.668899164246525 139.73770919608188 43.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d8a35d07-3be9-4198-b44b-34f3afc6424d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8a35d07-3be9-4198-b44b-34f3afc6424d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8a35d07-3be9-4198-b44b-34f3afc6424d">
											<gml:posList>35.668890797472464 139.73772934301638 43.874 35.66890147347919 139.73771135835477 43.845 35.668899164246525 139.73770919608188 43.846 35.668890797472464 139.73772934301638 43.874</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c0fd2ce4-9627-43df-a046-ac90b8b0dc50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0fd2ce4-9627-43df-a046-ac90b8b0dc50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0fd2ce4-9627-43df-a046-ac90b8b0dc50">
											<gml:posList>35.66890556524092 139.73769941268856 43.874 35.668899164246525 139.73770919608188 43.846 35.66890147347919 139.73771135835477 43.845 35.66890556524092 139.73769941268856 43.874</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2308ad01-ed0e-4761-bf1d-0ac7998b5926">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2308ad01-ed0e-4761-bf1d-0ac7998b5926">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2308ad01-ed0e-4761-bf1d-0ac7998b5926">
											<gml:posList>35.66890990036169 139.737619389884 46.29 35.66889784774398 139.73760646934102 46.29 35.668898248861304 139.7376121465344 46.29 35.668910310500905 139.73762507811358 46.29 35.66890990036169 139.737619389884 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a795fb12-4df4-4933-98bf-b382c530e17a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a795fb12-4df4-4933-98bf-b382c530e17a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a795fb12-4df4-4933-98bf-b382c530e17a">
											<gml:posList>35.66890147347919 139.73771135835477 43.845 35.66890962102203 139.73769891077862 43.874 35.66890556524092 139.73769941268856 43.874 35.66890147347919 139.73771135835477 43.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4ac1587-6999-4d42-a651-17da3f0a8779">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4ac1587-6999-4d42-a651-17da3f0a8779">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4ac1587-6999-4d42-a651-17da3f0a8779">
											<gml:posList>35.66890990036169 139.737619389884 46.29 35.66893546828538 139.73758030049473 46.29 35.668907123277506 139.73755030011745 40.496 35.66890990036169 139.737619389884 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-55131c17-a18a-4d96-99e5-8f5e736516f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55131c17-a18a-4d96-99e5-8f5e736516f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55131c17-a18a-4d96-99e5-8f5e736516f4">
											<gml:posList>35.66893546828538 139.73758030049473 46.29 35.66890990036169 139.737619389884 46.29 35.668910310500905 139.73762507811358 46.29 35.668935896436324 139.7375859666123 46.29 35.66893546828538 139.73758030049473 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0632fc80-ea88-432f-9add-0fe2b857a8b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0632fc80-ea88-432f-9add-0fe2b857a8b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0632fc80-ea88-432f-9add-0fe2b857a8b6">
											<gml:posList>35.66899362497309 139.73778466062694 46.29 35.66890962102203 139.73769891077862 46.29 35.66888826545034 139.73774175075366 36.092 35.668980905395784 139.73783996134657 35.633 35.66899362497309 139.73778466062694 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c2898d05-ba15-49b3-a49f-bfea4f867063">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2898d05-ba15-49b3-a49f-bfea4f867063">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2898d05-ba15-49b3-a49f-bfea4f867063">
											<gml:posList>35.668911682752295 139.73769587065394 45.697 35.66899319690161 139.73777908287266 45.697 35.66902248391433 139.73773541598578 45.697 35.66895838110735 139.73767091712745 45.697 35.66898305991947 139.73763589374465 45.697 35.668935896436324 139.7375859666123 45.697 35.668910310500905 139.73762507811358 45.697 35.668898248861304 139.7376121465344 45.697 35.66887068209211 139.7376540218855 45.697 35.668911682752295 139.73769587065394 45.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5fcc723d-eb5b-4c9f-8c66-35f836599644">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fcc723d-eb5b-4c9f-8c66-35f836599644">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fcc723d-eb5b-4c9f-8c66-35f836599644">
											<gml:posList>35.66890962102203 139.73769891077862 46.29 35.66899362497309 139.73778466062694 46.29 35.66899319690161 139.73777908287266 46.29 35.668911682752295 139.73769587065394 46.29 35.66890962102203 139.73769891077862 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3582ad88-6f03-49f5-a4f4-4aa2e7ee6e59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3582ad88-6f03-49f5-a4f4-4aa2e7ee6e59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3582ad88-6f03-49f5-a4f4-4aa2e7ee6e59">
											<gml:posList>35.66898760252037 139.7376354906646 46.29 35.66893546828538 139.73758030049473 46.29 35.668935896436324 139.7375859666123 46.29 35.66898305991947 139.73763589374465 46.29 35.66898760252037 139.7376354906646 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f50993c-1bf8-41e0-94d9-9ce28bba2aad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f50993c-1bf8-41e0-94d9-9ce28bba2aad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f50993c-1bf8-41e0-94d9-9ce28bba2aad">
											<gml:posList>35.6689629777293 139.7376704366626 46.29 35.66898760252037 139.7376354906646 46.29 35.66898305991947 139.73763589374465 46.29 35.66895838110735 139.73767091712745 46.29 35.6689629777293 139.7376704366626 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9251f488-7969-4c00-898d-875ecd2f97a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9251f488-7969-4c00-898d-875ecd2f97a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9251f488-7969-4c00-898d-875ecd2f97a3">
											<gml:posList>35.66898842895828 139.73766596577823 40.93 35.66897639186864 139.73768392999693 40.93 35.66897862907969 139.73768620281777 40.93 35.66898880254021 139.7376710244314 40.93 35.66898842895828 139.73766596577823 40.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d4520b2-451e-4d15-9f6a-371866379da2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d4520b2-451e-4d15-9f6a-371866379da2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d4520b2-451e-4d15-9f6a-371866379da2">
											<gml:posList>35.66902701738781 139.7377348693231 46.29 35.6689629777293 139.7376704366626 46.29 35.66895838110735 139.73767091712745 46.29 35.66902248391433 139.73773541598578 46.29 35.66902701738781 139.7377348693231 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d2f3488e-356e-434f-9c04-05a54bd86732">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2f3488e-356e-434f-9c04-05a54bd86732">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2f3488e-356e-434f-9c04-05a54bd86732">
											<gml:posList>35.668980905395784 139.73783996134657 35.633 35.66900892466808 139.73780029467656 43.732 35.66899362497309 139.73778466062694 46.29 35.668980905395784 139.73783996134657 35.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a389a15-ff65-4b19-bd47-a385c12c5c58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a389a15-ff65-4b19-bd47-a385c12c5c58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a389a15-ff65-4b19-bd47-a385c12c5c58">
											<gml:posList>35.66899362497309 139.73778466062694 46.29 35.66902701738781 139.7377348693231 46.29 35.66902248391433 139.73773541598578 46.29 35.66899319690161 139.73777908287266 46.29 35.66899362497309 139.73778466062694 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0c849b9d-5209-4b4b-8f51-b23e807f7673">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c849b9d-5209-4b4b-8f51-b23e807f7673">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c849b9d-5209-4b4b-8f51-b23e807f7673">
											<gml:posList>35.66905036314345 139.73773510659433 40.827 35.66898880254021 139.7376710244314 40.827 35.66897862907969 139.73768620281777 40.827 35.66904057635318 139.73774913573155 40.827 35.66905036314345 139.73773510659433 40.827</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fff125a4-e5df-44c7-9f63-e736b4233268">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fff125a4-e5df-44c7-9f63-e736b4233268">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fff125a4-e5df-44c7-9f63-e736b4233268">
											<gml:posList>35.66900892466808 139.73780029467656 43.732 35.66904307494344 139.73775138615227 43.552 35.66902701738781 139.7377348693231 46.29 35.66899362497309 139.73778466062694 46.29 35.66900892466808 139.73780029467656 43.732</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-906428ee-b701-4226-a591-2615c0078677">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-906428ee-b701-4226-a591-2615c0078677">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-906428ee-b701-4226-a591-2615c0078677">
											<gml:posList>35.669054464072154 139.73773470404618 40.93 35.66898842895828 139.73766596577823 40.93 35.66898880254021 139.7376710244314 40.93 35.66905036314345 139.73773510659433 40.93 35.669054464072154 139.73773470404618 40.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-69b5032d-9a52-4bf5-9707-321530f9de28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69b5032d-9a52-4bf5-9707-321530f9de28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69b5032d-9a52-4bf5-9707-321530f9de28">
											<gml:posList>35.66904281356299 139.73775140855602 40.93 35.669054464072154 139.73773470404618 40.93 35.66905036314345 139.73773510659433 40.93 35.66904057635318 139.73774913573155 40.93 35.66904281356299 139.73775140855602 40.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26a880d2-2c9c-4af6-b714-eefcca8f2697">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26a880d2-2c9c-4af6-b714-eefcca8f2697">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26a880d2-2c9c-4af6-b714-eefcca8f2697">
											<gml:posList>35.668907123277506 139.73755030011745 22.449 35.668875791094194 139.73759507405612 22.449 35.668875791094194 139.73759507405612 40.496 35.668907123277506 139.73755030011745 40.496 35.668907123277506 139.73755030011745 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85e1a7bd-8830-4a5d-93ee-0dba1465a145">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85e1a7bd-8830-4a5d-93ee-0dba1465a145">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85e1a7bd-8830-4a5d-93ee-0dba1465a145">
											<gml:posList>35.668875791094194 139.73759507405612 22.449 35.66886415302608 139.73758205361275 22.449 35.66886415302608 139.73758205361275 40.496 35.668875791094194 139.73759507405612 40.496 35.668875791094194 139.73759507405612 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-482a3a5c-6b8b-4685-96b5-ef9fa52c6971">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-482a3a5c-6b8b-4685-96b5-ef9fa52c6971">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-482a3a5c-6b8b-4685-96b5-ef9fa52c6971">
											<gml:posList>35.66898760252037 139.7376354906646 22.449 35.668907123277506 139.73755030011745 22.449 35.668907123277506 139.73755030011745 40.496 35.66893546828538 139.73758030049473 46.29 35.66898760252037 139.7376354906646 46.29 35.66898760252037 139.7376354906646 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26eace4d-68d2-4fbc-a206-2f3496ed532f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26eace4d-68d2-4fbc-a206-2f3496ed532f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26eace4d-68d2-4fbc-a206-2f3496ed532f">
											<gml:posList>35.66886415302608 139.73758205361275 22.449 35.6688358818095 139.7376221845219 22.449 35.6688358818095 139.7376221845219 40.496 35.66886415302608 139.73758205361275 40.496 35.66886415302608 139.73758205361275 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ddfcc1ad-41d0-4855-8491-9fc012101265">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ddfcc1ad-41d0-4855-8491-9fc012101265">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ddfcc1ad-41d0-4855-8491-9fc012101265">
											<gml:posList>35.668935896436324 139.7375859666123 46.29 35.668910310500905 139.73762507811358 46.29 35.668910310500905 139.73762507811358 45.697 35.668935896436324 139.7375859666123 45.697 35.668935896436324 139.7375859666123 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b586c02-fe8f-4670-a22c-236dc7a0e3e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b586c02-fe8f-4670-a22c-236dc7a0e3e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b586c02-fe8f-4670-a22c-236dc7a0e3e0">
											<gml:posList>35.66898305991947 139.73763589374465 46.29 35.668935896436324 139.7375859666123 46.29 35.668935896436324 139.7375859666123 45.697 35.66898305991947 139.73763589374465 45.697 35.66898305991947 139.73763589374465 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-034471be-7451-42bd-825f-88f66ebe2d27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-034471be-7451-42bd-825f-88f66ebe2d27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-034471be-7451-42bd-825f-88f66ebe2d27">
											<gml:posList>35.6688358818095 139.7376221845219 22.449 35.66882532688392 139.73761104061563 22.449 35.66882532688392 139.73761104061563 40.496 35.6688358818095 139.7376221845219 40.496 35.6688358818095 139.7376221845219 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a7263ac-872b-4f98-8071-f9be5b833df7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a7263ac-872b-4f98-8071-f9be5b833df7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a7263ac-872b-4f98-8071-f9be5b833df7">
											<gml:posList>35.668910310500905 139.73762507811358 46.29 35.668898248861304 139.7376121465344 46.29 35.668898248861304 139.7376121465344 45.697 35.668910310500905 139.73762507811358 45.697 35.668910310500905 139.73762507811358 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67d73a57-090a-4e38-9b79-32c13a1f3a6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67d73a57-090a-4e38-9b79-32c13a1f3a6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67d73a57-090a-4e38-9b79-32c13a1f3a6a">
											<gml:posList>35.6688358818095 139.7376221845219 40.496 35.66882532688392 139.73761104061563 40.496 35.66883831763975 139.73762485475763 43.874 35.66885354570245 139.73764106322656 43.874 35.6688358818095 139.7376221845219 40.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-12f601d5-6304-475f-951f-f1a505a55ad1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12f601d5-6304-475f-951f-f1a505a55ad1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12f601d5-6304-475f-951f-f1a505a55ad1">
											<gml:posList>35.668898248861304 139.7376121465344 46.29 35.66887068209211 139.7376540218855 46.29 35.66887068209211 139.7376540218855 45.697 35.668898248861304 139.7376121465344 45.697 35.668898248861304 139.7376121465344 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07b174c9-a870-4f4c-bb3f-6f8521a00ea7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07b174c9-a870-4f4c-bb3f-6f8521a00ea7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07b174c9-a870-4f4c-bb3f-6f8521a00ea7">
											<gml:posList>35.66882532688392 139.73761104061563 22.449 35.66879066284681 139.73765990549546 22.449 35.66879066284681 139.73765990549546 40.496 35.66882532688392 139.73761104061563 40.496 35.66882532688392 139.73761104061563 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6270b4db-31b8-46b6-9de9-f3b6bb143d0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6270b4db-31b8-46b6-9de9-f3b6bb143d0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6270b4db-31b8-46b6-9de9-f3b6bb143d0c">
											<gml:posList>35.668851636925964 139.73764374969437 43.874 35.66883867322228 139.7376299465608 43.873 35.66883866420856 139.73762994657153 43.445 35.668851636925964 139.73764374969437 43.446 35.668851636925964 139.73764374969437 43.874</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9c2fd95-1d5b-4243-ae11-be2472179b8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9c2fd95-1d5b-4243-ae11-be2472179b8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9c2fd95-1d5b-4243-ae11-be2472179b8b">
											<gml:posList>35.66883867322228 139.7376299465608 43.873 35.66882169355393 139.73765540586763 43.873 35.66882169355393 139.73765540586763 43.445 35.66883866420856 139.73762994657153 43.445 35.66883867322228 139.7376299465608 43.873</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f21aa04d-baf6-4587-a128-06633190f2d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f21aa04d-baf6-4587-a128-06633190f2d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f21aa04d-baf6-4587-a128-06633190f2d1">
											<gml:posList>35.66886618467379 139.73765456850865 46.29 35.66885354570245 139.73764106322656 43.874 35.66886618467379 139.73765456850865 43.874 35.66886618467379 139.73765456850865 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ddd3169f-7cfe-4859-a537-ac29693b8ec4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ddd3169f-7cfe-4859-a537-ac29693b8ec4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ddd3169f-7cfe-4859-a537-ac29693b8ec4">
											<gml:posList>35.66886430295572 139.73765727703636 43.874 35.668851636925964 139.73764374969437 43.874 35.668851636925964 139.73764374969437 43.446 35.66886429394201 139.7376572770471 43.446 35.66886430295572 139.73765727703636 43.874</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7913a0f0-f6ff-4232-adab-e5c1e50a91b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7913a0f0-f6ff-4232-adab-e5c1e50a91b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7913a0f0-f6ff-4232-adab-e5c1e50a91b4">
											<gml:posList>35.6689629777293 139.7376704366626 22.449 35.66898760252037 139.7376354906646 22.449 35.66898760252037 139.7376354906646 46.29 35.6689629777293 139.7376704366626 46.29 35.6689629777293 139.7376704366626 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e62b3f0-8fb6-4fa7-aeb8-b9c8dcf18b6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e62b3f0-8fb6-4fa7-aeb8-b9c8dcf18b6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e62b3f0-8fb6-4fa7-aeb8-b9c8dcf18b6c">
											<gml:posList>35.66895838110735 139.73767091712745 46.29 35.66898305991947 139.73763589374465 46.29 35.66898305991947 139.73763589374465 45.697 35.66895838110735 139.73767091712745 45.697 35.66895838110735 139.73767091712745 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0af40bc0-6c6a-4ac2-a6e9-3b2934add7cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0af40bc0-6c6a-4ac2-a6e9-3b2934add7cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0af40bc0-6c6a-4ac2-a6e9-3b2934add7cb">
											<gml:posList>35.66887068209211 139.7376540218855 46.29 35.668911682752295 139.73769587065394 46.29 35.668911682752295 139.73769587065394 45.697 35.66887068209211 139.7376540218855 45.697 35.66887068209211 139.7376540218855 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc292ce9-21cc-4058-95ed-d48045fcf904">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc292ce9-21cc-4058-95ed-d48045fcf904">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc292ce9-21cc-4058-95ed-d48045fcf904">
											<gml:posList>35.66898842895828 139.73766596577823 22.449 35.66897639186864 139.73768392999693 22.449 35.66897639186864 139.73768392999693 40.93 35.66898842895828 139.73766596577823 40.93 35.66898842895828 139.73766596577823 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-89cafc5b-32cc-42f3-aecb-89e073936987">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89cafc5b-32cc-42f3-aecb-89e073936987">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89cafc5b-32cc-42f3-aecb-89e073936987">
											<gml:posList>35.66886618467379 139.73765456850865 46.29 35.66886618467379 139.73765456850865 43.874 35.66890962102203 139.73769891077862 43.874 35.66890962102203 139.73769891077862 46.29 35.66886618467379 139.73765456850865 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0513755-4315-4e68-8215-fa4cd9ec53dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0513755-4315-4e68-8215-fa4cd9ec53dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0513755-4315-4e68-8215-fa4cd9ec53dd">
											<gml:posList>35.66897639186864 139.73768392999693 40.93 35.66897639186864 139.73768392999693 22.449 35.6689629777293 139.7376704366626 22.449 35.6689629777293 139.7376704366626 46.29 35.66897639186864 139.73768392999693 40.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0abec330-7785-4157-aa32-2913a788c3c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0abec330-7785-4157-aa32-2913a788c3c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0abec330-7785-4157-aa32-2913a788c3c7">
											<gml:posList>35.66890556524092 139.73769941268856 43.874 35.66886430295572 139.73765727703636 43.874 35.66886429394201 139.7376572770471 43.446 35.668905565232144 139.73769940164252 43.446 35.66890556524092 139.73769941268856 43.874</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a362cba-043e-41ee-a849-1375d22ce030">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a362cba-043e-41ee-a849-1375d22ce030">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a362cba-043e-41ee-a849-1375d22ce030">
											<gml:posList>35.66898880254021 139.7376710244314 40.93 35.66897862907969 139.73768620281777 40.93 35.66897862907969 139.73768620281777 40.827 35.66898880254021 139.7376710244314 40.827 35.66898880254021 139.7376710244314 40.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-667cfce0-108b-4938-959e-25b8e33c1edd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-667cfce0-108b-4938-959e-25b8e33c1edd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-667cfce0-108b-4938-959e-25b8e33c1edd">
											<gml:posList>35.66882169355393 139.73765540586763 43.873 35.66889026157579 139.73772419619425 43.874 35.668890252562065 139.737724196205 43.446 35.66882169355393 139.73765540586763 43.445 35.66882169355393 139.73765540586763 43.873</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fddc5cc9-9a9e-42ac-b047-0d3220e4390a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fddc5cc9-9a9e-42ac-b047-0d3220e4390a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fddc5cc9-9a9e-42ac-b047-0d3220e4390a">
											<gml:posList>35.669054464072154 139.73773470404618 22.449 35.66898842895828 139.73766596577823 22.449 35.66898842895828 139.73766596577823 40.93 35.669054464072154 139.73773470404618 40.93 35.669054464072154 139.73773470404618 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f6a4691-49d8-4788-ace9-705bda4c03b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f6a4691-49d8-4788-ace9-705bda4c03b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f6a4691-49d8-4788-ace9-705bda4c03b7">
											<gml:posList>35.66905036314345 139.73773510659433 40.93 35.66898880254021 139.7376710244314 40.93 35.66898880254021 139.7376710244314 40.827 35.66905036314345 139.73773510659433 40.827 35.66905036314345 139.73773510659433 40.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-346aac5e-8052-45d0-8810-6c761644f557">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-346aac5e-8052-45d0-8810-6c761644f557">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-346aac5e-8052-45d0-8810-6c761644f557">
											<gml:posList>35.66902248391433 139.73773541598578 46.29 35.66895838110735 139.73767091712745 46.29 35.66895838110735 139.73767091712745 45.697 35.66902248391433 139.73773541598578 45.697 35.66902248391433 139.73773541598578 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2d0a44e-77aa-4a91-a99e-291d1292fdbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2d0a44e-77aa-4a91-a99e-291d1292fdbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2d0a44e-77aa-4a91-a99e-291d1292fdbd">
											<gml:posList>35.668899164246525 139.73770919608188 43.846 35.66890556524092 139.73769941268856 43.874 35.668905565232144 139.73769940164252 43.446 35.668899155224025 139.73770918504658 43.418 35.668899164246525 139.73770919608188 43.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7734812-e309-4d97-b913-cac1cdc72800">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7734812-e309-4d97-b913-cac1cdc72800">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7734812-e309-4d97-b913-cac1cdc72800">
											<gml:posList>35.66890147347919 139.73771135835477 43.845 35.66890962102203 139.73769891077862 46.29 35.66890962102203 139.73769891077862 43.874 35.66890147347919 139.73771135835477 43.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b549882-e01b-4121-acbb-8c958841a449">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b549882-e01b-4121-acbb-8c958841a449">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b549882-e01b-4121-acbb-8c958841a449">
											<gml:posList>35.66887585147422 139.73775050298045 36.159 35.6688758064056 139.73775050303416 40.496 35.66879066284681 139.73765990549546 40.496 35.66879066284681 139.73765990549546 22.449 35.66887943298275 139.73775435378332 22.449 35.66887946903764 139.73775435374034 36.141 35.66887585147422 139.73775050298045 36.159</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99e7ce30-6120-4550-a55b-96579a75c4ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99e7ce30-6120-4550-a55b-96579a75c4ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99e7ce30-6120-4550-a55b-96579a75c4ac">
											<gml:posList>35.6689629777293 139.7376704366626 46.29 35.66902701738781 139.7377348693231 46.29 35.66904307494344 139.73775138615227 43.552 35.6689629777293 139.7376704366626 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa55a8c2-6dbf-4e64-9c67-e8881338de0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa55a8c2-6dbf-4e64-9c67-e8881338de0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa55a8c2-6dbf-4e64-9c67-e8881338de0a">
											<gml:posList>35.66897639186864 139.73768392999693 40.93 35.6689629777293 139.7376704366626 46.29 35.66904307494344 139.73775138615227 43.552 35.66897862907969 139.73768620281777 40.93 35.66897639186864 139.73768392999693 40.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edbdd86c-4b97-4c42-a422-65a4edb402e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edbdd86c-4b97-4c42-a422-65a4edb402e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edbdd86c-4b97-4c42-a422-65a4edb402e3">
											<gml:posList>35.66889026157579 139.73772419619425 43.874 35.668899164246525 139.73770919608188 43.846 35.668899155224025 139.73770918504658 43.418 35.668890252562065 139.737724196205 43.446 35.66889026157579 139.73772419619425 43.874</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48f3595c-d09a-4438-a376-411ff0a82057">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48f3595c-d09a-4438-a376-411ff0a82057">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48f3595c-d09a-4438-a376-411ff0a82057">
											<gml:posList>35.66904307494344 139.73775138615227 43.552 35.66904281356299 139.73775140855602 40.93 35.66904057635318 139.73774913573155 40.93 35.66904057635318 139.73774913573155 40.827 35.66897862907969 139.73768620281777 40.827 35.66897862907969 139.73768620281777 40.93 35.66904307494344 139.73775138615227 43.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7321a288-c871-45f9-8a87-87ca0967d739">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7321a288-c871-45f9-8a87-87ca0967d739">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7321a288-c871-45f9-8a87-87ca0967d739">
											<gml:posList>35.66890962102203 139.73769891077862 46.29 35.66887946903764 139.73775435374034 36.141 35.66888826545034 139.73774175075366 36.092 35.66890962102203 139.73769891077862 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2349f693-da5b-40a3-8f1a-24af7228a260">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2349f693-da5b-40a3-8f1a-24af7228a260">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2349f693-da5b-40a3-8f1a-24af7228a260">
											<gml:posList>35.66890147347919 139.73771135835477 43.845 35.668890797472464 139.73772934301638 43.874 35.6688758064056 139.73775050303416 40.496 35.66890147347919 139.73771135835477 43.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-923d6c3a-2174-4d2e-bf41-89f109143f65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-923d6c3a-2174-4d2e-bf41-89f109143f65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-923d6c3a-2174-4d2e-bf41-89f109143f65">
											<gml:posList>35.6688758064056 139.73775050303416 40.496 35.66887585147422 139.73775050298045 36.159 35.66890147347919 139.73771135835477 43.845 35.6688758064056 139.73775050303416 40.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f6058a2-8ab8-46c1-bef6-17ad2d3dc29f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f6058a2-8ab8-46c1-bef6-17ad2d3dc29f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f6058a2-8ab8-46c1-bef6-17ad2d3dc29f">
											<gml:posList>35.668911682752295 139.73769587065394 46.29 35.66899319690161 139.73777908287266 46.29 35.66899319690161 139.73777908287266 45.697 35.668911682752295 139.73769587065394 45.697 35.668911682752295 139.73769587065394 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d5e97f9-6a9b-4327-b981-0afddeb18c22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d5e97f9-6a9b-4327-b981-0afddeb18c22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d5e97f9-6a9b-4327-b981-0afddeb18c22">
											<gml:posList>35.66904057635318 139.73774913573155 40.93 35.66905036314345 139.73773510659433 40.93 35.66905036314345 139.73773510659433 40.827 35.66904057635318 139.73774913573155 40.827 35.66904057635318 139.73774913573155 40.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78aba2b1-6b4b-4ced-833a-15af293d77c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78aba2b1-6b4b-4ced-833a-15af293d77c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78aba2b1-6b4b-4ced-833a-15af293d77c7">
											<gml:posList>35.66887943298275 139.73775435378332 22.449 35.668888256436624 139.7377417507644 22.449 35.66888826545034 139.73774175075366 36.092 35.66887946903764 139.73775435374034 36.141 35.66887943298275 139.73775435378332 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bfda7f3c-5e83-427e-910b-8353b5b3e700">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfda7f3c-5e83-427e-910b-8353b5b3e700">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfda7f3c-5e83-427e-910b-8353b5b3e700">
											<gml:posList>35.66899319690161 139.73777908287266 46.29 35.66902248391433 139.73773541598578 46.29 35.66902248391433 139.73773541598578 45.697 35.66899319690161 139.73777908287266 45.697 35.66899319690161 139.73777908287266 46.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe8f2ddd-615c-4491-8153-98777f0e9474">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe8f2ddd-615c-4491-8153-98777f0e9474">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe8f2ddd-615c-4491-8153-98777f0e9474">
											<gml:posList>35.66904281356299 139.73775140855602 40.93 35.66904307494344 139.73775138615227 43.552 35.66900892466808 139.73780029467656 43.732 35.668980905395784 139.73783996134657 35.633 35.668981085661514 139.73783995008583 22.449 35.669054464072154 139.73773470404618 22.449 35.669054464072154 139.73773470404618 40.93 35.66904281356299 139.73775140855602 40.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a5cf4e3-56c7-4c69-a1e5-3115ebb51170">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a5cf4e3-56c7-4c69-a1e5-3115ebb51170">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a5cf4e3-56c7-4c69-a1e5-3115ebb51170">
											<gml:posList>35.668888256436624 139.7377417507644 22.449 35.668981085661514 139.73783995008583 22.449 35.668980905395784 139.73783996134657 35.633 35.66888826545034 139.73774175075366 36.092 35.668888256436624 139.7377417507644 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂六丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6407</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">360.51455</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>