<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_8fdb4c31-833b-4ce4-8bbf-637b8446056d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">37.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671047491219426 139.7441746040245 0 35.67097523106619 139.7441542044631 0 35.67097594034411 139.74415041477891 0 35.670866833358815 139.74411960642774 0 35.6708565261862 139.7441744076709 0 35.67084560827755 139.74417132684133 0 35.670794422309854 139.74444360919753 0 35.67080402393092 139.7444463159467 0 35.6707956919107 139.7444906540544 0 35.670978384181446 139.7445422258199 0 35.671047491219426 139.7441746040245 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671047491219426 139.7441746040245 7.02 35.670978384181446 139.7445422258199 7.02 35.6707956919107 139.7444906540544 7.02 35.67080402393092 139.7444463159467 7.02 35.670794422309854 139.74444360919753 7.02 35.67084560827755 139.74417132684133 7.02 35.6708565261862 139.7441744076709 7.02 35.670866833358815 139.74411960642774 7.02 35.67097594034411 139.74415041477891 7.02 35.67097523106619 139.7441542044631 7.02 35.671047491219426 139.7441746040245 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671047491219426 139.7441746040245 7.02 35.67097523106619 139.7441542044631 7.02 35.67097523106619 139.7441542044631 44.66 35.671047491219426 139.7441746040245 44.66 35.671047491219426 139.7441746040245 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67097523106619 139.7441542044631 7.02 35.67097594034411 139.74415041477891 7.02 35.67097594034411 139.74415041477891 44.66 35.67097523106619 139.7441542044631 44.66 35.67097523106619 139.7441542044631 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67097594034411 139.74415041477891 7.02 35.670866833358815 139.74411960642774 7.02 35.670866833358815 139.74411960642774 44.66 35.67097594034411 139.74415041477891 44.66 35.67097594034411 139.74415041477891 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670866833358815 139.74411960642774 7.02 35.6708565261862 139.7441744076709 7.02 35.6708565261862 139.7441744076709 44.66 35.670866833358815 139.74411960642774 44.66 35.670866833358815 139.74411960642774 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6708565261862 139.7441744076709 7.02 35.67084560827755 139.74417132684133 7.02 35.67084560827755 139.74417132684133 44.66 35.6708565261862 139.7441744076709 44.66 35.6708565261862 139.7441744076709 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67084560827755 139.74417132684133 7.02 35.670794422309854 139.74444360919753 7.02 35.670794422309854 139.74444360919753 44.66 35.67084560827755 139.74417132684133 44.66 35.67084560827755 139.74417132684133 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670794422309854 139.74444360919753 7.02 35.67080402393092 139.7444463159467 7.02 35.67080402393092 139.7444463159467 44.66 35.670794422309854 139.74444360919753 44.66 35.670794422309854 139.74444360919753 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67080402393092 139.7444463159467 7.02 35.6707956919107 139.7444906540544 7.02 35.6707956919107 139.7444906540544 44.66 35.67080402393092 139.7444463159467 44.66 35.67080402393092 139.7444463159467 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6707956919107 139.7444906540544 7.02 35.670978384181446 139.7445422258199 7.02 35.670978384181446 139.7445422258199 44.66 35.6707956919107 139.7444906540544 44.66 35.6707956919107 139.7444906540544 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670978384181446 139.7445422258199 7.02 35.671047491219426 139.7441746040245 7.02 35.671047491219426 139.7441746040245 44.66 35.670978384181446 139.7445422258199 44.66 35.670978384181446 139.7445422258199 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671047491219426 139.7441746040245 44.66 35.67097523106619 139.7441542044631 44.66 35.67097594034411 139.74415041477891 44.66 35.670866833358815 139.74411960642774 44.66 35.6708565261862 139.7441744076709 44.66 35.67084560827755 139.74417132684133 44.66 35.670794422309854 139.74444360919753 44.66 35.67080402393092 139.7444463159467 44.66 35.6707956919107 139.7444906540544 44.66 35.670978384181446 139.7445422258199 44.66 35.671047491219426 139.7441746040245 44.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-89f3c52c-72f8-41bf-848f-5a4c36b6417a"/>
							<gml:surfaceMember xlink:href="#poly-5e18dca4-d48c-49ce-96b3-0a633c3e75f7"/>
							<gml:surfaceMember xlink:href="#poly-ddb54aa0-cfc6-4dd8-b4c2-58032361361c"/>
							<gml:surfaceMember xlink:href="#poly-e5586f4d-c100-4c31-b760-09276973c362"/>
							<gml:surfaceMember xlink:href="#poly-b7c1b8c8-2373-4f94-9b7a-078afe0c8956"/>
							<gml:surfaceMember xlink:href="#poly-700c5302-11f3-4ba8-a927-a88554df62dc"/>
							<gml:surfaceMember xlink:href="#poly-c138129a-fa9f-4736-99ca-0adf90edf443"/>
							<gml:surfaceMember xlink:href="#poly-d43a7694-8779-4eed-9539-b6fdfd5cfaf2"/>
							<gml:surfaceMember xlink:href="#poly-a715c82b-4aa9-43c9-95be-43944428c327"/>
							<gml:surfaceMember xlink:href="#poly-ade6ce4a-692d-49b2-a06e-9fe09fb37b0d"/>
							<gml:surfaceMember xlink:href="#poly-7f67ec83-1e5b-4cbc-ad86-78c5b8cc80c2"/>
							<gml:surfaceMember xlink:href="#poly-abc0b85f-ffc4-4743-a173-b32c0b50f53f"/>
							<gml:surfaceMember xlink:href="#poly-7bc1f07a-133a-4ff7-8b8a-e485f6b4ac53"/>
							<gml:surfaceMember xlink:href="#poly-9ff709bb-9143-407b-9fa7-dec30e8fec30"/>
							<gml:surfaceMember xlink:href="#poly-747f5376-77cb-478f-a05c-154c20c60cbb"/>
							<gml:surfaceMember xlink:href="#poly-8f83ea34-cb9e-4250-826c-302e5e18a230"/>
							<gml:surfaceMember xlink:href="#poly-4a288a07-30d7-4f32-859e-21c0f5f372aa"/>
							<gml:surfaceMember xlink:href="#poly-f9bbed27-992c-4a1b-86d7-870277507204"/>
							<gml:surfaceMember xlink:href="#poly-73352701-e92e-4717-9411-37c2d0e571ab"/>
							<gml:surfaceMember xlink:href="#poly-9dbd9c64-55a7-4eaf-84c9-f6036f4eaac6"/>
							<gml:surfaceMember xlink:href="#poly-86f82ba3-a792-4e2d-aeef-7fb084678a15"/>
							<gml:surfaceMember xlink:href="#poly-c3d8207f-1c97-4d04-80fc-2ba3665e5e5b"/>
							<gml:surfaceMember xlink:href="#poly-8d7472ff-3da5-4fd9-abad-e9352e083dc7"/>
							<gml:surfaceMember xlink:href="#poly-7ca3c019-7f87-4a00-b7df-39ba5b04d372"/>
							<gml:surfaceMember xlink:href="#poly-b5332e82-09b5-431d-bad4-5d90d2ba0da8"/>
							<gml:surfaceMember xlink:href="#poly-00090e75-0331-4af0-8b8e-a0e4d276c0e5"/>
							<gml:surfaceMember xlink:href="#poly-cf31475c-c370-4b89-b582-dbda6c9cb14c"/>
							<gml:surfaceMember xlink:href="#poly-eb15866f-b23c-43cd-be59-266c48cfa38c"/>
							<gml:surfaceMember xlink:href="#poly-cf27e253-35c2-42a6-991d-df920da8f6fe"/>
							<gml:surfaceMember xlink:href="#poly-81312107-9d44-4f98-aeae-40050532f084"/>
							<gml:surfaceMember xlink:href="#poly-c30c9e90-e856-44b1-b190-7781ac716864"/>
							<gml:surfaceMember xlink:href="#poly-b1fe0f09-c289-424d-8b9e-64c879e66987"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_8fdb4c31-833b-4ce4-8bbf-637b8446056d_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98f61607-a9b6-477c-9df5-b153940fc706">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670985619652875 139.7441728170426 44.887 35.67103037316154 139.74418544848288 44.887 35.67102508493006 139.744213622552 44.887 35.67098032241056 139.74420099110682 44.887 35.670985619652875 139.7441728170426 44.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51cc9349-3b5d-4b83-8b9f-03789a2a9a86">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670952988147434 139.74447522476126 44.887 35.67096799913424 139.74447946096598 44.887 35.67095909245622 139.74452682649456 44.887 35.67094408147104 139.74452259028146 44.887 35.670952988147434 139.74447522476126 44.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb70c1d2-af66-4de3-89f3-01d7ac47fa77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb70c1d2-af66-4de3-89f3-01d7ac47fa77_0">
											<gml:posList>35.67103037316154 139.74418544848288 44.887 35.670985619652875 139.7441728170426 44.887 35.670985619652875 139.7441728170426 47.849 35.67103037316154 139.74418544848288 47.849 35.67103037316154 139.74418544848288 44.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f242f268-213b-4220-bd48-1b12790b054c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f242f268-213b-4220-bd48-1b12790b054c_0">
											<gml:posList>35.670985619652875 139.7441728170426 44.887 35.67098032241056 139.74420099110682 44.887 35.67098032241056 139.74420099110682 47.849 35.670985619652875 139.7441728170426 47.849 35.670985619652875 139.7441728170426 44.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0adb1a75-0a27-46fc-9ba9-342e9493948d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0adb1a75-0a27-46fc-9ba9-342e9493948d_0">
											<gml:posList>35.67102508493006 139.744213622552 47.849 35.67103037316154 139.74418544848288 47.849 35.670985619652875 139.7441728170426 47.849 35.67098032241056 139.74420099110682 47.849 35.67102508493006 139.744213622552 47.849</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4db79ba4-6213-498a-be4c-9d50735acf3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4db79ba4-6213-498a-be4c-9d50735acf3f_0">
											<gml:posList>35.67102508493006 139.744213622552 44.887 35.67103037316154 139.74418544848288 44.887 35.67103037316154 139.74418544848288 47.849 35.67102508493006 139.744213622552 47.849 35.67102508493006 139.744213622552 44.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d44d1a2c-106d-497a-923d-7d529454415b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d44d1a2c-106d-497a-923d-7d529454415b_0">
											<gml:posList>35.67098032241056 139.74420099110682 44.887 35.67102508493006 139.744213622552 44.887 35.67102508493006 139.744213622552 47.849 35.67098032241056 139.74420099110682 47.849 35.67098032241056 139.74420099110682 44.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcf6ecf2-ead3-4106-9d21-5a89df3fb74f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcf6ecf2-ead3-4106-9d21-5a89df3fb74f_0">
											<gml:posList>35.67096799913424 139.74447946096598 44.887 35.670952988147434 139.74447522476126 44.887 35.670952988147434 139.74447522476126 47.585 35.67096799913424 139.74447946096598 47.585 35.67096799913424 139.74447946096598 44.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18e3ca5a-a1e9-4d44-8547-d568e38dd856">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18e3ca5a-a1e9-4d44-8547-d568e38dd856_0">
											<gml:posList>35.670952988147434 139.74447522476126 44.887 35.67094408147104 139.74452259028146 44.887 35.67094408147104 139.74452259028146 47.585 35.670952988147434 139.74447522476126 47.585 35.670952988147434 139.74447522476126 44.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5f61c65-7030-4b0f-a1be-1eb7473ba6ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5f61c65-7030-4b0f-a1be-1eb7473ba6ab_0">
											<gml:posList>35.670952988147434 139.74447522476126 47.585 35.67094408147104 139.74452259028146 47.585 35.67095909245622 139.74452682649456 47.585 35.67096799913424 139.74447946096598 47.585 35.670952988147434 139.74447522476126 47.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f8afede-cab5-4e40-a2de-2141b8b961d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f8afede-cab5-4e40-a2de-2141b8b961d7_0">
											<gml:posList>35.67095909245622 139.74452682649456 44.887 35.67096799913424 139.74447946096598 44.887 35.67096799913424 139.74447946096598 47.585 35.67095909245622 139.74452682649456 47.585 35.67095909245622 139.74452682649456 44.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-800f50b3-fac1-428d-95cf-68779eb3aa2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-800f50b3-fac1-428d-95cf-68779eb3aa2e_0">
											<gml:posList>35.67095909245622 139.74452682649456 44.887 35.67095909245622 139.74452682649456 47.585 35.67094408147104 139.74452259028146 47.585 35.67094408147104 139.74452259028146 44.887 35.67095909245622 139.74452682649456 44.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-89f3c52c-72f8-41bf-848f-5a4c36b6417a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89f3c52c-72f8-41bf-848f-5a4c36b6417a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89f3c52c-72f8-41bf-848f-5a4c36b6417a">
											<gml:posList>35.67080402393089 139.7444463159467 7.02 35.670794422309854 139.7444436091975 7.02 35.67084560827753 139.74417132684133 7.02 35.6708565261862 139.7441744076709 7.02 35.670866833358794 139.74411960642772 7.02 35.67097594034409 139.74415041477891 7.02 35.67097523106617 139.7441542044631 7.02 35.67104749121942 139.7441746040245 7.02 35.670978384181424 139.7445422258199 7.02 35.6707956919107 139.7444906540544 7.02 35.67080402393089 139.7444463159467 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e18dca4-d48c-49ce-96b3-0a633c3e75f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e18dca4-d48c-49ce-96b3-0a633c3e75f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e18dca4-d48c-49ce-96b3-0a633c3e75f7">
											<gml:posList>35.670866833358794 139.74411960642772 46.6 35.67087007399107 139.74412595446 46.6 35.67097076940431 139.74415438616725 46.6 35.67097594034409 139.74415041477891 46.6 35.670866833358794 139.74411960642772 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ddb54aa0-cfc6-4dd8-b4c2-58032361361c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ddb54aa0-cfc6-4dd8-b4c2-58032361361c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ddb54aa0-cfc6-4dd8-b4c2-58032361361c">
											<gml:posList>35.6708565261862 139.7441744076709 46.6 35.67085976681559 139.74418075570458 46.6 35.67087007399107 139.74412595446 46.6 35.670866833358794 139.74411960642772 46.6 35.6708565261862 139.7441744076709 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5586f4d-c100-4c31-b760-09276973c362">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5586f4d-c100-4c31-b760-09276973c362">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5586f4d-c100-4c31-b760-09276973c362">
											<gml:posList>35.67097523106617 139.7441542044631 46.6 35.67097594034409 139.74415041477891 46.6 35.67097076940431 139.74415438616725 46.6 35.67097005111254 139.74415817586117 46.6 35.67097523106617 139.7441542044631 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b7c1b8c8-2373-4f94-9b7a-078afe0c8956">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7c1b8c8-2373-4f94-9b7a-078afe0c8956">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7c1b8c8-2373-4f94-9b7a-078afe0c8956">
											<gml:posList>35.67097523106617 139.7441542044631 46.6 35.67097005111254 139.74415817586117 46.6 35.67104232027891 139.7441785754148 46.6 35.67104749121942 139.7441746040245 46.6 35.67097523106617 139.7441542044631 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-700c5302-11f3-4ba8-a927-a88554df62dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-700c5302-11f3-4ba8-a927-a88554df62dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-700c5302-11f3-4ba8-a927-a88554df62dc">
											<gml:posList>35.6708565261862 139.7441744076709 46.6 35.67084560827753 139.74417132684133 46.6 35.670848848907085 139.744177674874 46.6 35.67085976681559 139.74418075570458 46.6 35.6708565261862 139.7441744076709 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c138129a-fa9f-4736-99ca-0adf90edf443">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c138129a-fa9f-4736-99ca-0adf90edf443">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c138129a-fa9f-4736-99ca-0adf90edf443">
											<gml:posList>35.670794422309854 139.7444436091975 46.6 35.67079960228124 139.74443964887288 46.6 35.670848848907085 139.744177674874 46.6 35.67084560827753 139.74417132684133 46.6 35.670794422309854 139.7444436091975 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d43a7694-8779-4eed-9539-b6fdfd5cfaf2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d43a7694-8779-4eed-9539-b6fdfd5cfaf2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d43a7694-8779-4eed-9539-b6fdfd5cfaf2">
											<gml:posList>35.67097005111254 139.74415817586117 44.887 35.67097076940431 139.74415438616725 44.887 35.67087007399107 139.74412595446 44.887 35.67085976681559 139.74418075570458 44.887 35.670848848907085 139.744177674874 44.887 35.67079960228124 139.74443964887288 44.887 35.67080920390236 139.74444235562174 44.887 35.67080087188364 139.74448669373274 44.887 35.67097515259299 139.74453588879857 44.887 35.67104232027891 139.7441785754148 44.887 35.67097005111254 139.74415817586117 44.887</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a715c82b-4aa9-43c9-95be-43944428c327">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a715c82b-4aa9-43c9-95be-43944428c327">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a715c82b-4aa9-43c9-95be-43944428c327">
											<gml:posList>35.67104749121942 139.7441746040245 46.6 35.67104232027891 139.7441785754148 46.6 35.67097515259299 139.74453588879857 46.6 35.670978384181424 139.7445422258199 46.6 35.67104749121942 139.7441746040245 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ade6ce4a-692d-49b2-a06e-9fe09fb37b0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ade6ce4a-692d-49b2-a06e-9fe09fb37b0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ade6ce4a-692d-49b2-a06e-9fe09fb37b0d">
											<gml:posList>35.67080402393089 139.7444463159467 46.6 35.67080920390236 139.74444235562174 46.6 35.67079960228124 139.74443964887288 46.6 35.670794422309854 139.7444436091975 46.6 35.67080402393089 139.7444463159467 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f67ec83-1e5b-4cbc-ad86-78c5b8cc80c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f67ec83-1e5b-4cbc-ad86-78c5b8cc80c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f67ec83-1e5b-4cbc-ad86-78c5b8cc80c2">
											<gml:posList>35.67080402393089 139.7444463159467 46.6 35.6707956919107 139.7444906540544 46.6 35.67080087188364 139.74448669373274 46.6 35.67080920390236 139.74444235562174 46.6 35.67080402393089 139.7444463159467 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-abc0b85f-ffc4-4743-a173-b32c0b50f53f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abc0b85f-ffc4-4743-a173-b32c0b50f53f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abc0b85f-ffc4-4743-a173-b32c0b50f53f">
											<gml:posList>35.670978384181424 139.7445422258199 46.6 35.67097515259299 139.74453588879857 46.6 35.67080087188364 139.74448669373274 46.6 35.6707956919107 139.7444906540544 46.6 35.670978384181424 139.7445422258199 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7bc1f07a-133a-4ff7-8b8a-e485f6b4ac53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bc1f07a-133a-4ff7-8b8a-e485f6b4ac53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bc1f07a-133a-4ff7-8b8a-e485f6b4ac53">
											<gml:posList>35.67097594034409 139.74415041477891 7.02 35.670866833358794 139.74411960642772 7.02 35.670866833358794 139.74411960642772 46.6 35.67097594034409 139.74415041477891 46.6 35.67097594034409 139.74415041477891 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ff709bb-9143-407b-9fa7-dec30e8fec30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ff709bb-9143-407b-9fa7-dec30e8fec30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ff709bb-9143-407b-9fa7-dec30e8fec30">
											<gml:posList>35.67087007399107 139.74412595446 46.6 35.67087007399107 139.74412595446 44.887 35.67097076940431 139.74415438616725 44.887 35.67097076940431 139.74415438616725 46.6 35.67087007399107 139.74412595446 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-747f5376-77cb-478f-a05c-154c20c60cbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-747f5376-77cb-478f-a05c-154c20c60cbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-747f5376-77cb-478f-a05c-154c20c60cbb">
											<gml:posList>35.670866833358794 139.74411960642772 7.02 35.6708565261862 139.7441744076709 7.02 35.6708565261862 139.7441744076709 46.6 35.670866833358794 139.74411960642772 46.6 35.670866833358794 139.74411960642772 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f83ea34-cb9e-4250-826c-302e5e18a230">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f83ea34-cb9e-4250-826c-302e5e18a230">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f83ea34-cb9e-4250-826c-302e5e18a230">
											<gml:posList>35.67097523106617 139.7441542044631 7.02 35.67097594034409 139.74415041477891 7.02 35.67097594034409 139.74415041477891 46.6 35.67097523106617 139.7441542044631 46.6 35.67097523106617 139.7441542044631 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a288a07-30d7-4f32-859e-21c0f5f372aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a288a07-30d7-4f32-859e-21c0f5f372aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a288a07-30d7-4f32-859e-21c0f5f372aa">
											<gml:posList>35.67085976681559 139.74418075570458 46.6 35.67085976681559 139.74418075570458 44.887 35.67087007399107 139.74412595446 44.887 35.67087007399107 139.74412595446 46.6 35.67085976681559 139.74418075570458 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9bbed27-992c-4a1b-86d7-870277507204">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9bbed27-992c-4a1b-86d7-870277507204">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9bbed27-992c-4a1b-86d7-870277507204">
											<gml:posList>35.67097076940431 139.74415438616725 46.6 35.67097076940431 139.74415438616725 44.887 35.67097005111254 139.74415817586117 44.887 35.67097005111254 139.74415817586117 46.6 35.67097076940431 139.74415438616725 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73352701-e92e-4717-9411-37c2d0e571ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73352701-e92e-4717-9411-37c2d0e571ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73352701-e92e-4717-9411-37c2d0e571ab">
											<gml:posList>35.67104749121942 139.7441746040245 7.02 35.67097523106617 139.7441542044631 7.02 35.67097523106617 139.7441542044631 46.6 35.67104749121942 139.7441746040245 46.6 35.67104749121942 139.7441746040245 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9dbd9c64-55a7-4eaf-84c9-f6036f4eaac6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dbd9c64-55a7-4eaf-84c9-f6036f4eaac6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dbd9c64-55a7-4eaf-84c9-f6036f4eaac6">
											<gml:posList>35.67097005111254 139.74415817586117 46.6 35.67097005111254 139.74415817586117 44.887 35.67104232027891 139.7441785754148 44.887 35.67104232027891 139.7441785754148 46.6 35.67097005111254 139.74415817586117 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86f82ba3-a792-4e2d-aeef-7fb084678a15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86f82ba3-a792-4e2d-aeef-7fb084678a15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86f82ba3-a792-4e2d-aeef-7fb084678a15">
											<gml:posList>35.6708565261862 139.7441744076709 7.02 35.67084560827753 139.74417132684133 7.02 35.67084560827753 139.74417132684133 46.6 35.6708565261862 139.7441744076709 46.6 35.6708565261862 139.7441744076709 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3d8207f-1c97-4d04-80fc-2ba3665e5e5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3d8207f-1c97-4d04-80fc-2ba3665e5e5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3d8207f-1c97-4d04-80fc-2ba3665e5e5b">
											<gml:posList>35.670848848907085 139.744177674874 46.6 35.670848848907085 139.744177674874 44.887 35.67085976681559 139.74418075570458 44.887 35.67085976681559 139.74418075570458 46.6 35.670848848907085 139.744177674874 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d7472ff-3da5-4fd9-abad-e9352e083dc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d7472ff-3da5-4fd9-abad-e9352e083dc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d7472ff-3da5-4fd9-abad-e9352e083dc7">
											<gml:posList>35.67084560827753 139.74417132684133 7.02 35.670794422309854 139.7444436091975 7.02 35.670794422309854 139.7444436091975 46.6 35.67084560827753 139.74417132684133 46.6 35.67084560827753 139.74417132684133 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ca3c019-7f87-4a00-b7df-39ba5b04d372">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ca3c019-7f87-4a00-b7df-39ba5b04d372">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ca3c019-7f87-4a00-b7df-39ba5b04d372">
											<gml:posList>35.67079960228124 139.74443964887288 46.6 35.67079960228124 139.74443964887288 44.887 35.670848848907085 139.744177674874 44.887 35.670848848907085 139.744177674874 46.6 35.67079960228124 139.74443964887288 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5332e82-09b5-431d-bad4-5d90d2ba0da8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5332e82-09b5-431d-bad4-5d90d2ba0da8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5332e82-09b5-431d-bad4-5d90d2ba0da8">
											<gml:posList>35.67104232027891 139.7441785754148 46.6 35.67104232027891 139.7441785754148 44.887 35.67097515259299 139.74453588879857 44.887 35.67097515259299 139.74453588879857 46.6 35.67104232027891 139.7441785754148 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00090e75-0331-4af0-8b8e-a0e4d276c0e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00090e75-0331-4af0-8b8e-a0e4d276c0e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00090e75-0331-4af0-8b8e-a0e4d276c0e5">
											<gml:posList>35.670978384181424 139.7445422258199 7.02 35.67104749121942 139.7441746040245 7.02 35.67104749121942 139.7441746040245 46.6 35.670978384181424 139.7445422258199 46.6 35.670978384181424 139.7445422258199 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf31475c-c370-4b89-b582-dbda6c9cb14c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf31475c-c370-4b89-b582-dbda6c9cb14c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf31475c-c370-4b89-b582-dbda6c9cb14c">
											<gml:posList>35.67080920390236 139.74444235562174 46.6 35.67080920390236 139.74444235562174 44.887 35.67079960228124 139.74443964887288 44.887 35.67079960228124 139.74443964887288 46.6 35.67080920390236 139.74444235562174 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb15866f-b23c-43cd-be59-266c48cfa38c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb15866f-b23c-43cd-be59-266c48cfa38c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb15866f-b23c-43cd-be59-266c48cfa38c">
											<gml:posList>35.670794422309854 139.7444436091975 7.02 35.67080402393089 139.7444463159467 7.02 35.67080402393089 139.7444463159467 46.6 35.670794422309854 139.7444436091975 46.6 35.670794422309854 139.7444436091975 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf27e253-35c2-42a6-991d-df920da8f6fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf27e253-35c2-42a6-991d-df920da8f6fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf27e253-35c2-42a6-991d-df920da8f6fe">
											<gml:posList>35.67080087188364 139.74448669373274 46.6 35.67080087188364 139.74448669373274 44.887 35.67080920390236 139.74444235562174 44.887 35.67080920390236 139.74444235562174 46.6 35.67080087188364 139.74448669373274 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81312107-9d44-4f98-aeae-40050532f084">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81312107-9d44-4f98-aeae-40050532f084">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81312107-9d44-4f98-aeae-40050532f084">
											<gml:posList>35.67080402393089 139.7444463159467 7.02 35.6707956919107 139.7444906540544 7.02 35.6707956919107 139.7444906540544 46.6 35.67080402393089 139.7444463159467 46.6 35.67080402393089 139.7444463159467 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c30c9e90-e856-44b1-b190-7781ac716864">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c30c9e90-e856-44b1-b190-7781ac716864">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c30c9e90-e856-44b1-b190-7781ac716864">
											<gml:posList>35.67097515259299 139.74453588879857 46.6 35.67097515259299 139.74453588879857 44.887 35.67080087188364 139.74448669373274 44.887 35.67080087188364 139.74448669373274 46.6 35.67097515259299 139.74453588879857 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1fe0f09-c289-424d-8b9e-64c879e66987">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1fe0f09-c289-424d-8b9e-64c879e66987">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1fe0f09-c289-424d-8b9e-64c879e66987">
											<gml:posList>35.6707956919107 139.7444906540544 7.02 35.670978384181424 139.7445422258199 7.02 35.670978384181424 139.7445422258199 46.6 35.6707956919107 139.7444906540544 46.6 35.6707956919107 139.7444906540544 7.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8790</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">675.943</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.2</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>