<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_90436947-6713-4c66-8b8c-46c1a6be398d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>赤坂一丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">4.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66958484747052 139.74193358585993 0 35.66962174298411 139.74197226057507 0 35.669646467812946 139.74193684051042 0 35.66972402956048 139.74201814027262 0 35.669762827557705 139.74196254487435 0 35.66965881644848 139.74185351629401 0 35.66958484747052 139.74193358585993 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66958484747052 139.74193358585993 8.77 35.66965881644848 139.74185351629401 8.77 35.669762827557705 139.74196254487435 8.77 35.66972402956048 139.74201814027262 8.77 35.669646467812946 139.74193684051042 8.77 35.66962174298411 139.74197226057507 8.77 35.66958484747052 139.74193358585993 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66958484747052 139.74193358585993 8.77 35.66962174298411 139.74197226057507 8.77 35.66962174298411 139.74197226057507 13.11 35.66958484747052 139.74193358585993 13.11 35.66958484747052 139.74193358585993 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66962174298411 139.74197226057507 8.77 35.669646467812946 139.74193684051042 8.77 35.669646467812946 139.74193684051042 13.11 35.66962174298411 139.74197226057507 13.11 35.66962174298411 139.74197226057507 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669646467812946 139.74193684051042 8.77 35.66972402956048 139.74201814027262 8.77 35.66972402956048 139.74201814027262 13.11 35.669646467812946 139.74193684051042 13.11 35.669646467812946 139.74193684051042 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66972402956048 139.74201814027262 8.77 35.669762827557705 139.74196254487435 8.77 35.669762827557705 139.74196254487435 13.11 35.66972402956048 139.74201814027262 13.11 35.66972402956048 139.74201814027262 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669762827557705 139.74196254487435 8.77 35.66965881644848 139.74185351629401 8.77 35.66965881644848 139.74185351629401 13.11 35.669762827557705 139.74196254487435 13.11 35.669762827557705 139.74196254487435 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66965881644848 139.74185351629401 8.77 35.66958484747052 139.74193358585993 8.77 35.66958484747052 139.74193358585993 13.11 35.66965881644848 139.74185351629401 13.11 35.66965881644848 139.74185351629401 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66958484747052 139.74193358585993 13.11 35.66962174298411 139.74197226057507 13.11 35.669646467812946 139.74193684051042 13.11 35.66972402956048 139.74201814027262 13.11 35.669762827557705 139.74196254487435 13.11 35.66965881644848 139.74185351629401 13.11 35.66958484747052 139.74193358585993 13.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-4a6bdbe8-79ea-468c-84f7-4e0082be3c84"/>
							<gml:surfaceMember xlink:href="#poly-f127b22c-288c-437b-bfc5-ced97d2e3a7d"/>
							<gml:surfaceMember xlink:href="#poly-a65a2f97-223f-434b-ba37-6cf61d347b14"/>
							<gml:surfaceMember xlink:href="#poly-39a2dba6-6411-4486-8793-043846c8269d"/>
							<gml:surfaceMember xlink:href="#poly-c7c02ce1-1c97-47b6-a903-4756d930306d"/>
							<gml:surfaceMember xlink:href="#poly-03624e49-6b3c-42c6-a71a-ee726bc0d916"/>
							<gml:surfaceMember xlink:href="#poly-f857d773-b39e-4e6b-9718-f4c3cb8cbf42"/>
							<gml:surfaceMember xlink:href="#poly-e18483e4-17db-4154-b8a1-0c097cd867b9"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-4a6bdbe8-79ea-468c-84f7-4e0082be3c84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a6bdbe8-79ea-468c-84f7-4e0082be3c84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a6bdbe8-79ea-468c-84f7-4e0082be3c84">
											<gml:posList>35.66965881644847 139.74185351629401 8.77 35.6697628275577 139.74196254487433 8.77 35.66972402956047 139.7420181402726 8.77 35.66964646781294 139.74193684051045 8.77 35.66962174298413 139.74197226057507 8.77 35.669584847470496 139.74193358585993 8.77 35.66965881644847 139.74185351629401 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f127b22c-288c-437b-bfc5-ced97d2e3a7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f127b22c-288c-437b-bfc5-ced97d2e3a7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f127b22c-288c-437b-bfc5-ced97d2e3a7d">
											<gml:posList>35.66965881644847 139.74185351629401 13.805 35.669584847470496 139.74193358585993 13.805 35.66962174298413 139.74197226057507 13.805 35.66964646781294 139.74193684051045 13.805 35.66972402956047 139.7420181402726 13.805 35.6697628275577 139.74196254487433 13.805 35.66965881644847 139.74185351629401 13.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a65a2f97-223f-434b-ba37-6cf61d347b14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a65a2f97-223f-434b-ba37-6cf61d347b14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a65a2f97-223f-434b-ba37-6cf61d347b14">
											<gml:posList>35.66965881644847 139.74185351629401 8.77 35.669584847470496 139.74193358585993 8.77 35.669584847470496 139.74193358585993 13.805 35.66965881644847 139.74185351629401 13.805 35.66965881644847 139.74185351629401 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39a2dba6-6411-4486-8793-043846c8269d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39a2dba6-6411-4486-8793-043846c8269d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39a2dba6-6411-4486-8793-043846c8269d">
											<gml:posList>35.6697628275577 139.74196254487433 8.77 35.66965881644847 139.74185351629401 8.77 35.66965881644847 139.74185351629401 13.805 35.6697628275577 139.74196254487433 13.805 35.6697628275577 139.74196254487433 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7c02ce1-1c97-47b6-a903-4756d930306d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7c02ce1-1c97-47b6-a903-4756d930306d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7c02ce1-1c97-47b6-a903-4756d930306d">
											<gml:posList>35.669584847470496 139.74193358585993 8.77 35.66962174298413 139.74197226057507 8.77 35.66962174298413 139.74197226057507 13.805 35.669584847470496 139.74193358585993 13.805 35.669584847470496 139.74193358585993 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03624e49-6b3c-42c6-a71a-ee726bc0d916">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03624e49-6b3c-42c6-a71a-ee726bc0d916">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03624e49-6b3c-42c6-a71a-ee726bc0d916">
											<gml:posList>35.66962174298413 139.74197226057507 8.77 35.66964646781294 139.74193684051045 8.77 35.66964646781294 139.74193684051045 13.805 35.66962174298413 139.74197226057507 13.805 35.66962174298413 139.74197226057507 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f857d773-b39e-4e6b-9718-f4c3cb8cbf42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f857d773-b39e-4e6b-9718-f4c3cb8cbf42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f857d773-b39e-4e6b-9718-f4c3cb8cbf42">
											<gml:posList>35.66964646781294 139.74193684051045 8.77 35.66972402956047 139.7420181402726 8.77 35.66972402956047 139.7420181402726 13.805 35.66964646781294 139.74193684051045 13.805 35.66964646781294 139.74193684051045 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e18483e4-17db-4154-b8a1-0c097cd867b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e18483e4-17db-4154-b8a1-0c097cd867b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e18483e4-17db-4154-b8a1-0c097cd867b9">
											<gml:posList>35.66972402956047 139.7420181402726 8.77 35.6697628275577 139.74196254487433 8.77 35.6697628275577 139.74196254487433 13.805 35.66972402956047 139.7420181402726 13.805 35.66972402956047 139.7420181402726 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4126</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">110.43746</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>