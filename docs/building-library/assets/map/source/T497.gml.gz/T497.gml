<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_909d29f7-8d1e-4a37-b612-fb7dbdd76ed6">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">17</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67406443617986 139.7376860895043 0 35.674138682434126 139.73765230825057 0 35.67411373467038 139.73756440570878 0 35.67416068321542 139.7375481108561 0 35.67416448031163 139.73756235666613 0 35.67422367995196 139.73753654692524 0 35.67419511641237 139.73743583438082 0 35.674023201892446 139.73752043728456 0 35.67406443617986 139.7376860895043 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67406443617986 139.7376860895043 9.395 35.674023201892446 139.73752043728456 9.395 35.67419511641237 139.73743583438082 9.395 35.67422367995196 139.73753654692524 9.395 35.67416448031163 139.73756235666613 9.395 35.67416068321542 139.7375481108561 9.395 35.67411373467038 139.73756440570878 9.395 35.674138682434126 139.73765230825057 9.395 35.67406443617986 139.7376860895043 9.395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67406443617986 139.7376860895043 9.395 35.674138682434126 139.73765230825057 9.395 35.674138682434126 139.73765230825057 26.36 35.67406443617986 139.7376860895043 26.36 35.67406443617986 139.7376860895043 9.395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674138682434126 139.73765230825057 9.395 35.67411373467038 139.73756440570878 9.395 35.67411373467038 139.73756440570878 26.36 35.674138682434126 139.73765230825057 26.36 35.674138682434126 139.73765230825057 9.395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67411373467038 139.73756440570878 9.395 35.67416068321542 139.7375481108561 9.395 35.67416068321542 139.7375481108561 26.36 35.67411373467038 139.73756440570878 26.36 35.67411373467038 139.73756440570878 9.395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67416068321542 139.7375481108561 9.395 35.67416448031163 139.73756235666613 9.395 35.67416448031163 139.73756235666613 26.36 35.67416068321542 139.7375481108561 26.36 35.67416068321542 139.7375481108561 9.395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67416448031163 139.73756235666613 9.395 35.67422367995196 139.73753654692524 9.395 35.67422367995196 139.73753654692524 26.36 35.67416448031163 139.73756235666613 26.36 35.67416448031163 139.73756235666613 9.395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67422367995196 139.73753654692524 9.395 35.67419511641237 139.73743583438082 9.395 35.67419511641237 139.73743583438082 26.36 35.67422367995196 139.73753654692524 26.36 35.67422367995196 139.73753654692524 9.395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67419511641237 139.73743583438082 9.395 35.674023201892446 139.73752043728456 9.395 35.674023201892446 139.73752043728456 26.36 35.67419511641237 139.73743583438082 26.36 35.67419511641237 139.73743583438082 9.395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674023201892446 139.73752043728456 9.395 35.67406443617986 139.7376860895043 9.395 35.67406443617986 139.7376860895043 26.36 35.674023201892446 139.73752043728456 26.36 35.674023201892446 139.73752043728456 9.395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67406443617986 139.7376860895043 26.36 35.674138682434126 139.73765230825057 26.36 35.67411373467038 139.73756440570878 26.36 35.67416068321542 139.7375481108561 26.36 35.67416448031163 139.73756235666613 26.36 35.67422367995196 139.73753654692524 26.36 35.67419511641237 139.73743583438082 26.36 35.674023201892446 139.73752043728456 26.36 35.67406443617986 139.7376860895043 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2f76f425-729e-4ef1-adce-e65717027b50"/>
							<gml:surfaceMember xlink:href="#poly-92a0a704-4162-49ae-8b9e-1967342ce4fd"/>
							<gml:surfaceMember xlink:href="#poly-e6afe758-43ac-4de6-9348-9543740ff948"/>
							<gml:surfaceMember xlink:href="#poly-83f1274a-5a3f-4fb0-bf75-a580b6fdea2c"/>
							<gml:surfaceMember xlink:href="#poly-1dbe11a5-0d2c-4fdd-89cb-ba554a39478f"/>
							<gml:surfaceMember xlink:href="#poly-c4ae1bb0-b389-4b1e-a256-3cd5afabe5ef"/>
							<gml:surfaceMember xlink:href="#poly-ab7df758-a407-427d-ae83-ae3c49991097"/>
							<gml:surfaceMember xlink:href="#poly-06a1847a-670d-444c-acda-21e06909b1b9"/>
							<gml:surfaceMember xlink:href="#poly-40bf7a2b-5702-4167-a83e-949bdf73a418"/>
							<gml:surfaceMember xlink:href="#poly-548b1070-5860-4b57-840b-2d79859d0deb"/>
							<gml:surfaceMember xlink:href="#poly-2d8d8e47-f25d-4e8f-ac17-2506e755c43e"/>
							<gml:surfaceMember xlink:href="#poly-3fd8708c-b8ee-40bf-94dc-28492397cb12"/>
							<gml:surfaceMember xlink:href="#poly-31d2d1d3-2790-4020-bd85-ff925a2ca979"/>
							<gml:surfaceMember xlink:href="#poly-c641ecea-a790-4869-88ed-14b2eff2827c"/>
							<gml:surfaceMember xlink:href="#poly-4ea4ea12-2d22-4bf9-b393-5890c2e4e708"/>
							<gml:surfaceMember xlink:href="#poly-411e8fa6-a823-4b00-8ef5-9fa386d5376f"/>
							<gml:surfaceMember xlink:href="#poly-b8a72048-672f-4bbd-b770-af6120fc6a1f"/>
							<gml:surfaceMember xlink:href="#poly-4ca3697f-e76e-4a86-9877-227e2b98c6fb"/>
							<gml:surfaceMember xlink:href="#poly-4545b5de-15a8-48c3-8e79-66fe6ce58510"/>
							<gml:surfaceMember xlink:href="#poly-904b86a5-dff6-42cf-bbec-1fc6f24b8a8e"/>
							<gml:surfaceMember xlink:href="#poly-2f134f10-2544-4f23-b081-303ce97a21e6"/>
							<gml:surfaceMember xlink:href="#poly-0c67ef17-0eb1-4d87-9958-2a65ca11d882"/>
							<gml:surfaceMember xlink:href="#poly-08f1c1b0-dade-4738-a3bb-bc4cdc42029d"/>
							<gml:surfaceMember xlink:href="#poly-e404c06d-bced-459d-8fa7-43d9517a916b"/>
							<gml:surfaceMember xlink:href="#poly-af4d6cf6-b086-463f-9c31-22186be6ed3b"/>
							<gml:surfaceMember xlink:href="#poly-a6753513-b34c-4702-a2ca-39c7837aa2c1"/>
							<gml:surfaceMember xlink:href="#poly-044966f6-143e-42a2-a35f-248741ce9da6"/>
							<gml:surfaceMember xlink:href="#poly-da489950-e64a-498a-818e-0d2656202741"/>
							<gml:surfaceMember xlink:href="#poly-8cc22441-8f15-4735-9002-bf9ab034ffb4"/>
							<gml:surfaceMember xlink:href="#poly-e5b9c0ac-cbeb-4cff-ac29-10b509165791"/>
							<gml:surfaceMember xlink:href="#poly-7cf5a969-13a1-4ada-8365-6e5b00f57eb0"/>
							<gml:surfaceMember xlink:href="#poly-b6017d82-19db-4e75-b0ac-f64428b0a2ef"/>
							<gml:surfaceMember xlink:href="#poly-6bc2b1e9-3958-4efe-b2f9-eb46dc661f51"/>
							<gml:surfaceMember xlink:href="#poly-57b3aa05-9722-41df-b707-fe47bfd75f20"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_909d29f7-8d1e-4a37-b612-fb7dbdd76ed6_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a38ad503-de3a-4ef6-ad0a-69528c7e33b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a38ad503-de3a-4ef6-ad0a-69528c7e33b8_0">
											<gml:posList>35.67402893492301 139.7375434739779 29.212 35.674037543509456 139.73757807320035 27.233 35.674037543509456 139.73757807320035 29.212 35.67402893492301 139.7375434739779 29.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fa0d602-a549-4bf5-b6c6-a3d8d644e2ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fa0d602-a549-4bf5-b6c6-a3d8d644e2ca_0">
											<gml:posList>35.67402893492301 139.7375434739779 29.212 35.67402893492301 139.7375434739779 27.233 35.674037543509456 139.73757807320035 27.233 35.67402893492301 139.7375434739779 29.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5244dbcb-f4c6-4b76-a73c-cb73bec5f3ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5244dbcb-f4c6-4b76-a73c-cb73bec5f3ca_0">
											<gml:posList>35.67402893492301 139.7375434739779 29.212 35.67405229891201 139.7375326644179 27.233 35.67402893492301 139.7375434739779 27.233 35.67402893492301 139.7375434739779 29.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-744fa42b-7cd8-457d-b96c-1693555ea6e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-744fa42b-7cd8-457d-b96c-1693555ea6e0_0">
											<gml:posList>35.67402893492301 139.7375434739779 29.212 35.67405229891201 139.7375326644179 29.212 35.67405229891201 139.7375326644179 27.233 35.67402893492301 139.7375434739779 29.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7f72028-fec2-4838-9160-a77cbcbaeedc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7f72028-fec2-4838-9160-a77cbcbaeedc_0">
											<gml:posList>35.674037543509456 139.73757807320035 29.212 35.6740534739091 139.73757069702657 29.212 35.67402893492301 139.7375434739779 29.212 35.674037543509456 139.73757807320035 29.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bb188da-f9c4-4d7e-8c67-6bbc5ac015e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bb188da-f9c4-4d7e-8c67-6bbc5ac015e2_0">
											<gml:posList>35.67402893492301 139.7375434739779 29.212 35.6740534739091 139.73757069702657 29.212 35.67405229891201 139.7375326644179 29.212 35.67402893492301 139.7375434739779 29.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46251176-3b60-43a3-be2b-e17e081a56b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46251176-3b60-43a3-be2b-e17e081a56b1_0">
											<gml:posList>35.6740534739091 139.73757069702657 29.212 35.67406270057216 139.7375664329998 29.212 35.67405229891201 139.7375326644179 29.212 35.6740534739091 139.73757069702657 29.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a45b9652-dc80-41af-8725-b7f79c619fbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a45b9652-dc80-41af-8725-b7f79c619fbf_0">
											<gml:posList>35.6740534739091 139.73757069702657 29.212 35.674037543509456 139.73757807320035 27.233 35.6740596820842 139.73756782849821 27.233 35.6740534739091 139.73757069702657 29.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-256da1b4-4358-4807-a03d-55a09962553a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-256da1b4-4358-4807-a03d-55a09962553a_0">
											<gml:posList>35.6740534739091 139.73757069702657 29.212 35.674037543509456 139.73757807320035 29.212 35.674037543509456 139.73757807320035 27.233 35.6740534739091 139.73757069702657 29.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce4312c8-9675-41ef-a05c-9169a7c244d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce4312c8-9675-41ef-a05c-9169a7c244d7_0">
											<gml:posList>35.67405229891201 139.7375326644179 29.212 35.67406270057216 139.7375664329998 27.233 35.67405229891201 139.7375326644179 27.233 35.67405229891201 139.7375326644179 29.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7162f920-bc64-4f78-946a-e1d47484886a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7162f920-bc64-4f78-946a-e1d47484886a_0">
											<gml:posList>35.67405229891201 139.7375326644179 29.212 35.67406270057216 139.7375664329998 29.212 35.67406270057216 139.7375664329998 27.233 35.67405229891201 139.7375326644179 29.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f081e363-9679-4973-b551-72e213baf5f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f081e363-9679-4973-b551-72e213baf5f0_0">
											<gml:posList>35.67406270057216 139.7375664329998 29.212 35.6740596820842 139.73756782849821 27.233 35.67406270057216 139.7375664329998 27.233 35.67406270057216 139.7375664329998 29.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcc14cee-04db-4d77-9ecf-bbb773d3e100">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcc14cee-04db-4d77-9ecf-bbb773d3e100_0">
											<gml:posList>35.67406270057216 139.7375664329998 29.212 35.6740534739091 139.73757069702657 29.212 35.6740596820842 139.73756782849821 27.233 35.67406270057216 139.7375664329998 29.212</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cbd30ac-259e-47a5-b908-e9746ce303c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cbd30ac-259e-47a5-b908-e9746ce303c2_0">
											<gml:posList>35.67410927973982 139.73750505671964 30.081 35.67410927973982 139.73750505671964 27.233 35.67411663850311 139.73753218984686 27.233 35.67410927973982 139.73750505671964 30.081</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-322eabd6-1b6e-4efa-b35c-4b9412d42156">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-322eabd6-1b6e-4efa-b35c-4b9412d42156_0">
											<gml:posList>35.67411663850311 139.73753218984686 30.624 35.67410927973982 139.73750505671964 30.081 35.67411663850311 139.73753218984686 27.233 35.67411663850311 139.73753218984686 30.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73dae7fe-b71d-4c4c-aac1-e35998e6dc8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73dae7fe-b71d-4c4c-aac1-e35998e6dc8c_0">
											<gml:posList>35.674133759035485 139.73752522096504 30.624 35.67411663850311 139.73753218984686 27.233 35.674133759035485 139.73752522096504 27.233 35.674133759035485 139.73752522096504 30.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00ebba92-fae6-4ce7-97da-fa5de2459a5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00ebba92-fae6-4ce7-97da-fa5de2459a5b_0">
											<gml:posList>35.674133759035485 139.73752522096504 30.624 35.67411663850311 139.73753218984686 30.624 35.67411663850311 139.73753218984686 27.233 35.674133759035485 139.73752522096504 30.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6931b966-721c-483d-ad47-d54ce8f72e99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6931b966-721c-483d-ad47-d54ce8f72e99_0">
											<gml:posList>35.674141795035574 139.73755387774855 27.233 35.674141795035574 139.73755387774855 30.286 35.674133759035485 139.73752522096504 27.233 35.674141795035574 139.73755387774855 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d2fbf83-94b7-4e0b-9934-7bf732c8cd5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d2fbf83-94b7-4e0b-9934-7bf732c8cd5f_0">
											<gml:posList>35.674133759035485 139.73752522096504 27.233 35.674135774833786 139.73753243210103 30.771 35.674133759035485 139.73752522096504 30.624 35.674133759035485 139.73752522096504 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8491e28-5a87-47ca-8ed0-9d6ff503cff6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8491e28-5a87-47ca-8ed0-9d6ff503cff6_0">
											<gml:posList>35.674133759035485 139.73752522096504 27.233 35.674141795035574 139.73755387774855 30.286 35.674135774833786 139.73753243210103 30.771 35.674133759035485 139.73752522096504 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00126548-431d-42cd-a709-22fd147cdf9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00126548-431d-42cd-a709-22fd147cdf9c_0">
											<gml:posList>35.67410927973982 139.73750505671964 30.081 35.67417810424965 139.73747701504269 27.233 35.67410927973982 139.73750505671964 27.233 35.67410927973982 139.73750505671964 30.081</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eec4f304-71cd-4d89-aaba-93af62a828c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eec4f304-71cd-4d89-aaba-93af62a828c6_0">
											<gml:posList>35.67410927973982 139.73750505671964 30.081 35.67417810424965 139.73747701504269 30.081 35.67417810424965 139.73747701504269 27.233 35.67410927973982 139.73750505671964 30.081</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f63c1e5-5a43-425d-8f6b-ecbfa85cdf3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f63c1e5-5a43-425d-8f6b-ecbfa85cdf3f_0">
											<gml:posList>35.674133759035485 139.73752522096504 30.624 35.67417810424965 139.73747701504269 30.081 35.67410927973982 139.73750505671964 30.081 35.674133759035485 139.73752522096504 30.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b54061f-10bc-4361-ac87-f03d219cd153">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b54061f-10bc-4361-ac87-f03d219cd153_0">
											<gml:posList>35.67410927973982 139.73750505671964 30.081 35.67411663850311 139.73753218984686 30.624 35.674133759035485 139.73752522096504 30.624 35.67410927973982 139.73750505671964 30.081</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4d4cd19-fd04-42a3-8ef1-07c1894cd469">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4d4cd19-fd04-42a3-8ef1-07c1894cd469_0">
											<gml:posList>35.6741875765982 139.7375096359156 30.771 35.67417810424965 139.73747701504269 30.081 35.674133759035485 139.73752522096504 30.624 35.6741875765982 139.7375096359156 30.771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10833eb9-cbe6-4732-bcc2-04811a6f0373">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10833eb9-cbe6-4732-bcc2-04811a6f0373_0">
											<gml:posList>35.674135774833786 139.73753243210103 30.771 35.6741875765982 139.7375096359156 30.771 35.674133759035485 139.73752522096504 30.624 35.674135774833786 139.73753243210103 30.771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9863f4c-191d-4432-b844-5c37da381f30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9863f4c-191d-4432-b844-5c37da381f30_0">
											<gml:posList>35.674141795035574 139.73755387774855 30.286 35.674161349395554 139.737547060616 27.233 35.674161349395554 139.737547060616 30.286 35.674141795035574 139.73755387774855 30.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d71230d-74d0-4dee-b651-4aedc3b1e1b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d71230d-74d0-4dee-b651-4aedc3b1e1b6_0">
											<gml:posList>35.674141795035574 139.73755387774855 30.286 35.674141795035574 139.73755387774855 27.233 35.674161349395554 139.737547060616 27.233 35.674141795035574 139.73755387774855 30.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac2bd800-1ab0-40b1-9fc1-f13c69b3c2a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac2bd800-1ab0-40b1-9fc1-f13c69b3c2a6_0">
											<gml:posList>35.67416426120585 139.73755886614526 30.081 35.674161349395554 139.737547060616 27.233 35.67416426120585 139.73755886614526 27.233 35.67416426120585 139.73755886614526 30.081</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5783d5d3-5e77-4cc7-a982-d1811fdd4efb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5783d5d3-5e77-4cc7-a982-d1811fdd4efb_0">
											<gml:posList>35.67416426120585 139.73755886614526 30.081 35.674161349395554 139.737547060616 30.286 35.674161349395554 139.737547060616 27.233 35.67416426120585 139.73755886614526 30.081</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53e16afc-1002-42c4-b3f9-179ba3ce4a74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53e16afc-1002-42c4-b3f9-179ba3ce4a74_0">
											<gml:posList>35.674161349395554 139.737547060616 30.286 35.6741875765982 139.7375096359156 30.771 35.674135774833786 139.73753243210103 30.771 35.674161349395554 139.737547060616 30.286</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ddbb8bc-308f-42e0-85c9-86cdc6f27029">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ddbb8bc-308f-42e0-85c9-86cdc6f27029_0">
											<gml:posList>35.674135774833786 139.73753243210103 30.771 35.674141795035574 139.73755387774855 30.286 35.674161349395554 139.737547060616 30.286 35.674135774833786 139.73753243210103 30.771</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40b9e3a9-a22a-4937-a857-f2a9d5c2c70d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40b9e3a9-a22a-4937-a857-f2a9d5c2c70d_0">
											<gml:posList>35.6741978985649 139.73754519422587 30.081 35.6741875765982 139.7375096359156 30.771 35.674161349395554 139.737547060616 30.286 35.6741978985649 139.73754519422587 30.081</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e055385-48f2-4f2b-8e4c-c16af5155e32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e055385-48f2-4f2b-8e4c-c16af5155e32_0">
											<gml:posList>35.67416426120585 139.73755886614526 30.081 35.6741978985649 139.73754519422587 30.081 35.674161349395554 139.737547060616 30.286 35.67416426120585 139.73755886614526 30.081</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8d7c53e-128e-4bf1-8019-5a2c8b905afa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8d7c53e-128e-4bf1-8019-5a2c8b905afa_0">
											<gml:posList>35.6741978985649 139.73754519422587 30.081 35.67416426120585 139.73755886614526 27.233 35.6741978985649 139.73754519422587 27.233 35.6741978985649 139.73754519422587 30.081</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3648c419-86b4-48ca-bbc5-2afcc1223bcf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3648c419-86b4-48ca-bbc5-2afcc1223bcf_0">
											<gml:posList>35.6741978985649 139.73754519422587 30.081 35.67416426120585 139.73755886614526 30.081 35.67416426120585 139.73755886614526 27.233 35.6741978985649 139.73754519422587 30.081</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e16e6c3-9ee8-469c-8533-15aaf4c44c50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e16e6c3-9ee8-469c-8533-15aaf4c44c50_0">
											<gml:posList>35.6741978985649 139.73754519422587 27.233 35.67417810424965 139.73747701504269 27.233 35.6741875765982 139.7375096359156 30.771 35.6741978985649 139.73754519422587 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4d41ab3-9fa3-4036-946b-42f733a52222">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4d41ab3-9fa3-4036-946b-42f733a52222_0">
											<gml:posList>35.6741978985649 139.73754519422587 27.233 35.6741875765982 139.7375096359156 30.771 35.6741978985649 139.73754519422587 30.081 35.6741978985649 139.73754519422587 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e39b4f85-457e-4305-83cc-68f744cfa1a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e39b4f85-457e-4305-83cc-68f744cfa1a7_0">
											<gml:posList>35.67417810424965 139.73747701504269 27.233 35.67417810424965 139.73747701504269 30.081 35.6741875765982 139.7375096359156 30.771 35.67417810424965 139.73747701504269 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b59e10b-30cb-4f9b-b64a-dac27cd30bdb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67406270057216 139.7375664329998 27.233 35.6740596820842 139.73756782849821 27.233 35.67405229891201 139.7375326644179 27.233 35.67406270057216 139.7375664329998 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-093b6d3a-26b0-4d81-ab59-027d7fec2d24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67405229891201 139.7375326644179 27.233 35.6740596820842 139.73756782849821 27.233 35.67402893492301 139.7375434739779 27.233 35.67405229891201 139.7375326644179 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f8a75cd-ce77-4902-98ea-f3f4678ae415">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6740596820842 139.73756782849821 27.233 35.674037543509456 139.73757807320035 27.233 35.67402893492301 139.7375434739779 27.233 35.6740596820842 139.73756782849821 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83ba1361-1601-4899-8afc-5edeab972e90">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674161349395554 139.737547060616 27.233 35.674141795035574 139.73755387774855 27.233 35.674133759035485 139.73752522096504 27.233 35.674161349395554 139.737547060616 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6dd2b641-54a6-47fc-938b-13ba82085f71">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6741978985649 139.73754519422587 27.233 35.67416426120585 139.73755886614526 27.233 35.674161349395554 139.737547060616 27.233 35.6741978985649 139.73754519422587 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9379b273-7298-4122-8926-feac92957b40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6741978985649 139.73754519422587 27.233 35.674161349395554 139.737547060616 27.233 35.67417810424965 139.73747701504269 27.233 35.6741978985649 139.73754519422587 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e67f638-33bd-4e3f-bb98-dccab01555c1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674133759035485 139.73752522096504 27.233 35.67411663850311 139.73753218984686 27.233 35.67410927973982 139.73750505671964 27.233 35.674133759035485 139.73752522096504 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f839510-4fa4-4b6f-9cfa-20bdf6effbb3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67417810424965 139.73747701504269 27.233 35.674133759035485 139.73752522096504 27.233 35.67410927973982 139.73750505671964 27.233 35.67417810424965 139.73747701504269 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5389bf58-9236-4a36-9452-9769b8f63502">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674161349395554 139.737547060616 27.233 35.674133759035485 139.73752522096504 27.233 35.67417810424965 139.73747701504269 27.233 35.674161349395554 139.737547060616 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_909d29f7-8d1e-4a37-b612-fb7dbdd76ed6_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-938d4434-d1d8-46a6-9a65-469a49560834">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674042398414485 139.7375850158158 30.739 35.67404261466462 139.73758491613663 30.739 35.674043753976825 139.73758942185557 30.739 35.674042398414485 139.7375850158158 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b14ba888-6c11-4f0b-9dde-b291b7754b1d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674052935737365 139.73759670175474 30.198 35.67404686272341 139.7375995148854 30.198 35.674043753976825 139.73758942185557 30.198 35.67404261466462 139.73758491613663 30.198 35.6740484714281 139.7375822026842 30.198 35.674052935737365 139.73759670175474 30.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e147369b-76cd-47c4-810d-a51e31617384">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674053431946156 139.73763128858423 33.933 35.67406984000575 139.73762382347513 33.933 35.67407423220027 139.7376383226379 33.933 35.67405782413977 139.73764578774444 33.933 35.674053431946156 139.73763128858423 33.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-444ff4a0-b700-4b88-bbdd-b676930f9096">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67412500488682 139.73764761864894 30.198 35.67410909240473 139.7376548622314 30.198 35.6740985366669 139.73762000017206 30.198 35.67411444914691 139.73761275658364 30.198 35.67412500488682 139.73764761864894 30.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1faa0fb-eae4-4b14-a38e-db2419085911">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1faa0fb-eae4-4b14-a38e-db2419085911_0">
											<gml:posList>35.67404261466462 139.73758491613663 30.739 35.674042398414485 139.7375850158158 30.739 35.674042398414485 139.7375850158158 31.756 35.6740484714281 139.7375822026842 31.756 35.6740484714281 139.7375822026842 30.198 35.67404261466462 139.73758491613663 30.198 35.67404261466462 139.73758491613663 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfa7f3d1-e854-47f4-b7e5-29764023c4b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfa7f3d1-e854-47f4-b7e5-29764023c4b7_0">
											<gml:posList>35.67404261466462 139.73758491613663 30.739 35.67404261466462 139.73758491613663 30.198 35.674043753976825 139.73758942185557 30.198 35.674043753976825 139.73758942185557 30.739 35.67404261466462 139.73758491613663 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f047922-21fa-4f4f-86db-fe6f0848d69a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f047922-21fa-4f4f-86db-fe6f0848d69a_0">
											<gml:posList>35.674052935737365 139.73759670175474 31.756 35.674052935737365 139.73759670175474 30.198 35.6740484714281 139.7375822026842 30.198 35.6740484714281 139.7375822026842 31.756 35.674052935737365 139.73759670175474 31.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d53de19-fba5-43ff-9faa-5522bd5f9647">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d53de19-fba5-43ff-9faa-5522bd5f9647_0">
											<gml:posList>35.6740484714281 139.7375822026842 31.756 35.674042398414485 139.7375850158158 31.756 35.67404686272341 139.7375995148854 31.756 35.674052935737365 139.73759670175474 31.756 35.6740484714281 139.7375822026842 31.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74c52aac-19dd-4998-bc88-4e4e805023dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74c52aac-19dd-4998-bc88-4e4e805023dc_0">
											<gml:posList>35.674043753976825 139.73758942185557 30.739 35.674043753976825 139.73758942185557 30.198 35.67404686272341 139.7375995148854 30.198 35.67404686272341 139.7375995148854 31.756 35.674042398414485 139.7375850158158 31.756 35.674042398414485 139.7375850158158 30.739 35.674043753976825 139.73758942185557 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0560be9-f279-49a6-8e5e-8f019e137d90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0560be9-f279-49a6-8e5e-8f019e137d90_0">
											<gml:posList>35.674052935737365 139.73759670175474 31.756 35.67404686272341 139.7375995148854 31.756 35.67404686272341 139.7375995148854 30.198 35.674052935737365 139.73759670175474 30.198 35.674052935737365 139.73759670175474 31.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e346a67-175f-4b3f-b6df-68728f3756e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e346a67-175f-4b3f-b6df-68728f3756e3_0">
											<gml:posList>35.67411444914691 139.73761275658364 32.696 35.67411444914691 139.73761275658364 30.198 35.6740985366669 139.73762000017206 30.198 35.6740985366669 139.73762000017206 32.696 35.67411444914691 139.73761275658364 32.696</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80fcc6f9-9193-44ff-9cfd-a472a5c951ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80fcc6f9-9193-44ff-9cfd-a472a5c951ce_0">
											<gml:posList>35.674053431946156 139.73763128858423 35.707 35.67406984000575 139.73762382347513 35.707 35.67406984000575 139.73762382347513 33.933 35.674053431946156 139.73763128858423 33.933 35.674053431946156 139.73763128858423 35.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c313d4a-7f10-409a-bd42-74b0a121c2d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c313d4a-7f10-409a-bd42-74b0a121c2d9_0">
											<gml:posList>35.67411444914691 139.73761275658364 32.696 35.67412500488682 139.73764761864894 32.696 35.67412500488682 139.73764761864894 30.198 35.67411444914691 139.73761275658364 30.198 35.67411444914691 139.73761275658364 32.696</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af3e0286-e19b-44ee-ad29-6abcdd5d65ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af3e0286-e19b-44ee-ad29-6abcdd5d65ea_0">
											<gml:posList>35.67406984000575 139.73762382347513 35.707 35.67407423220027 139.7376383226379 35.707 35.67407423220027 139.7376383226379 33.933 35.67406984000575 139.73762382347513 33.933 35.67406984000575 139.73762382347513 35.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2abff3d2-4a25-4d89-a38a-1cc8d9899549">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2abff3d2-4a25-4d89-a38a-1cc8d9899549_0">
											<gml:posList>35.6740985366669 139.73762000017206 32.696 35.67410909240473 139.7376548622314 32.696 35.67412500488682 139.73764761864894 32.696 35.67411444914691 139.73761275658364 32.696 35.6740985366669 139.73762000017206 32.696</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e4a1fb2-80b9-45d9-be1e-1ccc10d5fd6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e4a1fb2-80b9-45d9-be1e-1ccc10d5fd6b_0">
											<gml:posList>35.67407423220027 139.7376383226379 35.707 35.67406984000575 139.73762382347513 35.707 35.674053431946156 139.73763128858423 35.707 35.67405782413977 139.73764578774444 35.707 35.67407423220027 139.7376383226379 35.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2cb7cbd6-a512-43b6-9914-87c4efa922c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2cb7cbd6-a512-43b6-9914-87c4efa922c6_0">
											<gml:posList>35.67410909240473 139.7376548622314 32.696 35.6740985366669 139.73762000017206 32.696 35.6740985366669 139.73762000017206 30.198 35.67410909240473 139.7376548622314 30.198 35.67410909240473 139.7376548622314 32.696</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bbee086-a81a-47f2-a4f2-e8c9d66cd2cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bbee086-a81a-47f2-a4f2-e8c9d66cd2cf_0">
											<gml:posList>35.67405782413977 139.73764578774444 35.707 35.674053431946156 139.73763128858423 35.707 35.674053431946156 139.73763128858423 33.933 35.67405782413977 139.73764578774444 33.933 35.67405782413977 139.73764578774444 35.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-866c0b4e-2ef4-4aad-99e4-4a331ec3b34b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-866c0b4e-2ef4-4aad-99e4-4a331ec3b34b_0">
											<gml:posList>35.67407423220027 139.7376383226379 35.707 35.67405782413977 139.73764578774444 35.707 35.67405782413977 139.73764578774444 33.933 35.67407423220027 139.7376383226379 33.933 35.67407423220027 139.7376383226379 35.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05219c47-d44a-4b3f-9cbf-74a4e7cc0cf7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05219c47-d44a-4b3f-9cbf-74a4e7cc0cf7_0">
											<gml:posList>35.67410909240473 139.7376548622314 32.696 35.67410909240473 139.7376548622314 30.198 35.67412500488682 139.73764761864894 30.198 35.67412500488682 139.73764761864894 32.696 35.67410909240473 139.7376548622314 32.696</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2f76f425-729e-4ef1-adce-e65717027b50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f76f425-729e-4ef1-adce-e65717027b50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f76f425-729e-4ef1-adce-e65717027b50">
											<gml:posList>35.67422367995193 139.73753654692524 9.395 35.674164480311624 139.73756235666613 9.395 35.674160683215405 139.7375481108561 9.395 35.67411373467038 139.73756440570878 9.395 35.674138682434105 139.7376523082506 9.395 35.67406443617986 139.7376860895043 9.395 35.67402320189243 139.73752043728453 9.395 35.67419511641237 139.73743583438082 9.395 35.67422367995193 139.73753654692524 9.395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-92a0a704-4162-49ae-8b9e-1967342ce4fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92a0a704-4162-49ae-8b9e-1967342ce4fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92a0a704-4162-49ae-8b9e-1967342ce4fd">
											<gml:posList>35.67402765086229 139.7375383056277 26.714 35.67419511641237 139.73743583438082 23.376 35.67402320189243 139.73752043728453 23.376 35.67402765086229 139.7375383056277 26.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6afe758-43ac-4de6-9348-9543740ff948">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6afe758-43ac-4de6-9348-9543740ff948">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6afe758-43ac-4de6-9348-9543740ff948">
											<gml:posList>35.67402765086229 139.7375383056277 26.714 35.67417810424965 139.73747701504269 26.714 35.67419511641237 139.73743583438082 23.376 35.67402765086229 139.7375383056277 26.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-83f1274a-5a3f-4fb0-bf75-a580b6fdea2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83f1274a-5a3f-4fb0-bf75-a580b6fdea2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83f1274a-5a3f-4fb0-bf75-a580b6fdea2c">
											<gml:posList>35.67417810424965 139.73747701504269 26.714 35.674198558402864 139.73754750221556 26.714 35.67422367995193 139.73753654692524 23.376 35.67419511641237 139.73743583438082 23.376 35.67417810424965 139.73747701504269 26.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1dbe11a5-0d2c-4fdd-89cb-ba554a39478f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1dbe11a5-0d2c-4fdd-89cb-ba554a39478f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1dbe11a5-0d2c-4fdd-89cb-ba554a39478f">
											<gml:posList>35.67410743724226 139.73754572209242 27.233 35.67411373467038 139.73756440570878 27.233 35.674160683215405 139.7375481108561 27.233 35.674164480311624 139.73756235666613 27.233 35.674198558402864 139.73754750221556 27.233 35.67417810424965 139.73747701504269 27.233 35.67402765086229 139.7375383056277 27.233 35.674037543509456 139.73757807320035 27.233 35.67410743724226 139.73754572209242 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c4ae1bb0-b389-4b1e-a256-3cd5afabe5ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4ae1bb0-b389-4b1e-a256-3cd5afabe5ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4ae1bb0-b389-4b1e-a256-3cd5afabe5ef">
											<gml:posList>35.67411373467038 139.73756440570878 30.739 35.67410743724226 139.73754572209242 30.739 35.67410565650728 139.73755072840808 30.739 35.67411074324997 139.73756583431614 30.739 35.67411373467038 139.73756440570878 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab7df758-a407-427d-ae83-ae3c49991097">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab7df758-a407-427d-ae83-ae3c49991097">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab7df758-a407-427d-ae83-ae3c49991097">
											<gml:posList>35.674037543509456 139.73757807320035 30.739 35.67404147537859 139.7375804435581 30.739 35.67410565650728 139.73755072840808 30.739 35.67410743724226 139.73754572209242 30.739 35.674037543509456 139.73757807320035 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06a1847a-670d-444c-acda-21e06909b1b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06a1847a-670d-444c-acda-21e06909b1b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06a1847a-670d-444c-acda-21e06909b1b9">
											<gml:posList>35.67404147537859 139.7375804435581 30.739 35.674037543509456 139.73757807320035 30.739 35.67404945259482 139.73762588042 30.739 35.67405263329523 139.73762444054324 30.739 35.67404147537859 139.7375804435581 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-40bf7a2b-5702-4167-a83e-949bdf73a418">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40bf7a2b-5702-4167-a83e-949bdf73a418">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40bf7a2b-5702-4167-a83e-949bdf73a418">
											<gml:posList>35.67411074324997 139.73756583431614 30.198 35.67410565650728 139.73755072840808 30.198 35.67404147537859 139.7375804435581 30.198 35.67405263329523 139.73762444054324 30.198 35.67409006276724 139.73760740592436 30.198 35.67410500165218 139.73765672297145 30.198 35.674112038827836 139.73765352205527 30.198 35.67411382823104 139.7376594188967 30.198 35.674116819705226 139.73765805657334 30.198 35.674134624391975 139.73764996013057 30.198 35.67411074324997 139.73756583431614 30.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-548b1070-5860-4b57-840b-2d79859d0deb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-548b1070-5860-4b57-840b-2d79859d0deb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-548b1070-5860-4b57-840b-2d79859d0deb">
											<gml:posList>35.67411373467038 139.73756440570878 30.739 35.67411074324997 139.73756583431614 30.739 35.674134624391975 139.73764996013057 30.739 35.674138682434105 139.7376523082506 30.739 35.67411373467038 139.73756440570878 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d8d8e47-f25d-4e8f-ac17-2506e755c43e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d8d8e47-f25d-4e8f-ac17-2506e755c43e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d8d8e47-f25d-4e8f-ac17-2506e755c43e">
											<gml:posList>35.67406443617986 139.7376860895043 33.933 35.674114939849794 139.73766310719245 33.933 35.674112038827836 139.73765352205527 33.933 35.67410500165218 139.73765672297145 33.933 35.67409006276724 139.73760740592436 33.933 35.67404945259482 139.73762588042 33.933 35.67406443617986 139.7376860895043 33.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3fd8708c-b8ee-40bf-94dc-28492397cb12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fd8708c-b8ee-40bf-94dc-28492397cb12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fd8708c-b8ee-40bf-94dc-28492397cb12">
											<gml:posList>35.674116819705226 139.73765805657334 30.739 35.67411382823104 139.7376594188967 30.739 35.674114939849794 139.73766310719245 30.739 35.674138682434105 139.7376523082506 30.739 35.674134624391975 139.73764996013057 30.739 35.674116819705226 139.73765805657334 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31d2d1d3-2790-4020-bd85-ff925a2ca979">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31d2d1d3-2790-4020-bd85-ff925a2ca979">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31d2d1d3-2790-4020-bd85-ff925a2ca979">
											<gml:posList>35.67419511641237 139.73743583438082 9.395 35.67402320189243 139.73752043728453 9.395 35.67402320189243 139.73752043728453 23.376 35.67419511641237 139.73743583438082 23.376 35.67419511641237 139.73743583438082 9.395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c641ecea-a790-4869-88ed-14b2eff2827c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c641ecea-a790-4869-88ed-14b2eff2827c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c641ecea-a790-4869-88ed-14b2eff2827c">
											<gml:posList>35.67402765086229 139.7375383056277 27.233 35.67417810424965 139.73747701504269 27.233 35.67417810424965 139.73747701504269 26.714 35.67402765086229 139.7375383056277 26.714 35.67402765086229 139.7375383056277 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ea4ea12-2d22-4bf9-b393-5890c2e4e708">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ea4ea12-2d22-4bf9-b393-5890c2e4e708">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ea4ea12-2d22-4bf9-b393-5890c2e4e708">
											<gml:posList>35.67410743724226 139.73754572209242 27.233 35.67410743724226 139.73754572209242 30.739 35.67411373467038 139.73756440570878 30.739 35.67411373467038 139.73756440570878 27.233 35.67410743724226 139.73754572209242 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-411e8fa6-a823-4b00-8ef5-9fa386d5376f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-411e8fa6-a823-4b00-8ef5-9fa386d5376f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-411e8fa6-a823-4b00-8ef5-9fa386d5376f">
											<gml:posList>35.674160683215405 139.7375481108561 27.233 35.67411373467038 139.73756440570878 27.233 35.67411373467038 139.73756440570878 9.395 35.674160683215405 139.7375481108561 9.395 35.674160683215405 139.7375481108561 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8a72048-672f-4bbd-b770-af6120fc6a1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8a72048-672f-4bbd-b770-af6120fc6a1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8a72048-672f-4bbd-b770-af6120fc6a1f">
											<gml:posList>35.67410565650728 139.73755072840808 30.739 35.67410565650728 139.73755072840808 30.198 35.67411074324997 139.73756583431614 30.198 35.67411074324997 139.73756583431614 30.739 35.67410565650728 139.73755072840808 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ca3697f-e76e-4a86-9877-227e2b98c6fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ca3697f-e76e-4a86-9877-227e2b98c6fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ca3697f-e76e-4a86-9877-227e2b98c6fb">
											<gml:posList>35.674037543509456 139.73757807320035 30.739 35.67410743724226 139.73754572209242 30.739 35.67410743724226 139.73754572209242 27.233 35.674037543509456 139.73757807320035 27.233 35.674037543509456 139.73757807320035 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4545b5de-15a8-48c3-8e79-66fe6ce58510">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4545b5de-15a8-48c3-8e79-66fe6ce58510">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4545b5de-15a8-48c3-8e79-66fe6ce58510">
											<gml:posList>35.67404147537859 139.7375804435581 30.739 35.67404147537859 139.7375804435581 30.198 35.67410565650728 139.73755072840808 30.198 35.67410565650728 139.73755072840808 30.739 35.67404147537859 139.7375804435581 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-904b86a5-dff6-42cf-bbec-1fc6f24b8a8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-904b86a5-dff6-42cf-bbec-1fc6f24b8a8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-904b86a5-dff6-42cf-bbec-1fc6f24b8a8e">
											<gml:posList>35.67405263329523 139.73762444054324 30.739 35.67405263329523 139.73762444054324 30.198 35.67404147537859 139.7375804435581 30.198 35.67404147537859 139.7375804435581 30.739 35.67405263329523 139.73762444054324 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f134f10-2544-4f23-b081-303ce97a21e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f134f10-2544-4f23-b081-303ce97a21e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f134f10-2544-4f23-b081-303ce97a21e6">
											<gml:posList>35.67402765086229 139.7375383056277 26.714 35.67402320189243 139.73752043728453 23.376 35.67402320189243 139.73752043728453 9.395 35.67406443617986 139.7376860895043 9.395 35.67406443617986 139.7376860895043 33.933 35.67404945259482 139.73762588042 33.933 35.67404945259482 139.73762588042 30.739 35.674037543509456 139.73757807320035 30.739 35.674037543509456 139.73757807320035 27.233 35.67402765086229 139.7375383056277 27.233 35.67402765086229 139.7375383056277 26.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c67ef17-0eb1-4d87-9958-2a65ca11d882">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c67ef17-0eb1-4d87-9958-2a65ca11d882">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c67ef17-0eb1-4d87-9958-2a65ca11d882">
											<gml:posList>35.67411074324997 139.73756583431614 30.739 35.67411074324997 139.73756583431614 30.198 35.674134624391975 139.73764996013057 30.198 35.674134624391975 139.73764996013057 30.739 35.67411074324997 139.73756583431614 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08f1c1b0-dade-4738-a3bb-bc4cdc42029d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08f1c1b0-dade-4738-a3bb-bc4cdc42029d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08f1c1b0-dade-4738-a3bb-bc4cdc42029d">
											<gml:posList>35.674138682434105 139.7376523082506 30.739 35.674138682434105 139.7376523082506 9.395 35.67411373467038 139.73756440570878 9.395 35.67411373467038 139.73756440570878 27.233 35.67411373467038 139.73756440570878 30.739 35.674138682434105 139.7376523082506 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e404c06d-bced-459d-8fa7-43d9517a916b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e404c06d-bced-459d-8fa7-43d9517a916b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e404c06d-bced-459d-8fa7-43d9517a916b">
											<gml:posList>35.67405263329523 139.73762444054324 30.739 35.67404945259482 139.73762588042 30.739 35.67404945259482 139.73762588042 33.933 35.67409006276724 139.73760740592436 33.933 35.67409006276724 139.73760740592436 30.198 35.67405263329523 139.73762444054324 30.198 35.67405263329523 139.73762444054324 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af4d6cf6-b086-463f-9c31-22186be6ed3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af4d6cf6-b086-463f-9c31-22186be6ed3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af4d6cf6-b086-463f-9c31-22186be6ed3b">
											<gml:posList>35.67409006276724 139.73760740592436 33.933 35.67410500165218 139.73765672297145 33.933 35.67410500165218 139.73765672297145 30.198 35.67409006276724 139.73760740592436 30.198 35.67409006276724 139.73760740592436 33.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6753513-b34c-4702-a2ca-39c7837aa2c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6753513-b34c-4702-a2ca-39c7837aa2c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6753513-b34c-4702-a2ca-39c7837aa2c1">
											<gml:posList>35.674134624391975 139.73764996013057 30.739 35.674134624391975 139.73764996013057 30.198 35.674116819705226 139.73765805657334 30.198 35.674116819705226 139.73765805657334 30.739 35.674134624391975 139.73764996013057 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-044966f6-143e-42a2-a35f-248741ce9da6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-044966f6-143e-42a2-a35f-248741ce9da6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-044966f6-143e-42a2-a35f-248741ce9da6">
											<gml:posList>35.67410500165218 139.73765672297145 33.933 35.674112038827836 139.73765352205527 33.933 35.674112038827836 139.73765352205527 30.198 35.67410500165218 139.73765672297145 30.198 35.67410500165218 139.73765672297145 33.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da489950-e64a-498a-818e-0d2656202741">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da489950-e64a-498a-818e-0d2656202741">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da489950-e64a-498a-818e-0d2656202741">
											<gml:posList>35.67411382823104 139.7376594188967 30.739 35.67411382823104 139.7376594188967 30.198 35.674112038827836 139.73765352205527 30.198 35.674112038827836 139.73765352205527 33.933 35.674114939849794 139.73766310719245 33.933 35.674114939849794 139.73766310719245 30.739 35.67411382823104 139.7376594188967 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cc22441-8f15-4735-9002-bf9ab034ffb4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cc22441-8f15-4735-9002-bf9ab034ffb4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cc22441-8f15-4735-9002-bf9ab034ffb4">
											<gml:posList>35.674116819705226 139.73765805657334 30.739 35.674116819705226 139.73765805657334 30.198 35.67411382823104 139.7376594188967 30.198 35.67411382823104 139.7376594188967 30.739 35.674116819705226 139.73765805657334 30.739</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5b9c0ac-cbeb-4cff-ac29-10b509165791">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5b9c0ac-cbeb-4cff-ac29-10b509165791">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5b9c0ac-cbeb-4cff-ac29-10b509165791">
											<gml:posList>35.67406443617986 139.7376860895043 9.395 35.674138682434105 139.7376523082506 9.395 35.674138682434105 139.7376523082506 30.739 35.674114939849794 139.73766310719245 30.739 35.674114939849794 139.73766310719245 33.933 35.67406443617986 139.7376860895043 33.933 35.67406443617986 139.7376860895043 9.395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7cf5a969-13a1-4ada-8365-6e5b00f57eb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cf5a969-13a1-4ada-8365-6e5b00f57eb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cf5a969-13a1-4ada-8365-6e5b00f57eb0">
											<gml:posList>35.67422367995193 139.73753654692524 9.395 35.67419511641237 139.73743583438082 9.395 35.67419511641237 139.73743583438082 23.376 35.67422367995193 139.73753654692524 23.376 35.67422367995193 139.73753654692524 9.395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6017d82-19db-4e75-b0ac-f64428b0a2ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6017d82-19db-4e75-b0ac-f64428b0a2ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6017d82-19db-4e75-b0ac-f64428b0a2ef">
											<gml:posList>35.674198558402864 139.73754750221556 26.714 35.67417810424965 139.73747701504269 26.714 35.67417810424965 139.73747701504269 27.233 35.674198558402864 139.73754750221556 27.233 35.674198558402864 139.73754750221556 26.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6bc2b1e9-3958-4efe-b2f9-eb46dc661f51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bc2b1e9-3958-4efe-b2f9-eb46dc661f51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bc2b1e9-3958-4efe-b2f9-eb46dc661f51">
											<gml:posList>35.67422367995193 139.73753654692524 9.395 35.67422367995193 139.73753654692524 23.376 35.674198558402864 139.73754750221556 26.714 35.674198558402864 139.73754750221556 27.233 35.674164480311624 139.73756235666613 27.233 35.674164480311624 139.73756235666613 9.395 35.67422367995193 139.73753654692524 9.395</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57b3aa05-9722-41df-b707-fe47bfd75f20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57b3aa05-9722-41df-b707-fe47bfd75f20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57b3aa05-9722-41df-b707-fe47bfd75f20">
											<gml:posList>35.674164480311624 139.73756235666613 27.233 35.674160683215405 139.7375481108561 27.233 35.674160683215405 139.7375481108561 9.395 35.674164480311624 139.73756235666613 9.395 35.674164480311624 139.73756235666613 27.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3851</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">241.5207</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>