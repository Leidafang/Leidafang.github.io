<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_94542f3d-7942-40ef-845d-8c74c9728c79">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">22</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.674110949512254 139.74023082394842 0 35.674219314208244 139.7402446722845 0 35.674239215630706 139.7400106449985 0 35.67424459283776 139.73994737376185 0 35.67416465837435 139.7399347851734 0 35.67408472390852 139.73992219660988 0 35.674079134059134 139.73999020703357 0 35.67402261231519 139.73998287151534 0 35.67400260284022 139.74021697562853 0 35.674110949512254 139.74023082394842 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674110949512254 139.74023082394842 20.46 35.67400260284022 139.74021697562853 20.46 35.67402261231519 139.73998287151534 20.46 35.674079134059134 139.73999020703357 20.46 35.67408472390852 139.73992219660988 20.46 35.67416465837435 139.7399347851734 20.46 35.67424459283776 139.73994737376185 20.46 35.674239215630706 139.7400106449985 20.46 35.674219314208244 139.7402446722845 20.46 35.674110949512254 139.74023082394842 20.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674110949512254 139.74023082394842 20.46 35.674219314208244 139.7402446722845 20.46 35.674219314208244 139.7402446722845 37.95 35.674110949512254 139.74023082394842 37.95 35.674110949512254 139.74023082394842 20.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674219314208244 139.7402446722845 20.46 35.674239215630706 139.7400106449985 20.46 35.674239215630706 139.7400106449985 37.95 35.674219314208244 139.7402446722845 37.95 35.674219314208244 139.7402446722845 20.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674239215630706 139.7400106449985 20.46 35.67424459283776 139.73994737376185 20.46 35.67424459283776 139.73994737376185 37.95 35.674239215630706 139.7400106449985 37.95 35.674239215630706 139.7400106449985 20.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67424459283776 139.73994737376185 20.46 35.67416465837435 139.7399347851734 20.46 35.67416465837435 139.7399347851734 37.95 35.67424459283776 139.73994737376185 37.95 35.67424459283776 139.73994737376185 20.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67416465837435 139.7399347851734 20.46 35.67408472390852 139.73992219660988 20.46 35.67408472390852 139.73992219660988 37.95 35.67416465837435 139.7399347851734 37.95 35.67416465837435 139.7399347851734 20.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67408472390852 139.73992219660988 20.46 35.674079134059134 139.73999020703357 20.46 35.674079134059134 139.73999020703357 37.95 35.67408472390852 139.73992219660988 37.95 35.67408472390852 139.73992219660988 20.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674079134059134 139.73999020703357 20.46 35.67402261231519 139.73998287151534 20.46 35.67402261231519 139.73998287151534 37.95 35.674079134059134 139.73999020703357 37.95 35.674079134059134 139.73999020703357 20.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67402261231519 139.73998287151534 20.46 35.67400260284022 139.74021697562853 20.46 35.67400260284022 139.74021697562853 37.95 35.67402261231519 139.73998287151534 37.95 35.67402261231519 139.73998287151534 20.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67400260284022 139.74021697562853 20.46 35.674110949512254 139.74023082394842 20.46 35.674110949512254 139.74023082394842 37.95 35.67400260284022 139.74021697562853 37.95 35.67400260284022 139.74021697562853 20.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674110949512254 139.74023082394842 37.95 35.674219314208244 139.7402446722845 37.95 35.674239215630706 139.7400106449985 37.95 35.67424459283776 139.73994737376185 37.95 35.67416465837435 139.7399347851734 37.95 35.67408472390852 139.73992219660988 37.95 35.674079134059134 139.73999020703357 37.95 35.67402261231519 139.73998287151534 37.95 35.67400260284022 139.74021697562853 37.95 35.674110949512254 139.74023082394842 37.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fc80cca0-805b-4652-b019-df5f4f636d5a"/>
							<gml:surfaceMember xlink:href="#poly-97fa59c5-fb32-41c9-bf43-b6bdbd7cae23"/>
							<gml:surfaceMember xlink:href="#poly-c68bec69-f5a8-4e74-bb9e-6652ef9e13a3"/>
							<gml:surfaceMember xlink:href="#poly-de2c9b51-05cf-4fb5-ba9e-dcc4bf04eda5"/>
							<gml:surfaceMember xlink:href="#poly-3fdadf2f-bdf5-461a-a722-3ab0341dff5b"/>
							<gml:surfaceMember xlink:href="#poly-35fd1a4a-e462-404b-92ac-c6695ab6f9aa"/>
							<gml:surfaceMember xlink:href="#poly-412e1634-ef5d-46a3-88b9-5f4a8544c122"/>
							<gml:surfaceMember xlink:href="#poly-99ea93af-1661-482a-87d9-d21da45569b2"/>
							<gml:surfaceMember xlink:href="#poly-5f4d9878-86a3-44ca-8a3c-c1fd25ffc4aa"/>
							<gml:surfaceMember xlink:href="#poly-17a1a01a-63f0-49fa-9b5e-c6262bc78327"/>
							<gml:surfaceMember xlink:href="#poly-afd319f3-74aa-4894-b6c1-89bda9cfaa48"/>
							<gml:surfaceMember xlink:href="#poly-daf4a784-dcce-46c4-b0a4-bbe485ff3f1a"/>
							<gml:surfaceMember xlink:href="#poly-2e17f303-0e42-42d7-a7f5-f748c562811c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fc80cca0-805b-4652-b019-df5f4f636d5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc80cca0-805b-4652-b019-df5f4f636d5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc80cca0-805b-4652-b019-df5f4f636d5a">
											<gml:posList>35.674002602831656 139.74021696458178 20.46 35.674022594270625 139.7399828494428 20.46 35.67407911599742 139.73999016286749 20.46 35.67408469685883 139.73992218559462 20.46 35.67424456579661 139.73994737379334 20.46 35.674219305194505 139.74024467229495 20.46 35.674002602831656 139.74021696458178 20.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97fa59c5-fb32-41c9-bf43-b6bdbd7cae23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97fa59c5-fb32-41c9-bf43-b6bdbd7cae23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97fa59c5-fb32-41c9-bf43-b6bdbd7cae23">
											<gml:posList>35.67416466738804 139.73993478516292 39.99 35.67408469685883 139.73992218559462 35.2 35.67407911596317 139.73999011868045 35.2 35.67415912078497 139.7400004536858 39.99 35.67416466738804 139.73993478516292 39.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c68bec69-f5a8-4e74-bb9e-6652ef9e13a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c68bec69-f5a8-4e74-bb9e-6652ef9e13a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c68bec69-f5a8-4e74-bb9e-6652ef9e13a3">
											<gml:posList>35.67424456579661 139.73994737379334 35.2 35.67416466738804 139.73993478516292 39.99 35.67415912078497 139.7400004536858 39.99 35.67423919774027 139.74001082176798 35.2 35.67424456579661 139.73994737379334 35.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-de2c9b51-05cf-4fb5-ba9e-dcc4bf04eda5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de2c9b51-05cf-4fb5-ba9e-dcc4bf04eda5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de2c9b51-05cf-4fb5-ba9e-dcc4bf04eda5">
											<gml:posList>35.67411095852596 139.74023082393794 41.95 35.674219305194505 139.74024467229495 35.2 35.67423919774027 139.74001082176798 35.2 35.67411095852596 139.74023082393794 41.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3fdadf2f-bdf5-461a-a722-3ab0341dff5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fdadf2f-bdf5-461a-a722-3ab0341dff5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fdadf2f-bdf5-461a-a722-3ab0341dff5b">
											<gml:posList>35.67423919774027 139.74001082176798 35.2 35.67413084189493 139.73999679698596 42.49 35.67411095852596 139.74023082393794 41.95 35.67423919774027 139.74001082176798 35.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35fd1a4a-e462-404b-92ac-c6695ab6f9aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35fd1a4a-e462-404b-92ac-c6695ab6f9aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35fd1a4a-e462-404b-92ac-c6695ab6f9aa">
											<gml:posList>35.67402259423636 139.7399828052558 35.2 35.674002602840204 139.7402169756285 35.2 35.67413084189493 139.73999679698596 42.49 35.67402259423636 139.7399828052558 35.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-412e1634-ef5d-46a3-88b9-5f4a8544c122">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-412e1634-ef5d-46a3-88b9-5f4a8544c122">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-412e1634-ef5d-46a3-88b9-5f4a8544c122">
											<gml:posList>35.674002602840204 139.7402169756285 35.2 35.67411095852596 139.74023082393794 41.95 35.67413084189493 139.73999679698596 42.49 35.674002602840204 139.7402169756285 35.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99ea93af-1661-482a-87d9-d21da45569b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99ea93af-1661-482a-87d9-d21da45569b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99ea93af-1661-482a-87d9-d21da45569b2">
											<gml:posList>35.674002602831656 139.74021696458178 20.46 35.674002602840204 139.7402169756285 35.2 35.67402259423636 139.7399828052558 35.2 35.674022594270625 139.7399828494428 20.46 35.674002602831656 139.74021696458178 20.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f4d9878-86a3-44ca-8a3c-c1fd25ffc4aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f4d9878-86a3-44ca-8a3c-c1fd25ffc4aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f4d9878-86a3-44ca-8a3c-c1fd25ffc4aa">
											<gml:posList>35.67413084189493 139.73999679698596 42.49 35.67423919774027 139.74001082176798 35.2 35.67415912078497 139.7400004536858 39.99 35.67407911596317 139.73999011868045 35.2 35.67407911599742 139.73999016286749 20.46 35.674022594270625 139.7399828494428 20.46 35.67402259423636 139.7399828052558 35.2 35.67413084189493 139.73999679698596 42.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17a1a01a-63f0-49fa-9b5e-c6262bc78327">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17a1a01a-63f0-49fa-9b5e-c6262bc78327">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17a1a01a-63f0-49fa-9b5e-c6262bc78327">
											<gml:posList>35.674219305194505 139.74024467229495 35.2 35.67411095852596 139.74023082393794 41.95 35.674002602840204 139.7402169756285 35.2 35.674002602831656 139.74021696458178 20.46 35.674219305194505 139.74024467229495 20.46 35.674219305194505 139.74024467229495 35.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afd319f3-74aa-4894-b6c1-89bda9cfaa48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afd319f3-74aa-4894-b6c1-89bda9cfaa48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afd319f3-74aa-4894-b6c1-89bda9cfaa48">
											<gml:posList>35.67424456579661 139.73994737379334 20.46 35.67424456579661 139.73994737379334 35.2 35.67423919774027 139.74001082176798 35.2 35.674219305194505 139.74024467229495 35.2 35.674219305194505 139.74024467229495 20.46 35.67424456579661 139.73994737379334 20.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-daf4a784-dcce-46c4-b0a4-bbe485ff3f1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-daf4a784-dcce-46c4-b0a4-bbe485ff3f1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-daf4a784-dcce-46c4-b0a4-bbe485ff3f1a">
											<gml:posList>35.67408469685883 139.73992218559462 35.2 35.67416466738804 139.73993478516292 39.99 35.67424456579661 139.73994737379334 35.2 35.67424456579661 139.73994737379334 20.46 35.67408469685883 139.73992218559462 20.46 35.67408469685883 139.73992218559462 35.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e17f303-0e42-42d7-a7f5-f748c562811c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e17f303-0e42-42d7-a7f5-f748c562811c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e17f303-0e42-42d7-a7f5-f748c562811c">
											<gml:posList>35.67408469685883 139.73992218559462 20.46 35.67407911599742 139.73999016286749 20.46 35.67407911596317 139.73999011868045 35.2 35.67408469685883 139.73992218559462 35.2 35.67408469685883 139.73992218559462 20.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4565</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">618.89625</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>