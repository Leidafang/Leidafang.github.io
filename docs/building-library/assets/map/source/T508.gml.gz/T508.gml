<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_94bed6bd-ea36-4aec-ba82-98ea71d465e0">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">16.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67425258202021 139.73792765722473 0 35.67429142462249 139.73805598583888 0 35.67431343723739 139.7380459844154 0 35.67432312525407 139.73807796443995 0 35.67437756659221 139.73805321013077 0 35.67433116876203 139.73789995773632 0 35.674323717097934 139.7379033469287 0 35.67432158426618 139.737896290561 0 35.67425258202021 139.73792765722473 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67425258202021 139.73792765722473 8.32 35.67432158426618 139.737896290561 8.32 35.674323717097934 139.7379033469287 8.32 35.67433116876203 139.73789995773632 8.32 35.67437756659221 139.73805321013077 8.32 35.67432312525407 139.73807796443995 8.32 35.67431343723739 139.7380459844154 8.32 35.67429142462249 139.73805598583888 8.32 35.67425258202021 139.73792765722473 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67425258202021 139.73792765722473 8.32 35.67429142462249 139.73805598583888 8.32 35.67429142462249 139.73805598583888 24.44 35.67425258202021 139.73792765722473 24.44 35.67425258202021 139.73792765722473 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67429142462249 139.73805598583888 8.32 35.67431343723739 139.7380459844154 8.32 35.67431343723739 139.7380459844154 24.44 35.67429142462249 139.73805598583888 24.44 35.67429142462249 139.73805598583888 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67431343723739 139.7380459844154 8.32 35.67432312525407 139.73807796443995 8.32 35.67432312525407 139.73807796443995 24.44 35.67431343723739 139.7380459844154 24.44 35.67431343723739 139.7380459844154 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67432312525407 139.73807796443995 8.32 35.67437756659221 139.73805321013077 8.32 35.67437756659221 139.73805321013077 24.44 35.67432312525407 139.73807796443995 24.44 35.67432312525407 139.73807796443995 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67437756659221 139.73805321013077 8.32 35.67433116876203 139.73789995773632 8.32 35.67433116876203 139.73789995773632 24.44 35.67437756659221 139.73805321013077 24.44 35.67437756659221 139.73805321013077 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67433116876203 139.73789995773632 8.32 35.674323717097934 139.7379033469287 8.32 35.674323717097934 139.7379033469287 24.44 35.67433116876203 139.73789995773632 24.44 35.67433116876203 139.73789995773632 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674323717097934 139.7379033469287 8.32 35.67432158426618 139.737896290561 8.32 35.67432158426618 139.737896290561 24.44 35.674323717097934 139.7379033469287 24.44 35.674323717097934 139.7379033469287 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67432158426618 139.737896290561 8.32 35.67425258202021 139.73792765722473 8.32 35.67425258202021 139.73792765722473 24.44 35.67432158426618 139.737896290561 24.44 35.67432158426618 139.737896290561 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67425258202021 139.73792765722473 24.44 35.67429142462249 139.73805598583888 24.44 35.67431343723739 139.7380459844154 24.44 35.67432312525407 139.73807796443995 24.44 35.67437756659221 139.73805321013077 24.44 35.67433116876203 139.73789995773632 24.44 35.674323717097934 139.7379033469287 24.44 35.67432158426618 139.737896290561 24.44 35.67425258202021 139.73792765722473 24.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-92837778-3383-4c12-b92a-e259f5dd9ca1"/>
							<gml:surfaceMember xlink:href="#poly-33ad07f1-b2f4-4d05-811b-804ba8f9ce98"/>
							<gml:surfaceMember xlink:href="#poly-a4c6a9aa-2664-4e96-8e05-765b33b5a41f"/>
							<gml:surfaceMember xlink:href="#poly-8a88cd0d-1b7f-418b-97ae-ccb1aff9dea1"/>
							<gml:surfaceMember xlink:href="#poly-bb4933e6-2e99-46f6-9696-124f962dee89"/>
							<gml:surfaceMember xlink:href="#poly-8f8acf80-f135-4acb-8cec-6aba53d7fa4d"/>
							<gml:surfaceMember xlink:href="#poly-06ba488c-78ad-4dc5-bb1f-55cab72ed33a"/>
							<gml:surfaceMember xlink:href="#poly-af3087b6-8496-43e3-8a0b-8663b87300a7"/>
							<gml:surfaceMember xlink:href="#poly-7e4eef74-56ff-470e-9163-b21e6348c10d"/>
							<gml:surfaceMember xlink:href="#poly-861ff7f3-a8fc-49da-a5c2-2d19c4cd4db4"/>
							<gml:surfaceMember xlink:href="#poly-f46b29a8-0a4b-4c00-8f5e-ca7983806c7c"/>
							<gml:surfaceMember xlink:href="#poly-3a95f8ba-dced-4a6f-887e-968e0dcb7c20"/>
							<gml:surfaceMember xlink:href="#poly-19d8777d-e860-4843-895a-5700cd9bc518"/>
							<gml:surfaceMember xlink:href="#poly-b93ff6e5-9e50-407c-ad89-05f1ff4c8e1a"/>
							<gml:surfaceMember xlink:href="#poly-7e3a1ffb-ed76-455f-b8b5-7bad18d2bc50"/>
							<gml:surfaceMember xlink:href="#poly-117cc63b-939f-411f-b9e0-7f309035c605"/>
							<gml:surfaceMember xlink:href="#poly-845510fb-127d-47bf-9e53-ea7ee980655e"/>
							<gml:surfaceMember xlink:href="#poly-119e4374-0a65-4458-bdb8-f10307715ab8"/>
							<gml:surfaceMember xlink:href="#poly-b028920f-71bb-4068-af36-a6833ce85405"/>
							<gml:surfaceMember xlink:href="#poly-b351683d-aa16-4220-b455-98099e0cdbfd"/>
							<gml:surfaceMember xlink:href="#poly-186a99bb-fdca-4c9f-9c5b-4092050cc0d1"/>
							<gml:surfaceMember xlink:href="#poly-3c601a2d-b7ae-4f71-94ad-884474fd763d"/>
							<gml:surfaceMember xlink:href="#poly-0b812169-e785-4178-919a-43047967b102"/>
							<gml:surfaceMember xlink:href="#poly-79f62017-e56b-446f-ba87-f91becece775"/>
							<gml:surfaceMember xlink:href="#poly-f3015b59-554b-4e5d-8b15-09a950ff1cfe"/>
							<gml:surfaceMember xlink:href="#poly-5283c881-efc2-4ae6-8d49-7d40f93b8a16"/>
							<gml:surfaceMember xlink:href="#poly-2abb2af0-5cc7-4ffe-a008-604787a38272"/>
							<gml:surfaceMember xlink:href="#poly-e804b3c6-27cf-4e86-b890-ab6beaff7235"/>
							<gml:surfaceMember xlink:href="#poly-d9cdb907-485c-4388-9e8f-f8fb44ce0d38"/>
							<gml:surfaceMember xlink:href="#poly-5a66a3d1-fa92-45fc-9e3d-044c37d98509"/>
							<gml:surfaceMember xlink:href="#poly-bc315de6-b935-4718-8db1-18deb80a29d8"/>
							<gml:surfaceMember xlink:href="#poly-c63d73d3-9157-411e-a926-605c91698357"/>
							<gml:surfaceMember xlink:href="#poly-40097ca2-13c7-4285-9cb6-548b5e157db7"/>
							<gml:surfaceMember xlink:href="#poly-a26c1514-1c10-4e50-b0ed-63a88a114b90"/>
							<gml:surfaceMember xlink:href="#poly-83df963a-348e-4f32-9e82-263c007b2087"/>
							<gml:surfaceMember xlink:href="#poly-f1b300f5-7248-47da-8a37-e1207ceb275f"/>
							<gml:surfaceMember xlink:href="#poly-a3d92eea-540f-4a22-88c7-d81a9f8b5b64"/>
							<gml:surfaceMember xlink:href="#poly-a9528683-ca13-4945-9ba4-a18c94a015b6"/>
							<gml:surfaceMember xlink:href="#poly-d361b392-258c-46b8-92b2-58b44c1eaff4"/>
							<gml:surfaceMember xlink:href="#poly-d88aa7c3-d786-4d30-b306-49536deab711"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_94bed6bd-ea36-4aec-ba82-98ea71d465e0_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86dcc82c-49ca-4dde-96df-9a9142a01cc5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67432312525408 139.73807796443995 8.42 35.67430111264527 139.73808797690265 8.42 35.67429142462246 139.73805598583888 8.42 35.67431343722864 139.7380459733686 8.42 35.67432312525408 139.73807796443995 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f78ebc1b-e0e2-48c1-9f4e-924506c9eadb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f78ebc1b-e0e2-48c1-9f4e-924506c9eadb_0">
											<gml:posList>35.67430111264527 139.73808797690265 24.692 35.67429142462246 139.73805598583888 24.692 35.67429142462246 139.73805598583888 8.42 35.67430111264527 139.73808797690265 8.42 35.67430111264527 139.73808797690265 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36b63999-b05a-4ed7-b3f7-589967f259cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36b63999-b05a-4ed7-b3f7-589967f259cb_0">
											<gml:posList>35.67429142462246 139.73805598583888 24.692 35.67431343722864 139.7380459733686 24.692 35.67431343722864 139.7380459733686 8.42 35.67429142462246 139.73805598583888 8.42 35.67429142462246 139.73805598583888 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5a7e43a-855b-4d2b-8347-b0d272fa47f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5a7e43a-855b-4d2b-8347-b0d272fa47f0_0">
											<gml:posList>35.67430111264527 139.73808797690265 24.692 35.67432312525408 139.73807796443995 24.692 35.67431343722864 139.7380459733686 24.692 35.67429142462246 139.73805598583888 24.692 35.67430111264527 139.73808797690265 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b024b80f-5939-4a27-b80a-b035b3b76b38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b024b80f-5939-4a27-b80a-b035b3b76b38_0">
											<gml:posList>35.67432312525408 139.73807796443995 24.692 35.67430111264527 139.73808797690265 24.692 35.67430111264527 139.73808797690265 8.42 35.67432312525408 139.73807796443995 8.42 35.67432312525408 139.73807796443995 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6211340f-3b92-4e17-b18a-1689e4904086">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6211340f-3b92-4e17-b18a-1689e4904086_0">
											<gml:posList>35.67431343722864 139.7380459733686 24.692 35.67432312525408 139.73807796443995 24.692 35.67432312525408 139.73807796443995 8.42 35.67431343722864 139.7380459733686 8.42 35.67431343722864 139.7380459733686 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_94bed6bd-ea36-4aec-ba82-98ea71d465e0_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00b95b52-831a-4ebc-b447-2c3e2eb3e508">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6742732730861 139.73794479932064 24.223 35.67431110808815 139.73792759861954 24.223 35.674317976480175 139.73795026952945 24.223 35.67428013246995 139.73796748127884 24.223 35.6742732730861 139.73794479932064 24.223</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f645dcf9-4668-46ff-9caa-707f65f89b62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f645dcf9-4668-46ff-9caa-707f65f89b62_0">
											<gml:posList>35.6742732730861 139.73794479932064 27.548 35.6742732730861 139.73794479932064 24.223 35.67428013246995 139.73796748127884 24.223 35.67428013246995 139.73796748127884 27.548 35.6742732730861 139.73794479932064 27.548</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a849b47-c838-4ff5-aa3e-507d23864b4b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a849b47-c838-4ff5-aa3e-507d23864b4b_0">
											<gml:posList>35.67431110808815 139.73792759861954 27.548 35.67431110808815 139.73792759861954 24.223 35.6742732730861 139.73794479932064 24.223 35.6742732730861 139.73794479932064 27.548 35.67431110808815 139.73792759861954 27.548</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-046259b7-b661-47df-ad9c-44ee778ab66b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-046259b7-b661-47df-ad9c-44ee778ab66b_0">
											<gml:posList>35.6742732730861 139.73794479932064 27.548 35.67428013246995 139.73796748127884 27.548 35.674317976480175 139.73795026952945 27.548 35.67431110808815 139.73792759861954 27.548 35.6742732730861 139.73794479932064 27.548</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0537f042-8135-4646-84e2-0158600d50d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0537f042-8135-4646-84e2-0158600d50d8_0">
											<gml:posList>35.67428013246995 139.73796748127884 27.548 35.67428013246995 139.73796748127884 24.223 35.674317976480175 139.73795026952945 24.223 35.674317976480175 139.73795026952945 27.548 35.67428013246995 139.73796748127884 27.548</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b98536a-8351-429d-8815-0891a331daae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b98536a-8351-429d-8815-0891a331daae_0">
											<gml:posList>35.674317976480175 139.73795026952945 24.223 35.67431110808815 139.73792759861954 24.223 35.67431110808815 139.73792759861954 27.548 35.674317976480175 139.73795026952945 27.548 35.674317976480175 139.73795026952945 24.223</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-92837778-3383-4c12-b92a-e259f5dd9ca1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92837778-3383-4c12-b92a-e259f5dd9ca1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92837778-3383-4c12-b92a-e259f5dd9ca1">
											<gml:posList>35.67437756659221 139.73805321013077 8.32 35.67432312525408 139.73807796443995 8.32 35.67431343723739 139.7380459844154 8.32 35.67429142462246 139.73805598583888 8.32 35.674252582020195 139.73792765722473 8.32 35.674321584266146 139.737896290561 8.32 35.674323717097934 139.7379033469287 8.32 35.674331168762016 139.7378999577363 8.32 35.67437756659221 139.73805321013077 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-33ad07f1-b2f4-4d05-811b-804ba8f9ce98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33ad07f1-b2f4-4d05-811b-804ba8f9ce98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33ad07f1-b2f4-4d05-811b-804ba8f9ce98">
											<gml:posList>35.674323717097934 139.7379033469287 24.692 35.674321584266146 139.737896290561 24.692 35.67431795940829 139.7379059718747 24.692 35.67432009223952 139.73791302824236 24.692 35.674323717097934 139.7379033469287 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4c6a9aa-2664-4e96-8e05-765b33b5a41f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4c6a9aa-2664-4e96-8e05-765b33b5a41f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4c6a9aa-2664-4e96-8e05-765b33b5a41f">
											<gml:posList>35.674323717097934 139.7379033469287 24.692 35.67432009223952 139.73791302824236 24.692 35.67432754390388 139.737909639051 24.692 35.674331168762016 139.7378999577363 24.692 35.674323717097934 139.7379033469287 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a88cd0d-1b7f-418b-97ae-ccb1aff9dea1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a88cd0d-1b7f-418b-97ae-ccb1aff9dea1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a88cd0d-1b7f-418b-97ae-ccb1aff9dea1">
											<gml:posList>35.674252582020195 139.73792765722473 24.692 35.67426048157173 139.7379321107282 24.692 35.67431795940829 139.7379059718747 24.692 35.674321584266146 139.737896290561 24.692 35.674252582020195 139.73792765722473 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb4933e6-2e99-46f6-9696-124f962dee89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb4933e6-2e99-46f6-9696-124f962dee89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb4933e6-2e99-46f6-9696-124f962dee89">
											<gml:posList>35.674252582020195 139.73792765722473 24.692 35.67427071100494 139.73798756451365 24.692 35.67427647771013 139.7379849395643 24.692 35.674274344900596 139.73797790529215 24.692 35.67426048157173 139.7379321107282 24.692 35.674252582020195 139.73792765722473 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8f8acf80-f135-4acb-8cec-6aba53d7fa4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f8acf80-f135-4acb-8cec-6aba53d7fa4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f8acf80-f135-4acb-8cec-6aba53d7fa4d">
											<gml:posList>35.67427071100494 139.73798756451365 27.885 35.67427515675268 139.7379900668487 27.885 35.6743258136685 139.73796702925128 27.885 35.674327864482215 139.73796158073768 27.885 35.67427071100494 139.73798756451365 27.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06ba488c-78ad-4dc5-bb1f-55cab72ed33a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06ba488c-78ad-4dc5-bb1f-55cab72ed33a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06ba488c-78ad-4dc5-bb1f-55cab72ed33a">
											<gml:posList>35.674331168762016 139.7378999577363 24.692 35.67432754390388 139.737909639051 24.692 35.67436967606775 139.73804876764498 24.692 35.67437756659221 139.73805321013077 24.692 35.674331168762016 139.7378999577363 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af3087b6-8496-43e3-8a0b-8663b87300a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af3087b6-8496-43e3-8a0b-8663b87300a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af3087b6-8496-43e3-8a0b-8663b87300a7">
											<gml:posList>35.67434448420679 139.73801649672882 24.223 35.67431511905143 139.73802985408634 24.223 35.6743172518754 139.73803691045703 24.223 35.674326750134504 139.73806829418015 24.223 35.67436967606775 139.73804876764498 24.223 35.67432754390388 139.737909639051 24.223 35.67432009223952 139.73791302824236 24.223 35.67431795940829 139.7379059718747 24.223 35.67426048157173 139.7379321107282 24.223 35.674274344900596 139.73797790529215 24.223 35.67427647771013 139.7379849395643 24.223 35.674327864482215 139.73796158073768 24.223 35.67434448420679 139.73801649672882 24.223</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e4eef74-56ff-470e-9163-b21e6348c10d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e4eef74-56ff-470e-9163-b21e6348c10d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e4eef74-56ff-470e-9163-b21e6348c10d">
											<gml:posList>35.674327864482215 139.73796158073768 27.885 35.6743258136685 139.73796702925128 27.885 35.67434002943717 139.73801398335405 27.885 35.67434448420679 139.73801649672882 27.885 35.674327864482215 139.73796158073768 27.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-861ff7f3-a8fc-49da-a5c2-2d19c4cd4db4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-861ff7f3-a8fc-49da-a5c2-2d19c4cd4db4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-861ff7f3-a8fc-49da-a5c2-2d19c4cd4db4">
											<gml:posList>35.67434002943717 139.73801398335405 27.526 35.6743258136685 139.73796702925128 27.526 35.67427515675268 139.7379900668487 27.526 35.67428938152616 139.73803702091524 27.526 35.67434002943717 139.73801398335405 27.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f46b29a8-0a4b-4c00-8f5e-ca7983806c7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f46b29a8-0a4b-4c00-8f5e-ca7983806c7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f46b29a8-0a4b-4c00-8f5e-ca7983806c7c">
											<gml:posList>35.67428733973148 139.73804248046036 27.885 35.67428938152616 139.73803702091524 27.885 35.67427515675268 139.7379900668487 27.885 35.67427071100494 139.73798756451365 27.885 35.67428733973148 139.73804248046036 27.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a95f8ba-dced-4a6f-887e-968e0dcb7c20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a95f8ba-dced-4a6f-887e-968e0dcb7c20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a95f8ba-dced-4a6f-887e-968e0dcb7c20">
											<gml:posList>35.67434448420679 139.73801649672882 27.885 35.67434002943717 139.73801398335405 27.885 35.67428938152616 139.73803702091524 27.885 35.67428733973148 139.73804248046036 27.885 35.67434448420679 139.73801649672882 27.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-19d8777d-e860-4843-895a-5700cd9bc518">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19d8777d-e860-4843-895a-5700cd9bc518">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19d8777d-e860-4843-895a-5700cd9bc518">
											<gml:posList>35.67431511905143 139.73802985408634 24.692 35.67428733973148 139.73804248046036 24.692 35.6743172518754 139.73803691045703 24.692 35.67431511905143 139.73802985408634 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b93ff6e5-9e50-407c-ad89-05f1ff4c8e1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b93ff6e5-9e50-407c-ad89-05f1ff4c8e1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b93ff6e5-9e50-407c-ad89-05f1ff4c8e1a">
											<gml:posList>35.67428733973148 139.73804248046036 24.692 35.67429142462246 139.73805598583888 24.692 35.67431343723739 139.7380459844154 24.692 35.6743172518754 139.73803691045703 24.692 35.67428733973148 139.73804248046036 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e3a1ffb-ed76-455f-b8b5-7bad18d2bc50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e3a1ffb-ed76-455f-b8b5-7bad18d2bc50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e3a1ffb-ed76-455f-b8b5-7bad18d2bc50">
											<gml:posList>35.67431343723739 139.7380459844154 24.692 35.67432312525408 139.73807796443995 24.692 35.674326750134504 139.73806829418015 24.692 35.6743172518754 139.73803691045703 24.692 35.67431343723739 139.7380459844154 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-117cc63b-939f-411f-b9e0-7f309035c605">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-117cc63b-939f-411f-b9e0-7f309035c605">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-117cc63b-939f-411f-b9e0-7f309035c605">
											<gml:posList>35.67437756659221 139.73805321013077 24.692 35.67436967606775 139.73804876764498 24.692 35.674326750134504 139.73806829418015 24.692 35.67432312525408 139.73807796443995 24.692 35.67437756659221 139.73805321013077 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-845510fb-127d-47bf-9e53-ea7ee980655e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-845510fb-127d-47bf-9e53-ea7ee980655e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-845510fb-127d-47bf-9e53-ea7ee980655e">
											<gml:posList>35.674323717097934 139.7379033469287 8.32 35.674321584266146 139.737896290561 8.32 35.674321584266146 139.737896290561 24.692 35.674323717097934 139.7379033469287 24.692 35.674323717097934 139.7379033469287 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-119e4374-0a65-4458-bdb8-f10307715ab8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-119e4374-0a65-4458-bdb8-f10307715ab8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-119e4374-0a65-4458-bdb8-f10307715ab8">
											<gml:posList>35.674331168762016 139.7378999577363 8.32 35.674323717097934 139.7379033469287 8.32 35.674323717097934 139.7379033469287 24.692 35.674331168762016 139.7378999577363 24.692 35.674331168762016 139.7378999577363 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b028920f-71bb-4068-af36-a6833ce85405">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b028920f-71bb-4068-af36-a6833ce85405">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b028920f-71bb-4068-af36-a6833ce85405">
											<gml:posList>35.67431795940829 139.7379059718747 24.692 35.67431795940829 139.7379059718747 24.223 35.67432009223952 139.73791302824236 24.223 35.67432009223952 139.73791302824236 24.692 35.67431795940829 139.7379059718747 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b351683d-aa16-4220-b455-98099e0cdbfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b351683d-aa16-4220-b455-98099e0cdbfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b351683d-aa16-4220-b455-98099e0cdbfd">
											<gml:posList>35.67432009223952 139.73791302824236 24.692 35.67432009223952 139.73791302824236 24.223 35.67432754390388 139.737909639051 24.223 35.67432754390388 139.737909639051 24.692 35.67432009223952 139.73791302824236 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-186a99bb-fdca-4c9f-9c5b-4092050cc0d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-186a99bb-fdca-4c9f-9c5b-4092050cc0d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-186a99bb-fdca-4c9f-9c5b-4092050cc0d1">
											<gml:posList>35.674321584266146 139.737896290561 8.32 35.674252582020195 139.73792765722473 8.32 35.674252582020195 139.73792765722473 24.692 35.674321584266146 139.737896290561 24.692 35.674321584266146 139.737896290561 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c601a2d-b7ae-4f71-94ad-884474fd763d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c601a2d-b7ae-4f71-94ad-884474fd763d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c601a2d-b7ae-4f71-94ad-884474fd763d">
											<gml:posList>35.67426048157173 139.7379321107282 24.692 35.67426048157173 139.7379321107282 24.223 35.67431795940829 139.7379059718747 24.223 35.67431795940829 139.7379059718747 24.692 35.67426048157173 139.7379321107282 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b812169-e785-4178-919a-43047967b102">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b812169-e785-4178-919a-43047967b102">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b812169-e785-4178-919a-43047967b102">
											<gml:posList>35.674274344900596 139.73797790529215 24.692 35.674274344900596 139.73797790529215 24.223 35.67426048157173 139.7379321107282 24.223 35.67426048157173 139.7379321107282 24.692 35.674274344900596 139.73797790529215 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79f62017-e56b-446f-ba87-f91becece775">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79f62017-e56b-446f-ba87-f91becece775">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79f62017-e56b-446f-ba87-f91becece775">
											<gml:posList>35.67427647771013 139.7379849395643 24.692 35.67427071100494 139.73798756451365 24.692 35.67427071100494 139.73798756451365 27.885 35.674327864482215 139.73796158073768 27.885 35.674327864482215 139.73796158073768 24.223 35.67427647771013 139.7379849395643 24.223 35.67427647771013 139.7379849395643 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3015b59-554b-4e5d-8b15-09a950ff1cfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3015b59-554b-4e5d-8b15-09a950ff1cfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3015b59-554b-4e5d-8b15-09a950ff1cfe">
											<gml:posList>35.674331168762016 139.7378999577363 24.692 35.67437756659221 139.73805321013077 24.692 35.67437756659221 139.73805321013077 8.32 35.674331168762016 139.7378999577363 8.32 35.674331168762016 139.7378999577363 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5283c881-efc2-4ae6-8d49-7d40f93b8a16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5283c881-efc2-4ae6-8d49-7d40f93b8a16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5283c881-efc2-4ae6-8d49-7d40f93b8a16">
											<gml:posList>35.67427515675268 139.7379900668487 27.885 35.67427515675268 139.7379900668487 27.526 35.6743258136685 139.73796702925128 27.526 35.6743258136685 139.73796702925128 27.885 35.67427515675268 139.7379900668487 27.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2abb2af0-5cc7-4ffe-a008-604787a38272">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2abb2af0-5cc7-4ffe-a008-604787a38272">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2abb2af0-5cc7-4ffe-a008-604787a38272">
											<gml:posList>35.67432754390388 139.737909639051 24.692 35.67432754390388 139.737909639051 24.223 35.67436967606775 139.73804876764498 24.223 35.67436967606775 139.73804876764498 24.692 35.67432754390388 139.737909639051 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e804b3c6-27cf-4e86-b890-ab6beaff7235">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e804b3c6-27cf-4e86-b890-ab6beaff7235">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e804b3c6-27cf-4e86-b890-ab6beaff7235">
											<gml:posList>35.67427647771013 139.7379849395643 24.692 35.67427647771013 139.7379849395643 24.223 35.674274344900596 139.73797790529215 24.223 35.674274344900596 139.73797790529215 24.692 35.67427647771013 139.7379849395643 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9cdb907-485c-4388-9e8f-f8fb44ce0d38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9cdb907-485c-4388-9e8f-f8fb44ce0d38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9cdb907-485c-4388-9e8f-f8fb44ce0d38">
											<gml:posList>35.674327864482215 139.73796158073768 27.885 35.67434448420679 139.73801649672882 27.885 35.67434448420679 139.73801649672882 24.223 35.674327864482215 139.73796158073768 24.223 35.674327864482215 139.73796158073768 27.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a66a3d1-fa92-45fc-9e3d-044c37d98509">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a66a3d1-fa92-45fc-9e3d-044c37d98509">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a66a3d1-fa92-45fc-9e3d-044c37d98509">
											<gml:posList>35.6743258136685 139.73796702925128 27.885 35.6743258136685 139.73796702925128 27.526 35.67434002943717 139.73801398335405 27.526 35.67434002943717 139.73801398335405 27.885 35.6743258136685 139.73796702925128 27.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc315de6-b935-4718-8db1-18deb80a29d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc315de6-b935-4718-8db1-18deb80a29d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc315de6-b935-4718-8db1-18deb80a29d8">
											<gml:posList>35.67428733973148 139.73804248046036 24.692 35.67428733973148 139.73804248046036 27.885 35.67427071100494 139.73798756451365 27.885 35.67427071100494 139.73798756451365 24.692 35.674252582020195 139.73792765722473 24.692 35.674252582020195 139.73792765722473 8.32 35.67429142462246 139.73805598583888 8.32 35.67429142462246 139.73805598583888 24.692 35.67428733973148 139.73804248046036 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c63d73d3-9157-411e-a926-605c91698357">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c63d73d3-9157-411e-a926-605c91698357">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c63d73d3-9157-411e-a926-605c91698357">
											<gml:posList>35.67428938152616 139.73803702091524 27.885 35.67428938152616 139.73803702091524 27.526 35.67427515675268 139.7379900668487 27.526 35.67427515675268 139.7379900668487 27.885 35.67428938152616 139.73803702091524 27.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40097ca2-13c7-4285-9cb6-548b5e157db7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40097ca2-13c7-4285-9cb6-548b5e157db7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40097ca2-13c7-4285-9cb6-548b5e157db7">
											<gml:posList>35.67434002943717 139.73801398335405 27.885 35.67434002943717 139.73801398335405 27.526 35.67428938152616 139.73803702091524 27.526 35.67428938152616 139.73803702091524 27.885 35.67434002943717 139.73801398335405 27.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a26c1514-1c10-4e50-b0ed-63a88a114b90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a26c1514-1c10-4e50-b0ed-63a88a114b90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a26c1514-1c10-4e50-b0ed-63a88a114b90">
											<gml:posList>35.67434448420679 139.73801649672882 24.223 35.67434448420679 139.73801649672882 27.885 35.67428733973148 139.73804248046036 27.885 35.67428733973148 139.73804248046036 24.692 35.67431511905143 139.73802985408634 24.692 35.67431511905143 139.73802985408634 24.223 35.67434448420679 139.73801649672882 24.223</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83df963a-348e-4f32-9e82-263c007b2087">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83df963a-348e-4f32-9e82-263c007b2087">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83df963a-348e-4f32-9e82-263c007b2087">
											<gml:posList>35.6743172518754 139.73803691045703 24.692 35.6743172518754 139.73803691045703 24.223 35.67431511905143 139.73802985408634 24.223 35.67431511905143 139.73802985408634 24.692 35.6743172518754 139.73803691045703 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1b300f5-7248-47da-8a37-e1207ceb275f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1b300f5-7248-47da-8a37-e1207ceb275f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1b300f5-7248-47da-8a37-e1207ceb275f">
											<gml:posList>35.67429142462246 139.73805598583888 8.32 35.67431343723739 139.7380459844154 8.32 35.67431343723739 139.7380459844154 24.692 35.67429142462246 139.73805598583888 24.692 35.67429142462246 139.73805598583888 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3d92eea-540f-4a22-88c7-d81a9f8b5b64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3d92eea-540f-4a22-88c7-d81a9f8b5b64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3d92eea-540f-4a22-88c7-d81a9f8b5b64">
											<gml:posList>35.674326750134504 139.73806829418015 24.692 35.674326750134504 139.73806829418015 24.223 35.6743172518754 139.73803691045703 24.223 35.6743172518754 139.73803691045703 24.692 35.674326750134504 139.73806829418015 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9528683-ca13-4945-9ba4-a18c94a015b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9528683-ca13-4945-9ba4-a18c94a015b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9528683-ca13-4945-9ba4-a18c94a015b6">
											<gml:posList>35.67436967606775 139.73804876764498 24.692 35.67436967606775 139.73804876764498 24.223 35.674326750134504 139.73806829418015 24.223 35.674326750134504 139.73806829418015 24.692 35.67436967606775 139.73804876764498 24.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d361b392-258c-46b8-92b2-58b44c1eaff4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d361b392-258c-46b8-92b2-58b44c1eaff4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d361b392-258c-46b8-92b2-58b44c1eaff4">
											<gml:posList>35.67431343723739 139.7380459844154 8.32 35.67432312525408 139.73807796443995 8.32 35.67432312525408 139.73807796443995 24.692 35.67431343723739 139.7380459844154 24.692 35.67431343723739 139.7380459844154 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d88aa7c3-d786-4d30-b306-49536deab711">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d88aa7c3-d786-4d30-b306-49536deab711">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d88aa7c3-d786-4d30-b306-49536deab711">
											<gml:posList>35.67432312525408 139.73807796443995 8.32 35.67437756659221 139.73805321013077 8.32 35.67437756659221 139.73805321013077 24.692 35.67432312525408 139.73807796443995 24.692 35.67432312525408 139.73807796443995 8.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2105</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">119.23451</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.15</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>