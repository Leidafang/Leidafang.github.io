<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_94de66a6-e9bf-453b-8d35-aa924d61f610">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">4.2</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66996383604626 139.74643450342467 0 35.669979486855034 139.74645111100037 0 35.670013749134725 139.74640265833708 0 35.66999809831139 139.74638603971755 0 35.66996383604626 139.74643450342467 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66996383604626 139.74643450342467 6.552 35.66999809831139 139.74638603971755 6.552 35.670013749134725 139.74640265833708 6.552 35.669979486855034 139.74645111100037 6.552 35.66996383604626 139.74643450342467 6.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66996383604626 139.74643450342467 6.552 35.669979486855034 139.74645111100037 6.552 35.669979486855034 139.74645111100037 10.76 35.66996383604626 139.74643450342467 10.76 35.66996383604626 139.74643450342467 6.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669979486855034 139.74645111100037 6.552 35.670013749134725 139.74640265833708 6.552 35.670013749134725 139.74640265833708 10.76 35.669979486855034 139.74645111100037 10.76 35.669979486855034 139.74645111100037 6.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670013749134725 139.74640265833708 6.552 35.66999809831139 139.74638603971755 6.552 35.66999809831139 139.74638603971755 10.76 35.670013749134725 139.74640265833708 10.76 35.670013749134725 139.74640265833708 6.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66999809831139 139.74638603971755 6.552 35.66996383604626 139.74643450342467 6.552 35.66996383604626 139.74643450342467 10.76 35.66999809831139 139.74638603971755 10.76 35.66999809831139 139.74638603971755 6.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66996383604626 139.74643450342467 10.76 35.669979486855034 139.74645111100037 10.76 35.670013749134725 139.74640265833708 10.76 35.66999809831139 139.74638603971755 10.76 35.66996383604626 139.74643450342467 10.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f679818c-366e-4a97-9194-e8bb9531697d"/>
							<gml:surfaceMember xlink:href="#poly-015b323b-9648-4ec4-9615-c35112219e74"/>
							<gml:surfaceMember xlink:href="#poly-cb504860-c473-41bc-987d-43f4e67621a4"/>
							<gml:surfaceMember xlink:href="#poly-0b1abe2b-bc54-4c41-a460-6c9cb64a180a"/>
							<gml:surfaceMember xlink:href="#poly-e0305b4c-b373-47c1-99de-181f0bc9dad1"/>
							<gml:surfaceMember xlink:href="#poly-eb74a9c8-56ed-47db-b817-127c3c113227"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f679818c-366e-4a97-9194-e8bb9531697d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f679818c-366e-4a97-9194-e8bb9531697d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f679818c-366e-4a97-9194-e8bb9531697d">
											<gml:posList>35.669963836046264 139.74643450342467 6.552 35.66999809831137 139.74638603971755 6.552 35.67001374913468 139.74640265833705 6.552 35.669979486855034 139.74645111100034 6.552 35.669963836046264 139.74643450342467 6.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-015b323b-9648-4ec4-9615-c35112219e74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-015b323b-9648-4ec4-9615-c35112219e74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-015b323b-9648-4ec4-9615-c35112219e74">
											<gml:posList>35.66999809831137 139.74638603971755 12.7 35.669963836046264 139.74643450342467 12.7 35.669979486855034 139.74645111100034 12.7 35.67001374913468 139.74640265833705 12.7 35.66999809831137 139.74638603971755 12.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb504860-c473-41bc-987d-43f4e67621a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb504860-c473-41bc-987d-43f4e67621a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb504860-c473-41bc-987d-43f4e67621a4">
											<gml:posList>35.67001374913468 139.74640265833705 6.552 35.66999809831137 139.74638603971755 6.552 35.66999809831137 139.74638603971755 12.7 35.67001374913468 139.74640265833705 12.7 35.67001374913468 139.74640265833705 6.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b1abe2b-bc54-4c41-a460-6c9cb64a180a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b1abe2b-bc54-4c41-a460-6c9cb64a180a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b1abe2b-bc54-4c41-a460-6c9cb64a180a">
											<gml:posList>35.66999809831137 139.74638603971755 6.552 35.669963836046264 139.74643450342467 6.552 35.669963836046264 139.74643450342467 12.7 35.66999809831137 139.74638603971755 12.7 35.66999809831137 139.74638603971755 6.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0305b4c-b373-47c1-99de-181f0bc9dad1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0305b4c-b373-47c1-99de-181f0bc9dad1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0305b4c-b373-47c1-99de-181f0bc9dad1">
											<gml:posList>35.669979486855034 139.74645111100034 6.552 35.67001374913468 139.74640265833705 6.552 35.67001374913468 139.74640265833705 12.7 35.669979486855034 139.74645111100034 12.7 35.669979486855034 139.74645111100034 6.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb74a9c8-56ed-47db-b817-127c3c113227">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb74a9c8-56ed-47db-b817-127c3c113227">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb74a9c8-56ed-47db-b817-127c3c113227">
											<gml:posList>35.669963836046264 139.74643450342467 6.552 35.669979486855034 139.74645111100034 6.552 35.669979486855034 139.74645111100034 12.7 35.669963836046264 139.74643450342467 12.7 35.669963836046264 139.74643450342467 6.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9959</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>