<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_94e36968-c9e0-4657-9a75-aa8597676a98">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">14.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671117687198 139.7388515054489 0 35.67109993753516 139.7387460999209 0 35.670910771796784 139.73878741544524 0 35.670946274437064 139.73900266669298 0 35.67097493270586 139.73899578424357 0 35.67097266819714 139.7389816475917 0 35.67112776499245 139.7389440179033 0 35.67113021038598 139.7389589276139 0 35.671161121648666 139.73895149016238 0 35.67114413829164 139.73884614993014 0 35.671117687198 139.7388515054489 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671117687198 139.7388515054489 17.32 35.67114413829164 139.73884614993014 17.32 35.671161121648666 139.73895149016238 17.32 35.67113021038598 139.7389589276139 17.32 35.67112776499245 139.7389440179033 17.32 35.67097266819714 139.7389816475917 17.32 35.67097493270586 139.73899578424357 17.32 35.670946274437064 139.73900266669298 17.32 35.670910771796784 139.73878741544524 17.32 35.67109993753516 139.7387460999209 17.32 35.671117687198 139.7388515054489 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671117687198 139.7388515054489 17.32 35.67109993753516 139.7387460999209 17.32 35.67109993753516 139.7387460999209 32.03 35.671117687198 139.7388515054489 32.03 35.671117687198 139.7388515054489 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67109993753516 139.7387460999209 17.32 35.670910771796784 139.73878741544524 17.32 35.670910771796784 139.73878741544524 32.03 35.67109993753516 139.7387460999209 32.03 35.67109993753516 139.7387460999209 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670910771796784 139.73878741544524 17.32 35.670946274437064 139.73900266669298 17.32 35.670946274437064 139.73900266669298 32.03 35.670910771796784 139.73878741544524 32.03 35.670910771796784 139.73878741544524 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670946274437064 139.73900266669298 17.32 35.67097493270586 139.73899578424357 17.32 35.67097493270586 139.73899578424357 32.03 35.670946274437064 139.73900266669298 32.03 35.670946274437064 139.73900266669298 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67097493270586 139.73899578424357 17.32 35.67097266819714 139.7389816475917 17.32 35.67097266819714 139.7389816475917 32.03 35.67097493270586 139.73899578424357 32.03 35.67097493270586 139.73899578424357 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67097266819714 139.7389816475917 17.32 35.67112776499245 139.7389440179033 17.32 35.67112776499245 139.7389440179033 32.03 35.67097266819714 139.7389816475917 32.03 35.67097266819714 139.7389816475917 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67112776499245 139.7389440179033 17.32 35.67113021038598 139.7389589276139 17.32 35.67113021038598 139.7389589276139 32.03 35.67112776499245 139.7389440179033 32.03 35.67112776499245 139.7389440179033 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67113021038598 139.7389589276139 17.32 35.671161121648666 139.73895149016238 17.32 35.671161121648666 139.73895149016238 32.03 35.67113021038598 139.7389589276139 32.03 35.67113021038598 139.7389589276139 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671161121648666 139.73895149016238 17.32 35.67114413829164 139.73884614993014 17.32 35.67114413829164 139.73884614993014 32.03 35.671161121648666 139.73895149016238 32.03 35.671161121648666 139.73895149016238 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67114413829164 139.73884614993014 17.32 35.671117687198 139.7388515054489 17.32 35.671117687198 139.7388515054489 32.03 35.67114413829164 139.73884614993014 32.03 35.67114413829164 139.73884614993014 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671117687198 139.7388515054489 32.03 35.67109993753516 139.7387460999209 32.03 35.670910771796784 139.73878741544524 32.03 35.670946274437064 139.73900266669298 32.03 35.67097493270586 139.73899578424357 32.03 35.67097266819714 139.7389816475917 32.03 35.67112776499245 139.7389440179033 32.03 35.67113021038598 139.7389589276139 32.03 35.671161121648666 139.73895149016238 32.03 35.67114413829164 139.73884614993014 32.03 35.671117687198 139.7388515054489 32.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c50cb0a9-87ee-42b9-9f5f-58aa7feb3030"/>
							<gml:surfaceMember xlink:href="#poly-c52f2798-9bba-4876-bce9-bc3fe68db088"/>
							<gml:surfaceMember xlink:href="#poly-8a710e33-4c43-41ce-8c1c-14d78afba03a"/>
							<gml:surfaceMember xlink:href="#poly-bd39680f-ee62-408c-8020-ef963d25e4bd"/>
							<gml:surfaceMember xlink:href="#poly-975750c8-068a-49cd-a273-5328494bdc62"/>
							<gml:surfaceMember xlink:href="#poly-ce652524-3052-41b8-94da-ef0161715c7c"/>
							<gml:surfaceMember xlink:href="#poly-401fc47f-c2fe-4a2c-b682-e3f2c39af9ec"/>
							<gml:surfaceMember xlink:href="#poly-e74607c4-4fe9-4fe4-a17c-fb33f1e9c977"/>
							<gml:surfaceMember xlink:href="#poly-c5fa4dfa-8bf1-4b6c-9229-1584fbe8a37d"/>
							<gml:surfaceMember xlink:href="#poly-b0c10e07-bd07-45b9-8d61-cd85ff74a793"/>
							<gml:surfaceMember xlink:href="#poly-7b32d21b-41ef-4f29-b382-f1bf742efde3"/>
							<gml:surfaceMember xlink:href="#poly-dff19c8f-ecdc-414a-92ae-201251788c93"/>
							<gml:surfaceMember xlink:href="#poly-c067c46b-a2b5-4d1a-a555-b8a0c4020ad2"/>
							<gml:surfaceMember xlink:href="#poly-ed76f2c4-69c6-4f5c-9e9b-a164855bab27"/>
							<gml:surfaceMember xlink:href="#poly-cc732a14-36a6-4174-b2e1-ab0b9d2432f7"/>
							<gml:surfaceMember xlink:href="#poly-e9e29083-5c34-45ac-b931-b2e871e10ab2"/>
							<gml:surfaceMember xlink:href="#poly-3d629207-0440-434d-83c7-b3cd38aee116"/>
							<gml:surfaceMember xlink:href="#poly-12fa3a76-8ef9-44c4-b4cc-4a5ea5855f4b"/>
							<gml:surfaceMember xlink:href="#poly-ff4d664d-ae11-4e48-abce-4c1fa68ae739"/>
							<gml:surfaceMember xlink:href="#poly-06efee58-e071-4e64-8824-fc3162611e40"/>
							<gml:surfaceMember xlink:href="#poly-85b5909e-970e-486b-b36c-e90d85666410"/>
							<gml:surfaceMember xlink:href="#poly-31f06965-eb1d-4fac-9cc8-6501e76a35ec"/>
							<gml:surfaceMember xlink:href="#poly-40c39587-e72c-4454-bc1c-d3215e9ded9f"/>
							<gml:surfaceMember xlink:href="#poly-4344d990-7858-485b-9a7a-5069e7d384c4"/>
							<gml:surfaceMember xlink:href="#poly-ca9f06c9-5934-43a2-b9f6-d2787b383bff"/>
							<gml:surfaceMember xlink:href="#poly-d4c959d1-02f5-4954-a163-1a60364448cd"/>
							<gml:surfaceMember xlink:href="#poly-74fb57f9-79ae-416f-b260-1391a69b4d6b"/>
							<gml:surfaceMember xlink:href="#poly-1f144878-e41c-469f-8bca-1fade075e16f"/>
							<gml:surfaceMember xlink:href="#poly-f370ee74-a67a-4b02-ae8e-5a7f47b72249"/>
							<gml:surfaceMember xlink:href="#poly-c7ed786b-b7dc-490e-ba70-340a27741541"/>
							<gml:surfaceMember xlink:href="#poly-11e2f781-47d8-4b45-9b47-517548c29eb2"/>
							<gml:surfaceMember xlink:href="#poly-ef32a21d-c06d-46a2-bf80-128bdded17f8"/>
							<gml:surfaceMember xlink:href="#poly-27babf1a-5ab7-49ac-b7b9-13b32e517d0f"/>
							<gml:surfaceMember xlink:href="#poly-861172e8-db47-4aa6-8364-05f854a80abb"/>
							<gml:surfaceMember xlink:href="#poly-bb1d7a5e-d2fe-4176-9af0-ef47a016f37f"/>
							<gml:surfaceMember xlink:href="#poly-11ed9c65-5ea0-4277-947e-b643d7ce2eca"/>
							<gml:surfaceMember xlink:href="#poly-b4e1e43b-a3ea-4a7b-8b7c-46b765b86f71"/>
							<gml:surfaceMember xlink:href="#poly-b1a57bea-d696-492a-9566-37cfd9baaff5"/>
							<gml:surfaceMember xlink:href="#poly-ebc3eb0e-abe8-4174-97d6-e1d73db982f6"/>
							<gml:surfaceMember xlink:href="#poly-684d4898-4c57-418d-99bb-785f825b95a8"/>
							<gml:surfaceMember xlink:href="#poly-d5f3db03-923f-4147-bfd1-922e080c87cd"/>
							<gml:surfaceMember xlink:href="#poly-37f77e62-fe89-48d6-8a4a-fd4d82658845"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_94e36968-c9e0-4657-9a75-aa8597676a98_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d00fe3a8-26ef-4f93-a900-1139141b7b80">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67113286130242 139.7387762176498 17.32 35.671144138291666 139.73884614993014 17.32 35.67111768719796 139.73885150544888 17.32 35.67110681659256 139.73878254479123 17.32 35.67113286130242 139.7387762176498 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e2bb2dc-61c0-424e-a762-886a0dbf0e13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e2bb2dc-61c0-424e-a762-886a0dbf0e13_0">
											<gml:posList>35.67110681659256 139.73878254479123 29.451 35.67110681659256 139.73878254479123 17.32 35.67111768719796 139.73885150544888 17.32 35.67111768719796 139.73885150544888 29.451 35.67110681659256 139.73878254479123 29.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1361418b-b2ce-4122-9885-ee4c3bafb4e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1361418b-b2ce-4122-9885-ee4c3bafb4e7_0">
											<gml:posList>35.67113286130242 139.7387762176498 29.451 35.67113286130242 139.7387762176498 17.32 35.67110681659256 139.73878254479123 17.32 35.67110681659256 139.73878254479123 29.451 35.67113286130242 139.7387762176498 29.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18584e60-0810-4a99-af67-0b526ca63edf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18584e60-0810-4a99-af67-0b526ca63edf_0">
											<gml:posList>35.67113286130242 139.7387762176498 29.451 35.67110681659256 139.73878254479123 29.451 35.67111768719796 139.73885150544888 29.451 35.671144138291666 139.73884614993014 29.451 35.67113286130242 139.7387762176498 29.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9536fbb-0764-4575-bd4d-cfc9d85c931d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9536fbb-0764-4575-bd4d-cfc9d85c931d_0">
											<gml:posList>35.67111768719796 139.73885150544888 29.451 35.67111768719796 139.73885150544888 17.32 35.671144138291666 139.73884614993014 17.32 35.671144138291666 139.73884614993014 29.451 35.67111768719796 139.73885150544888 29.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4accf6e3-3f6e-4234-b16f-316d62e92159">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4accf6e3-3f6e-4234-b16f-316d62e92159_0">
											<gml:posList>35.671144138291666 139.73884614993014 29.451 35.671144138291666 139.73884614993014 17.32 35.67113286130242 139.7387762176498 17.32 35.67113286130242 139.7387762176498 29.451 35.671144138291666 139.73884614993014 29.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_94e36968-c9e0-4657-9a75-aa8597676a98_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a84d777b-5315-4e59-b122-51a376a3ef2d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67095575486179 139.73887361221142 31.778 35.67096170516421 139.73890967149916 31.778 35.67093663383317 139.73891587592766 31.778 35.67093068353259 139.7388798166507 31.778 35.67095575486179 139.73887361221142 31.778</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c63313d5-2491-4742-ba96-e1287743dbd8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67093068353259 139.7388798166507 32.678 35.67093663383317 139.73891587592766 32.678 35.67093214586603 139.73891698584634 32.678 35.67092619556578 139.7388809265713 32.678 35.67093068353259 139.7388798166507 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dea71657-9fe5-4a9d-8c4e-eafeb179c7b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dea71657-9fe5-4a9d-8c4e-eafeb179c7b7_0">
											<gml:posList>35.67093068353259 139.7388798166507 32.678 35.67092619556578 139.7388809265713 32.678 35.67092619556578 139.7388809265713 38.452 35.67095575486179 139.73887361221142 38.452 35.67095575486179 139.73887361221142 31.778 35.67093068353259 139.7388798166507 31.778 35.67093068353259 139.7388798166507 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ccbb821-6402-40d3-b7aa-c8ad36357d57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ccbb821-6402-40d3-b7aa-c8ad36357d57_0">
											<gml:posList>35.67095575486179 139.73887361221142 31.778 35.67095575486179 139.73887361221142 38.452 35.67096170516421 139.73890967149916 38.452 35.67096170516421 139.73890967149916 31.778 35.67095575486179 139.73887361221142 31.778</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5f2081f-8ca0-4662-a400-7e39fbacf6d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5f2081f-8ca0-4662-a400-7e39fbacf6d0_0">
											<gml:posList>35.67095575486179 139.73887361221142 38.452 35.67092619556578 139.7388809265713 38.452 35.67093214586603 139.73891698584634 38.452 35.67096170516421 139.73890967149916 38.452 35.67095575486179 139.73887361221142 38.452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2aeaf299-db20-4628-986e-9778ec17245f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2aeaf299-db20-4628-986e-9778ec17245f_0">
											<gml:posList>35.67093068353259 139.7388798166507 32.678 35.67093068353259 139.7388798166507 31.778 35.67093663383317 139.73891587592766 31.778 35.67093663383317 139.73891587592766 32.678 35.67093068353259 139.7388798166507 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c5411ae-92f6-46fa-872d-b2ee8bca8061">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c5411ae-92f6-46fa-872d-b2ee8bca8061_0">
											<gml:posList>35.67093214586603 139.73891698584634 32.678 35.67093214586603 139.73891698584634 38.452 35.67092619556578 139.7388809265713 38.452 35.67092619556578 139.7388809265713 32.678 35.67093214586603 139.73891698584634 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f9465e2-1a90-4d56-b515-2c98c433c58d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f9465e2-1a90-4d56-b515-2c98c433c58d_0">
											<gml:posList>35.67096170516421 139.73890967149916 31.778 35.67096170516421 139.73890967149916 38.452 35.67093214586603 139.73891698584634 38.452 35.67093214586603 139.73891698584634 32.678 35.67093663383317 139.73891587592766 32.678 35.67093663383317 139.73891587592766 31.778 35.67096170516421 139.73890967149916 31.778</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c50cb0a9-87ee-42b9-9f5f-58aa7feb3030">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c50cb0a9-87ee-42b9-9f5f-58aa7feb3030">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c50cb0a9-87ee-42b9-9f5f-58aa7feb3030">
											<gml:posList>35.67116112164866 139.73895149016238 17.32 35.67113021038597 139.7389589276139 17.32 35.67112776499243 139.7389440179033 17.32 35.67097266819713 139.73898164759166 17.32 35.67097493270581 139.73899578424357 17.32 35.67094627443707 139.73900266669295 17.32 35.67091077179677 139.73878741544524 17.32 35.671099937535146 139.73874609992086 17.32 35.67111768719796 139.73885150544888 17.32 35.671144138291666 139.73884614993014 17.32 35.67116112164866 139.73895149016238 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c52f2798-9bba-4876-bce9-bc3fe68db088">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c52f2798-9bba-4876-bce9-bc3fe68db088">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c52f2798-9bba-4876-bce9-bc3fe68db088">
											<gml:posList>35.67091972901082 139.73884173075132 32.678 35.67094544064173 139.73883594530713 32.678 35.67093730366506 139.73878161797066 26.565 35.67091077179677 139.73878741544524 26.565 35.67091972901082 139.73884173075132 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a710e33-4c43-41ce-8c1c-14d78afba03a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a710e33-4c43-41ce-8c1c-14d78afba03a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a710e33-4c43-41ce-8c1c-14d78afba03a">
											<gml:posList>35.67094627443707 139.73900266669295 32.678 35.67094986577149 139.73899610094293 32.678 35.670925140771665 139.73884622023138 32.678 35.67091972901082 139.73884173075132 32.678 35.67094627443707 139.73900266669295 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd39680f-ee62-408c-8020-ef963d25e4bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd39680f-ee62-408c-8020-ef963d25e4bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd39680f-ee62-408c-8020-ef963d25e4bd">
											<gml:posList>35.67094544064173 139.73883594530713 32.678 35.67091972901082 139.73884173075132 32.678 35.670925140771665 139.73884622023138 32.678 35.67095077129661 139.73884045697648 32.678 35.67094544064173 139.73883594530713 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-975750c8-068a-49cd-a273-5328494bdc62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-975750c8-068a-49cd-a273-5328494bdc62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-975750c8-068a-49cd-a273-5328494bdc62">
											<gml:posList>35.67094544064173 139.73883594530713 32.678 35.67095077129661 139.73884045697648 32.678 35.67094986517396 139.73883440465133 32.678 35.670944534518846 139.7388298929824 32.678 35.67094544064173 139.73883594530713 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce652524-3052-41b8-94da-ef0161715c7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce652524-3052-41b8-94da-ef0161715c7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce652524-3052-41b8-94da-ef0161715c7c">
											<gml:posList>35.67097493270581 139.73899578424357 32.678 35.67096957508483 139.73899136096497 32.678 35.67094986577149 139.73899610094293 32.678 35.67094627443707 139.73900266669295 32.678 35.67097493270581 139.73899578424357 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-401fc47f-c2fe-4a2c-b682-e3f2c39af9ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-401fc47f-c2fe-4a2c-b682-e3f2c39af9ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-401fc47f-c2fe-4a2c-b682-e3f2c39af9ec">
											<gml:posList>35.67097266819713 139.73898164759166 32.678 35.67096731058428 139.7389772353605 32.678 35.67096957508483 139.73899136096497 32.678 35.67097493270581 139.73899578424357 32.678 35.67097266819713 139.73898164759166 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e74607c4-4fe9-4fe4-a17c-fb33f1e9c977">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e74607c4-4fe9-4fe4-a17c-fb33f1e9c977">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e74607c4-4fe9-4fe4-a17c-fb33f1e9c977">
											<gml:posList>35.671099937535146 139.73874609992086 26.565 35.67093730366506 139.73878161797066 26.565 35.670944534518846 139.7388298929824 32.678 35.671099937535146 139.73874609992086 26.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c5fa4dfa-8bf1-4b6c-9229-1584fbe8a37d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5fa4dfa-8bf1-4b6c-9229-1584fbe8a37d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5fa4dfa-8bf1-4b6c-9229-1584fbe8a37d">
											<gml:posList>35.670944534518846 139.7388298929824 32.678 35.67094986517396 139.73883440465133 32.678 35.67110483787341 139.73879950328597 32.678 35.671108465286196 139.73879298165676 32.678 35.670944534518846 139.7388298929824 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b0c10e07-bd07-45b9-8d61-cd85ff74a793">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0c10e07-bd07-45b9-8d61-cd85ff74a793">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0c10e07-bd07-45b9-8d61-cd85ff74a793">
											<gml:posList>35.671099937535146 139.73874609992086 26.565 35.670944534518846 139.7388298929824 32.678 35.671108465286196 139.73879298165676 32.678 35.671099937535146 139.73874609992086 26.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b32d21b-41ef-4f29-b382-f1bf742efde3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b32d21b-41ef-4f29-b382-f1bf742efde3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b32d21b-41ef-4f29-b382-f1bf742efde3">
											<gml:posList>35.67094986577149 139.73899610094293 31.778 35.67096957508483 139.73899136096497 31.778 35.67096731058428 139.7389772353605 31.778 35.67113134730113 139.73893744110003 31.778 35.67113379269549 139.73895235081113 31.778 35.671155755012485 139.73894706688716 31.778 35.67114051981174 139.73885257213203 31.778 35.67111404167657 139.73885792768033 31.778 35.67110483787341 139.73879950328597 31.778 35.67094986517396 139.73883440465133 31.778 35.67095077129661 139.73884045697648 31.778 35.670925140771665 139.73884622023138 31.778 35.67094986577149 139.73899610094293 31.778</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dff19c8f-ecdc-414a-92ae-201251788c93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dff19c8f-ecdc-414a-92ae-201251788c93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dff19c8f-ecdc-414a-92ae-201251788c93">
											<gml:posList>35.67112776499243 139.7389440179033 32.678 35.67113134730113 139.73893744110003 32.678 35.67096731058428 139.7389772353605 32.678 35.67097266819713 139.73898164759166 32.678 35.67112776499243 139.7389440179033 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c067c46b-a2b5-4d1a-a555-b8a0c4020ad2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c067c46b-a2b5-4d1a-a555-b8a0c4020ad2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c067c46b-a2b5-4d1a-a555-b8a0c4020ad2">
											<gml:posList>35.67111768719796 139.73885150544888 32.678 35.671108465286196 139.73879298165676 32.678 35.67110483787341 139.73879950328597 32.678 35.67111404167657 139.73885792768033 32.678 35.67111768719796 139.73885150544888 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed76f2c4-69c6-4f5c-9e9b-a164855bab27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed76f2c4-69c6-4f5c-9e9b-a164855bab27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed76f2c4-69c6-4f5c-9e9b-a164855bab27">
											<gml:posList>35.67111768719796 139.73885150544888 32.678 35.67111404167657 139.73885792768033 32.678 35.67114051981174 139.73885257213203 32.678 35.671144138291666 139.73884614993014 32.678 35.67111768719796 139.73885150544888 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc732a14-36a6-4174-b2e1-ab0b9d2432f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc732a14-36a6-4174-b2e1-ab0b9d2432f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc732a14-36a6-4174-b2e1-ab0b9d2432f7">
											<gml:posList>35.67112776499243 139.7389440179033 32.678 35.67113021038597 139.7389589276139 32.678 35.67113379269549 139.73895235081113 32.678 35.67113134730113 139.73893744110003 32.678 35.67112776499243 139.7389440179033 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e9e29083-5c34-45ac-b931-b2e871e10ab2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9e29083-5c34-45ac-b931-b2e871e10ab2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9e29083-5c34-45ac-b931-b2e871e10ab2">
											<gml:posList>35.67116112164866 139.73895149016238 32.678 35.671155755012485 139.73894706688716 32.678 35.67113379269549 139.73895235081113 32.678 35.67113021038597 139.7389589276139 32.678 35.67116112164866 139.73895149016238 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d629207-0440-434d-83c7-b3cd38aee116">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d629207-0440-434d-83c7-b3cd38aee116">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d629207-0440-434d-83c7-b3cd38aee116">
											<gml:posList>35.671144138291666 139.73884614993014 32.678 35.67114051981174 139.73885257213203 32.678 35.671155755012485 139.73894706688716 32.678 35.67116112164866 139.73895149016238 32.678 35.671144138291666 139.73884614993014 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-12fa3a76-8ef9-44c4-b4cc-4a5ea5855f4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12fa3a76-8ef9-44c4-b4cc-4a5ea5855f4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12fa3a76-8ef9-44c4-b4cc-4a5ea5855f4b">
											<gml:posList>35.67091077179677 139.73878741544524 17.32 35.67094627443707 139.73900266669295 17.32 35.67094627443707 139.73900266669295 32.678 35.67091972901082 139.73884173075132 32.678 35.67091077179677 139.73878741544524 26.565 35.67091077179677 139.73878741544524 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff4d664d-ae11-4e48-abce-4c1fa68ae739">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff4d664d-ae11-4e48-abce-4c1fa68ae739">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff4d664d-ae11-4e48-abce-4c1fa68ae739">
											<gml:posList>35.67094986577149 139.73899610094293 32.678 35.67094986577149 139.73899610094293 31.778 35.670925140771665 139.73884622023138 31.778 35.670925140771665 139.73884622023138 32.678 35.67094986577149 139.73899610094293 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06efee58-e071-4e64-8824-fc3162611e40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06efee58-e071-4e64-8824-fc3162611e40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06efee58-e071-4e64-8824-fc3162611e40">
											<gml:posList>35.670925140771665 139.73884622023138 32.678 35.670925140771665 139.73884622023138 31.778 35.67095077129661 139.73884045697648 31.778 35.67095077129661 139.73884045697648 32.678 35.670925140771665 139.73884622023138 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85b5909e-970e-486b-b36c-e90d85666410">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85b5909e-970e-486b-b36c-e90d85666410">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85b5909e-970e-486b-b36c-e90d85666410">
											<gml:posList>35.67093730366506 139.73878161797066 26.565 35.67094544064173 139.73883594530713 32.678 35.670944534518846 139.7388298929824 32.678 35.67093730366506 139.73878161797066 26.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31f06965-eb1d-4fac-9cc8-6501e76a35ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31f06965-eb1d-4fac-9cc8-6501e76a35ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31f06965-eb1d-4fac-9cc8-6501e76a35ec">
											<gml:posList>35.67095077129661 139.73884045697648 32.678 35.67095077129661 139.73884045697648 31.778 35.67094986517396 139.73883440465133 31.778 35.67094986517396 139.73883440465133 32.678 35.67095077129661 139.73884045697648 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40c39587-e72c-4454-bc1c-d3215e9ded9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40c39587-e72c-4454-bc1c-d3215e9ded9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40c39587-e72c-4454-bc1c-d3215e9ded9f">
											<gml:posList>35.67096957508483 139.73899136096497 32.678 35.67096957508483 139.73899136096497 31.778 35.67094986577149 139.73899610094293 31.778 35.67094986577149 139.73899610094293 32.678 35.67096957508483 139.73899136096497 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4344d990-7858-485b-9a7a-5069e7d384c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4344d990-7858-485b-9a7a-5069e7d384c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4344d990-7858-485b-9a7a-5069e7d384c4">
											<gml:posList>35.67094627443707 139.73900266669295 17.32 35.67097493270581 139.73899578424357 17.32 35.67097493270581 139.73899578424357 32.678 35.67094627443707 139.73900266669295 32.678 35.67094627443707 139.73900266669295 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca9f06c9-5934-43a2-b9f6-d2787b383bff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca9f06c9-5934-43a2-b9f6-d2787b383bff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca9f06c9-5934-43a2-b9f6-d2787b383bff">
											<gml:posList>35.67096731058428 139.7389772353605 32.678 35.67096731058428 139.7389772353605 31.778 35.67096957508483 139.73899136096497 31.778 35.67096957508483 139.73899136096497 32.678 35.67096731058428 139.7389772353605 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4c959d1-02f5-4954-a163-1a60364448cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4c959d1-02f5-4954-a163-1a60364448cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4c959d1-02f5-4954-a163-1a60364448cd">
											<gml:posList>35.67097493270581 139.73899578424357 17.32 35.67097266819713 139.73898164759166 17.32 35.67097266819713 139.73898164759166 32.678 35.67097493270581 139.73899578424357 32.678 35.67097493270581 139.73899578424357 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74fb57f9-79ae-416f-b260-1391a69b4d6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74fb57f9-79ae-416f-b260-1391a69b4d6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74fb57f9-79ae-416f-b260-1391a69b4d6b">
											<gml:posList>35.671099937535146 139.73874609992086 17.32 35.67091077179677 139.73878741544524 17.32 35.67091077179677 139.73878741544524 26.565 35.67093730366506 139.73878161797066 26.565 35.671099937535146 139.73874609992086 26.565 35.671099937535146 139.73874609992086 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f144878-e41c-469f-8bca-1fade075e16f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f144878-e41c-469f-8bca-1fade075e16f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f144878-e41c-469f-8bca-1fade075e16f">
											<gml:posList>35.67094986517396 139.73883440465133 32.678 35.67094986517396 139.73883440465133 31.778 35.67110483787341 139.73879950328597 31.778 35.67110483787341 139.73879950328597 32.678 35.67094986517396 139.73883440465133 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f370ee74-a67a-4b02-ae8e-5a7f47b72249">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f370ee74-a67a-4b02-ae8e-5a7f47b72249">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f370ee74-a67a-4b02-ae8e-5a7f47b72249">
											<gml:posList>35.67113134730113 139.73893744110003 32.678 35.67113134730113 139.73893744110003 31.778 35.67096731058428 139.7389772353605 31.778 35.67096731058428 139.7389772353605 32.678 35.67113134730113 139.73893744110003 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7ed786b-b7dc-490e-ba70-340a27741541">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7ed786b-b7dc-490e-ba70-340a27741541">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7ed786b-b7dc-490e-ba70-340a27741541">
											<gml:posList>35.67097266819713 139.73898164759166 17.32 35.67112776499243 139.7389440179033 17.32 35.67112776499243 139.7389440179033 32.678 35.67097266819713 139.73898164759166 32.678 35.67097266819713 139.73898164759166 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11e2f781-47d8-4b45-9b47-517548c29eb2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11e2f781-47d8-4b45-9b47-517548c29eb2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11e2f781-47d8-4b45-9b47-517548c29eb2">
											<gml:posList>35.671108465286196 139.73879298165676 32.678 35.671099937535146 139.73874609992086 17.32 35.671099937535146 139.73874609992086 26.565 35.671108465286196 139.73879298165676 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef32a21d-c06d-46a2-bf80-128bdded17f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef32a21d-c06d-46a2-bf80-128bdded17f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef32a21d-c06d-46a2-bf80-128bdded17f8">
											<gml:posList>35.671108465286196 139.73879298165676 32.678 35.67111768719796 139.73885150544888 17.32 35.671099937535146 139.73874609992086 17.32 35.671108465286196 139.73879298165676 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27babf1a-5ab7-49ac-b7b9-13b32e517d0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27babf1a-5ab7-49ac-b7b9-13b32e517d0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27babf1a-5ab7-49ac-b7b9-13b32e517d0f">
											<gml:posList>35.67110483787341 139.73879950328597 32.678 35.67110483787341 139.73879950328597 31.778 35.67111404167657 139.73885792768033 31.778 35.67111404167657 139.73885792768033 32.678 35.67110483787341 139.73879950328597 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-861172e8-db47-4aa6-8364-05f854a80abb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-861172e8-db47-4aa6-8364-05f854a80abb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-861172e8-db47-4aa6-8364-05f854a80abb">
											<gml:posList>35.671108465286196 139.73879298165676 32.678 35.67111768719796 139.73885150544888 32.678 35.67111768719796 139.73885150544888 17.32 35.671108465286196 139.73879298165676 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb1d7a5e-d2fe-4176-9af0-ef47a016f37f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb1d7a5e-d2fe-4176-9af0-ef47a016f37f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb1d7a5e-d2fe-4176-9af0-ef47a016f37f">
											<gml:posList>35.67111404167657 139.73885792768033 32.678 35.67111404167657 139.73885792768033 31.778 35.67114051981174 139.73885257213203 31.778 35.67114051981174 139.73885257213203 32.678 35.67111404167657 139.73885792768033 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11ed9c65-5ea0-4277-947e-b643d7ce2eca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11ed9c65-5ea0-4277-947e-b643d7ce2eca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11ed9c65-5ea0-4277-947e-b643d7ce2eca">
											<gml:posList>35.67112776499243 139.7389440179033 17.32 35.67113021038597 139.7389589276139 17.32 35.67113021038597 139.7389589276139 32.678 35.67112776499243 139.7389440179033 32.678 35.67112776499243 139.7389440179033 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4e1e43b-a3ea-4a7b-8b7c-46b765b86f71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4e1e43b-a3ea-4a7b-8b7c-46b765b86f71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4e1e43b-a3ea-4a7b-8b7c-46b765b86f71">
											<gml:posList>35.671144138291666 139.73884614993014 17.32 35.67111768719796 139.73885150544888 17.32 35.67111768719796 139.73885150544888 32.678 35.671144138291666 139.73884614993014 32.678 35.671144138291666 139.73884614993014 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1a57bea-d696-492a-9566-37cfd9baaff5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1a57bea-d696-492a-9566-37cfd9baaff5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1a57bea-d696-492a-9566-37cfd9baaff5">
											<gml:posList>35.67113379269549 139.73895235081113 32.678 35.67113379269549 139.73895235081113 31.778 35.67113134730113 139.73893744110003 31.778 35.67113134730113 139.73893744110003 32.678 35.67113379269549 139.73895235081113 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebc3eb0e-abe8-4174-97d6-e1d73db982f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebc3eb0e-abe8-4174-97d6-e1d73db982f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebc3eb0e-abe8-4174-97d6-e1d73db982f6">
											<gml:posList>35.671155755012485 139.73894706688716 32.678 35.671155755012485 139.73894706688716 31.778 35.67113379269549 139.73895235081113 31.778 35.67113379269549 139.73895235081113 32.678 35.671155755012485 139.73894706688716 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-684d4898-4c57-418d-99bb-785f825b95a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-684d4898-4c57-418d-99bb-785f825b95a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-684d4898-4c57-418d-99bb-785f825b95a8">
											<gml:posList>35.67113021038597 139.7389589276139 17.32 35.67116112164866 139.73895149016238 17.32 35.67116112164866 139.73895149016238 32.678 35.67113021038597 139.7389589276139 32.678 35.67113021038597 139.7389589276139 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5f3db03-923f-4147-bfd1-922e080c87cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5f3db03-923f-4147-bfd1-922e080c87cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5f3db03-923f-4147-bfd1-922e080c87cd">
											<gml:posList>35.67114051981174 139.73885257213203 32.678 35.67114051981174 139.73885257213203 31.778 35.671155755012485 139.73894706688716 31.778 35.671155755012485 139.73894706688716 32.678 35.67114051981174 139.73885257213203 32.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37f77e62-fe89-48d6-8a4a-fd4d82658845">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37f77e62-fe89-48d6-8a4a-fd4d82658845">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37f77e62-fe89-48d6-8a4a-fd4d82658845">
											<gml:posList>35.67116112164866 139.73895149016238 17.32 35.671144138291666 139.73884614993014 17.32 35.671144138291666 139.73884614993014 32.678 35.67116112164866 139.73895149016238 32.678 35.67116112164866 139.73895149016238 17.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7494</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">445.3756</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>