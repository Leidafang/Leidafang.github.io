<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_95611643-0e5f-4243-a15c-4072def2f279">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">15.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66894016606844 139.7382877508944 0 35.668965835366386 139.7382512021778 0 35.66895367549792 139.73823935312603 0 35.66884917991293 139.7381374667995 0 35.66882460239207 139.73817538391305 0 35.66884363610136 139.73819402914467 0 35.6688354435607 139.73820663135834 0 35.668849966825796 139.73822075307012 0 35.668844025008994 139.73822992833786 0 35.668872440135196 139.73825762022412 0 35.66885803579167 139.73827995032406 0 35.66889493034468 139.73831591672464 0 35.66891891825283 139.73828465004664 0 35.668927686532896 139.7382934323157 0 35.6689058447518 139.73832579001103 0 35.668895543757316 139.73831652353076 0 35.668880959128444 139.73833885384016 0 35.66890948243773 139.7383666008799 0 35.66895275894842 139.73830005232688 0 35.66894016606844 139.7382877508944 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894016606844 139.7382877508944 18.74 35.66895275894842 139.73830005232688 18.74 35.66890948243773 139.7383666008799 18.74 35.668880959128444 139.73833885384016 18.74 35.668895543757316 139.73831652353076 18.74 35.6689058447518 139.73832579001103 18.74 35.668927686532896 139.7382934323157 18.74 35.66891891825283 139.73828465004664 18.74 35.66889493034468 139.73831591672464 18.74 35.66885803579167 139.73827995032406 18.74 35.668872440135196 139.73825762022412 18.74 35.668844025008994 139.73822992833786 18.74 35.668849966825796 139.73822075307012 18.74 35.6688354435607 139.73820663135834 18.74 35.66884363610136 139.73819402914467 18.74 35.66882460239207 139.73817538391305 18.74 35.66884917991293 139.7381374667995 18.74 35.66895367549792 139.73823935312603 18.74 35.668965835366386 139.7382512021778 18.74 35.66894016606844 139.7382877508944 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894016606844 139.7382877508944 18.74 35.668965835366386 139.7382512021778 18.74 35.668965835366386 139.7382512021778 34.46 35.66894016606844 139.7382877508944 34.46 35.66894016606844 139.7382877508944 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668965835366386 139.7382512021778 18.74 35.66895367549792 139.73823935312603 18.74 35.66895367549792 139.73823935312603 34.46 35.668965835366386 139.7382512021778 34.46 35.668965835366386 139.7382512021778 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66895367549792 139.73823935312603 18.74 35.66884917991293 139.7381374667995 18.74 35.66884917991293 139.7381374667995 34.46 35.66895367549792 139.73823935312603 34.46 35.66895367549792 139.73823935312603 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884917991293 139.7381374667995 18.74 35.66882460239207 139.73817538391305 18.74 35.66882460239207 139.73817538391305 34.46 35.66884917991293 139.7381374667995 34.46 35.66884917991293 139.7381374667995 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882460239207 139.73817538391305 18.74 35.66884363610136 139.73819402914467 18.74 35.66884363610136 139.73819402914467 34.46 35.66882460239207 139.73817538391305 34.46 35.66882460239207 139.73817538391305 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884363610136 139.73819402914467 18.74 35.6688354435607 139.73820663135834 18.74 35.6688354435607 139.73820663135834 34.46 35.66884363610136 139.73819402914467 34.46 35.66884363610136 139.73819402914467 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6688354435607 139.73820663135834 18.74 35.668849966825796 139.73822075307012 18.74 35.668849966825796 139.73822075307012 34.46 35.6688354435607 139.73820663135834 34.46 35.6688354435607 139.73820663135834 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668849966825796 139.73822075307012 18.74 35.668844025008994 139.73822992833786 18.74 35.668844025008994 139.73822992833786 34.46 35.668849966825796 139.73822075307012 34.46 35.668849966825796 139.73822075307012 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668844025008994 139.73822992833786 18.74 35.668872440135196 139.73825762022412 18.74 35.668872440135196 139.73825762022412 34.46 35.668844025008994 139.73822992833786 34.46 35.668844025008994 139.73822992833786 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668872440135196 139.73825762022412 18.74 35.66885803579167 139.73827995032406 18.74 35.66885803579167 139.73827995032406 34.46 35.668872440135196 139.73825762022412 34.46 35.668872440135196 139.73825762022412 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66885803579167 139.73827995032406 18.74 35.66889493034468 139.73831591672464 18.74 35.66889493034468 139.73831591672464 34.46 35.66885803579167 139.73827995032406 34.46 35.66885803579167 139.73827995032406 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66889493034468 139.73831591672464 18.74 35.66891891825283 139.73828465004664 18.74 35.66891891825283 139.73828465004664 34.46 35.66889493034468 139.73831591672464 34.46 35.66889493034468 139.73831591672464 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66891891825283 139.73828465004664 18.74 35.668927686532896 139.7382934323157 18.74 35.668927686532896 139.7382934323157 34.46 35.66891891825283 139.73828465004664 34.46 35.66891891825283 139.73828465004664 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668927686532896 139.7382934323157 18.74 35.6689058447518 139.73832579001103 18.74 35.6689058447518 139.73832579001103 34.46 35.668927686532896 139.7382934323157 34.46 35.668927686532896 139.7382934323157 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6689058447518 139.73832579001103 18.74 35.668895543757316 139.73831652353076 18.74 35.668895543757316 139.73831652353076 34.46 35.6689058447518 139.73832579001103 34.46 35.6689058447518 139.73832579001103 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668895543757316 139.73831652353076 18.74 35.668880959128444 139.73833885384016 18.74 35.668880959128444 139.73833885384016 34.46 35.668895543757316 139.73831652353076 34.46 35.668895543757316 139.73831652353076 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668880959128444 139.73833885384016 18.74 35.66890948243773 139.7383666008799 18.74 35.66890948243773 139.7383666008799 34.46 35.668880959128444 139.73833885384016 34.46 35.668880959128444 139.73833885384016 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890948243773 139.7383666008799 18.74 35.66895275894842 139.73830005232688 18.74 35.66895275894842 139.73830005232688 34.46 35.66890948243773 139.7383666008799 34.46 35.66890948243773 139.7383666008799 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66895275894842 139.73830005232688 18.74 35.66894016606844 139.7382877508944 18.74 35.66894016606844 139.7382877508944 34.46 35.66895275894842 139.73830005232688 34.46 35.66895275894842 139.73830005232688 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894016606844 139.7382877508944 34.46 35.668965835366386 139.7382512021778 34.46 35.66895367549792 139.73823935312603 34.46 35.66884917991293 139.7381374667995 34.46 35.66882460239207 139.73817538391305 34.46 35.66884363610136 139.73819402914467 34.46 35.6688354435607 139.73820663135834 34.46 35.668849966825796 139.73822075307012 34.46 35.668844025008994 139.73822992833786 34.46 35.668872440135196 139.73825762022412 34.46 35.66885803579167 139.73827995032406 34.46 35.66889493034468 139.73831591672464 34.46 35.66891891825283 139.73828465004664 34.46 35.668927686532896 139.7382934323157 34.46 35.6689058447518 139.73832579001103 34.46 35.668895543757316 139.73831652353076 34.46 35.668880959128444 139.73833885384016 34.46 35.66890948243773 139.7383666008799 34.46 35.66895275894842 139.73830005232688 34.46 35.66894016606844 139.7382877508944 34.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3d76f01d-f0b6-4cca-a87b-afad67fd2fe4"/>
							<gml:surfaceMember xlink:href="#poly-70cddd8f-e170-4403-ab2b-702f90d16662"/>
							<gml:surfaceMember xlink:href="#poly-f5cc3480-dcda-4e94-a0e3-cde395aab659"/>
							<gml:surfaceMember xlink:href="#poly-b3413ae1-8a4b-41bb-9107-8c0fbbda9a45"/>
							<gml:surfaceMember xlink:href="#poly-88f8b916-da4d-4aec-8a30-f5bc26a4988c"/>
							<gml:surfaceMember xlink:href="#poly-2472d9de-12cc-41f0-93bb-bb16392e2852"/>
							<gml:surfaceMember xlink:href="#poly-90588466-f628-4117-bd5c-ed685303833d"/>
							<gml:surfaceMember xlink:href="#poly-e4362b8a-4d5e-48cc-8e77-0abc4338d126"/>
							<gml:surfaceMember xlink:href="#poly-c2fad1ce-fb30-403f-b6a4-73aa1ac3bc19"/>
							<gml:surfaceMember xlink:href="#poly-37c4b8df-bda8-4cc9-8682-e40b4fbd1745"/>
							<gml:surfaceMember xlink:href="#poly-50bb5838-5f72-4ed5-b39d-c98964b389bf"/>
							<gml:surfaceMember xlink:href="#poly-179420ce-8d11-4574-9455-7383775748ca"/>
							<gml:surfaceMember xlink:href="#poly-a2b7cf89-d016-44e7-be18-f75bf39e5367"/>
							<gml:surfaceMember xlink:href="#poly-26e96075-e6d5-4bb6-929e-07722629487b"/>
							<gml:surfaceMember xlink:href="#poly-3ce5a623-7583-48c8-a9c6-42f32bfa4d0a"/>
							<gml:surfaceMember xlink:href="#poly-6ac4142a-2b31-4ca5-bbb4-31d50be73f59"/>
							<gml:surfaceMember xlink:href="#poly-702498f9-e543-4fdd-80fb-443634657c06"/>
							<gml:surfaceMember xlink:href="#poly-a7c4165b-2562-40d5-b5c5-a2d0e02d8c39"/>
							<gml:surfaceMember xlink:href="#poly-850a11ff-9329-4bf4-821b-90f0622558cc"/>
							<gml:surfaceMember xlink:href="#poly-c470e000-b5e1-49cb-920e-5c3b9ff75fd1"/>
							<gml:surfaceMember xlink:href="#poly-76d18dad-a208-4914-abb8-b9e56ed0c57c"/>
							<gml:surfaceMember xlink:href="#poly-31985237-0cd2-4819-be42-d754d0d05c84"/>
							<gml:surfaceMember xlink:href="#poly-d33dd5b1-4dd2-459f-bfdc-850c741f767c"/>
							<gml:surfaceMember xlink:href="#poly-b88a4924-e9ac-41ec-9857-cd72b5e81da9"/>
							<gml:surfaceMember xlink:href="#poly-771c9a26-8111-4cee-86df-92f6ee5c18ff"/>
							<gml:surfaceMember xlink:href="#poly-39957c55-01af-4155-961c-9db2ffbc0d90"/>
							<gml:surfaceMember xlink:href="#poly-efa9adef-b5d3-4e8d-ba94-04e81ca77a0e"/>
							<gml:surfaceMember xlink:href="#poly-41d32f87-ef2e-4c5c-a573-add447a62a5b"/>
							<gml:surfaceMember xlink:href="#poly-62d90289-851a-47fc-96a2-0436d4bd5fbc"/>
							<gml:surfaceMember xlink:href="#poly-35174951-83d2-495b-9cda-7ac0aec72e6f"/>
							<gml:surfaceMember xlink:href="#poly-e0819b95-f06c-4bdb-bc60-f37b35fba82c"/>
							<gml:surfaceMember xlink:href="#poly-2a965a97-2119-4945-bfcd-c00db983534e"/>
							<gml:surfaceMember xlink:href="#poly-8ffa4928-5955-424c-8c5d-7038045a6f94"/>
							<gml:surfaceMember xlink:href="#poly-3361c50d-f91c-4101-879e-3a150f9bb5d6"/>
							<gml:surfaceMember xlink:href="#poly-6624833c-f2eb-4ee3-8a7f-8c9442ec43c9"/>
							<gml:surfaceMember xlink:href="#poly-53bd5121-d4aa-4211-bd04-579a5b7374f6"/>
							<gml:surfaceMember xlink:href="#poly-0a4efbd4-0ac4-4d12-98da-13bf078d63a2"/>
							<gml:surfaceMember xlink:href="#poly-ebf571b2-e748-40d5-b880-744095e5d113"/>
							<gml:surfaceMember xlink:href="#poly-d7d6392c-8a29-41e0-b240-f1394cee2b66"/>
							<gml:surfaceMember xlink:href="#poly-a10c8a3a-e237-4384-84b1-295c4d3c61e1"/>
							<gml:surfaceMember xlink:href="#poly-ddd0acd6-d5f8-42bd-bf28-eddc87157038"/>
							<gml:surfaceMember xlink:href="#poly-473324cd-f731-436d-8920-b16e57530857"/>
							<gml:surfaceMember xlink:href="#poly-1ce2c6ff-19ae-4dd9-b5e3-36ee8da09718"/>
							<gml:surfaceMember xlink:href="#poly-ea908fca-b780-40fe-aab0-36df00028388"/>
							<gml:surfaceMember xlink:href="#poly-b062de30-5a18-4e71-84ae-5c1e70dc4a5f"/>
							<gml:surfaceMember xlink:href="#poly-3a9b63f3-1e7a-4c08-a8c1-29132bdbd952"/>
							<gml:surfaceMember xlink:href="#poly-6d15a4e7-804c-4fb1-b091-918e1c32199b"/>
							<gml:surfaceMember xlink:href="#poly-cd12f7de-e551-45e5-a09b-61c93dc299b2"/>
							<gml:surfaceMember xlink:href="#poly-143b9d42-233b-424a-8928-081b4e969370"/>
							<gml:surfaceMember xlink:href="#poly-2c8256ee-0caa-4f4b-8df2-e168d82b06ec"/>
							<gml:surfaceMember xlink:href="#poly-c8975630-94ce-4528-b678-82dfd71440d5"/>
							<gml:surfaceMember xlink:href="#poly-76294eee-208b-4231-a267-d84113671719"/>
							<gml:surfaceMember xlink:href="#poly-edd2cfa9-c263-4f6e-ba2c-72e691a4944e"/>
							<gml:surfaceMember xlink:href="#poly-8af85ab4-7318-4703-87d4-cde28eaabf56"/>
							<gml:surfaceMember xlink:href="#poly-dc6434c9-cec2-4c14-8ef0-858215a07fd8"/>
							<gml:surfaceMember xlink:href="#poly-2228db20-1d35-401d-8040-bfa531346eb3"/>
							<gml:surfaceMember xlink:href="#poly-57eade2f-1384-4723-8a89-ee262cdc187d"/>
							<gml:surfaceMember xlink:href="#poly-83691a45-9c4e-40b7-9a4a-fed398971dae"/>
							<gml:surfaceMember xlink:href="#poly-b1ef9ac1-9f98-4d33-afc2-43fec1b5f8e3"/>
							<gml:surfaceMember xlink:href="#poly-d57b3670-2e10-4ba4-955b-4d4f8f27d2cb"/>
							<gml:surfaceMember xlink:href="#poly-10f96790-9833-4152-ba88-ebe109044706"/>
							<gml:surfaceMember xlink:href="#poly-c8428c51-b5ea-4378-a722-60b9f84bbe3e"/>
							<gml:surfaceMember xlink:href="#poly-5a80feae-dcde-4eac-be57-4d8bbba97860"/>
							<gml:surfaceMember xlink:href="#poly-c0073830-2377-414a-9826-a3a2b6bdbe80"/>
							<gml:surfaceMember xlink:href="#poly-00844ce1-762e-408f-b42f-b478c183da17"/>
							<gml:surfaceMember xlink:href="#poly-0d9da6cc-fbe6-4da9-b1d2-5d5978d6434a"/>
							<gml:surfaceMember xlink:href="#poly-c82df2bf-1764-4921-b7a3-3cee160af7cd"/>
							<gml:surfaceMember xlink:href="#poly-bd15dc34-9078-4fc5-a5ad-2c6eb7f8e2e0"/>
							<gml:surfaceMember xlink:href="#poly-4061b0e0-2b23-4114-ad09-7104cdfca390"/>
							<gml:surfaceMember xlink:href="#poly-c28e00b6-4b1e-4633-aa7e-83d4cbf697d8"/>
							<gml:surfaceMember xlink:href="#poly-d2241f13-b68b-4cf4-9f4b-04d6063cf44c"/>
							<gml:surfaceMember xlink:href="#poly-4ef61675-7236-4542-a486-7cd03a3c7f22"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_95611643-0e5f-4243-a15c-4072def2f279_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16883b3f-a8fe-4890-8ad7-0ff8749b3b03">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66892459779036 139.73824010560543 37.535 35.6689332417447 139.73822841966867 37.535 35.66893993580805 139.7382358567737 37.535 35.66893128283927 139.73824754272133 37.535 35.66892459779036 139.73824010560543 37.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1664a3ea-c307-47a0-9175-fabb5f086fb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1664a3ea-c307-47a0-9175-fabb5f086fb8_0">
											<gml:posList>35.6689332417447 139.73822841966867 37.535 35.6689332417447 139.73822841966867 39.75 35.66893993580805 139.7382358567737 39.75 35.66893993580805 139.7382358567737 37.535 35.6689332417447 139.73822841966867 37.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80770c70-dbff-4df3-9dc6-28484d53b697">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80770c70-dbff-4df3-9dc6-28484d53b697_0">
											<gml:posList>35.66892459779036 139.73824010560543 37.535 35.66892459779036 139.73824010560543 39.75 35.6689332417447 139.73822841966867 39.75 35.6689332417447 139.73822841966867 37.535 35.66892459779036 139.73824010560543 37.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2738a1f-c50f-4e39-bea6-d65f98045327">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2738a1f-c50f-4e39-bea6-d65f98045327_0">
											<gml:posList>35.66893993580805 139.7382358567737 39.75 35.6689332417447 139.73822841966867 39.75 35.66892459779036 139.73824010560543 39.75 35.66893128283927 139.73824754272133 39.75 35.66893993580805 139.7382358567737 39.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdbdb807-292f-47c5-a268-d44fea633264">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdbdb807-292f-47c5-a268-d44fea633264_0">
											<gml:posList>35.66893993580805 139.7382358567737 37.535 35.66893993580805 139.7382358567737 39.75 35.66893128283927 139.73824754272133 39.75 35.66893128283927 139.73824754272133 37.535 35.66893993580805 139.7382358567737 37.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc626abf-3628-4b93-9098-bccb44ed7e9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc626abf-3628-4b93-9098-bccb44ed7e9f_0">
											<gml:posList>35.66893128283927 139.73824754272133 37.535 35.66893128283927 139.73824754272133 39.75 35.66892459779036 139.73824010560543 39.75 35.66892459779036 139.73824010560543 37.535 35.66893128283927 139.73824754272133 37.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_95611643-0e5f-4243-a15c-4072def2f279_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48c53ebc-472d-4b7b-af80-f2ac4ee84f5c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6689658353751 139.73825121322386 18.74 35.668977273586314 139.73826235618662 18.74 35.66895275894841 139.73830005232685 18.74 35.66895190198206 139.7382992138418 18.74 35.66894021117195 139.73828779502517 18.74 35.6689658353751 139.73825121322386 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7311ccfe-7855-4577-866c-54fa9096852b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668918918252785 139.73828465004664 18.74 35.66892682052663 139.73829256070346 18.74 35.66890584305227 139.7383236360321 18.74 35.668895884814525 139.73831466738937 18.74 35.668918918252785 139.73828465004664 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a10474f6-bb29-4352-96d4-f70ad2239823">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a10474f6-bb29-4352-96d4-f70ad2239823_0">
											<gml:posList>35.668894930344685 139.73831591672464 37.568 35.668895884814525 139.73831466738937 18.74 35.66890584305227 139.7383236360321 18.74 35.66890584475178 139.73832579001103 37.568 35.668894930344685 139.73831591672464 37.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b2c8126-b352-432d-9a90-5b422a68c57a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b2c8126-b352-432d-9a90-5b422a68c57a_0">
											<gml:posList>35.668918918252785 139.73828465004664 18.74 35.668895884814525 139.73831466738937 18.74 35.668894930344685 139.73831591672464 37.568 35.668918918252785 139.73828465004664 35.098 35.668918918252785 139.73828465004664 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d26760bc-d3a5-41b1-bd9a-309e738aa667">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d26760bc-d3a5-41b1-bd9a-309e738aa667_0">
											<gml:posList>35.66890584475178 139.73832579001103 37.568 35.66892761436209 139.73829335507878 35.098 35.668918918252785 139.73828465004664 35.098 35.668894930344685 139.73831591672464 37.568 35.66890584475178 139.73832579001103 37.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0e47c5e-6b45-455d-9cdf-311c42921ec5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0e47c5e-6b45-455d-9cdf-311c42921ec5_0">
											<gml:posList>35.66890584305227 139.7383236360321 18.74 35.66892682052663 139.73829256070346 18.74 35.66892761436209 139.73829335507878 35.098 35.66890584475178 139.73832579001103 37.568 35.66890584305227 139.7383236360321 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6bf63e6-9d61-46ad-b446-adb6722fe919">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6bf63e6-9d61-46ad-b446-adb6722fe919_0">
											<gml:posList>35.66892761436209 139.73829335507878 35.098 35.66892682052663 139.73829256070346 18.74 35.668918918252785 139.73828465004664 18.74 35.668918918252785 139.73828465004664 35.098 35.66892761436209 139.73829335507878 35.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4633fdae-f8cc-4f96-8756-cd4fbeb3458a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4633fdae-f8cc-4f96-8756-cd4fbeb3458a_0">
											<gml:posList>35.66895190198206 139.7382992138418 32.906 35.66894021117195 139.73828779502517 32.906 35.66894021117195 139.73828779502517 18.74 35.66895190198206 139.7382992138418 18.74 35.66895190198206 139.7382992138418 32.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0dfe14a6-3e21-4cdd-a8bd-3ef6670d0a37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0dfe14a6-3e21-4cdd-a8bd-3ef6670d0a37_0">
											<gml:posList>35.66895190198206 139.7382992138418 32.906 35.66895190198206 139.7382992138418 18.74 35.66895275894841 139.73830005232685 18.74 35.66895275894841 139.73830005232685 32.906 35.66895190198206 139.7382992138418 32.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abd73054-a449-425a-b78b-ff5f17eee774">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abd73054-a449-425a-b78b-ff5f17eee774_0">
											<gml:posList>35.66894021117195 139.73828779502517 18.74 35.66894021117195 139.73828779502517 32.906 35.6689658353751 139.73825121322386 32.906 35.6689658353751 139.73825121322386 18.74 35.66894021117195 139.73828779502517 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7fc6c59-e10e-49e0-b690-b2d0bd100275">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7fc6c59-e10e-49e0-b690-b2d0bd100275_0">
											<gml:posList>35.66895190198206 139.7382992138418 32.906 35.66895275894841 139.73830005232685 32.906 35.668977273586314 139.73826235618662 32.906 35.6689658353751 139.73825121322386 32.906 35.66894021117195 139.73828779502517 32.906 35.66895190198206 139.7382992138418 32.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-539500dc-3474-4b17-9fa1-16fb8f273b74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-539500dc-3474-4b17-9fa1-16fb8f273b74_0">
											<gml:posList>35.66895275894841 139.73830005232685 18.74 35.668977273586314 139.73826235618662 18.74 35.668977273586314 139.73826235618662 32.906 35.66895275894841 139.73830005232685 32.906 35.66895275894841 139.73830005232685 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36794435-d687-4402-a05e-1707f34d231a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36794435-d687-4402-a05e-1707f34d231a_0">
											<gml:posList>35.668977273586314 139.73826235618662 18.74 35.6689658353751 139.73825121322386 18.74 35.6689658353751 139.73825121322386 32.906 35.668977273586314 139.73826235618662 32.906 35.668977273586314 139.73826235618662 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3d76f01d-f0b6-4cca-a87b-afad67fd2fe4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d76f01d-f0b6-4cca-a87b-afad67fd2fe4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d76f01d-f0b6-4cca-a87b-afad67fd2fe4">
											<gml:posList>35.66890584475178 139.73832579001103 18.74 35.66892768653291 139.73829343231566 18.74 35.66895275894841 139.73830005232685 18.74 35.668909482437726 139.7383666008799 18.74 35.66890584475178 139.73832579001103 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-70cddd8f-e170-4403-ab2b-702f90d16662">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70cddd8f-e170-4403-ab2b-702f90d16662">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70cddd8f-e170-4403-ab2b-702f90d16662">
											<gml:posList>35.66888095912842 139.73833885384016 18.74 35.668895543757316 139.73831652353076 18.74 35.66890584475178 139.73832579001103 18.74 35.668909482437726 139.7383666008799 18.74 35.66888095912842 139.73833885384016 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f5cc3480-dcda-4e94-a0e3-cde395aab659">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5cc3480-dcda-4e94-a0e3-cde395aab659">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5cc3480-dcda-4e94-a0e3-cde395aab659">
											<gml:posList>35.668843636101336 139.73819402914467 18.74 35.66882460239205 139.73817538391305 18.74 35.66884917991291 139.7381374667995 18.74 35.66895367549788 139.73823935312603 18.74 35.66896583536638 139.7382512021778 18.74 35.668940166068445 139.7382877508944 18.74 35.66895275894841 139.73830005232685 18.74 35.66892768653291 139.73829343231566 18.74 35.668918918252785 139.73828465004664 18.74 35.668894930344685 139.73831591672464 18.74 35.66885803579166 139.73827995032406 18.74 35.6688724401352 139.73825762022412 18.74 35.668844025009 139.73822992833786 18.74 35.66884996682577 139.73822075307012 18.74 35.66883544356068 139.73820663135834 18.74 35.668843636101336 139.73819402914467 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b3413ae1-8a4b-41bb-9107-8c0fbbda9a45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3413ae1-8a4b-41bb-9107-8c0fbbda9a45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3413ae1-8a4b-41bb-9107-8c0fbbda9a45">
											<gml:posList>35.66889901017479 139.7381860544655 37.712 35.66884920697155 139.73813748885948 26.327 35.668824575333424 139.73817536185308 26.332 35.66884369022732 139.7381940843107 30.697 35.66889901017479 139.7381860544655 37.712</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-88f8b916-da4d-4aec-8a30-f5bc26a4988c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88f8b916-da4d-4aec-8a30-f5bc26a4988c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88f8b916-da4d-4aec-8a30-f5bc26a4988c">
											<gml:posList>35.6688724401352 139.73825762022412 37.707 35.66887387315167 139.73825740864993 37.707 35.66885873646918 139.738242669076 37.707 35.6688572583405 139.73824282547363 37.707 35.6688724401352 139.73825762022412 37.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2472d9de-12cc-41f0-93bb-bb16392e2852">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2472d9de-12cc-41f0-93bb-bb16392e2852">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2472d9de-12cc-41f0-93bb-bb16392e2852">
											<gml:posList>35.6688724401352 139.73825762022412 37.707 35.66885803579166 139.73827995032406 37.707 35.668859468808165 139.73827973875032 37.707 35.66887387315167 139.73825740864993 37.707 35.6688724401352 139.73825762022412 37.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-90588466-f628-4117-bd5c-ed685303833d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90588466-f628-4117-bd5c-ed685303833d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90588466-f628-4117-bd5c-ed685303833d">
											<gml:posList>35.66884369022732 139.7381940843107 30.697 35.66883541649333 139.73820659825233 30.704 35.66884999389311 139.73822078617616 34.075 35.66889901017479 139.7381860544655 37.712 35.66884369022732 139.7381940843107 30.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e4362b8a-4d5e-48cc-8e77-0abc4338d126">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4362b8a-4d5e-48cc-8e77-0abc4338d126">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4362b8a-4d5e-48cc-8e77-0abc4338d126">
											<gml:posList>35.66889901017479 139.7381860544655 37.712 35.668844025009 139.73822992833786 34.077 35.6688572583405 139.73824282547363 37.707 35.66889901017479 139.7381860544655 37.712</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c2fad1ce-fb30-403f-b6a4-73aa1ac3bc19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2fad1ce-fb30-403f-b6a4-73aa1ac3bc19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2fad1ce-fb30-403f-b6a4-73aa1ac3bc19">
											<gml:posList>35.66889901017479 139.7381860544655 37.712 35.66884999389311 139.73822078617616 34.075 35.668844025009 139.73822992833786 34.077 35.66889901017479 139.7381860544655 37.712</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-37c4b8df-bda8-4cc9-8682-e40b4fbd1745">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37c4b8df-bda8-4cc9-8682-e40b4fbd1745">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37c4b8df-bda8-4cc9-8682-e40b4fbd1745">
											<gml:posList>35.668894930344685 139.73831591672464 37.707 35.668894829860115 139.73831422679737 37.707 35.668859468808165 139.73827973875032 37.707 35.66885803579166 139.73827995032406 37.707 35.668894930344685 139.73831591672464 37.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50bb5838-5f72-4ed5-b39d-c98964b389bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50bb5838-5f72-4ed5-b39d-c98964b389bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50bb5838-5f72-4ed5-b39d-c98964b389bf">
											<gml:posList>35.6688572583405 139.73824282547363 37.707 35.66885873646918 139.738242669076 37.707 35.66889917380086 139.73818779954806 37.707 35.66889901017479 139.7381860544655 37.712 35.6688572583405 139.73824282547363 37.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-179420ce-8d11-4574-9455-7383775748ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-179420ce-8d11-4574-9455-7383775748ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-179420ce-8d11-4574-9455-7383775748ca">
											<gml:posList>35.66889917380086 139.73818779954806 37.535 35.66885873646918 139.738242669076 37.535 35.668887796254275 139.73824204917213 37.535 35.668914808635854 139.73820556514772 37.535 35.66889917380086 139.73818779954806 37.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a2b7cf89-d016-44e7-be18-f75bf39e5367">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2b7cf89-d016-44e7-be18-f75bf39e5367">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2b7cf89-d016-44e7-be18-f75bf39e5367">
											<gml:posList>35.66888095912842 139.73833885384016 34.579 35.668882401158754 139.73833864225674 34.579 35.66889572539153 139.73831824650003 34.579 35.668895543757316 139.73831652353076 34.579 35.66888095912842 139.73833885384016 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26e96075-e6d5-4bb6-929e-07722629487b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26e96075-e6d5-4bb6-929e-07722629487b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26e96075-e6d5-4bb6-929e-07722629487b">
											<gml:posList>35.668909482437726 139.7383666008799 34.579 35.6689093187881 139.73836482265864 34.579 35.668882401158754 139.73833864225674 34.579 35.66888095912842 139.73833885384016 34.579 35.668909482437726 139.7383666008799 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ce5a623-7583-48c8-a9c6-42f32bfa4d0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ce5a623-7583-48c8-a9c6-42f32bfa4d0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ce5a623-7583-48c8-a9c6-42f32bfa4d0a">
											<gml:posList>35.66890719280444 139.73826361016287 40.825 35.66890712832171 139.73826185391636 40.825 35.66888922937539 139.73824197015014 40.825 35.668887796254275 139.73824204917213 40.825 35.66890719280444 139.73826361016287 40.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ac4142a-2b31-4ca5-bbb4-31d50be73f59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ac4142a-2b31-4ca5-bbb4-31d50be73f59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ac4142a-2b31-4ca5-bbb4-31d50be73f59">
											<gml:posList>35.66890584475178 139.73832579001103 34.579 35.668895543757316 139.73831652353076 34.579 35.66889572539153 139.73831824650003 34.579 35.6689060173634 139.7383275019452 34.579 35.66890584475178 139.73832579001103 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-702498f9-e543-4fdd-80fb-443634657c06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-702498f9-e543-4fdd-80fb-443634657c06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-702498f9-e543-4fdd-80fb-443634657c06">
											<gml:posList>35.668887796254275 139.73824204917213 40.825 35.66888922937539 139.73824197015014 40.825 35.6689148731194 139.73820732139433 40.825 35.668914808635854 139.73820556514772 40.825 35.668887796254275 139.73824204917213 40.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7c4165b-2562-40d5-b5c5-a2d0e02d8c39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7c4165b-2562-40d5-b5c5-a2d0e02d8c39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7c4165b-2562-40d5-b5c5-a2d0e02d8c39">
											<gml:posList>35.668952179324336 139.73823948745323 37.535 35.66889917380086 139.73818779954806 37.535 35.668914808635854 139.73820556514772 37.535 35.66893420519246 139.73822712613688 37.535 35.66890719280444 139.73826361016287 37.535 35.668887796254275 139.73824204917213 37.535 35.66885873646918 139.738242669076 37.535 35.66887387315167 139.73825740864993 37.535 35.668859468808165 139.73827973875032 37.535 35.668894829860115 139.73831422679737 37.535 35.668952179324336 139.73823948745323 37.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-850a11ff-9329-4bf4-821b-90f0622558cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-850a11ff-9329-4bf4-821b-90f0622558cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-850a11ff-9329-4bf4-821b-90f0622558cc">
											<gml:posList>35.66893277208881 139.73822722725126 40.329 35.6689148731194 139.73820732139433 40.329 35.66888922937539 139.73824197015014 40.329 35.66890712832171 139.73826185391636 40.329 35.66893277208881 139.73822722725126 40.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c470e000-b5e1-49cb-920e-5c3b9ff75fd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c470e000-b5e1-49cb-920e-5c3b9ff75fd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c470e000-b5e1-49cb-920e-5c3b9ff75fd1">
											<gml:posList>35.66890584475178 139.73832579001103 34.579 35.6689060173634 139.7383275019452 34.579 35.66892912859803 139.73829326491548 34.579 35.66892768653291 139.73829343231566 34.579 35.66890584475178 139.73832579001103 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-76d18dad-a208-4914-abb8-b9e56ed0c57c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76d18dad-a208-4914-abb8-b9e56ed0c57c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76d18dad-a208-4914-abb8-b9e56ed0c57c">
											<gml:posList>35.66893420519246 139.73822712613688 40.825 35.66893277208881 139.73822722725126 40.825 35.66890712832171 139.73826185391636 40.825 35.66890719280444 139.73826361016287 40.825 35.66893420519246 139.73822712613688 40.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-31985237-0cd2-4819-be42-d754d0d05c84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31985237-0cd2-4819-be42-d754d0d05c84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31985237-0cd2-4819-be42-d754d0d05c84">
											<gml:posList>35.6689093187881 139.73836482265864 34.378 35.668951307895725 139.7383002528758 34.378 35.66893868794845 139.73828791833745 34.378 35.668964357255156 139.73825138066763 34.378 35.66895302718142 139.73824020444175 34.378 35.66891967462963 139.73828366605085 34.378 35.66892912859803 139.73829326491548 34.378 35.6689060173634 139.7383275019452 34.378 35.66889572539153 139.73831824650003 34.378 35.668882401158754 139.73833864225674 34.378 35.6689093187881 139.73836482265864 34.378</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d33dd5b1-4dd2-459f-bfdc-850c741f767c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d33dd5b1-4dd2-459f-bfdc-850c741f767c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d33dd5b1-4dd2-459f-bfdc-850c741f767c">
											<gml:posList>35.66891967462963 139.73828366605085 34.579 35.668918918252785 139.73828465004664 34.579 35.66892768653291 139.73829343231566 34.579 35.66892912859803 139.73829326491548 34.579 35.66891967462963 139.73828366605085 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b88a4924-e9ac-41ec-9857-cd72b5e81da9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b88a4924-e9ac-41ec-9857-cd72b5e81da9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b88a4924-e9ac-41ec-9857-cd72b5e81da9">
											<gml:posList>35.66895367549788 139.73823935312603 37.707 35.668952179324336 139.73823948745323 37.707 35.668894829860115 139.73831422679737 37.707 35.668894930344685 139.73831591672464 37.707 35.66895367549788 139.73823935312603 37.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-771c9a26-8111-4cee-86df-92f6ee5c18ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-771c9a26-8111-4cee-86df-92f6ee5c18ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-771c9a26-8111-4cee-86df-92f6ee5c18ff">
											<gml:posList>35.668914808635854 139.73820556514772 40.825 35.6689148731194 139.73820732139433 40.825 35.66893277208881 139.73822722725126 40.825 35.66893420519246 139.73822712613688 40.825 35.668914808635854 139.73820556514772 40.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-39957c55-01af-4155-961c-9db2ffbc0d90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39957c55-01af-4155-961c-9db2ffbc0d90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39957c55-01af-4155-961c-9db2ffbc0d90">
											<gml:posList>35.66889901017479 139.7381860544655 37.712 35.66889917380086 139.73818779954806 37.707 35.668952179324336 139.73823948745323 37.707 35.66895367549788 139.73823935312603 37.707 35.66889901017479 139.7381860544655 37.712</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-efa9adef-b5d3-4e8d-ba94-04e81ca77a0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efa9adef-b5d3-4e8d-ba94-04e81ca77a0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efa9adef-b5d3-4e8d-ba94-04e81ca77a0e">
											<gml:posList>35.66895275894841 139.73830005232685 34.579 35.668951307895725 139.7383002528758 34.579 35.6689093187881 139.73836482265864 34.579 35.668909482437726 139.7383666008799 34.579 35.66895275894841 139.73830005232685 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41d32f87-ef2e-4c5c-a573-add447a62a5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41d32f87-ef2e-4c5c-a573-add447a62a5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41d32f87-ef2e-4c5c-a573-add447a62a5b">
											<gml:posList>35.668940166068445 139.7382877508944 34.579 35.66893868794845 139.73828791833745 34.579 35.668951307895725 139.7383002528758 34.579 35.66895275894841 139.73830005232685 34.579 35.668940166068445 139.7382877508944 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-62d90289-851a-47fc-96a2-0436d4bd5fbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62d90289-851a-47fc-96a2-0436d4bd5fbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62d90289-851a-47fc-96a2-0436d4bd5fbc">
											<gml:posList>35.668940166068445 139.7382877508944 34.579 35.66896583536638 139.7382512021778 34.579 35.668964357255156 139.73825138066763 34.579 35.66893868794845 139.73828791833745 34.579 35.668940166068445 139.7382877508944 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35174951-83d2-495b-9cda-7ac0aec72e6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35174951-83d2-495b-9cda-7ac0aec72e6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35174951-83d2-495b-9cda-7ac0aec72e6f">
											<gml:posList>35.668964357255156 139.73825138066763 34.579 35.66896583536638 139.7382512021778 34.579 35.66895367549788 139.73823935312603 34.579 35.66895302718142 139.73824020444175 34.579 35.668964357255156 139.73825138066763 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0819b95-f06c-4bdb-bc60-f37b35fba82c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0819b95-f06c-4bdb-bc60-f37b35fba82c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0819b95-f06c-4bdb-bc60-f37b35fba82c">
											<gml:posList>35.66885873646918 139.738242669076 37.707 35.66885873646918 139.738242669076 37.535 35.66889917380086 139.73818779954806 37.535 35.66889917380086 139.73818779954806 37.707 35.66885873646918 139.738242669076 37.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a965a97-2119-4945-bfcd-c00db983534e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a965a97-2119-4945-bfcd-c00db983534e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a965a97-2119-4945-bfcd-c00db983534e">
											<gml:posList>35.66888922937539 139.73824197015014 40.825 35.66888922937539 139.73824197015014 40.329 35.6689148731194 139.73820732139433 40.329 35.6689148731194 139.73820732139433 40.825 35.66888922937539 139.73824197015014 40.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ffa4928-5955-424c-8c5d-7038045a6f94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ffa4928-5955-424c-8c5d-7038045a6f94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ffa4928-5955-424c-8c5d-7038045a6f94">
											<gml:posList>35.66893277208881 139.73822722725126 40.825 35.66893277208881 139.73822722725126 40.329 35.66890712832171 139.73826185391636 40.329 35.66890712832171 139.73826185391636 40.825 35.66893277208881 139.73822722725126 40.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3361c50d-f91c-4101-879e-3a150f9bb5d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3361c50d-f91c-4101-879e-3a150f9bb5d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3361c50d-f91c-4101-879e-3a150f9bb5d6">
											<gml:posList>35.6689060173634 139.7383275019452 34.579 35.6689060173634 139.7383275019452 34.378 35.66892912859803 139.73829326491548 34.378 35.66892912859803 139.73829326491548 34.579 35.6689060173634 139.7383275019452 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6624833c-f2eb-4ee3-8a7f-8c9442ec43c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6624833c-f2eb-4ee3-8a7f-8c9442ec43c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6624833c-f2eb-4ee3-8a7f-8c9442ec43c9">
											<gml:posList>35.66884917991291 139.7381374667995 18.74 35.66882460239205 139.73817538391305 18.74 35.668824575333424 139.73817536185308 26.332 35.66884920697155 139.73813748885948 26.327 35.66884917991291 139.7381374667995 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53bd5121-d4aa-4211-bd04-579a5b7374f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53bd5121-d4aa-4211-bd04-579a5b7374f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53bd5121-d4aa-4211-bd04-579a5b7374f6">
											<gml:posList>35.668824575333424 139.73817536185308 26.332 35.66882460239205 139.73817538391305 18.74 35.668843636101336 139.73819402914467 18.74 35.66884369022732 139.7381940843107 30.697 35.668824575333424 139.73817536185308 26.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a4efbd4-0ac4-4d12-98da-13bf078d63a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a4efbd4-0ac4-4d12-98da-13bf078d63a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a4efbd4-0ac4-4d12-98da-13bf078d63a2">
											<gml:posList>35.66884917991291 139.7381374667995 18.74 35.66884920697155 139.73813748885948 26.327 35.66889901017479 139.7381860544655 37.712 35.66895367549788 139.73823935312603 37.707 35.66895367549788 139.73823935312603 34.579 35.66895367549788 139.73823935312603 18.74 35.66884917991291 139.7381374667995 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebf571b2-e748-40d5-b880-744095e5d113">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebf571b2-e748-40d5-b880-744095e5d113">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebf571b2-e748-40d5-b880-744095e5d113">
											<gml:posList>35.668843636101336 139.73819402914467 18.74 35.66883544356068 139.73820663135834 18.74 35.66883541649333 139.73820659825233 30.704 35.66884369022732 139.7381940843107 30.697 35.668843636101336 139.73819402914467 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7d6392c-8a29-41e0-b240-f1394cee2b66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7d6392c-8a29-41e0-b240-f1394cee2b66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7d6392c-8a29-41e0-b240-f1394cee2b66">
											<gml:posList>35.66883541649333 139.73820659825233 30.704 35.66883544356068 139.73820663135834 18.74 35.66884996682577 139.73822075307012 18.74 35.66884999389311 139.73822078617616 34.075 35.66883541649333 139.73820659825233 30.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a10c8a3a-e237-4384-84b1-295c4d3c61e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a10c8a3a-e237-4384-84b1-295c4d3c61e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a10c8a3a-e237-4384-84b1-295c4d3c61e1">
											<gml:posList>35.66889917380086 139.73818779954806 37.707 35.66889917380086 139.73818779954806 37.535 35.668952179324336 139.73823948745323 37.535 35.668952179324336 139.73823948745323 37.707 35.66889917380086 139.73818779954806 37.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ddd0acd6-d5f8-42bd-bf28-eddc87157038">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ddd0acd6-d5f8-42bd-bf28-eddc87157038">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ddd0acd6-d5f8-42bd-bf28-eddc87157038">
											<gml:posList>35.668914808635854 139.73820556514772 37.535 35.668914808635854 139.73820556514772 40.825 35.66893420519246 139.73822712613688 40.825 35.66893420519246 139.73822712613688 37.535 35.668914808635854 139.73820556514772 37.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-473324cd-f731-436d-8920-b16e57530857">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-473324cd-f731-436d-8920-b16e57530857">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-473324cd-f731-436d-8920-b16e57530857">
											<gml:posList>35.6689148731194 139.73820732139433 40.825 35.6689148731194 139.73820732139433 40.329 35.66893277208881 139.73822722725126 40.329 35.66893277208881 139.73822722725126 40.825 35.6689148731194 139.73820732139433 40.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ce2c6ff-19ae-4dd9-b5e3-36ee8da09718">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ce2c6ff-19ae-4dd9-b5e3-36ee8da09718">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ce2c6ff-19ae-4dd9-b5e3-36ee8da09718">
											<gml:posList>35.668887796254275 139.73824204917213 37.535 35.668887796254275 139.73824204917213 40.825 35.668914808635854 139.73820556514772 40.825 35.668914808635854 139.73820556514772 37.535 35.668887796254275 139.73824204917213 37.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea908fca-b780-40fe-aab0-36df00028388">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea908fca-b780-40fe-aab0-36df00028388">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea908fca-b780-40fe-aab0-36df00028388">
											<gml:posList>35.66884996682577 139.73822075307012 18.74 35.668844025009 139.73822992833786 18.74 35.668844025009 139.73822992833786 34.077 35.66884999389311 139.73822078617616 34.075 35.66884996682577 139.73822075307012 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b062de30-5a18-4e71-84ae-5c1e70dc4a5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b062de30-5a18-4e71-84ae-5c1e70dc4a5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b062de30-5a18-4e71-84ae-5c1e70dc4a5f">
											<gml:posList>35.668844025009 139.73822992833786 34.077 35.668844025009 139.73822992833786 18.74 35.6688724401352 139.73825762022412 18.74 35.6688724401352 139.73825762022412 37.707 35.6688572583405 139.73824282547363 37.707 35.668844025009 139.73822992833786 34.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a9b63f3-1e7a-4c08-a8c1-29132bdbd952">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a9b63f3-1e7a-4c08-a8c1-29132bdbd952">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a9b63f3-1e7a-4c08-a8c1-29132bdbd952">
											<gml:posList>35.66896583536638 139.7382512021778 18.74 35.66895367549788 139.73823935312603 18.74 35.66895367549788 139.73823935312603 34.579 35.66896583536638 139.7382512021778 34.579 35.66896583536638 139.7382512021778 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d15a4e7-804c-4fb1-b091-918e1c32199b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d15a4e7-804c-4fb1-b091-918e1c32199b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d15a4e7-804c-4fb1-b091-918e1c32199b">
											<gml:posList>35.66893420519246 139.73822712613688 37.535 35.66893420519246 139.73822712613688 40.825 35.66890719280444 139.73826361016287 40.825 35.66890719280444 139.73826361016287 37.535 35.66893420519246 139.73822712613688 37.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd12f7de-e551-45e5-a09b-61c93dc299b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd12f7de-e551-45e5-a09b-61c93dc299b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd12f7de-e551-45e5-a09b-61c93dc299b2">
											<gml:posList>35.66895302718142 139.73824020444175 34.579 35.66895302718142 139.73824020444175 34.378 35.668964357255156 139.73825138066763 34.378 35.668964357255156 139.73825138066763 34.579 35.66895302718142 139.73824020444175 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-143b9d42-233b-424a-8928-081b4e969370">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-143b9d42-233b-424a-8928-081b4e969370">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-143b9d42-233b-424a-8928-081b4e969370">
											<gml:posList>35.66887387315167 139.73825740864993 37.707 35.66887387315167 139.73825740864993 37.535 35.66885873646918 139.738242669076 37.535 35.66885873646918 139.738242669076 37.707 35.66887387315167 139.73825740864993 37.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c8256ee-0caa-4f4b-8df2-e168d82b06ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c8256ee-0caa-4f4b-8df2-e168d82b06ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c8256ee-0caa-4f4b-8df2-e168d82b06ec">
											<gml:posList>35.66890712832171 139.73826185391636 40.825 35.66890712832171 139.73826185391636 40.329 35.66888922937539 139.73824197015014 40.329 35.66888922937539 139.73824197015014 40.825 35.66890712832171 139.73826185391636 40.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8975630-94ce-4528-b678-82dfd71440d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8975630-94ce-4528-b678-82dfd71440d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8975630-94ce-4528-b678-82dfd71440d5">
											<gml:posList>35.66890719280444 139.73826361016287 37.535 35.66890719280444 139.73826361016287 40.825 35.668887796254275 139.73824204917213 40.825 35.668887796254275 139.73824204917213 37.535 35.66890719280444 139.73826361016287 37.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76294eee-208b-4231-a267-d84113671719">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76294eee-208b-4231-a267-d84113671719">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76294eee-208b-4231-a267-d84113671719">
											<gml:posList>35.668859468808165 139.73827973875032 37.707 35.668859468808165 139.73827973875032 37.535 35.66887387315167 139.73825740864993 37.535 35.66887387315167 139.73825740864993 37.707 35.668859468808165 139.73827973875032 37.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edd2cfa9-c263-4f6e-ba2c-72e691a4944e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edd2cfa9-c263-4f6e-ba2c-72e691a4944e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edd2cfa9-c263-4f6e-ba2c-72e691a4944e">
											<gml:posList>35.6688724401352 139.73825762022412 18.74 35.66885803579166 139.73827995032406 18.74 35.66885803579166 139.73827995032406 37.707 35.6688724401352 139.73825762022412 37.707 35.6688724401352 139.73825762022412 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8af85ab4-7318-4703-87d4-cde28eaabf56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8af85ab4-7318-4703-87d4-cde28eaabf56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8af85ab4-7318-4703-87d4-cde28eaabf56">
											<gml:posList>35.668940166068445 139.7382877508944 18.74 35.66896583536638 139.7382512021778 18.74 35.66896583536638 139.7382512021778 34.579 35.668940166068445 139.7382877508944 34.579 35.668940166068445 139.7382877508944 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc6434c9-cec2-4c14-8ef0-858215a07fd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc6434c9-cec2-4c14-8ef0-858215a07fd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc6434c9-cec2-4c14-8ef0-858215a07fd8">
											<gml:posList>35.668964357255156 139.73825138066763 34.579 35.668964357255156 139.73825138066763 34.378 35.66893868794845 139.73828791833745 34.378 35.66893868794845 139.73828791833745 34.579 35.668964357255156 139.73825138066763 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2228db20-1d35-401d-8040-bfa531346eb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2228db20-1d35-401d-8040-bfa531346eb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2228db20-1d35-401d-8040-bfa531346eb3">
											<gml:posList>35.668952179324336 139.73823948745323 37.707 35.668952179324336 139.73823948745323 37.535 35.668894829860115 139.73831422679737 37.535 35.668894829860115 139.73831422679737 37.707 35.668952179324336 139.73823948745323 37.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57eade2f-1384-4723-8a89-ee262cdc187d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57eade2f-1384-4723-8a89-ee262cdc187d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57eade2f-1384-4723-8a89-ee262cdc187d">
											<gml:posList>35.66891967462963 139.73828366605085 34.579 35.66891967462963 139.73828366605085 34.378 35.66895302718142 139.73824020444175 34.378 35.66895302718142 139.73824020444175 34.579 35.66895367549788 139.73823935312603 34.579 35.66895367549788 139.73823935312603 37.707 35.668894930344685 139.73831591672464 37.707 35.668894930344685 139.73831591672464 18.74 35.668918918252785 139.73828465004664 18.74 35.668918918252785 139.73828465004664 34.579 35.66891967462963 139.73828366605085 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83691a45-9c4e-40b7-9a4a-fed398971dae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83691a45-9c4e-40b7-9a4a-fed398971dae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83691a45-9c4e-40b7-9a4a-fed398971dae">
											<gml:posList>35.66892912859803 139.73829326491548 34.579 35.66892912859803 139.73829326491548 34.378 35.66891967462963 139.73828366605085 34.378 35.66891967462963 139.73828366605085 34.579 35.66892912859803 139.73829326491548 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1ef9ac1-9f98-4d33-afc2-43fec1b5f8e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1ef9ac1-9f98-4d33-afc2-43fec1b5f8e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1ef9ac1-9f98-4d33-afc2-43fec1b5f8e3">
											<gml:posList>35.668918918252785 139.73828465004664 18.74 35.66892768653291 139.73829343231566 18.74 35.66892768653291 139.73829343231566 34.579 35.668918918252785 139.73828465004664 34.579 35.668918918252785 139.73828465004664 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d57b3670-2e10-4ba4-955b-4d4f8f27d2cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d57b3670-2e10-4ba4-955b-4d4f8f27d2cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d57b3670-2e10-4ba4-955b-4d4f8f27d2cb">
											<gml:posList>35.66895275894841 139.73830005232685 18.74 35.668940166068445 139.7382877508944 18.74 35.668940166068445 139.7382877508944 34.579 35.66895275894841 139.73830005232685 34.579 35.66895275894841 139.73830005232685 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10f96790-9833-4152-ba88-ebe109044706">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10f96790-9833-4152-ba88-ebe109044706">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10f96790-9833-4152-ba88-ebe109044706">
											<gml:posList>35.66893868794845 139.73828791833745 34.579 35.66893868794845 139.73828791833745 34.378 35.668951307895725 139.7383002528758 34.378 35.668951307895725 139.7383002528758 34.579 35.66893868794845 139.73828791833745 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8428c51-b5ea-4378-a722-60b9f84bbe3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8428c51-b5ea-4378-a722-60b9f84bbe3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8428c51-b5ea-4378-a722-60b9f84bbe3e">
											<gml:posList>35.668894829860115 139.73831422679737 37.707 35.668894829860115 139.73831422679737 37.535 35.668859468808165 139.73827973875032 37.535 35.668859468808165 139.73827973875032 37.707 35.668894829860115 139.73831422679737 37.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a80feae-dcde-4eac-be57-4d8bbba97860">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a80feae-dcde-4eac-be57-4d8bbba97860">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a80feae-dcde-4eac-be57-4d8bbba97860">
											<gml:posList>35.668894930344685 139.73831591672464 37.707 35.66885803579166 139.73827995032406 37.707 35.66885803579166 139.73827995032406 18.74 35.668894930344685 139.73831591672464 18.74 35.668894930344685 139.73831591672464 37.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0073830-2377-414a-9826-a3a2b6bdbe80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0073830-2377-414a-9826-a3a2b6bdbe80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0073830-2377-414a-9826-a3a2b6bdbe80">
											<gml:posList>35.66892768653291 139.73829343231566 18.74 35.66890584475178 139.73832579001103 18.74 35.66890584475178 139.73832579001103 34.579 35.66892768653291 139.73829343231566 34.579 35.66892768653291 139.73829343231566 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00844ce1-762e-408f-b42f-b478c183da17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00844ce1-762e-408f-b42f-b478c183da17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00844ce1-762e-408f-b42f-b478c183da17">
											<gml:posList>35.66890584475178 139.73832579001103 18.74 35.668895543757316 139.73831652353076 18.74 35.668895543757316 139.73831652353076 34.579 35.66890584475178 139.73832579001103 34.579 35.66890584475178 139.73832579001103 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d9da6cc-fbe6-4da9-b1d2-5d5978d6434a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d9da6cc-fbe6-4da9-b1d2-5d5978d6434a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d9da6cc-fbe6-4da9-b1d2-5d5978d6434a">
											<gml:posList>35.66889572539153 139.73831824650003 34.579 35.66889572539153 139.73831824650003 34.378 35.6689060173634 139.7383275019452 34.378 35.6689060173634 139.7383275019452 34.579 35.66889572539153 139.73831824650003 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c82df2bf-1764-4921-b7a3-3cee160af7cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c82df2bf-1764-4921-b7a3-3cee160af7cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c82df2bf-1764-4921-b7a3-3cee160af7cd">
											<gml:posList>35.668895543757316 139.73831652353076 18.74 35.66888095912842 139.73833885384016 18.74 35.66888095912842 139.73833885384016 34.579 35.668895543757316 139.73831652353076 34.579 35.668895543757316 139.73831652353076 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd15dc34-9078-4fc5-a5ad-2c6eb7f8e2e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd15dc34-9078-4fc5-a5ad-2c6eb7f8e2e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd15dc34-9078-4fc5-a5ad-2c6eb7f8e2e0">
											<gml:posList>35.668882401158754 139.73833864225674 34.579 35.668882401158754 139.73833864225674 34.378 35.66889572539153 139.73831824650003 34.378 35.66889572539153 139.73831824650003 34.579 35.668882401158754 139.73833864225674 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4061b0e0-2b23-4114-ad09-7104cdfca390">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4061b0e0-2b23-4114-ad09-7104cdfca390">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4061b0e0-2b23-4114-ad09-7104cdfca390">
											<gml:posList>35.668951307895725 139.7383002528758 34.579 35.668951307895725 139.7383002528758 34.378 35.6689093187881 139.73836482265864 34.378 35.6689093187881 139.73836482265864 34.579 35.668951307895725 139.7383002528758 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c28e00b6-4b1e-4633-aa7e-83d4cbf697d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c28e00b6-4b1e-4633-aa7e-83d4cbf697d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c28e00b6-4b1e-4633-aa7e-83d4cbf697d8">
											<gml:posList>35.668909482437726 139.7383666008799 18.74 35.66895275894841 139.73830005232685 18.74 35.66895275894841 139.73830005232685 34.579 35.668909482437726 139.7383666008799 34.579 35.668909482437726 139.7383666008799 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2241f13-b68b-4cf4-9f4b-04d6063cf44c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2241f13-b68b-4cf4-9f4b-04d6063cf44c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2241f13-b68b-4cf4-9f4b-04d6063cf44c">
											<gml:posList>35.6689093187881 139.73836482265864 34.579 35.6689093187881 139.73836482265864 34.378 35.668882401158754 139.73833864225674 34.378 35.668882401158754 139.73833864225674 34.579 35.6689093187881 139.73836482265864 34.579</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ef61675-7236-4542-a486-7cd03a3c7f22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ef61675-7236-4542-a486-7cd03a3c7f22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ef61675-7236-4542-a486-7cd03a3c7f22">
											<gml:posList>35.66888095912842 139.73833885384016 18.74 35.668909482437726 139.7383666008799 18.74 35.668909482437726 139.7383666008799 34.579 35.66888095912842 139.73833885384016 34.579 35.66888095912842 139.73833885384016 18.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11189</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">151.17026</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>