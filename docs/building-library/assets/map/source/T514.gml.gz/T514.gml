<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_95b67360-12f8-4399-9a66-935661dd1dff">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">29.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668609283862324 139.74976218827527 0 35.66862731978221 139.74970493106656 0 35.66853696604867 139.749661875513 0 35.66847853741952 139.74984619126343 0 35.66876555993398 139.7499829405397 0 35.6687899388464 139.7499527933738 0 35.668818700108545 139.7498619166819 0 35.668609283862324 139.74976218827527 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668609283862324 139.74976218827527 5.21 35.668818700108545 139.7498619166819 5.21 35.6687899388464 139.7499527933738 5.21 35.66876555993398 139.7499829405397 5.21 35.66847853741952 139.74984619126343 5.21 35.66853696604867 139.749661875513 5.21 35.66862731978221 139.74970493106656 5.21 35.668609283862324 139.74976218827527 5.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668609283862324 139.74976218827527 5.21 35.66862731978221 139.74970493106656 5.21 35.66862731978221 139.74970493106656 34.3 35.668609283862324 139.74976218827527 34.3 35.668609283862324 139.74976218827527 5.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862731978221 139.74970493106656 5.21 35.66853696604867 139.749661875513 5.21 35.66853696604867 139.749661875513 34.3 35.66862731978221 139.74970493106656 34.3 35.66862731978221 139.74970493106656 5.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66853696604867 139.749661875513 5.21 35.66847853741952 139.74984619126343 5.21 35.66847853741952 139.74984619126343 34.3 35.66853696604867 139.749661875513 34.3 35.66853696604867 139.749661875513 5.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66847853741952 139.74984619126343 5.21 35.66876555993398 139.7499829405397 5.21 35.66876555993398 139.7499829405397 34.3 35.66847853741952 139.74984619126343 34.3 35.66847853741952 139.74984619126343 5.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66876555993398 139.7499829405397 5.21 35.6687899388464 139.7499527933738 5.21 35.6687899388464 139.7499527933738 34.3 35.66876555993398 139.7499829405397 34.3 35.66876555993398 139.7499829405397 5.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6687899388464 139.7499527933738 5.21 35.668818700108545 139.7498619166819 5.21 35.668818700108545 139.7498619166819 34.3 35.6687899388464 139.7499527933738 34.3 35.6687899388464 139.7499527933738 5.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668818700108545 139.7498619166819 5.21 35.668609283862324 139.74976218827527 5.21 35.668609283862324 139.74976218827527 34.3 35.668818700108545 139.7498619166819 34.3 35.668818700108545 139.7498619166819 5.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668609283862324 139.74976218827527 34.3 35.66862731978221 139.74970493106656 34.3 35.66853696604867 139.749661875513 34.3 35.66847853741952 139.74984619126343 34.3 35.66876555993398 139.7499829405397 34.3 35.6687899388464 139.7499527933738 34.3 35.668818700108545 139.7498619166819 34.3 35.668609283862324 139.74976218827527 34.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fc82812d-9115-4829-993f-78b88d67054e"/>
							<gml:surfaceMember xlink:href="#poly-1019f7da-afce-4cee-bcdf-dd1746e0ef7e"/>
							<gml:surfaceMember xlink:href="#poly-559b7c4a-3948-401c-b0c1-798975eaf139"/>
							<gml:surfaceMember xlink:href="#poly-2e4c2e18-46b5-4fc8-b713-40b578cd380f"/>
							<gml:surfaceMember xlink:href="#poly-3996a1ca-4257-4aa9-b995-ba22c194ee19"/>
							<gml:surfaceMember xlink:href="#poly-2cbb284b-0f47-4624-9d54-889e2504c0ae"/>
							<gml:surfaceMember xlink:href="#poly-5ad69f78-929b-4b52-b839-1ffb9cf2c914"/>
							<gml:surfaceMember xlink:href="#poly-20c20b8a-489f-44e9-8b32-89826b108c17"/>
							<gml:surfaceMember xlink:href="#poly-61eebee8-0f98-402f-950f-ada1214d36c8"/>
							<gml:surfaceMember xlink:href="#poly-ef13f1da-7e18-4363-9666-8e7d0468c801"/>
							<gml:surfaceMember xlink:href="#poly-f5c7ae42-d252-4c1d-9567-02f9a27c784e"/>
							<gml:surfaceMember xlink:href="#poly-b3f1b5b2-99a1-48e7-a9df-c88e0a2ac2b7"/>
							<gml:surfaceMember xlink:href="#poly-d97b22c2-c45c-4393-b7e4-9c91f461854d"/>
							<gml:surfaceMember xlink:href="#poly-19b0b07c-40c5-4a26-8fa9-c186ad944b63"/>
							<gml:surfaceMember xlink:href="#poly-69fe45b9-1aad-45cb-9fad-c9234af8f735"/>
							<gml:surfaceMember xlink:href="#poly-4d731ac8-2ef0-4fb7-ab95-a7bdf3132a74"/>
							<gml:surfaceMember xlink:href="#poly-1ea6597f-5205-4241-bc96-889fd77106c0"/>
							<gml:surfaceMember xlink:href="#poly-2c20a205-fdb4-4173-b1a2-9a216d28b0a7"/>
							<gml:surfaceMember xlink:href="#poly-8372a5b3-23ec-4207-9e82-d32996979ea5"/>
							<gml:surfaceMember xlink:href="#poly-0e8ea3e7-3f06-4a46-aa06-04e638038ffc"/>
							<gml:surfaceMember xlink:href="#poly-df2315da-9e00-4857-ac2e-d0ec24e9203a"/>
							<gml:surfaceMember xlink:href="#poly-fba3cb5b-4472-4de0-ac4b-db7973c58dc0"/>
							<gml:surfaceMember xlink:href="#poly-4f3d3e1f-eecb-4bb0-92fe-e09f551c33f3"/>
							<gml:surfaceMember xlink:href="#poly-8105570b-c028-4c65-97ef-f35d27da2ac1"/>
							<gml:surfaceMember xlink:href="#poly-ebdd99d4-41bf-4122-94b7-b55a1750911d"/>
							<gml:surfaceMember xlink:href="#poly-7bcf435e-659d-4fed-b472-9683fcf85cbc"/>
							<gml:surfaceMember xlink:href="#poly-3acf38c7-5461-45fa-9677-6964c59b87f6"/>
							<gml:surfaceMember xlink:href="#poly-4321070b-7cde-4e65-b1ec-56e5e29af791"/>
							<gml:surfaceMember xlink:href="#poly-88c4aabe-af13-46b9-850e-fe1677076825"/>
							<gml:surfaceMember xlink:href="#poly-0e9581fd-fb86-4aac-8a93-2f16bf7afdb8"/>
							<gml:surfaceMember xlink:href="#poly-66c9c75d-6605-46d5-b919-f5101488b978"/>
							<gml:surfaceMember xlink:href="#poly-9dde081b-666e-407b-bcef-5abc5ef7a6be"/>
							<gml:surfaceMember xlink:href="#poly-23f50a9f-275a-4c9a-b7e5-6e1f1453c9a7"/>
							<gml:surfaceMember xlink:href="#poly-1ece4db8-1690-4222-82d5-506d7d603351"/>
							<gml:surfaceMember xlink:href="#poly-df4c6cd4-0913-433d-a127-72af68c6067c"/>
							<gml:surfaceMember xlink:href="#poly-6e8d08e8-b0a6-4908-a145-1219db4145f9"/>
							<gml:surfaceMember xlink:href="#poly-7d7fa184-314f-4ba5-8c63-0f6d9adeb5f1"/>
							<gml:surfaceMember xlink:href="#poly-bc6894b3-6263-4574-9957-90cce30ded2a"/>
							<gml:surfaceMember xlink:href="#poly-0e0957ac-6710-4d17-a846-3d48dbc50dac"/>
							<gml:surfaceMember xlink:href="#poly-5dc3d500-0ff4-4431-9e6b-961ce61348d9"/>
							<gml:surfaceMember xlink:href="#poly-524242e8-0cee-45b8-bb83-227573846aed"/>
							<gml:surfaceMember xlink:href="#poly-4ce07657-69bb-4a5d-9c2d-fc572311699f"/>
							<gml:surfaceMember xlink:href="#poly-03927c0d-6eeb-4155-b44f-6de40279f52c"/>
							<gml:surfaceMember xlink:href="#poly-1d9a00f3-1eca-4682-8bce-c2c408126ddf"/>
							<gml:surfaceMember xlink:href="#poly-3028d576-3513-43ca-935b-1e4f2e0ad9b9"/>
							<gml:surfaceMember xlink:href="#poly-1868b2a0-a7e7-4732-8e85-a6284ec88ea5"/>
							<gml:surfaceMember xlink:href="#poly-64e88694-dfe1-418b-ae12-f30c0b4aabef"/>
							<gml:surfaceMember xlink:href="#poly-dd2064ca-14ff-4df3-ae15-5404d6171b4a"/>
							<gml:surfaceMember xlink:href="#poly-c0a04d7d-9c89-4b65-8f26-a01e5a20f720"/>
							<gml:surfaceMember xlink:href="#poly-e95710a1-b189-4c42-8fea-90559d2de159"/>
							<gml:surfaceMember xlink:href="#poly-2aa53994-4d35-42dd-8547-6a744ee2673e"/>
							<gml:surfaceMember xlink:href="#poly-83e82a56-ebc1-4732-819d-11f9c530dc32"/>
							<gml:surfaceMember xlink:href="#poly-4dc204b8-b51d-4e85-88d6-1bccef8e1dd3"/>
							<gml:surfaceMember xlink:href="#poly-3e6933b2-038e-4aa8-a89b-984f52dbf66b"/>
							<gml:surfaceMember xlink:href="#poly-6a4bc6dc-2a17-4646-9721-fdbef9cde528"/>
							<gml:surfaceMember xlink:href="#poly-fcd056ca-cf59-48ff-8297-39e8553e8c46"/>
							<gml:surfaceMember xlink:href="#poly-b17cfc8a-21ae-4699-a5db-0fb18672bda3"/>
							<gml:surfaceMember xlink:href="#poly-558e286d-d358-4234-88df-10da973246b5"/>
							<gml:surfaceMember xlink:href="#poly-0e28c811-2eeb-4343-8605-fff9a6763928"/>
							<gml:surfaceMember xlink:href="#poly-cc036b8b-08c7-4502-a36e-d36a549d504f"/>
							<gml:surfaceMember xlink:href="#poly-f651e46b-3de6-45ab-ab51-97ab76fab78b"/>
							<gml:surfaceMember xlink:href="#poly-677aba57-50e5-4d20-b5e8-3e56500965ed"/>
							<gml:surfaceMember xlink:href="#poly-d1d99ee8-48f6-492d-963a-e5a4f6735013"/>
							<gml:surfaceMember xlink:href="#poly-62486e69-dec2-456a-afd3-3428d9e7af28"/>
							<gml:surfaceMember xlink:href="#poly-4a793e04-6ba8-426e-af47-848f418f9135"/>
							<gml:surfaceMember xlink:href="#poly-682152c5-eff7-4451-8084-9e5352396a64"/>
							<gml:surfaceMember xlink:href="#poly-f96b5d60-95be-49b6-8771-c857839b16f2"/>
							<gml:surfaceMember xlink:href="#poly-a8f1602a-23f8-47d3-b450-712ffbaa237a"/>
							<gml:surfaceMember xlink:href="#poly-451ecbd8-2117-464f-bdea-fc36df1e8d1b"/>
							<gml:surfaceMember xlink:href="#poly-684b36f5-dbf7-46a5-a4b3-f4641e1ec4ee"/>
							<gml:surfaceMember xlink:href="#poly-ea2a2bd3-f4f6-4b33-84ba-fa9eead4f464"/>
							<gml:surfaceMember xlink:href="#poly-4b900bda-2ddb-4f74-ac1d-f6691ac76954"/>
							<gml:surfaceMember xlink:href="#poly-17b135cb-09e5-4d20-9634-2c393454894a"/>
							<gml:surfaceMember xlink:href="#poly-1cfa42fb-f0f1-4f6a-a449-671f815ad678"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_95b67360-12f8-4399-9a66-935661dd1dff_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0de1e42f-d6be-49cf-a24f-25906befcb32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858400685964 139.74974801321528 34.315 35.66859246118236 139.74972123991017 34.315 35.668615571012644 139.74973222869116 34.315 35.668607116687525 139.74975900200283 34.315 35.66858400685964 139.74974801321528 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74d226b2-5794-4592-b573-8ad5a2079064">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66861780716097 139.74973329782338 34.7 35.66860935283561 139.74976007113568 34.7 35.668607116687525 139.74975900200283 34.7 35.668615571012644 139.74973222869116 34.7 35.66861780716097 139.74973329782338 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0045d5f5-0885-4a0d-8a74-cb0316e133fd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854158222602 139.74975235433683 34.315 35.66856190557756 139.74976156761645 34.315 35.66855349708082 139.7497894454602 34.315 35.668533164717644 139.7497802321839 34.315 35.66854158222602 139.74975235433683 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5c7e2fb-3fe5-422a-87a8-60b402b2f2b4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66859381058719 139.74976935494107 34.315 35.668610491693826 139.74977756683884 34.315 35.668602765263756 139.74980115813332 34.315 35.668586084166364 139.7497929572774 34.315 35.66859381058719 139.74976935494107 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df66db27-6d89-45a5-8069-e0c21648770f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668603621917086 139.74981465547194 34.315 35.66859568992558 139.7498407875582 34.315 35.66854297897461 139.74981676214907 34.315 35.668550910960974 139.74979063007763 34.315 35.668603621917086 139.74981465547194 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03eea887-4c44-44b3-976b-5601a8ff33c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03eea887-4c44-44b3-976b-5601a8ff33c9_0">
											<gml:posList>35.668533164717644 139.7497802321839 34.315 35.668533164717644 139.7497802321839 37.104 35.66854158222602 139.74975235433683 37.104 35.66854158222602 139.74975235433683 34.315 35.668533164717644 139.7497802321839 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-257803f7-7689-4263-8562-c256edaec304">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-257803f7-7689-4263-8562-c256edaec304_0">
											<gml:posList>35.668533164717644 139.7497802321839 34.315 35.66855349708082 139.7497894454602 34.315 35.66855349708082 139.7497894454602 37.104 35.668533164717644 139.7497802321839 37.104 35.668533164717644 139.7497802321839 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54f93b4d-80b9-4007-bffd-cde361d64f14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54f93b4d-80b9-4007-bffd-cde361d64f14_0">
											<gml:posList>35.66854297897461 139.74981676214907 34.315 35.66854297897461 139.74981676214907 37.104 35.668550910960974 139.74979063007763 37.104 35.668550910960974 139.74979063007763 34.315 35.66854297897461 139.74981676214907 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1c1b44b-1d16-47bc-87dc-30d6e400e237">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1c1b44b-1d16-47bc-87dc-30d6e400e237_0">
											<gml:posList>35.66855349708082 139.7497894454602 37.104 35.66856190557756 139.74976156761645 37.104 35.66854158222602 139.74975235433683 37.104 35.668533164717644 139.7497802321839 37.104 35.66855349708082 139.7497894454602 37.104</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6b7ba01-ca9a-4038-84ac-c0e7f93dc6ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6b7ba01-ca9a-4038-84ac-c0e7f93dc6ff_0">
											<gml:posList>35.66856190557756 139.74976156761645 34.315 35.66854158222602 139.74975235433683 34.315 35.66854158222602 139.74975235433683 37.104 35.66856190557756 139.74976156761645 37.104 35.66856190557756 139.74976156761645 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da976ee1-90e9-402c-8655-e00e89eab82a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da976ee1-90e9-402c-8655-e00e89eab82a_0">
											<gml:posList>35.66856190557756 139.74976156761645 34.315 35.66856190557756 139.74976156761645 37.104 35.66855349708082 139.7497894454602 37.104 35.66855349708082 139.7497894454602 34.315 35.66856190557756 139.74976156761645 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62093023-c475-42a8-abb5-e97d8d904bcf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62093023-c475-42a8-abb5-e97d8d904bcf_0">
											<gml:posList>35.66859568992558 139.7498407875582 34.315 35.66859568992558 139.7498407875582 37.104 35.66854297897461 139.74981676214907 37.104 35.66854297897461 139.74981676214907 34.315 35.66859568992558 139.7498407875582 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdf88b1f-bbe8-4fb3-8b58-b881604324da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdf88b1f-bbe8-4fb3-8b58-b881604324da_0">
											<gml:posList>35.66854297897461 139.74981676214907 37.104 35.66859568992558 139.7498407875582 37.104 35.668603621917086 139.74981465547194 37.104 35.668550910960974 139.74979063007763 37.104 35.66854297897461 139.74981676214907 37.104</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5792d647-a08f-41c8-ba69-f92725b09252">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5792d647-a08f-41c8-ba69-f92725b09252_0">
											<gml:posList>35.668603621917086 139.74981465547194 34.315 35.668550910960974 139.74979063007763 34.315 35.668550910960974 139.74979063007763 37.104 35.668603621917086 139.74981465547194 37.104 35.668603621917086 139.74981465547194 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-270add1b-6cd1-4e54-a1d0-0343a8926b70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-270add1b-6cd1-4e54-a1d0-0343a8926b70_0">
											<gml:posList>35.66858400685964 139.74974801321528 34.315 35.66858400685964 139.74974801321528 36.927 35.66859246118236 139.74972123991017 36.927 35.66859246118236 139.74972123991017 34.315 35.66858400685964 139.74974801321528 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4758e5fc-57ee-45a2-9c61-45d74589ce69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4758e5fc-57ee-45a2-9c61-45d74589ce69_0">
											<gml:posList>35.668586084166364 139.7497929572774 34.315 35.668586084166364 139.7497929572774 36.766 35.66859381058719 139.74976935494107 36.766 35.66859381058719 139.74976935494107 34.315 35.668586084166364 139.7497929572774 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01886292-43d8-4848-9469-55b82fa153ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01886292-43d8-4848-9469-55b82fa153ed_0">
											<gml:posList>35.668586084166364 139.7497929572774 34.315 35.668602765263756 139.74980115813332 34.315 35.668602765263756 139.74980115813332 36.766 35.668586084166364 139.7497929572774 36.766 35.668586084166364 139.7497929572774 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56c29070-87ad-44df-be31-42c7dcbc3b35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56c29070-87ad-44df-be31-42c7dcbc3b35_0">
											<gml:posList>35.668607116687525 139.74975900200283 34.7 35.66860935283561 139.74976007113568 34.7 35.66860935283561 139.74976007113568 36.927 35.66858400685964 139.74974801321528 36.927 35.66858400685964 139.74974801321528 34.315 35.668607116687525 139.74975900200283 34.315 35.668607116687525 139.74975900200283 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a5acc7a-551d-4949-9b48-02440c4dcb49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a5acc7a-551d-4949-9b48-02440c4dcb49_0">
											<gml:posList>35.66859381058719 139.74976935494107 36.766 35.668586084166364 139.7497929572774 36.766 35.668602765263756 139.74980115813332 36.766 35.668610491693826 139.74977756683884 36.766 35.66859381058719 139.74976935494107 36.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e442bef1-254c-48d0-be85-10bebb0c58f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e442bef1-254c-48d0-be85-10bebb0c58f1_0">
											<gml:posList>35.66859568992558 139.7498407875582 34.315 35.668603621917086 139.74981465547194 34.315 35.668603621917086 139.74981465547194 37.104 35.66859568992558 139.7498407875582 37.104 35.66859568992558 139.7498407875582 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a803f5c8-7c4f-4577-9d1d-1cba98b73d9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a803f5c8-7c4f-4577-9d1d-1cba98b73d9b_0">
											<gml:posList>35.66861780716097 139.74973329782338 36.927 35.66859246118236 139.74972123991017 36.927 35.66858400685964 139.74974801321528 36.927 35.66860935283561 139.74976007113568 36.927 35.66861780716097 139.74973329782338 36.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48228693-c0b4-42e1-bec4-a2e62e3137c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48228693-c0b4-42e1-bec4-a2e62e3137c6_0">
											<gml:posList>35.668610491693826 139.74977756683884 34.315 35.66859381058719 139.74976935494107 34.315 35.66859381058719 139.74976935494107 36.766 35.668610491693826 139.74977756683884 36.766 35.668610491693826 139.74977756683884 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2c54c0b-b04c-4f13-9435-5601350fef74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2c54c0b-b04c-4f13-9435-5601350fef74_0">
											<gml:posList>35.668615571012644 139.74973222869116 34.7 35.668615571012644 139.74973222869116 34.315 35.66859246118236 139.74972123991017 34.315 35.66859246118236 139.74972123991017 36.927 35.66861780716097 139.74973329782338 36.927 35.66861780716097 139.74973329782338 34.7 35.668615571012644 139.74973222869116 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0710abcf-9f9c-4d43-9e11-9a5de1d27171">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0710abcf-9f9c-4d43-9e11-9a5de1d27171_0">
											<gml:posList>35.668602765263756 139.74980115813332 34.315 35.668610491693826 139.74977756683884 34.315 35.668610491693826 139.74977756683884 36.766 35.668602765263756 139.74980115813332 36.766 35.668602765263756 139.74980115813332 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a4e2a31-217d-4a0c-bee2-baff1f5e3dbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a4e2a31-217d-4a0c-bee2-baff1f5e3dbd_0">
											<gml:posList>35.668607116687525 139.74975900200283 34.7 35.668607116687525 139.74975900200283 34.315 35.668615571012644 139.74973222869116 34.315 35.668615571012644 139.74973222869116 34.7 35.668607116687525 139.74975900200283 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb4ff5bb-820f-48c7-ae1d-f037403e8d9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb4ff5bb-820f-48c7-ae1d-f037403e8d9f_0">
											<gml:posList>35.66860935283561 139.74976007113568 34.7 35.66861780716097 139.74973329782338 34.7 35.66861780716097 139.74973329782338 36.927 35.66860935283561 139.74976007113568 36.927 35.66860935283561 139.74976007113568 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_95b67360-12f8-4399-9a66-935661dd1dff_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a21d145-7297-4346-8d48-4515df424ed6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879595451037 139.74986310190607 22.144 35.66880516958711 139.74986748863836 22.144 35.668794070906074 139.7499025050981 22.144 35.66878485582294 139.74989810731637 22.144 35.66879595451037 139.74986310190607 22.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7365fa1-6677-485f-9a18-0d62d0e10de2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6687532090552 139.74993779551696 25.314 35.668733796348995 139.74992893469667 25.314 35.66874886144188 139.7498814321191 25.314 35.66876845473223 139.7498907345832 25.314 35.6687532090552 139.74993779551696 25.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22841de0-373f-4e79-a6c2-0306fa42faa2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668758515315524 139.74994672624194 25.314 35.66875145521092 139.74994333140512 25.314 35.66876288715166 139.74990793905764 25.314 35.668769884145846 139.74991131186542 25.314 35.668758515315524 139.74994672624194 25.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16873c6f-a041-479f-82b8-3fc914d0fbcc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16873c6f-a041-479f-82b8-3fc914d0fbcc_0">
											<gml:posList>35.66880516958711 139.74986748863836 25.57 35.66880516958711 139.74986748863836 22.144 35.66879595451037 139.74986310190607 22.144 35.66879595451037 139.74986310190607 25.57 35.66880516958711 139.74986748863836 25.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-450ebee6-d751-4bac-bdb5-2206b84566b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-450ebee6-d751-4bac-bdb5-2206b84566b3_0">
											<gml:posList>35.66879595451037 139.74986310190607 25.57 35.66879595451037 139.74986310190607 22.144 35.66878485582294 139.74989810731637 22.144 35.66878485582294 139.74989810731637 25.57 35.66879595451037 139.74986310190607 25.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-059d08f4-811d-4137-b3c3-d6f3f68cd5b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-059d08f4-811d-4137-b3c3-d6f3f68cd5b8_0">
											<gml:posList>35.66878485582294 139.74989810731637 25.57 35.668794070906074 139.7499025050981 25.57 35.66880516958711 139.74986748863836 25.57 35.66879595451037 139.74986310190607 25.57 35.66878485582294 139.74989810731637 25.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf8295fe-ff7c-4ada-a34a-22398caa2f5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf8295fe-ff7c-4ada-a34a-22398caa2f5c_0">
											<gml:posList>35.668794070906074 139.7499025050981 25.57 35.668794070906074 139.7499025050981 22.144 35.66880516958711 139.74986748863836 22.144 35.66880516958711 139.74986748863836 25.57 35.668794070906074 139.7499025050981 25.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-269d2cda-f1dc-486e-9776-8a71b491fa51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-269d2cda-f1dc-486e-9776-8a71b491fa51_0">
											<gml:posList>35.66876845473223 139.7498907345832 34.7 35.66876845473223 139.7498907345832 25.314 35.66874886144188 139.7498814321191 25.314 35.66874886144188 139.7498814321191 34.7 35.66876845473223 139.7498907345832 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9a1e3d2-c878-4835-871e-ac9b957ca97e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9a1e3d2-c878-4835-871e-ac9b957ca97e_0">
											<gml:posList>35.66878485582294 139.74989810731637 25.57 35.66878485582294 139.74989810731637 22.144 35.668794070906074 139.7499025050981 22.144 35.668794070906074 139.7499025050981 25.57 35.66878485582294 139.74989810731637 25.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1f0bc03-fe45-48de-9e20-2d2b8542717c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1f0bc03-fe45-48de-9e20-2d2b8542717c_0">
											<gml:posList>35.66874886144188 139.7498814321191 34.7 35.66874886144188 139.7498814321191 25.314 35.668733796348995 139.74992893469667 25.314 35.668733796348995 139.74992893469667 34.7 35.66874886144188 139.7498814321191 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fcee32d-cc2f-427a-b5d5-1d8e8c350a7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fcee32d-cc2f-427a-b5d5-1d8e8c350a7d_0">
											<gml:posList>35.6687532090552 139.74993779551696 34.7 35.66876845473223 139.7498907345832 34.7 35.66874886144188 139.7498814321191 34.7 35.668733796348995 139.74992893469667 34.7 35.6687532090552 139.74993779551696 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6477d1a5-5992-4bcd-a5ac-c462ce52f46d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6477d1a5-5992-4bcd-a5ac-c462ce52f46d_0">
											<gml:posList>35.668769884145846 139.74991131186542 28.753 35.668769884145846 139.74991131186542 25.314 35.66876288715166 139.74990793905764 25.314 35.66876288715166 139.74990793905764 28.753 35.668769884145846 139.74991131186542 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fb065b9-791a-4be6-a82b-1d815af3e692">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fb065b9-791a-4be6-a82b-1d815af3e692_0">
											<gml:posList>35.6687532090552 139.74993779551696 34.7 35.6687532090552 139.74993779551696 25.314 35.66876845473223 139.7498907345832 25.314 35.66876845473223 139.7498907345832 34.7 35.6687532090552 139.74993779551696 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14543907-6e19-4b79-a45f-107f5f9418d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14543907-6e19-4b79-a45f-107f5f9418d8_0">
											<gml:posList>35.66876288715166 139.74990793905764 28.753 35.66876288715166 139.74990793905764 25.314 35.66875145521092 139.74994333140512 25.314 35.66875145521092 139.74994333140512 28.753 35.66876288715166 139.74990793905764 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e99867b1-27ef-4420-a59b-9279445f6c55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e99867b1-27ef-4420-a59b-9279445f6c55_0">
											<gml:posList>35.668758515315524 139.74994672624194 28.753 35.668769884145846 139.74991131186542 28.753 35.66876288715166 139.74990793905764 28.753 35.66875145521092 139.74994333140512 28.753 35.668758515315524 139.74994672624194 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7b8850b-2b12-4e10-8a8f-cc140dcb6686">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7b8850b-2b12-4e10-8a8f-cc140dcb6686_0">
											<gml:posList>35.668758515315524 139.74994672624194 28.753 35.668758515315524 139.74994672624194 25.314 35.668769884145846 139.74991131186542 25.314 35.668769884145846 139.74991131186542 28.753 35.668758515315524 139.74994672624194 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-321d9342-8620-4624-9511-8199c643fd81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-321d9342-8620-4624-9511-8199c643fd81_0">
											<gml:posList>35.668733796348995 139.74992893469667 34.7 35.668733796348995 139.74992893469667 25.314 35.6687532090552 139.74993779551696 25.314 35.6687532090552 139.74993779551696 34.7 35.668733796348995 139.74992893469667 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66507b0c-f6f7-4a77-ab46-43bcbcd5f25d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66507b0c-f6f7-4a77-ab46-43bcbcd5f25d_0">
											<gml:posList>35.66875145521092 139.74994333140512 28.753 35.66875145521092 139.74994333140512 25.314 35.668758515315524 139.74994672624194 25.314 35.668758515315524 139.74994672624194 28.753 35.66875145521092 139.74994333140512 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_95b67360-12f8-4399-9a66-935661dd1dff_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d700a239-ea5b-4734-a2c7-78f82e788c16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854862331077 139.74984526601673 34.315 35.66855120392432 139.74983613932685 34.315 35.66856588260808 139.74984237608334 34.315 35.66856329298032 139.74985150278408 34.315 35.66854862331077 139.74984526601673 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f480469-8119-46d7-a09e-da9358caff1e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66857899196801 139.7498602680189 34.315 35.6685690107468 139.7498559152354 34.315 35.66857169045088 139.74984670007225 34.315 35.66858167167242 139.74985105285475 34.315 35.66857899196801 139.7498602680189 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6e7b35d-f885-4a5c-8cdf-8bad0dc820bc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66859940733374 139.74985919739436 34.315 35.66859687136599 139.74986771651174 34.315 35.66858475313359 139.74986227239572 34.315 35.668587298122326 139.74985376431604 34.315 35.66859940733374 139.74985919739436 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bc836a7-5c5e-40af-af15-812d708861e5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668616529731736 139.7498668675972 34.315 35.668613984749726 139.74987538672556 34.315 35.66860168618955 139.7498698654728 34.315 35.66860423117883 139.7498613573916 34.315 35.668616529731736 139.7498668675972 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-085ccd9b-4015-434b-a540-de8960e39601">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862175907342 139.7498428481104 34.315 35.66861855753836 139.74985345562095 34.315 35.66860813439159 139.74984873877776 34.315 35.668611335926244 139.7498381312684 34.315 35.66862175907342 139.7498428481104 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9174ad6e-5181-4995-b5e9-56246c7bc479">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668626084719136 139.74982848378204 34.315 35.668622685342875 139.74983975426082 34.315 35.66861262285957 139.74983520273383 34.315 35.66861602222775 139.74982392121026 34.315 35.668626084719136 139.74982848378204 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a05271f6-e41b-468c-b8b0-cbfa0c59c495">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66864980886307 139.74988048583833 34.315 35.668646723814255 139.74989009908793 34.315 35.66863753575634 139.74988567919547 34.315 35.66864062080479 139.7498760659468 34.315 35.66864980886307 139.74988048583833 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad195942-3e17-4ba7-a4ac-881cd62ec288">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866129604941 139.74988580911204 34.315 35.668658417688285 139.74989451637381 34.315 35.66864959921633 139.74989012923368 34.315 35.668652486590865 139.7498814219633 34.315 35.66866129604941 139.74988580911204 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98f01b1b-6b1d-4ee3-bcd8-a33f14ca270d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686740907082 139.74989182692622 34.315 35.66867146526676 139.74990130714775 34.315 35.668661339919375 139.74989708705638 34.315 35.66866397437422 139.74988760682655 34.315 35.6686740907082 139.74989182692622 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd418b0b-dd95-445d-a10f-e2066bf38fa9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867272602515 139.7498216087647 34.315 35.668663502001785 139.74981732146844 34.315 35.668666433911 139.74980785197187 34.315 35.66867565793471 139.7498121392672 34.315 35.66867272602515 139.7498216087647 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d465df7-8c9d-41d3-b504-939ddd65cad0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867272602515 139.7498216087647 34.315 35.66867565793471 139.7498121392672 34.315 35.66867565793471 139.7498121392672 36.129 35.66867272602515 139.7498216087647 36.129 35.66867272602515 139.7498216087647 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-765c778a-9389-4871-be50-3c31dfaee6de">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865419181322 139.74984475843968 34.315 35.66870138516207 139.7498670664633 34.315 35.668698210290984 139.74987713270028 34.315 35.66865102595768 139.74985482466224 34.315 35.66865419181322 139.74984475843968 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-718655f0-661a-49d0-b9df-bb214fac9c44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867868752783 139.74981355000278 34.315 35.66867572863827 139.7498231078969 34.315 35.66867572863827 139.7498231078969 36.129 35.66867868752783 139.74981355000278 36.129 35.66867868752783 139.74981355000278 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e07b50cf-000b-4bb1-bc48-35d4ff364601">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867868752783 139.74981355000278 34.315 35.6686899673477 139.74981879616257 34.315 35.66868700845774 139.74982835405785 34.315 35.66867572863827 139.7498231078969 34.315 35.66867868752783 139.74981355000278 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aaef98c5-d015-4704-b189-d76cf3812219">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869068361045 139.74988983241997 34.315 35.668688057564545 139.74989844000802 34.315 35.66867639910268 139.74989309481694 34.315 35.66867902515587 139.74988449827597 34.315 35.66869068361045 139.74988983241997 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a792a78-2dab-45df-bdcc-dbdcb7fdafca">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865931816419 139.74982820615912 34.315 35.668732118856454 139.7498625387354 34.315 35.66872928578008 139.7498715552475 34.315 35.668656485090345 139.74983722266424 34.315 35.66865931816419 139.74982820615912 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5e64eb8-5d1d-4698-b029-a80b9b6ee224">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869057918837 139.74983021711782 34.315 35.66869366422471 139.74982059281464 34.315 35.66871899226512 139.7498327943915 34.315 35.668715907227835 139.74984241869726 34.315 35.66869057918837 139.74983021711782 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-815c0565-16fd-4846-8845-9066e9461786">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66870765176226 139.74987003132213 34.315 35.66872644254097 139.7498789148647 34.315 35.668723276682634 139.74988898109495 34.315 35.66870447689093 139.74988009755975 34.315 35.66870765176226 139.74987003132213 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-895b84d3-b608-4cb5-b970-ed93ca675f43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66873570877102 139.74984006736554 34.315 35.668732245953045 139.7498508408538 34.315 35.66872059630377 139.7498452084607 34.315 35.66872405912124 139.74983443497376 34.315 35.66873570877102 139.74984006736554 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-517e62d4-32e3-41cd-8f54-bdc4eba0eaf9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-517e62d4-32e3-41cd-8f54-bdc4eba0eaf9_0">
											<gml:posList>35.66861262285957 139.74983520273383 34.315 35.668622685342875 139.74983975426082 34.315 35.668622685342875 139.74983975426082 36.76 35.66861262285957 139.74983520273383 36.76 35.66861262285957 139.74983520273383 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f954ea1-1793-43e2-a1f2-446fb66fd739">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f954ea1-1793-43e2-a1f2-446fb66fd739_0">
											<gml:posList>35.66870138516207 139.7498670664633 34.315 35.66865419181322 139.74984475843968 34.315 35.66865419181322 139.74984475843968 36.303 35.66870138516207 139.7498670664633 36.303 35.66870138516207 139.7498670664633 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c52bb4c5-9924-44c3-9c0e-fb6fb664b0b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c52bb4c5-9924-44c3-9c0e-fb6fb664b0b3_0">
											<gml:posList>35.66868700845774 139.74982835405785 34.315 35.6686899673477 139.74981879616257 34.315 35.6686899673477 139.74981879616257 36.129 35.66868700845774 139.74982835405785 36.129 35.66868700845774 139.74982835405785 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44b45ac3-ab05-4e1a-923c-eb5d4910af3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44b45ac3-ab05-4e1a-923c-eb5d4910af3e_0">
											<gml:posList>35.668715907227835 139.74984241869726 34.315 35.668715907227835 139.74984241869726 36.303 35.66869057918837 139.74983021711782 36.303 35.66869057918837 139.74983021711782 34.315 35.668715907227835 139.74984241869726 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-319dba88-0031-42a3-9487-64e19405e197">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-319dba88-0031-42a3-9487-64e19405e197_0">
											<gml:posList>35.66872059630377 139.7498452084607 34.315 35.668732245953045 139.7498508408538 34.315 35.668732245953045 139.7498508408538 36.129 35.66872059630377 139.7498452084607 36.129 35.66872059630377 139.7498452084607 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e4a4152-18c7-4731-a7cf-efb56f30470c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e4a4152-18c7-4731-a7cf-efb56f30470c_0">
											<gml:posList>35.66855120392432 139.74983613932685 34.315 35.66854862331077 139.74984526601673 34.315 35.66854862331077 139.74984526601673 36.303 35.66855120392432 139.74983613932685 36.303 35.66855120392432 139.74983613932685 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3fc7705-8359-43e8-bfd9-0d8e3f8cef04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3fc7705-8359-43e8-bfd9-0d8e3f8cef04_0">
											<gml:posList>35.66867565793471 139.7498121392672 34.315 35.668666433911 139.74980785197187 34.315 35.668666433911 139.74980785197187 36.129 35.66867565793471 139.7498121392672 36.129 35.66867565793471 139.7498121392672 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4043b538-abc9-42f3-9080-97b0e16ceff3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4043b538-abc9-42f3-9080-97b0e16ceff3_0">
											<gml:posList>35.668666433911 139.74980785197187 34.315 35.668663502001785 139.74981732146844 34.315 35.668663502001785 139.74981732146844 36.129 35.668666433911 139.74980785197187 36.129 35.668666433911 139.74980785197187 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcb1f9ef-e0e1-41c3-abeb-f57fb543db65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcb1f9ef-e0e1-41c3-abeb-f57fb543db65_0">
											<gml:posList>35.668666433911 139.74980785197187 36.129 35.668663502001785 139.74981732146844 36.129 35.66867272602515 139.7498216087647 36.129 35.66867565793471 139.7498121392672 36.129 35.668666433911 139.74980785197187 36.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a7c2ff6-563c-4bed-b958-0049213adf25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a7c2ff6-563c-4bed-b958-0049213adf25_0">
											<gml:posList>35.6686899673477 139.74981879616257 34.315 35.66867868752783 139.74981355000278 34.315 35.66867868752783 139.74981355000278 36.129 35.6686899673477 139.74981879616257 36.129 35.6686899673477 139.74981879616257 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f913967a-a30e-41c4-a51b-fa5601243dd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f913967a-a30e-41c4-a51b-fa5601243dd0_0">
											<gml:posList>35.668663502001785 139.74981732146844 34.315 35.66867272602515 139.7498216087647 34.315 35.66867272602515 139.7498216087647 36.129 35.668663502001785 139.74981732146844 36.129 35.668663502001785 139.74981732146844 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc3d8fda-bf7f-4d56-998a-510e659e2e40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc3d8fda-bf7f-4d56-998a-510e659e2e40_0">
											<gml:posList>35.66868700845774 139.74982835405785 36.129 35.6686899673477 139.74981879616257 36.129 35.66867868752783 139.74981355000278 36.129 35.66867572863827 139.7498231078969 36.129 35.66868700845774 139.74982835405785 36.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52df0e8a-95cf-4c91-aa7b-b6416df0ff6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52df0e8a-95cf-4c91-aa7b-b6416df0ff6c_0">
											<gml:posList>35.66869366422471 139.74982059281464 34.315 35.66869057918837 139.74983021711782 34.315 35.66869057918837 139.74983021711782 36.303 35.66869366422471 139.74982059281464 36.303 35.66869366422471 139.74982059281464 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10cb3523-9611-43cb-8918-7b043deaa95f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10cb3523-9611-43cb-8918-7b043deaa95f_0">
											<gml:posList>35.66867572863827 139.7498231078969 34.315 35.66868700845774 139.74982835405785 34.315 35.66868700845774 139.74982835405785 36.129 35.66867572863827 139.7498231078969 36.129 35.66867572863827 139.7498231078969 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-545b157d-bb25-4fcd-a174-5ebc647880bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-545b157d-bb25-4fcd-a174-5ebc647880bb_0">
											<gml:posList>35.668626084719136 139.74982848378204 34.315 35.66861602222775 139.74982392121026 34.315 35.66861602222775 139.74982392121026 36.76 35.668626084719136 139.74982848378204 36.76 35.668626084719136 139.74982848378204 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-534d6a80-2e59-4c75-bd48-2bf6dadf6b52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-534d6a80-2e59-4c75-bd48-2bf6dadf6b52_0">
											<gml:posList>35.66871899226512 139.7498327943915 34.315 35.66869366422471 139.74982059281464 34.315 35.66869366422471 139.74982059281464 36.303 35.66871899226512 139.7498327943915 36.303 35.66871899226512 139.7498327943915 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a577b9d-559c-4658-8eb7-252cd00e8f69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a577b9d-559c-4658-8eb7-252cd00e8f69_0">
											<gml:posList>35.66861262285957 139.74983520273383 34.315 35.66861262285957 139.74983520273383 36.76 35.66861602222775 139.74982392121026 36.76 35.66861602222775 139.74982392121026 34.315 35.66861262285957 139.74983520273383 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d6d8962-88cf-4def-9e02-a808490c1442">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d6d8962-88cf-4def-9e02-a808490c1442_0">
											<gml:posList>35.66869057918837 139.74983021711782 36.303 35.668715907227835 139.74984241869726 36.303 35.66871899226512 139.7498327943915 36.303 35.66869366422471 139.74982059281464 36.303 35.66869057918837 139.74983021711782 36.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96f28cd4-1f7c-4141-a871-8ea862548f37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96f28cd4-1f7c-4141-a871-8ea862548f37_0">
											<gml:posList>35.66861262285957 139.74983520273383 36.76 35.668622685342875 139.74983975426082 36.76 35.668626084719136 139.74982848378204 36.76 35.66861602222775 139.74982392121026 36.76 35.66861262285957 139.74983520273383 36.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fb7e37d-5a0c-4452-b0c4-ec30c9a81112">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fb7e37d-5a0c-4452-b0c4-ec30c9a81112_0">
											<gml:posList>35.668656485090345 139.74983722266424 34.315 35.668656485090345 139.74983722266424 36.303 35.66865931816419 139.74982820615912 36.303 35.66865931816419 139.74982820615912 34.315 35.668656485090345 139.74983722266424 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed3ec138-a69c-4826-8c3a-8de6bedfd38e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed3ec138-a69c-4826-8c3a-8de6bedfd38e_0">
											<gml:posList>35.668622685342875 139.74983975426082 34.315 35.668626084719136 139.74982848378204 34.315 35.668626084719136 139.74982848378204 36.76 35.668622685342875 139.74983975426082 36.76 35.668622685342875 139.74983975426082 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2935413b-1772-4285-b89c-4abead830288">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2935413b-1772-4285-b89c-4abead830288_0">
											<gml:posList>35.66873570877102 139.74984006736554 34.315 35.66872405912124 139.74983443497376 34.315 35.66872405912124 139.74983443497376 36.129 35.66873570877102 139.74984006736554 36.129 35.66873570877102 139.74984006736554 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea4091b7-5d7a-4a5d-a0bb-6c34ebeafa8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea4091b7-5d7a-4a5d-a0bb-6c34ebeafa8c_0">
											<gml:posList>35.668715907227835 139.74984241869726 34.315 35.66871899226512 139.7498327943915 34.315 35.66871899226512 139.7498327943915 36.303 35.668715907227835 139.74984241869726 36.303 35.668715907227835 139.74984241869726 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd0b63a9-691a-4e22-8367-ae77d73f8351">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd0b63a9-691a-4e22-8367-ae77d73f8351_0">
											<gml:posList>35.66856588260808 139.74984237608334 34.315 35.66855120392432 139.74983613932685 34.315 35.66855120392432 139.74983613932685 36.303 35.66856588260808 139.74984237608334 36.303 35.66856588260808 139.74984237608334 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cd89dcd-1a46-4b99-954a-d8eb663f0818">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cd89dcd-1a46-4b99-954a-d8eb663f0818_0">
											<gml:posList>35.66872059630377 139.7498452084607 34.315 35.66872059630377 139.7498452084607 36.129 35.66872405912124 139.74983443497376 36.129 35.66872405912124 139.74983443497376 34.315 35.66872059630377 139.7498452084607 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c82d6e53-fe9f-4405-83d9-6728e34225d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c82d6e53-fe9f-4405-83d9-6728e34225d9_0">
											<gml:posList>35.66862175907342 139.7498428481104 34.315 35.668611335926244 139.7498381312684 34.315 35.668611335926244 139.7498381312684 36.76 35.66862175907342 139.7498428481104 36.76 35.66862175907342 139.7498428481104 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c392879-554a-49fb-a6c2-fc4de117d0d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c392879-554a-49fb-a6c2-fc4de117d0d7_0">
											<gml:posList>35.66872059630377 139.7498452084607 36.129 35.668732245953045 139.7498508408538 36.129 35.66873570877102 139.74984006736554 36.129 35.66872405912124 139.74983443497376 36.129 35.66872059630377 139.7498452084607 36.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3926a3e2-38d6-45a3-8806-8b00494c697d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3926a3e2-38d6-45a3-8806-8b00494c697d_0">
											<gml:posList>35.66860813439159 139.74984873877776 34.315 35.66860813439159 139.74984873877776 36.76 35.668611335926244 139.7498381312684 36.76 35.668611335926244 139.7498381312684 34.315 35.66860813439159 139.74984873877776 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8ef15af-9c51-48c3-8792-480b047047fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8ef15af-9c51-48c3-8792-480b047047fa_0">
											<gml:posList>35.66854862331077 139.74984526601673 36.303 35.66856329298032 139.74985150278408 36.303 35.66856588260808 139.74984237608334 36.303 35.66855120392432 139.74983613932685 36.303 35.66854862331077 139.74984526601673 36.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4ffca37-1d79-4879-bed4-7487ce780df4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4ffca37-1d79-4879-bed4-7487ce780df4_0">
											<gml:posList>35.668732118856454 139.7498625387354 34.315 35.66865931816419 139.74982820615912 34.315 35.66865931816419 139.74982820615912 36.303 35.668732118856454 139.7498625387354 36.303 35.668732118856454 139.7498625387354 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42df62ee-a552-49e7-8692-a750e2e1221a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42df62ee-a552-49e7-8692-a750e2e1221a_0">
											<gml:posList>35.668732245953045 139.7498508408538 34.315 35.66873570877102 139.74984006736554 34.315 35.66873570877102 139.74984006736554 36.129 35.668732245953045 139.7498508408538 36.129 35.668732245953045 139.7498508408538 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-275fde67-6cf7-4e88-a118-ae88a93d8069">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-275fde67-6cf7-4e88-a118-ae88a93d8069_0">
											<gml:posList>35.66860813439159 139.74984873877776 36.76 35.66861855753836 139.74985345562095 36.76 35.66862175907342 139.7498428481104 36.76 35.668611335926244 139.7498381312684 36.76 35.66860813439159 139.74984873877776 36.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5d9dfd3-85a8-4ca1-a021-804ce29c3d76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5d9dfd3-85a8-4ca1-a021-804ce29c3d76_0">
											<gml:posList>35.66856329298032 139.74985150278408 34.315 35.66856588260808 139.74984237608334 34.315 35.66856588260808 139.74984237608334 36.303 35.66856329298032 139.74985150278408 36.303 35.66856329298032 139.74985150278408 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af76f5bf-a91d-4fd2-8e69-4a3e4b6c1def">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af76f5bf-a91d-4fd2-8e69-4a3e4b6c1def_0">
											<gml:posList>35.66861855753836 139.74985345562095 34.315 35.66862175907342 139.7498428481104 34.315 35.66862175907342 139.7498428481104 36.76 35.66861855753836 139.74985345562095 36.76 35.66861855753836 139.74985345562095 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc1176c6-682d-46ac-b5ad-e5506b3fa43a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc1176c6-682d-46ac-b5ad-e5506b3fa43a_0">
											<gml:posList>35.66854862331077 139.74984526601673 34.315 35.66856329298032 139.74985150278408 34.315 35.66856329298032 139.74985150278408 36.303 35.66854862331077 139.74984526601673 36.303 35.66854862331077 139.74984526601673 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28a95522-1582-4597-ace9-da5f3c3cf973">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28a95522-1582-4597-ace9-da5f3c3cf973_0">
											<gml:posList>35.66858167167242 139.74985105285475 34.315 35.66857169045088 139.74984670007225 34.315 35.66857169045088 139.74984670007225 36.303 35.66858167167242 139.74985105285475 36.303 35.66858167167242 139.74985105285475 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-421bec49-cd95-4f65-a4f0-3f422dd5870e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-421bec49-cd95-4f65-a4f0-3f422dd5870e_0">
											<gml:posList>35.66865419181322 139.74984475843968 34.315 35.66865102595768 139.74985482466224 34.315 35.66865102595768 139.74985482466224 36.303 35.66865419181322 139.74984475843968 36.303 35.66865419181322 139.74984475843968 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-960cedb2-4565-448c-b785-03aefecc394d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-960cedb2-4565-448c-b785-03aefecc394d_0">
											<gml:posList>35.66872928578008 139.7498715552475 36.303 35.668732118856454 139.7498625387354 36.303 35.66865931816419 139.74982820615912 36.303 35.668656485090345 139.74983722266424 36.303 35.66872928578008 139.7498715552475 36.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-577d5829-2479-4ae3-9e0b-00d2a1d86eaa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-577d5829-2479-4ae3-9e0b-00d2a1d86eaa_0">
											<gml:posList>35.66860813439159 139.74984873877776 34.315 35.66861855753836 139.74985345562095 34.315 35.66861855753836 139.74985345562095 36.76 35.66860813439159 139.74984873877776 36.76 35.66860813439159 139.74984873877776 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0bb53a3-949d-4405-8483-4c6846b98204">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0bb53a3-949d-4405-8483-4c6846b98204_0">
											<gml:posList>35.66857169045088 139.74984670007225 34.315 35.6685690107468 139.7498559152354 34.315 35.6685690107468 139.7498559152354 36.303 35.66857169045088 139.74984670007225 36.303 35.66857169045088 139.74984670007225 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d90e4ade-26df-427d-bd66-1ab660006a16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d90e4ade-26df-427d-bd66-1ab660006a16_0">
											<gml:posList>35.66857899196801 139.7498602680189 36.303 35.66858167167242 139.74985105285475 36.303 35.66857169045088 139.74984670007225 36.303 35.6685690107468 139.7498559152354 36.303 35.66857899196801 139.7498602680189 36.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40b7d273-631e-42de-9355-a0ea8296b994">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40b7d273-631e-42de-9355-a0ea8296b994_0">
											<gml:posList>35.668656485090345 139.74983722266424 34.315 35.66872928578008 139.7498715552475 34.315 35.66872928578008 139.7498715552475 36.303 35.668656485090345 139.74983722266424 36.303 35.668656485090345 139.74983722266424 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-920461b6-8753-48a8-b48d-c953bc665662">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-920461b6-8753-48a8-b48d-c953bc665662_0">
											<gml:posList>35.66857899196801 139.7498602680189 34.315 35.66858167167242 139.74985105285475 34.315 35.66858167167242 139.74985105285475 36.303 35.66857899196801 139.7498602680189 36.303 35.66857899196801 139.7498602680189 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80c90638-c13a-4b80-8224-aa7150d78839">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80c90638-c13a-4b80-8224-aa7150d78839_0">
											<gml:posList>35.66859940733374 139.74985919739436 34.315 35.668587298122326 139.74985376431604 34.315 35.668587298122326 139.74985376431604 36.303 35.66859940733374 139.74985919739436 36.303 35.66859940733374 139.74985919739436 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fb0d984-8567-44ac-8058-3a77c010b9b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fb0d984-8567-44ac-8058-3a77c010b9b0_0">
											<gml:posList>35.668587298122326 139.74985376431604 34.315 35.66858475313359 139.74986227239572 34.315 35.66858475313359 139.74986227239572 36.303 35.668587298122326 139.74985376431604 36.303 35.668587298122326 139.74985376431604 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94280fb6-53d9-42f6-a23f-8d670f466aae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94280fb6-53d9-42f6-a23f-8d670f466aae_0">
											<gml:posList>35.6685690107468 139.7498559152354 34.315 35.66857899196801 139.7498602680189 34.315 35.66857899196801 139.7498602680189 36.303 35.6685690107468 139.7498559152354 36.303 35.6685690107468 139.7498559152354 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d82aea9b-39ef-458d-88eb-be4eac822f28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d82aea9b-39ef-458d-88eb-be4eac822f28_0">
											<gml:posList>35.66858475313359 139.74986227239572 36.303 35.66859687136599 139.74986771651174 36.303 35.66859940733374 139.74985919739436 36.303 35.668587298122326 139.74985376431604 36.303 35.66858475313359 139.74986227239572 36.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-164f5b34-74bb-4669-92c2-c87ca2b24618">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-164f5b34-74bb-4669-92c2-c87ca2b24618_0">
											<gml:posList>35.668698210290984 139.74987713270028 36.303 35.66870138516207 139.7498670664633 36.303 35.66865419181322 139.74984475843968 36.303 35.66865102595768 139.74985482466224 36.303 35.668698210290984 139.74987713270028 36.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20eaa571-ebc9-4ea3-b39c-bc4615a89284">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20eaa571-ebc9-4ea3-b39c-bc4615a89284_0">
											<gml:posList>35.66859687136599 139.74986771651174 34.315 35.66859940733374 139.74985919739436 34.315 35.66859940733374 139.74985919739436 36.303 35.66859687136599 139.74986771651174 36.303 35.66859687136599 139.74986771651174 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad112df8-897c-4268-8866-bfe915d82011">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad112df8-897c-4268-8866-bfe915d82011_0">
											<gml:posList>35.668616529731736 139.7498668675972 34.315 35.66860423117883 139.7498613573916 34.315 35.66860423117883 139.7498613573916 36.303 35.668616529731736 139.7498668675972 36.303 35.668616529731736 139.7498668675972 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-072f6872-67cd-47be-8f73-91c18ceefbda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-072f6872-67cd-47be-8f73-91c18ceefbda_0">
											<gml:posList>35.66858475313359 139.74986227239572 34.315 35.66859687136599 139.74986771651174 34.315 35.66859687136599 139.74986771651174 36.303 35.66858475313359 139.74986227239572 36.303 35.66858475313359 139.74986227239572 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46f21103-de7c-404e-89c2-f40be727cb34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46f21103-de7c-404e-89c2-f40be727cb34_0">
											<gml:posList>35.66860423117883 139.7498613573916 34.315 35.66860168618955 139.7498698654728 34.315 35.66860168618955 139.7498698654728 36.303 35.66860423117883 139.7498613573916 36.303 35.66860423117883 139.7498613573916 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58fb3fc7-03dc-4217-949b-35342f74c5dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58fb3fc7-03dc-4217-949b-35342f74c5dd_0">
											<gml:posList>35.66865102595768 139.74985482466224 34.315 35.668698210290984 139.74987713270028 34.315 35.668698210290984 139.74987713270028 36.303 35.66865102595768 139.74985482466224 36.303 35.66865102595768 139.74985482466224 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a88c9285-b3c0-4f97-88cf-b7fe1c3d1a68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a88c9285-b3c0-4f97-88cf-b7fe1c3d1a68_0">
											<gml:posList>35.66872928578008 139.7498715552475 34.315 35.668732118856454 139.7498625387354 34.315 35.668732118856454 139.7498625387354 36.303 35.66872928578008 139.7498715552475 36.303 35.66872928578008 139.7498715552475 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3952ceaf-3e88-4003-8456-e7aa8ec16b8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3952ceaf-3e88-4003-8456-e7aa8ec16b8d_0">
											<gml:posList>35.66860168618955 139.7498698654728 36.303 35.668613984749726 139.74987538672556 36.303 35.668616529731736 139.7498668675972 36.303 35.66860423117883 139.7498613573916 36.303 35.66860168618955 139.7498698654728 36.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcc2b404-8bbb-417b-abba-adc7a6dcdad8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dcc2b404-8bbb-417b-abba-adc7a6dcdad8_0">
											<gml:posList>35.668613984749726 139.74987538672556 34.315 35.668616529731736 139.7498668675972 34.315 35.668616529731736 139.7498668675972 36.303 35.668613984749726 139.74987538672556 36.303 35.668613984749726 139.74987538672556 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f789fb3-2e96-4c00-bcbf-369d7ee47ff5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f789fb3-2e96-4c00-bcbf-369d7ee47ff5_0">
											<gml:posList>35.668698210290984 139.74987713270028 34.315 35.66870138516207 139.7498670664633 34.315 35.66870138516207 139.7498670664633 36.303 35.668698210290984 139.74987713270028 36.303 35.668698210290984 139.74987713270028 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f4a3b98-4105-41f2-a162-338938f1349f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f4a3b98-4105-41f2-a162-338938f1349f_0">
											<gml:posList>35.66860168618955 139.7498698654728 34.315 35.668613984749726 139.74987538672556 34.315 35.668613984749726 139.74987538672556 36.303 35.66860168618955 139.7498698654728 36.303 35.66860168618955 139.7498698654728 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f844e2a-6678-47c4-95dc-3de0fe28b1dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f844e2a-6678-47c4-95dc-3de0fe28b1dc_0">
											<gml:posList>35.66872644254097 139.7498789148647 34.315 35.66870765176226 139.74987003132213 34.315 35.66870765176226 139.74987003132213 36.303 35.66872644254097 139.7498789148647 36.303 35.66872644254097 139.7498789148647 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f440558-dc56-4f3e-9ff9-6bb7b1e1d371">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f440558-dc56-4f3e-9ff9-6bb7b1e1d371_0">
											<gml:posList>35.66870765176226 139.74987003132213 34.315 35.66870447689093 139.74988009755975 34.315 35.66870447689093 139.74988009755975 36.303 35.66870765176226 139.74987003132213 36.303 35.66870765176226 139.74987003132213 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a0c45d6-049f-4b11-9796-0eb33a0127e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a0c45d6-049f-4b11-9796-0eb33a0127e2_0">
											<gml:posList>35.66864980886307 139.74988048583833 34.315 35.66864062080479 139.7498760659468 34.315 35.66864062080479 139.7498760659468 36.129 35.66864980886307 139.74988048583833 36.129 35.66864980886307 139.74988048583833 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-978c11f4-28d8-43a7-8d2b-59b2abe1d76e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-978c11f4-28d8-43a7-8d2b-59b2abe1d76e_0">
											<gml:posList>35.668723276682634 139.74988898109495 36.303 35.66872644254097 139.7498789148647 36.303 35.66870765176226 139.74987003132213 36.303 35.66870447689093 139.74988009755975 36.303 35.668723276682634 139.74988898109495 36.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee668f76-5948-4867-be41-764b9af1bdcf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee668f76-5948-4867-be41-764b9af1bdcf_0">
											<gml:posList>35.66864062080479 139.7498760659468 34.315 35.66863753575634 139.74988567919547 34.315 35.66863753575634 139.74988567919547 36.129 35.66864062080479 139.7498760659468 36.129 35.66864062080479 139.7498760659468 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ee9842c-c969-49a9-9bbb-75d4e2dce18c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ee9842c-c969-49a9-9bbb-75d4e2dce18c_0">
											<gml:posList>35.66863753575634 139.74988567919547 36.129 35.668646723814255 139.74989009908793 36.129 35.66864980886307 139.74988048583833 36.129 35.66864062080479 139.7498760659468 36.129 35.66863753575634 139.74988567919547 36.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b1fbec4-5722-4f5f-87eb-b61abd13d9f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b1fbec4-5722-4f5f-87eb-b61abd13d9f0_0">
											<gml:posList>35.66866129604941 139.74988580911204 34.315 35.668652486590865 139.7498814219633 34.315 35.668652486590865 139.7498814219633 36.129 35.66866129604941 139.74988580911204 36.129 35.66866129604941 139.74988580911204 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e5824d3-0a4c-40cd-aa5e-367b4fb916bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e5824d3-0a4c-40cd-aa5e-367b4fb916bc_0">
											<gml:posList>35.668723276682634 139.74988898109495 34.315 35.66872644254097 139.7498789148647 34.315 35.66872644254097 139.7498789148647 36.303 35.668723276682634 139.74988898109495 36.303 35.668723276682634 139.74988898109495 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71c8cb70-8c32-48ed-a876-5b51558ffdf9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71c8cb70-8c32-48ed-a876-5b51558ffdf9_0">
											<gml:posList>35.66870447689093 139.74988009755975 34.315 35.668723276682634 139.74988898109495 34.315 35.668723276682634 139.74988898109495 36.303 35.66870447689093 139.74988009755975 36.303 35.66870447689093 139.74988009755975 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9ebcb62-7cd3-4732-9169-d56f26e59e61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9ebcb62-7cd3-4732-9169-d56f26e59e61_0">
											<gml:posList>35.668646723814255 139.74989009908793 34.315 35.66864980886307 139.74988048583833 34.315 35.66864980886307 139.74988048583833 36.129 35.668646723814255 139.74989009908793 36.129 35.668646723814255 139.74989009908793 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f99f3ee-3b86-412e-8df4-9e42cb767395">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f99f3ee-3b86-412e-8df4-9e42cb767395_0">
											<gml:posList>35.668652486590865 139.7498814219633 34.315 35.66864959921633 139.74989012923368 34.315 35.66864959921633 139.74989012923368 36.129 35.668652486590865 139.7498814219633 36.129 35.668652486590865 139.7498814219633 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bed6557a-a5ad-4172-8003-5ba2b80aea06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bed6557a-a5ad-4172-8003-5ba2b80aea06_0">
											<gml:posList>35.66869068361045 139.74988983241997 34.315 35.66867902515587 139.74988449827597 34.315 35.66867902515587 139.74988449827597 36.303 35.66869068361045 139.74988983241997 36.303 35.66869068361045 139.74988983241997 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a11fd38b-0938-4be2-ac38-f53663d6ef1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a11fd38b-0938-4be2-ac38-f53663d6ef1b_0">
											<gml:posList>35.66863753575634 139.74988567919547 34.315 35.668646723814255 139.74989009908793 34.315 35.668646723814255 139.74989009908793 36.129 35.66863753575634 139.74988567919547 36.129 35.66863753575634 139.74988567919547 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7830c348-66d7-4004-89b4-94da7aa2cccb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7830c348-66d7-4004-89b4-94da7aa2cccb_0">
											<gml:posList>35.66864959921633 139.74989012923368 36.129 35.668658417688285 139.74989451637381 36.129 35.66866129604941 139.74988580911204 36.129 35.668652486590865 139.7498814219633 36.129 35.66864959921633 139.74989012923368 36.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21f14f77-becb-44db-be3b-085e54f4dd00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21f14f77-becb-44db-be3b-085e54f4dd00_0">
											<gml:posList>35.66867639910268 139.74989309481694 34.315 35.66867639910268 139.74989309481694 36.303 35.66867902515587 139.74988449827597 36.303 35.66867902515587 139.74988449827597 34.315 35.66867639910268 139.74989309481694 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f36b0551-fe79-46cd-991f-9a33ed4ebb47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f36b0551-fe79-46cd-991f-9a33ed4ebb47_0">
											<gml:posList>35.6686740907082 139.74989182692622 34.315 35.66866397437422 139.74988760682655 34.315 35.66866397437422 139.74988760682655 36.129 35.6686740907082 139.74989182692622 36.129 35.6686740907082 139.74989182692622 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6272a77b-be32-43a2-9874-6150723ffcbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6272a77b-be32-43a2-9874-6150723ffcbb_0">
											<gml:posList>35.66866129604941 139.74988580911204 34.315 35.66866129604941 139.74988580911204 36.129 35.668658417688285 139.74989451637381 36.129 35.668658417688285 139.74989451637381 34.315 35.66866129604941 139.74988580911204 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8db2360-1b93-447e-af1b-f845d952b06f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8db2360-1b93-447e-af1b-f845d952b06f_0">
											<gml:posList>35.66867639910268 139.74989309481694 36.303 35.668688057564545 139.74989844000802 36.303 35.66869068361045 139.74988983241997 36.303 35.66867902515587 139.74988449827597 36.303 35.66867639910268 139.74989309481694 36.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2a0f7c0-ee41-4c35-a013-d7f271e01fa9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2a0f7c0-ee41-4c35-a013-d7f271e01fa9_0">
											<gml:posList>35.66864959921633 139.74989012923368 34.315 35.668658417688285 139.74989451637381 34.315 35.668658417688285 139.74989451637381 36.129 35.66864959921633 139.74989012923368 36.129 35.66864959921633 139.74989012923368 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4af73949-abc8-45bc-8500-d871e695b591">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4af73949-abc8-45bc-8500-d871e695b591_0">
											<gml:posList>35.66866397437422 139.74988760682655 34.315 35.668661339919375 139.74989708705638 34.315 35.668661339919375 139.74989708705638 36.129 35.66866397437422 139.74988760682655 36.129 35.66866397437422 139.74988760682655 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c94ad44-3763-44ac-a985-deec3494690b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c94ad44-3763-44ac-a985-deec3494690b_0">
											<gml:posList>35.66869068361045 139.74988983241997 34.315 35.66869068361045 139.74988983241997 36.303 35.668688057564545 139.74989844000802 36.303 35.668688057564545 139.74989844000802 34.315 35.66869068361045 139.74988983241997 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66dc82ac-3bcb-4c92-9e6d-0ccb2d85fa92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66dc82ac-3bcb-4c92-9e6d-0ccb2d85fa92_0">
											<gml:posList>35.668661339919375 139.74989708705638 36.129 35.66867146526676 139.74990130714775 36.129 35.6686740907082 139.74989182692622 36.129 35.66866397437422 139.74988760682655 36.129 35.668661339919375 139.74989708705638 36.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-113975b5-07e2-4e02-bded-ae821ddaeb45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-113975b5-07e2-4e02-bded-ae821ddaeb45_0">
											<gml:posList>35.66867639910268 139.74989309481694 34.315 35.668688057564545 139.74989844000802 34.315 35.668688057564545 139.74989844000802 36.303 35.66867639910268 139.74989309481694 36.303 35.66867639910268 139.74989309481694 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13cc083f-5cb3-423c-9772-df585cdd2f49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13cc083f-5cb3-423c-9772-df585cdd2f49_0">
											<gml:posList>35.66867146526676 139.74990130714775 34.315 35.6686740907082 139.74989182692622 34.315 35.6686740907082 139.74989182692622 36.129 35.66867146526676 139.74990130714775 36.129 35.66867146526676 139.74990130714775 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd434567-38e4-492f-8e5f-430b1d3297f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd434567-38e4-492f-8e5f-430b1d3297f4_0">
											<gml:posList>35.668661339919375 139.74989708705638 34.315 35.66867146526676 139.74990130714775 34.315 35.66867146526676 139.74990130714775 36.129 35.668661339919375 139.74989708705638 36.129 35.668661339919375 139.74989708705638 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fc82812d-9115-4829-993f-78b88d67054e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc82812d-9115-4829-993f-78b88d67054e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc82812d-9115-4829-993f-78b88d67054e">
											<gml:posList>35.668478479093906 139.749846222732 5.21 35.668536940363715 139.749661804015 5.21 35.668627378054886 139.74970489957613 5.21 35.66860930018685 139.74976213679562 5.21 35.66881875841358 139.74986188519415 5.21 35.668789977469366 139.7499528240754 5.21 35.668765571145315 139.7499830051387 5.21 35.668478479093906 139.749846222732 5.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1019f7da-afce-4cee-bcdf-dd1746e0ef7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1019f7da-afce-4cee-bcdf-dd1746e0ef7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1019f7da-afce-4cee-bcdf-dd1746e0ef7e">
											<gml:posList>35.66855200730681 139.74966899029008 34.7 35.66855369614321 139.7496736941276 34.7 35.668623548662886 139.74970698022153 34.7 35.668627378054886 139.74970489957613 34.7 35.66855200730681 139.74966899029008 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-559b7c4a-3948-401c-b0c1-798975eaf139">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-559b7c4a-3948-401c-b0c1-798975eaf139">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-559b7c4a-3948-401c-b0c1-798975eaf139">
											<gml:posList>35.66860930018685 139.74976213679562 34.7 35.668627378054886 139.74970489957613 34.7 35.668623548662886 139.74970698022153 34.7 35.66860547079382 139.7497642174378 34.7 35.66860930018685 139.74976213679562 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2e4c2e18-46b5-4fc8-b713-40b578cd380f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e4c2e18-46b5-4fc8-b713-40b578cd380f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e4c2e18-46b5-4fc8-b713-40b578cd380f">
											<gml:posList>35.66850035505033 139.74983267964896 34.7 35.668504193443006 139.74983057691142 34.7 35.66855369614321 139.7496736941276 34.7 35.66855200730681 139.74966899029008 34.7 35.66850035505033 139.74983267964896 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3996a1ca-4257-4aa9-b995-ba22c194ee19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3996a1ca-4257-4aa9-b995-ba22c194ee19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3996a1ca-4257-4aa9-b995-ba22c194ee19">
											<gml:posList>35.66860930018685 139.74976213679562 34.7 35.66860547079382 139.7497642174378 34.7 35.668759575428545 139.74983760133918 34.7 35.66876341384412 139.7498355317331 34.7 35.66860930018685 139.74976213679562 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2cbb284b-0f47-4624-9d54-889e2504c0ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cbb284b-0f47-4624-9d54-889e2504c0ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cbb284b-0f47-4624-9d54-889e2504c0ae">
											<gml:posList>35.66860547079382 139.7497642174378 34.315 35.668623548662886 139.74970698022153 34.315 35.66855369614321 139.7496736941276 34.315 35.668504193443006 139.74983057691142 34.315 35.668728716730385 139.74993489379207 34.315 35.668759575428545 139.74983760133918 34.315 35.66860547079382 139.7497642174378 34.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5ad69f78-929b-4b52-b839-1ffb9cf2c914">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ad69f78-929b-4b52-b839-1ffb9cf2c914">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ad69f78-929b-4b52-b839-1ffb9cf2c914">
											<gml:posList>35.66850035505033 139.74983267964896 28.503 35.66855083809318 139.74967269192283 28.503 35.668538981127206 139.74966707083064 28.503 35.668483002759906 139.7498444506621 28.503 35.66872024101365 139.7499568731647 28.503 35.668726203774725 139.7499376026838 28.503 35.66850035505033 139.74983267964896 28.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20c20b8a-489f-44e9-8b32-89826b108c17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20c20b8a-489f-44e9-8b32-89826b108c17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20c20b8a-489f-44e9-8b32-89826b108c17">
											<gml:posList>35.668723066386775 139.7499627577619 29.3 35.668730423560895 139.74993956448878 29.3 35.668726203774725 139.7499376026838 29.3 35.66872024101365 139.7499568731647 29.3 35.668483002759906 139.7498444506621 29.3 35.668538981127206 139.74966707083064 29.3 35.66855083809318 139.74967269192283 29.3 35.66855200730681 139.74966899029008 29.3 35.668536940363715 139.749661804015 29.3 35.668478479093906 139.749846222732 29.3 35.668723066386775 139.7499627577619 29.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-61eebee8-0f98-402f-950f-ada1214d36c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61eebee8-0f98-402f-950f-ada1214d36c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61eebee8-0f98-402f-950f-ada1214d36c8">
											<gml:posList>35.668764425350034 139.74983836951148 28.753 35.66876341384412 139.7498355317331 28.753 35.668762766272735 139.74983757592437 28.753 35.668764425350034 139.74983836951148 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef13f1da-7e18-4363-9666-8e7d0468c801">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef13f1da-7e18-4363-9666-8e7d0468c801">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef13f1da-7e18-4363-9666-8e7d0468c801">
											<gml:posList>35.66876341384412 139.7498355317331 28.753 35.668764425350034 139.74983836951148 28.753 35.668774884728016 139.74984334038365 28.753 35.668777146292825 139.74984206773425 28.753 35.66876341384412 139.7498355317331 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f5c7ae42-d252-4c1d-9567-02f9a27c784e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5c7ae42-d252-4c1d-9567-02f9a27c784e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5c7ae42-d252-4c1d-9567-02f9a27c784e">
											<gml:posList>35.66874950902166 139.74987939897457 28.497 35.668751168098694 139.7498801925624 28.497 35.66876259225766 139.74988561532265 28.497 35.668774884728016 139.74984334038365 28.497 35.668764425350034 139.74983836951148 28.497 35.668762766272735 139.74983757592437 28.497 35.66874950902166 139.74987939897457 28.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b3f1b5b2-99a1-48e7-a9df-c88e0a2ac2b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3f1b5b2-99a1-48e7-a9df-c88e0a2ac2b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3f1b5b2-99a1-48e7-a9df-c88e0a2ac2b7">
											<gml:posList>35.668777146292825 139.74984206773425 28.753 35.668774884728016 139.74984334038365 28.753 35.66876259225766 139.74988561532265 28.753 35.66876365785242 139.74988846409138 28.753 35.668777146292825 139.74984206773425 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d97b22c2-c45c-4393-b7e4-9c91f461854d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d97b22c2-c45c-4393-b7e4-9c91f461854d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d97b22c2-c45c-4393-b7e4-9c91f461854d">
											<gml:posList>35.66874950902166 139.74987939897457 28.753 35.66874886144188 139.7498814321191 28.753 35.668751168098694 139.7498801925624 28.753 35.66874950902166 139.74987939897457 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-19b0b07c-40c5-4a26-8fa9-c186ad944b63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19b0b07c-40c5-4a26-8fa9-c186ad944b63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19b0b07c-40c5-4a26-8fa9-c186ad944b63">
											<gml:posList>35.66876365785242 139.74988846409138 28.753 35.66876259225766 139.74988561532265 28.753 35.668751168098694 139.7498801925624 28.753 35.66874886144188 139.7498814321191 28.753 35.66876365785242 139.74988846409138 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-69fe45b9-1aad-45cb-9fad-c9234af8f735">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69fe45b9-1aad-45cb-9fad-c9234af8f735">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69fe45b9-1aad-45cb-9fad-c9234af8f735">
											<gml:posList>35.668730423560895 139.74993956448878 34.7 35.668728716730385 139.74993489379207 34.7 35.668504193443006 139.74983057691142 34.7 35.66850035505033 139.74983267964896 34.7 35.668730423560895 139.74993956448878 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d731ac8-2ef0-4fb7-ab95-a7bdf3132a74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d731ac8-2ef0-4fb7-ab95-a7bdf3132a74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d731ac8-2ef0-4fb7-ab95-a7bdf3132a74">
											<gml:posList>35.66876341384412 139.7498355317331 34.7 35.668759575428545 139.74983760133918 34.7 35.668728716730385 139.74993489379207 34.7 35.668730423560895 139.74993956448878 34.7 35.66876341384412 139.7498355317331 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ea6597f-5205-4241-bc96-889fd77106c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ea6597f-5205-4241-bc96-889fd77106c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ea6597f-5205-4241-bc96-889fd77106c0">
											<gml:posList>35.66876365785242 139.74988846409138 25.314 35.66874886144188 139.7498814321191 25.314 35.668733796348995 139.74992893469667 25.314 35.6687532090552 139.74993779551696 25.314 35.66875042981078 139.74994645849966 25.314 35.668765073007116 139.7499535237815 25.314 35.66879660625641 139.74985407661114 25.314 35.668776426910206 139.74984454279613 25.314 35.668764332274485 139.7498861437216 25.314 35.66876365785242 139.74988846409138 25.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c20a205-fdb4-4173-b1a2-9a216d28b0a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c20a205-fdb4-4173-b1a2-9a216d28b0a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c20a205-fdb4-4173-b1a2-9a216d28b0a7">
											<gml:posList>35.668733796348995 139.74992893469667 28.753 35.668730423560895 139.74993956448878 28.753 35.66874966528852 139.74994883419242 28.753 35.6687532090552 139.74993779551696 28.753 35.668733796348995 139.74992893469667 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8372a5b3-23ec-4207-9e82-d32996979ea5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8372a5b3-23ec-4207-9e82-d32996979ea5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8372a5b3-23ec-4207-9e82-d32996979ea5">
											<gml:posList>35.66875042981078 139.74994645849966 25.57 35.66874966528852 139.74994883419242 25.57 35.66876623806486 139.74995682533535 25.57 35.668765073007116 139.7499535237815 25.57 35.66875042981078 139.74994645849966 25.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e8ea3e7-3f06-4a46-aa06-04e638038ffc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e8ea3e7-3f06-4a46-aa06-04e638038ffc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e8ea3e7-3f06-4a46-aa06-04e638038ffc">
											<gml:posList>35.668767173458015 139.74995388611654 22.4 35.66876623806486 139.74995682533535 22.4 35.66876957190496 139.74995503241047 22.4 35.668767173458015 139.74995388611654 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df2315da-9e00-4857-ac2e-d0ec24e9203a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df2315da-9e00-4857-ac2e-d0ec24e9203a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df2315da-9e00-4857-ac2e-d0ec24e9203a">
											<gml:posList>35.668730423560895 139.74993956448878 12.772 35.66872373194951 139.74996065832374 12.772 35.668764298114716 139.7499799798477 12.772 35.6687780049179 139.74996250181016 12.772 35.668730423560895 139.74993956448878 12.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fba3cb5b-4472-4de0-ac4b-db7973c58dc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fba3cb5b-4472-4de0-ac4b-db7973c58dc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fba3cb5b-4472-4de0-ac4b-db7973c58dc0">
											<gml:posList>35.668765571145315 139.7499830051387 13.1 35.66878098945588 139.74996393469215 13.1 35.6687780049179 139.74996250181016 13.1 35.668764298114716 139.7499799798477 13.1 35.66872373194951 139.74996065832374 13.1 35.668723066386775 139.7499627577619 13.1 35.668765571145315 139.7499830051387 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f3d3e1f-eecb-4bb0-92fe-e09f551c33f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f3d3e1f-eecb-4bb0-92fe-e09f551c33f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f3d3e1f-eecb-4bb0-92fe-e09f551c33f3">
											<gml:posList>35.66878098945588 139.74996393469215 22.4 35.66878036494665 139.7499602349181 22.4 35.66876957190496 139.74995503241047 22.4 35.66876623806486 139.74995682533535 22.4 35.66878098945588 139.74996393469215 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8105570b-c028-4c65-97ef-f35d27da2ac1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8105570b-c028-4c65-97ef-f35d27da2ac1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8105570b-c028-4c65-97ef-f35d27da2ac1">
											<gml:posList>35.66879928232259 139.74985261574741 25.57 35.66879660625641 139.74985407661114 25.57 35.668765073007116 139.7499535237815 25.57 35.66876623806486 139.74995682533535 25.57 35.66879928232259 139.74985261574741 25.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ebdd99d4-41bf-4122-94b7-b55a1750911d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebdd99d4-41bf-4122-94b7-b55a1750911d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebdd99d4-41bf-4122-94b7-b55a1750911d">
											<gml:posList>35.668789977469366 139.7499528240754 22.4 35.6687877859098 139.74995105898782 22.4 35.66878036494665 139.7499602349181 22.4 35.66878098945588 139.74996393469215 22.4 35.668789977469366 139.7499528240754 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7bcf435e-659d-4fed-b472-9683fcf85cbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bcf435e-659d-4fed-b472-9683fcf85cbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bcf435e-659d-4fed-b472-9683fcf85cbc">
											<gml:posList>35.668777146292825 139.74984206773425 25.57 35.668776426910206 139.74984454279613 25.57 35.66879660625641 139.74985407661114 25.57 35.66879928232259 139.74985261574741 25.57 35.668777146292825 139.74984206773425 25.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3acf38c7-5461-45fa-9677-6964c59b87f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3acf38c7-5461-45fa-9677-6964c59b87f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3acf38c7-5461-45fa-9677-6964c59b87f6">
											<gml:posList>35.668800745387436 139.74985671230604 22.144 35.66879834693957 139.74985556601462 22.144 35.668767173458015 139.74995388611654 22.144 35.66876957190496 139.74995503241047 22.144 35.66878036494665 139.7499602349181 22.144 35.6687877859098 139.74995105898782 22.144 35.668815433603946 139.7498637002067 22.144 35.668800745387436 139.74985671230604 22.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4321070b-7cde-4e65-b1ec-56e5e29af791">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4321070b-7cde-4e65-b1ec-56e5e29af791">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4321070b-7cde-4e65-b1ec-56e5e29af791">
											<gml:posList>35.668800745387436 139.74985671230604 22.4 35.66879928232259 139.74985261574741 22.4 35.66879834693957 139.74985556601462 22.4 35.668800745387436 139.74985671230604 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-88c4aabe-af13-46b9-850e-fe1677076825">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88c4aabe-af13-46b9-850e-fe1677076825">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88c4aabe-af13-46b9-850e-fe1677076825">
											<gml:posList>35.668789977469366 139.7499528240754 22.4 35.66881875841358 139.74986188519415 22.4 35.668815433603946 139.7498637002067 22.4 35.6687877859098 139.74995105898782 22.4 35.668789977469366 139.7499528240754 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e9581fd-fb86-4aac-8a93-2f16bf7afdb8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e9581fd-fb86-4aac-8a93-2f16bf7afdb8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e9581fd-fb86-4aac-8a93-2f16bf7afdb8">
											<gml:posList>35.66879928232259 139.74985261574741 22.4 35.668800745387436 139.74985671230604 22.4 35.668815433603946 139.7498637002067 22.4 35.66881875841358 139.74986188519415 22.4 35.66879928232259 139.74985261574741 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66c9c75d-6605-46d5-b919-f5101488b978">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66c9c75d-6605-46d5-b919-f5101488b978">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66c9c75d-6605-46d5-b919-f5101488b978">
											<gml:posList>35.66860547079382 139.7497642174378 34.7 35.66860547079382 139.7497642174378 34.315 35.668759575428545 139.74983760133918 34.315 35.668759575428545 139.74983760133918 34.7 35.66860547079382 139.7497642174378 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9dde081b-666e-407b-bcef-5abc5ef7a6be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dde081b-666e-407b-bcef-5abc5ef7a6be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dde081b-666e-407b-bcef-5abc5ef7a6be">
											<gml:posList>35.668536940363715 139.749661804015 5.21 35.668478479093906 139.749846222732 5.21 35.668478479093906 139.749846222732 29.3 35.668536940363715 139.749661804015 29.3 35.668536940363715 139.749661804015 5.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23f50a9f-275a-4c9a-b7e5-6e1f1453c9a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23f50a9f-275a-4c9a-b7e5-6e1f1453c9a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23f50a9f-275a-4c9a-b7e5-6e1f1453c9a7">
											<gml:posList>35.668483002759906 139.7498444506621 29.3 35.668483002759906 139.7498444506621 28.503 35.668538981127206 139.74966707083064 28.503 35.668538981127206 139.74966707083064 29.3 35.668483002759906 139.7498444506621 29.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ece4db8-1690-4222-82d5-506d7d603351">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ece4db8-1690-4222-82d5-506d7d603351">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ece4db8-1690-4222-82d5-506d7d603351">
											<gml:posList>35.66850035505033 139.74983267964896 28.503 35.66850035505033 139.74983267964896 34.7 35.66855200730681 139.74966899029008 34.7 35.66855200730681 139.74966899029008 29.3 35.66855083809318 139.74967269192283 29.3 35.66855083809318 139.74967269192283 28.503 35.66850035505033 139.74983267964896 28.503</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df4c6cd4-0913-433d-a127-72af68c6067c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df4c6cd4-0913-433d-a127-72af68c6067c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df4c6cd4-0913-433d-a127-72af68c6067c">
											<gml:posList>35.668504193443006 139.74983057691142 34.7 35.668504193443006 139.74983057691142 34.315 35.66855369614321 139.7496736941276 34.315 35.66855369614321 139.7496736941276 34.7 35.668504193443006 139.74983057691142 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e8d08e8-b0a6-4908-a145-1219db4145f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e8d08e8-b0a6-4908-a145-1219db4145f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e8d08e8-b0a6-4908-a145-1219db4145f9">
											<gml:posList>35.668538981127206 139.74966707083064 29.3 35.668538981127206 139.74966707083064 28.503 35.66855083809318 139.74967269192283 28.503 35.66855083809318 139.74967269192283 29.3 35.668538981127206 139.74966707083064 29.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d7fa184-314f-4ba5-8c63-0f6d9adeb5f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d7fa184-314f-4ba5-8c63-0f6d9adeb5f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d7fa184-314f-4ba5-8c63-0f6d9adeb5f1">
											<gml:posList>35.66855200730681 139.74966899029008 29.3 35.66855200730681 139.74966899029008 34.7 35.668627378054886 139.74970489957613 34.7 35.668627378054886 139.74970489957613 5.21 35.668536940363715 139.749661804015 5.21 35.668536940363715 139.749661804015 29.3 35.66855200730681 139.74966899029008 29.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc6894b3-6263-4574-9957-90cce30ded2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc6894b3-6263-4574-9957-90cce30ded2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc6894b3-6263-4574-9957-90cce30ded2a">
											<gml:posList>35.66855369614321 139.7496736941276 34.7 35.66855369614321 139.7496736941276 34.315 35.668623548662886 139.74970698022153 34.315 35.668623548662886 139.74970698022153 34.7 35.66855369614321 139.7496736941276 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e0957ac-6710-4d17-a846-3d48dbc50dac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e0957ac-6710-4d17-a846-3d48dbc50dac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e0957ac-6710-4d17-a846-3d48dbc50dac">
											<gml:posList>35.66872024101365 139.7499568731647 29.3 35.66872024101365 139.7499568731647 28.503 35.668483002759906 139.7498444506621 28.503 35.668483002759906 139.7498444506621 29.3 35.66872024101365 139.7499568731647 29.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5dc3d500-0ff4-4431-9e6b-961ce61348d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5dc3d500-0ff4-4431-9e6b-961ce61348d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5dc3d500-0ff4-4431-9e6b-961ce61348d9">
											<gml:posList>35.668623548662886 139.74970698022153 34.7 35.668623548662886 139.74970698022153 34.315 35.66860547079382 139.7497642174378 34.315 35.66860547079382 139.7497642174378 34.7 35.668623548662886 139.74970698022153 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-524242e8-0cee-45b8-bb83-227573846aed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-524242e8-0cee-45b8-bb83-227573846aed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-524242e8-0cee-45b8-bb83-227573846aed">
											<gml:posList>35.668730423560895 139.74993956448878 34.7 35.66850035505033 139.74983267964896 34.7 35.66850035505033 139.74983267964896 28.503 35.668726203774725 139.7499376026838 28.503 35.668726203774725 139.7499376026838 29.3 35.668730423560895 139.74993956448878 29.3 35.668730423560895 139.74993956448878 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ce07657-69bb-4a5d-9c2d-fc572311699f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ce07657-69bb-4a5d-9c2d-fc572311699f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ce07657-69bb-4a5d-9c2d-fc572311699f">
											<gml:posList>35.668728716730385 139.74993489379207 34.7 35.668728716730385 139.74993489379207 34.315 35.668504193443006 139.74983057691142 34.315 35.668504193443006 139.74983057691142 34.7 35.668728716730385 139.74993489379207 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03927c0d-6eeb-4155-b44f-6de40279f52c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03927c0d-6eeb-4155-b44f-6de40279f52c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03927c0d-6eeb-4155-b44f-6de40279f52c">
											<gml:posList>35.668627378054886 139.74970489957613 34.7 35.66860930018685 139.74976213679562 34.7 35.66860930018685 139.74976213679562 5.21 35.668627378054886 139.74970489957613 5.21 35.668627378054886 139.74970489957613 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d9a00f3-1eca-4682-8bce-c2c408126ddf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d9a00f3-1eca-4682-8bce-c2c408126ddf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d9a00f3-1eca-4682-8bce-c2c408126ddf">
											<gml:posList>35.668723066386775 139.7499627577619 25.314 35.668723066386775 139.7499627577619 29.3 35.668478479093906 139.749846222732 29.3 35.668478479093906 139.749846222732 5.21 35.668765571145315 139.7499830051387 5.21 35.668765571145315 139.7499830051387 13.1 35.668723066386775 139.7499627577619 13.1 35.668723066386775 139.7499627577619 25.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3028d576-3513-43ca-935b-1e4f2e0ad9b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3028d576-3513-43ca-935b-1e4f2e0ad9b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3028d576-3513-43ca-935b-1e4f2e0ad9b9">
											<gml:posList>35.668777146292825 139.74984206773425 25.57 35.66879928232259 139.74985261574741 25.57 35.66879928232259 139.74985261574741 22.4 35.66881875841358 139.74986188519415 22.4 35.66881875841358 139.74986188519415 5.21 35.66860930018685 139.74976213679562 5.21 35.66860930018685 139.74976213679562 34.7 35.66876341384412 139.7498355317331 34.7 35.66876341384412 139.7498355317331 28.753 35.668777146292825 139.74984206773425 28.753 35.668777146292825 139.74984206773425 25.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1868b2a0-a7e7-4732-8e85-a6284ec88ea5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1868b2a0-a7e7-4732-8e85-a6284ec88ea5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1868b2a0-a7e7-4732-8e85-a6284ec88ea5">
											<gml:posList>35.668726203774725 139.7499376026838 29.3 35.668726203774725 139.7499376026838 28.503 35.66872024101365 139.7499568731647 28.503 35.66872024101365 139.7499568731647 29.3 35.668726203774725 139.7499376026838 29.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64e88694-dfe1-418b-ae12-f30c0b4aabef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64e88694-dfe1-418b-ae12-f30c0b4aabef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64e88694-dfe1-418b-ae12-f30c0b4aabef">
											<gml:posList>35.668723066386775 139.7499627577619 25.314 35.668723066386775 139.7499627577619 13.1 35.66872373194951 139.74996065832374 13.1 35.66872373194951 139.74996065832374 12.772 35.668730423560895 139.74993956448878 12.772 35.668730423560895 139.74993956448878 25.314 35.668723066386775 139.7499627577619 25.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd2064ca-14ff-4df3-ae15-5404d6171b4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd2064ca-14ff-4df3-ae15-5404d6171b4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd2064ca-14ff-4df3-ae15-5404d6171b4a">
											<gml:posList>35.668733796348995 139.74992893469667 28.753 35.668733796348995 139.74992893469667 25.314 35.66874886144188 139.7498814321191 25.314 35.66874886144188 139.7498814321191 28.753 35.66874950902166 139.74987939897457 28.753 35.66874950902166 139.74987939897457 28.497 35.668762766272735 139.74983757592437 28.497 35.668762766272735 139.74983757592437 28.753 35.66876341384412 139.7498355317331 28.753 35.66876341384412 139.7498355317331 34.7 35.668730423560895 139.74993956448878 34.7 35.668730423560895 139.74993956448878 29.3 35.668723066386775 139.7499627577619 29.3 35.668723066386775 139.7499627577619 25.314 35.668730423560895 139.74993956448878 25.314 35.668730423560895 139.74993956448878 28.753 35.668733796348995 139.74992893469667 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0a04d7d-9c89-4b65-8f26-a01e5a20f720">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0a04d7d-9c89-4b65-8f26-a01e5a20f720">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0a04d7d-9c89-4b65-8f26-a01e5a20f720">
											<gml:posList>35.668733796348995 139.74992893469667 28.753 35.6687532090552 139.74993779551696 28.753 35.6687532090552 139.74993779551696 25.57 35.6687532090552 139.74993779551696 25.314 35.668733796348995 139.74992893469667 25.314 35.668733796348995 139.74992893469667 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e95710a1-b189-4c42-8fea-90559d2de159">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e95710a1-b189-4c42-8fea-90559d2de159">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e95710a1-b189-4c42-8fea-90559d2de159">
											<gml:posList>35.668764298114716 139.7499799798477 13.1 35.668764298114716 139.7499799798477 12.772 35.66872373194951 139.74996065832374 12.772 35.66872373194951 139.74996065832374 13.1 35.668764298114716 139.7499799798477 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2aa53994-4d35-42dd-8547-6a744ee2673e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2aa53994-4d35-42dd-8547-6a744ee2673e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2aa53994-4d35-42dd-8547-6a744ee2673e">
											<gml:posList>35.668759575428545 139.74983760133918 34.7 35.668759575428545 139.74983760133918 34.315 35.668728716730385 139.74993489379207 34.315 35.668728716730385 139.74993489379207 34.7 35.668759575428545 139.74983760133918 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83e82a56-ebc1-4732-819d-11f9c530dc32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83e82a56-ebc1-4732-819d-11f9c530dc32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83e82a56-ebc1-4732-819d-11f9c530dc32">
											<gml:posList>35.668751168098694 139.7498801925624 28.753 35.668751168098694 139.7498801925624 28.497 35.66874950902166 139.74987939897457 28.497 35.66874950902166 139.74987939897457 28.753 35.668751168098694 139.7498801925624 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4dc204b8-b51d-4e85-88d6-1bccef8e1dd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4dc204b8-b51d-4e85-88d6-1bccef8e1dd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4dc204b8-b51d-4e85-88d6-1bccef8e1dd3">
											<gml:posList>35.6687532090552 139.74993779551696 28.753 35.66874966528852 139.74994883419242 28.753 35.66874966528852 139.74994883419242 25.57 35.66875042981078 139.74994645849966 25.57 35.6687532090552 139.74993779551696 25.57 35.6687532090552 139.74993779551696 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e6933b2-038e-4aa8-a89b-984f52dbf66b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e6933b2-038e-4aa8-a89b-984f52dbf66b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e6933b2-038e-4aa8-a89b-984f52dbf66b">
											<gml:posList>35.6687532090552 139.74993779551696 25.57 35.66875042981078 139.74994645849966 25.57 35.66875042981078 139.74994645849966 25.314 35.6687532090552 139.74993779551696 25.314 35.6687532090552 139.74993779551696 25.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a4bc6dc-2a17-4646-9721-fdbef9cde528">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a4bc6dc-2a17-4646-9721-fdbef9cde528">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a4bc6dc-2a17-4646-9721-fdbef9cde528">
											<gml:posList>35.6687780049179 139.74996250181016 13.1 35.66878098945588 139.74996393469215 13.1 35.66878098945588 139.74996393469215 22.4 35.66876623806486 139.74995682533535 22.4 35.66876623806486 139.74995682533535 25.57 35.66874966528852 139.74994883419242 25.57 35.66874966528852 139.74994883419242 28.753 35.668730423560895 139.74993956448878 28.753 35.668730423560895 139.74993956448878 25.314 35.668730423560895 139.74993956448878 12.772 35.6687780049179 139.74996250181016 12.772 35.6687780049179 139.74996250181016 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcd056ca-cf59-48ff-8297-39e8553e8c46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcd056ca-cf59-48ff-8297-39e8553e8c46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcd056ca-cf59-48ff-8297-39e8553e8c46">
											<gml:posList>35.66876365785242 139.74988846409138 25.314 35.66876365785242 139.74988846409138 28.753 35.66874886144188 139.7498814321191 28.753 35.66874886144188 139.7498814321191 25.314 35.66876365785242 139.74988846409138 25.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b17cfc8a-21ae-4699-a5db-0fb18672bda3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b17cfc8a-21ae-4699-a5db-0fb18672bda3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b17cfc8a-21ae-4699-a5db-0fb18672bda3">
											<gml:posList>35.66876259225766 139.74988561532265 28.753 35.66876259225766 139.74988561532265 28.497 35.668751168098694 139.7498801925624 28.497 35.668751168098694 139.7498801925624 28.753 35.66876259225766 139.74988561532265 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-558e286d-d358-4234-88df-10da973246b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-558e286d-d358-4234-88df-10da973246b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-558e286d-d358-4234-88df-10da973246b5">
											<gml:posList>35.66875042981078 139.74994645849966 25.57 35.668765073007116 139.7499535237815 25.57 35.668765073007116 139.7499535237815 25.314 35.66875042981078 139.74994645849966 25.314 35.66875042981078 139.74994645849966 25.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e28c811-2eeb-4343-8605-fff9a6763928">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e28c811-2eeb-4343-8605-fff9a6763928">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e28c811-2eeb-4343-8605-fff9a6763928">
											<gml:posList>35.668762766272735 139.74983757592437 28.753 35.668762766272735 139.74983757592437 28.497 35.668764425350034 139.74983836951148 28.497 35.668764425350034 139.74983836951148 28.753 35.668762766272735 139.74983757592437 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc036b8b-08c7-4502-a36e-d36a549d504f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc036b8b-08c7-4502-a36e-d36a549d504f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc036b8b-08c7-4502-a36e-d36a549d504f">
											<gml:posList>35.66876957190496 139.74995503241047 22.4 35.66876957190496 139.74995503241047 22.144 35.668767173458015 139.74995388611654 22.144 35.668767173458015 139.74995388611654 22.4 35.66876957190496 139.74995503241047 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f651e46b-3de6-45ab-ab51-97ab76fab78b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f651e46b-3de6-45ab-ab51-97ab76fab78b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f651e46b-3de6-45ab-ab51-97ab76fab78b">
											<gml:posList>35.668774884728016 139.74984334038365 28.753 35.668774884728016 139.74984334038365 28.497 35.66876259225766 139.74988561532265 28.497 35.66876259225766 139.74988561532265 28.753 35.668774884728016 139.74984334038365 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-677aba57-50e5-4d20-b5e8-3e56500965ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-677aba57-50e5-4d20-b5e8-3e56500965ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-677aba57-50e5-4d20-b5e8-3e56500965ed">
											<gml:posList>35.668764425350034 139.74983836951148 28.753 35.668764425350034 139.74983836951148 28.497 35.668774884728016 139.74984334038365 28.497 35.668774884728016 139.74984334038365 28.753 35.668764425350034 139.74983836951148 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1d99ee8-48f6-492d-963a-e5a4f6735013">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1d99ee8-48f6-492d-963a-e5a4f6735013">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1d99ee8-48f6-492d-963a-e5a4f6735013">
											<gml:posList>35.66876365785242 139.74988846409138 28.753 35.66876365785242 139.74988846409138 25.314 35.668764332274485 139.7498861437216 25.314 35.668776426910206 139.74984454279613 25.314 35.668776426910206 139.74984454279613 25.57 35.668777146292825 139.74984206773425 25.57 35.668777146292825 139.74984206773425 28.753 35.66876365785242 139.74988846409138 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62486e69-dec2-456a-afd3-3428d9e7af28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62486e69-dec2-456a-afd3-3428d9e7af28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62486e69-dec2-456a-afd3-3428d9e7af28">
											<gml:posList>35.6687780049179 139.74996250181016 13.1 35.6687780049179 139.74996250181016 12.772 35.668764298114716 139.7499799798477 12.772 35.668764298114716 139.7499799798477 13.1 35.6687780049179 139.74996250181016 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a793e04-6ba8-426e-af47-848f418f9135">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a793e04-6ba8-426e-af47-848f418f9135">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a793e04-6ba8-426e-af47-848f418f9135">
											<gml:posList>35.66878036494665 139.7499602349181 22.4 35.66878036494665 139.7499602349181 22.144 35.66876957190496 139.74995503241047 22.144 35.66876957190496 139.74995503241047 22.4 35.66878036494665 139.7499602349181 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-682152c5-eff7-4451-8084-9e5352396a64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-682152c5-eff7-4451-8084-9e5352396a64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-682152c5-eff7-4451-8084-9e5352396a64">
											<gml:posList>35.668789977469366 139.7499528240754 5.21 35.668789977469366 139.7499528240754 22.4 35.66878098945588 139.74996393469215 22.4 35.66878098945588 139.74996393469215 13.1 35.668765571145315 139.7499830051387 13.1 35.668765571145315 139.7499830051387 5.21 35.668789977469366 139.7499528240754 5.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f96b5d60-95be-49b6-8771-c857839b16f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f96b5d60-95be-49b6-8771-c857839b16f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f96b5d60-95be-49b6-8771-c857839b16f2">
											<gml:posList>35.66879660625641 139.74985407661114 25.57 35.66879660625641 139.74985407661114 25.314 35.668765073007116 139.7499535237815 25.314 35.668765073007116 139.7499535237815 25.57 35.66879660625641 139.74985407661114 25.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8f1602a-23f8-47d3-b450-712ffbaa237a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8f1602a-23f8-47d3-b450-712ffbaa237a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8f1602a-23f8-47d3-b450-712ffbaa237a">
											<gml:posList>35.668767173458015 139.74995388611654 22.4 35.668767173458015 139.74995388611654 22.144 35.66879834693957 139.74985556601462 22.144 35.66879834693957 139.74985556601462 22.4 35.66879928232259 139.74985261574741 22.4 35.66879928232259 139.74985261574741 25.57 35.66876623806486 139.74995682533535 25.57 35.66876623806486 139.74995682533535 22.4 35.668767173458015 139.74995388611654 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-451ecbd8-2117-464f-bdea-fc36df1e8d1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-451ecbd8-2117-464f-bdea-fc36df1e8d1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-451ecbd8-2117-464f-bdea-fc36df1e8d1b">
											<gml:posList>35.6687877859098 139.74995105898782 22.4 35.6687877859098 139.74995105898782 22.144 35.66878036494665 139.7499602349181 22.144 35.66878036494665 139.7499602349181 22.4 35.6687877859098 139.74995105898782 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-684b36f5-dbf7-46a5-a4b3-f4641e1ec4ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-684b36f5-dbf7-46a5-a4b3-f4641e1ec4ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-684b36f5-dbf7-46a5-a4b3-f4641e1ec4ee">
											<gml:posList>35.668776426910206 139.74984454279613 25.57 35.668776426910206 139.74984454279613 25.314 35.66879660625641 139.74985407661114 25.314 35.66879660625641 139.74985407661114 25.57 35.668776426910206 139.74984454279613 25.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea2a2bd3-f4f6-4b33-84ba-fa9eead4f464">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea2a2bd3-f4f6-4b33-84ba-fa9eead4f464">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea2a2bd3-f4f6-4b33-84ba-fa9eead4f464">
											<gml:posList>35.66879834693957 139.74985556601462 22.4 35.66879834693957 139.74985556601462 22.144 35.668800745387436 139.74985671230604 22.144 35.668800745387436 139.74985671230604 22.4 35.66879834693957 139.74985556601462 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b900bda-2ddb-4f74-ac1d-f6691ac76954">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b900bda-2ddb-4f74-ac1d-f6691ac76954">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b900bda-2ddb-4f74-ac1d-f6691ac76954">
											<gml:posList>35.668815433603946 139.7498637002067 22.4 35.668815433603946 139.7498637002067 22.144 35.6687877859098 139.74995105898782 22.144 35.6687877859098 139.74995105898782 22.4 35.668815433603946 139.7498637002067 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17b135cb-09e5-4d20-9634-2c393454894a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17b135cb-09e5-4d20-9634-2c393454894a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17b135cb-09e5-4d20-9634-2c393454894a">
											<gml:posList>35.668789977469366 139.7499528240754 5.21 35.66881875841358 139.74986188519415 5.21 35.66881875841358 139.74986188519415 22.4 35.668789977469366 139.7499528240754 22.4 35.668789977469366 139.7499528240754 5.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1cfa42fb-f0f1-4f6a-a449-671f815ad678">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cfa42fb-f0f1-4f6a-a449-671f815ad678">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cfa42fb-f0f1-4f6a-a449-671f815ad678">
											<gml:posList>35.668800745387436 139.74985671230604 22.4 35.668800745387436 139.74985671230604 22.144 35.668815433603946 139.7498637002067 22.144 35.668815433603946 139.7498637002067 22.4 35.668800745387436 139.74985671230604 22.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-18</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">498.29205</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>