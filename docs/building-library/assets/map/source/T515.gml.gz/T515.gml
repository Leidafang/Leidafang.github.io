<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_95d22c86-f75b-4dee-84da-32b24b8f2664">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="説明注記">
				<gen:value>料金所</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>8</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101008003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3003</bldg:class>
			<bldg:measuredHeight uom="m">6.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.673258780874704 139.74735541568015 0 35.67329432127145 139.7473922734144 0 35.6733361001321 139.74732948355665 0 35.673342403029 139.74732008712698 0 35.67329766435287 139.74727727407824 0 35.67327006183918 139.7472485823962 0 35.67325346514166 139.7472325825664 0 35.67323984423369 139.74721834701128 0 35.67323624261672 139.7472237637403 0 35.67319365368086 139.7472881009749 0 35.673258780874704 139.74735541568015 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673258780874704 139.74735541568015 14.852 35.67319365368086 139.7472881009749 14.852 35.67323624261672 139.7472237637403 14.852 35.67323984423369 139.74721834701128 14.852 35.67325346514166 139.7472325825664 14.852 35.67327006183918 139.7472485823962 14.852 35.67329766435287 139.74727727407824 14.852 35.673342403029 139.74732008712698 14.852 35.6733361001321 139.74732948355665 14.852 35.67329432127145 139.7473922734144 14.852 35.673258780874704 139.74735541568015 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673258780874704 139.74735541568015 14.852 35.67329432127145 139.7473922734144 14.852 35.67329432127145 139.7473922734144 21.49 35.673258780874704 139.74735541568015 21.49 35.673258780874704 139.74735541568015 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67329432127145 139.7473922734144 14.852 35.6733361001321 139.74732948355665 14.852 35.6733361001321 139.74732948355665 21.49 35.67329432127145 139.7473922734144 21.49 35.67329432127145 139.7473922734144 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6733361001321 139.74732948355665 14.852 35.673342403029 139.74732008712698 14.852 35.673342403029 139.74732008712698 21.49 35.6733361001321 139.74732948355665 21.49 35.6733361001321 139.74732948355665 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673342403029 139.74732008712698 14.852 35.67329766435287 139.74727727407824 14.852 35.67329766435287 139.74727727407824 21.49 35.673342403029 139.74732008712698 21.49 35.673342403029 139.74732008712698 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67329766435287 139.74727727407824 14.852 35.67327006183918 139.7472485823962 14.852 35.67327006183918 139.7472485823962 21.49 35.67329766435287 139.74727727407824 21.49 35.67329766435287 139.74727727407824 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67327006183918 139.7472485823962 14.852 35.67325346514166 139.7472325825664 14.852 35.67325346514166 139.7472325825664 21.49 35.67327006183918 139.7472485823962 21.49 35.67327006183918 139.7472485823962 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67325346514166 139.7472325825664 14.852 35.67323984423369 139.74721834701128 14.852 35.67323984423369 139.74721834701128 21.49 35.67325346514166 139.7472325825664 21.49 35.67325346514166 139.7472325825664 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67323984423369 139.74721834701128 14.852 35.67323624261672 139.7472237637403 14.852 35.67323624261672 139.7472237637403 21.49 35.67323984423369 139.74721834701128 21.49 35.67323984423369 139.74721834701128 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67323624261672 139.7472237637403 14.852 35.67319365368086 139.7472881009749 14.852 35.67319365368086 139.7472881009749 21.49 35.67323624261672 139.7472237637403 21.49 35.67323624261672 139.7472237637403 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67319365368086 139.7472881009749 14.852 35.673258780874704 139.74735541568015 14.852 35.673258780874704 139.74735541568015 21.49 35.67319365368086 139.7472881009749 21.49 35.67319365368086 139.7472881009749 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673258780874704 139.74735541568015 21.49 35.67329432127145 139.7473922734144 21.49 35.6733361001321 139.74732948355665 21.49 35.673342403029 139.74732008712698 21.49 35.67329766435287 139.74727727407824 21.49 35.67327006183918 139.7472485823962 21.49 35.67325346514166 139.7472325825664 21.49 35.67323984423369 139.74721834701128 21.49 35.67323624261672 139.7472237637403 21.49 35.67319365368086 139.7472881009749 21.49 35.673258780874704 139.74735541568015 21.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-422b8432-566f-4d54-9c95-4ad722cbd635"/>
							<gml:surfaceMember xlink:href="#poly-ef41c36f-22e2-4d9b-9214-612488945460"/>
							<gml:surfaceMember xlink:href="#poly-c379b0bc-c52a-47c9-8d25-e6210db808aa"/>
							<gml:surfaceMember xlink:href="#poly-10144547-4453-4593-819e-7bdc34e1dbbd"/>
							<gml:surfaceMember xlink:href="#poly-6d24eb39-da4e-4731-9b12-6aeb88a7c9e0"/>
							<gml:surfaceMember xlink:href="#poly-5412f90b-c3e8-43dc-b126-c5b7b1ca12a3"/>
							<gml:surfaceMember xlink:href="#poly-646511fb-bf64-46d3-9b49-ab653aa5aa04"/>
							<gml:surfaceMember xlink:href="#poly-3dfc9dfc-6c7f-418b-9e69-480d1e934a74"/>
							<gml:surfaceMember xlink:href="#poly-8112df31-7daa-445a-adcd-3552fde8b849"/>
							<gml:surfaceMember xlink:href="#poly-15016510-826d-4120-bf53-1adf9b7373ae"/>
							<gml:surfaceMember xlink:href="#poly-67e20e33-49d5-48c7-823f-8adbc89ebf76"/>
							<gml:surfaceMember xlink:href="#poly-1bccd37d-3050-4e08-8d86-d81a5e2a923c"/>
							<gml:surfaceMember xlink:href="#poly-8062c313-db71-4ef6-b7a7-3f90a1e449d0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-422b8432-566f-4d54-9c95-4ad722cbd635">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-422b8432-566f-4d54-9c95-4ad722cbd635">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-422b8432-566f-4d54-9c95-4ad722cbd635">
											<gml:posList>35.67323624261672 139.7472237637403 14.852 35.67323984423366 139.7472183470113 14.852 35.67325346514165 139.74723258256637 14.852 35.67327006183917 139.7472485823962 14.852 35.673297664352866 139.74727727407824 14.852 35.673342403028975 139.74732008712698 14.852 35.673336100132076 139.74732948355663 14.852 35.67329432127145 139.7473922734144 14.852 35.67325878087469 139.74735541568015 14.852 35.67319365368085 139.7472881009749 14.852 35.67323624261672 139.7472237637403 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef41c36f-22e2-4d9b-9214-612488945460">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef41c36f-22e2-4d9b-9214-612488945460">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef41c36f-22e2-4d9b-9214-612488945460">
											<gml:posList>35.673336100132076 139.74732948355663 20.4 35.673342403028975 139.74732008712698 20.4 35.673297664352866 139.74727727407824 20.4 35.67327006183917 139.7472485823962 20.4 35.67325346514165 139.74723258256637 20.4 35.67323984423366 139.7472183470113 20.4 35.67323624261672 139.7472237637403 20.4 35.67319365368085 139.7472881009749 20.4 35.67325878087469 139.74735541568015 20.4 35.67329432127145 139.7473922734144 20.4 35.673336100132076 139.74732948355663 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c379b0bc-c52a-47c9-8d25-e6210db808aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c379b0bc-c52a-47c9-8d25-e6210db808aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c379b0bc-c52a-47c9-8d25-e6210db808aa">
											<gml:posList>35.67325346514165 139.74723258256637 14.852 35.67323984423366 139.7472183470113 20.4 35.67325346514165 139.74723258256637 20.4 35.67325346514165 139.74723258256637 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10144547-4453-4593-819e-7bdc34e1dbbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10144547-4453-4593-819e-7bdc34e1dbbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10144547-4453-4593-819e-7bdc34e1dbbd">
											<gml:posList>35.67325346514165 139.74723258256637 14.852 35.67323984423366 139.7472183470113 14.852 35.67323984423366 139.7472183470113 20.4 35.67325346514165 139.74723258256637 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d24eb39-da4e-4731-9b12-6aeb88a7c9e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d24eb39-da4e-4731-9b12-6aeb88a7c9e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d24eb39-da4e-4731-9b12-6aeb88a7c9e0">
											<gml:posList>35.67325346514165 139.74723258256637 14.852 35.67325346514165 139.74723258256637 20.4 35.67327006183917 139.7472485823962 14.852 35.67325346514165 139.74723258256637 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5412f90b-c3e8-43dc-b126-c5b7b1ca12a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5412f90b-c3e8-43dc-b126-c5b7b1ca12a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5412f90b-c3e8-43dc-b126-c5b7b1ca12a3">
											<gml:posList>35.67325346514165 139.74723258256637 20.4 35.67327006183917 139.7472485823962 20.4 35.67327006183917 139.7472485823962 14.852 35.67325346514165 139.74723258256637 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-646511fb-bf64-46d3-9b49-ab653aa5aa04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-646511fb-bf64-46d3-9b49-ab653aa5aa04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-646511fb-bf64-46d3-9b49-ab653aa5aa04">
											<gml:posList>35.67323624261672 139.7472237637403 14.852 35.67319365368085 139.7472881009749 14.852 35.67319365368085 139.7472881009749 20.4 35.67323624261672 139.7472237637403 20.4 35.67323984423366 139.7472183470113 20.4 35.67323984423366 139.7472183470113 14.852 35.67323624261672 139.7472237637403 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3dfc9dfc-6c7f-418b-9e69-480d1e934a74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3dfc9dfc-6c7f-418b-9e69-480d1e934a74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3dfc9dfc-6c7f-418b-9e69-480d1e934a74">
											<gml:posList>35.67325878087469 139.74735541568015 14.852 35.67329432127145 139.7473922734144 14.852 35.67329432127145 139.7473922734144 20.4 35.67325878087469 139.74735541568015 20.4 35.67319365368085 139.7472881009749 20.4 35.67319365368085 139.7472881009749 14.852 35.67325878087469 139.74735541568015 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8112df31-7daa-445a-adcd-3552fde8b849">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8112df31-7daa-445a-adcd-3552fde8b849">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8112df31-7daa-445a-adcd-3552fde8b849">
											<gml:posList>35.67327006183917 139.7472485823962 20.4 35.673297664352866 139.74727727407824 14.852 35.67327006183917 139.7472485823962 14.852 35.67327006183917 139.7472485823962 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15016510-826d-4120-bf53-1adf9b7373ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15016510-826d-4120-bf53-1adf9b7373ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15016510-826d-4120-bf53-1adf9b7373ae">
											<gml:posList>35.67327006183917 139.7472485823962 20.4 35.673297664352866 139.74727727407824 20.4 35.673297664352866 139.74727727407824 14.852 35.67327006183917 139.7472485823962 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67e20e33-49d5-48c7-823f-8adbc89ebf76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67e20e33-49d5-48c7-823f-8adbc89ebf76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67e20e33-49d5-48c7-823f-8adbc89ebf76">
											<gml:posList>35.673297664352866 139.74727727407824 20.4 35.673342403028975 139.74732008712698 20.4 35.673342403028975 139.74732008712698 14.852 35.673297664352866 139.74727727407824 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1bccd37d-3050-4e08-8d86-d81a5e2a923c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bccd37d-3050-4e08-8d86-d81a5e2a923c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bccd37d-3050-4e08-8d86-d81a5e2a923c">
											<gml:posList>35.673297664352866 139.74727727407824 20.4 35.673342403028975 139.74732008712698 14.852 35.673297664352866 139.74727727407824 14.852 35.673297664352866 139.74727727407824 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8062c313-db71-4ef6-b7a7-3f90a1e449d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8062c313-db71-4ef6-b7a7-3f90a1e449d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8062c313-db71-4ef6-b7a7-3f90a1e449d0">
											<gml:posList>35.673336100132076 139.74732948355663 14.852 35.673342403028975 139.74732008712698 14.852 35.673342403028975 139.74732008712698 20.4 35.673336100132076 139.74732948355663 20.4 35.67329432127145 139.7473922734144 20.4 35.67329432127145 139.7473922734144 14.852 35.673336100132076 139.74732948355663 14.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区霞が関三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4535</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">120.37555</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>