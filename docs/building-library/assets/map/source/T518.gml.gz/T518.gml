<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9621a8e3-47ce-4a99-b951-bb024db034f5">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">32.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66931527100212 139.74836705006416 0 35.66931058191588 139.74836429350492 0 35.66932623835642 139.74832539458865 0 35.66921541230739 139.74825846226128 0 35.66914693799201 139.7484287551664 0 35.66925568993474 139.74849447479525 0 35.669303640142566 139.74837536906531 0 35.66931032218169 139.74837942695473 0 35.66931527100212 139.74836705006416 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66931527100212 139.74836705006416 5.78 35.66931032218169 139.74837942695473 5.78 35.669303640142566 139.74837536906531 5.78 35.66925568993474 139.74849447479525 5.78 35.66914693799201 139.7484287551664 5.78 35.66921541230739 139.74825846226128 5.78 35.66932623835642 139.74832539458865 5.78 35.66931058191588 139.74836429350492 5.78 35.66931527100212 139.74836705006416 5.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66931527100212 139.74836705006416 5.78 35.66931058191588 139.74836429350492 5.78 35.66931058191588 139.74836429350492 38.44 35.66931527100212 139.74836705006416 38.44 35.66931527100212 139.74836705006416 5.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66931058191588 139.74836429350492 5.78 35.66932623835642 139.74832539458865 5.78 35.66932623835642 139.74832539458865 38.44 35.66931058191588 139.74836429350492 38.44 35.66931058191588 139.74836429350492 5.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66932623835642 139.74832539458865 5.78 35.66921541230739 139.74825846226128 5.78 35.66921541230739 139.74825846226128 38.44 35.66932623835642 139.74832539458865 38.44 35.66932623835642 139.74832539458865 5.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66921541230739 139.74825846226128 5.78 35.66914693799201 139.7484287551664 5.78 35.66914693799201 139.7484287551664 38.44 35.66921541230739 139.74825846226128 38.44 35.66921541230739 139.74825846226128 5.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66914693799201 139.7484287551664 5.78 35.66925568993474 139.74849447479525 5.78 35.66925568993474 139.74849447479525 38.44 35.66914693799201 139.7484287551664 38.44 35.66914693799201 139.7484287551664 5.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925568993474 139.74849447479525 5.78 35.669303640142566 139.74837536906531 5.78 35.669303640142566 139.74837536906531 38.44 35.66925568993474 139.74849447479525 38.44 35.66925568993474 139.74849447479525 5.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669303640142566 139.74837536906531 5.78 35.66931032218169 139.74837942695473 5.78 35.66931032218169 139.74837942695473 38.44 35.669303640142566 139.74837536906531 38.44 35.669303640142566 139.74837536906531 5.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66931032218169 139.74837942695473 5.78 35.66931527100212 139.74836705006416 5.78 35.66931527100212 139.74836705006416 38.44 35.66931032218169 139.74837942695473 38.44 35.66931032218169 139.74837942695473 5.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66931527100212 139.74836705006416 38.44 35.66931058191588 139.74836429350492 38.44 35.66932623835642 139.74832539458865 38.44 35.66921541230739 139.74825846226128 38.44 35.66914693799201 139.7484287551664 38.44 35.66925568993474 139.74849447479525 38.44 35.669303640142566 139.74837536906531 38.44 35.66931032218169 139.74837942695473 38.44 35.66931527100212 139.74836705006416 38.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8819a1c1-41db-490d-8c18-73c69d8b381d"/>
							<gml:surfaceMember xlink:href="#poly-ff6b50f2-f8c1-46f6-a1db-c039fb87c39f"/>
							<gml:surfaceMember xlink:href="#poly-7275f5ec-a2e8-4107-ab30-7bc0cc59ddb3"/>
							<gml:surfaceMember xlink:href="#poly-29a9a9ef-7296-4e13-be4e-361e78d46820"/>
							<gml:surfaceMember xlink:href="#poly-f10ca756-5933-4f6d-8216-d0b376bcdc3d"/>
							<gml:surfaceMember xlink:href="#poly-5ddaac20-e62e-4fa2-951f-d0e148aaac0a"/>
							<gml:surfaceMember xlink:href="#poly-36366c9c-28c3-4678-874c-0a1228946921"/>
							<gml:surfaceMember xlink:href="#poly-128c5280-55ff-47f5-b8ad-ce4b0e367bcc"/>
							<gml:surfaceMember xlink:href="#poly-b35b1f62-2ca3-476d-93e0-a61fd99383d8"/>
							<gml:surfaceMember xlink:href="#poly-a6f4bf32-5677-424a-bee4-1f09ecd41537"/>
							<gml:surfaceMember xlink:href="#poly-b9d773b8-3954-4fdb-8df9-00065758c81a"/>
							<gml:surfaceMember xlink:href="#poly-3e5fbdb2-fb18-4170-a34f-308b3e2b01f7"/>
							<gml:surfaceMember xlink:href="#poly-4c9e1171-bc40-4fa4-9373-756548124ccc"/>
							<gml:surfaceMember xlink:href="#poly-8e041aa8-2eca-4798-8657-fb44dda9c7cd"/>
							<gml:surfaceMember xlink:href="#poly-52c19db6-b770-4dd9-8ea5-892a6428ce88"/>
							<gml:surfaceMember xlink:href="#poly-eca1e497-e3d4-4f2e-98e4-cd413a3f0bc1"/>
							<gml:surfaceMember xlink:href="#poly-8e23a85f-75b3-4a42-8705-894b11cd1bde"/>
							<gml:surfaceMember xlink:href="#poly-363b747c-5df3-4b17-b881-04c86916b135"/>
							<gml:surfaceMember xlink:href="#poly-b88a07b4-dc68-473b-b76a-a580221a80b2"/>
							<gml:surfaceMember xlink:href="#poly-2d2675a6-75e7-48f5-8e38-e50b7caec3a3"/>
							<gml:surfaceMember xlink:href="#poly-eafce171-f99c-481c-bb9e-bb766c47012a"/>
							<gml:surfaceMember xlink:href="#poly-c3079922-1eaa-4657-a229-ed63183b3f9b"/>
							<gml:surfaceMember xlink:href="#poly-2dad1384-e9aa-4963-8b8a-0bab79055eb4"/>
							<gml:surfaceMember xlink:href="#poly-a4b50a80-d414-4cb9-8738-9c537d1491ff"/>
							<gml:surfaceMember xlink:href="#poly-fbaec353-27e5-43fd-84d5-9e237587b927"/>
							<gml:surfaceMember xlink:href="#poly-9668c030-81c9-42de-970d-242b38c70641"/>
							<gml:surfaceMember xlink:href="#poly-6a6c9b20-b91e-4aad-bd4c-439e0f83f6e8"/>
							<gml:surfaceMember xlink:href="#poly-e9370e90-866f-4ae9-9120-5ebffd4996ba"/>
							<gml:surfaceMember xlink:href="#poly-25e79ae7-f981-4b42-acb5-6df4e9f5477e"/>
							<gml:surfaceMember xlink:href="#poly-57f988b1-567f-4079-a22d-e2bc9a1d5f55"/>
							<gml:surfaceMember xlink:href="#poly-f257ef44-3c84-49ea-ba1b-73f1afd1773e"/>
							<gml:surfaceMember xlink:href="#poly-06a013bf-e3ce-48c6-9694-e921bea00e9f"/>
							<gml:surfaceMember xlink:href="#poly-43386c31-d391-4d8c-8b04-da93f7aa1dfd"/>
							<gml:surfaceMember xlink:href="#poly-c96bf872-80ac-4c71-840d-f91d222368af"/>
							<gml:surfaceMember xlink:href="#poly-7aa53362-7533-43fe-a056-d84d3b8e4bfc"/>
							<gml:surfaceMember xlink:href="#poly-e43810be-57c6-4def-a6c9-e4c27785f1eb"/>
							<gml:surfaceMember xlink:href="#poly-f85289bb-fd95-448d-a5ee-d89d75d26915"/>
							<gml:surfaceMember xlink:href="#poly-18282438-0a7f-4bc8-9884-70ac1585756c"/>
							<gml:surfaceMember xlink:href="#poly-a5300520-1514-4f0f-952c-b4db85147e83"/>
							<gml:surfaceMember xlink:href="#poly-9cd35870-def9-4114-8447-1de2c1fd9f51"/>
							<gml:surfaceMember xlink:href="#poly-ef5bf495-e1ac-4459-84b0-98bea97b3b51"/>
							<gml:surfaceMember xlink:href="#poly-8f6a0086-3e57-4ce2-958a-fb29ca348b4a"/>
							<gml:surfaceMember xlink:href="#poly-5f05e346-a063-4528-bc38-a554ad51d84d"/>
							<gml:surfaceMember xlink:href="#poly-c794e69b-8aa2-40ee-8538-66da4be5588f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9621a8e3-47ce-4a99-b951-bb024db034f5_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-810aabd0-e217-411f-897b-052fb133c14c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924887027303 139.74847419031738 38.633 35.66916028107412 139.7484198820714 38.633 35.66922077580177 139.7482716787527 38.633 35.669281915382754 139.7483091596155 38.633 35.6692811055669 139.74831117086606 38.633 35.66922146292053 139.7482746162865 38.633 35.66916248888405 139.7484190954607 38.633 35.66924805717715 139.748471551159 38.633 35.66927685139885 139.74840102442118 38.633 35.669278357345604 139.7484019506991 38.633 35.66924887027303 139.74847419031738 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bc24d35-ed69-4928-9489-77546801745d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7bc24d35-ed69-4928-9489-77546801745d_0">
											<gml:posList>35.66922077580177 139.7482716787527 38.633 35.66922077580177 139.7482716787527 39.531 35.669281915382754 139.7483091596155 39.531 35.669281915382754 139.7483091596155 38.633 35.66922077580177 139.7482716787527 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b2a5260-97b3-4c75-ad8a-3367345af5c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b2a5260-97b3-4c75-ad8a-3367345af5c4_0">
											<gml:posList>35.66922146292053 139.7482746162865 39.531 35.66922146292053 139.7482746162865 38.633 35.6692811055669 139.74831117086606 38.633 35.6692811055669 139.74831117086606 39.531 35.66922146292053 139.7482746162865 39.531</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8caf672b-fea8-4861-a400-ba627bf997b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8caf672b-fea8-4861-a400-ba627bf997b6_0">
											<gml:posList>35.6692811055669 139.74831117086606 39.531 35.6692811055669 139.74831117086606 38.633 35.669281915382754 139.7483091596155 38.633 35.669281915382754 139.7483091596155 39.531 35.6692811055669 139.74831117086606 39.531</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23d211cf-211d-418c-a8c6-c1196ccfaac2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23d211cf-211d-418c-a8c6-c1196ccfaac2_0">
											<gml:posList>35.66916028107412 139.7484198820714 38.633 35.66916028107412 139.7484198820714 39.531 35.66922077580177 139.7482716787527 39.531 35.66922077580177 139.7482716787527 38.633 35.66916028107412 139.7484198820714 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c75ee641-de80-491f-9b0a-49bbbe3ccf3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c75ee641-de80-491f-9b0a-49bbbe3ccf3c_0">
											<gml:posList>35.66922146292053 139.7482746162865 38.633 35.66922146292053 139.7482746162865 39.531 35.66916248888405 139.7484190954607 39.531 35.66916248888405 139.7484190954607 38.633 35.66922146292053 139.7482746162865 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a185e9e9-fc6d-4d71-8e76-79af9929e619">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a185e9e9-fc6d-4d71-8e76-79af9929e619_0">
											<gml:posList>35.66927685139885 139.74840102442118 39.531 35.66924805717715 139.748471551159 39.531 35.66916248888405 139.7484190954607 39.531 35.66922146292053 139.7482746162865 39.531 35.6692811055669 139.74831117086606 39.531 35.669281915382754 139.7483091596155 39.531 35.66922077580177 139.7482716787527 39.531 35.66916028107412 139.7484198820714 39.531 35.66924887027303 139.74847419031738 39.531 35.669278357345604 139.7484019506991 39.531 35.66927685139885 139.74840102442118 39.531</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31b92e24-9cbf-4b80-b575-bc7fc6e2a86e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31b92e24-9cbf-4b80-b575-bc7fc6e2a86e_0">
											<gml:posList>35.66927685139885 139.74840102442118 38.633 35.66927685139885 139.74840102442118 39.531 35.669278357345604 139.7484019506991 39.531 35.669278357345604 139.7484019506991 38.633 35.66927685139885 139.74840102442118 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfb3c50e-dc6e-4aea-8f19-eefd85951ed4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfb3c50e-dc6e-4aea-8f19-eefd85951ed4_0">
											<gml:posList>35.66924805717715 139.748471551159 38.633 35.66924805717715 139.748471551159 39.531 35.66927685139885 139.74840102442118 39.531 35.66927685139885 139.74840102442118 38.633 35.66924805717715 139.748471551159 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9193d556-826a-4ab7-888a-3980f56adf3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9193d556-826a-4ab7-888a-3980f56adf3a_0">
											<gml:posList>35.669278357345604 139.7484019506991 39.531 35.66924887027303 139.74847419031738 39.531 35.66924887027303 139.74847419031738 38.633 35.669278357345604 139.7484019506991 38.633 35.669278357345604 139.7484019506991 39.531</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a8646b3-bbdc-4c2d-8e78-954f42100197">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a8646b3-bbdc-4c2d-8e78-954f42100197_0">
											<gml:posList>35.66916248888405 139.7484190954607 39.531 35.66924805717715 139.748471551159 39.531 35.66924805717715 139.748471551159 38.633 35.66916248888405 139.7484190954607 38.633 35.66916248888405 139.7484190954607 39.531</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ee42f5e-2058-457c-890d-ece1499f791a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ee42f5e-2058-457c-890d-ece1499f791a_0">
											<gml:posList>35.66924887027303 139.74847419031738 38.633 35.66924887027303 139.74847419031738 39.531 35.66916028107412 139.7484198820714 39.531 35.66916028107412 139.7484198820714 38.633 35.66924887027303 139.74847419031738 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9621a8e3-47ce-4a99-b951-bb024db034f5_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed43a8d0-801e-4ab7-aadf-04264b626918">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66930909319754 139.74837500981178 38.633 35.669302420172016 139.7483709519133 38.633 35.669301484381194 139.74837327258834 38.633 35.6692825660465 139.74836261104693 38.633 35.669276807378324 139.74837695499807 38.633 35.669269187529686 139.74837235684507 38.633 35.66927947310123 139.7483480886919 38.633 35.66929739103052 139.74835891698135 38.633 35.66931272359913 139.7483209021029 38.633 35.669314671398425 139.74832208197188 38.633 35.66932264293241 139.748326889626 38.633 35.669306977493214 139.74836581064199 38.633 35.66931167559316 139.74836856719165 38.633 35.66930909319754 139.74837500981178 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f3e6739-2794-4ba7-adfd-935de19fec33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f3e6739-2794-4ba7-adfd-935de19fec33_0">
											<gml:posList>35.669314671398425 139.74832208197188 38.633 35.66931272359913 139.7483209021029 38.633 35.66931272359913 139.7483209021029 39.1 35.669314671398425 139.74832208197188 39.1 35.669314671398425 139.74832208197188 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71bae326-c893-4ee4-b205-72965dad1951">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71bae326-c893-4ee4-b205-72965dad1951_0">
											<gml:posList>35.66932264293241 139.748326889626 38.633 35.669314671398425 139.74832208197188 38.633 35.669314671398425 139.74832208197188 39.1 35.66932264293241 139.748326889626 39.1 35.66932264293241 139.748326889626 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ae64eba-8b5e-4eaf-b094-a1b566307a18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ae64eba-8b5e-4eaf-b094-a1b566307a18_0">
											<gml:posList>35.66929739103052 139.74835891698135 38.633 35.66929739103052 139.74835891698135 39.1 35.66931272359913 139.7483209021029 39.1 35.66931272359913 139.7483209021029 38.633 35.66929739103052 139.74835891698135 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fba5d222-a697-4436-9f21-3942c7f63683">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fba5d222-a697-4436-9f21-3942c7f63683_0">
											<gml:posList>35.66932264293241 139.748326889626 38.633 35.66932264293241 139.748326889626 39.1 35.669306977493214 139.74836581064199 39.1 35.669306977493214 139.74836581064199 38.633 35.66932264293241 139.748326889626 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-944a5ce7-4c17-4fa1-b94a-a8a5e045c9dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-944a5ce7-4c17-4fa1-b94a-a8a5e045c9dd_0">
											<gml:posList>35.669306977493214 139.74836581064199 39.1 35.66932264293241 139.748326889626 39.1 35.669314671398425 139.74832208197188 39.1 35.66931272359913 139.7483209021029 39.1 35.66929739103052 139.74835891698135 39.1 35.66927947310123 139.7483480886919 39.1 35.669269187529686 139.74837235684507 39.1 35.669276807378324 139.74837695499807 39.1 35.6692825660465 139.74836261104693 39.1 35.669301484381194 139.74837327258834 39.1 35.669302420172016 139.7483709519133 39.1 35.66930909319754 139.74837500981178 39.1 35.66931167559316 139.74836856719165 39.1 35.669306977493214 139.74836581064199 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cd22b3b-fe95-4e68-ab86-6fd71560ee64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cd22b3b-fe95-4e68-ab86-6fd71560ee64_0">
											<gml:posList>35.66927947310123 139.7483480886919 38.633 35.66927947310123 139.7483480886919 39.1 35.66929739103052 139.74835891698135 39.1 35.66929739103052 139.74835891698135 38.633 35.66927947310123 139.7483480886919 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98c7837c-b307-46d2-9296-bc9c732607e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98c7837c-b307-46d2-9296-bc9c732607e8_0">
											<gml:posList>35.669269187529686 139.74837235684507 38.633 35.669269187529686 139.74837235684507 39.1 35.66927947310123 139.7483480886919 39.1 35.66927947310123 139.7483480886919 38.633 35.669269187529686 139.74837235684507 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9264f0d8-bbfe-4cc6-84a6-de00ee333537">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9264f0d8-bbfe-4cc6-84a6-de00ee333537_0">
											<gml:posList>35.66931167559316 139.74836856719165 38.633 35.669306977493214 139.74836581064199 38.633 35.669306977493214 139.74836581064199 39.1 35.66931167559316 139.74836856719165 39.1 35.66931167559316 139.74836856719165 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d08e678a-4464-4c37-ac70-268d8b9d2cca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d08e678a-4464-4c37-ac70-268d8b9d2cca_0">
											<gml:posList>35.669301484381194 139.74837327258834 39.1 35.6692825660465 139.74836261104693 39.1 35.6692825660465 139.74836261104693 38.633 35.669301484381194 139.74837327258834 38.633 35.669301484381194 139.74837327258834 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-399090a7-cf24-4a69-90be-a8f7dbfbea9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-399090a7-cf24-4a69-90be-a8f7dbfbea9b_0">
											<gml:posList>35.6692825660465 139.74836261104693 39.1 35.669276807378324 139.74837695499807 39.1 35.669276807378324 139.74837695499807 38.633 35.6692825660465 139.74836261104693 38.633 35.6692825660465 139.74836261104693 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-270a61e3-4ed5-4891-adf6-4795037e09c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-270a61e3-4ed5-4891-adf6-4795037e09c7_0">
											<gml:posList>35.66930909319754 139.74837500981178 38.633 35.66931167559316 139.74836856719165 38.633 35.66931167559316 139.74836856719165 39.1 35.66930909319754 139.74837500981178 39.1 35.66930909319754 139.74837500981178 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b81504b9-fd93-43d9-811d-39cef3993882">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b81504b9-fd93-43d9-811d-39cef3993882_0">
											<gml:posList>35.669302420172016 139.7483709519133 39.1 35.669301484381194 139.74837327258834 39.1 35.669301484381194 139.74837327258834 38.633 35.669302420172016 139.7483709519133 38.633 35.669302420172016 139.7483709519133 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c69f0967-21d7-4754-a294-80e7f63e86e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c69f0967-21d7-4754-a294-80e7f63e86e7_0">
											<gml:posList>35.669302420172016 139.7483709519133 38.633 35.66930909319754 139.74837500981178 38.633 35.66930909319754 139.74837500981178 39.1 35.669302420172016 139.7483709519133 39.1 35.669302420172016 139.7483709519133 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1be8fe4-4755-4bc0-9cc4-f9537a2c289b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1be8fe4-4755-4bc0-9cc4-f9537a2c289b_0">
											<gml:posList>35.669276807378324 139.74837695499807 39.1 35.669269187529686 139.74837235684507 39.1 35.669269187529686 139.74837235684507 38.633 35.669276807378324 139.74837695499807 38.633 35.669276807378324 139.74837695499807 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9621a8e3-47ce-4a99-b951-bb024db034f5_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13885711-cebb-4126-bde1-9c0d29cb9066">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669267477932564 139.74838940279955 38.633 35.66927107132357 139.74838502473418 38.633 35.66927817877399 139.7483788092912 38.633 35.6692797017976 139.74837838792536 38.633 35.669283893468666 139.74837879219015 38.633 35.66929656249215 139.74838549480228 38.633 35.669290623835025 139.748400247651 38.633 35.66927954118921 139.74839348812594 38.633 35.669276148943695 139.7484018978078 38.633 35.669265129464165 139.7483952376318 38.633 35.669267477932564 139.74838940279955 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bf98c61-68a8-4668-b8c5-4055573a6817">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669292697888054 139.7484015157567 39.1 35.669290623835025 139.748400247651 39.1 35.66929656249215 139.74838549480228 39.1 35.66929869052639 139.74838661925108 39.1 35.669292697888054 139.7484015157567 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a9ddc84-4fd0-4716-8517-b00149ff82bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a9ddc84-4fd0-4716-8517-b00149ff82bf_0">
											<gml:posList>35.669265129464165 139.7483952376318 38.633 35.669265129464165 139.7483952376318 40.33 35.669267477932564 139.74838940279955 40.33 35.669267477932564 139.74838940279955 38.633 35.669265129464165 139.7483952376318 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d63bd1ef-e78a-440e-ae28-c9898a9a3521">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d63bd1ef-e78a-440e-ae28-c9898a9a3521_0">
											<gml:posList>35.669267477932564 139.74838940279955 40.33 35.66927107132357 139.74838502473418 40.33 35.66927107132357 139.74838502473418 38.633 35.669267477932564 139.74838940279955 38.633 35.669267477932564 139.74838940279955 40.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25c23764-ccb0-4ef9-af0f-d2083eafeaa2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25c23764-ccb0-4ef9-af0f-d2083eafeaa2_0">
											<gml:posList>35.669276148943695 139.7484018978078 38.633 35.669276148943695 139.7484018978078 40.33 35.669265129464165 139.7483952376318 40.33 35.669265129464165 139.7483952376318 38.633 35.669276148943695 139.7484018978078 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5925cd0-9968-4a1d-8781-ed81de9e550d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5925cd0-9968-4a1d-8781-ed81de9e550d_0">
											<gml:posList>35.66927107132357 139.74838502473418 40.33 35.66927817877399 139.7483788092912 40.33 35.66927817877399 139.7483788092912 38.633 35.66927107132357 139.74838502473418 38.633 35.66927107132357 139.74838502473418 40.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecd208ac-7208-43fd-a195-05bf326cce95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ecd208ac-7208-43fd-a195-05bf326cce95_0">
											<gml:posList>35.66927954118921 139.74839348812594 38.633 35.66927954118921 139.74839348812594 40.33 35.669276148943695 139.7484018978078 40.33 35.669276148943695 139.7484018978078 38.633 35.66927954118921 139.74839348812594 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f0c59ea-8122-4f2a-9a8c-bd44282d324b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f0c59ea-8122-4f2a-9a8c-bd44282d324b_0">
											<gml:posList>35.66927817877399 139.7483788092912 38.633 35.66927817877399 139.7483788092912 40.33 35.6692797017976 139.74837838792536 40.33 35.6692797017976 139.74837838792536 38.633 35.66927817877399 139.7483788092912 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06285f47-2f9e-4ae7-84b2-86180adef802">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06285f47-2f9e-4ae7-84b2-86180adef802_0">
											<gml:posList>35.6692797017976 139.74837838792536 40.33 35.669283893468666 139.74837879219015 40.33 35.669283893468666 139.74837879219015 38.633 35.6692797017976 139.74837838792536 38.633 35.6692797017976 139.74837838792536 40.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4da40436-be54-4df4-a295-3a12ca2f8d3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4da40436-be54-4df4-a295-3a12ca2f8d3e_0">
											<gml:posList>35.669283893468666 139.74837879219015 40.33 35.6692797017976 139.74837838792536 40.33 35.66927817877399 139.7483788092912 40.33 35.66927107132357 139.74838502473418 40.33 35.669267477932564 139.74838940279955 40.33 35.669265129464165 139.7483952376318 40.33 35.669276148943695 139.7484018978078 40.33 35.66927954118921 139.74839348812594 40.33 35.669292697888054 139.7484015157567 40.33 35.66929869052639 139.74838661925108 40.33 35.669283893468666 139.74837879219015 40.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddd575f8-8eb1-449c-ad29-5a07d59c9e86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddd575f8-8eb1-449c-ad29-5a07d59c9e86_0">
											<gml:posList>35.669292697888054 139.7484015157567 40.33 35.66927954118921 139.74839348812594 40.33 35.66927954118921 139.74839348812594 38.633 35.669290623835025 139.748400247651 38.633 35.669290623835025 139.748400247651 39.1 35.669292697888054 139.7484015157567 39.1 35.669292697888054 139.7484015157567 40.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78f447ff-9ccf-43ca-a6bd-252d4727f8a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78f447ff-9ccf-43ca-a6bd-252d4727f8a5_0">
											<gml:posList>35.66929656249215 139.74838549480228 39.1 35.66929656249215 139.74838549480228 38.633 35.669283893468666 139.74837879219015 38.633 35.669283893468666 139.74837879219015 40.33 35.66929869052639 139.74838661925108 40.33 35.66929869052639 139.74838661925108 39.1 35.66929656249215 139.74838549480228 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f41643f-af2c-41db-a869-350eaacd807d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f41643f-af2c-41db-a869-350eaacd807d_0">
											<gml:posList>35.66929656249215 139.74838549480228 39.1 35.669290623835025 139.748400247651 39.1 35.669290623835025 139.748400247651 38.633 35.66929656249215 139.74838549480228 38.633 35.66929656249215 139.74838549480228 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0acc0b13-ef1c-486c-87f3-066bb3e69922">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0acc0b13-ef1c-486c-87f3-066bb3e69922_0">
											<gml:posList>35.66929869052639 139.74838661925108 39.1 35.66929869052639 139.74838661925108 40.33 35.669292697888054 139.7484015157567 40.33 35.669292697888054 139.7484015157567 39.1 35.66929869052639 139.74838661925108 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9621a8e3-47ce-4a99-b951-bb024db034f5_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00c6e856-2d40-4d7e-b6b5-ee6ca55e2b6d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923075581011 139.7484019348443 38.633 35.66921158415055 139.74838993699586 38.633 35.66923337849633 139.74833762165912 38.633 35.66925255016101 139.7483496194983 38.633 35.66923075581011 139.7484019348443 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b08aabcc-e588-421a-ba83-1523a609416e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b08aabcc-e588-421a-ba83-1523a609416e_0">
											<gml:posList>35.66923075581011 139.7484019348443 38.633 35.66923075581011 139.7484019348443 41.429 35.66921158415055 139.74838993699586 41.429 35.66921158415055 139.74838993699586 38.633 35.66923075581011 139.7484019348443 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46d46896-7e1f-4f6c-8b59-362c17b54fa6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46d46896-7e1f-4f6c-8b59-362c17b54fa6_0">
											<gml:posList>35.66921158415055 139.74838993699586 38.633 35.66921158415055 139.74838993699586 41.429 35.66923337849633 139.74833762165912 41.429 35.66923337849633 139.74833762165912 38.633 35.66921158415055 139.74838993699586 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcc29fc6-855b-459f-bfb1-f1617c5c74d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dcc29fc6-855b-459f-bfb1-f1617c5c74d0_0">
											<gml:posList>35.66923337849633 139.74833762165912 41.429 35.66921158415055 139.74838993699586 41.429 35.66923075581011 139.7484019348443 41.429 35.66925255016101 139.7483496194983 41.429 35.66923337849633 139.74833762165912 41.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66867964-51c0-4e19-a578-f6aead791960">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66867964-51c0-4e19-a578-f6aead791960_0">
											<gml:posList>35.66925255016101 139.7483496194983 38.633 35.66925255016101 139.7483496194983 41.429 35.66923075581011 139.7484019348443 41.429 35.66923075581011 139.7484019348443 38.633 35.66925255016101 139.7483496194983 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6761e941-dc4d-475e-8dab-c1b8f03acba4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6761e941-dc4d-475e-8dab-c1b8f03acba4_0">
											<gml:posList>35.66923337849633 139.74833762165912 38.633 35.66923337849633 139.74833762165912 41.429 35.66925255016101 139.7483496194983 41.429 35.66925255016101 139.7483496194983 38.633 35.66923337849633 139.74833762165912 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9621a8e3-47ce-4a99-b951-bb024db034f5_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcadf5e0-9987-4cb6-9d03-fdbd56dc4677">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923420328812 139.7483057527796 38.633 35.66919312724201 139.74840727682857 38.633 35.669239116984684 139.7484352189422 38.633 35.66923486991178 139.74844572828258 38.633 35.669179979798706 139.74841237195773 38.633 35.66920669499625 139.74834635427058 38.633 35.66921134807485 139.74834917714 38.633 35.66921534321501 139.74833931978455 38.633 35.66921168206712 139.74833709235344 38.633 35.66922109400994 139.74831383033467 38.633 35.6692250166655 139.74831621213315 38.633 35.66923022652661 139.74830333790047 38.633 35.66923420328812 139.7483057527796 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-678c77ce-18db-443b-a2d8-899208ff28aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-678c77ce-18db-443b-a2d8-899208ff28aa_0">
											<gml:posList>35.66923022652661 139.74830333790047 38.633 35.66923022652661 139.74830333790047 39.851 35.66923420328812 139.7483057527796 39.851 35.66923420328812 139.7483057527796 38.633 35.66923022652661 139.74830333790047 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0945b885-4e37-4ebb-8c5d-11cc2ed4c85b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0945b885-4e37-4ebb-8c5d-11cc2ed4c85b_0">
											<gml:posList>35.6692250166655 139.74831621213315 38.633 35.6692250166655 139.74831621213315 39.851 35.66923022652661 139.74830333790047 39.851 35.66923022652661 139.74830333790047 38.633 35.6692250166655 139.74831621213315 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07bd0f02-1949-4fe4-8aea-f1726913ff27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07bd0f02-1949-4fe4-8aea-f1726913ff27_0">
											<gml:posList>35.66922109400994 139.74831383033467 38.633 35.66922109400994 139.74831383033467 39.851 35.6692250166655 139.74831621213315 39.851 35.6692250166655 139.74831621213315 38.633 35.66922109400994 139.74831383033467 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5aa2dda-6568-4dc9-9b11-3723b4953080">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5aa2dda-6568-4dc9-9b11-3723b4953080_0">
											<gml:posList>35.66921168206712 139.74833709235344 38.633 35.66921168206712 139.74833709235344 39.851 35.66922109400994 139.74831383033467 39.851 35.66922109400994 139.74831383033467 38.633 35.66921168206712 139.74833709235344 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62a30320-8e0f-499b-9506-7ea40510d5fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62a30320-8e0f-499b-9506-7ea40510d5fe_0">
											<gml:posList>35.66921534321501 139.74833931978455 38.633 35.66921534321501 139.74833931978455 39.851 35.66921168206712 139.74833709235344 39.851 35.66921168206712 139.74833709235344 38.633 35.66921534321501 139.74833931978455 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f47e1a27-5301-4a1c-ab78-5c18229918ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f47e1a27-5301-4a1c-ab78-5c18229918ee_0">
											<gml:posList>35.66921134807485 139.74834917714 38.633 35.66921134807485 139.74834917714 39.851 35.66921534321501 139.74833931978455 39.851 35.66921534321501 139.74833931978455 38.633 35.66921134807485 139.74834917714 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69497e47-52e9-4cb2-b3f9-4c774d85a10c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69497e47-52e9-4cb2-b3f9-4c774d85a10c_0">
											<gml:posList>35.66920669499625 139.74834635427058 38.633 35.66920669499625 139.74834635427058 39.851 35.66921134807485 139.74834917714 39.851 35.66921134807485 139.74834917714 38.633 35.66920669499625 139.74834635427058 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bea5245b-41b9-457e-bad8-d8a45459954d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bea5245b-41b9-457e-bad8-d8a45459954d_0">
											<gml:posList>35.66923420328812 139.7483057527796 38.633 35.66923420328812 139.7483057527796 39.851 35.66919312724201 139.74840727682857 39.851 35.66919312724201 139.74840727682857 38.633 35.66923420328812 139.7483057527796 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d64841ee-dfe8-4179-82b7-bb32d541d6d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d64841ee-dfe8-4179-82b7-bb32d541d6d7_0">
											<gml:posList>35.6692250166655 139.74831621213315 39.851 35.66922109400994 139.74831383033467 39.851 35.66921168206712 139.74833709235344 39.851 35.66921534321501 139.74833931978455 39.851 35.66921134807485 139.74834917714 39.851 35.66920669499625 139.74834635427058 39.851 35.669179979798706 139.74841237195773 39.851 35.66923486991178 139.74844572828258 39.851 35.669239116984684 139.7484352189422 39.851 35.66919312724201 139.74840727682857 39.851 35.66923420328812 139.7483057527796 39.851 35.66923022652661 139.74830333790047 39.851 35.6692250166655 139.74831621213315 39.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-227f57e8-c1e6-4fbf-9554-a7809dd52ddd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-227f57e8-c1e6-4fbf-9554-a7809dd52ddd_0">
											<gml:posList>35.669179979798706 139.74841237195773 38.633 35.669179979798706 139.74841237195773 39.851 35.66920669499625 139.74834635427058 39.851 35.66920669499625 139.74834635427058 38.633 35.669179979798706 139.74841237195773 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cf04883-422e-4ce6-a18f-58e9c1fbe288">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cf04883-422e-4ce6-a18f-58e9c1fbe288_0">
											<gml:posList>35.66919312724201 139.74840727682857 38.633 35.66919312724201 139.74840727682857 39.851 35.669239116984684 139.7484352189422 39.851 35.669239116984684 139.7484352189422 38.633 35.66919312724201 139.74840727682857 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aad73cf7-be88-46d2-8ef1-c9969ea35288">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aad73cf7-be88-46d2-8ef1-c9969ea35288_0">
											<gml:posList>35.66923486991178 139.74844572828258 39.851 35.669179979798706 139.74841237195773 39.851 35.669179979798706 139.74841237195773 38.633 35.66923486991178 139.74844572828258 38.633 35.66923486991178 139.74844572828258 39.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83e49f57-ea54-4485-8cfa-fc282c6d1b64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83e49f57-ea54-4485-8cfa-fc282c6d1b64_0">
											<gml:posList>35.669239116984684 139.7484352189422 38.633 35.669239116984684 139.7484352189422 39.851 35.66923486991178 139.74844572828258 39.851 35.66923486991178 139.74844572828258 38.633 35.669239116984684 139.7484352189422 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8819a1c1-41db-490d-8c18-73c69d8b381d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8819a1c1-41db-490d-8c18-73c69d8b381d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8819a1c1-41db-490d-8c18-73c69d8b381d">
											<gml:posList>35.669310581915866 139.7483642935049 5.78 35.66931527100211 139.74836705006416 5.78 35.66931032218165 139.7483794269547 5.78 35.66930364014256 139.74837536906534 5.78 35.669255689934744 139.74849447479525 5.78 35.66914693799196 139.7484287551664 5.78 35.66921541230737 139.7482584622613 5.78 35.66932623835643 139.74832539458865 5.78 35.669310581915866 139.7483642935049 5.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ff6b50f2-f8c1-46f6-a1db-c039fb87c39f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff6b50f2-f8c1-46f6-a1db-c039fb87c39f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff6b50f2-f8c1-46f6-a1db-c039fb87c39f">
											<gml:posList>35.66914693799196 139.7484287551664 39.1 35.66915053340959 139.74842724909084 39.1 35.669216632274235 139.7482628683607 39.1 35.66921541230737 139.7482584622613 39.1 35.66914693799196 139.7484287551664 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7275f5ec-a2e8-4107-ab30-7bc0cc59ddb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7275f5ec-a2e8-4107-ab30-7bc0cc59ddb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7275f5ec-a2e8-4107-ab30-7bc0cc59ddb3">
											<gml:posList>35.669255689934744 139.74849447479525 39.1 35.66925446996857 139.74849005764403 39.1 35.66915053340959 139.74842724909084 39.1 35.66914693799196 139.7484287551664 39.1 35.669255689934744 139.74849447479525 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-29a9a9ef-7296-4e13-be4e-361e78d46820">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29a9a9ef-7296-4e13-be4e-361e78d46820">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29a9a9ef-7296-4e13-be4e-361e78d46820">
											<gml:posList>35.669216632274235 139.7482628683607 38.633 35.66915053340959 139.74842724909084 38.633 35.66925446996857 139.74849005764403 38.633 35.669302420172016 139.7483709519133 38.633 35.66930909319754 139.74837500981178 38.633 35.66931167559316 139.74836856719165 38.633 35.669306977493214 139.74836581064199 38.633 35.66932264293241 139.748326889626 38.633 35.669314671398425 139.74832208197188 38.633 35.66931226370412 139.74832062643767 38.633 35.669297237134586 139.74835797822502 38.633 35.6692691203304 139.74834099701812 38.633 35.66928413787323 139.74830363420418 38.633 35.66928173017869 139.7483021786711 38.633 35.669216632274235 139.7482628683607 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f10ca756-5933-4f6d-8216-d0b376bcdc3d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f10ca756-5933-4f6d-8216-d0b376bcdc3d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f10ca756-5933-4f6d-8216-d0b376bcdc3d">
											<gml:posList>35.66921541230737 139.7482584622613 39.1 35.669216632274235 139.7482628683607 39.1 35.66928173017869 139.7483021786711 39.1 35.669285325602424 139.7483006836334 39.1 35.66921541230737 139.7482584622613 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5ddaac20-e62e-4fa2-951f-d0e148aaac0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ddaac20-e62e-4fa2-951f-d0e148aaac0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ddaac20-e62e-4fa2-951f-d0e148aaac0a">
											<gml:posList>35.6692691203304 139.74834099701812 43.089 35.669271291999095 139.74834008893532 43.089 35.669286066600044 139.74830333391387 43.089 35.669285325602424 139.7483006836334 43.089 35.6692691203304 139.74834099701812 43.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36366c9c-28c3-4678-874c-0a1228946921">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36366c9c-28c3-4678-874c-0a1228946921">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36366c9c-28c3-4678-874c-0a1228946921">
											<gml:posList>35.66930364014256 139.74837536906534 39.1 35.669302420172016 139.7483709519133 39.1 35.66925446996857 139.74849005764403 39.1 35.669255689934744 139.74849447479525 39.1 35.66930364014256 139.74837536906534 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-128c5280-55ff-47f5-b8ad-ce4b0e367bcc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-128c5280-55ff-47f5-b8ad-ce4b0e367bcc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-128c5280-55ff-47f5-b8ad-ce4b0e367bcc">
											<gml:posList>35.669297237134586 139.74835797822502 43.089 35.66929650514411 139.74835531688805 43.089 35.669271291999095 139.74834008893532 43.089 35.6692691203304 139.74834099701812 43.089 35.669297237134586 139.74835797822502 43.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b35b1f62-2ca3-476d-93e0-a61fd99383d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b35b1f62-2ca3-476d-93e0-a61fd99383d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b35b1f62-2ca3-476d-93e0-a61fd99383d8">
											<gml:posList>35.66928413787323 139.74830363420418 39.1 35.669285325602424 139.7483006836334 39.1 35.66928173017869 139.7483021786711 39.1 35.66928413787323 139.74830363420418 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6f4bf32-5677-424a-bee4-1f09ecd41537">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6f4bf32-5677-424a-bee4-1f09ecd41537">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6f4bf32-5677-424a-bee4-1f09ecd41537">
											<gml:posList>35.66931128877114 139.74831857289436 42.8 35.669286066600044 139.74830333391387 42.8 35.669271291999095 139.74834008893532 42.8 35.66929650514411 139.74835531688805 42.8 35.66931128877114 139.74831857289436 42.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9d773b8-3954-4fdb-8df9-00065758c81a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9d773b8-3954-4fdb-8df9-00065758c81a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9d773b8-3954-4fdb-8df9-00065758c81a">
											<gml:posList>35.669285325602424 139.7483006836334 43.089 35.669286066600044 139.74830333391387 43.089 35.66931128877114 139.74831857289436 43.089 35.669313451433744 139.74831767586613 43.089 35.669285325602424 139.7483006836334 43.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e5fbdb2-fb18-4170-a34f-308b3e2b01f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e5fbdb2-fb18-4170-a34f-308b3e2b01f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e5fbdb2-fb18-4170-a34f-308b3e2b01f7">
											<gml:posList>35.669313451433744 139.74831767586613 43.089 35.66931128877114 139.74831857289436 43.089 35.66929650514411 139.74835531688805 43.089 35.669297237134586 139.74835797822502 43.089 35.669313451433744 139.74831767586613 43.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c9e1171-bc40-4fa4-9373-756548124ccc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c9e1171-bc40-4fa4-9373-756548124ccc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c9e1171-bc40-4fa4-9373-756548124ccc">
											<gml:posList>35.66930364014256 139.74837536906534 39.1 35.66931032218165 139.7483794269547 39.1 35.66930909319754 139.74837500981178 39.1 35.669302420172016 139.7483709519133 39.1 35.66930364014256 139.74837536906534 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e041aa8-2eca-4798-8657-fb44dda9c7cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e041aa8-2eca-4798-8657-fb44dda9c7cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e041aa8-2eca-4798-8657-fb44dda9c7cd">
											<gml:posList>35.669310581915866 139.7483642935049 39.1 35.669306977493214 139.74836581064199 39.1 35.66931167559316 139.74836856719165 39.1 35.66931527100211 139.74836705006416 39.1 35.669310581915866 139.7483642935049 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-52c19db6-b770-4dd9-8ea5-892a6428ce88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52c19db6-b770-4dd9-8ea5-892a6428ce88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52c19db6-b770-4dd9-8ea5-892a6428ce88">
											<gml:posList>35.66931527100211 139.74836705006416 39.1 35.66931167559316 139.74836856719165 39.1 35.66930909319754 139.74837500981178 39.1 35.66931032218165 139.7483794269547 39.1 35.66931527100211 139.74836705006416 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eca1e497-e3d4-4f2e-98e4-cd413a3f0bc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eca1e497-e3d4-4f2e-98e4-cd413a3f0bc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eca1e497-e3d4-4f2e-98e4-cd413a3f0bc1">
											<gml:posList>35.669314671398425 139.74832208197188 39.1 35.669313451433744 139.74831767586613 39.1 35.66931226370412 139.74832062643767 39.1 35.669314671398425 139.74832208197188 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e23a85f-75b3-4a42-8705-894b11cd1bde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e23a85f-75b3-4a42-8705-894b11cd1bde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e23a85f-75b3-4a42-8705-894b11cd1bde">
											<gml:posList>35.669310581915866 139.7483642935049 39.1 35.66932623835643 139.74832539458865 39.1 35.66932264293241 139.748326889626 39.1 35.669306977493214 139.74836581064199 39.1 35.669310581915866 139.7483642935049 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-363b747c-5df3-4b17-b881-04c86916b135">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-363b747c-5df3-4b17-b881-04c86916b135">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-363b747c-5df3-4b17-b881-04c86916b135">
											<gml:posList>35.669313451433744 139.74831767586613 39.1 35.669314671398425 139.74832208197188 39.1 35.66932264293241 139.748326889626 39.1 35.66932623835643 139.74832539458865 39.1 35.669313451433744 139.74831767586613 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b88a07b4-dc68-473b-b76a-a580221a80b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b88a07b4-dc68-473b-b76a-a580221a80b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b88a07b4-dc68-473b-b76a-a580221a80b2">
											<gml:posList>35.669216632274235 139.7482628683607 39.1 35.669216632274235 139.7482628683607 38.633 35.66928173017869 139.7483021786711 38.633 35.66928173017869 139.7483021786711 39.1 35.669216632274235 139.7482628683607 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d2675a6-75e7-48f5-8e38-e50b7caec3a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d2675a6-75e7-48f5-8e38-e50b7caec3a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d2675a6-75e7-48f5-8e38-e50b7caec3a3">
											<gml:posList>35.669285325602424 139.7483006836334 39.1 35.669285325602424 139.7483006836334 43.089 35.669313451433744 139.74831767586613 43.089 35.669313451433744 139.74831767586613 39.1 35.66932623835643 139.74832539458865 39.1 35.66932623835643 139.74832539458865 5.78 35.66921541230737 139.7482584622613 5.78 35.66921541230737 139.7482584622613 39.1 35.669285325602424 139.7483006836334 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eafce171-f99c-481c-bb9e-bb766c47012a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eafce171-f99c-481c-bb9e-bb766c47012a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eafce171-f99c-481c-bb9e-bb766c47012a">
											<gml:posList>35.66928173017869 139.7483021786711 39.1 35.66928173017869 139.7483021786711 38.633 35.66928413787323 139.74830363420418 38.633 35.66928413787323 139.74830363420418 39.1 35.66928173017869 139.7483021786711 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3079922-1eaa-4657-a229-ed63183b3f9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3079922-1eaa-4657-a229-ed63183b3f9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3079922-1eaa-4657-a229-ed63183b3f9b">
											<gml:posList>35.669286066600044 139.74830333391387 43.089 35.669286066600044 139.74830333391387 42.8 35.66931128877114 139.74831857289436 42.8 35.66931128877114 139.74831857289436 43.089 35.669286066600044 139.74830333391387 43.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2dad1384-e9aa-4963-8b8a-0bab79055eb4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dad1384-e9aa-4963-8b8a-0bab79055eb4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dad1384-e9aa-4963-8b8a-0bab79055eb4">
											<gml:posList>35.6692691203304 139.74834099701812 38.633 35.6692691203304 139.74834099701812 43.089 35.669285325602424 139.7483006836334 43.089 35.669285325602424 139.7483006836334 39.1 35.66928413787323 139.74830363420418 39.1 35.66928413787323 139.74830363420418 38.633 35.6692691203304 139.74834099701812 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4b50a80-d414-4cb9-8738-9c537d1491ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4b50a80-d414-4cb9-8738-9c537d1491ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4b50a80-d414-4cb9-8738-9c537d1491ff">
											<gml:posList>35.66931226370412 139.74832062643767 39.1 35.66931226370412 139.74832062643767 38.633 35.669314671398425 139.74832208197188 38.633 35.669314671398425 139.74832208197188 39.1 35.66931226370412 139.74832062643767 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fbaec353-27e5-43fd-84d5-9e237587b927">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbaec353-27e5-43fd-84d5-9e237587b927">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbaec353-27e5-43fd-84d5-9e237587b927">
											<gml:posList>35.669271291999095 139.74834008893532 43.089 35.669271291999095 139.74834008893532 42.8 35.669286066600044 139.74830333391387 42.8 35.669286066600044 139.74830333391387 43.089 35.669271291999095 139.74834008893532 43.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9668c030-81c9-42de-970d-242b38c70641">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9668c030-81c9-42de-970d-242b38c70641">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9668c030-81c9-42de-970d-242b38c70641">
											<gml:posList>35.669314671398425 139.74832208197188 39.1 35.669314671398425 139.74832208197188 38.633 35.66932264293241 139.748326889626 38.633 35.66932264293241 139.748326889626 39.1 35.669314671398425 139.74832208197188 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a6c9b20-b91e-4aad-bd4c-439e0f83f6e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a6c9b20-b91e-4aad-bd4c-439e0f83f6e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a6c9b20-b91e-4aad-bd4c-439e0f83f6e8">
											<gml:posList>35.66931128877114 139.74831857289436 43.089 35.66931128877114 139.74831857289436 42.8 35.66929650514411 139.74835531688805 42.8 35.66929650514411 139.74835531688805 43.089 35.66931128877114 139.74831857289436 43.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9370e90-866f-4ae9-9120-5ebffd4996ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9370e90-866f-4ae9-9120-5ebffd4996ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9370e90-866f-4ae9-9120-5ebffd4996ba">
											<gml:posList>35.669313451433744 139.74831767586613 43.089 35.669297237134586 139.74835797822502 43.089 35.669297237134586 139.74835797822502 38.633 35.66931226370412 139.74832062643767 38.633 35.66931226370412 139.74832062643767 39.1 35.669313451433744 139.74831767586613 39.1 35.669313451433744 139.74831767586613 43.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25e79ae7-f981-4b42-acb5-6df4e9f5477e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25e79ae7-f981-4b42-acb5-6df4e9f5477e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25e79ae7-f981-4b42-acb5-6df4e9f5477e">
											<gml:posList>35.66921541230737 139.7482584622613 5.78 35.66914693799196 139.7484287551664 5.78 35.66914693799196 139.7484287551664 39.1 35.66921541230737 139.7482584622613 39.1 35.66921541230737 139.7482584622613 5.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57f988b1-567f-4079-a22d-e2bc9a1d5f55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57f988b1-567f-4079-a22d-e2bc9a1d5f55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57f988b1-567f-4079-a22d-e2bc9a1d5f55">
											<gml:posList>35.669310581915866 139.7483642935049 5.78 35.66932623835643 139.74832539458865 5.78 35.66932623835643 139.74832539458865 39.1 35.669310581915866 139.7483642935049 39.1 35.669310581915866 139.7483642935049 5.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f257ef44-3c84-49ea-ba1b-73f1afd1773e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f257ef44-3c84-49ea-ba1b-73f1afd1773e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f257ef44-3c84-49ea-ba1b-73f1afd1773e">
											<gml:posList>35.66915053340959 139.74842724909084 39.1 35.66915053340959 139.74842724909084 38.633 35.669216632274235 139.7482628683607 38.633 35.669216632274235 139.7482628683607 39.1 35.66915053340959 139.74842724909084 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06a013bf-e3ce-48c6-9694-e921bea00e9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06a013bf-e3ce-48c6-9694-e921bea00e9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06a013bf-e3ce-48c6-9694-e921bea00e9f">
											<gml:posList>35.66932264293241 139.748326889626 39.1 35.66932264293241 139.748326889626 38.633 35.669306977493214 139.74836581064199 38.633 35.669306977493214 139.74836581064199 39.1 35.66932264293241 139.748326889626 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43386c31-d391-4d8c-8b04-da93f7aa1dfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43386c31-d391-4d8c-8b04-da93f7aa1dfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43386c31-d391-4d8c-8b04-da93f7aa1dfd">
											<gml:posList>35.66929650514411 139.74835531688805 43.089 35.66929650514411 139.74835531688805 42.8 35.669271291999095 139.74834008893532 42.8 35.669271291999095 139.74834008893532 43.089 35.66929650514411 139.74835531688805 43.089</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c96bf872-80ac-4c71-840d-f91d222368af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c96bf872-80ac-4c71-840d-f91d222368af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c96bf872-80ac-4c71-840d-f91d222368af">
											<gml:posList>35.6692691203304 139.74834099701812 38.633 35.669297237134586 139.74835797822502 38.633 35.669297237134586 139.74835797822502 43.089 35.6692691203304 139.74834099701812 43.089 35.6692691203304 139.74834099701812 38.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7aa53362-7533-43fe-a056-d84d3b8e4bfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7aa53362-7533-43fe-a056-d84d3b8e4bfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7aa53362-7533-43fe-a056-d84d3b8e4bfc">
											<gml:posList>35.66931527100211 139.74836705006416 5.78 35.669310581915866 139.7483642935049 5.78 35.669310581915866 139.7483642935049 39.1 35.66931527100211 139.74836705006416 39.1 35.66931527100211 139.74836705006416 5.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e43810be-57c6-4def-a6c9-e4c27785f1eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e43810be-57c6-4def-a6c9-e4c27785f1eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e43810be-57c6-4def-a6c9-e4c27785f1eb">
											<gml:posList>35.669306977493214 139.74836581064199 39.1 35.669306977493214 139.74836581064199 38.633 35.66931167559316 139.74836856719165 38.633 35.66931167559316 139.74836856719165 39.1 35.669306977493214 139.74836581064199 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f85289bb-fd95-448d-a5ee-d89d75d26915">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f85289bb-fd95-448d-a5ee-d89d75d26915">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f85289bb-fd95-448d-a5ee-d89d75d26915">
											<gml:posList>35.66931167559316 139.74836856719165 39.1 35.66931167559316 139.74836856719165 38.633 35.66930909319754 139.74837500981178 38.633 35.66930909319754 139.74837500981178 39.1 35.66931167559316 139.74836856719165 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18282438-0a7f-4bc8-9884-70ac1585756c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18282438-0a7f-4bc8-9884-70ac1585756c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18282438-0a7f-4bc8-9884-70ac1585756c">
											<gml:posList>35.66930909319754 139.74837500981178 39.1 35.66930909319754 139.74837500981178 38.633 35.669302420172016 139.7483709519133 38.633 35.669302420172016 139.7483709519133 39.1 35.66930909319754 139.74837500981178 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5300520-1514-4f0f-952c-b4db85147e83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5300520-1514-4f0f-952c-b4db85147e83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5300520-1514-4f0f-952c-b4db85147e83">
											<gml:posList>35.66931032218165 139.7483794269547 5.78 35.66931527100211 139.74836705006416 5.78 35.66931527100211 139.74836705006416 39.1 35.66931032218165 139.7483794269547 39.1 35.66931032218165 139.7483794269547 5.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cd35870-def9-4114-8447-1de2c1fd9f51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cd35870-def9-4114-8447-1de2c1fd9f51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cd35870-def9-4114-8447-1de2c1fd9f51">
											<gml:posList>35.66930364014256 139.74837536906534 5.78 35.66931032218165 139.7483794269547 5.78 35.66931032218165 139.7483794269547 39.1 35.66930364014256 139.74837536906534 39.1 35.66930364014256 139.74837536906534 5.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef5bf495-e1ac-4459-84b0-98bea97b3b51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef5bf495-e1ac-4459-84b0-98bea97b3b51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef5bf495-e1ac-4459-84b0-98bea97b3b51">
											<gml:posList>35.669302420172016 139.7483709519133 39.1 35.669302420172016 139.7483709519133 38.633 35.66925446996857 139.74849005764403 38.633 35.66925446996857 139.74849005764403 39.1 35.669302420172016 139.7483709519133 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f6a0086-3e57-4ce2-958a-fb29ca348b4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f6a0086-3e57-4ce2-958a-fb29ca348b4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f6a0086-3e57-4ce2-958a-fb29ca348b4a">
											<gml:posList>35.669255689934744 139.74849447479525 5.78 35.66930364014256 139.74837536906534 5.78 35.66930364014256 139.74837536906534 39.1 35.669255689934744 139.74849447479525 39.1 35.669255689934744 139.74849447479525 5.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f05e346-a063-4528-bc38-a554ad51d84d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f05e346-a063-4528-bc38-a554ad51d84d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f05e346-a063-4528-bc38-a554ad51d84d">
											<gml:posList>35.66925446996857 139.74849005764403 39.1 35.66925446996857 139.74849005764403 38.633 35.66915053340959 139.74842724909084 38.633 35.66915053340959 139.74842724909084 39.1 35.66925446996857 139.74849005764403 39.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c794e69b-8aa2-40ee-8538-66da4be5588f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c794e69b-8aa2-40ee-8538-66da4be5588f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c794e69b-8aa2-40ee-8538-66da4be5588f">
											<gml:posList>35.66914693799196 139.7484287551664 5.78 35.669255689934744 139.74849447479525 5.78 35.669255689934744 139.74849447479525 39.1 35.66914693799196 139.7484287551664 39.1 35.66914693799196 139.7484287551664 5.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10050</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">233.2875</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>