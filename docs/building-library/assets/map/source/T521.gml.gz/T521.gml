<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_97364e89-cce9-4e91-a4bb-a1fe70fdafb9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="地区計画">
				<gen:value>虎ノ門二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">164.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>35</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66993271025251 139.7455997649046 0 35.669680472146695 139.74530632341927 0 35.66943724051468 139.74562052147039 0 35.66968956784208 139.74591374203584 0 35.66993271025251 139.7455997649046 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66993271025251 139.7455997649046 7.6 35.66968956784208 139.74591374203584 7.6 35.66943724051468 139.74562052147039 7.6 35.669680472146695 139.74530632341927 7.6 35.66993271025251 139.7455997649046 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66993271025251 139.7455997649046 7.6 35.669680472146695 139.74530632341927 7.6 35.669680472146695 139.74530632341927 161.61 35.66993271025251 139.7455997649046 161.61 35.66993271025251 139.7455997649046 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669680472146695 139.74530632341927 7.6 35.66943724051468 139.74562052147039 7.6 35.66943724051468 139.74562052147039 161.61 35.669680472146695 139.74530632341927 161.61 35.669680472146695 139.74530632341927 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66943724051468 139.74562052147039 7.6 35.66968956784208 139.74591374203584 7.6 35.66968956784208 139.74591374203584 161.61 35.66943724051468 139.74562052147039 161.61 35.66943724051468 139.74562052147039 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66968956784208 139.74591374203584 7.6 35.66993271025251 139.7455997649046 7.6 35.66993271025251 139.7455997649046 161.61 35.66968956784208 139.74591374203584 161.61 35.66968956784208 139.74591374203584 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66993271025251 139.7455997649046 161.61 35.669680472146695 139.74530632341927 161.61 35.66943724051468 139.74562052147039 161.61 35.66968956784208 139.74591374203584 161.61 35.66993271025251 139.7455997649046 161.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9d522b77-7215-4a5f-bd25-3a0a10cea2a3"/>
							<gml:surfaceMember xlink:href="#poly-3f61e156-5e6b-46a3-af28-1d59696d7b2c"/>
							<gml:surfaceMember xlink:href="#poly-f0bcc6e6-6a03-48ce-9a50-0704f9d4ba74"/>
							<gml:surfaceMember xlink:href="#poly-ca181fd2-624b-4195-9b1c-01fdeb5fc458"/>
							<gml:surfaceMember xlink:href="#poly-bd5a5978-99e1-47db-a5fb-65caede6cc8f"/>
							<gml:surfaceMember xlink:href="#poly-ab6a625e-f45d-438a-882c-1903b6f1bb03"/>
							<gml:surfaceMember xlink:href="#poly-a585b8f3-cbe8-4b9a-9361-78a8e22db5bc"/>
							<gml:surfaceMember xlink:href="#poly-58ff72aa-96f2-45c4-945b-2869fbd6b8c2"/>
							<gml:surfaceMember xlink:href="#poly-672af26b-f5fb-4b8a-a5ee-b779977c1fda"/>
							<gml:surfaceMember xlink:href="#poly-b78c28c6-6c4a-4b39-9cc9-897c516c960a"/>
							<gml:surfaceMember xlink:href="#poly-c4d205e8-51ee-4a64-a84a-6cd0bd2a3275"/>
							<gml:surfaceMember xlink:href="#poly-3d22f2be-5a30-4148-866f-b5e46cb23bda"/>
							<gml:surfaceMember xlink:href="#poly-a6308e7a-56af-4528-bbbd-d39668f8039f"/>
							<gml:surfaceMember xlink:href="#poly-4a22ed0a-51b0-460d-836c-fac125665ea3"/>
							<gml:surfaceMember xlink:href="#poly-c1a9becc-1c10-4d87-8ef3-48da01c56b14"/>
							<gml:surfaceMember xlink:href="#poly-af9891ed-a654-4a55-a8da-495309d6d68e"/>
							<gml:surfaceMember xlink:href="#poly-371d6f87-d0c5-4140-8da8-7b6671276dfd"/>
							<gml:surfaceMember xlink:href="#poly-d3c3e0e4-c324-469b-8c68-1d1e2b0f073e"/>
							<gml:surfaceMember xlink:href="#poly-150c0b67-2336-422d-bf23-7e1dff2325f4"/>
							<gml:surfaceMember xlink:href="#poly-f6c7ce6b-cc22-4977-b539-c41acf0609d9"/>
							<gml:surfaceMember xlink:href="#poly-3d91ff47-0119-47ba-8cfa-a11b2b05c336"/>
							<gml:surfaceMember xlink:href="#poly-84524b53-a431-4f17-8228-e7730471f6b4"/>
							<gml:surfaceMember xlink:href="#poly-a8e9ee65-a401-41a2-9ea2-43e798335079"/>
							<gml:surfaceMember xlink:href="#poly-a9cffc84-55d1-40b1-b776-4fa978452cf0"/>
							<gml:surfaceMember xlink:href="#poly-b25af265-81b5-4785-a9db-9b9c2ff4868b"/>
							<gml:surfaceMember xlink:href="#poly-857b98e3-6a35-40ac-90ce-75cae77aebcc"/>
							<gml:surfaceMember xlink:href="#poly-322fc3e9-c4c8-4de7-b77f-4ce8bd525080"/>
							<gml:surfaceMember xlink:href="#poly-c1bc4a13-0f6e-4aa3-a7dd-120abd8ac3c7"/>
							<gml:surfaceMember xlink:href="#poly-fab253cf-e7b7-48e5-b698-0986af28a879"/>
							<gml:surfaceMember xlink:href="#poly-f028cf54-868f-4c0e-896d-c9e15d886ea1"/>
							<gml:surfaceMember xlink:href="#poly-0e1de1b4-5c9b-443d-9ff0-3b70cfb8539f"/>
							<gml:surfaceMember xlink:href="#poly-8c7b23e5-3b48-4117-9892-a3928b1e66ca"/>
							<gml:surfaceMember xlink:href="#poly-d7c90105-7500-421c-b448-b9accfc0180f"/>
							<gml:surfaceMember xlink:href="#poly-8388c845-948d-4c44-81c7-c5d1e9380923"/>
							<gml:surfaceMember xlink:href="#poly-b30da2ae-f940-4d76-be02-ce9610fdc7d4"/>
							<gml:surfaceMember xlink:href="#poly-745e0c61-542d-442c-9601-ed7f043cddd5"/>
							<gml:surfaceMember xlink:href="#poly-95ed6e4c-29c2-4593-b104-aebeb8d0563d"/>
							<gml:surfaceMember xlink:href="#poly-75a71de8-4310-434c-a0d6-03192b5f9a70"/>
							<gml:surfaceMember xlink:href="#poly-053ded67-b0ec-4709-8d5c-6853b32ff406"/>
							<gml:surfaceMember xlink:href="#poly-5abac22c-53ca-4614-a5f9-38d5dc871f75"/>
							<gml:surfaceMember xlink:href="#poly-2f365498-16b9-4869-9c13-d111e515ec0c"/>
							<gml:surfaceMember xlink:href="#poly-d27d2939-228e-4bc8-bc16-c33a61814e22"/>
							<gml:surfaceMember xlink:href="#poly-b439cb3d-c239-42da-99ca-c59278e4df62"/>
							<gml:surfaceMember xlink:href="#poly-7d674177-aa45-426c-9dfd-aa6681479819"/>
							<gml:surfaceMember xlink:href="#poly-0774f23d-9ffa-4d7c-bb67-0d5450558f80"/>
							<gml:surfaceMember xlink:href="#poly-30992a2f-cf99-46bc-83be-11bae8f3eb63"/>
							<gml:surfaceMember xlink:href="#poly-caae0169-6643-4d2f-9dfd-7a756f6cf133"/>
							<gml:surfaceMember xlink:href="#poly-ad355bc2-bc3a-46cc-bf87-c5945a7eece8"/>
							<gml:surfaceMember xlink:href="#poly-17e26830-7776-41cb-86a4-5d9e0d096911"/>
							<gml:surfaceMember xlink:href="#poly-26b63774-af3c-4a89-b05e-ab857b5ed3d3"/>
							<gml:surfaceMember xlink:href="#poly-71bfd853-2792-4b2d-bb96-347d14e6a71e"/>
							<gml:surfaceMember xlink:href="#poly-2a03b862-9240-4643-ad35-f45a138b4a8f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_97364e89-cce9-4e91-a4bb-a1fe70fdafb9_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2354c15d-3b1f-4daa-9242-4e19d20648cd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66974696957187 139.74544633797547 174.895 35.66972979721422 139.74546939910988 174.895 35.66972317573152 139.7454619943863 174.895 35.669740348087764 139.74543893325222 174.895 35.66974696957187 139.74544633797547 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b708d007-15d6-4e72-a73e-ef47f0af2dd1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66979904429161 139.7455484691048 174.895 35.66979425341896 139.74555454974868 174.895 35.669770562888964 139.745526474213 174.895 35.669775326751264 139.7455204377835 174.895 35.66979904429161 139.7455484691048 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f814dfbf-3ac9-4ca1-98cb-5dbb841cb472">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669770571902696 139.74552647420313 179.206 35.669770562888964 139.745526474213 174.895 35.66979425341896 139.74555454974868 174.895 35.66979425341896 139.74555454974868 179.206 35.669770571902696 139.74552647420313 179.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa6c3d04-77bb-4d29-a6dc-245bc260429f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669768221495296 139.74552945924452 179.206 35.669770571902696 139.74552647420313 179.206 35.66979425341896 139.74555454974868 179.206 35.66979190301088 139.74555753479018 179.206 35.669768221495296 139.74552945924452 179.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-624eb130-381a-4256-8347-2469488f7379">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66979190301088 139.74555753479018 179.067 35.669768221495296 139.74552945924452 179.067 35.669768221495296 139.74552945924452 179.206 35.66979190301088 139.74555753479018 179.206 35.66979190301088 139.74555753479018 179.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c401b42-472e-4c09-821d-346652fcc7ad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6697677081882 139.745530111531 179.067 35.669768221495296 139.74552945924452 179.067 35.66979190301088 139.74555753479018 179.067 35.66979142573438 139.74555815389868 179.067 35.6697677081882 139.745530111531 179.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-944d7bac-91cf-4968-ae91-68b763405a9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-944d7bac-91cf-4968-ae91-68b763405a9e_0">
											<gml:posList>35.66974696957187 139.74544633797547 174.895 35.669740348087764 139.74543893325222 174.895 35.669740348087764 139.74543893325222 177.95 35.66974696957187 139.74544633797547 177.95 35.66974696957187 139.74544633797547 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb5e433a-7f1d-4ec6-9a6b-0083a551f64e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb5e433a-7f1d-4ec6-9a6b-0083a551f64e_0">
											<gml:posList>35.669740348087764 139.74543893325222 174.895 35.66972317573152 139.7454619943863 174.895 35.66972317573152 139.7454619943863 177.95 35.669740348087764 139.74543893325222 177.95 35.669740348087764 139.74543893325222 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8112ba65-a643-40b7-8917-5f058509846f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8112ba65-a643-40b7-8917-5f058509846f_0">
											<gml:posList>35.66974696957187 139.74544633797547 177.95 35.669740348087764 139.74543893325222 177.95 35.66972317573152 139.7454619943863 177.95 35.66972979721422 139.74546939910988 177.95 35.66974696957187 139.74544633797547 177.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02a9ae15-f287-4f4d-9f0b-3e9b830bb594">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02a9ae15-f287-4f4d-9f0b-3e9b830bb594_0">
											<gml:posList>35.66974696957187 139.74544633797547 174.895 35.66974696957187 139.74544633797547 177.95 35.66972979721422 139.74546939910988 177.95 35.66972979721422 139.74546939910988 174.895 35.66974696957187 139.74544633797547 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea8ecebc-7515-4993-afcc-f3f4e93e021c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea8ecebc-7515-4993-afcc-f3f4e93e021c_0">
											<gml:posList>35.66972317573152 139.7454619943863 174.895 35.66972979721422 139.74546939910988 174.895 35.66972979721422 139.74546939910988 177.95 35.66972317573152 139.7454619943863 177.95 35.66972317573152 139.7454619943863 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53627dbc-e08f-40da-a7db-ff8b362a6750">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53627dbc-e08f-40da-a7db-ff8b362a6750_0">
											<gml:posList>35.669770571902696 139.74552647420313 179.206 35.669768221495296 139.74552945924452 179.206 35.669768221495296 139.74552945924452 179.067 35.6697677081882 139.745530111531 179.067 35.6697677081882 139.745530111531 179.386 35.669775326751264 139.7455204377835 179.386 35.669775326751264 139.7455204377835 174.895 35.669770562888964 139.745526474213 174.895 35.669770571902696 139.74552647420313 179.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b3e8aaf-dec7-4478-8361-f5f6a4ff4028">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b3e8aaf-dec7-4478-8361-f5f6a4ff4028_0">
											<gml:posList>35.66979904429161 139.7455484691048 174.895 35.669775326751264 139.7455204377835 174.895 35.669775326751264 139.7455204377835 179.386 35.66979904429161 139.7455484691048 179.386 35.66979904429161 139.7455484691048 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24b7b4cf-86e8-4f1a-8a03-655cecdb652c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24b7b4cf-86e8-4f1a-8a03-655cecdb652c_0">
											<gml:posList>35.669775326751264 139.7455204377835 179.386 35.6697677081882 139.745530111531 179.386 35.66979142573438 139.74555815389868 179.386 35.66979904429161 139.7455484691048 179.386 35.669775326751264 139.7455204377835 179.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bab516c-6159-48ee-9551-dedaa67cf78c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bab516c-6159-48ee-9551-dedaa67cf78c_0">
											<gml:posList>35.6697677081882 139.745530111531 179.067 35.66979142573438 139.74555815389868 179.067 35.66979142573438 139.74555815389868 179.386 35.6697677081882 139.745530111531 179.386 35.6697677081882 139.745530111531 179.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a84a00fa-bd64-414e-aeaa-cdfe0792730d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a84a00fa-bd64-414e-aeaa-cdfe0792730d_0">
											<gml:posList>35.66979190301088 139.74555753479018 179.206 35.66979425341896 139.74555454974868 179.206 35.66979425341896 139.74555454974868 174.895 35.66979904429161 139.7455484691048 174.895 35.66979904429161 139.7455484691048 179.386 35.66979142573438 139.74555815389868 179.386 35.66979142573438 139.74555815389868 179.067 35.66979190301088 139.74555753479018 179.067 35.66979190301088 139.74555753479018 179.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_97364e89-cce9-4e91-a4bb-a1fe70fdafb9_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f888d1a8-1467-4c62-8a25-d42071e2f9ab">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66972885367313 139.7454116286737 174.895 35.66973617178836 139.74542255635845 174.895 35.66972791225069 139.74543085004197 174.895 35.669720603158 139.7454199333939 174.895 35.66972885367313 139.7454116286737 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26714c6e-19a2-444f-9cb6-23128f09e6e0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6697135744628 139.74544739082825 174.895 35.66970355914957 139.7454335940978 174.895 35.66971541178471 139.7454206681331 174.895 35.6697254270994 139.745434464864 174.895 35.6697135744628 139.74544739082825 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44f1f519-1732-4937-bb23-22225bb39f62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44f1f519-1732-4937-bb23-22225bb39f62_0">
											<gml:posList>35.669720603158 139.7454199333939 174.895 35.66972791225069 139.74543085004197 174.895 35.66972791225069 139.74543085004197 177.494 35.669720603158 139.7454199333939 177.494 35.669720603158 139.7454199333939 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c8122ba-d182-4e71-89c7-67e54f5e298f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c8122ba-d182-4e71-89c7-67e54f5e298f_0">
											<gml:posList>35.66970355914957 139.7454335940978 174.895 35.6697135744628 139.74544739082825 174.895 35.6697135744628 139.74544739082825 177.494 35.66970355914957 139.7454335940978 177.494 35.66970355914957 139.7454335940978 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db0a279c-c33b-4a39-88b5-147d08b67cd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db0a279c-c33b-4a39-88b5-147d08b67cd8_0">
											<gml:posList>35.66971541178471 139.7454206681331 174.895 35.66970355914957 139.7454335940978 174.895 35.66970355914957 139.7454335940978 177.494 35.66971541178471 139.7454206681331 177.494 35.66971541178471 139.7454206681331 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b2ae925-c641-46e2-8923-222a609224cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b2ae925-c641-46e2-8923-222a609224cd_0">
											<gml:posList>35.6697135744628 139.74544739082825 177.494 35.6697254270994 139.745434464864 177.494 35.66971541178471 139.7454206681331 177.494 35.66970355914957 139.7454335940978 177.494 35.6697135744628 139.74544739082825 177.494</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1114c6e-e789-44dc-8f45-c7f66df4daeb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1114c6e-e789-44dc-8f45-c7f66df4daeb_0">
											<gml:posList>35.6697254270994 139.745434464864 174.895 35.6697254270994 139.745434464864 177.494 35.6697135744628 139.74544739082825 177.494 35.6697135744628 139.74544739082825 174.895 35.6697254270994 139.745434464864 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67ebf2d9-d9c5-488b-9e33-7b7110134297">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67ebf2d9-d9c5-488b-9e33-7b7110134297_0">
											<gml:posList>35.6697254270994 139.745434464864 174.895 35.66971541178471 139.7454206681331 174.895 35.66971541178471 139.7454206681331 177.494 35.6697254270994 139.745434464864 177.494 35.6697254270994 139.745434464864 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6ea402b-b102-4f87-9b03-7a9f121b2444">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6ea402b-b102-4f87-9b03-7a9f121b2444_0">
											<gml:posList>35.66972885367313 139.7454116286737 174.895 35.669720603158 139.7454199333939 174.895 35.669720603158 139.7454199333939 177.494 35.66972885367313 139.7454116286737 177.494 35.66972885367313 139.7454116286737 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff2f140f-9c4c-4ceb-bafc-a13f96ac10e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff2f140f-9c4c-4ceb-bafc-a13f96ac10e4_0">
											<gml:posList>35.66972885367313 139.7454116286737 177.494 35.669720603158 139.7454199333939 177.494 35.66972791225069 139.74543085004197 177.494 35.66973617178836 139.74542255635845 177.494 35.66972885367313 139.7454116286737 177.494</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b65d186-ed2c-474a-b36d-14bee4cb19c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b65d186-ed2c-474a-b36d-14bee4cb19c8_0">
											<gml:posList>35.66972791225069 139.74543085004197 174.895 35.66973617178836 139.74542255635845 174.895 35.66973617178836 139.74542255635845 177.494 35.66972791225069 139.74543085004197 177.494 35.66972791225069 139.74543085004197 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37be852e-6d6b-4c90-b2f6-2c14efe15021">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37be852e-6d6b-4c90-b2f6-2c14efe15021_0">
											<gml:posList>35.66973617178836 139.74542255635845 174.895 35.66972885367313 139.7454116286737 174.895 35.66972885367313 139.7454116286737 177.494 35.66973617178836 139.74542255635845 177.494 35.66973617178836 139.74542255635845 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9d522b77-7215-4a5f-bd25-3a0a10cea2a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d522b77-7215-4a5f-bd25-3a0a10cea2a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d522b77-7215-4a5f-bd25-3a0a10cea2a3">
											<gml:posList>35.66993271025252 139.7455997649046 7.6 35.669689567842056 139.7459137420358 7.6 35.66943724051468 139.74562052147039 7.6 35.66968047214668 139.74530632341927 7.6 35.66993271025252 139.7455997649046 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f61e156-5e6b-46a3-af28-1d59696d7b2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f61e156-5e6b-46a3-af28-1d59696d7b2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f61e156-5e6b-46a3-af28-1d59696d7b2c">
											<gml:posList>35.66943724051468 139.74562052147039 178.4 35.66944837220806 139.7456201558167 178.4 35.66954230601536 139.7454988326678 178.4 35.66954207065604 139.74548510256804 178.4 35.66943724051468 139.74562052147039 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0bcc6e6-6a03-48ce-9a50-0704f9d4ba74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0bcc6e6-6a03-48ce-9a50-0704f9d4ba74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0bcc6e6-6a03-48ce-9a50-0704f9d4ba74">
											<gml:posList>35.669574990292936 139.74552421405212 178.4 35.66954207065604 139.74548510256804 178.4 35.66954230601536 139.7454988326678 178.4 35.669575081299335 139.7455377675773 178.4 35.669574990292936 139.74552421405212 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca181fd2-624b-4195-9b1c-01fdeb5fc458">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca181fd2-624b-4195-9b1c-01fdeb5fc458">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca181fd2-624b-4195-9b1c-01fdeb5fc458">
											<gml:posList>35.669689567842056 139.7459137420358 178.4 35.66968926949811 139.74590010034757 178.4 35.66944837220806 139.7456201558167 178.4 35.66943724051468 139.74562052147039 178.4 35.669689567842056 139.7459137420358 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd5a5978-99e1-47db-a5fb-65caede6cc8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd5a5978-99e1-47db-a5fb-65caede6cc8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd5a5978-99e1-47db-a5fb-65caede6cc8f">
											<gml:posList>35.66968295476439 139.74542262575304 174.895 35.66968076155223 139.74531997615972 174.895 35.66958661182424 139.7454416092567 174.895 35.669620938196395 139.74548151452643 174.895 35.669575081299335 139.7455377675773 174.895 35.66954230601536 139.7454988326678 174.895 35.66944837220806 139.7456201558167 174.895 35.66968926949811 139.74590010034757 174.895 35.66968569096786 139.74578833915956 174.895 35.66953406806171 139.74561093795518 174.895 35.66968295476439 139.74542262575304 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab6a625e-f45d-438a-882c-1903b6f1bb03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab6a625e-f45d-438a-882c-1903b6f1bb03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab6a625e-f45d-438a-882c-1903b6f1bb03">
											<gml:posList>35.669574990292936 139.74552421405212 168.2 35.66960965313346 139.7454816925836 168.2 35.66957547110186 139.74544195285344 168.2 35.66954207065604 139.74548510256804 168.2 35.669574990292936 139.74552421405212 168.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a585b8f3-cbe8-4b9a-9361-78a8e22db5bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a585b8f3-cbe8-4b9a-9361-78a8e22db5bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a585b8f3-cbe8-4b9a-9361-78a8e22db5bc">
											<gml:posList>35.66960965313346 139.7454816925836 178.4 35.669574990292936 139.74552421405212 178.4 35.669575081299335 139.7455377675773 178.4 35.669620938196395 139.74548151452643 178.4 35.66960965313346 139.7454816925836 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-58ff72aa-96f2-45c4-945b-2869fbd6b8c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58ff72aa-96f2-45c4-945b-2869fbd6b8c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58ff72aa-96f2-45c4-945b-2869fbd6b8c2">
											<gml:posList>35.66960965313346 139.7454816925836 178.4 35.669620938196395 139.74548151452643 178.4 35.66958661182424 139.7454416092567 178.4 35.66957547110186 139.74544195285344 178.4 35.66960965313346 139.7454816925836 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-672af26b-f5fb-4b8a-a5ee-b779977c1fda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-672af26b-f5fb-4b8a-a5ee-b779977c1fda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-672af26b-f5fb-4b8a-a5ee-b779977c1fda">
											<gml:posList>35.66953406806171 139.74561093795518 179.206 35.66953886328308 139.74561082224744 179.206 35.66968303114821 139.74542848013616 179.206 35.66968295476439 139.74542262575304 179.206 35.66953406806171 139.74561093795518 179.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b78c28c6-6c4a-4b39-9cc9-897c516c960a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b78c28c6-6c4a-4b39-9cc9-897c516c960a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b78c28c6-6c4a-4b39-9cc9-897c516c960a">
											<gml:posList>35.66968569096786 139.74578833915956 179.206 35.66968563267717 139.74578255103313 179.206 35.66953886328308 139.74561082224744 179.206 35.66953406806171 139.74561093795518 179.206 35.66968569096786 139.74578833915956 179.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c4d205e8-51ee-4a64-a84a-6cd0bd2a3275">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4d205e8-51ee-4a64-a84a-6cd0bd2a3275">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4d205e8-51ee-4a64-a84a-6cd0bd2a3275">
											<gml:posList>35.66957547110186 139.74544195285344 178.4 35.66958661182424 139.7454416092567 178.4 35.66968076155223 139.74531997615972 178.4 35.66968047214668 139.74530632341927 178.4 35.66957547110186 139.74544195285344 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d22f2be-5a30-4148-866f-b5e46cb23bda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d22f2be-5a30-4148-866f-b5e46cb23bda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d22f2be-5a30-4148-866f-b5e46cb23bda">
											<gml:posList>35.66968563267717 139.74578255103313 179.067 35.669831408267875 139.7456043605021 179.067 35.66968303114821 139.74542848013616 179.067 35.66953886328308 139.74561082224744 179.067 35.66968563267717 139.74578255103313 179.067</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6308e7a-56af-4528-bbbd-d39668f8039f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6308e7a-56af-4528-bbbd-d39668f8039f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6308e7a-56af-4528-bbbd-d39668f8039f">
											<gml:posList>35.66979285843959 139.74578035726776 178.4 35.66978179877583 139.74578061236042 178.4 35.66968926949811 139.74590010034757 178.4 35.669689567842056 139.7459137420358 178.4 35.66979285843959 139.74578035726776 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a22ed0a-51b0-460d-836c-fac125665ea3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a22ed0a-51b0-460d-836c-fac125665ea3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a22ed0a-51b0-460d-836c-fac125665ea3">
											<gml:posList>35.66968295476439 139.74542262575304 179.206 35.66968303114821 139.74542848013616 179.206 35.669831408267875 139.7456043605021 179.206 35.66983623959217 139.74560431103114 179.206 35.66968295476439 139.74542262575304 179.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c1a9becc-1c10-4d87-8ef3-48da01c56b14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1a9becc-1c10-4d87-8ef3-48da01c56b14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1a9becc-1c10-4d87-8ef3-48da01c56b14">
											<gml:posList>35.66983623959217 139.74560431103114 179.206 35.669831408267875 139.7456043605021 179.206 35.66968563267717 139.74578255103313 179.206 35.66968569096786 139.74578833915956 179.206 35.66983623959217 139.74560431103114 179.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af9891ed-a654-4a55-a8da-495309d6d68e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af9891ed-a654-4a55-a8da-495309d6d68e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af9891ed-a654-4a55-a8da-495309d6d68e">
											<gml:posList>35.6697599566973 139.74574094730607 178.4 35.66974886994417 139.74574113615662 178.4 35.66978179877583 139.74578061236042 178.4 35.66979285843959 139.74578035726776 178.4 35.6697599566973 139.74574094730607 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-371d6f87-d0c5-4140-8da8-7b6671276dfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-371d6f87-d0c5-4140-8da8-7b6671276dfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-371d6f87-d0c5-4140-8da8-7b6671276dfd">
											<gml:posList>35.66979379894628 139.7456978523285 178.4 35.66979354567865 139.7456842547588 178.4 35.66974886994417 139.74574113615662 178.4 35.6697599566973 139.74574094730607 178.4 35.66979379894628 139.7456978523285 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3c3e0e4-c324-469b-8c68-1d1e2b0f073e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3c3e0e4-c324-469b-8c68-1d1e2b0f073e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3c3e0e4-c324-469b-8c68-1d1e2b0f073e">
											<gml:posList>35.66982692539474 139.7457363673027 168.2 35.66979379894628 139.7456978523285 168.2 35.6697599566973 139.74574094730607 168.2 35.66979285843959 139.74578035726776 168.2 35.66982692539474 139.7457363673027 168.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-150c0b67-2336-422d-bf23-7e1dff2325f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-150c0b67-2336-422d-bf23-7e1dff2325f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-150c0b67-2336-422d-bf23-7e1dff2325f4">
											<gml:posList>35.66992156954639 139.74560013057328 174.895 35.66968076155223 139.74531997615972 174.895 35.66968295476439 139.74542262575304 174.895 35.66983623959217 139.74560431103114 174.895 35.66968569096786 139.74578833915956 174.895 35.66968926949811 139.74590010034757 174.895 35.66978179877583 139.74578061236042 174.895 35.66974886994417 139.74574113615662 174.895 35.66979354567865 139.7456842547588 174.895 35.669826627030666 139.7457227255918 174.895 35.66992156954639 139.74560013057328 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f6c7ce6b-cc22-4977-b539-c41acf0609d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6c7ce6b-cc22-4977-b539-c41acf0609d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6c7ce6b-cc22-4977-b539-c41acf0609d9">
											<gml:posList>35.66968047214668 139.74530632341927 178.4 35.66968076155223 139.74531997615972 178.4 35.66992156954639 139.74560013057328 178.4 35.66993271025252 139.7455997649046 178.4 35.66968047214668 139.74530632341927 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d91ff47-0119-47ba-8cfa-a11b2b05c336">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d91ff47-0119-47ba-8cfa-a11b2b05c336">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d91ff47-0119-47ba-8cfa-a11b2b05c336">
											<gml:posList>35.66979379894628 139.7456978523285 178.4 35.66982692539474 139.7457363673027 178.4 35.669826627030666 139.7457227255918 178.4 35.66979354567865 139.7456842547588 178.4 35.66979379894628 139.7456978523285 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-84524b53-a431-4f17-8228-e7730471f6b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84524b53-a431-4f17-8228-e7730471f6b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84524b53-a431-4f17-8228-e7730471f6b4">
											<gml:posList>35.66993271025252 139.7455997649046 178.4 35.66992156954639 139.74560013057328 178.4 35.669826627030666 139.7457227255918 178.4 35.66982692539474 139.7457363673027 178.4 35.66993271025252 139.7455997649046 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8e9ee65-a401-41a2-9ea2-43e798335079">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8e9ee65-a401-41a2-9ea2-43e798335079">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8e9ee65-a401-41a2-9ea2-43e798335079">
											<gml:posList>35.66953886328308 139.74561082224744 179.206 35.66953886328308 139.74561082224744 179.067 35.66968303114821 139.74542848013616 179.067 35.66968303114821 139.74542848013616 179.206 35.66953886328308 139.74561082224744 179.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9cffc84-55d1-40b1-b776-4fa978452cf0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9cffc84-55d1-40b1-b776-4fa978452cf0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9cffc84-55d1-40b1-b776-4fa978452cf0">
											<gml:posList>35.669831408267875 139.7456043605021 179.206 35.669831408267875 139.7456043605021 179.067 35.66968563267717 139.74578255103313 179.067 35.66968563267717 139.74578255103313 179.206 35.669831408267875 139.7456043605021 179.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b25af265-81b5-4785-a9db-9b9c2ff4868b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b25af265-81b5-4785-a9db-9b9c2ff4868b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b25af265-81b5-4785-a9db-9b9c2ff4868b">
											<gml:posList>35.66958661182424 139.7454416092567 178.4 35.66958661182424 139.7454416092567 174.895 35.66968076155223 139.74531997615972 174.895 35.66968076155223 139.74531997615972 178.4 35.66958661182424 139.7454416092567 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-857b98e3-6a35-40ac-90ce-75cae77aebcc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-857b98e3-6a35-40ac-90ce-75cae77aebcc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-857b98e3-6a35-40ac-90ce-75cae77aebcc">
											<gml:posList>35.66993271025252 139.7455997649046 7.6 35.66968047214668 139.74530632341927 7.6 35.66968047214668 139.74530632341927 178.4 35.66993271025252 139.7455997649046 178.4 35.66993271025252 139.7455997649046 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-322fc3e9-c4c8-4de7-b77f-4ce8bd525080">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-322fc3e9-c4c8-4de7-b77f-4ce8bd525080">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-322fc3e9-c4c8-4de7-b77f-4ce8bd525080">
											<gml:posList>35.66968076155223 139.74531997615972 178.4 35.66968076155223 139.74531997615972 174.895 35.66992156954639 139.74560013057328 174.895 35.66992156954639 139.74560013057328 178.4 35.66968076155223 139.74531997615972 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1bc4a13-0f6e-4aa3-a7dd-120abd8ac3c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1bc4a13-0f6e-4aa3-a7dd-120abd8ac3c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1bc4a13-0f6e-4aa3-a7dd-120abd8ac3c7">
											<gml:posList>35.669620938196395 139.74548151452643 178.4 35.669620938196395 139.74548151452643 174.895 35.66958661182424 139.7454416092567 174.895 35.66958661182424 139.7454416092567 178.4 35.669620938196395 139.74548151452643 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fab253cf-e7b7-48e5-b698-0986af28a879">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fab253cf-e7b7-48e5-b698-0986af28a879">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fab253cf-e7b7-48e5-b698-0986af28a879">
											<gml:posList>35.66960965313346 139.7454816925836 178.4 35.66957547110186 139.74544195285344 178.4 35.66957547110186 139.74544195285344 168.2 35.66960965313346 139.7454816925836 168.2 35.66960965313346 139.7454816925836 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f028cf54-868f-4c0e-896d-c9e15d886ea1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f028cf54-868f-4c0e-896d-c9e15d886ea1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f028cf54-868f-4c0e-896d-c9e15d886ea1">
											<gml:posList>35.66968047214668 139.74530632341927 178.4 35.66968047214668 139.74530632341927 7.6 35.66943724051468 139.74562052147039 7.6 35.66943724051468 139.74562052147039 178.4 35.66954207065604 139.74548510256804 178.4 35.66954207065604 139.74548510256804 168.2 35.66957547110186 139.74544195285344 168.2 35.66957547110186 139.74544195285344 178.4 35.66968047214668 139.74530632341927 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e1de1b4-5c9b-443d-9ff0-3b70cfb8539f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e1de1b4-5c9b-443d-9ff0-3b70cfb8539f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e1de1b4-5c9b-443d-9ff0-3b70cfb8539f">
											<gml:posList>35.669574990292936 139.74552421405212 178.4 35.66960965313346 139.7454816925836 178.4 35.66960965313346 139.7454816925836 168.2 35.669574990292936 139.74552421405212 168.2 35.669574990292936 139.74552421405212 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c7b23e5-3b48-4117-9892-a3928b1e66ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c7b23e5-3b48-4117-9892-a3928b1e66ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c7b23e5-3b48-4117-9892-a3928b1e66ca">
											<gml:posList>35.66954207065604 139.74548510256804 178.4 35.669574990292936 139.74552421405212 178.4 35.669574990292936 139.74552421405212 168.2 35.66954207065604 139.74548510256804 168.2 35.66954207065604 139.74548510256804 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7c90105-7500-421c-b448-b9accfc0180f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7c90105-7500-421c-b448-b9accfc0180f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7c90105-7500-421c-b448-b9accfc0180f">
											<gml:posList>35.669575081299335 139.7455377675773 178.4 35.669575081299335 139.7455377675773 174.895 35.669620938196395 139.74548151452643 174.895 35.669620938196395 139.74548151452643 178.4 35.669575081299335 139.7455377675773 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8388c845-948d-4c44-81c7-c5d1e9380923">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8388c845-948d-4c44-81c7-c5d1e9380923">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8388c845-948d-4c44-81c7-c5d1e9380923">
											<gml:posList>35.66968295476439 139.74542262575304 174.895 35.66968295476439 139.74542262575304 179.206 35.66983623959217 139.74560431103114 179.206 35.66983623959217 139.74560431103114 174.895 35.66968295476439 139.74542262575304 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b30da2ae-f940-4d76-be02-ce9610fdc7d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b30da2ae-f940-4d76-be02-ce9610fdc7d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b30da2ae-f940-4d76-be02-ce9610fdc7d4">
											<gml:posList>35.66968303114821 139.74542848013616 179.206 35.66968303114821 139.74542848013616 179.067 35.669831408267875 139.7456043605021 179.067 35.669831408267875 139.7456043605021 179.206 35.66968303114821 139.74542848013616 179.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-745e0c61-542d-442c-9601-ed7f043cddd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-745e0c61-542d-442c-9601-ed7f043cddd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-745e0c61-542d-442c-9601-ed7f043cddd5">
											<gml:posList>35.66953406806171 139.74561093795518 174.895 35.66953406806171 139.74561093795518 179.206 35.66968295476439 139.74542262575304 179.206 35.66968295476439 139.74542262575304 174.895 35.66953406806171 139.74561093795518 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95ed6e4c-29c2-4593-b104-aebeb8d0563d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95ed6e4c-29c2-4593-b104-aebeb8d0563d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95ed6e4c-29c2-4593-b104-aebeb8d0563d">
											<gml:posList>35.66954230601536 139.7454988326678 178.4 35.66954230601536 139.7454988326678 174.895 35.669575081299335 139.7455377675773 174.895 35.669575081299335 139.7455377675773 178.4 35.66954230601536 139.7454988326678 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75a71de8-4310-434c-a0d6-03192b5f9a70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75a71de8-4310-434c-a0d6-03192b5f9a70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75a71de8-4310-434c-a0d6-03192b5f9a70">
											<gml:posList>35.66944837220806 139.7456201558167 178.4 35.66944837220806 139.7456201558167 174.895 35.66954230601536 139.7454988326678 174.895 35.66954230601536 139.7454988326678 178.4 35.66944837220806 139.7456201558167 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-053ded67-b0ec-4709-8d5c-6853b32ff406">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-053ded67-b0ec-4709-8d5c-6853b32ff406">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-053ded67-b0ec-4709-8d5c-6853b32ff406">
											<gml:posList>35.66992156954639 139.74560013057328 178.4 35.66992156954639 139.74560013057328 174.895 35.669826627030666 139.7457227255918 174.895 35.669826627030666 139.7457227255918 178.4 35.66992156954639 139.74560013057328 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5abac22c-53ca-4614-a5f9-38d5dc871f75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5abac22c-53ca-4614-a5f9-38d5dc871f75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5abac22c-53ca-4614-a5f9-38d5dc871f75">
											<gml:posList>35.66983623959217 139.74560431103114 174.895 35.66983623959217 139.74560431103114 179.206 35.66968569096786 139.74578833915956 179.206 35.66968569096786 139.74578833915956 174.895 35.66983623959217 139.74560431103114 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f365498-16b9-4869-9c13-d111e515ec0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f365498-16b9-4869-9c13-d111e515ec0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f365498-16b9-4869-9c13-d111e515ec0c">
											<gml:posList>35.66968563267717 139.74578255103313 179.206 35.66968563267717 139.74578255103313 179.067 35.66953886328308 139.74561082224744 179.067 35.66953886328308 139.74561082224744 179.206 35.66968563267717 139.74578255103313 179.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d27d2939-228e-4bc8-bc16-c33a61814e22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d27d2939-228e-4bc8-bc16-c33a61814e22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d27d2939-228e-4bc8-bc16-c33a61814e22">
											<gml:posList>35.66968569096786 139.74578833915956 174.895 35.66968569096786 139.74578833915956 179.206 35.66953406806171 139.74561093795518 179.206 35.66953406806171 139.74561093795518 174.895 35.66968569096786 139.74578833915956 174.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b439cb3d-c239-42da-99ca-c59278e4df62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b439cb3d-c239-42da-99ca-c59278e4df62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b439cb3d-c239-42da-99ca-c59278e4df62">
											<gml:posList>35.669826627030666 139.7457227255918 178.4 35.669826627030666 139.7457227255918 174.895 35.66979354567865 139.7456842547588 174.895 35.66979354567865 139.7456842547588 178.4 35.669826627030666 139.7457227255918 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d674177-aa45-426c-9dfd-aa6681479819">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d674177-aa45-426c-9dfd-aa6681479819">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d674177-aa45-426c-9dfd-aa6681479819">
											<gml:posList>35.66979354567865 139.7456842547588 178.4 35.66979354567865 139.7456842547588 174.895 35.66974886994417 139.74574113615662 174.895 35.66974886994417 139.74574113615662 178.4 35.66979354567865 139.7456842547588 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0774f23d-9ffa-4d7c-bb67-0d5450558f80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0774f23d-9ffa-4d7c-bb67-0d5450558f80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0774f23d-9ffa-4d7c-bb67-0d5450558f80">
											<gml:posList>35.66982692539474 139.7457363673027 178.4 35.66979379894628 139.7456978523285 178.4 35.66979379894628 139.7456978523285 168.2 35.66982692539474 139.7457363673027 168.2 35.66982692539474 139.7457363673027 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30992a2f-cf99-46bc-83be-11bae8f3eb63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30992a2f-cf99-46bc-83be-11bae8f3eb63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30992a2f-cf99-46bc-83be-11bae8f3eb63">
											<gml:posList>35.66979379894628 139.7456978523285 178.4 35.6697599566973 139.74574094730607 178.4 35.6697599566973 139.74574094730607 168.2 35.66979379894628 139.7456978523285 168.2 35.66979379894628 139.7456978523285 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-caae0169-6643-4d2f-9dfd-7a756f6cf133">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-caae0169-6643-4d2f-9dfd-7a756f6cf133">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-caae0169-6643-4d2f-9dfd-7a756f6cf133">
											<gml:posList>35.66993271025252 139.7455997649046 7.6 35.66993271025252 139.7455997649046 178.4 35.66982692539474 139.7457363673027 178.4 35.66982692539474 139.7457363673027 168.2 35.66979285843959 139.74578035726776 168.2 35.66979285843959 139.74578035726776 178.4 35.669689567842056 139.7459137420358 178.4 35.669689567842056 139.7459137420358 7.6 35.66993271025252 139.7455997649046 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad355bc2-bc3a-46cc-bf87-c5945a7eece8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad355bc2-bc3a-46cc-bf87-c5945a7eece8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad355bc2-bc3a-46cc-bf87-c5945a7eece8">
											<gml:posList>35.66968926949811 139.74590010034757 178.4 35.66968926949811 139.74590010034757 174.895 35.66944837220806 139.7456201558167 174.895 35.66944837220806 139.7456201558167 178.4 35.66968926949811 139.74590010034757 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17e26830-7776-41cb-86a4-5d9e0d096911">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17e26830-7776-41cb-86a4-5d9e0d096911">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17e26830-7776-41cb-86a4-5d9e0d096911">
											<gml:posList>35.6697599566973 139.74574094730607 178.4 35.66979285843959 139.74578035726776 178.4 35.66979285843959 139.74578035726776 168.2 35.6697599566973 139.74574094730607 168.2 35.6697599566973 139.74574094730607 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26b63774-af3c-4a89-b05e-ab857b5ed3d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26b63774-af3c-4a89-b05e-ab857b5ed3d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26b63774-af3c-4a89-b05e-ab857b5ed3d3">
											<gml:posList>35.66974886994417 139.74574113615662 178.4 35.66974886994417 139.74574113615662 174.895 35.66978179877583 139.74578061236042 174.895 35.66978179877583 139.74578061236042 178.4 35.66974886994417 139.74574113615662 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71bfd853-2792-4b2d-bb96-347d14e6a71e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71bfd853-2792-4b2d-bb96-347d14e6a71e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71bfd853-2792-4b2d-bb96-347d14e6a71e">
											<gml:posList>35.66943724051468 139.74562052147039 7.6 35.669689567842056 139.7459137420358 7.6 35.669689567842056 139.7459137420358 178.4 35.66943724051468 139.74562052147039 178.4 35.66943724051468 139.74562052147039 7.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a03b862-9240-4643-ad35-f45a138b4a8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a03b862-9240-4643-ad35-f45a138b4a8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a03b862-9240-4643-ad35-f45a138b4a8f">
											<gml:posList>35.66978179877583 139.74578061236042 178.4 35.66978179877583 139.74578061236042 174.895 35.66968926949811 139.74590010034757 174.895 35.66968926949811 139.74590010034757 178.4 35.66978179877583 139.74578061236042 178.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2488</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">1512.27855</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>