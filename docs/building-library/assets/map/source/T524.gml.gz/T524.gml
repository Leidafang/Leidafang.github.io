<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_97510491-adc2-4998-a1c7-525150680cc4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">27.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>2</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67163095403526 139.73936737649808 0 35.67162303265234 139.73935798526978 0 35.6715774682322 139.73941572310542 0 35.67156815955497 139.73943049203098 0 35.67172941699153 139.73958321910087 0 35.671777012225036 139.7395057388651 0 35.6717243080775 139.73945835606585 0 35.671772191660985 139.73938086437664 0 35.671755169780525 139.7393642373257 0 35.671784591489576 139.7393191995925 0 35.67173888390917 139.73927436043206 0 35.67172687337665 139.73929200464875 0 35.67172102798228 139.73928624526144 0 35.67168170118686 139.7393440974069 0 35.6716789858841 139.73934131688765 0 35.67166832504394 139.7393328457225 0 35.671640317440286 139.7393765451097 0 35.67163095403526 139.73936737649808 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67163095403526 139.73936737649808 9.64 35.671640317440286 139.7393765451097 9.64 35.67166832504394 139.7393328457225 9.64 35.6716789858841 139.73934131688765 9.64 35.67168170118686 139.7393440974069 9.64 35.67172102798228 139.73928624526144 9.64 35.67172687337665 139.73929200464875 9.64 35.67173888390917 139.73927436043206 9.64 35.671784591489576 139.7393191995925 9.64 35.671755169780525 139.7393642373257 9.64 35.671772191660985 139.73938086437664 9.64 35.6717243080775 139.73945835606585 9.64 35.671777012225036 139.7395057388651 9.64 35.67172941699153 139.73958321910087 9.64 35.67156815955497 139.73943049203098 9.64 35.6715774682322 139.73941572310542 9.64 35.67162303265234 139.73935798526978 9.64 35.67163095403526 139.73936737649808 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67163095403526 139.73936737649808 9.64 35.67162303265234 139.73935798526978 9.64 35.67162303265234 139.73935798526978 33.22 35.67163095403526 139.73936737649808 33.22 35.67163095403526 139.73936737649808 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67162303265234 139.73935798526978 9.64 35.6715774682322 139.73941572310542 9.64 35.6715774682322 139.73941572310542 33.22 35.67162303265234 139.73935798526978 33.22 35.67162303265234 139.73935798526978 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715774682322 139.73941572310542 9.64 35.67156815955497 139.73943049203098 9.64 35.67156815955497 139.73943049203098 33.22 35.6715774682322 139.73941572310542 33.22 35.6715774682322 139.73941572310542 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156815955497 139.73943049203098 9.64 35.67172941699153 139.73958321910087 9.64 35.67172941699153 139.73958321910087 33.22 35.67156815955497 139.73943049203098 33.22 35.67156815955497 139.73943049203098 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67172941699153 139.73958321910087 9.64 35.671777012225036 139.7395057388651 9.64 35.671777012225036 139.7395057388651 33.22 35.67172941699153 139.73958321910087 33.22 35.67172941699153 139.73958321910087 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671777012225036 139.7395057388651 9.64 35.6717243080775 139.73945835606585 9.64 35.6717243080775 139.73945835606585 33.22 35.671777012225036 139.7395057388651 33.22 35.671777012225036 139.7395057388651 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6717243080775 139.73945835606585 9.64 35.671772191660985 139.73938086437664 9.64 35.671772191660985 139.73938086437664 33.22 35.6717243080775 139.73945835606585 33.22 35.6717243080775 139.73945835606585 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671772191660985 139.73938086437664 9.64 35.671755169780525 139.7393642373257 9.64 35.671755169780525 139.7393642373257 33.22 35.671772191660985 139.73938086437664 33.22 35.671772191660985 139.73938086437664 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671755169780525 139.7393642373257 9.64 35.671784591489576 139.7393191995925 9.64 35.671784591489576 139.7393191995925 33.22 35.671755169780525 139.7393642373257 33.22 35.671755169780525 139.7393642373257 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671784591489576 139.7393191995925 9.64 35.67173888390917 139.73927436043206 9.64 35.67173888390917 139.73927436043206 33.22 35.671784591489576 139.7393191995925 33.22 35.671784591489576 139.7393191995925 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67173888390917 139.73927436043206 9.64 35.67172687337665 139.73929200464875 9.64 35.67172687337665 139.73929200464875 33.22 35.67173888390917 139.73927436043206 33.22 35.67173888390917 139.73927436043206 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67172687337665 139.73929200464875 9.64 35.67172102798228 139.73928624526144 9.64 35.67172102798228 139.73928624526144 33.22 35.67172687337665 139.73929200464875 33.22 35.67172687337665 139.73929200464875 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67172102798228 139.73928624526144 9.64 35.67168170118686 139.7393440974069 9.64 35.67168170118686 139.7393440974069 33.22 35.67172102798228 139.73928624526144 33.22 35.67172102798228 139.73928624526144 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67168170118686 139.7393440974069 9.64 35.6716789858841 139.73934131688765 9.64 35.6716789858841 139.73934131688765 33.22 35.67168170118686 139.7393440974069 33.22 35.67168170118686 139.7393440974069 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6716789858841 139.73934131688765 9.64 35.67166832504394 139.7393328457225 9.64 35.67166832504394 139.7393328457225 33.22 35.6716789858841 139.73934131688765 33.22 35.6716789858841 139.73934131688765 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67166832504394 139.7393328457225 9.64 35.671640317440286 139.7393765451097 9.64 35.671640317440286 139.7393765451097 33.22 35.67166832504394 139.7393328457225 33.22 35.67166832504394 139.7393328457225 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671640317440286 139.7393765451097 9.64 35.67163095403526 139.73936737649808 9.64 35.67163095403526 139.73936737649808 33.22 35.671640317440286 139.7393765451097 33.22 35.671640317440286 139.7393765451097 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67163095403526 139.73936737649808 33.22 35.67162303265234 139.73935798526978 33.22 35.6715774682322 139.73941572310542 33.22 35.67156815955497 139.73943049203098 33.22 35.67172941699153 139.73958321910087 33.22 35.671777012225036 139.7395057388651 33.22 35.6717243080775 139.73945835606585 33.22 35.671772191660985 139.73938086437664 33.22 35.671755169780525 139.7393642373257 33.22 35.671784591489576 139.7393191995925 33.22 35.67173888390917 139.73927436043206 33.22 35.67172687337665 139.73929200464875 33.22 35.67172102798228 139.73928624526144 33.22 35.67168170118686 139.7393440974069 33.22 35.6716789858841 139.73934131688765 33.22 35.67166832504394 139.7393328457225 33.22 35.671640317440286 139.7393765451097 33.22 35.67163095403526 139.73936737649808 33.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-346f5ca7-f9b2-46c7-8350-aa8cbc6473db"/>
							<gml:surfaceMember xlink:href="#poly-51a34d03-23d7-442c-a359-bc944d159851"/>
							<gml:surfaceMember xlink:href="#poly-2b03cc60-49eb-4f4e-a68c-e9dd23ecae6f"/>
							<gml:surfaceMember xlink:href="#poly-b5ea0c96-1ae2-4a2e-b38d-5989c228802e"/>
							<gml:surfaceMember xlink:href="#poly-1c184ce9-a8d9-449b-90fb-d002a4fe6a6b"/>
							<gml:surfaceMember xlink:href="#poly-3106c71b-6d74-4bfc-a2c5-8ee102aa938b"/>
							<gml:surfaceMember xlink:href="#poly-0421d58f-5949-41df-9b6a-f7289e9a64ee"/>
							<gml:surfaceMember xlink:href="#poly-97103857-49a4-41a9-9fc6-6f0d09d39a1c"/>
							<gml:surfaceMember xlink:href="#poly-04d7f3cd-83b2-4575-846c-19d8eab2f8b3"/>
							<gml:surfaceMember xlink:href="#poly-3aacb24d-00e8-41bb-a01a-845cd1ef06cc"/>
							<gml:surfaceMember xlink:href="#poly-4f06386b-0143-4436-8c89-5c43b8bf8c12"/>
							<gml:surfaceMember xlink:href="#poly-4a573819-2d0a-465e-8920-fd6710cee113"/>
							<gml:surfaceMember xlink:href="#poly-f3dea004-7533-4418-99c3-e1e1c40e771d"/>
							<gml:surfaceMember xlink:href="#poly-69fdaa69-48eb-4fca-aa65-55856f71b220"/>
							<gml:surfaceMember xlink:href="#poly-38b10c73-cda6-4000-8912-97ed49b39a65"/>
							<gml:surfaceMember xlink:href="#poly-80bc257c-5a6a-46b7-9f74-bebb8a2aa4ac"/>
							<gml:surfaceMember xlink:href="#poly-406936f7-e6b8-4911-b486-5cf52d8a5d64"/>
							<gml:surfaceMember xlink:href="#poly-93c3ece3-c501-47c6-9c95-a7d5f12e358f"/>
							<gml:surfaceMember xlink:href="#poly-594699e4-9cfa-45af-ac74-b14fe12f0aea"/>
							<gml:surfaceMember xlink:href="#poly-9503b7d3-e9a9-4804-91fc-887e45b235fb"/>
							<gml:surfaceMember xlink:href="#poly-2bcc0059-c1ff-40fb-b057-eaf0631e080b"/>
							<gml:surfaceMember xlink:href="#poly-51015377-cb05-4124-932f-60fc6e8d7f00"/>
							<gml:surfaceMember xlink:href="#poly-afa82939-83d1-49f4-b899-1b602e161ec2"/>
							<gml:surfaceMember xlink:href="#poly-41be49b2-6908-4eeb-841e-89e00b748c15"/>
							<gml:surfaceMember xlink:href="#poly-af8b276b-8772-4cfa-9db2-8d4840e47b0e"/>
							<gml:surfaceMember xlink:href="#poly-af59f25a-6753-4c00-9d5c-42bc60b8cf85"/>
							<gml:surfaceMember xlink:href="#poly-cb53f5b6-e8db-4075-9349-038265049b86"/>
							<gml:surfaceMember xlink:href="#poly-4c8abcf6-7f10-4084-bb38-04871133eb69"/>
							<gml:surfaceMember xlink:href="#poly-6fc805df-0e5e-4a5b-91a0-3cfa5faa0f05"/>
							<gml:surfaceMember xlink:href="#poly-30eb50e9-7e7e-4362-832e-868a2b9de5be"/>
							<gml:surfaceMember xlink:href="#poly-bb424a22-852c-4209-b002-af477fe1afa2"/>
							<gml:surfaceMember xlink:href="#poly-c3bd2997-41ec-4086-a7e5-c728e124fc86"/>
							<gml:surfaceMember xlink:href="#poly-2553f3df-0932-434c-883c-aeccde469eca"/>
							<gml:surfaceMember xlink:href="#poly-177ae592-26b5-4a40-b48d-76e797227f35"/>
							<gml:surfaceMember xlink:href="#poly-05f5a860-1ba7-4c03-aa5f-1fbd34c51333"/>
							<gml:surfaceMember xlink:href="#poly-c6649233-36a2-43de-ad61-1d16e1888906"/>
							<gml:surfaceMember xlink:href="#poly-3d0cfc93-c30b-40cc-87ea-6b2e03b3114c"/>
							<gml:surfaceMember xlink:href="#poly-ad03c8b5-4bd3-4f2e-8cf0-b12930331eb4"/>
							<gml:surfaceMember xlink:href="#poly-a57914f8-5e9c-4bb3-b7f7-4226e4c3e61f"/>
							<gml:surfaceMember xlink:href="#poly-a0c15d1c-26d9-4d3f-8b80-555b2bc58807"/>
							<gml:surfaceMember xlink:href="#poly-6a023cb6-b8bc-43a0-b72e-3efd613c0311"/>
							<gml:surfaceMember xlink:href="#poly-ca82e59e-8ffb-4ac3-9bdd-a9b57df4ef72"/>
							<gml:surfaceMember xlink:href="#poly-e10e4589-d790-475f-93e6-b019f89fefce"/>
							<gml:surfaceMember xlink:href="#poly-eaa14759-2875-4989-a7b0-9d7e30d4f330"/>
							<gml:surfaceMember xlink:href="#poly-d6d52fc2-8bdb-4704-b596-ceab2921b68a"/>
							<gml:surfaceMember xlink:href="#poly-f650330b-9fb6-4a4d-8b2b-c3ffa1f5bd21"/>
							<gml:surfaceMember xlink:href="#poly-3f6d8814-85e6-4ade-be9d-828448889567"/>
							<gml:surfaceMember xlink:href="#poly-c5423f54-28ee-4f6a-a8a5-83f729c4ca0d"/>
							<gml:surfaceMember xlink:href="#poly-2002a577-2de4-4ea2-bc7f-277dd8242704"/>
							<gml:surfaceMember xlink:href="#poly-6c5954bc-b443-44e3-b27e-fda0af4c66c4"/>
							<gml:surfaceMember xlink:href="#poly-10c3185e-15b8-47dd-b75c-8467630085e6"/>
							<gml:surfaceMember xlink:href="#poly-f647d5d6-db7b-4e88-8d01-909807722de1"/>
							<gml:surfaceMember xlink:href="#poly-e90e5ca8-b51e-4de4-890b-2f50a35cc04b"/>
							<gml:surfaceMember xlink:href="#poly-41607399-c097-441c-befb-cfe6efae425b"/>
							<gml:surfaceMember xlink:href="#poly-e3e3f8fa-b128-4ccb-ae06-f8f54d3ff9c2"/>
							<gml:surfaceMember xlink:href="#poly-43b01f1f-6731-4fb5-a14f-e8e5c94a6b4b"/>
							<gml:surfaceMember xlink:href="#poly-25e2e595-e225-4fb3-9289-0627971fd61b"/>
							<gml:surfaceMember xlink:href="#poly-58e8658e-bb27-44a6-b3b6-eae93be55d69"/>
							<gml:surfaceMember xlink:href="#poly-fe076ae2-7276-4b75-b77a-a5dc360773cb"/>
							<gml:surfaceMember xlink:href="#poly-7d43a31e-cf26-4e7d-ae16-9005f961f236"/>
							<gml:surfaceMember xlink:href="#poly-9c4df788-8962-439a-9390-6fa0eae61e85"/>
							<gml:surfaceMember xlink:href="#poly-c01f4c09-18c9-4de0-9ca9-e24f63c208a9"/>
							<gml:surfaceMember xlink:href="#poly-637d78fc-99c6-44a7-8972-016e4b719655"/>
							<gml:surfaceMember xlink:href="#poly-d1ae66dc-a537-4727-9508-feaf9100bbac"/>
							<gml:surfaceMember xlink:href="#poly-1332dca7-48c7-409e-9921-8c49cb13d85a"/>
							<gml:surfaceMember xlink:href="#poly-88f1d708-1357-4002-b351-e167b4e12a68"/>
							<gml:surfaceMember xlink:href="#poly-1578829d-bd63-4bb4-aa1c-cb1a8c8c55c4"/>
							<gml:surfaceMember xlink:href="#poly-ee1aa8e5-f60a-4818-890c-3ee2937dcd00"/>
							<gml:surfaceMember xlink:href="#poly-9b982525-a7a2-4d4a-a695-4a73ed25ffe6"/>
							<gml:surfaceMember xlink:href="#poly-dcbc8065-a986-4ed2-aff7-fbcef2be3b64"/>
							<gml:surfaceMember xlink:href="#poly-28b92c85-133f-42a0-b9fb-cbf6317913b8"/>
							<gml:surfaceMember xlink:href="#poly-ca9f80e3-6c9c-488a-a408-569afa76d936"/>
							<gml:surfaceMember xlink:href="#poly-65285be8-a564-43b7-8038-140d439faf86"/>
							<gml:surfaceMember xlink:href="#poly-3bb8afbf-613f-445e-9762-301ba8ad7ece"/>
							<gml:surfaceMember xlink:href="#poly-e735b2a8-da4d-4523-a610-caa968d685b9"/>
							<gml:surfaceMember xlink:href="#poly-fb4ddd57-9814-4c63-9f21-c7e2f4916a26"/>
							<gml:surfaceMember xlink:href="#poly-3fdaf9a4-3280-454b-b164-750ad81dd3ca"/>
							<gml:surfaceMember xlink:href="#poly-026ad587-cdfd-45ee-a49d-e4add40f26c2"/>
							<gml:surfaceMember xlink:href="#poly-b7391301-7038-41f8-ab72-e194ec760ecb"/>
							<gml:surfaceMember xlink:href="#poly-2f877e1d-c5b1-4020-8b25-2af3b5e0855e"/>
							<gml:surfaceMember xlink:href="#poly-3520ecfd-c5ef-43bd-a4a2-ba1e38880617"/>
							<gml:surfaceMember xlink:href="#poly-c351ea31-85c5-488b-8e3d-18a86e1fbd61"/>
							<gml:surfaceMember xlink:href="#poly-cf3c5fcd-beca-4312-9e0d-006fc0e27f63"/>
							<gml:surfaceMember xlink:href="#poly-72d896eb-fc31-4034-8d2b-3aa2f773797d"/>
							<gml:surfaceMember xlink:href="#poly-4d34aa70-f060-4aae-8f50-160d14296f5a"/>
							<gml:surfaceMember xlink:href="#poly-43a70771-8a64-4f24-878e-d900356efa20"/>
							<gml:surfaceMember xlink:href="#poly-537595e1-0bd0-4940-90b9-33f42d34e6a8"/>
							<gml:surfaceMember xlink:href="#poly-1d9e2784-5241-4c13-a3d1-75c75be2fba6"/>
							<gml:surfaceMember xlink:href="#poly-b3087782-ca39-4d41-8fa3-2aafb3451f28"/>
							<gml:surfaceMember xlink:href="#poly-79fb384a-e151-4847-b984-211489733438"/>
							<gml:surfaceMember xlink:href="#poly-6b607665-b0ef-4c5a-bb6d-43d0415e237a"/>
							<gml:surfaceMember xlink:href="#poly-07fedbf0-19d2-41df-ac4a-88b81123e54c"/>
							<gml:surfaceMember xlink:href="#poly-29737cf2-c32d-4d47-a99d-c1bcbc67a914"/>
							<gml:surfaceMember xlink:href="#poly-9c94967b-f413-42da-b4d5-984c32583c1a"/>
							<gml:surfaceMember xlink:href="#poly-957576e9-76d4-44e1-bff8-59fafbdc748e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_97510491-adc2-4998-a1c7-525150680cc4_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f07fd42f-7494-4896-9c73-97360bfc4148">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f07fd42f-7494-4896-9c73-97360bfc4148_0">
											<gml:posList>35.67176131322733 139.7393707696233 36.826 35.67177970717026 139.7393437284438 38.39 35.671761556313314 139.73937040480556 39.299 35.67176131322733 139.7393707696233 36.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8f122ab-9cba-4c45-b3ac-80b78f489582">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8f122ab-9cba-4c45-b3ac-80b78f489582_0">
											<gml:posList>35.6717551607668 139.73936423733628 39.299 35.67176131322733 139.7393707696233 36.826 35.671761556313314 139.73937040480556 39.299 35.6717551607668 139.73936423733628 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b68fcc18-9ef5-4e57-8fa8-8d2eadc95d80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b68fcc18-9ef5-4e57-8fa8-8d2eadc95d80_0">
											<gml:posList>35.67178375775678 139.73933656559382 38.39 35.671773014040284 139.73933739562733 38.39 35.67177970717026 139.7393437284438 38.39 35.67178375775678 139.73933656559382 38.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef5848df-9a7f-45a7-896d-e3712a57419d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef5848df-9a7f-45a7-896d-e3712a57419d_0">
											<gml:posList>35.67178375775678 139.73933656559382 38.39 35.67177750662642 139.73933065202456 38.39 35.671773014040284 139.73933739562733 38.39 35.67178375775678 139.73933656559382 38.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dba02ab4-f423-4669-b1ee-b915d0d20eb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dba02ab4-f423-4669-b1ee-b915d0d20eb6_0">
											<gml:posList>35.67179374331761 139.7393459986048 9.67 35.67177750662642 139.73933065202456 9.67 35.67178375775678 139.73933656559382 38.39 35.67179374331761 139.7393459986048 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cb4a454-89f3-4ebb-836b-f188348642fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0cb4a454-89f3-4ebb-836b-f188348642fd_0">
											<gml:posList>35.67179374331761 139.7393459986048 9.67 35.67178375775678 139.73933656559382 38.39 35.67179374331761 139.7393459986048 38.39 35.67179374331761 139.7393459986048 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b46254f9-7d3e-47b4-aa5f-ac3d41ee447c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b46254f9-7d3e-47b4-aa5f-ac3d41ee447c_0">
											<gml:posList>35.67177750662642 139.73933065202456 9.67 35.67177750662642 139.73933065202456 38.39 35.67178375775678 139.73933656559382 38.39 35.67177750662642 139.73933065202456 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b96518a2-9008-4ec5-af5f-3b3fa31ec2af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b96518a2-9008-4ec5-af5f-3b3fa31ec2af_0">
											<gml:posList>35.67177970717026 139.7393437284438 38.39 35.67179374331761 139.7393459986048 38.39 35.67178375775678 139.73933656559382 38.39 35.67177970717026 139.7393437284438 38.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3971ba34-b790-4c47-a4f7-dace6e7b3d97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3971ba34-b790-4c47-a4f7-dace6e7b3d97_0">
											<gml:posList>35.67177970717026 139.7393437284438 38.39 35.67178944918765 139.7393529408116 38.39 35.67179374331761 139.7393459986048 38.39 35.67177970717026 139.7393437284438 38.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34e65bf9-a76c-4e6f-842d-35dbf90f46cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34e65bf9-a76c-4e6f-842d-35dbf90f46cf_0">
											<gml:posList>35.671773014040284 139.73933739562733 38.39 35.67177750662642 139.73933065202456 9.67 35.6717551607668 139.73936423733628 9.67 35.671773014040284 139.73933739562733 38.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c582f485-ceeb-4d8c-ade5-d40098d1186d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c582f485-ceeb-4d8c-ade5-d40098d1186d_0">
											<gml:posList>35.6717551607668 139.73936423733628 9.67 35.6717551607668 139.73936423733628 39.299 35.671773014040284 139.73933739562733 38.39 35.6717551607668 139.73936423733628 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fe19bea-03a2-435c-b10e-8a44edb5626a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fe19bea-03a2-435c-b10e-8a44edb5626a_0">
											<gml:posList>35.67177750662642 139.73933065202456 38.39 35.67177750662642 139.73933065202456 9.67 35.671773014040284 139.73933739562733 38.39 35.67177750662642 139.73933065202456 38.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06a862a5-ca58-48a9-a8a9-f879dfcd37c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06a862a5-ca58-48a9-a8a9-f879dfcd37c5_0">
											<gml:posList>35.671773014040284 139.73933739562733 38.39 35.671761556313314 139.73937040480556 39.299 35.67177970717026 139.7393437284438 38.39 35.671773014040284 139.73933739562733 38.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b151d32c-ab1c-4e94-ab0e-ec371c5ec603">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b151d32c-ab1c-4e94-ab0e-ec371c5ec603_0">
											<gml:posList>35.671773014040284 139.73933739562733 38.39 35.6717551607668 139.73936423733628 39.299 35.671761556313314 139.73937040480556 39.299 35.671773014040284 139.73933739562733 38.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fecd436b-aa37-4750-a6a1-6771eea0862a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fecd436b-aa37-4750-a6a1-6771eea0862a_0">
											<gml:posList>35.671772191660985 139.73938086437664 36.826 35.67178944918765 139.7393529408116 38.39 35.67177970717026 139.7393437284438 38.39 35.671772191660985 139.73938086437664 36.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea9add5b-722e-4aba-8a8b-822d4a76d1ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea9add5b-722e-4aba-8a8b-822d4a76d1ee_0">
											<gml:posList>35.67176131322733 139.7393707696233 36.826 35.671772191660985 139.73938086437664 36.826 35.67177970717026 139.7393437284438 38.39 35.67176131322733 139.7393707696233 36.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4542a79-b23f-4338-ab97-b9c2166200c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4542a79-b23f-4338-ab97-b9c2166200c4_0">
											<gml:posList>35.67178944918765 139.7393529408116 38.39 35.671772191660985 139.73938086437664 36.826 35.67179374331761 139.7393459986048 38.39 35.67178944918765 139.7393529408116 38.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e2343f0-9cdf-4e8a-89b4-9acd9645fd1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e2343f0-9cdf-4e8a-89b4-9acd9645fd1c_0">
											<gml:posList>35.671772191660985 139.73938086437664 36.826 35.671772191660985 139.73938086437664 9.67 35.67179374331761 139.7393459986048 9.67 35.671772191660985 139.73938086437664 36.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf656248-dcdf-4490-a103-dd077d17e66e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf656248-dcdf-4490-a103-dd077d17e66e_0">
											<gml:posList>35.67179374331761 139.7393459986048 38.39 35.671772191660985 139.73938086437664 36.826 35.67179374331761 139.7393459986048 9.67 35.67179374331761 139.7393459986048 38.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-311e2ccd-3668-4e1d-94a7-9be894b473ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-311e2ccd-3668-4e1d-94a7-9be894b473ad_0">
											<gml:posList>35.67176131322733 139.7393707696233 36.826 35.6717551607668 139.73936423733628 9.67 35.67176131322733 139.7393707696233 9.67 35.67176131322733 139.7393707696233 36.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c085e14-facd-4981-a63c-781fef73d1c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c085e14-facd-4981-a63c-781fef73d1c1_0">
											<gml:posList>35.67176131322733 139.7393707696233 36.826 35.6717551607668 139.73936423733628 39.299 35.6717551607668 139.73936423733628 9.67 35.67176131322733 139.7393707696233 36.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9dc9f74-2b70-47a8-aee5-7dc9feeb0d05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9dc9f74-2b70-47a8-aee5-7dc9feeb0d05_0">
											<gml:posList>35.67176131322733 139.7393707696233 36.826 35.671772191660985 139.73938086437664 9.67 35.671772191660985 139.73938086437664 36.826 35.67176131322733 139.7393707696233 36.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7ce8a9d-a1f0-4ccb-b474-b1f4e8aa24b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7ce8a9d-a1f0-4ccb-b474-b1f4e8aa24b6_0">
											<gml:posList>35.67176131322733 139.7393707696233 36.826 35.67176131322733 139.7393707696233 9.67 35.671772191660985 139.73938086437664 9.67 35.67176131322733 139.7393707696233 36.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-604837cf-e7d5-4741-a803-0159256e9afd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-604837cf-e7d5-4741-a803-0159256e9afd_0">
											<gml:posList>35.67171472436866 139.73938630029193 39.299 35.67170812548159 139.73939678005175 44.264 35.67171472436866 139.73938630029193 44.264 35.67171472436866 139.73938630029193 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-382b43f7-d7d8-4444-ae71-606c4bb7e678">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-382b43f7-d7d8-4444-ae71-606c4bb7e678_0">
											<gml:posList>35.67171472436866 139.73938630029193 39.299 35.67170812548159 139.73939678005175 39.299 35.67170812548159 139.73939678005175 44.264 35.67171472436866 139.73938630029193 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3fcb2ef-9620-4a52-8130-7ed05849f547">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3fcb2ef-9620-4a52-8130-7ed05849f547_0">
											<gml:posList>35.67171472436866 139.73938630029193 38.987 35.67171472436866 139.73938630029193 39.299 35.67173983693025 139.73940981084294 38.987 35.67171472436866 139.73938630029193 38.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de327876-86cc-4e48-aa50-283ffb272c64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de327876-86cc-4e48-aa50-283ffb272c64_0">
											<gml:posList>35.67173983693025 139.73940981084294 38.987 35.67171472436866 139.73938630029193 39.299 35.67173983693025 139.73940981084294 39.946 35.67173983693025 139.73940981084294 38.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eeea19ff-0f7b-4325-8822-fa539dd5026d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eeea19ff-0f7b-4325-8822-fa539dd5026d_0">
											<gml:posList>35.67171472436866 139.73938630029193 39.299 35.67171472436866 139.73938630029193 44.264 35.67173983693025 139.73940981084294 39.946 35.67171472436866 139.73938630029193 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11bf0254-11db-4fd6-9921-d85a1c2e1bc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11bf0254-11db-4fd6-9921-d85a1c2e1bc9_0">
											<gml:posList>35.67171472436866 139.73938630029193 44.264 35.67173331021124 139.73942036784473 39.946 35.67173983693025 139.73940981084294 39.946 35.67171472436866 139.73938630029193 44.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-738523bb-7b18-445d-873a-59bb7a4e414d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-738523bb-7b18-445d-873a-59bb7a4e414d_0">
											<gml:posList>35.67171472436866 139.73938630029193 44.264 35.67170812548159 139.73939678005175 44.264 35.67173331021124 139.73942036784473 39.946 35.67171472436866 139.73938630029193 44.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-478e7143-fab2-424d-99b0-b7454b07a234">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-478e7143-fab2-424d-99b0-b7454b07a234_0">
											<gml:posList>35.67170812548159 139.73939678005175 38.987 35.67173331021124 139.73942036784473 38.987 35.67170812548159 139.73939678005175 39.299 35.67170812548159 139.73939678005175 38.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-388306e0-fb6a-4ecf-a9cc-6bf2305050d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-388306e0-fb6a-4ecf-a9cc-6bf2305050d1_0">
											<gml:posList>35.67170812548159 139.73939678005175 39.299 35.67173331021124 139.73942036784473 39.946 35.67170812548159 139.73939678005175 44.264 35.67170812548159 139.73939678005175 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a60a013-e15d-42ab-8b27-c9195c781c24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a60a013-e15d-42ab-8b27-c9195c781c24_0">
											<gml:posList>35.67170812548159 139.73939678005175 39.299 35.67173331021124 139.73942036784473 38.987 35.67173331021124 139.73942036784473 39.946 35.67170812548159 139.73939678005175 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bca8f25d-801e-454a-a9ab-1b33640d2378">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bca8f25d-801e-454a-a9ab-1b33640d2378_0">
											<gml:posList>35.67173331021124 139.73942036784473 38.987 35.67173983693025 139.73940981084294 39.946 35.67173331021124 139.73942036784473 39.946 35.67173331021124 139.73942036784473 38.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68fcc320-6369-4343-a278-8f64b6006ced">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68fcc320-6369-4343-a278-8f64b6006ced_0">
											<gml:posList>35.67173331021124 139.73942036784473 38.987 35.67173983693025 139.73940981084294 38.987 35.67173983693025 139.73940981084294 39.946 35.67173331021124 139.73942036784473 38.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3011dc52-0bea-47c4-bede-88a974d467a4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6717551607668 139.73936423733628 9.67 35.67177750662642 139.73933065202456 9.67 35.67176131322733 139.7393707696233 9.67 35.6717551607668 139.73936423733628 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7890e3e-13d8-4678-bba6-eb57730438af">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67176131322733 139.7393707696233 9.67 35.67179374331761 139.7393459986048 9.67 35.671772191660985 139.73938086437664 9.67 35.67176131322733 139.7393707696233 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0bfdc0c-1c35-4752-a0ac-3e376273a880">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67176131322733 139.7393707696233 9.67 35.67177750662642 139.73933065202456 9.67 35.67179374331761 139.7393459986048 9.67 35.67176131322733 139.7393707696233 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a8d2be2-ce58-41ec-8f35-0ec2cb69b117">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67171472436866 139.73938630029193 38.987 35.67173331021124 139.73942036784473 38.987 35.67170812548159 139.73939678005175 38.987 35.67171472436866 139.73938630029193 38.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-417514e4-c3dc-4e41-bd44-39787fe9d030">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67171472436866 139.73938630029193 38.987 35.67173983693025 139.73940981084294 38.987 35.67173331021124 139.73942036784473 38.987 35.67171472436866 139.73938630029193 38.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_97510491-adc2-4998-a1c7-525150680cc4_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cd53485-a1c0-4f26-98a2-d991e96c577f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671729397755385 139.73937351340703 46.472 35.671743694862464 139.73938677448098 46.472 35.671737438220994 139.7393969003573 46.472 35.67172315012013 139.73938362822557 46.472 35.671729397755385 139.73937351340703 46.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f826ef1b-0170-4cbd-87c1-da2027e469b2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671720569664465 139.73932264383205 31.311 35.671740486860635 139.73934170873733 31.311 35.671728765291775 139.73936003748517 31.311 35.671708784959314 139.73934091741992 31.311 35.671720569664465 139.73932264383205 31.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-847df722-add7-4806-9a9d-e18e0d5cf420">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67167866451125 139.7393684141774 31.311 35.67170243348815 139.73933347956455 31.311 35.67170770132959 139.7393383780086 31.311 35.671684988335755 139.739375078815 31.311 35.67167866451125 139.7393684141774 31.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc088738-1607-449e-a004-34003bbc82ba">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671674662669346 139.7393687392143 31.784 35.6717001152804 139.73933132822654 31.784 35.67170243348815 139.73933347956455 31.784 35.67167866451125 139.7393684141774 31.784 35.671684988335755 139.739375078815 31.784 35.671683052825166 139.73937820722549 31.784 35.671674662669346 139.7393687392143 31.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74de7537-b29b-43d5-8647-73dbfa81e22f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74de7537-b29b-43d5-8647-73dbfa81e22f_0">
											<gml:posList>35.671683052825166 139.73937820722549 31.784 35.671683052825166 139.73937820722549 33.758 35.671674662669346 139.7393687392143 33.758 35.671674662669346 139.7393687392143 31.784 35.671683052825166 139.73937820722549 31.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d5c4bcf-8b2d-42ab-9748-e915174873af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d5c4bcf-8b2d-42ab-9748-e915174873af_0">
											<gml:posList>35.67167866451125 139.7393684141774 31.311 35.671684988335755 139.739375078815 31.311 35.671684988335755 139.739375078815 31.784 35.67167866451125 139.7393684141774 31.784 35.67167866451125 139.7393684141774 31.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8739fb3a-aba4-4b27-9e89-a1821bc05d0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8739fb3a-aba4-4b27-9e89-a1821bc05d0a_0">
											<gml:posList>35.67168426814316 139.7393762395351 33.758 35.671683052825166 139.73937820722549 33.758 35.671683052825166 139.73937820722549 31.784 35.671684988335755 139.739375078815 31.784 35.67168426814316 139.7393762395351 33.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60fbe708-6091-4759-b47d-4f227e54905c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60fbe708-6091-4759-b47d-4f227e54905c_0">
											<gml:posList>35.6717001152804 139.73933132822654 31.784 35.671674662669346 139.7393687392143 31.784 35.671674662669346 139.7393687392143 33.758 35.6717001152804 139.73933132822654 33.758 35.6717001152804 139.73933132822654 31.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75b5f2c1-24d8-4af5-9a64-12f415c27118">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75b5f2c1-24d8-4af5-9a64-12f415c27118_0">
											<gml:posList>35.67167866451125 139.7393684141774 31.784 35.67170243348815 139.73933347956455 31.784 35.67170243348815 139.73933347956455 31.311 35.67167866451125 139.7393684141774 31.311 35.67167866451125 139.7393684141774 31.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-312dc719-d723-4e4d-99dd-bb273934cee9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-312dc719-d723-4e4d-99dd-bb273934cee9_0">
											<gml:posList>35.67168426814316 139.7393762395351 33.758 35.67170770132959 139.7393383780086 33.758 35.6717001152804 139.73933132822654 33.758 35.671674662669346 139.7393687392143 33.758 35.671683052825166 139.73937820722549 33.758 35.67168426814316 139.7393762395351 33.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87f4a515-2beb-4296-a822-4e736866f7d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87f4a515-2beb-4296-a822-4e736866f7d8_0">
											<gml:posList>35.67170770132959 139.7393383780086 31.311 35.67170770132959 139.7393383780086 33.758 35.67168426814316 139.7393762395351 33.758 35.671684988335755 139.739375078815 31.784 35.671684988335755 139.739375078815 31.311 35.67170770132959 139.7393383780086 31.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1f95664-684d-4862-8d05-a6b680a34a6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1f95664-684d-4862-8d05-a6b680a34a6d_0">
											<gml:posList>35.67170243348815 139.73933347956455 31.784 35.6717001152804 139.73933132822654 31.784 35.6717001152804 139.73933132822654 33.758 35.67170770132959 139.7393383780086 33.758 35.67170770132959 139.7393383780086 31.311 35.67170243348815 139.73933347956455 31.311 35.67170243348815 139.73933347956455 31.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e473120-0d26-4c72-b90c-8dac99ba887d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e473120-0d26-4c72-b90c-8dac99ba887d_0">
											<gml:posList>35.671720569664465 139.73932264383205 31.311 35.671708784959314 139.73934091741992 31.311 35.671708784959314 139.73934091741992 34.096 35.671720569664465 139.73932264383205 34.096 35.671720569664465 139.73932264383205 31.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82bdeadd-8259-47ed-bbe5-fc8d565bd360">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82bdeadd-8259-47ed-bbe5-fc8d565bd360_0">
											<gml:posList>35.671728765291775 139.73936003748517 31.311 35.671728765291775 139.73936003748517 34.096 35.671708784959314 139.73934091741992 34.096 35.671708784959314 139.73934091741992 31.311 35.671728765291775 139.73936003748517 31.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b20b5e5-f2c1-45f0-8f7a-4dedc0e7dcdc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b20b5e5-f2c1-45f0-8f7a-4dedc0e7dcdc_0">
											<gml:posList>35.671728765291775 139.73936003748517 34.096 35.671740486860635 139.73934170873733 34.096 35.671720569664465 139.73932264383205 34.096 35.671708784959314 139.73934091741992 34.096 35.671728765291775 139.73936003748517 34.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-736e871a-6727-42af-8cbb-8054a4a7eb31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-736e871a-6727-42af-8cbb-8054a4a7eb31_0">
											<gml:posList>35.671729397755385 139.73937351340703 46.472 35.67172315012013 139.73938362822557 46.472 35.67172315012013 139.73938362822557 46.971 35.671729397755385 139.73937351340703 46.971 35.671729397755385 139.73937351340703 46.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6cdda79e-1266-440f-8a29-a83f7fdd69d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6cdda79e-1266-440f-8a29-a83f7fdd69d7_0">
											<gml:posList>35.671737438220994 139.7393969003573 46.472 35.671737438220994 139.7393969003573 46.971 35.67172315012013 139.73938362822557 46.971 35.67172315012013 139.73938362822557 46.472 35.671737438220994 139.7393969003573 46.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72870427-ef38-435d-bfc9-7c087949b46f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72870427-ef38-435d-bfc9-7c087949b46f_0">
											<gml:posList>35.671720569664465 139.73932264383205 31.311 35.671720569664465 139.73932264383205 34.096 35.671740486860635 139.73934170873733 34.096 35.671740486860635 139.73934170873733 31.311 35.671720569664465 139.73932264383205 31.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9afdb110-37f0-45e7-ae18-de4665c71e56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9afdb110-37f0-45e7-ae18-de4665c71e56_0">
											<gml:posList>35.671737438220994 139.7393969003573 46.971 35.671743694862464 139.73938677448098 46.971 35.671729397755385 139.73937351340703 46.971 35.67172315012013 139.73938362822557 46.971 35.671737438220994 139.7393969003573 46.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8dfbaa0b-fa86-4312-99e6-76c92c8f2434">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8dfbaa0b-fa86-4312-99e6-76c92c8f2434_0">
											<gml:posList>35.671740486860635 139.73934170873733 31.311 35.671740486860635 139.73934170873733 34.096 35.671728765291775 139.73936003748517 34.096 35.671728765291775 139.73936003748517 31.311 35.671740486860635 139.73934170873733 31.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bf04ef2-4e7f-429b-bf22-2d505e49173f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1bf04ef2-4e7f-429b-bf22-2d505e49173f_0">
											<gml:posList>35.671743694862464 139.73938677448098 46.472 35.671729397755385 139.73937351340703 46.472 35.671729397755385 139.73937351340703 46.971 35.671743694862464 139.73938677448098 46.971 35.671743694862464 139.73938677448098 46.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6525620-264a-4579-95ed-27b6c7a72885">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6525620-264a-4579-95ed-27b6c7a72885_0">
											<gml:posList>35.671737438220994 139.7393969003573 46.472 35.671743694862464 139.73938677448098 46.472 35.671743694862464 139.73938677448098 46.971 35.671737438220994 139.7393969003573 46.971 35.671737438220994 139.7393969003573 46.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-346f5ca7-f9b2-46c7-8350-aa8cbc6473db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-346f5ca7-f9b2-46c7-8350-aa8cbc6473db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-346f5ca7-f9b2-46c7-8350-aa8cbc6473db">
											<gml:posList>35.671640317440286 139.73937654510968 9.64 35.67166832504394 139.73933284572246 9.64 35.6716789858841 139.73934131688765 9.64 35.67168170118685 139.7393440974069 9.64 35.67172102798226 139.73928624526144 9.64 35.671726873376635 139.73929200464875 9.64 35.67173888390917 139.73927436043206 9.64 35.67178459148955 139.7393191995925 9.64 35.671755169780525 139.7393642373257 9.64 35.671772191660985 139.73938086437664 9.64 35.67172430807748 139.73945835606585 9.64 35.671777012225014 139.7395057388651 9.64 35.67172941699153 139.73958321910084 9.64 35.67156815955498 139.73943049203098 9.64 35.67157746823219 139.73941572310542 9.64 35.671623032652306 139.73935798526975 9.64 35.67163095403522 139.73936737649808 9.64 35.671640317440286 139.73937654510968 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-51a34d03-23d7-442c-a359-bc944d159851">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51a34d03-23d7-442c-a359-bc944d159851">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51a34d03-23d7-442c-a359-bc944d159851">
											<gml:posList>35.67157746823219 139.73941572310542 24.203 35.67156815955498 139.73943049203098 24.203 35.67158247491614 139.7394440513206 24.203 35.67163095403522 139.73936737649808 24.203 35.671623032652306 139.73935798526975 24.203 35.67157746823219 139.73941572310542 24.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2b03cc60-49eb-4f4e-a68c-e9dd23ecae6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b03cc60-49eb-4f4e-a68c-e9dd23ecae6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b03cc60-49eb-4f4e-a68c-e9dd23ecae6f">
											<gml:posList>35.67158247491614 139.7394440513206 26.745 35.671590521097876 139.73945166393196 26.745 35.671594292877174 139.73944528572716 26.745 35.671640317440286 139.73937654510968 26.745 35.67163095403522 139.73936737649808 26.745 35.67158247491614 139.7394440513206 26.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b5ea0c96-1ae2-4a2e-b38d-5989c228802e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5ea0c96-1ae2-4a2e-b38d-5989c228802e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5ea0c96-1ae2-4a2e-b38d-5989c228802e">
											<gml:posList>35.671594292877174 139.73944528572716 29.409 35.671590521097876 139.73945166393196 29.409 35.67159986622802 139.73946052327022 29.409 35.6716041784693 139.73945368048226 29.409 35.67164852676092 139.73938529531128 29.409 35.671640317440286 139.73937654510968 29.409 35.671594292877174 139.73944528572716 29.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c184ce9-a8d9-449b-90fb-d002a4fe6a6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c184ce9-a8d9-449b-90fb-d002a4fe6a6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c184ce9-a8d9-449b-90fb-d002a4fe6a6b">
											<gml:posList>35.67161098836932 139.73947105958732 39.299 35.67161480975631 139.73947050279202 39.299 35.67166474065251 139.73939453322538 39.299 35.67166430440019 139.73938992737263 39.299 35.67161098836932 139.73947105958732 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3106c71b-6d74-4bfc-a2c5-8ee102aa938b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3106c71b-6d74-4bfc-a2c5-8ee102aa938b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3106c71b-6d74-4bfc-a2c5-8ee102aa938b">
											<gml:posList>35.6716582499809 139.7393935245584 37.076 35.67164852676092 139.73938529531128 37.076 35.6716041784693 139.73945368048226 37.076 35.67159986622802 139.73946052327022 37.076 35.67161098836932 139.73947105958732 37.076 35.67166430440019 139.73938992737263 37.076 35.67167138544497 139.739396679495 37.076 35.671683052825166 139.73937820722549 37.076 35.671674662669346 139.7393687392143 37.076 35.6716582499809 139.7393935245584 37.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0421d58f-5949-41df-9b6a-f7289e9a64ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0421d58f-5949-41df-9b6a-f7289e9a64ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0421d58f-5949-41df-9b6a-f7289e9a64ee">
											<gml:posList>35.671676918373954 139.73953350523985 39.299 35.67167643703254 139.73952886629903 39.299 35.67161480975631 139.73947050279202 39.299 35.67161098836932 139.73947105958732 39.299 35.671676918373954 139.73953350523985 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97103857-49a4-41a9-9fc6-6f0d09d39a1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97103857-49a4-41a9-9fc6-6f0d09d39a1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97103857-49a4-41a9-9fc6-6f0d09d39a1c">
											<gml:posList>35.67166832504394 139.73933284572246 27.011 35.671640317440286 139.73937654510968 27.011 35.67164852676092 139.73938529531128 27.011 35.6716789858841 139.73934131688765 27.011 35.67166832504394 139.73933284572246 27.011</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-04d7f3cd-83b2-4575-846c-19d8eab2f8b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04d7f3cd-83b2-4575-846c-19d8eab2f8b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04d7f3cd-83b2-4575-846c-19d8eab2f8b3">
											<gml:posList>35.6716789858841 139.73934131688765 31.542 35.67164852676092 139.73938529531128 31.542 35.6716582499809 139.7393935245584 31.542 35.671674662669346 139.7393687392143 31.542 35.67168744750518 139.7393499563297 31.542 35.6716789858841 139.73934131688765 31.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3aacb24d-00e8-41bb-a01a-845cd1ef06cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3aacb24d-00e8-41bb-a01a-845cd1ef06cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3aacb24d-00e8-41bb-a01a-845cd1ef06cc">
											<gml:posList>35.67167138544497 139.739396679495 39.299 35.67166430440019 139.73938992737263 39.299 35.67166474065251 139.73939453322538 39.299 35.671671866791485 139.7394013184347 39.299 35.67167138544497 139.739396679495 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f06386b-0143-4436-8c89-5c43b8bf8c12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f06386b-0143-4436-8c89-5c43b8bf8c12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f06386b-0143-4436-8c89-5c43b8bf8c12">
											<gml:posList>35.67167138544497 139.739396679495 39.299 35.671671866791485 139.7394013184347 39.299 35.6716835161622 139.7393828682797 39.299 35.671683052825166 139.73937820722549 39.299 35.67167138544497 139.739396679495 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a573819-2d0a-465e-8920-fd6710cee113">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a573819-2d0a-465e-8920-fd6710cee113">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a573819-2d0a-465e-8920-fd6710cee113">
											<gml:posList>35.671683052825166 139.73937820722549 31.784 35.671684988335755 139.739375078815 31.784 35.67167866451125 139.7393684141774 31.784 35.671674662669346 139.7393687392143 31.784 35.671683052825166 139.73937820722549 31.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f3dea004-7533-4418-99c3-e1e1c40e771d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3dea004-7533-4418-99c3-e1e1c40e771d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3dea004-7533-4418-99c3-e1e1c40e771d">
											<gml:posList>35.67166474065251 139.73939453322538 38.987 35.67161480975631 139.73947050279202 38.987 35.67167643703254 139.73952886629903 38.987 35.671720585781266 139.73945883542137 38.987 35.67174696276673 139.73941620943464 38.987 35.67171473338238 139.73938630028132 38.987 35.671704461955756 139.73940326860549 38.987 35.6716835161622 139.7393828682797 38.987 35.671671866791485 139.7394013184347 38.987 35.67166474065251 139.73939453322538 38.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-69fdaa69-48eb-4fca-aa65-55856f71b220">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69fdaa69-48eb-4fca-aa65-55856f71b220">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69fdaa69-48eb-4fca-aa65-55856f71b220">
											<gml:posList>35.67170401665558 139.73939861857522 39.299 35.671683052825166 139.73937820722549 39.299 35.6716835161622 139.7393828682797 39.299 35.671704461955756 139.73940326860549 39.299 35.67170401665558 139.73939861857522 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38b10c73-cda6-4000-8912-97ed49b39a65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38b10c73-cda6-4000-8912-97ed49b39a65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38b10c73-cda6-4000-8912-97ed49b39a65">
											<gml:posList>35.671683052825166 139.73937820722549 37.076 35.67168488400675 139.73937999460264 37.076 35.67170756109379 139.73934348162933 37.076 35.67170712518443 139.73933931763165 37.076 35.671683052825166 139.73937820722549 37.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-80bc257c-5a6a-46b7-9f74-bebb8a2aa4ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80bc257c-5a6a-46b7-9f74-bebb8a2aa4ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80bc257c-5a6a-46b7-9f74-bebb8a2aa4ac">
											<gml:posList>35.67172440709923 139.73945819025326 39.299 35.671720585781266 139.73945883542137 39.299 35.67167643703254 139.73952886629903 39.299 35.671676918373954 139.73953350523985 39.299 35.67172440709923 139.73945819025326 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-406936f7-e6b8-4911-b486-5cf52d8a5d64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-406936f7-e6b8-4911-b486-5cf52d8a5d64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-406936f7-e6b8-4911-b486-5cf52d8a5d64">
											<gml:posList>35.67168744750518 139.7393499563297 28.297 35.671726873376635 139.73929200464875 28.297 35.67172102798226 139.73928624526144 28.297 35.67168170118685 139.7393440974069 28.297 35.67168744750518 139.7393499563297 28.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93c3ece3-c501-47c6-9c95-a7d5f12e358f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93c3ece3-c501-47c6-9c95-a7d5f12e358f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93c3ece3-c501-47c6-9c95-a7d5f12e358f">
											<gml:posList>35.6717272708332 139.73936237003673 36.94 35.67170756109379 139.73934348162933 36.94 35.67168488400675 139.73937999460264 36.94 35.67170401665558 139.73939861857522 36.94 35.6717272708332 139.73936237003673 36.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-594699e4-9cfa-45af-ac74-b14fe12f0aea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-594699e4-9cfa-45af-ac74-b14fe12f0aea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-594699e4-9cfa-45af-ac74-b14fe12f0aea">
											<gml:posList>35.671674662669346 139.7393687392143 31.784 35.67167866451125 139.7393684141774 31.784 35.67173929340087 139.73927931980617 31.784 35.67173888390917 139.73927436043206 31.784 35.671674662669346 139.7393687392143 31.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9503b7d3-e9a9-4804-91fc-887e45b235fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9503b7d3-e9a9-4804-91fc-887e45b235fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9503b7d3-e9a9-4804-91fc-887e45b235fb">
											<gml:posList>35.671728765291775 139.73936003748517 37.076 35.67170712518443 139.73933931763165 37.076 35.67170756109379 139.73934348162933 37.076 35.6717272708332 139.73936237003673 37.076 35.671728765291775 139.73936003748517 37.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2bcc0059-c1ff-40fb-b057-eaf0631e080b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bcc0059-c1ff-40fb-b057-eaf0631e080b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bcc0059-c1ff-40fb-b057-eaf0631e080b">
											<gml:posList>35.67171473338238 139.73938630028132 46.971 35.671716626013726 139.7393859777167 46.971 35.67172900432958 139.73936603542472 46.971 35.671728741129975 139.73936372702616 46.971 35.67171473338238 139.73938630028132 46.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-51015377-cb05-4124-932f-60fc6e8d7f00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51015377-cb05-4124-932f-60fc6e8d7f00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51015377-cb05-4124-932f-60fc6e8d7f00">
											<gml:posList>35.671676918373954 139.73953350523985 39.299 35.671777012225014 139.7395057388651 29.081 35.67172440709923 139.73945819025326 39.299 35.671676918373954 139.73953350523985 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-afa82939-83d1-49f4-b899-1b602e161ec2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afa82939-83d1-49f4-b899-1b602e161ec2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afa82939-83d1-49f4-b899-1b602e161ec2">
											<gml:posList>35.671676918373954 139.73953350523985 39.299 35.67172941699153 139.73958321910084 29.081 35.671777012225014 139.7395057388651 29.081 35.671676918373954 139.73953350523985 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41be49b2-6908-4eeb-841e-89e00b748c15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41be49b2-6908-4eeb-841e-89e00b748c15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41be49b2-6908-4eeb-841e-89e00b748c15">
											<gml:posList>35.67173848828938 139.7393448814105 31.311 35.67175400393295 139.73936029511 31.311 35.67178051772784 139.73931976773858 31.311 35.67173929340087 139.73927931980617 31.311 35.67167866451125 139.7393684141774 31.311 35.671684988335755 139.739375078815 31.311 35.67170712518443 139.73933931763165 31.311 35.671728765291775 139.73936003748517 31.311 35.67173848828938 139.7393448814105 31.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af8b276b-8772-4cfa-9db2-8d4840e47b0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af8b276b-8772-4cfa-9db2-8d4840e47b0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af8b276b-8772-4cfa-9db2-8d4840e47b0e">
											<gml:posList>35.67174858641677 139.73941772089603 46.971 35.67174832321816 139.73941541249673 46.971 35.671716626013726 139.7393859777167 46.971 35.67171473338238 139.73938630028132 46.971 35.67174858641677 139.73941772089603 46.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af59f25a-6753-4c00-9d5c-42bc60b8cf85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af59f25a-6753-4c00-9d5c-42bc60b8cf85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af59f25a-6753-4c00-9d5c-42bc60b8cf85">
											<gml:posList>35.67176255808945 139.7393951145397 39.299 35.67174858641677 139.73941772089603 39.299 35.671772191660985 139.73938086437664 39.299 35.671755169780525 139.7393642373257 39.299 35.671756268135425 139.73936254593167 39.299 35.67173848828938 139.7393448814105 39.299 35.67170401665558 139.73939861857522 39.299 35.671704461955756 139.73940326860549 39.299 35.67171473338238 139.73938630028132 39.299 35.671728741129975 139.73936372702616 39.299 35.67173848137951 139.73934757675153 39.299 35.671754230801874 139.73936225006548 39.299 35.671752790416974 139.73936457150793 39.299 35.67177019953398 139.7393807452002 39.299 35.671761773327 139.7393943863935 39.299 35.67176255808945 139.7393951145397 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb53f5b6-e8db-4075-9349-038265049b86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb53f5b6-e8db-4075-9349-038265049b86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb53f5b6-e8db-4075-9349-038265049b86">
											<gml:posList>35.671760674480424 139.73939544814016 46.472 35.67172900432958 139.73936603542472 46.472 35.671716626013726 139.7393859777167 46.472 35.671748332231886 139.73941541248618 46.472 35.671760674480424 139.73939544814016 46.472</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c8abcf6-7f10-4084-bb38-04871133eb69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c8abcf6-7f10-4084-bb38-04871133eb69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c8abcf6-7f10-4084-bb38-04871133eb69">
											<gml:posList>35.671728741129975 139.73936372702616 46.971 35.67172900432958 139.73936603542472 46.971 35.671760674480424 139.73939544814016 46.971 35.67176255808945 139.7393951145397 46.971 35.671728741129975 139.73936372702616 46.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6fc805df-0e5e-4a5b-91a0-3cfa5faa0f05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fc805df-0e5e-4a5b-91a0-3cfa5faa0f05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fc805df-0e5e-4a5b-91a0-3cfa5faa0f05">
											<gml:posList>35.67172440709923 139.73945819025326 39.299 35.671772191660985 139.73938086437664 39.299 35.67174858641677 139.73941772089603 39.299 35.67174696276673 139.73941620943464 39.299 35.671720585781266 139.73945883542137 39.299 35.67172440709923 139.73945819025326 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-30eb50e9-7e7e-4362-832e-868a2b9de5be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30eb50e9-7e7e-4362-832e-868a2b9de5be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30eb50e9-7e7e-4362-832e-868a2b9de5be">
											<gml:posList>35.671728741129975 139.73936372702616 38.987 35.671761773327 139.7393943863935 38.987 35.67177019953398 139.7393807452002 38.987 35.671752790416974 139.73936457150793 38.987 35.671754230801874 139.73936225006548 38.987 35.67173848137951 139.73934757675153 38.987 35.671728741129975 139.73936372702616 38.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb424a22-852c-4209-b002-af477fe1afa2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb424a22-852c-4209-b002-af477fe1afa2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb424a22-852c-4209-b002-af477fe1afa2">
											<gml:posList>35.67176255808945 139.7393951145397 46.971 35.671760674480424 139.73939544814016 46.971 35.67174832321816 139.73941541249673 46.971 35.67174858641677 139.73941772089603 46.971 35.67176255808945 139.7393951145397 46.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c3bd2997-41ec-4086-a7e5-c728e124fc86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3bd2997-41ec-4086-a7e5-c728e124fc86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3bd2997-41ec-4086-a7e5-c728e124fc86">
											<gml:posList>35.67173888390917 139.73927436043206 31.784 35.67173929340087 139.73927931980617 31.784 35.67178051772784 139.73931976773858 31.784 35.67178459148955 139.7393191995925 31.784 35.67173888390917 139.73927436043206 31.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2553f3df-0932-434c-883c-aeccde469eca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2553f3df-0932-434c-883c-aeccde469eca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2553f3df-0932-434c-883c-aeccde469eca">
											<gml:posList>35.671756268135425 139.73936254593167 31.784 35.67178459148955 139.7393191995925 31.784 35.67178051772784 139.73931976773858 31.784 35.67175400393295 139.73936029511 31.784 35.671756268135425 139.73936254593167 31.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-177ae592-26b5-4a40-b48d-76e797227f35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-177ae592-26b5-4a40-b48d-76e797227f35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-177ae592-26b5-4a40-b48d-76e797227f35">
											<gml:posList>35.67172900432958 139.73936603542472 46.971 35.67172900432958 139.73936603542472 46.472 35.671760674480424 139.73939544814016 46.472 35.671760674480424 139.73939544814016 46.971 35.67172900432958 139.73936603542472 46.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05f5a860-1ba7-4c03-aa5f-1fbd34c51333">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05f5a860-1ba7-4c03-aa5f-1fbd34c51333">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05f5a860-1ba7-4c03-aa5f-1fbd34c51333">
											<gml:posList>35.67174832321816 139.73941541249673 46.971 35.671748332231886 139.73941541248618 46.472 35.671716626013726 139.7393859777167 46.472 35.671716626013726 139.7393859777167 46.971 35.67174832321816 139.73941541249673 46.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6649233-36a2-43de-ad61-1d16e1888906">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6649233-36a2-43de-ad61-1d16e1888906">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6649233-36a2-43de-ad61-1d16e1888906">
											<gml:posList>35.67157746823219 139.73941572310542 9.64 35.67156815955498 139.73943049203098 9.64 35.67156815955498 139.73943049203098 24.203 35.67157746823219 139.73941572310542 24.203 35.67157746823219 139.73941572310542 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d0cfc93-c30b-40cc-87ea-6b2e03b3114c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d0cfc93-c30b-40cc-87ea-6b2e03b3114c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d0cfc93-c30b-40cc-87ea-6b2e03b3114c">
											<gml:posList>35.671590521097876 139.73945166393196 26.745 35.671590521097876 139.73945166393196 29.409 35.671594292877174 139.73944528572716 29.409 35.671594292877174 139.73944528572716 26.745 35.671590521097876 139.73945166393196 26.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad03c8b5-4bd3-4f2e-8cf0-b12930331eb4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad03c8b5-4bd3-4f2e-8cf0-b12930331eb4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad03c8b5-4bd3-4f2e-8cf0-b12930331eb4">
											<gml:posList>35.671726873376635 139.73929200464875 28.297 35.671726873376635 139.73929200464875 9.64 35.67172102798226 139.73928624526144 9.64 35.67172102798226 139.73928624526144 28.297 35.671726873376635 139.73929200464875 28.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a57914f8-5e9c-4bb3-b7f7-4226e4c3e61f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a57914f8-5e9c-4bb3-b7f7-4226e4c3e61f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a57914f8-5e9c-4bb3-b7f7-4226e4c3e61f">
											<gml:posList>35.67178459148955 139.7393191995925 9.64 35.67173888390917 139.73927436043206 9.64 35.67173888390917 139.73927436043206 31.784 35.67178459148955 139.7393191995925 31.784 35.67178459148955 139.7393191995925 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0c15d1c-26d9-4d3f-8b80-555b2bc58807">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0c15d1c-26d9-4d3f-8b80-555b2bc58807">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0c15d1c-26d9-4d3f-8b80-555b2bc58807">
											<gml:posList>35.67173929340087 139.73927931980617 31.784 35.67173929340087 139.73927931980617 31.311 35.67178051772784 139.73931976773858 31.311 35.67178051772784 139.73931976773858 31.784 35.67173929340087 139.73927931980617 31.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a023cb6-b8bc-43a0-b72e-3efd613c0311">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a023cb6-b8bc-43a0-b72e-3efd613c0311">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a023cb6-b8bc-43a0-b72e-3efd613c0311">
											<gml:posList>35.67172102798226 139.73928624526144 28.297 35.67172102798226 139.73928624526144 9.64 35.67168170118685 139.7393440974069 9.64 35.67168170118685 139.7393440974069 28.297 35.67172102798226 139.73928624526144 28.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca82e59e-8ffb-4ac3-9bdd-a9b57df4ef72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca82e59e-8ffb-4ac3-9bdd-a9b57df4ef72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca82e59e-8ffb-4ac3-9bdd-a9b57df4ef72">
											<gml:posList>35.67168744750518 139.7393499563297 31.542 35.671674662669346 139.7393687392143 31.542 35.671674662669346 139.7393687392143 31.784 35.67173888390917 139.73927436043206 31.784 35.67173888390917 139.73927436043206 9.64 35.671726873376635 139.73929200464875 9.64 35.671726873376635 139.73929200464875 28.297 35.67168744750518 139.7393499563297 28.297 35.67168744750518 139.7393499563297 31.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e10e4589-d790-475f-93e6-b019f89fefce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e10e4589-d790-475f-93e6-b019f89fefce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e10e4589-d790-475f-93e6-b019f89fefce">
											<gml:posList>35.67167866451125 139.7393684141774 31.784 35.67167866451125 139.7393684141774 31.311 35.67173929340087 139.73927931980617 31.311 35.67173929340087 139.73927931980617 31.784 35.67167866451125 139.7393684141774 31.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eaa14759-2875-4989-a7b0-9d7e30d4f330">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eaa14759-2875-4989-a7b0-9d7e30d4f330">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eaa14759-2875-4989-a7b0-9d7e30d4f330">
											<gml:posList>35.67166832504394 139.73933284572246 27.011 35.6716789858841 139.73934131688765 27.011 35.6716789858841 139.73934131688765 9.64 35.67166832504394 139.73933284572246 9.64 35.67166832504394 139.73933284572246 27.011</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6d52fc2-8bdb-4704-b596-ceab2921b68a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6d52fc2-8bdb-4704-b596-ceab2921b68a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6d52fc2-8bdb-4704-b596-ceab2921b68a">
											<gml:posList>35.67178051772784 139.73931976773858 31.784 35.67178051772784 139.73931976773858 31.311 35.67175400393295 139.73936029511 31.311 35.67175400393295 139.73936029511 31.784 35.67178051772784 139.73931976773858 31.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f650330b-9fb6-4a4d-8b2b-c3ffa1f5bd21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f650330b-9fb6-4a4d-8b2b-c3ffa1f5bd21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f650330b-9fb6-4a4d-8b2b-c3ffa1f5bd21">
											<gml:posList>35.671756268135425 139.73936254593167 31.784 35.671756268135425 139.73936254593167 39.299 35.671755169780525 139.7393642373257 39.299 35.671755169780525 139.7393642373257 9.64 35.67178459148955 139.7393191995925 9.64 35.67178459148955 139.7393191995925 31.784 35.671756268135425 139.73936254593167 31.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f6d8814-85e6-4ade-be9d-828448889567">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f6d8814-85e6-4ade-be9d-828448889567">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f6d8814-85e6-4ade-be9d-828448889567">
											<gml:posList>35.6716789858841 139.73934131688765 27.011 35.6716789858841 139.73934131688765 31.542 35.67168744750518 139.7393499563297 31.542 35.67168744750518 139.7393499563297 28.297 35.67168170118685 139.7393440974069 28.297 35.67168170118685 139.7393440974069 9.64 35.6716789858841 139.73934131688765 9.64 35.6716789858841 139.73934131688765 27.011</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5423f54-28ee-4f6a-a8a5-83f729c4ca0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5423f54-28ee-4f6a-a8a5-83f729c4ca0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5423f54-28ee-4f6a-a8a5-83f729c4ca0d">
											<gml:posList>35.67170712518443 139.73933931763165 37.076 35.671728765291775 139.73936003748517 37.076 35.671728765291775 139.73936003748517 31.311 35.67170712518443 139.73933931763165 31.311 35.67170712518443 139.73933931763165 37.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2002a577-2de4-4ea2-bc7f-277dd8242704">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2002a577-2de4-4ea2-bc7f-277dd8242704">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2002a577-2de4-4ea2-bc7f-277dd8242704">
											<gml:posList>35.67170756109379 139.73934348162933 37.076 35.67170756109379 139.73934348162933 36.94 35.6717272708332 139.73936237003673 36.94 35.6717272708332 139.73936237003673 37.076 35.67170756109379 139.73934348162933 37.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c5954bc-b443-44e3-b27e-fda0af4c66c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c5954bc-b443-44e3-b27e-fda0af4c66c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c5954bc-b443-44e3-b27e-fda0af4c66c4">
											<gml:posList>35.67173848828938 139.7393448814105 31.311 35.67173848828938 139.7393448814105 39.299 35.671756268135425 139.73936254593167 39.299 35.671756268135425 139.73936254593167 31.784 35.67175400393295 139.73936029511 31.784 35.67175400393295 139.73936029511 31.311 35.67173848828938 139.7393448814105 31.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10c3185e-15b8-47dd-b75c-8467630085e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10c3185e-15b8-47dd-b75c-8467630085e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10c3185e-15b8-47dd-b75c-8467630085e6">
											<gml:posList>35.67166832504394 139.73933284572246 27.011 35.67166832504394 139.73933284572246 9.64 35.671640317440286 139.73937654510968 9.64 35.671640317440286 139.73937654510968 26.745 35.671640317440286 139.73937654510968 27.011 35.67166832504394 139.73933284572246 27.011</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f647d5d6-db7b-4e88-8d01-909807722de1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f647d5d6-db7b-4e88-8d01-909807722de1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f647d5d6-db7b-4e88-8d01-909807722de1">
											<gml:posList>35.67173848137951 139.73934757675153 39.299 35.67173848137951 139.73934757675153 38.987 35.671754230801874 139.73936225006548 38.987 35.671754230801874 139.73936225006548 39.299 35.67173848137951 139.73934757675153 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e90e5ca8-b51e-4de4-890b-2f50a35cc04b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e90e5ca8-b51e-4de4-890b-2f50a35cc04b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e90e5ca8-b51e-4de4-890b-2f50a35cc04b">
											<gml:posList>35.671728741129975 139.73936372702616 39.299 35.671728741129975 139.73936372702616 38.987 35.67173848137951 139.73934757675153 38.987 35.67173848137951 139.73934757675153 39.299 35.671728741129975 139.73936372702616 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41607399-c097-441c-befb-cfe6efae425b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41607399-c097-441c-befb-cfe6efae425b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41607399-c097-441c-befb-cfe6efae425b">
											<gml:posList>35.671684988335755 139.739375078815 31.784 35.671683052825166 139.73937820722549 31.784 35.671683052825166 139.73937820722549 37.076 35.67170712518443 139.73933931763165 37.076 35.67170712518443 139.73933931763165 31.311 35.671684988335755 139.739375078815 31.311 35.671684988335755 139.739375078815 31.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3e3f8fa-b128-4ccb-ae06-f8f54d3ff9c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3e3f8fa-b128-4ccb-ae06-f8f54d3ff9c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3e3f8fa-b128-4ccb-ae06-f8f54d3ff9c2">
											<gml:posList>35.67168488400675 139.73937999460264 37.076 35.67168488400675 139.73937999460264 36.94 35.67170756109379 139.73934348162933 36.94 35.67170756109379 139.73934348162933 37.076 35.67168488400675 139.73937999460264 37.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43b01f1f-6731-4fb5-a14f-e8e5c94a6b4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43b01f1f-6731-4fb5-a14f-e8e5c94a6b4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43b01f1f-6731-4fb5-a14f-e8e5c94a6b4b">
											<gml:posList>35.67163095403522 139.73936737649808 24.203 35.67163095403522 139.73936737649808 9.64 35.671623032652306 139.73935798526975 9.64 35.671623032652306 139.73935798526975 24.203 35.67163095403522 139.73936737649808 24.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25e2e595-e225-4fb3-9289-0627971fd61b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25e2e595-e225-4fb3-9289-0627971fd61b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25e2e595-e225-4fb3-9289-0627971fd61b">
											<gml:posList>35.6716789858841 139.73934131688765 31.542 35.6716789858841 139.73934131688765 27.011 35.67164852676092 139.73938529531128 27.011 35.67164852676092 139.73938529531128 29.409 35.67164852676092 139.73938529531128 31.542 35.6716789858841 139.73934131688765 31.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58e8658e-bb27-44a6-b3b6-eae93be55d69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58e8658e-bb27-44a6-b3b6-eae93be55d69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58e8658e-bb27-44a6-b3b6-eae93be55d69">
											<gml:posList>35.671754230801874 139.73936225006548 39.299 35.671754230801874 139.73936225006548 38.987 35.671752790416974 139.73936457150793 38.987 35.671752790416974 139.73936457150793 39.299 35.671754230801874 139.73936225006548 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe076ae2-7276-4b75-b77a-a5dc360773cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe076ae2-7276-4b75-b77a-a5dc360773cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe076ae2-7276-4b75-b77a-a5dc360773cb">
											<gml:posList>35.671684988335755 139.739375078815 31.784 35.671684988335755 139.739375078815 31.311 35.67167866451125 139.7393684141774 31.311 35.67167866451125 139.7393684141774 31.784 35.671684988335755 139.739375078815 31.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d43a31e-cf26-4e7d-ae16-9005f961f236">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d43a31e-cf26-4e7d-ae16-9005f961f236">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d43a31e-cf26-4e7d-ae16-9005f961f236">
											<gml:posList>35.67173848828938 139.7393448814105 39.299 35.67173848828938 139.7393448814105 31.311 35.671728765291775 139.73936003748517 31.311 35.671728765291775 139.73936003748517 37.076 35.6717272708332 139.73936237003673 37.076 35.6717272708332 139.73936237003673 36.94 35.67170401665558 139.73939861857522 36.94 35.67170401665558 139.73939861857522 39.299 35.67173848828938 139.7393448814105 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c4df788-8962-439a-9390-6fa0eae61e85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c4df788-8962-439a-9390-6fa0eae61e85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c4df788-8962-439a-9390-6fa0eae61e85">
											<gml:posList>35.671640317440286 139.73937654510968 26.745 35.671640317440286 139.73937654510968 9.64 35.67163095403522 139.73936737649808 9.64 35.67163095403522 139.73936737649808 24.203 35.67163095403522 139.73936737649808 26.745 35.671640317440286 139.73937654510968 26.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c01f4c09-18c9-4de0-9ca9-e24f63c208a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c01f4c09-18c9-4de0-9ca9-e24f63c208a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c01f4c09-18c9-4de0-9ca9-e24f63c208a9">
											<gml:posList>35.671772191660985 139.73938086437664 9.64 35.671755169780525 139.7393642373257 9.64 35.671755169780525 139.7393642373257 39.299 35.671772191660985 139.73938086437664 39.299 35.671772191660985 139.73938086437664 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-637d78fc-99c6-44a7-8972-016e4b719655">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-637d78fc-99c6-44a7-8972-016e4b719655">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-637d78fc-99c6-44a7-8972-016e4b719655">
											<gml:posList>35.671752790416974 139.73936457150793 39.299 35.671752790416974 139.73936457150793 38.987 35.67177019953398 139.7393807452002 38.987 35.67177019953398 139.7393807452002 39.299 35.671752790416974 139.73936457150793 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1ae66dc-a537-4727-9508-feaf9100bbac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1ae66dc-a537-4727-9508-feaf9100bbac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1ae66dc-a537-4727-9508-feaf9100bbac">
											<gml:posList>35.671674662669346 139.7393687392143 37.076 35.671683052825166 139.73937820722549 37.076 35.671683052825166 139.73937820722549 31.784 35.671674662669346 139.7393687392143 31.784 35.671674662669346 139.7393687392143 37.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1332dca7-48c7-409e-9921-8c49cb13d85a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1332dca7-48c7-409e-9921-8c49cb13d85a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1332dca7-48c7-409e-9921-8c49cb13d85a">
											<gml:posList>35.67171473338238 139.73938630028132 39.299 35.67171473338238 139.73938630028132 46.971 35.671728741129975 139.73936372702616 46.971 35.671728741129975 139.73936372702616 39.299 35.67171473338238 139.73938630028132 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88f1d708-1357-4002-b351-e167b4e12a68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88f1d708-1357-4002-b351-e167b4e12a68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88f1d708-1357-4002-b351-e167b4e12a68">
											<gml:posList>35.671716626013726 139.7393859777167 46.971 35.671716626013726 139.7393859777167 46.472 35.67172900432958 139.73936603542472 46.472 35.67172900432958 139.73936603542472 46.971 35.671716626013726 139.7393859777167 46.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1578829d-bd63-4bb4-aa1c-cb1a8c8c55c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1578829d-bd63-4bb4-aa1c-cb1a8c8c55c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1578829d-bd63-4bb4-aa1c-cb1a8c8c55c4">
											<gml:posList>35.671728741129975 139.73936372702616 39.299 35.671728741129975 139.73936372702616 46.971 35.67176255808945 139.7393951145397 46.971 35.67176255808945 139.7393951145397 39.299 35.671761773327 139.7393943863935 39.299 35.671761773327 139.7393943863935 38.987 35.671728741129975 139.73936372702616 38.987 35.671728741129975 139.73936372702616 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee1aa8e5-f60a-4818-890c-3ee2937dcd00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee1aa8e5-f60a-4818-890c-3ee2937dcd00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee1aa8e5-f60a-4818-890c-3ee2937dcd00">
											<gml:posList>35.671640317440286 139.73937654510968 27.011 35.671640317440286 139.73937654510968 29.409 35.67164852676092 139.73938529531128 29.409 35.67164852676092 139.73938529531128 27.011 35.671640317440286 139.73937654510968 27.011</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b982525-a7a2-4d4a-a695-4a73ed25ffe6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b982525-a7a2-4d4a-a695-4a73ed25ffe6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b982525-a7a2-4d4a-a695-4a73ed25ffe6">
											<gml:posList>35.6716582499809 139.7393935245584 31.542 35.6716582499809 139.7393935245584 37.076 35.671674662669346 139.7393687392143 37.076 35.671674662669346 139.7393687392143 31.784 35.671674662669346 139.7393687392143 31.542 35.6716582499809 139.7393935245584 31.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dcbc8065-a986-4ed2-aff7-fbcef2be3b64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcbc8065-a986-4ed2-aff7-fbcef2be3b64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcbc8065-a986-4ed2-aff7-fbcef2be3b64">
											<gml:posList>35.67157746823219 139.73941572310542 9.64 35.67157746823219 139.73941572310542 24.203 35.671623032652306 139.73935798526975 24.203 35.671623032652306 139.73935798526975 9.64 35.67157746823219 139.73941572310542 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28b92c85-133f-42a0-b9fb-cbf6317913b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28b92c85-133f-42a0-b9fb-cbf6317913b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28b92c85-133f-42a0-b9fb-cbf6317913b8">
											<gml:posList>35.67167138544497 139.739396679495 39.299 35.671683052825166 139.73937820722549 39.299 35.671683052825166 139.73937820722549 37.076 35.67167138544497 139.739396679495 37.076 35.67167138544497 139.739396679495 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca9f80e3-6c9c-488a-a408-569afa76d936">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca9f80e3-6c9c-488a-a408-569afa76d936">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca9f80e3-6c9c-488a-a408-569afa76d936">
											<gml:posList>35.67177019953398 139.7393807452002 39.299 35.67177019953398 139.7393807452002 38.987 35.671761773327 139.7393943863935 38.987 35.671761773327 139.7393943863935 39.299 35.67177019953398 139.7393807452002 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65285be8-a564-43b7-8038-140d439faf86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65285be8-a564-43b7-8038-140d439faf86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65285be8-a564-43b7-8038-140d439faf86">
											<gml:posList>35.67168488400675 139.73937999460264 37.076 35.671683052825166 139.73937820722549 37.076 35.671683052825166 139.73937820722549 39.299 35.67170401665558 139.73939861857522 39.299 35.67170401665558 139.73939861857522 36.94 35.67168488400675 139.73937999460264 36.94 35.67168488400675 139.73937999460264 37.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3bb8afbf-613f-445e-9762-301ba8ad7ece">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bb8afbf-613f-445e-9762-301ba8ad7ece">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bb8afbf-613f-445e-9762-301ba8ad7ece">
											<gml:posList>35.67164852676092 139.73938529531128 31.542 35.67164852676092 139.73938529531128 37.076 35.6716582499809 139.7393935245584 37.076 35.6716582499809 139.7393935245584 31.542 35.67164852676092 139.73938529531128 31.542</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e735b2a8-da4d-4523-a610-caa968d685b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e735b2a8-da4d-4523-a610-caa968d685b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e735b2a8-da4d-4523-a610-caa968d685b9">
											<gml:posList>35.671671866791485 139.7394013184347 39.299 35.671671866791485 139.7394013184347 38.987 35.6716835161622 139.7393828682797 38.987 35.6716835161622 139.7393828682797 39.299 35.671671866791485 139.7394013184347 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb4ddd57-9814-4c63-9f21-c7e2f4916a26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb4ddd57-9814-4c63-9f21-c7e2f4916a26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb4ddd57-9814-4c63-9f21-c7e2f4916a26">
											<gml:posList>35.6716835161622 139.7393828682797 39.299 35.6716835161622 139.7393828682797 38.987 35.671704461955756 139.73940326860549 38.987 35.671704461955756 139.73940326860549 39.299 35.6716835161622 139.7393828682797 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fdaf9a4-3280-454b-b164-750ad81dd3ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fdaf9a4-3280-454b-b164-750ad81dd3ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fdaf9a4-3280-454b-b164-750ad81dd3ca">
											<gml:posList>35.67166430440019 139.73938992737263 39.299 35.67167138544497 139.739396679495 39.299 35.67167138544497 139.739396679495 37.076 35.67166430440019 139.73938992737263 37.076 35.67166430440019 139.73938992737263 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-026ad587-cdfd-45ee-a49d-e4add40f26c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-026ad587-cdfd-45ee-a49d-e4add40f26c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-026ad587-cdfd-45ee-a49d-e4add40f26c2">
											<gml:posList>35.671704461955756 139.73940326860549 39.299 35.671704461955756 139.73940326860549 38.987 35.67171473338238 139.73938630028132 38.987 35.67171473338238 139.73938630028132 39.299 35.671704461955756 139.73940326860549 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7391301-7038-41f8-ab72-e194ec760ecb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7391301-7038-41f8-ab72-e194ec760ecb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7391301-7038-41f8-ab72-e194ec760ecb">
											<gml:posList>35.67166474065251 139.73939453322538 39.299 35.67166474065251 139.73939453322538 38.987 35.671671866791485 139.7394013184347 38.987 35.671671866791485 139.7394013184347 39.299 35.67166474065251 139.73939453322538 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f877e1d-c5b1-4020-8b25-2af3b5e0855e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f877e1d-c5b1-4020-8b25-2af3b5e0855e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f877e1d-c5b1-4020-8b25-2af3b5e0855e">
											<gml:posList>35.67171473338238 139.73938630028132 39.299 35.67171473338238 139.73938630028132 38.987 35.67174696276673 139.73941620943464 38.987 35.67174696276673 139.73941620943464 39.299 35.67174858641677 139.73941772089603 39.299 35.67174858641677 139.73941772089603 46.971 35.67171473338238 139.73938630028132 46.971 35.67171473338238 139.73938630028132 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3520ecfd-c5ef-43bd-a4a2-ba1e38880617">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3520ecfd-c5ef-43bd-a4a2-ba1e38880617">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3520ecfd-c5ef-43bd-a4a2-ba1e38880617">
											<gml:posList>35.671760674480424 139.73939544814016 46.971 35.671760674480424 139.73939544814016 46.472 35.671748332231886 139.73941541248618 46.472 35.67174832321816 139.73941541249673 46.971 35.671760674480424 139.73939544814016 46.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c351ea31-85c5-488b-8e3d-18a86e1fbd61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c351ea31-85c5-488b-8e3d-18a86e1fbd61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c351ea31-85c5-488b-8e3d-18a86e1fbd61">
											<gml:posList>35.67158247491614 139.7394440513206 24.203 35.67158247491614 139.7394440513206 26.745 35.67163095403522 139.73936737649808 26.745 35.67163095403522 139.73936737649808 24.203 35.67158247491614 139.7394440513206 24.203</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf3c5fcd-beca-4312-9e0d-006fc0e27f63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf3c5fcd-beca-4312-9e0d-006fc0e27f63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf3c5fcd-beca-4312-9e0d-006fc0e27f63">
											<gml:posList>35.67176255808945 139.7393951145397 39.299 35.67176255808945 139.7393951145397 46.971 35.67174858641677 139.73941772089603 46.971 35.67174858641677 139.73941772089603 39.299 35.67176255808945 139.7393951145397 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72d896eb-fc31-4034-8d2b-3aa2f773797d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72d896eb-fc31-4034-8d2b-3aa2f773797d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72d896eb-fc31-4034-8d2b-3aa2f773797d">
											<gml:posList>35.671594292877174 139.73944528572716 26.745 35.671594292877174 139.73944528572716 29.409 35.671640317440286 139.73937654510968 29.409 35.671640317440286 139.73937654510968 27.011 35.671640317440286 139.73937654510968 26.745 35.671594292877174 139.73944528572716 26.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d34aa70-f060-4aae-8f50-160d14296f5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d34aa70-f060-4aae-8f50-160d14296f5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d34aa70-f060-4aae-8f50-160d14296f5a">
											<gml:posList>35.6716041784693 139.73945368048226 29.409 35.6716041784693 139.73945368048226 37.076 35.67164852676092 139.73938529531128 37.076 35.67164852676092 139.73938529531128 31.542 35.67164852676092 139.73938529531128 29.409 35.6716041784693 139.73945368048226 29.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43a70771-8a64-4f24-878e-d900356efa20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43a70771-8a64-4f24-878e-d900356efa20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43a70771-8a64-4f24-878e-d900356efa20">
											<gml:posList>35.67172430807748 139.73945835606585 9.64 35.671772191660985 139.73938086437664 9.64 35.671772191660985 139.73938086437664 39.299 35.67172440709923 139.73945819025326 39.299 35.67172430807748 139.73945835606585 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-537595e1-0bd0-4940-90b9-33f42d34e6a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-537595e1-0bd0-4940-90b9-33f42d34e6a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-537595e1-0bd0-4940-90b9-33f42d34e6a8">
											<gml:posList>35.67166430440019 139.73938992737263 37.076 35.67161098836932 139.73947105958732 37.076 35.67161098836932 139.73947105958732 39.299 35.67166430440019 139.73938992737263 39.299 35.67166430440019 139.73938992737263 37.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d9e2784-5241-4c13-a3d1-75c75be2fba6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d9e2784-5241-4c13-a3d1-75c75be2fba6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d9e2784-5241-4c13-a3d1-75c75be2fba6">
											<gml:posList>35.67161480975631 139.73947050279202 39.299 35.67161480975631 139.73947050279202 38.987 35.67166474065251 139.73939453322538 38.987 35.67166474065251 139.73939453322538 39.299 35.67161480975631 139.73947050279202 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3087782-ca39-4d41-8fa3-2aafb3451f28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3087782-ca39-4d41-8fa3-2aafb3451f28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3087782-ca39-4d41-8fa3-2aafb3451f28">
											<gml:posList>35.67174696276673 139.73941620943464 39.299 35.67174696276673 139.73941620943464 38.987 35.671720585781266 139.73945883542137 38.987 35.671720585781266 139.73945883542137 39.299 35.67174696276673 139.73941620943464 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79fb384a-e151-4847-b984-211489733438">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79fb384a-e151-4847-b984-211489733438">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79fb384a-e151-4847-b984-211489733438">
											<gml:posList>35.67159986622802 139.73946052327022 37.076 35.6716041784693 139.73945368048226 37.076 35.6716041784693 139.73945368048226 29.409 35.67159986622802 139.73946052327022 29.409 35.67159986622802 139.73946052327022 37.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b607665-b0ef-4c5a-bb6d-43d0415e237a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b607665-b0ef-4c5a-bb6d-43d0415e237a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b607665-b0ef-4c5a-bb6d-43d0415e237a">
											<gml:posList>35.671777012225014 139.7395057388651 29.081 35.671777012225014 139.7395057388651 9.64 35.67172430807748 139.73945835606585 9.64 35.67172440709923 139.73945819025326 39.299 35.671777012225014 139.7395057388651 29.081</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07fedbf0-19d2-41df-ac4a-88b81123e54c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07fedbf0-19d2-41df-ac4a-88b81123e54c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07fedbf0-19d2-41df-ac4a-88b81123e54c">
											<gml:posList>35.671720585781266 139.73945883542137 39.299 35.671720585781266 139.73945883542137 38.987 35.67167643703254 139.73952886629903 38.987 35.67167643703254 139.73952886629903 39.299 35.671720585781266 139.73945883542137 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29737cf2-c32d-4d47-a99d-c1bcbc67a914">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29737cf2-c32d-4d47-a99d-c1bcbc67a914">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29737cf2-c32d-4d47-a99d-c1bcbc67a914">
											<gml:posList>35.67167643703254 139.73952886629903 39.299 35.67167643703254 139.73952886629903 38.987 35.67161480975631 139.73947050279202 38.987 35.67161480975631 139.73947050279202 39.299 35.67167643703254 139.73952886629903 39.299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c94967b-f413-42da-b4d5-984c32583c1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c94967b-f413-42da-b4d5-984c32583c1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c94967b-f413-42da-b4d5-984c32583c1a">
											<gml:posList>35.67159986622802 139.73946052327022 29.409 35.671590521097876 139.73945166393196 29.409 35.671590521097876 139.73945166393196 26.745 35.67158247491614 139.7394440513206 26.745 35.67158247491614 139.7394440513206 24.203 35.67156815955498 139.73943049203098 24.203 35.67156815955498 139.73943049203098 9.64 35.67172941699153 139.73958321910084 9.64 35.67172941699153 139.73958321910084 29.081 35.671676918373954 139.73953350523985 39.299 35.67161098836932 139.73947105958732 39.299 35.67161098836932 139.73947105958732 37.076 35.67159986622802 139.73946052327022 37.076 35.67159986622802 139.73946052327022 29.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-957576e9-76d4-44e1-bff8-59fafbdc748e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-957576e9-76d4-44e1-bff8-59fafbdc748e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-957576e9-76d4-44e1-bff8-59fafbdc748e">
											<gml:posList>35.67172941699153 139.73958321910084 9.64 35.671777012225014 139.7395057388651 9.64 35.671777012225014 139.7395057388651 29.081 35.67172941699153 139.73958321910084 29.081 35.67172941699153 139.73958321910084 9.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6294</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">300.67425</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>