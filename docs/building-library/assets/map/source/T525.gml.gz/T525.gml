<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9851ec85-434d-4b1c-95cb-7ce9a9714694">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:measuredHeight uom="m">67.9</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671262967021654 139.74449518446121 0 35.671594468611545 139.74443907686512 0 35.671560970122755 139.7441418437311 0 35.67151724509542 139.7440210114386 0 35.67150895350368 139.7440224125236 0 35.671505269651476 139.7439896861002 0 35.6712400559312 139.7440345758733 0 35.67124361403769 139.74406792092773 0 35.67123560251729 139.74407019435503 0 35.67121753843586 139.7442032791021 0 35.671250738512505 139.74451163502417 0 35.67126456385148 139.74450929996763 0 35.671262967021654 139.74449518446121 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671262967021654 139.74449518446121 6.84 35.67126456385148 139.74450929996763 6.84 35.671250738512505 139.74451163502417 6.84 35.67121753843586 139.7442032791021 6.84 35.67123560251729 139.74407019435503 6.84 35.67124361403769 139.74406792092773 6.84 35.6712400559312 139.7440345758733 6.84 35.671505269651476 139.7439896861002 6.84 35.67150895350368 139.7440224125236 6.84 35.67151724509542 139.7440210114386 6.84 35.671560970122755 139.7441418437311 6.84 35.671594468611545 139.74443907686512 6.84 35.671262967021654 139.74449518446121 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671262967021654 139.74449518446121 6.84 35.671594468611545 139.74443907686512 6.84 35.671594468611545 139.74443907686512 74.78 35.671262967021654 139.74449518446121 74.78 35.671262967021654 139.74449518446121 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671594468611545 139.74443907686512 6.84 35.671560970122755 139.7441418437311 6.84 35.671560970122755 139.7441418437311 74.78 35.671594468611545 139.74443907686512 74.78 35.671594468611545 139.74443907686512 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671560970122755 139.7441418437311 6.84 35.67151724509542 139.7440210114386 6.84 35.67151724509542 139.7440210114386 74.78 35.671560970122755 139.7441418437311 74.78 35.671560970122755 139.7441418437311 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67151724509542 139.7440210114386 6.84 35.67150895350368 139.7440224125236 6.84 35.67150895350368 139.7440224125236 74.78 35.67151724509542 139.7440210114386 74.78 35.67151724509542 139.7440210114386 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67150895350368 139.7440224125236 6.84 35.671505269651476 139.7439896861002 6.84 35.671505269651476 139.7439896861002 74.78 35.67150895350368 139.7440224125236 74.78 35.67150895350368 139.7440224125236 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671505269651476 139.7439896861002 6.84 35.6712400559312 139.7440345758733 6.84 35.6712400559312 139.7440345758733 74.78 35.671505269651476 139.7439896861002 74.78 35.671505269651476 139.7439896861002 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6712400559312 139.7440345758733 6.84 35.67124361403769 139.74406792092773 6.84 35.67124361403769 139.74406792092773 74.78 35.6712400559312 139.7440345758733 74.78 35.6712400559312 139.7440345758733 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67124361403769 139.74406792092773 6.84 35.67123560251729 139.74407019435503 6.84 35.67123560251729 139.74407019435503 74.78 35.67124361403769 139.74406792092773 74.78 35.67124361403769 139.74406792092773 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67123560251729 139.74407019435503 6.84 35.67121753843586 139.7442032791021 6.84 35.67121753843586 139.7442032791021 74.78 35.67123560251729 139.74407019435503 74.78 35.67123560251729 139.74407019435503 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121753843586 139.7442032791021 6.84 35.671250738512505 139.74451163502417 6.84 35.671250738512505 139.74451163502417 74.78 35.67121753843586 139.7442032791021 74.78 35.67121753843586 139.7442032791021 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671250738512505 139.74451163502417 6.84 35.67126456385148 139.74450929996763 6.84 35.67126456385148 139.74450929996763 74.78 35.671250738512505 139.74451163502417 74.78 35.671250738512505 139.74451163502417 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67126456385148 139.74450929996763 6.84 35.671262967021654 139.74449518446121 6.84 35.671262967021654 139.74449518446121 74.78 35.67126456385148 139.74450929996763 74.78 35.67126456385148 139.74450929996763 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671262967021654 139.74449518446121 74.78 35.671594468611545 139.74443907686512 74.78 35.671560970122755 139.7441418437311 74.78 35.67151724509542 139.7440210114386 74.78 35.67150895350368 139.7440224125236 74.78 35.671505269651476 139.7439896861002 74.78 35.6712400559312 139.7440345758733 74.78 35.67124361403769 139.74406792092773 74.78 35.67123560251729 139.74407019435503 74.78 35.67121753843586 139.7442032791021 74.78 35.671250738512505 139.74451163502417 74.78 35.67126456385148 139.74450929996763 74.78 35.671262967021654 139.74449518446121 74.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2fa92921-c3b8-4126-86df-385c03c5317a"/>
							<gml:surfaceMember xlink:href="#poly-9ea813cd-7250-4a0a-be62-cb40cb4303b0"/>
							<gml:surfaceMember xlink:href="#poly-faaf8ada-5446-4001-8ab9-7fc1d1e8a637"/>
							<gml:surfaceMember xlink:href="#poly-996e46cc-c114-4e28-b2b4-63170af528b4"/>
							<gml:surfaceMember xlink:href="#poly-990f3a88-6c5f-4fee-a558-a43338791b6d"/>
							<gml:surfaceMember xlink:href="#poly-87a9d384-4671-4aea-958d-bd6165c6e51b"/>
							<gml:surfaceMember xlink:href="#poly-3e2e69c7-9091-4b12-b1e9-b6209980752c"/>
							<gml:surfaceMember xlink:href="#poly-40a11e99-76a9-4382-9455-23d7e2f171ac"/>
							<gml:surfaceMember xlink:href="#poly-881811db-59a2-462b-87b1-9b2f80363a32"/>
							<gml:surfaceMember xlink:href="#poly-9e78b0d2-b5dd-49ee-b4e0-24eaabb6c24e"/>
							<gml:surfaceMember xlink:href="#poly-d5af35d8-94a9-4ead-b63b-6a5f949950b7"/>
							<gml:surfaceMember xlink:href="#poly-25fd4421-d575-4877-b424-5532c974e498"/>
							<gml:surfaceMember xlink:href="#poly-b8b5f7a4-79dc-42b2-9098-90c3fd8c34ca"/>
							<gml:surfaceMember xlink:href="#poly-28e97ab9-a0e6-463f-9a5c-dd778515032d"/>
							<gml:surfaceMember xlink:href="#poly-16448ac9-cdc6-4be8-bea4-134a03b9e9a8"/>
							<gml:surfaceMember xlink:href="#poly-29d527f3-5a69-4994-8861-2ce236f0b4a0"/>
							<gml:surfaceMember xlink:href="#poly-3017186e-834f-40fa-9a4e-ee83ab60e810"/>
							<gml:surfaceMember xlink:href="#poly-190b1808-d1d0-45c2-bfa2-bb3538fc28ea"/>
							<gml:surfaceMember xlink:href="#poly-c35baa2e-8674-4af0-8c0f-847c3b22419b"/>
							<gml:surfaceMember xlink:href="#poly-1c291010-5643-45ef-a199-eaa5fcc953b2"/>
							<gml:surfaceMember xlink:href="#poly-60ab669a-e5d9-4959-aac6-bedf66172e0a"/>
							<gml:surfaceMember xlink:href="#poly-62055e0b-768f-444d-92b9-a98d6328f4c5"/>
							<gml:surfaceMember xlink:href="#poly-fe815fbf-d872-4105-9790-418e4c76b137"/>
							<gml:surfaceMember xlink:href="#poly-3ca97a70-0c12-4cc0-8296-9f3ad68d176e"/>
							<gml:surfaceMember xlink:href="#poly-812cea6e-abb2-4103-a071-7a9557cc752c"/>
							<gml:surfaceMember xlink:href="#poly-170da5a8-f6be-4dbb-af7b-5aa74a227638"/>
							<gml:surfaceMember xlink:href="#poly-6618d99f-c6a6-4924-bba9-bea2cf315946"/>
							<gml:surfaceMember xlink:href="#poly-24f3b908-4493-4fc1-aa4b-b2e849c3d7d2"/>
							<gml:surfaceMember xlink:href="#poly-f9547746-795f-4299-b28a-08ad879864f3"/>
							<gml:surfaceMember xlink:href="#poly-59ea2cf7-d14a-453f-afdb-670faec50e2f"/>
							<gml:surfaceMember xlink:href="#poly-27d05dba-fbae-41fa-9f0c-7188edee37d0"/>
							<gml:surfaceMember xlink:href="#poly-a2809dcd-9d4c-4872-9e80-bc5429612d8b"/>
							<gml:surfaceMember xlink:href="#poly-8de225b1-e20e-4271-b00c-01b5aa1a2d1f"/>
							<gml:surfaceMember xlink:href="#poly-dcd30fa3-856c-498e-85dc-287796da59c1"/>
							<gml:surfaceMember xlink:href="#poly-479e50bb-7100-4612-9eb1-7fe7cebb99d4"/>
							<gml:surfaceMember xlink:href="#poly-3e0548fd-a7e3-4127-8de6-5a7896ba9f75"/>
							<gml:surfaceMember xlink:href="#poly-1a5b4483-95b2-4278-a05c-e9f0ecaf909a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2fa92921-c3b8-4126-86df-385c03c5317a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fa92921-c3b8-4126-86df-385c03c5317a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fa92921-c3b8-4126-86df-385c03c5317a">
											<gml:posList>35.671250738512484 139.74451163502417 6.84 35.67121753843586 139.7442032791021 6.84 35.67123560251728 139.744070194355 6.84 35.671243614037685 139.74406792092773 6.84 35.6712400559312 139.7440345758733 6.84 35.67150526965146 139.7439896861002 6.84 35.671508953503654 139.7440224125236 6.84 35.67151724509544 139.7440210114386 6.84 35.67156097012276 139.7441418437311 6.84 35.67159446861157 139.74443907686512 6.84 35.67126296702164 139.7444951844612 6.84 35.67126456385146 139.7445092999676 6.84 35.671250738512484 139.74451163502417 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9ea813cd-7250-4a0a-be62-cb40cb4303b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ea813cd-7250-4a0a-be62-cb40cb4303b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ea813cd-7250-4a0a-be62-cb40cb4303b0">
											<gml:posList>35.671508953503654 139.7440224125236 75.814 35.67150526965146 139.7439896861002 75.814 35.6715001109849 139.7439980429379 75.814 35.67150379484301 139.744030780406 75.814 35.671508953503654 139.7440224125236 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-faaf8ada-5446-4001-8ab9-7fc1d1e8a637">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-faaf8ada-5446-4001-8ab9-7fc1d1e8a637">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-faaf8ada-5446-4001-8ab9-7fc1d1e8a637">
											<gml:posList>35.6712400559312 139.7440345758733 75.814 35.67124683896066 139.7440409199864 75.814 35.6715001109849 139.7439980429379 75.814 35.67150526965146 139.7439896861002 75.814 35.6712400559312 139.7440345758733 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-996e46cc-c114-4e28-b2b4-63170af528b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-996e46cc-c114-4e28-b2b4-63170af528b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-996e46cc-c114-4e28-b2b4-63170af528b4">
											<gml:posList>35.671508953503654 139.7440224125236 75.814 35.67150379484301 139.744030780406 75.814 35.67151357351057 139.74402912359798 75.814 35.67151724509544 139.7440210114386 75.814 35.671508953503654 139.7440224125236 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-990f3a88-6c5f-4fee-a558-a43338791b6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-990f3a88-6c5f-4fee-a558-a43338791b6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-990f3a88-6c5f-4fee-a558-a43338791b6d">
											<gml:posList>35.671243614037685 139.74406792092773 75.814 35.67125032448886 139.7440736354811 75.814 35.67124683896066 139.7440409199864 75.814 35.6712400559312 139.7440345758733 75.814 35.671243614037685 139.74406792092773 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-87a9d384-4671-4aea-958d-bd6165c6e51b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87a9d384-4671-4aea-958d-bd6165c6e51b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87a9d384-4671-4aea-958d-bd6165c6e51b">
											<gml:posList>35.671243614037685 139.74406792092773 75.814 35.67123560251728 139.744070194355 75.814 35.67124091613618 139.74407630813272 75.814 35.67125032448886 139.7440736354811 75.814 35.671243614037685 139.74406792092773 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e2e69c7-9091-4b12-b1e9-b6209980752c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e2e69c7-9091-4b12-b1e9-b6209980752c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e2e69c7-9091-4b12-b1e9-b6209980752c">
											<gml:posList>35.67156097012276 139.7441418437311 75.814 35.67151724509544 139.7440210114386 75.814 35.67151357351057 139.74402912359798 75.814 35.67155510371173 139.74414390489173 75.814 35.67156097012276 139.7441418437311 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-40a11e99-76a9-4382-9455-23d7e2f171ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40a11e99-76a9-4382-9455-23d7e2f171ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40a11e99-76a9-4382-9455-23d7e2f171ac">
											<gml:posList>35.67121753843586 139.7442032791021 75.814 35.67122365886783 139.74420342694728 75.814 35.67124091613618 139.74407630813272 75.814 35.67123560251728 139.744070194355 75.814 35.67121753843586 139.7442032791021 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-881811db-59a2-462b-87b1-9b2f80363a32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-881811db-59a2-462b-87b1-9b2f80363a32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-881811db-59a2-462b-87b1-9b2f80363a32">
											<gml:posList>35.67124091613618 139.74407630813272 74.759 35.67122365886783 139.74420342694728 74.759 35.67125441751394 139.7444890963326 74.759 35.6712621503749 139.74448785056887 74.759 35.671587658578545 139.74443275481366 74.759 35.67155510371173 139.74414390489173 74.759 35.67151357351057 139.74402912359798 74.759 35.67150379484301 139.744030780406 74.759 35.6715001109849 139.7439980429379 74.759 35.67124683896066 139.7440409199864 74.759 35.67125032448886 139.7440736354811 74.759 35.67124091613618 139.74407630813272 74.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e78b0d2-b5dd-49ee-b4e0-24eaabb6c24e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e78b0d2-b5dd-49ee-b4e0-24eaabb6c24e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e78b0d2-b5dd-49ee-b4e0-24eaabb6c24e">
											<gml:posList>35.67156097012276 139.7441418437311 75.814 35.67155510371173 139.74414390489173 75.814 35.671587658578545 139.74443275481366 75.814 35.67159446861157 139.74443907686512 75.814 35.67156097012276 139.7441418437311 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5af35d8-94a9-4ead-b63b-6a5f949950b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5af35d8-94a9-4ead-b63b-6a5f949950b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5af35d8-94a9-4ead-b63b-6a5f949950b7">
											<gml:posList>35.67121753843586 139.7442032791021 75.814 35.671249204697496 139.7444974089865 75.814 35.67125441751394 139.7444890963326 75.814 35.67122365886783 139.74420342694728 75.814 35.67121753843586 139.7442032791021 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-25fd4421-d575-4877-b424-5532c974e498">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25fd4421-d575-4877-b424-5532c974e498">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25fd4421-d575-4877-b424-5532c974e498">
											<gml:posList>35.67126296702164 139.7444951844612 75.814 35.67159446861157 139.74443907686512 75.814 35.671587658578545 139.74443275481366 75.814 35.6712621503749 139.74448785056887 75.814 35.67126296702164 139.7444951844612 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8b5f7a4-79dc-42b2-9098-90c3fd8c34ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8b5f7a4-79dc-42b2-9098-90c3fd8c34ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8b5f7a4-79dc-42b2-9098-90c3fd8c34ca">
											<gml:posList>35.67126296702164 139.7444951844612 75.814 35.6712621503749 139.74448785056887 75.814 35.67125441751394 139.7444890963326 75.814 35.671249204697496 139.7444974089865 75.814 35.67126296702164 139.7444951844612 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28e97ab9-a0e6-463f-9a5c-dd778515032d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28e97ab9-a0e6-463f-9a5c-dd778515032d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28e97ab9-a0e6-463f-9a5c-dd778515032d">
											<gml:posList>35.671250738512484 139.74451163502417 75.814 35.67126456385146 139.7445092999676 75.814 35.67126296702164 139.7444951844612 75.814 35.671249204697496 139.7444974089865 75.814 35.671250738512484 139.74451163502417 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16448ac9-cdc6-4be8-bea4-134a03b9e9a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16448ac9-cdc6-4be8-bea4-134a03b9e9a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16448ac9-cdc6-4be8-bea4-134a03b9e9a8">
											<gml:posList>35.671508953503654 139.7440224125236 6.84 35.67150526965146 139.7439896861002 6.84 35.67150526965146 139.7439896861002 75.814 35.671508953503654 139.7440224125236 75.814 35.671508953503654 139.7440224125236 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29d527f3-5a69-4994-8861-2ce236f0b4a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29d527f3-5a69-4994-8861-2ce236f0b4a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29d527f3-5a69-4994-8861-2ce236f0b4a0">
											<gml:posList>35.67150526965146 139.7439896861002 6.84 35.6712400559312 139.7440345758733 6.84 35.6712400559312 139.7440345758733 75.814 35.67150526965146 139.7439896861002 75.814 35.67150526965146 139.7439896861002 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3017186e-834f-40fa-9a4e-ee83ab60e810">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3017186e-834f-40fa-9a4e-ee83ab60e810">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3017186e-834f-40fa-9a4e-ee83ab60e810">
											<gml:posList>35.6715001109849 139.7439980429379 75.814 35.6715001109849 139.7439980429379 74.759 35.67150379484301 139.744030780406 74.759 35.67150379484301 139.744030780406 75.814 35.6715001109849 139.7439980429379 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-190b1808-d1d0-45c2-bfa2-bb3538fc28ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-190b1808-d1d0-45c2-bfa2-bb3538fc28ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-190b1808-d1d0-45c2-bfa2-bb3538fc28ea">
											<gml:posList>35.67124683896066 139.7440409199864 75.814 35.67124683896066 139.7440409199864 74.759 35.6715001109849 139.7439980429379 74.759 35.6715001109849 139.7439980429379 75.814 35.67124683896066 139.7440409199864 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c35baa2e-8674-4af0-8c0f-847c3b22419b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c35baa2e-8674-4af0-8c0f-847c3b22419b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c35baa2e-8674-4af0-8c0f-847c3b22419b">
											<gml:posList>35.67151724509544 139.7440210114386 6.84 35.671508953503654 139.7440224125236 6.84 35.671508953503654 139.7440224125236 75.814 35.67151724509544 139.7440210114386 75.814 35.67151724509544 139.7440210114386 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c291010-5643-45ef-a199-eaa5fcc953b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c291010-5643-45ef-a199-eaa5fcc953b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c291010-5643-45ef-a199-eaa5fcc953b2">
											<gml:posList>35.67150379484301 139.744030780406 75.814 35.67150379484301 139.744030780406 74.759 35.67151357351057 139.74402912359798 74.759 35.67151357351057 139.74402912359798 75.814 35.67150379484301 139.744030780406 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60ab669a-e5d9-4959-aac6-bedf66172e0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60ab669a-e5d9-4959-aac6-bedf66172e0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60ab669a-e5d9-4959-aac6-bedf66172e0a">
											<gml:posList>35.6712400559312 139.7440345758733 6.84 35.671243614037685 139.74406792092773 6.84 35.671243614037685 139.74406792092773 75.814 35.6712400559312 139.7440345758733 75.814 35.6712400559312 139.7440345758733 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62055e0b-768f-444d-92b9-a98d6328f4c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62055e0b-768f-444d-92b9-a98d6328f4c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62055e0b-768f-444d-92b9-a98d6328f4c5">
											<gml:posList>35.67125032448886 139.7440736354811 75.814 35.67125032448886 139.7440736354811 74.759 35.67124683896066 139.7440409199864 74.759 35.67124683896066 139.7440409199864 75.814 35.67125032448886 139.7440736354811 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe815fbf-d872-4105-9790-418e4c76b137">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe815fbf-d872-4105-9790-418e4c76b137">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe815fbf-d872-4105-9790-418e4c76b137">
											<gml:posList>35.671243614037685 139.74406792092773 6.84 35.67123560251728 139.744070194355 6.84 35.67123560251728 139.744070194355 75.814 35.671243614037685 139.74406792092773 75.814 35.671243614037685 139.74406792092773 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ca97a70-0c12-4cc0-8296-9f3ad68d176e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ca97a70-0c12-4cc0-8296-9f3ad68d176e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ca97a70-0c12-4cc0-8296-9f3ad68d176e">
											<gml:posList>35.67124091613618 139.74407630813272 75.814 35.67124091613618 139.74407630813272 74.759 35.67125032448886 139.7440736354811 74.759 35.67125032448886 139.7440736354811 75.814 35.67124091613618 139.74407630813272 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-812cea6e-abb2-4103-a071-7a9557cc752c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-812cea6e-abb2-4103-a071-7a9557cc752c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-812cea6e-abb2-4103-a071-7a9557cc752c">
											<gml:posList>35.67156097012276 139.7441418437311 6.84 35.67151724509544 139.7440210114386 6.84 35.67151724509544 139.7440210114386 75.814 35.67156097012276 139.7441418437311 75.814 35.67156097012276 139.7441418437311 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-170da5a8-f6be-4dbb-af7b-5aa74a227638">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-170da5a8-f6be-4dbb-af7b-5aa74a227638">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-170da5a8-f6be-4dbb-af7b-5aa74a227638">
											<gml:posList>35.67151357351057 139.74402912359798 75.814 35.67151357351057 139.74402912359798 74.759 35.67155510371173 139.74414390489173 74.759 35.67155510371173 139.74414390489173 75.814 35.67151357351057 139.74402912359798 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6618d99f-c6a6-4924-bba9-bea2cf315946">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6618d99f-c6a6-4924-bba9-bea2cf315946">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6618d99f-c6a6-4924-bba9-bea2cf315946">
											<gml:posList>35.67123560251728 139.744070194355 6.84 35.67121753843586 139.7442032791021 6.84 35.67121753843586 139.7442032791021 75.814 35.67123560251728 139.744070194355 75.814 35.67123560251728 139.744070194355 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24f3b908-4493-4fc1-aa4b-b2e849c3d7d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24f3b908-4493-4fc1-aa4b-b2e849c3d7d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24f3b908-4493-4fc1-aa4b-b2e849c3d7d2">
											<gml:posList>35.67122365886783 139.74420342694728 75.814 35.67122365886783 139.74420342694728 74.759 35.67124091613618 139.74407630813272 74.759 35.67124091613618 139.74407630813272 75.814 35.67122365886783 139.74420342694728 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9547746-795f-4299-b28a-08ad879864f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9547746-795f-4299-b28a-08ad879864f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9547746-795f-4299-b28a-08ad879864f3">
											<gml:posList>35.67155510371173 139.74414390489173 75.814 35.67155510371173 139.74414390489173 74.759 35.671587658578545 139.74443275481366 74.759 35.671587658578545 139.74443275481366 75.814 35.67155510371173 139.74414390489173 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59ea2cf7-d14a-453f-afdb-670faec50e2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59ea2cf7-d14a-453f-afdb-670faec50e2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59ea2cf7-d14a-453f-afdb-670faec50e2f">
											<gml:posList>35.67159446861157 139.74443907686512 6.84 35.67156097012276 139.7441418437311 6.84 35.67156097012276 139.7441418437311 75.814 35.67159446861157 139.74443907686512 75.814 35.67159446861157 139.74443907686512 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27d05dba-fbae-41fa-9f0c-7188edee37d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27d05dba-fbae-41fa-9f0c-7188edee37d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27d05dba-fbae-41fa-9f0c-7188edee37d0">
											<gml:posList>35.67125441751394 139.7444890963326 75.814 35.67125441751394 139.7444890963326 74.759 35.67122365886783 139.74420342694728 74.759 35.67122365886783 139.74420342694728 75.814 35.67125441751394 139.7444890963326 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2809dcd-9d4c-4872-9e80-bc5429612d8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2809dcd-9d4c-4872-9e80-bc5429612d8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2809dcd-9d4c-4872-9e80-bc5429612d8b">
											<gml:posList>35.67121753843586 139.7442032791021 6.84 35.671250738512484 139.74451163502417 6.84 35.671250738512484 139.74451163502417 75.814 35.671249204697496 139.7444974089865 75.814 35.67121753843586 139.7442032791021 75.814 35.67121753843586 139.7442032791021 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8de225b1-e20e-4271-b00c-01b5aa1a2d1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8de225b1-e20e-4271-b00c-01b5aa1a2d1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8de225b1-e20e-4271-b00c-01b5aa1a2d1f">
											<gml:posList>35.671587658578545 139.74443275481366 75.814 35.671587658578545 139.74443275481366 74.759 35.6712621503749 139.74448785056887 74.759 35.6712621503749 139.74448785056887 75.814 35.671587658578545 139.74443275481366 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dcd30fa3-856c-498e-85dc-287796da59c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcd30fa3-856c-498e-85dc-287796da59c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcd30fa3-856c-498e-85dc-287796da59c1">
											<gml:posList>35.67126296702164 139.7444951844612 6.84 35.67159446861157 139.74443907686512 6.84 35.67159446861157 139.74443907686512 75.814 35.67126296702164 139.7444951844612 75.814 35.67126296702164 139.7444951844612 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-479e50bb-7100-4612-9eb1-7fe7cebb99d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-479e50bb-7100-4612-9eb1-7fe7cebb99d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-479e50bb-7100-4612-9eb1-7fe7cebb99d4">
											<gml:posList>35.6712621503749 139.74448785056887 75.814 35.6712621503749 139.74448785056887 74.759 35.67125441751394 139.7444890963326 74.759 35.67125441751394 139.7444890963326 75.814 35.6712621503749 139.74448785056887 75.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e0548fd-a7e3-4127-8de6-5a7896ba9f75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e0548fd-a7e3-4127-8de6-5a7896ba9f75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e0548fd-a7e3-4127-8de6-5a7896ba9f75">
											<gml:posList>35.67126456385146 139.7445092999676 6.84 35.67126296702164 139.7444951844612 6.84 35.67126296702164 139.7444951844612 75.814 35.67126456385146 139.7445092999676 75.814 35.67126456385146 139.7445092999676 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a5b4483-95b2-4278-a05c-e9f0ecaf909a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a5b4483-95b2-4278-a05c-e9f0ecaf909a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a5b4483-95b2-4278-a05c-e9f0ecaf909a">
											<gml:posList>35.671250738512484 139.74451163502417 6.84 35.67126456385146 139.7445092999676 6.84 35.67126456385146 139.7445092999676 75.814 35.671250738512484 139.74451163502417 75.814 35.671250738512484 139.74451163502417 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-2894</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">224</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.42</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>