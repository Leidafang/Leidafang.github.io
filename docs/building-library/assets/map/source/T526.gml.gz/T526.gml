<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9854da81-c42d-46a4-a933-d209d65c761c">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">20.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67181454802478 139.73877166891992 0 35.67181167199718 139.73875936655955 0 35.671846662363414 139.73874671022537 0 35.671832526395406 139.73868624753763 0 35.671740341388066 139.73871861198904 0 35.67175743475789 139.73879171930926 0 35.67181454802478 139.73877166891992 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181454802478 139.73877166891992 10.41 35.67175743475789 139.73879171930926 10.41 35.671740341388066 139.73871861198904 10.41 35.671832526395406 139.73868624753763 10.41 35.671846662363414 139.73874671022537 10.41 35.67181167199718 139.73875936655955 10.41 35.67181454802478 139.73877166891992 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181454802478 139.73877166891992 10.41 35.67181167199718 139.73875936655955 10.41 35.67181167199718 139.73875936655955 30.47 35.67181454802478 139.73877166891992 30.47 35.67181454802478 139.73877166891992 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181167199718 139.73875936655955 10.41 35.671846662363414 139.73874671022537 10.41 35.671846662363414 139.73874671022537 30.47 35.67181167199718 139.73875936655955 30.47 35.67181167199718 139.73875936655955 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671846662363414 139.73874671022537 10.41 35.671832526395406 139.73868624753763 10.41 35.671832526395406 139.73868624753763 30.47 35.671846662363414 139.73874671022537 30.47 35.671846662363414 139.73874671022537 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671832526395406 139.73868624753763 10.41 35.671740341388066 139.73871861198904 10.41 35.671740341388066 139.73871861198904 30.47 35.671832526395406 139.73868624753763 30.47 35.671832526395406 139.73868624753763 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671740341388066 139.73871861198904 10.41 35.67175743475789 139.73879171930926 10.41 35.67175743475789 139.73879171930926 30.47 35.671740341388066 139.73871861198904 30.47 35.671740341388066 139.73871861198904 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67175743475789 139.73879171930926 10.41 35.67181454802478 139.73877166891992 10.41 35.67181454802478 139.73877166891992 30.47 35.67175743475789 139.73879171930926 30.47 35.67175743475789 139.73879171930926 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67181454802478 139.73877166891992 30.47 35.67181167199718 139.73875936655955 30.47 35.671846662363414 139.73874671022537 30.47 35.671832526395406 139.73868624753763 30.47 35.671740341388066 139.73871861198904 30.47 35.67175743475789 139.73879171930926 30.47 35.67181454802478 139.73877166891992 30.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-cc2bc139-5cd1-4de0-9d60-6a7bcd7202c4"/>
							<gml:surfaceMember xlink:href="#poly-bd2ebefa-b04d-4979-9170-29e524fc4765"/>
							<gml:surfaceMember xlink:href="#poly-773f6fe5-58cf-457a-bb5f-25daf83d69e7"/>
							<gml:surfaceMember xlink:href="#poly-1e664aae-636b-44e2-890d-10a61f31757e"/>
							<gml:surfaceMember xlink:href="#poly-cc10b968-fa51-4a49-9f08-e0817a1a362b"/>
							<gml:surfaceMember xlink:href="#poly-608bc5ba-a723-4308-ad49-651c07433744"/>
							<gml:surfaceMember xlink:href="#poly-5c1e1668-0a25-44c3-97f0-52063c61281f"/>
							<gml:surfaceMember xlink:href="#poly-2314fa51-b972-49e1-ae44-c3550306b62b"/>
							<gml:surfaceMember xlink:href="#poly-93560f6b-105c-4120-af20-e709956e5f36"/>
							<gml:surfaceMember xlink:href="#poly-28492da7-1513-4f48-aced-4bbfb96b888c"/>
							<gml:surfaceMember xlink:href="#poly-2cbe1a7d-352d-4d9e-968d-579cd447b2ac"/>
							<gml:surfaceMember xlink:href="#poly-3b602852-b819-40b7-9c18-c5936a662135"/>
							<gml:surfaceMember xlink:href="#poly-9e9ccaf3-0a38-42d1-8fa7-9120d05ca26f"/>
							<gml:surfaceMember xlink:href="#poly-c0e40f6e-e2ba-4110-be72-eaf71eb9d746"/>
							<gml:surfaceMember xlink:href="#poly-d8f095d5-f6e7-4f4d-90cb-b5eff7170e1a"/>
							<gml:surfaceMember xlink:href="#poly-1d199f29-bbb5-468c-b20d-87b7ef971cd7"/>
							<gml:surfaceMember xlink:href="#poly-5d05c7a2-7e23-4d28-9790-73a08233a28a"/>
							<gml:surfaceMember xlink:href="#poly-1f4ed0db-fda9-417e-bb0a-958033f73f37"/>
							<gml:surfaceMember xlink:href="#poly-17b759da-09b2-4f41-b04c-79425da4f6f6"/>
							<gml:surfaceMember xlink:href="#poly-01232f57-b596-4150-b776-c8382d56c45a"/>
							<gml:surfaceMember xlink:href="#poly-fcee5d94-44bb-44f9-8585-229f0c618ec4"/>
							<gml:surfaceMember xlink:href="#poly-8b9405bd-13b3-4b4c-9f4f-2ceb824225fa"/>
							<gml:surfaceMember xlink:href="#poly-a0c857ae-e680-41ae-8141-0b24b5e9f5ac"/>
							<gml:surfaceMember xlink:href="#poly-a21af455-43de-43e0-b0b7-a35bba57db25"/>
							<gml:surfaceMember xlink:href="#poly-781ddbff-c5ef-4b8e-9878-2647df4519e5"/>
							<gml:surfaceMember xlink:href="#poly-c8891e7e-7f9f-400e-92d4-411e7dd1680f"/>
							<gml:surfaceMember xlink:href="#poly-1aa4bc24-5029-42be-b98a-f99337d2dbf1"/>
							<gml:surfaceMember xlink:href="#poly-b59555a2-0919-42f5-a990-e28a168a18fc"/>
							<gml:surfaceMember xlink:href="#poly-ae446a89-36a8-4500-9c78-34399b48edd2"/>
							<gml:surfaceMember xlink:href="#poly-399c0812-f42d-472e-a1ea-a2bff23f5250"/>
							<gml:surfaceMember xlink:href="#poly-2826f12d-c542-480e-8a10-ad6df38f0472"/>
							<gml:surfaceMember xlink:href="#poly-1d9f06cf-4536-4dd6-bbd9-8edfc10c389b"/>
							<gml:surfaceMember xlink:href="#poly-4eb8f792-fcc6-4983-9cf3-4697eabcf84f"/>
							<gml:surfaceMember xlink:href="#poly-94aa2502-cb74-4bfb-8891-7fa0f1622eff"/>
							<gml:surfaceMember xlink:href="#poly-6a09e0dc-fe96-4f45-8982-ff69e1ab1327"/>
							<gml:surfaceMember xlink:href="#poly-703f2ab7-39cd-42e5-8bf5-ddb4ef023ec9"/>
							<gml:surfaceMember xlink:href="#poly-a6354b68-7123-41b5-863a-0d1fb0c16cd2"/>
							<gml:surfaceMember xlink:href="#poly-81d660b5-6d15-4430-b812-0a8a4a71c50e"/>
							<gml:surfaceMember xlink:href="#poly-4f84f2b5-3f46-4fb2-92b1-8dbd14a7f25a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9854da81-c42d-46a4-a933-d209d65c761c_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5f5aae1-eacd-4b7d-8aa1-9636929449cd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671803393510324 139.7387314729788 30.353 35.67179970235512 139.73871422277176 30.353 35.67181034487632 139.73871079685662 30.353 35.67181403604067 139.73872805811223 30.353 35.671803393510324 139.7387314729788 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa86bea3-116e-4f32-ad35-8366a91127dd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67180272712448 139.73875522364392 35.633 35.67180565711339 139.7387673712887 35.633 35.67178723829185 139.73877404297886 35.633 35.67178430829494 139.73876188429014 35.633 35.67180272712448 139.73875522364392 35.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2b8ba72-744f-4416-838d-2f020e3b2d69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2b8ba72-744f-4416-838d-2f020e3b2d69_0">
											<gml:posList>35.67178430829494 139.73876188429014 35.633 35.67178723829185 139.73877404297886 35.633 35.67178723829185 139.73877404297886 36.182 35.67178430829494 139.73876188429014 36.182 35.67178430829494 139.73876188429014 35.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-619c5e22-9420-498c-970c-acd1223309ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-619c5e22-9420-498c-970c-acd1223309ed_0">
											<gml:posList>35.67178430829494 139.73876188429014 35.633 35.67178430829494 139.73876188429014 36.182 35.67180272712448 139.73875522364392 36.182 35.67180272712448 139.73875522364392 35.633 35.67178430829494 139.73876188429014 35.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cb4fb7a-c00a-4ba3-bc51-e02c2ec9a899">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cb4fb7a-c00a-4ba3-bc51-e02c2ec9a899_0">
											<gml:posList>35.67178723829185 139.73877404297886 36.182 35.67180565711339 139.7387673712887 36.182 35.67180272712448 139.73875522364392 36.182 35.67178430829494 139.73876188429014 36.182 35.67178723829185 139.73877404297886 36.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e65ed60a-5f27-4471-ad72-f4304cc57274">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e65ed60a-5f27-4471-ad72-f4304cc57274_0">
											<gml:posList>35.67178723829185 139.73877404297886 35.633 35.67180565711339 139.7387673712887 35.633 35.67180565711339 139.7387673712887 36.182 35.67178723829185 139.73877404297886 36.182 35.67178723829185 139.73877404297886 35.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1aaddb8-f0c6-49fa-a05e-fa3e0b686449">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1aaddb8-f0c6-49fa-a05e-fa3e0b686449_0">
											<gml:posList>35.67179970235512 139.73871422277176 30.353 35.671803393510324 139.7387314729788 30.353 35.671803393510324 139.7387314729788 32.904 35.67179970235512 139.73871422277176 32.904 35.67179970235512 139.73871422277176 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92561db9-f5dc-4867-aa5f-dbfb2c6d6b01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92561db9-f5dc-4867-aa5f-dbfb2c6d6b01_0">
											<gml:posList>35.67180565711339 139.7387673712887 35.633 35.67180272712448 139.73875522364392 35.633 35.67180272712448 139.73875522364392 36.182 35.67180565711339 139.7387673712887 36.182 35.67180565711339 139.7387673712887 35.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea77128a-0afa-4b3f-8534-3e5725135799">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea77128a-0afa-4b3f-8534-3e5725135799_0">
											<gml:posList>35.67181034487632 139.73871079685662 30.353 35.67179970235512 139.73871422277176 30.353 35.67179970235512 139.73871422277176 32.904 35.67181034487632 139.73871079685662 32.904 35.67181034487632 139.73871079685662 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ee3be13-6447-42ed-ab43-d3f59c64b9b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ee3be13-6447-42ed-ab43-d3f59c64b9b1_0">
											<gml:posList>35.671803393510324 139.7387314729788 32.904 35.67181403604067 139.73872805811223 32.904 35.67181034487632 139.73871079685662 32.904 35.67179970235512 139.73871422277176 32.904 35.671803393510324 139.7387314729788 32.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc7d88b1-8ead-45c6-82df-ac3e5d5f8d89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc7d88b1-8ead-45c6-82df-ac3e5d5f8d89_0">
											<gml:posList>35.671803393510324 139.7387314729788 30.353 35.67181403604067 139.73872805811223 30.353 35.67181403604067 139.73872805811223 32.904 35.671803393510324 139.7387314729788 32.904 35.671803393510324 139.7387314729788 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16903a78-7fe7-4551-a710-ed472d7c1a1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16903a78-7fe7-4551-a710-ed472d7c1a1c_0">
											<gml:posList>35.67181403604067 139.73872805811223 30.353 35.67181034487632 139.73871079685662 30.353 35.67181034487632 139.73871079685662 32.904 35.67181403604067 139.73872805811223 32.904 35.67181403604067 139.73872805811223 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9854da81-c42d-46a4-a933-d209d65c761c_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c59b53a6-2faf-4cd1-a4b1-d4df5339a239">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179681088553 139.73873963302944 30.353 35.671798854841555 139.73874835731706 30.353 35.671777182805585 139.73875597179713 30.353 35.671775138841426 139.73874723646523 30.353 35.67179681088553 139.73873963302944 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85fbe8ea-fa18-4ca7-90cf-17f9e12ff2d3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67184961978472 139.73875935493493 10.41 35.671814548024756 139.7387716689199 10.41 35.67181167199715 139.73875936655955 10.41 35.67181177111337 139.73875932225678 10.41 35.671846662363386 139.73874671022534 10.41 35.67184961978472 139.73875935493493 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0be13dbd-cc26-41b8-a665-ae54087c7778">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0be13dbd-cc26-41b8-a665-ae54087c7778_0">
											<gml:posList>35.671775138841426 139.73874723646523 30.353 35.671777182805585 139.73875597179713 30.353 35.671777182805585 139.73875597179713 30.624 35.671775138841426 139.73874723646523 30.624 35.671775138841426 139.73874723646523 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c80bfbd-00e5-48fb-b569-16768ee63d43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c80bfbd-00e5-48fb-b569-16768ee63d43_0">
											<gml:posList>35.671775138841426 139.73874723646523 30.353 35.671775138841426 139.73874723646523 30.624 35.67179681088553 139.73873963302944 30.624 35.67179681088553 139.73873963302944 30.353 35.671775138841426 139.73874723646523 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3c4051c-8dc2-4197-a077-030552e3f70d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3c4051c-8dc2-4197-a077-030552e3f70d_0">
											<gml:posList>35.67179681088553 139.73873963302944 30.624 35.671775138841426 139.73874723646523 30.624 35.671777182805585 139.73875597179713 30.624 35.671798854841555 139.73874835731706 30.624 35.67179681088553 139.73873963302944 30.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88f6a35b-51bf-4be1-a86b-ab1ffaf7a450">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88f6a35b-51bf-4be1-a86b-ab1ffaf7a450_0">
											<gml:posList>35.671777182805585 139.73875597179713 30.353 35.671798854841555 139.73874835731706 30.353 35.671798854841555 139.73874835731706 30.624 35.671777182805585 139.73875597179713 30.624 35.671777182805585 139.73875597179713 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ab1e263-8ce0-4ce3-a880-4c989d803538">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ab1e263-8ce0-4ce3-a880-4c989d803538_0">
											<gml:posList>35.671798854841555 139.73874835731706 30.353 35.67179681088553 139.73873963302944 30.353 35.67179681088553 139.73873963302944 30.624 35.671798854841555 139.73874835731706 30.624 35.671798854841555 139.73874835731706 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c22e164a-f68d-4864-b4bf-7046ba4cf79c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c22e164a-f68d-4864-b4bf-7046ba4cf79c_0">
											<gml:posList>35.671814548024756 139.7387716689199 10.41 35.671814548024756 139.7387716689199 28.337 35.67181167199715 139.73875936655955 28.337 35.67181167199715 139.73875936655955 10.41 35.671814548024756 139.7387716689199 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8116a221-007a-49e8-abac-1ff2a322bc4b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8116a221-007a-49e8-abac-1ff2a322bc4b_0">
											<gml:posList>35.67181177111337 139.73875932225678 10.41 35.67181167199715 139.73875936655955 10.41 35.67181167199715 139.73875936655955 28.337 35.67182346745151 139.73875488987633 28.337 35.67181177111337 139.73875932225678 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1a8179e-420e-4f04-a314-357bbf7efe31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1a8179e-420e-4f04-a314-357bbf7efe31_0">
											<gml:posList>35.671846662363386 139.73874671022534 10.41 35.67181177111337 139.73875932225678 10.41 35.67182346745151 139.73875488987633 28.337 35.671846662363386 139.73874671022534 28.337 35.671846662363386 139.73874671022534 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8494b3af-169e-41e3-ba46-29c329ae0e08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8494b3af-169e-41e3-ba46-29c329ae0e08_0">
											<gml:posList>35.67182346745151 139.73875488987633 28.337 35.67181167199715 139.73875936655955 28.337 35.671814548024756 139.7387716689199 28.337 35.67184961978472 139.73875935493493 28.337 35.671846662363386 139.73874671022534 28.337 35.67182346745151 139.73875488987633 28.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1b0dcfc-de5a-415c-8d68-df972891318f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1b0dcfc-de5a-415c-8d68-df972891318f_0">
											<gml:posList>35.67184961978472 139.73875935493493 10.41 35.67184961978472 139.73875935493493 28.337 35.671814548024756 139.7387716689199 28.337 35.671814548024756 139.7387716689199 10.41 35.67184961978472 139.73875935493493 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26ff399f-bfb5-4b3f-8b55-4526cafda661">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26ff399f-bfb5-4b3f-8b55-4526cafda661_0">
											<gml:posList>35.67184961978472 139.73875935493493 10.41 35.671846662363386 139.73874671022534 10.41 35.671846662363386 139.73874671022534 28.337 35.67184961978472 139.73875935493493 28.337 35.67184961978472 139.73875935493493 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9854da81-c42d-46a4-a933-d209d65c761c_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2945ca1a-364a-43f1-a135-4e7a208bbf4b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6717593612221 139.73878856879952 30.692 35.67178258318638 139.73878040017942 30.692 35.671782755010874 139.7387811179962 30.692 35.67175952402417 139.73878927558027 30.692 35.6717593612221 139.73878856879952 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f81ca98d-55f4-4780-b103-292ee708c057">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671816658394306 139.738738714849 30.353 35.67182493071565 139.7387358109166 30.353 35.671816800039565 139.73870102416993 30.353 35.67174651234496 139.73872569652585 30.353 35.67176077491035 139.73878670028245 30.353 35.67178229375846 139.7387791412252 30.353 35.67178258318638 139.73878040017942 30.353 35.6717593612221 139.73878856879952 30.353 35.671744221384536 139.73872382133322 30.353 35.671817951364865 139.7386979298029 30.353 35.67182726682256 139.7387377854763 30.353 35.671818922408754 139.73874071158656 30.353 35.67182174419109 139.73875280412867 30.353 35.671820086117776 139.7387533805005 30.353 35.671816658394306 139.738738714849 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-481a0471-c698-4f2f-a7d3-80a3b6d0c237">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-481a0471-c698-4f2f-a7d3-80a3b6d0c237_0">
											<gml:posList>35.671744221384536 139.73872382133322 32.603 35.671817951364865 139.7386979298029 32.603 35.671817951364865 139.7386979298029 30.353 35.671744221384536 139.73872382133322 30.353 35.671744221384536 139.73872382133322 32.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01a9e05b-5e97-4ba9-8437-aa204c846b80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01a9e05b-5e97-4ba9-8437-aa204c846b80_0">
											<gml:posList>35.671816800039565 139.73870102416993 30.353 35.671816800039565 139.73870102416993 32.603 35.67174651234496 139.73872569652585 32.603 35.67174651234496 139.73872569652585 30.353 35.671816800039565 139.73870102416993 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37437d4c-3c2e-4f10-8e4c-651b90a3a0ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37437d4c-3c2e-4f10-8e4c-651b90a3a0ce_0">
											<gml:posList>35.671817951364865 139.7386979298029 30.353 35.671817951364865 139.7386979298029 32.603 35.67182726682256 139.7387377854763 32.603 35.67182726682256 139.7387377854763 30.353 35.671817951364865 139.7386979298029 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-723a6d1b-2dc2-4caa-af89-bb3c0bf25ef9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-723a6d1b-2dc2-4caa-af89-bb3c0bf25ef9_0">
											<gml:posList>35.67182493071565 139.7387358109166 32.603 35.671816800039565 139.73870102416993 32.603 35.671816800039565 139.73870102416993 30.353 35.67182493071565 139.7387358109166 30.353 35.67182493071565 139.7387358109166 32.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f43fdf6-28a9-4011-b1e6-07e864e9fdce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f43fdf6-28a9-4011-b1e6-07e864e9fdce_0">
											<gml:posList>35.671816658394306 139.738738714849 30.353 35.671816658394306 139.738738714849 32.603 35.67182493071565 139.7387358109166 32.603 35.67182493071565 139.7387358109166 30.353 35.671816658394306 139.738738714849 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1dcd98a4-c529-4880-8713-66424e917354">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1dcd98a4-c529-4880-8713-66424e917354_0">
											<gml:posList>35.67182726682256 139.7387377854763 30.353 35.67182726682256 139.7387377854763 32.603 35.671818922408754 139.73874071158656 32.603 35.671818922408754 139.73874071158656 30.353 35.67182726682256 139.7387377854763 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27cb22a0-10ac-4b8a-91e9-84d2c3088f69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27cb22a0-10ac-4b8a-91e9-84d2c3088f69_0">
											<gml:posList>35.67182174419109 139.73875280412867 32.603 35.671818922408754 139.73874071158656 32.603 35.67182726682256 139.7387377854763 32.603 35.671817951364865 139.7386979298029 32.603 35.671744221384536 139.73872382133322 32.603 35.67175952402417 139.73878927558027 32.603 35.671782755010874 139.7387811179962 32.603 35.67178229375846 139.7387791412252 32.603 35.67176077491035 139.73878670028245 32.603 35.67174651234496 139.73872569652585 32.603 35.671816800039565 139.73870102416993 32.603 35.67182493071565 139.7387358109166 32.603 35.671816658394306 139.738738714849 32.603 35.671820086117776 139.7387533805005 32.603 35.67182174419109 139.73875280412867 32.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57fea105-2c32-401b-b9a8-abec975a2565">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57fea105-2c32-401b-b9a8-abec975a2565_0">
											<gml:posList>35.671820086117776 139.7387533805005 30.353 35.671820086117776 139.7387533805005 32.603 35.671816658394306 139.738738714849 32.603 35.671816658394306 139.738738714849 30.353 35.671820086117776 139.7387533805005 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a4a7c88-8054-4b66-b28d-67a45343a1f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a4a7c88-8054-4b66-b28d-67a45343a1f9_0">
											<gml:posList>35.671818922408754 139.73874071158656 30.353 35.671818922408754 139.73874071158656 32.603 35.67182174419109 139.73875280412867 32.603 35.67182174419109 139.73875280412867 30.353 35.671818922408754 139.73874071158656 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2020c8f-e8d8-4ff5-8585-587aa37e49b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2020c8f-e8d8-4ff5-8585-587aa37e49b4_0">
											<gml:posList>35.67182174419109 139.73875280412867 30.353 35.67182174419109 139.73875280412867 32.603 35.671820086117776 139.7387533805005 32.603 35.671820086117776 139.7387533805005 30.353 35.67182174419109 139.73875280412867 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da982879-9698-4a75-879f-595eeedce516">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da982879-9698-4a75-879f-595eeedce516_0">
											<gml:posList>35.67174651234496 139.73872569652585 32.603 35.67176077491035 139.73878670028245 32.603 35.67176077491035 139.73878670028245 30.353 35.67174651234496 139.73872569652585 30.353 35.67174651234496 139.73872569652585 32.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a63856b5-6064-4713-9b6f-fc5ae9459c7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a63856b5-6064-4713-9b6f-fc5ae9459c7c_0">
											<gml:posList>35.6717593612221 139.73878856879952 30.692 35.67175952402417 139.73878927558027 30.692 35.67175952402417 139.73878927558027 32.603 35.671744221384536 139.73872382133322 32.603 35.671744221384536 139.73872382133322 30.353 35.6717593612221 139.73878856879952 30.353 35.6717593612221 139.73878856879952 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0540236b-943e-48f0-ad6a-1db990dfceaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0540236b-943e-48f0-ad6a-1db990dfceaf_0">
											<gml:posList>35.67178229375846 139.7387791412252 30.353 35.67178229375846 139.7387791412252 32.603 35.671782755010874 139.7387811179962 32.603 35.671782755010874 139.7387811179962 30.692 35.67178258318638 139.73878040017942 30.692 35.67178258318638 139.73878040017942 30.353 35.67178229375846 139.7387791412252 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcf35d8b-4331-479c-bc4d-d4123d1a9af4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcf35d8b-4331-479c-bc4d-d4123d1a9af4_0">
											<gml:posList>35.67176077491035 139.73878670028245 30.353 35.67176077491035 139.73878670028245 32.603 35.67178229375846 139.7387791412252 32.603 35.67178229375846 139.7387791412252 30.353 35.67176077491035 139.73878670028245 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1fb7fbf-312b-46fe-b503-9b70c122d6d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1fb7fbf-312b-46fe-b503-9b70c122d6d9_0">
											<gml:posList>35.67178258318638 139.73878040017942 30.692 35.6717593612221 139.73878856879952 30.692 35.6717593612221 139.73878856879952 30.353 35.67178258318638 139.73878040017942 30.353 35.67178258318638 139.73878040017942 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73974eaa-5ba0-4d72-abf1-5dd2fb03a7a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73974eaa-5ba0-4d72-abf1-5dd2fb03a7a5_0">
											<gml:posList>35.671782755010874 139.7387811179962 30.692 35.671782755010874 139.7387811179962 32.603 35.67175952402417 139.73878927558027 32.603 35.67175952402417 139.73878927558027 30.692 35.671782755010874 139.7387811179962 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-cc2bc139-5cd1-4de0-9d60-6a7bcd7202c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc2bc139-5cd1-4de0-9d60-6a7bcd7202c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc2bc139-5cd1-4de0-9d60-6a7bcd7202c4">
											<gml:posList>35.6718325263954 139.73868624753763 10.41 35.671846662363386 139.73874671022534 10.41 35.67181167199715 139.73875936655955 10.41 35.671814548024756 139.7387716689199 10.41 35.67175743475787 139.73879171930926 10.41 35.671740341388066 139.73871861198901 10.41 35.6718325263954 139.73868624753763 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd2ebefa-b04d-4979-9170-29e524fc4765">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd2ebefa-b04d-4979-9170-29e524fc4765">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd2ebefa-b04d-4979-9170-29e524fc4765">
											<gml:posList>35.67175743475787 139.73879171930926 30.692 35.67175878450013 139.7387887683157 30.692 35.671742758367046 139.73872026610374 30.692 35.671740341388066 139.73871861198901 30.692 35.67175743475787 139.73879171930926 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-773f6fe5-58cf-457a-bb5f-25daf83d69e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-773f6fe5-58cf-457a-bb5f-25daf83d69e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-773f6fe5-58cf-457a-bb5f-25daf83d69e7">
											<gml:posList>35.67178311680007 139.73878269721226 30.692 35.67178257417265 139.73878040019005 30.692 35.67175878450013 139.7387887683157 30.692 35.67175743475787 139.73879171930926 30.692 35.67178311680007 139.73878269721226 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1e664aae-636b-44e2-890d-10a61f31757e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e664aae-636b-44e2-890d-10a61f31757e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e664aae-636b-44e2-890d-10a61f31757e">
											<gml:posList>35.671740341388066 139.73871861198901 30.692 35.671742758367046 139.73872026610374 30.692 35.6718175516704 139.73869399773588 30.692 35.67181889238783 139.73869103570266 30.692 35.671740341388066 139.73871861198901 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc10b968-fa51-4a49-9f08-e0817a1a362b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc10b968-fa51-4a49-9f08-e0817a1a362b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc10b968-fa51-4a49-9f08-e0817a1a362b">
											<gml:posList>35.67178311680007 139.73878269721226 36.182 35.671784421516875 139.73877980150291 36.182 35.67177924828366 139.7387576705142 36.182 35.671776894444626 139.73875607155537 36.182 35.67178311680007 139.73878269721226 36.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-608bc5ba-a723-4308-ad49-651c07433744">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-608bc5ba-a723-4308-ad49-651c07433744">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-608bc5ba-a723-4308-ad49-651c07433744">
											<gml:posList>35.671742758367046 139.73872026610374 30.353 35.67175878450013 139.7387887683157 30.353 35.67178257417265 139.73878040019005 30.353 35.671776894444626 139.73875607155537 30.353 35.67180671264485 139.7387455974793 30.353 35.67180952536092 139.7387576237517 30.353 35.67182280768858 139.73875264822365 30.353 35.67182118517358 139.73874111763578 30.353 35.671827862066536 139.73873821558587 30.353 35.6718175516704 139.73869399773588 30.353 35.671742758367046 139.73872026610374 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c1e1668-0a25-44c3-97f0-52063c61281f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c1e1668-0a25-44c3-97f0-52063c61281f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c1e1668-0a25-44c3-97f0-52063c61281f">
											<gml:posList>35.671776894444626 139.73875607155537 36.182 35.67177924828366 139.7387576705142 36.182 35.671805398906486 139.73874848215414 36.182 35.67180671264485 139.7387455974793 36.182 35.671776894444626 139.73875607155537 36.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2314fa51-b972-49e1-ae44-c3550306b62b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2314fa51-b972-49e1-ae44-c3550306b62b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2314fa51-b972-49e1-ae44-c3550306b62b">
											<gml:posList>35.67181057215005 139.73877062419595 35.633 35.671805398906486 139.73874848215414 35.633 35.67177924828366 139.7387576705142 35.633 35.671784421516875 139.73877980150291 35.633 35.67181057215005 139.73877062419595 35.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93560f6b-105c-4120-af20-e709956e5f36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93560f6b-105c-4120-af20-e709956e5f36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93560f6b-105c-4120-af20-e709956e5f36">
											<gml:posList>35.67181293501128 139.73877223419169 36.182 35.67181057215005 139.73877062419595 36.182 35.671784421516875 139.73877980150291 36.182 35.67178311680007 139.73878269721226 36.182 35.67181293501128 139.73877223419169 36.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28492da7-1513-4f48-aced-4bbfb96b888c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28492da7-1513-4f48-aced-4bbfb96b888c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28492da7-1513-4f48-aced-4bbfb96b888c">
											<gml:posList>35.67180671264485 139.7387455974793 36.182 35.671805398906486 139.73874848215414 36.182 35.67181057215005 139.73877062419595 36.182 35.67181293501128 139.73877223419169 36.182 35.67180671264485 139.7387455974793 36.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2cbe1a7d-352d-4d9e-968d-579cd447b2ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cbe1a7d-352d-4d9e-968d-579cd447b2ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cbe1a7d-352d-4d9e-968d-579cd447b2ac">
											<gml:posList>35.67181293501128 139.73877223419169 30.692 35.671814548024756 139.7387716689199 30.692 35.67181167199715 139.73875936655955 30.692 35.67180952536092 139.7387576237517 30.692 35.67181293501128 139.73877223419169 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b602852-b819-40b7-9c18-c5936a662135">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b602852-b819-40b7-9c18-c5936a662135">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b602852-b819-40b7-9c18-c5936a662135">
											<gml:posList>35.67181167199715 139.73875936655955 30.692 35.671825017360185 139.73875431363209 30.692 35.67182280768858 139.73875264822365 30.692 35.67180952536092 139.7387576237517 30.692 35.67181167199715 139.73875936655955 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e9ccaf3-0a38-42d1-8fa7-9120d05ca26f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e9ccaf3-0a38-42d1-8fa7-9120d05ca26f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e9ccaf3-0a38-42d1-8fa7-9120d05ca26f">
											<gml:posList>35.67182338575352 139.73874268363647 30.692 35.67182118517358 139.73874111763578 30.692 35.67182280768858 139.73875264822365 30.692 35.671825017360185 139.73875431363209 30.692 35.67182338575352 139.73874268363647 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c0e40f6e-e2ba-4110-be72-eaf71eb9d746">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0e40f6e-e2ba-4110-be72-eaf71eb9d746">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0e40f6e-e2ba-4110-be72-eaf71eb9d746">
											<gml:posList>35.67181889238783 139.73869103570266 30.692 35.6718175516704 139.73869399773588 30.692 35.671827862066536 139.73873821558587 30.692 35.67183024286016 139.73873970404878 30.692 35.67181889238783 139.73869103570266 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d8f095d5-f6e7-4f4d-90cb-b5eff7170e1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8f095d5-f6e7-4f4d-90cb-b5eff7170e1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8f095d5-f6e7-4f4d-90cb-b5eff7170e1a">
											<gml:posList>35.67182338575352 139.73874268363647 30.692 35.67183024286016 139.73873970404878 30.692 35.671827862066536 139.73873821558587 30.692 35.67182118517358 139.73874111763578 30.692 35.67182338575352 139.73874268363647 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d199f29-bbb5-468c-b20d-87b7ef971cd7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d199f29-bbb5-468c-b20d-87b7ef971cd7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d199f29-bbb5-468c-b20d-87b7ef971cd7">
											<gml:posList>35.6718325263954 139.73868624753763 28.337 35.67181889238783 139.73869103570266 30.692 35.67183024286016 139.73873970404878 30.692 35.67184390390213 139.738734904813 28.337 35.6718325263954 139.73868624753763 28.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d05c7a2-7e23-4d28-9790-73a08233a28a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d05c7a2-7e23-4d28-9790-73a08233a28a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d05c7a2-7e23-4d28-9790-73a08233a28a">
											<gml:posList>35.671846662363386 139.73874671022534 28.337 35.67184390390213 139.738734904813 28.337 35.67182338575352 139.73874268363647 30.692 35.671846662363386 139.73874671022534 28.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f4ed0db-fda9-417e-bb0a-958033f73f37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f4ed0db-fda9-417e-bb0a-958033f73f37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f4ed0db-fda9-417e-bb0a-958033f73f37">
											<gml:posList>35.67182338575352 139.73874268363647 30.692 35.671825017360185 139.73875431363209 30.692 35.671846662363386 139.73874671022534 28.337 35.67182338575352 139.73874268363647 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17b759da-09b2-4f41-b04c-79425da4f6f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17b759da-09b2-4f41-b04c-79425da4f6f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17b759da-09b2-4f41-b04c-79425da4f6f6">
											<gml:posList>35.671742758367046 139.73872026610374 30.692 35.671742758367046 139.73872026610374 30.353 35.6718175516704 139.73869399773588 30.353 35.6718175516704 139.73869399773588 30.692 35.671742758367046 139.73872026610374 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01232f57-b596-4150-b776-c8382d56c45a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01232f57-b596-4150-b776-c8382d56c45a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01232f57-b596-4150-b776-c8382d56c45a">
											<gml:posList>35.67181889238783 139.73869103570266 30.692 35.6718325263954 139.73868624753763 28.337 35.6718325263954 139.73868624753763 10.41 35.671740341388066 139.73871861198901 10.41 35.671740341388066 139.73871861198901 30.692 35.67181889238783 139.73869103570266 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcee5d94-44bb-44f9-8585-229f0c618ec4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcee5d94-44bb-44f9-8585-229f0c618ec4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcee5d94-44bb-44f9-8585-229f0c618ec4">
											<gml:posList>35.6718175516704 139.73869399773588 30.692 35.6718175516704 139.73869399773588 30.353 35.671827862066536 139.73873821558587 30.353 35.671827862066536 139.73873821558587 30.692 35.6718175516704 139.73869399773588 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b9405bd-13b3-4b4c-9f4f-2ceb824225fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b9405bd-13b3-4b4c-9f4f-2ceb824225fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b9405bd-13b3-4b4c-9f4f-2ceb824225fa">
											<gml:posList>35.671846662363386 139.73874671022534 10.41 35.6718325263954 139.73868624753763 10.41 35.6718325263954 139.73868624753763 28.337 35.67184390390213 139.738734904813 28.337 35.671846662363386 139.73874671022534 28.337 35.671846662363386 139.73874671022534 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0c857ae-e680-41ae-8141-0b24b5e9f5ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0c857ae-e680-41ae-8141-0b24b5e9f5ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0c857ae-e680-41ae-8141-0b24b5e9f5ac">
											<gml:posList>35.67184390390213 139.738734904813 28.337 35.67183024286016 139.73873970404878 30.692 35.67182338575352 139.73874268363647 30.692 35.67184390390213 139.738734904813 28.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a21af455-43de-43e0-b0b7-a35bba57db25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a21af455-43de-43e0-b0b7-a35bba57db25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a21af455-43de-43e0-b0b7-a35bba57db25">
											<gml:posList>35.671827862066536 139.73873821558587 30.692 35.671827862066536 139.73873821558587 30.353 35.67182118517358 139.73874111763578 30.353 35.67182118517358 139.73874111763578 30.692 35.671827862066536 139.73873821558587 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-781ddbff-c5ef-4b8e-9878-2647df4519e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-781ddbff-c5ef-4b8e-9878-2647df4519e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-781ddbff-c5ef-4b8e-9878-2647df4519e5">
											<gml:posList>35.67182118517358 139.73874111763578 30.692 35.67182118517358 139.73874111763578 30.353 35.67182280768858 139.73875264822365 30.353 35.67182280768858 139.73875264822365 30.692 35.67182118517358 139.73874111763578 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8891e7e-7f9f-400e-92d4-411e7dd1680f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8891e7e-7f9f-400e-92d4-411e7dd1680f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8891e7e-7f9f-400e-92d4-411e7dd1680f">
											<gml:posList>35.671776894444626 139.73875607155537 36.182 35.67180671264485 139.7387455974793 36.182 35.67180671264485 139.7387455974793 30.353 35.671776894444626 139.73875607155537 30.353 35.671776894444626 139.73875607155537 36.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1aa4bc24-5029-42be-b98a-f99337d2dbf1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1aa4bc24-5029-42be-b98a-f99337d2dbf1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1aa4bc24-5029-42be-b98a-f99337d2dbf1">
											<gml:posList>35.67177924828366 139.7387576705142 36.182 35.67177924828366 139.7387576705142 35.633 35.671805398906486 139.73874848215414 35.633 35.671805398906486 139.73874848215414 36.182 35.67177924828366 139.7387576705142 36.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b59555a2-0919-42f5-a990-e28a168a18fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b59555a2-0919-42f5-a990-e28a168a18fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b59555a2-0919-42f5-a990-e28a168a18fc">
											<gml:posList>35.67181167199715 139.73875936655955 10.41 35.671846662363386 139.73874671022534 10.41 35.671846662363386 139.73874671022534 28.337 35.671825017360185 139.73875431363209 30.692 35.67181167199715 139.73875936655955 30.692 35.67181167199715 139.73875936655955 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae446a89-36a8-4500-9c78-34399b48edd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae446a89-36a8-4500-9c78-34399b48edd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae446a89-36a8-4500-9c78-34399b48edd2">
											<gml:posList>35.67175878450013 139.7387887683157 30.692 35.67175878450013 139.7387887683157 30.353 35.671742758367046 139.73872026610374 30.353 35.671742758367046 139.73872026610374 30.692 35.67175878450013 139.7387887683157 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-399c0812-f42d-472e-a1ea-a2bff23f5250">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-399c0812-f42d-472e-a1ea-a2bff23f5250">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-399c0812-f42d-472e-a1ea-a2bff23f5250">
											<gml:posList>35.671740341388066 139.73871861198901 10.41 35.67175743475787 139.73879171930926 10.41 35.67175743475787 139.73879171930926 30.692 35.671740341388066 139.73871861198901 30.692 35.671740341388066 139.73871861198901 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2826f12d-c542-480e-8a10-ad6df38f0472">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2826f12d-c542-480e-8a10-ad6df38f0472">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2826f12d-c542-480e-8a10-ad6df38f0472">
											<gml:posList>35.67182280768858 139.73875264822365 30.692 35.67182280768858 139.73875264822365 30.353 35.67180952536092 139.7387576237517 30.353 35.67180952536092 139.7387576237517 30.692 35.67182280768858 139.73875264822365 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d9f06cf-4536-4dd6-bbd9-8edfc10c389b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d9f06cf-4536-4dd6-bbd9-8edfc10c389b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d9f06cf-4536-4dd6-bbd9-8edfc10c389b">
											<gml:posList>35.67180671264485 139.7387455974793 30.353 35.67180671264485 139.7387455974793 36.182 35.67181293501128 139.73877223419169 36.182 35.67181293501128 139.73877223419169 30.692 35.67180952536092 139.7387576237517 30.692 35.67180952536092 139.7387576237517 30.353 35.67180671264485 139.7387455974793 30.353</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4eb8f792-fcc6-4983-9cf3-4697eabcf84f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4eb8f792-fcc6-4983-9cf3-4697eabcf84f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4eb8f792-fcc6-4983-9cf3-4697eabcf84f">
											<gml:posList>35.671805398906486 139.73874848215414 36.182 35.671805398906486 139.73874848215414 35.633 35.67181057215005 139.73877062419595 35.633 35.67181057215005 139.73877062419595 36.182 35.671805398906486 139.73874848215414 36.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94aa2502-cb74-4bfb-8891-7fa0f1622eff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94aa2502-cb74-4bfb-8891-7fa0f1622eff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94aa2502-cb74-4bfb-8891-7fa0f1622eff">
											<gml:posList>35.671814548024756 139.7387716689199 10.41 35.67181167199715 139.73875936655955 10.41 35.67181167199715 139.73875936655955 30.692 35.671814548024756 139.7387716689199 30.692 35.671814548024756 139.7387716689199 10.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a09e0dc-fe96-4f45-8982-ff69e1ab1327">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a09e0dc-fe96-4f45-8982-ff69e1ab1327">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a09e0dc-fe96-4f45-8982-ff69e1ab1327">
											<gml:posList>35.671784421516875 139.73877980150291 36.182 35.671784421516875 139.73877980150291 35.633 35.67177924828366 139.7387576705142 35.633 35.67177924828366 139.7387576705142 36.182 35.671784421516875 139.73877980150291 36.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-703f2ab7-39cd-42e5-8bf5-ddb4ef023ec9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-703f2ab7-39cd-42e5-8bf5-ddb4ef023ec9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-703f2ab7-39cd-42e5-8bf5-ddb4ef023ec9">
											<gml:posList>35.67178311680007 139.73878269721226 36.182 35.671776894444626 139.73875607155537 36.182 35.671776894444626 139.73875607155537 30.353 35.67178257417265 139.73878040019005 30.353 35.67178257417265 139.73878040019005 30.692 35.67178311680007 139.73878269721226 30.692 35.67178311680007 139.73878269721226 36.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6354b68-7123-41b5-863a-0d1fb0c16cd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6354b68-7123-41b5-863a-0d1fb0c16cd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6354b68-7123-41b5-863a-0d1fb0c16cd2">
											<gml:posList>35.67181057215005 139.73877062419595 36.182 35.67181057215005 139.73877062419595 35.633 35.671784421516875 139.73877980150291 35.633 35.671784421516875 139.73877980150291 36.182 35.67181057215005 139.73877062419595 36.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81d660b5-6d15-4430-b812-0a8a4a71c50e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81d660b5-6d15-4430-b812-0a8a4a71c50e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81d660b5-6d15-4430-b812-0a8a4a71c50e">
											<gml:posList>35.67181293501128 139.73877223419169 30.692 35.67181293501128 139.73877223419169 36.182 35.67178311680007 139.73878269721226 36.182 35.67178311680007 139.73878269721226 30.692 35.67175743475787 139.73879171930926 30.692 35.67175743475787 139.73879171930926 10.41 35.671814548024756 139.7387716689199 10.41 35.671814548024756 139.7387716689199 30.692 35.67181293501128 139.73877223419169 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f84f2b5-3f46-4fb2-92b1-8dbd14a7f25a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f84f2b5-3f46-4fb2-92b1-8dbd14a7f25a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f84f2b5-3f46-4fb2-92b1-8dbd14a7f25a">
											<gml:posList>35.67178257417265 139.73878040019005 30.692 35.67178257417265 139.73878040019005 30.353 35.67175878450013 139.7387887683157 30.353 35.67175878450013 139.7387887683157 30.692 35.67178257417265 139.73878040019005 30.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8752</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">73.2414</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>