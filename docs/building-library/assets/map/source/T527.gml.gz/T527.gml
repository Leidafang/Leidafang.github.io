<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9859574f-bf49-4e17-b471-834973aa38b9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">12.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672138195376526 139.73993865937632 0 35.672145983410054 139.73992726135958 0 35.672158062420586 139.73993967460413 0 35.67219227582713 139.73988971557404 0 35.672126540247476 139.7398220329602 0 35.672084223188556 139.73988316943058 0 35.672138195376526 139.73993865937632 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672138195376526 139.73993865937632 8.064 35.672084223188556 139.73988316943058 8.064 35.672126540247476 139.7398220329602 8.064 35.67219227582713 139.73988971557404 8.064 35.672158062420586 139.73993967460413 8.064 35.672145983410054 139.73992726135958 8.064 35.672138195376526 139.73993865937632 8.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672138195376526 139.73993865937632 8.064 35.672145983410054 139.73992726135958 8.064 35.672145983410054 139.73992726135958 20.7 35.672138195376526 139.73993865937632 20.7 35.672138195376526 139.73993865937632 8.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672145983410054 139.73992726135958 8.064 35.672158062420586 139.73993967460413 8.064 35.672158062420586 139.73993967460413 20.7 35.672145983410054 139.73992726135958 20.7 35.672145983410054 139.73992726135958 8.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672158062420586 139.73993967460413 8.064 35.67219227582713 139.73988971557404 8.064 35.67219227582713 139.73988971557404 20.7 35.672158062420586 139.73993967460413 20.7 35.672158062420586 139.73993967460413 8.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67219227582713 139.73988971557404 8.064 35.672126540247476 139.7398220329602 8.064 35.672126540247476 139.7398220329602 20.7 35.67219227582713 139.73988971557404 20.7 35.67219227582713 139.73988971557404 8.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672126540247476 139.7398220329602 8.064 35.672084223188556 139.73988316943058 8.064 35.672084223188556 139.73988316943058 20.7 35.672126540247476 139.7398220329602 20.7 35.672126540247476 139.7398220329602 8.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672084223188556 139.73988316943058 8.064 35.672138195376526 139.73993865937632 8.064 35.672138195376526 139.73993865937632 20.7 35.672084223188556 139.73988316943058 20.7 35.672084223188556 139.73988316943058 8.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672138195376526 139.73993865937632 20.7 35.672145983410054 139.73992726135958 20.7 35.672158062420586 139.73993967460413 20.7 35.67219227582713 139.73988971557404 20.7 35.672126540247476 139.7398220329602 20.7 35.672084223188556 139.73988316943058 20.7 35.672138195376526 139.73993865937632 20.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c58d9376-b758-4f8a-8143-f0ac84095384"/>
							<gml:surfaceMember xlink:href="#poly-54cc560e-a14a-4da6-aa9f-65a4dca6a356"/>
							<gml:surfaceMember xlink:href="#poly-4026c7e2-1da2-46d0-88e3-11539ddd4aee"/>
							<gml:surfaceMember xlink:href="#poly-d379d98d-2ccf-429d-ae51-4ff8feba008b"/>
							<gml:surfaceMember xlink:href="#poly-f740e1b6-7e9f-4e9c-b9aa-a489b0e03510"/>
							<gml:surfaceMember xlink:href="#poly-be99dcde-1728-43bd-9329-a42004b18121"/>
							<gml:surfaceMember xlink:href="#poly-702ef6b7-642a-4aab-89a2-130b655a243c"/>
							<gml:surfaceMember xlink:href="#poly-38cf0cf8-d5ca-4d10-addc-cff9d1ec8454"/>
							<gml:surfaceMember xlink:href="#poly-28b7cd96-a82d-4301-bdaf-5f7bfc12afab"/>
							<gml:surfaceMember xlink:href="#poly-bbb09d19-1481-4f70-8aba-e8f6588049c7"/>
							<gml:surfaceMember xlink:href="#poly-6bc82ea1-6305-41d7-a907-ca21177294a9"/>
							<gml:surfaceMember xlink:href="#poly-c2dcb3b3-1dee-49ee-b063-b236dfd42cde"/>
							<gml:surfaceMember xlink:href="#poly-a9bdc4a7-bc37-4249-8339-9c24352732cc"/>
							<gml:surfaceMember xlink:href="#poly-d4224e78-937d-4cd6-a9fe-4ff41a5ad68c"/>
							<gml:surfaceMember xlink:href="#poly-a8a76954-ff7a-4abe-a339-a7fd21209286"/>
							<gml:surfaceMember xlink:href="#poly-a7b84116-f458-4cf3-b92d-04a86ffea2e9"/>
							<gml:surfaceMember xlink:href="#poly-504b0e36-7530-4ac9-80c7-a4c1c2322361"/>
							<gml:surfaceMember xlink:href="#poly-ae6c287b-e0e7-4a05-8791-62106b6f6e66"/>
							<gml:surfaceMember xlink:href="#poly-c68aa977-f02b-45ba-b05f-cae22c4ebed7"/>
							<gml:surfaceMember xlink:href="#poly-c0180e64-df25-4c1c-9f69-28304fadb4c7"/>
							<gml:surfaceMember xlink:href="#poly-21d90aeb-3f47-4eab-9d41-3238f4bd16c1"/>
							<gml:surfaceMember xlink:href="#poly-dc1d2479-df3c-46c5-9a68-02625889627d"/>
							<gml:surfaceMember xlink:href="#poly-4f6f813d-b977-4077-98b4-f3c371d0d425"/>
							<gml:surfaceMember xlink:href="#poly-d7d6af2e-66b4-471a-b93c-bef7d7aa2aef"/>
							<gml:surfaceMember xlink:href="#poly-52c627a0-d027-4464-93a4-ccbf38f1ea70"/>
							<gml:surfaceMember xlink:href="#poly-b5e781aa-63f9-4bfe-a40c-f1bb7200a040"/>
							<gml:surfaceMember xlink:href="#poly-7986e5f4-1601-4f15-bf9a-35b58d10f93f"/>
							<gml:surfaceMember xlink:href="#poly-e1e6bcc2-12e5-44d6-8c6a-d6dbcc959647"/>
							<gml:surfaceMember xlink:href="#poly-0b9c2b77-5da0-4949-8781-3ea134cb1754"/>
							<gml:surfaceMember xlink:href="#poly-7e82f66e-c267-49ad-ac1a-3e07873b59e6"/>
							<gml:surfaceMember xlink:href="#poly-ce7af535-7d2f-45d0-89b2-4f6f33f32f96"/>
							<gml:surfaceMember xlink:href="#poly-ccc74774-da83-44cc-bd35-290c6038ceff"/>
							<gml:surfaceMember xlink:href="#poly-14ad3f18-fba8-49c2-8199-661132d615aa"/>
							<gml:surfaceMember xlink:href="#poly-a05d6789-4e75-4ab0-812c-fd09fd9682fd"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9859574f-bf49-4e17-b471-834973aa38b9_BuildingInstallation_1051">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3417debb-519e-4b8f-ad93-7591cd92b134">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3417debb-519e-4b8f-ad93-7591cd92b134_0">
											<gml:posList>35.67214549424408 139.73992413576926 18.731 35.67214703682417 139.7399257246684 18.25 35.67214598341005 139.73992726135958 18.25 35.67214549424408 139.73992413576926 18.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8a59d3e-3b14-492f-959b-950a486b2a92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8a59d3e-3b14-492f-959b-950a486b2a92_0">
											<gml:posList>35.672170780966326 139.7398701993578 20.837 35.672171744319684 139.73986876218893 20.837 35.67218011575662 139.73987739079828 18.25 35.672170780966326 139.7398701993578 20.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6473c398-75f6-4391-8f3d-11983d6c95e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6473c398-75f6-4391-8f3d-11983d6c95e2_0">
											<gml:posList>35.672179143372304 139.73987880588473 18.25 35.672170780966326 139.7398701993578 20.837 35.67218011575662 139.73987739079828 18.25 35.672179143372304 139.73987880588473 18.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f20c130-325f-4cf9-9d58-23fe429bb9fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f20c130-325f-4cf9-9d58-23fe429bb9fa_0">
											<gml:posList>35.672179143372304 139.73987880588473 18.069 35.67218011575662 139.73987739079828 18.25 35.67218011575662 139.73987739079828 18.069 35.672179143372304 139.73987880588473 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccb376dd-fcc9-4768-9376-cae34592b927">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccb376dd-fcc9-4768-9376-cae34592b927_0">
											<gml:posList>35.672179143372304 139.73987880588473 18.069 35.672179143372304 139.73987880588473 18.25 35.67218011575662 139.73987739079828 18.25 35.672179143372304 139.73987880588473 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-424b6074-127b-481e-b0c6-fa49eaff698c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-424b6074-127b-481e-b0c6-fa49eaff698c_0">
											<gml:posList>35.672171744319684 139.73986876218893 20.837 35.67219221282538 139.73988983715907 20.837 35.67218011575662 139.73987739079828 18.25 35.672171744319684 139.73986876218893 20.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-877cf9c0-9937-4b47-b182-180256424824">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-877cf9c0-9937-4b47-b182-180256424824_0">
											<gml:posList>35.67218011575662 139.73987739079828 18.25 35.67219220381167 139.73988983716959 18.069 35.67218011575662 139.73987739079828 18.069 35.67218011575662 139.73987739079828 18.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bbebef9-1c72-4838-a1b5-5f79a9d76d0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7bbebef9-1c72-4838-a1b5-5f79a9d76d0e_0">
											<gml:posList>35.67218011575662 139.73987739079828 18.25 35.67219221282538 139.73988983715907 20.837 35.67219220381167 139.73988983716959 18.069 35.67218011575662 139.73987739079828 18.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05e44fc0-2476-4c5a-a5ce-a0033b581a4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05e44fc0-2476-4c5a-a5ce-a0033b581a4f_0">
											<gml:posList>35.672189968503446 139.7398899612865 20.837 35.67219221282538 139.73988983715907 20.837 35.672171744319684 139.73986876218893 20.837 35.672189968503446 139.7398899612865 20.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9fe3937-e653-45c4-a2c7-58ee5d1ce726">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9fe3937-e653-45c4-a2c7-58ee5d1ce726_0">
											<gml:posList>35.672170780966326 139.7398701993578 20.837 35.672189968503446 139.7398899612865 20.837 35.672171744319684 139.73986876218893 20.837 35.672170780966326 139.7398701993578 20.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d04f8582-3363-407a-a268-88a840581bd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d04f8582-3363-407a-a268-88a840581bd8_0">
											<gml:posList>35.672179143372304 139.73987880588473 18.069 35.672189968503446 139.7398899612865 18.069 35.672179143372304 139.73987880588473 18.25 35.672179143372304 139.73987880588473 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d68aa373-076a-4737-a4f8-7f3dad1425f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d68aa373-076a-4737-a4f8-7f3dad1425f4_0">
											<gml:posList>35.672179143372304 139.73987880588473 18.25 35.672189968503446 139.7398899612865 20.837 35.672170780966326 139.7398701993578 20.837 35.672179143372304 139.73987880588473 18.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e44c264c-4645-4d06-85e0-303c1296b67f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e44c264c-4645-4d06-85e0-303c1296b67f_0">
											<gml:posList>35.672179143372304 139.73987880588473 18.25 35.672189968503446 139.7398899612865 18.069 35.672189968503446 139.7398899612865 20.837 35.672179143372304 139.73987880588473 18.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51d09854-daa3-4f9b-ae25-77d3b3f258b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51d09854-daa3-4f9b-ae25-77d3b3f258b2_0">
											<gml:posList>35.672157861925314 139.73993684693255 18.069 35.672189968503446 139.7398899612865 20.837 35.672189968503446 139.7398899612865 18.069 35.672157861925314 139.73993684693255 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd6ec907-d072-4389-a3d6-7d74d441a978">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd6ec907-d072-4389-a3d6-7d74d441a978_0">
											<gml:posList>35.672157861925314 139.73993684693255 18.069 35.672157861925314 139.73993684693255 20.837 35.672189968503446 139.7398899612865 20.837 35.672157861925314 139.73993684693255 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eae9be4f-6ebd-425a-9634-26afd005062d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eae9be4f-6ebd-425a-9634-26afd005062d_0">
											<gml:posList>35.67219221282538 139.73988983715907 20.837 35.672157861925314 139.73993684693255 20.837 35.6721580714343 139.73993967459361 20.837 35.67219221282538 139.73988983715907 20.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c468599-5670-40eb-86db-e36acc3cf7a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c468599-5670-40eb-86db-e36acc3cf7a3_0">
											<gml:posList>35.67219221282538 139.73988983715907 20.837 35.672189968503446 139.7398899612865 20.837 35.672157861925314 139.73993684693255 20.837 35.67219221282538 139.73988983715907 20.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac7276af-7281-4bee-8a3c-a798b8800e4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac7276af-7281-4bee-8a3c-a798b8800e4c_0">
											<gml:posList>35.6721580714343 139.73993967459361 20.837 35.67219220381167 139.73988983716959 18.069 35.67219221282538 139.73988983715907 20.837 35.6721580714343 139.73993967459361 20.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8622290-505b-4c13-9d53-c8270d81f13c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8622290-505b-4c13-9d53-c8270d81f13c_0">
											<gml:posList>35.6721580714343 139.73993967459361 20.837 35.67215806242058 139.73993967460413 18.069 35.67219220381167 139.73988983716959 18.069 35.6721580714343 139.73993967459361 20.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b08a8f3-5381-4da7-8b7d-a8756518313c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b08a8f3-5381-4da7-8b7d-a8756518313c_0">
											<gml:posList>35.67214598341005 139.73992726135958 18.069 35.67214703682417 139.7399257246684 18.25 35.67214703682417 139.7399257246684 18.069 35.67214598341005 139.73992726135958 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d228b598-641d-4d55-908f-78362becf217">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d228b598-641d-4d55-908f-78362becf217_0">
											<gml:posList>35.67214598341005 139.73992726135958 18.069 35.67214598341005 139.73992726135958 18.25 35.67214703682417 139.7399257246684 18.25 35.67214598341005 139.73992726135958 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2483328-68ca-4130-9453-e94869c015bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2483328-68ca-4130-9453-e94869c015bd_0">
											<gml:posList>35.67213857520202 139.7399170298836 18.731 35.67213857520202 139.7399170298836 20.837 35.67214549424408 139.73992413576926 18.731 35.67213857520202 139.7399170298836 18.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f440b375-8f47-48b7-b9d5-c3d83d76bf82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f440b375-8f47-48b7-b9d5-c3d83d76bf82_0">
											<gml:posList>35.67213857520202 139.7399170298836 20.837 35.672157861925314 139.73993684693255 20.837 35.67214549424408 139.73992413576926 18.731 35.67213857520202 139.7399170298836 20.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a4cbf9b-efa5-4484-b06d-e6407c6db5b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a4cbf9b-efa5-4484-b06d-e6407c6db5b5_0">
											<gml:posList>35.67214703682417 139.7399257246684 18.25 35.672157861925314 139.73993684693255 18.069 35.67214703682417 139.7399257246684 18.069 35.67214703682417 139.7399257246684 18.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22d3a7f7-4fc3-44a9-a134-19624b79134c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22d3a7f7-4fc3-44a9-a134-19624b79134c_0">
											<gml:posList>35.67214549424408 139.73992413576926 18.731 35.672157861925314 139.73993684693255 20.837 35.672157861925314 139.73993684693255 18.069 35.67214549424408 139.73992413576926 18.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e32fc1fc-0688-4303-a410-8846c009d481">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e32fc1fc-0688-4303-a410-8846c009d481_0">
											<gml:posList>35.67214703682417 139.7399257246684 18.25 35.67214549424408 139.73992413576926 18.731 35.672157861925314 139.73993684693255 18.069 35.67214703682417 139.7399257246684 18.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00f06c0b-d35a-4b1d-b467-694cf6faf003">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00f06c0b-d35a-4b1d-b467-694cf6faf003_0">
											<gml:posList>35.672157861925314 139.73993684693255 20.837 35.67213752178802 139.73991856657474 20.837 35.6721580714343 139.73993967459361 20.837 35.672157861925314 139.73993684693255 20.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60aba7b9-2610-4f75-a9f2-ee765e6c7014">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60aba7b9-2610-4f75-a9f2-ee765e6c7014_0">
											<gml:posList>35.672157861925314 139.73993684693255 20.837 35.67213857520202 139.7399170298836 20.837 35.67213752178802 139.73991856657474 20.837 35.672157861925314 139.73993684693255 20.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdf8bcd2-6ca0-4ac2-b6fe-a8422b63329d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdf8bcd2-6ca0-4ac2-b6fe-a8422b63329d_0">
											<gml:posList>35.67213857520202 139.7399170298836 18.731 35.67213752178802 139.73991856657474 18.251 35.67213752178802 139.73991856657474 20.837 35.67213857520202 139.7399170298836 18.731</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23e9cd03-13c3-44aa-911f-cdd2a9b2ded6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23e9cd03-13c3-44aa-911f-cdd2a9b2ded6_0">
											<gml:posList>35.67213857520202 139.7399170298836 20.837 35.67213857520202 139.7399170298836 18.731 35.67213752178802 139.73991856657474 20.837 35.67213857520202 139.7399170298836 20.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2423a1ab-4c45-4457-bbff-b7af5fea9d01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2423a1ab-4c45-4457-bbff-b7af5fea9d01_0">
											<gml:posList>35.67213752178802 139.73991856657474 18.251 35.67213857520202 139.7399170298836 18.731 35.67214549424408 139.73992413576926 18.731 35.67213752178802 139.73991856657474 18.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dd3c860-66d9-4984-ae30-15cab4ce8359">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dd3c860-66d9-4984-ae30-15cab4ce8359_0">
											<gml:posList>35.67214598341005 139.73992726135958 18.25 35.67213752178802 139.73991856657474 18.251 35.67214549424408 139.73992413576926 18.731 35.67214598341005 139.73992726135958 18.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9e513bc-8c8a-4bef-bcd3-1b62f608b285">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9e513bc-8c8a-4bef-bcd3-1b62f608b285_0">
											<gml:posList>35.67213752178802 139.73991856657474 20.837 35.67214598341005 139.73992726135958 18.25 35.6721580714343 139.73993967459361 20.837 35.67213752178802 139.73991856657474 20.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f38ca3c-1b19-4b69-bd9b-16de1d745950">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f38ca3c-1b19-4b69-bd9b-16de1d745950_0">
											<gml:posList>35.6721580714343 139.73993967459361 20.837 35.67214598341005 139.73992726135958 18.25 35.67215806242058 139.73993967460413 18.069 35.6721580714343 139.73993967459361 20.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75f35ae2-1080-4e55-a6cc-f5660beaf19f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75f35ae2-1080-4e55-a6cc-f5660beaf19f_0">
											<gml:posList>35.67213752178802 139.73991856657474 20.837 35.67213752178802 139.73991856657474 18.251 35.67214598341005 139.73992726135958 18.25 35.67213752178802 139.73991856657474 20.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-baa6c37f-ef1e-444b-95e2-e4fed5362bbc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-baa6c37f-ef1e-444b-95e2-e4fed5362bbc_0">
											<gml:posList>35.67215806242058 139.73993967460413 18.069 35.67214598341005 139.73992726135958 18.25 35.67214598341005 139.73992726135958 18.069 35.67215806242058 139.73993967460413 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e05e0283-1eec-4574-9d2b-e884d63425eb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67214598341005 139.73992726135958 18.069 35.67214703682417 139.7399257246684 18.069 35.672157861925314 139.73993684693255 18.069 35.67214598341005 139.73992726135958 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5b6276d-803b-45a5-89eb-3c8969cca728">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67215806242058 139.73993967460413 18.069 35.67214598341005 139.73992726135958 18.069 35.672157861925314 139.73993684693255 18.069 35.67215806242058 139.73993967460413 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b36ae08-5625-4699-bb52-6e8ca94152b1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672179143372304 139.73987880588473 18.069 35.67218011575662 139.73987739079828 18.069 35.672189968503446 139.7398899612865 18.069 35.672179143372304 139.73987880588473 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c488dac-e8dd-4519-9280-adad1c97a84e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67215806242058 139.73993967460413 18.069 35.672157861925314 139.73993684693255 18.069 35.67219220381167 139.73988983716959 18.069 35.67215806242058 139.73993967460413 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2557519a-1086-40a1-9074-f6c80886068d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672189968503446 139.7398899612865 18.069 35.67218011575662 139.73987739079828 18.069 35.67219220381167 139.73988983716959 18.069 35.672189968503446 139.7398899612865 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab99c743-738a-4c6d-9069-d3a539d4f730">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672157861925314 139.73993684693255 18.069 35.672189968503446 139.7398899612865 18.069 35.67219220381167 139.73988983716959 18.069 35.672157861925314 139.73993684693255 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c58d9376-b758-4f8a-8143-f0ac84095384">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c58d9376-b758-4f8a-8143-f0ac84095384">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c58d9376-b758-4f8a-8143-f0ac84095384">
											<gml:posList>35.67219227582712 139.73988971557404 8.064 35.67215806242058 139.73993967460413 8.064 35.67214598341005 139.73992726135958 8.064 35.6721381953765 139.73993865937632 8.064 35.672084223188556 139.73988316943058 8.064 35.672126540247454 139.7398220329602 8.064 35.67219227582712 139.73988971557404 8.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54cc560e-a14a-4da6-aa9f-65a4dca6a356">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54cc560e-a14a-4da6-aa9f-65a4dca6a356">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54cc560e-a14a-4da6-aa9f-65a4dca6a356">
											<gml:posList>35.672102563583465 139.73985666960016 16.848 35.672084223188556 139.73988316943058 16.848 35.67208692044266 139.73988593895675 16.848 35.67210516163579 139.73985937296277 16.848 35.672102563583465 139.73985666960016 16.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4026c7e2-1da2-46d0-88e3-11539ddd4aee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4026c7e2-1da2-46d0-88e3-11539ddd4aee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4026c7e2-1da2-46d0-88e3-11539ddd4aee">
											<gml:posList>35.67210516163579 139.73985937296277 18.069 35.67208692044266 139.73988593895675 18.069 35.6720940920765 139.73989330965662 18.069 35.672112945458196 139.73986578190292 18.069 35.67210516163579 139.73985937296277 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d379d98d-2ccf-429d-ae51-4ff8feba008b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d379d98d-2ccf-429d-ae51-4ff8feba008b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d379d98d-2ccf-429d-ae51-4ff8feba008b">
											<gml:posList>35.6720940920765 139.73989330965662 18.25 35.672129508232345 139.73992973287736 18.25 35.67214128197776 139.73989722035157 22.877 35.6720940920765 139.73989330965662 18.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f740e1b6-7e9f-4e9c-b9aa-a489b0e03510">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f740e1b6-7e9f-4e9c-b9aa-a489b0e03510">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f740e1b6-7e9f-4e9c-b9aa-a489b0e03510">
											<gml:posList>35.67214128197776 139.73989722035157 22.877 35.672112945458196 139.73986578190292 22.877 35.6720940920765 139.73989330965662 18.25 35.67214128197776 139.73989722035157 22.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-be99dcde-1728-43bd-9329-a42004b18121">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be99dcde-1728-43bd-9329-a42004b18121">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be99dcde-1728-43bd-9329-a42004b18121">
											<gml:posList>35.672102563583465 139.73985666960016 20.879 35.67210516163579 139.73985937296277 20.879 35.672112945458196 139.73986578190292 20.879 35.67213614755388 139.73983193046612 20.879 35.672126540247454 139.7398220329602 20.879 35.672102563583465 139.73985666960016 20.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-702ef6b7-642a-4aab-89a2-130b655a243c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-702ef6b7-642a-4aab-89a2-130b655a243c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-702ef6b7-642a-4aab-89a2-130b655a243c">
											<gml:posList>35.672112945458196 139.73986578190292 23.002 35.67211633439395 139.73986549074303 23.002 35.67213645728843 139.73983613882191 23.002 35.67213614755388 139.73983193046612 23.002 35.672112945458196 139.73986578190292 23.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38cf0cf8-d5ca-4d10-addc-cff9d1ec8454">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38cf0cf8-d5ca-4d10-addc-cff9d1ec8454">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38cf0cf8-d5ca-4d10-addc-cff9d1ec8454">
											<gml:posList>35.672112945458196 139.73986578190292 23.002 35.67214128197776 139.73989722035157 23.002 35.672141026241924 139.73989290146733 23.002 35.67211633439395 139.73986549074303 23.002 35.672112945458196 139.73986578190292 23.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28b7cd96-a82d-4301-bdaf-5f7bfc12afab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28b7cd96-a82d-4301-bdaf-5f7bfc12afab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28b7cd96-a82d-4301-bdaf-5f7bfc12afab">
											<gml:posList>35.672129508232345 139.73992973287736 18.25 35.67213752178802 139.73991856657474 18.25 35.67214128197776 139.73989722035157 22.877 35.672129508232345 139.73992973287736 18.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bbb09d19-1481-4f70-8aba-e8f6588049c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbb09d19-1481-4f70-8aba-e8f6588049c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbb09d19-1481-4f70-8aba-e8f6588049c7">
											<gml:posList>35.67213752178802 139.73991856657474 18.25 35.672129508232345 139.73992973287736 18.25 35.6721381953765 139.73993865937632 18.25 35.67214598341005 139.73992726135958 18.25 35.67213752178802 139.73991856657474 18.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6bc82ea1-6305-41d7-a907-ca21177294a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bc82ea1-6305-41d7-a907-ca21177294a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bc82ea1-6305-41d7-a907-ca21177294a9">
											<gml:posList>35.67216179711042 139.7398622342545 22.761 35.67213645728843 139.73983613882191 22.761 35.67211633439395 139.73986549074303 22.761 35.672141026241924 139.73989290146733 22.761 35.67216179711042 139.7398622342545 22.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c2dcb3b3-1dee-49ee-b063-b236dfd42cde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2dcb3b3-1dee-49ee-b063-b236dfd42cde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2dcb3b3-1dee-49ee-b063-b236dfd42cde">
											<gml:posList>35.67213752178802 139.73991856657474 18.25 35.67214598341005 139.73992726135958 18.25 35.67214128197776 139.73989722035157 22.877 35.67213752178802 139.73991856657474 18.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9bdc4a7-bc37-4249-8339-9c24352732cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9bdc4a7-bc37-4249-8339-9c24352732cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9bdc4a7-bc37-4249-8339-9c24352732cc">
											<gml:posList>35.67213614755388 139.73983193046612 23.002 35.67213645728843 139.73983613882191 23.002 35.67216179711042 139.7398622342545 23.002 35.67216522203242 139.73986185468027 23.002 35.67213614755388 139.73983193046612 23.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d4224e78-937d-4cd6-a9fe-4ff41a5ad68c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4224e78-937d-4cd6-a9fe-4ff41a5ad68c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4224e78-937d-4cd6-a9fe-4ff41a5ad68c">
											<gml:posList>35.67216522203242 139.73986185468027 23.002 35.67216179711042 139.7398622342545 23.002 35.672141026241924 139.73989290146733 23.002 35.67214128197776 139.73989722035157 23.002 35.67216522203242 139.73986185468027 23.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a8a76954-ff7a-4abe-a339-a7fd21209286">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8a76954-ff7a-4abe-a339-a7fd21209286">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8a76954-ff7a-4abe-a339-a7fd21209286">
											<gml:posList>35.67214128197776 139.73989722035157 22.877 35.67214598341005 139.73992726135958 18.25 35.672180196785796 139.73987726919228 18.25 35.67216522203242 139.73986185468027 22.877 35.67214128197776 139.73989722035157 22.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7b84116-f458-4cf3-b92d-04a86ffea2e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7b84116-f458-4cf3-b92d-04a86ffea2e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7b84116-f458-4cf3-b92d-04a86ffea2e9">
											<gml:posList>35.67215806242058 139.73993967460413 18.069 35.67219227582712 139.73988971557404 18.069 35.672180196785796 139.73987726919228 18.069 35.67214598341005 139.73992726135958 18.069 35.67215806242058 139.73993967460413 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-504b0e36-7530-4ac9-80c7-a4c1c2322361">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-504b0e36-7530-4ac9-80c7-a4c1c2322361">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-504b0e36-7530-4ac9-80c7-a4c1c2322361">
											<gml:posList>35.67213645728843 139.73983613882191 23.002 35.67213645728843 139.73983613882191 22.761 35.67216179711042 139.7398622342545 22.761 35.67216179711042 139.7398622342545 23.002 35.67213645728843 139.73983613882191 23.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae6c287b-e0e7-4a05-8791-62106b6f6e66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae6c287b-e0e7-4a05-8791-62106b6f6e66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae6c287b-e0e7-4a05-8791-62106b6f6e66">
											<gml:posList>35.672141026241924 139.73989290146733 23.002 35.672141026241924 139.73989290146733 22.761 35.67211633439395 139.73986549074303 22.761 35.67211633439395 139.73986549074303 23.002 35.672141026241924 139.73989290146733 23.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c68aa977-f02b-45ba-b05f-cae22c4ebed7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c68aa977-f02b-45ba-b05f-cae22c4ebed7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c68aa977-f02b-45ba-b05f-cae22c4ebed7">
											<gml:posList>35.67213614755388 139.73983193046612 23.002 35.67213614755388 139.73983193046612 20.879 35.672112945458196 139.73986578190292 20.879 35.672112945458196 139.73986578190292 22.877 35.672112945458196 139.73986578190292 23.002 35.67213614755388 139.73983193046612 23.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0180e64-df25-4c1c-9f69-28304fadb4c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0180e64-df25-4c1c-9f69-28304fadb4c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0180e64-df25-4c1c-9f69-28304fadb4c7">
											<gml:posList>35.67211633439395 139.73986549074303 23.002 35.67211633439395 139.73986549074303 22.761 35.67213645728843 139.73983613882191 22.761 35.67213645728843 139.73983613882191 23.002 35.67211633439395 139.73986549074303 23.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21d90aeb-3f47-4eab-9d41-3238f4bd16c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21d90aeb-3f47-4eab-9d41-3238f4bd16c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21d90aeb-3f47-4eab-9d41-3238f4bd16c1">
											<gml:posList>35.672126540247454 139.7398220329602 20.879 35.672126540247454 139.7398220329602 8.064 35.672084223188556 139.73988316943058 8.064 35.672084223188556 139.73988316943058 16.848 35.672102563583465 139.73985666960016 16.848 35.672102563583465 139.73985666960016 20.879 35.672126540247454 139.7398220329602 20.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc1d2479-df3c-46c5-9a68-02625889627d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc1d2479-df3c-46c5-9a68-02625889627d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc1d2479-df3c-46c5-9a68-02625889627d">
											<gml:posList>35.67216522203242 139.73986185468027 22.877 35.672180196785796 139.73987726919228 18.25 35.672180196785796 139.73987726919228 18.069 35.67219227582712 139.73988971557404 18.069 35.67219227582712 139.73988971557404 8.064 35.672126540247454 139.7398220329602 8.064 35.672126540247454 139.7398220329602 20.879 35.67213614755388 139.73983193046612 20.879 35.67213614755388 139.73983193046612 23.002 35.67216522203242 139.73986185468027 23.002 35.67216522203242 139.73986185468027 22.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f6f813d-b977-4077-98b4-f3c371d0d425">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f6f813d-b977-4077-98b4-f3c371d0d425">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f6f813d-b977-4077-98b4-f3c371d0d425">
											<gml:posList>35.672102563583465 139.73985666960016 16.848 35.67210516163579 139.73985937296277 16.848 35.67210516163579 139.73985937296277 18.069 35.67210516163579 139.73985937296277 20.879 35.672102563583465 139.73985666960016 20.879 35.672102563583465 139.73985666960016 16.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7d6af2e-66b4-471a-b93c-bef7d7aa2aef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7d6af2e-66b4-471a-b93c-bef7d7aa2aef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7d6af2e-66b4-471a-b93c-bef7d7aa2aef">
											<gml:posList>35.67210516163579 139.73985937296277 18.069 35.672112945458196 139.73986578190292 18.069 35.672112945458196 139.73986578190292 20.879 35.67210516163579 139.73985937296277 20.879 35.67210516163579 139.73985937296277 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52c627a0-d027-4464-93a4-ccbf38f1ea70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52c627a0-d027-4464-93a4-ccbf38f1ea70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52c627a0-d027-4464-93a4-ccbf38f1ea70">
											<gml:posList>35.67208692044266 139.73988593895675 16.848 35.67208692044266 139.73988593895675 18.069 35.67210516163579 139.73985937296277 18.069 35.67210516163579 139.73985937296277 16.848 35.67208692044266 139.73988593895675 16.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5e781aa-63f9-4bfe-a40c-f1bb7200a040">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5e781aa-63f9-4bfe-a40c-f1bb7200a040">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5e781aa-63f9-4bfe-a40c-f1bb7200a040">
											<gml:posList>35.67216179711042 139.7398622342545 23.002 35.67216179711042 139.7398622342545 22.761 35.672141026241924 139.73989290146733 22.761 35.672141026241924 139.73989290146733 23.002 35.67216179711042 139.7398622342545 23.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7986e5f4-1601-4f15-bf9a-35b58d10f93f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7986e5f4-1601-4f15-bf9a-35b58d10f93f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7986e5f4-1601-4f15-bf9a-35b58d10f93f">
											<gml:posList>35.6720940920765 139.73989330965662 18.069 35.6720940920765 139.73989330965662 18.25 35.672112945458196 139.73986578190292 22.877 35.672112945458196 139.73986578190292 20.879 35.672112945458196 139.73986578190292 18.069 35.6720940920765 139.73989330965662 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1e6bcc2-12e5-44d6-8c6a-d6dbcc959647">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1e6bcc2-12e5-44d6-8c6a-d6dbcc959647">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1e6bcc2-12e5-44d6-8c6a-d6dbcc959647">
											<gml:posList>35.67216522203242 139.73986185468027 22.877 35.67216522203242 139.73986185468027 23.002 35.67214128197776 139.73989722035157 23.002 35.67214128197776 139.73989722035157 22.877 35.67216522203242 139.73986185468027 22.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b9c2b77-5da0-4949-8781-3ea134cb1754">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b9c2b77-5da0-4949-8781-3ea134cb1754">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b9c2b77-5da0-4949-8781-3ea134cb1754">
											<gml:posList>35.672112945458196 139.73986578190292 22.877 35.67214128197776 139.73989722035157 22.877 35.67214128197776 139.73989722035157 23.002 35.672112945458196 139.73986578190292 22.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e82f66e-c267-49ad-ac1a-3e07873b59e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e82f66e-c267-49ad-ac1a-3e07873b59e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e82f66e-c267-49ad-ac1a-3e07873b59e6">
											<gml:posList>35.672112945458196 139.73986578190292 23.002 35.672112945458196 139.73986578190292 22.877 35.67214128197776 139.73989722035157 23.002 35.672112945458196 139.73986578190292 23.002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce7af535-7d2f-45d0-89b2-4f6f33f32f96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce7af535-7d2f-45d0-89b2-4f6f33f32f96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce7af535-7d2f-45d0-89b2-4f6f33f32f96">
											<gml:posList>35.6721381953765 139.73993865937632 18.069 35.6721381953765 139.73993865937632 8.064 35.67214598341005 139.73992726135958 8.064 35.67214598341005 139.73992726135958 18.069 35.672180196785796 139.73987726919228 18.069 35.672180196785796 139.73987726919228 18.25 35.67214598341005 139.73992726135958 18.25 35.6721381953765 139.73993865937632 18.25 35.6721381953765 139.73993865937632 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccc74774-da83-44cc-bd35-290c6038ceff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccc74774-da83-44cc-bd35-290c6038ceff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccc74774-da83-44cc-bd35-290c6038ceff">
											<gml:posList>35.6721381953765 139.73993865937632 18.069 35.6721381953765 139.73993865937632 18.25 35.672129508232345 139.73992973287736 18.25 35.6720940920765 139.73989330965662 18.25 35.6720940920765 139.73989330965662 18.069 35.67208692044266 139.73988593895675 18.069 35.67208692044266 139.73988593895675 16.848 35.672084223188556 139.73988316943058 16.848 35.672084223188556 139.73988316943058 8.064 35.6721381953765 139.73993865937632 8.064 35.6721381953765 139.73993865937632 18.069</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14ad3f18-fba8-49c2-8199-661132d615aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14ad3f18-fba8-49c2-8199-661132d615aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14ad3f18-fba8-49c2-8199-661132d615aa">
											<gml:posList>35.67215806242058 139.73993967460413 8.064 35.67219227582712 139.73988971557404 8.064 35.67219227582712 139.73988971557404 18.069 35.67215806242058 139.73993967460413 18.069 35.67215806242058 139.73993967460413 8.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a05d6789-4e75-4ab0-812c-fd09fd9682fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a05d6789-4e75-4ab0-812c-fd09fd9682fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a05d6789-4e75-4ab0-812c-fd09fd9682fd">
											<gml:posList>35.67215806242058 139.73993967460413 8.064 35.67215806242058 139.73993967460413 18.069 35.67214598341005 139.73992726135958 18.069 35.67214598341005 139.73992726135958 8.064 35.67215806242058 139.73993967460413 8.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1732</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">63.07385</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>