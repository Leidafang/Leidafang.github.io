<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_99298a00-a77d-4bda-9a49-f64ea44f9ebb">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.8</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67297266236952 139.7389715612298 0 35.67296084225428 139.73899058636653 0 35.67297189215152 139.73900090194948 0 35.67298371226838 139.73898187681166 0 35.67297266236952 139.7389715612298 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67297266236952 139.7389715612298 7.651 35.67298371226838 139.73898187681166 7.651 35.67297189215152 139.73900090194948 7.651 35.67296084225428 139.73899058636653 7.651 35.67297266236952 139.7389715612298 7.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67297266236952 139.7389715612298 7.651 35.67296084225428 139.73899058636653 7.651 35.67296084225428 139.73899058636653 11.41 35.67297266236952 139.7389715612298 11.41 35.67297266236952 139.7389715612298 7.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67296084225428 139.73899058636653 7.651 35.67297189215152 139.73900090194948 7.651 35.67297189215152 139.73900090194948 11.41 35.67296084225428 139.73899058636653 11.41 35.67296084225428 139.73899058636653 7.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67297189215152 139.73900090194948 7.651 35.67298371226838 139.73898187681166 7.651 35.67298371226838 139.73898187681166 11.41 35.67297189215152 139.73900090194948 11.41 35.67297189215152 139.73900090194948 7.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67298371226838 139.73898187681166 7.651 35.67297266236952 139.7389715612298 7.651 35.67297266236952 139.7389715612298 11.41 35.67298371226838 139.73898187681166 11.41 35.67298371226838 139.73898187681166 7.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67297266236952 139.7389715612298 11.41 35.67296084225428 139.73899058636653 11.41 35.67297189215152 139.73900090194948 11.41 35.67298371226838 139.73898187681166 11.41 35.67297266236952 139.7389715612298 11.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-dbb2c24f-dd38-4d87-9e6b-514bc8944fd3"/>
							<gml:surfaceMember xlink:href="#poly-d279846a-d4b0-4d65-a72d-6c9f3968fea7"/>
							<gml:surfaceMember xlink:href="#poly-b54f6465-656b-4910-b581-4cb97c33214f"/>
							<gml:surfaceMember xlink:href="#poly-af5928a1-77e8-46c3-ae4e-a8d645b73c67"/>
							<gml:surfaceMember xlink:href="#poly-a2acd241-7612-4c38-9be4-82bd7a3d1e12"/>
							<gml:surfaceMember xlink:href="#poly-d4ab1d03-6742-476a-be3c-1ce3a24c3a60"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-dbb2c24f-dd38-4d87-9e6b-514bc8944fd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbb2c24f-dd38-4d87-9e6b-514bc8944fd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbb2c24f-dd38-4d87-9e6b-514bc8944fd3">
											<gml:posList>35.672972662369496 139.7389715612298 7.651 35.672983712268355 139.73898187681164 7.651 35.672971892151516 139.73900090194945 7.651 35.67296084225428 139.73899058636653 7.651 35.672972662369496 139.7389715612298 7.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d279846a-d4b0-4d65-a72d-6c9f3968fea7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d279846a-d4b0-4d65-a72d-6c9f3968fea7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d279846a-d4b0-4d65-a72d-6c9f3968fea7">
											<gml:posList>35.67296084225428 139.73899058636653 12.394 35.672971892151516 139.73900090194945 12.394 35.672983712268355 139.73898187681164 12.394 35.672972662369496 139.7389715612298 12.394 35.67296084225428 139.73899058636653 12.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b54f6465-656b-4910-b581-4cb97c33214f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b54f6465-656b-4910-b581-4cb97c33214f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b54f6465-656b-4910-b581-4cb97c33214f">
											<gml:posList>35.672983712268355 139.73898187681164 12.394 35.672983712268355 139.73898187681164 7.651 35.672972662369496 139.7389715612298 7.651 35.672972662369496 139.7389715612298 12.394 35.672983712268355 139.73898187681164 12.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af5928a1-77e8-46c3-ae4e-a8d645b73c67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af5928a1-77e8-46c3-ae4e-a8d645b73c67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af5928a1-77e8-46c3-ae4e-a8d645b73c67">
											<gml:posList>35.672972662369496 139.7389715612298 12.394 35.672972662369496 139.7389715612298 7.651 35.67296084225428 139.73899058636653 7.651 35.67296084225428 139.73899058636653 12.394 35.672972662369496 139.7389715612298 12.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2acd241-7612-4c38-9be4-82bd7a3d1e12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2acd241-7612-4c38-9be4-82bd7a3d1e12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2acd241-7612-4c38-9be4-82bd7a3d1e12">
											<gml:posList>35.672971892151516 139.73900090194945 12.394 35.672971892151516 139.73900090194945 7.651 35.672983712268355 139.73898187681164 7.651 35.672983712268355 139.73898187681164 12.394 35.672971892151516 139.73900090194945 12.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4ab1d03-6742-476a-be3c-1ce3a24c3a60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4ab1d03-6742-476a-be3c-1ce3a24c3a60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4ab1d03-6742-476a-be3c-1ce3a24c3a60">
											<gml:posList>35.67296084225428 139.73899058636653 12.394 35.67296084225428 139.73899058636653 7.651 35.672971892151516 139.73900090194945 7.651 35.672971892151516 139.73900090194945 12.394 35.67296084225428 139.73899058636653 12.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9369</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.13</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>