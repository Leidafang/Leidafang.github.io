<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9a6deecc-480c-477e-a777-1d4f15872171">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">19.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670307646810464 139.7445440842908 0 35.67030685592411 139.7445472333478 0 35.670359258337825 139.74456704753536 0 35.670395459622256 139.74442333977325 0 35.67031724365762 139.74439375627728 0 35.67028184231579 139.74453432589254 0 35.670307646810464 139.7445440842908 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670307646810464 139.7445440842908 7.969 35.67028184231579 139.74453432589254 7.969 35.67031724365762 139.74439375627728 7.969 35.670395459622256 139.74442333977325 7.969 35.670359258337825 139.74456704753536 7.969 35.67030685592411 139.7445472333478 7.969 35.670307646810464 139.7445440842908 7.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670307646810464 139.7445440842908 7.969 35.67030685592411 139.7445472333478 7.969 35.67030685592411 139.7445472333478 27.35 35.670307646810464 139.7445440842908 27.35 35.670307646810464 139.7445440842908 7.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67030685592411 139.7445472333478 7.969 35.670359258337825 139.74456704753536 7.969 35.670359258337825 139.74456704753536 27.35 35.67030685592411 139.7445472333478 27.35 35.67030685592411 139.7445472333478 7.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670359258337825 139.74456704753536 7.969 35.670395459622256 139.74442333977325 7.969 35.670395459622256 139.74442333977325 27.35 35.670359258337825 139.74456704753536 27.35 35.670359258337825 139.74456704753536 7.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670395459622256 139.74442333977325 7.969 35.67031724365762 139.74439375627728 7.969 35.67031724365762 139.74439375627728 27.35 35.670395459622256 139.74442333977325 27.35 35.670395459622256 139.74442333977325 7.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67031724365762 139.74439375627728 7.969 35.67028184231579 139.74453432589254 7.969 35.67028184231579 139.74453432589254 27.35 35.67031724365762 139.74439375627728 27.35 35.67031724365762 139.74439375627728 7.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67028184231579 139.74453432589254 7.969 35.670307646810464 139.7445440842908 7.969 35.670307646810464 139.7445440842908 27.35 35.67028184231579 139.74453432589254 27.35 35.67028184231579 139.74453432589254 7.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670307646810464 139.7445440842908 27.35 35.67030685592411 139.7445472333478 27.35 35.670359258337825 139.74456704753536 27.35 35.670395459622256 139.74442333977325 27.35 35.67031724365762 139.74439375627728 27.35 35.67028184231579 139.74453432589254 27.35 35.670307646810464 139.7445440842908 27.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9346718d-3973-4a3e-b2cb-591ad6b8d4d1"/>
							<gml:surfaceMember xlink:href="#poly-574b15f1-2773-41e5-9d55-dffa7ead333e"/>
							<gml:surfaceMember xlink:href="#poly-e009f7a3-fd5c-4d22-9531-48955a0ef6c4"/>
							<gml:surfaceMember xlink:href="#poly-a11085f1-bcd1-4e6b-962b-8795be41ae58"/>
							<gml:surfaceMember xlink:href="#poly-800eec41-141e-4869-b1ca-e994ac469125"/>
							<gml:surfaceMember xlink:href="#poly-5fb89fe3-5e1f-4bee-ac20-fb6e64a1f394"/>
							<gml:surfaceMember xlink:href="#poly-b19b383f-7344-4f1c-bff0-7a949870e81f"/>
							<gml:surfaceMember xlink:href="#poly-7d298eea-8b9e-4a79-bf7b-f99bd4173c30"/>
							<gml:surfaceMember xlink:href="#poly-849f9672-090c-4088-b565-e7e634302eac"/>
							<gml:surfaceMember xlink:href="#poly-c610a9d9-5fd4-46f8-9912-c9c36144c38b"/>
							<gml:surfaceMember xlink:href="#poly-edebc582-a7f8-468f-a634-e54c3dc42af7"/>
							<gml:surfaceMember xlink:href="#poly-874a0a36-a31b-4f68-84f9-ba3639b17ff2"/>
							<gml:surfaceMember xlink:href="#poly-1a1aad44-093d-49a8-bfc5-8ede6eeeaab0"/>
							<gml:surfaceMember xlink:href="#poly-0fdd7f0f-6e07-4296-9627-10841949f1fe"/>
							<gml:surfaceMember xlink:href="#poly-1fec1ca0-434c-429b-a008-d372d7b96167"/>
							<gml:surfaceMember xlink:href="#poly-8db98ab5-9467-4048-ad07-0afc6c4eb506"/>
							<gml:surfaceMember xlink:href="#poly-887c8339-431f-4ae5-86d1-ba916ff83d89"/>
							<gml:surfaceMember xlink:href="#poly-33f97639-92fa-45a6-9594-a48657f76004"/>
							<gml:surfaceMember xlink:href="#poly-c376f3a3-a345-4ff7-bea1-db1f33d6b73f"/>
							<gml:surfaceMember xlink:href="#poly-3040358f-9688-4c35-9132-f664075bd04e"/>
							<gml:surfaceMember xlink:href="#poly-54ddd252-5252-43a4-adf5-7587f74ca4cf"/>
							<gml:surfaceMember xlink:href="#poly-c6f83b05-1f89-4518-bf5c-8350c4450499"/>
							<gml:surfaceMember xlink:href="#poly-cd67867d-2a79-4e39-a2d4-21e02798ca25"/>
							<gml:surfaceMember xlink:href="#poly-501ecdc5-93ba-4154-b5ff-af6fdf662416"/>
							<gml:surfaceMember xlink:href="#poly-75b0a9d2-a0e8-4929-be0c-17cf6300b075"/>
							<gml:surfaceMember xlink:href="#poly-b11c0710-afc6-4eaf-9aaa-115ea17ab115"/>
							<gml:surfaceMember xlink:href="#poly-6eb8b671-4888-4e17-b835-b29448a582b8"/>
							<gml:surfaceMember xlink:href="#poly-8463472d-40cd-421e-804f-b9264499c1c9"/>
							<gml:surfaceMember xlink:href="#poly-3502cdcc-08f0-4eb2-86ae-c619c8f4fb41"/>
							<gml:surfaceMember xlink:href="#poly-cfeff53d-8272-4ede-ad17-5aa957f62ad4"/>
							<gml:surfaceMember xlink:href="#poly-4a8852e2-c48b-4cc2-9597-181beacc96c4"/>
							<gml:surfaceMember xlink:href="#poly-3721ef09-797a-4ff2-8322-d799ef8efcb0"/>
							<gml:surfaceMember xlink:href="#poly-29a1d055-6594-4523-8397-a548cccbc965"/>
							<gml:surfaceMember xlink:href="#poly-e351e091-e75c-475a-8a90-8ffa55adfc9f"/>
							<gml:surfaceMember xlink:href="#poly-e4cdc12e-f013-4055-abd4-5d9d61805ed7"/>
							<gml:surfaceMember xlink:href="#poly-dad8a46b-3ce7-4919-bf61-a9dcc8c82018"/>
							<gml:surfaceMember xlink:href="#poly-d3829900-36d9-4d0a-9d80-d736db528794"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9a6deecc-480c-477e-a777-1d4f15872171_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb5b1cc5-fcce-454b-873d-0053ad2161eb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033901874461 139.74453748807431 26.845 35.670335596241145 139.74451672490775 26.845 35.670347459621844 139.74446963262588 26.845 35.67037880914283 139.7444815278405 26.845 35.670358003280406 139.74456413271304 26.845 35.670334371705806 139.74455520036528 26.845 35.67033901874461 139.74453748807431 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70941eec-ba7e-49db-a56f-7c76daac6b22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670334371705806 139.74455520036528 27.41 35.670358003280406 139.74456413271304 27.41 35.67037880914283 139.7444815278405 27.41 35.67038054928056 139.7444821886877 27.41 35.670359131876964 139.74456668314886 27.41 35.67033385934062 139.74455712298072 27.41 35.670334371705806 139.74455520036528 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8fe3325-3b6a-4917-985f-de46b384adc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8fe3325-3b6a-4917-985f-de46b384adc8_0">
											<gml:posList>35.670334371705806 139.74455520036528 27.41 35.67033385934062 139.74455712298072 27.41 35.67033385934062 139.74455712298072 30.258 35.67033901874461 139.74453748807431 30.258 35.67033901874461 139.74453748807431 26.845 35.670334371705806 139.74455520036528 26.845 35.670334371705806 139.74455520036528 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4ccf589-d67f-47bb-83f1-828752225132">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4ccf589-d67f-47bb-83f1-828752225132_0">
											<gml:posList>35.67033901874461 139.74453748807431 26.845 35.67033901874461 139.74453748807431 30.258 35.670335596241145 139.74451672490775 30.258 35.670335596241145 139.74451672490775 26.845 35.67033901874461 139.74453748807431 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14b722c0-21dd-48f3-ad5d-4fb8a1faf9ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14b722c0-21dd-48f3-ad5d-4fb8a1faf9ce_0">
											<gml:posList>35.670335596241145 139.74451672490775 26.845 35.670335596241145 139.74451672490775 30.258 35.670347459621844 139.74446963262588 30.258 35.670347459621844 139.74446963262588 26.845 35.670335596241145 139.74451672490775 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5558ccad-8690-425d-83e7-75786c87f387">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5558ccad-8690-425d-83e7-75786c87f387_0">
											<gml:posList>35.670358003280406 139.74456413271304 27.41 35.670334371705806 139.74455520036528 27.41 35.670334371705806 139.74455520036528 26.845 35.670358003280406 139.74456413271304 26.845 35.670358003280406 139.74456413271304 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96fe1ea7-80f4-41c1-841f-e8c9d6ee0396">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96fe1ea7-80f4-41c1-841f-e8c9d6ee0396_0">
											<gml:posList>35.670359131876964 139.74456668314886 27.41 35.670359131876964 139.74456668314886 30.258 35.67033385934062 139.74455712298072 30.258 35.67033385934062 139.74455712298072 27.41 35.670359131876964 139.74456668314886 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a3fd996-4337-4ac3-9ae6-2980ac317379">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a3fd996-4337-4ac3-9ae6-2980ac317379_0">
											<gml:posList>35.670359131876964 139.74456668314886 30.258 35.67038054928056 139.7444821886877 30.258 35.670347459621844 139.74446963262588 30.258 35.670335596241145 139.74451672490775 30.258 35.67033901874461 139.74453748807431 30.258 35.67033385934062 139.74455712298072 30.258 35.670359131876964 139.74456668314886 30.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5f4e9e0-973c-46b5-ba79-e99b33ecf4a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5f4e9e0-973c-46b5-ba79-e99b33ecf4a2_0">
											<gml:posList>35.670347459621844 139.74446963262588 26.845 35.670347459621844 139.74446963262588 30.258 35.67038054928056 139.7444821886877 30.258 35.67038054928056 139.7444821886877 27.41 35.67037880914283 139.7444815278405 27.41 35.67037880914283 139.7444815278405 26.845 35.670347459621844 139.74446963262588 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df9ca122-762e-48df-af63-b8acd35e6378">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df9ca122-762e-48df-af63-b8acd35e6378_0">
											<gml:posList>35.670358003280406 139.74456413271304 26.845 35.67037880914283 139.7444815278405 26.845 35.67037880914283 139.7444815278405 27.41 35.670358003280406 139.74456413271304 27.41 35.670358003280406 139.74456413271304 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-520a906c-b152-409c-a22c-ea2e752e4a31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-520a906c-b152-409c-a22c-ea2e752e4a31_0">
											<gml:posList>35.67038054928056 139.7444821886877 27.41 35.67038054928056 139.7444821886877 30.258 35.670359131876964 139.74456668314886 30.258 35.670359131876964 139.74456668314886 27.41 35.67038054928056 139.7444821886877 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9a6deecc-480c-477e-a777-1d4f15872171_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81d785a4-82b4-41a4-91ca-823eb7e4be1d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670347459621844 139.74446963262588 26.845 35.670335596241145 139.74451672490775 26.845 35.67032458740451 139.74451256161944 26.845 35.67033644176988 139.74446546935343 26.845 35.670347459621844 139.74446963262588 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8aaf0516-8306-4dde-bb7d-7228ddda4be3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6703228419249 139.74452909979223 26.845 35.670333823703515 139.74453324102018 26.845 35.670329186224734 139.7445516933986 26.845 35.670318204446744 139.74454755216834 26.845 35.6703228419249 139.74452909979223 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53f31dfc-f56f-4da6-a646-aed8d4d5e825">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53f31dfc-f56f-4da6-a646-aed8d4d5e825_0">
											<gml:posList>35.67033644176988 139.74446546935343 26.845 35.67033644176988 139.74446546935343 29.294 35.670347459621844 139.74446963262588 29.294 35.670347459621844 139.74446963262588 26.845 35.67033644176988 139.74446546935343 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44e18f43-f3d3-469e-8b0b-9a421f99284d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44e18f43-f3d3-469e-8b0b-9a421f99284d_0">
											<gml:posList>35.67032458740451 139.74451256161944 26.845 35.67032458740451 139.74451256161944 29.294 35.67033644176988 139.74446546935343 29.294 35.67033644176988 139.74446546935343 26.845 35.67032458740451 139.74451256161944 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c376751a-2394-422b-a5e5-c25407a07982">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c376751a-2394-422b-a5e5-c25407a07982_0">
											<gml:posList>35.670347459621844 139.74446963262588 29.294 35.67033644176988 139.74446546935343 29.294 35.67032458740451 139.74451256161944 29.294 35.670335596241145 139.74451672490775 29.294 35.670347459621844 139.74446963262588 29.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd2ff32a-8ad2-4a21-88fd-a372db46e6f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd2ff32a-8ad2-4a21-88fd-a372db46e6f1_0">
											<gml:posList>35.670347459621844 139.74446963262588 26.845 35.670347459621844 139.74446963262588 29.294 35.670335596241145 139.74451672490775 29.294 35.670335596241145 139.74451672490775 26.845 35.670347459621844 139.74446963262588 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8873ebe-0140-4392-9568-263084978ad8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8873ebe-0140-4392-9568-263084978ad8_0">
											<gml:posList>35.67032458740451 139.74451256161944 26.845 35.670335596241145 139.74451672490775 26.845 35.670335596241145 139.74451672490775 29.294 35.67032458740451 139.74451256161944 29.294 35.67032458740451 139.74451256161944 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45066eb0-3576-4d13-b6a0-aa31fdc5a4c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45066eb0-3576-4d13-b6a0-aa31fdc5a4c8_0">
											<gml:posList>35.670333823703515 139.74453324102018 26.845 35.6703228419249 139.74452909979223 26.845 35.6703228419249 139.74452909979223 30.258 35.670333823703515 139.74453324102018 30.258 35.670333823703515 139.74453324102018 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52cc80e4-9ffb-42b4-b3cf-2cc8d7e1bbc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52cc80e4-9ffb-42b4-b3cf-2cc8d7e1bbc7_0">
											<gml:posList>35.6703228419249 139.74452909979223 26.845 35.670318204446744 139.74454755216834 26.845 35.670318204446744 139.74454755216834 30.258 35.6703228419249 139.74452909979223 30.258 35.6703228419249 139.74452909979223 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08e96ccb-31ff-44ba-8c26-9647d8fd4778">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08e96ccb-31ff-44ba-8c26-9647d8fd4778_0">
											<gml:posList>35.670329186224734 139.7445516933986 30.258 35.670333823703515 139.74453324102018 30.258 35.6703228419249 139.74452909979223 30.258 35.670318204446744 139.74454755216834 30.258 35.670329186224734 139.7445516933986 30.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33d83bd7-f50e-40e0-8863-cedfc1356d7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33d83bd7-f50e-40e0-8863-cedfc1356d7e_0">
											<gml:posList>35.670333823703515 139.74453324102018 30.258 35.670329186224734 139.7445516933986 30.258 35.670329186224734 139.7445516933986 26.845 35.670333823703515 139.74453324102018 26.845 35.670333823703515 139.74453324102018 30.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb80a7e8-9d20-4bdd-83c7-817c75b821ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb80a7e8-9d20-4bdd-83c7-817c75b821ff_0">
											<gml:posList>35.670318204446744 139.74454755216834 26.845 35.670329186224734 139.7445516933986 26.845 35.670329186224734 139.7445516933986 30.258 35.670318204446744 139.74454755216834 30.258 35.670318204446744 139.74454755216834 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9346718d-3973-4a3e-b2cb-591ad6b8d4d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9346718d-3973-4a3e-b2cb-591ad6b8d4d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9346718d-3973-4a3e-b2cb-591ad6b8d4d1">
											<gml:posList>35.67030764681048 139.74454408429077 7.969 35.6702818423158 139.74453432589254 7.969 35.6703172436576 139.74439375627728 7.969 35.67039545962224 139.74442333977322 7.969 35.670359258337804 139.74456704753536 7.969 35.67030685592411 139.7445472333478 7.969 35.67030764681048 139.74454408429077 7.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-574b15f1-2773-41e5-9d55-dffa7ead333e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-574b15f1-2773-41e5-9d55-dffa7ead333e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-574b15f1-2773-41e5-9d55-dffa7ead333e">
											<gml:posList>35.670358003280406 139.74456413271304 26.845 35.67038241310604 139.74446724103228 26.845 35.67038251948536 139.74446482178337 26.845 35.670358003280406 139.74456413271304 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e009f7a3-fd5c-4d22-9531-48955a0ef6c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e009f7a3-fd5c-4d22-9531-48955a0ef6c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e009f7a3-fd5c-4d22-9531-48955a0ef6c4">
											<gml:posList>35.67030764681048 139.74454408429077 27.41 35.6703100343151 139.74454254621807 27.41 35.670300828729104 139.74453906579788 27.41 35.67029844122451 139.74454060387052 27.41 35.67030764681048 139.74454408429077 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a11085f1-bcd1-4e6b-962b-8795be41ae58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a11085f1-bcd1-4e6b-962b-8795be41ae58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a11085f1-bcd1-4e6b-962b-8795be41ae58">
											<gml:posList>35.670333842573505 139.74440003422887 23.77 35.6703172436576 139.74439375627728 20.6 35.6702818423158 139.74453432589254 20.6 35.67029844122451 139.74454060387052 23.77 35.670333842573505 139.74440003422887 23.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-800eec41-141e-4869-b1ca-e994ac469125">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-800eec41-141e-4869-b1ca-e994ac469125">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-800eec41-141e-4869-b1ca-e994ac469125">
											<gml:posList>35.67030764681048 139.74454408429077 27.41 35.67030685592411 139.7445472333478 27.41 35.67030924342878 139.74454569527518 27.41 35.6703100343151 139.74454254621807 27.41 35.67030764681048 139.74454408429077 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5fb89fe3-5e1f-4bee-ac20-fb6e64a1f394">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fb89fe3-5e1f-4bee-ac20-fb6e64a1f394">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fb89fe3-5e1f-4bee-ac20-fb6e64a1f394">
											<gml:posList>35.670324977887105 139.74444319072282 26.845 35.670300828729104 139.74453906579788 26.845 35.6703100343151 139.74454254621807 26.845 35.670324977887105 139.74444319072282 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b19b383f-7344-4f1c-bff0-7a949870e81f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b19b383f-7344-4f1c-bff0-7a949870e81f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b19b383f-7344-4f1c-bff0-7a949870e81f">
											<gml:posList>35.67029844122451 139.74454060387052 27.41 35.670300828729104 139.74453906579788 27.41 35.67033510665676 139.744402960084 27.41 35.670333842573505 139.74440003422887 27.41 35.67029844122451 139.74454060387052 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d298eea-8b9e-4a79-bf7b-f99bd4173c30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d298eea-8b9e-4a79-bf7b-f99bd4173c30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d298eea-8b9e-4a79-bf7b-f99bd4173c30">
											<gml:posList>35.6703100343151 139.74454254621807 26.845 35.67034199293101 139.74448814116124 26.845 35.67033060401637 139.74444530536593 26.845 35.670324977887105 139.74444319072282 26.845 35.6703100343151 139.74454254621807 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-849f9672-090c-4088-b565-e7e634302eac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-849f9672-090c-4088-b565-e7e634302eac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-849f9672-090c-4088-b565-e7e634302eac">
											<gml:posList>35.67033510665676 139.744402960084 26.845 35.670324977887105 139.74444319072282 26.845 35.67033060401637 139.74444530536593 26.845 35.67034004756424 139.74440483246693 26.845 35.67033510665676 139.744402960084 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c610a9d9-5fd4-46f8-9912-c9c36144c38b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c610a9d9-5fd4-46f8-9912-c9c36144c38b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c610a9d9-5fd4-46f8-9912-c9c36144c38b">
											<gml:posList>35.670359258337804 139.74456704753536 27.41 35.670358003280406 139.74456413271304 27.41 35.67030924342878 139.74454569527518 27.41 35.67030685592411 139.7445472333478 27.41 35.670359258337804 139.74456704753536 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-edebc582-a7f8-468f-a634-e54c3dc42af7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edebc582-a7f8-468f-a634-e54c3dc42af7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edebc582-a7f8-468f-a634-e54c3dc42af7">
											<gml:posList>35.670358003280406 139.74456413271304 26.845 35.6703100343151 139.74454254621807 26.845 35.67030924342878 139.74454569527518 26.845 35.670358003280406 139.74456413271304 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-874a0a36-a31b-4f68-84f9-ba3639b17ff2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-874a0a36-a31b-4f68-84f9-ba3639b17ff2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-874a0a36-a31b-4f68-84f9-ba3639b17ff2">
											<gml:posList>35.67034056869598 139.74440257845302 27.41 35.670333842573505 139.74440003422887 27.41 35.67033510665676 139.744402960084 27.41 35.67034004756424 139.74440483246693 27.41 35.67034056869598 139.74440257845302 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a1aad44-093d-49a8-bfc5-8ede6eeeaab0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a1aad44-093d-49a8-bfc5-8ede6eeeaab0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a1aad44-093d-49a8-bfc5-8ede6eeeaab0">
											<gml:posList>35.67034004756424 139.74440483246693 27.41 35.67033060401637 139.74444530536593 27.41 35.67036053791232 139.74445656145483 31.248 35.67034004756424 139.74440483246693 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0fdd7f0f-6e07-4296-9627-10841949f1fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fdd7f0f-6e07-4296-9627-10841949f1fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fdd7f0f-6e07-4296-9627-10841949f1fe">
											<gml:posList>35.67036053791232 139.74445656145483 26.845 35.67033060401637 139.74444530536593 26.845 35.67034199293101 139.74448814116124 26.845 35.67036053791232 139.74445656145483 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1fec1ca0-434c-429b-a008-d372d7b96167">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1fec1ca0-434c-429b-a008-d372d7b96167">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1fec1ca0-434c-429b-a008-d372d7b96167">
											<gml:posList>35.670358003280406 139.74456413271304 26.845 35.67038251948536 139.74446482178337 26.845 35.6703100343151 139.74454254621807 26.845 35.670358003280406 139.74456413271304 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8db98ab5-9467-4048-ad07-0afc6c4eb506">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8db98ab5-9467-4048-ad07-0afc6c4eb506">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8db98ab5-9467-4048-ad07-0afc6c4eb506">
											<gml:posList>35.67034199293101 139.74448814116124 26.845 35.6703100343151 139.74454254621807 26.845 35.67038251948536 139.74446482178337 26.845 35.67036053791232 139.74445656145483 26.845 35.67034199293101 139.74448814116124 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-887c8339-431f-4ae5-86d1-ba916ff83d89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-887c8339-431f-4ae5-86d1-ba916ff83d89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-887c8339-431f-4ae5-86d1-ba916ff83d89">
											<gml:posList>35.67034004756424 139.74440483246693 27.41 35.67036053791232 139.74445656145483 31.248 35.6703712149329 139.74441417617138 31.248 35.67034004756424 139.74440483246693 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-33f97639-92fa-45a6-9594-a48657f76004">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33f97639-92fa-45a6-9594-a48657f76004">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33f97639-92fa-45a6-9594-a48657f76004">
											<gml:posList>35.67034004756424 139.74440483246693 27.41 35.6703712149329 139.74441417617138 31.248 35.67034056869598 139.74440257845302 27.41 35.67034004756424 139.74440483246693 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c376f3a3-a345-4ff7-bea1-db1f33d6b73f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c376f3a3-a345-4ff7-bea1-db1f33d6b73f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c376f3a3-a345-4ff7-bea1-db1f33d6b73f">
											<gml:posList>35.67038479157962 139.7444656808733 27.41 35.67038241310604 139.74446724103228 27.41 35.670358003280406 139.74456413271304 27.41 35.670359258337804 139.74456704753536 27.41 35.67038479157962 139.7444656808733 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3040358f-9688-4c35-9132-f664075bd04e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3040358f-9688-4c35-9132-f664075bd04e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3040358f-9688-4c35-9132-f664075bd04e">
											<gml:posList>35.67039545962224 139.74442333977322 31.248 35.6703712149329 139.74441417617138 31.248 35.67036053791232 139.74445656145483 31.248 35.67038479157962 139.7444656808733 31.248 35.67039545962224 139.74442333977322 31.248</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54ddd252-5252-43a4-adf5-7587f74ca4cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54ddd252-5252-43a4-adf5-7587f74ca4cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54ddd252-5252-43a4-adf5-7587f74ca4cf">
											<gml:posList>35.67038241310604 139.74446724103228 27.41 35.67038479157962 139.7444656808733 27.41 35.67038251948536 139.74446482178337 27.41 35.67038241310604 139.74446724103228 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6f83b05-1f89-4518-bf5c-8350c4450499">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6f83b05-1f89-4518-bf5c-8350c4450499">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6f83b05-1f89-4518-bf5c-8350c4450499">
											<gml:posList>35.67034004756424 139.74440483246693 26.845 35.67033060401637 139.74444530536593 26.845 35.67033060401637 139.74444530536593 27.41 35.67034004756424 139.74440483246693 27.41 35.67034004756424 139.74440483246693 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd67867d-2a79-4e39-a2d4-21e02798ca25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd67867d-2a79-4e39-a2d4-21e02798ca25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd67867d-2a79-4e39-a2d4-21e02798ca25">
											<gml:posList>35.67034004756424 139.74440483246693 26.845 35.67034004756424 139.74440483246693 27.41 35.67033510665676 139.744402960084 27.41 35.67033510665676 139.744402960084 26.845 35.67034004756424 139.74440483246693 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-501ecdc5-93ba-4154-b5ff-af6fdf662416">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-501ecdc5-93ba-4154-b5ff-af6fdf662416">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-501ecdc5-93ba-4154-b5ff-af6fdf662416">
											<gml:posList>35.670333842573505 139.74440003422887 23.77 35.670333842573505 139.74440003422887 27.41 35.67034056869598 139.74440257845302 27.41 35.6703712149329 139.74441417617138 31.248 35.67039545962224 139.74442333977322 31.248 35.67039545962224 139.74442333977322 7.969 35.6703172436576 139.74439375627728 7.969 35.6703172436576 139.74439375627728 20.6 35.670333842573505 139.74440003422887 23.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75b0a9d2-a0e8-4929-be0c-17cf6300b075">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75b0a9d2-a0e8-4929-be0c-17cf6300b075">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75b0a9d2-a0e8-4929-be0c-17cf6300b075">
											<gml:posList>35.67038251948536 139.74446482178337 27.41 35.67038479157962 139.7444656808733 27.41 35.67038479157962 139.7444656808733 31.248 35.67036053791232 139.74445656145483 31.248 35.67033060401637 139.74444530536593 27.41 35.67033060401637 139.74444530536593 26.845 35.67036053791232 139.74445656145483 26.845 35.67038251948536 139.74446482178337 26.845 35.67038251948536 139.74446482178337 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b11c0710-afc6-4eaf-9aaa-115ea17ab115">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b11c0710-afc6-4eaf-9aaa-115ea17ab115">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b11c0710-afc6-4eaf-9aaa-115ea17ab115">
											<gml:posList>35.6702818423158 139.74453432589254 20.6 35.6703172436576 139.74439375627728 20.6 35.6703172436576 139.74439375627728 7.969 35.6702818423158 139.74453432589254 7.969 35.6702818423158 139.74453432589254 20.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6eb8b671-4888-4e17-b835-b29448a582b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6eb8b671-4888-4e17-b835-b29448a582b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6eb8b671-4888-4e17-b835-b29448a582b8">
											<gml:posList>35.67038241310604 139.74446724103228 26.845 35.67038241310604 139.74446724103228 27.41 35.67038251948536 139.74446482178337 27.41 35.67038251948536 139.74446482178337 26.845 35.67038241310604 139.74446724103228 26.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8463472d-40cd-421e-804f-b9264499c1c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8463472d-40cd-421e-804f-b9264499c1c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8463472d-40cd-421e-804f-b9264499c1c9">
											<gml:posList>35.67029844122451 139.74454060387052 23.77 35.67029844122451 139.74454060387052 27.41 35.670333842573505 139.74440003422887 27.41 35.670333842573505 139.74440003422887 23.77 35.67029844122451 139.74454060387052 23.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3502cdcc-08f0-4eb2-86ae-c619c8f4fb41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3502cdcc-08f0-4eb2-86ae-c619c8f4fb41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3502cdcc-08f0-4eb2-86ae-c619c8f4fb41">
											<gml:posList>35.670300828729104 139.74453906579788 27.41 35.670300828729104 139.74453906579788 26.845 35.670324977887105 139.74444319072282 26.845 35.67033510665676 139.744402960084 26.845 35.67033510665676 139.744402960084 27.41 35.670300828729104 139.74453906579788 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfeff53d-8272-4ede-ad17-5aa957f62ad4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfeff53d-8272-4ede-ad17-5aa957f62ad4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfeff53d-8272-4ede-ad17-5aa957f62ad4">
											<gml:posList>35.67039545962224 139.74442333977322 7.969 35.67039545962224 139.74442333977322 31.248 35.67038479157962 139.7444656808733 31.248 35.67038479157962 139.7444656808733 27.41 35.670359258337804 139.74456704753536 27.41 35.670359258337804 139.74456704753536 7.969 35.67039545962224 139.74442333977322 7.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a8852e2-c48b-4cc2-9597-181beacc96c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a8852e2-c48b-4cc2-9597-181beacc96c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a8852e2-c48b-4cc2-9597-181beacc96c4">
											<gml:posList>35.67038241310604 139.74446724103228 27.41 35.67038241310604 139.74446724103228 26.845 35.670358003280406 139.74456413271304 26.845 35.670358003280406 139.74456413271304 27.41 35.67038241310604 139.74446724103228 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3721ef09-797a-4ff2-8322-d799ef8efcb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3721ef09-797a-4ff2-8322-d799ef8efcb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3721ef09-797a-4ff2-8322-d799ef8efcb0">
											<gml:posList>35.67030764681048 139.74454408429077 7.969 35.67030764681048 139.74454408429077 27.41 35.67029844122451 139.74454060387052 27.41 35.67029844122451 139.74454060387052 23.77 35.6702818423158 139.74453432589254 20.6 35.6702818423158 139.74453432589254 7.969 35.67030764681048 139.74454408429077 7.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29a1d055-6594-4523-8397-a548cccbc965">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29a1d055-6594-4523-8397-a548cccbc965">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29a1d055-6594-4523-8397-a548cccbc965">
											<gml:posList>35.6703100343151 139.74454254621807 27.41 35.6703100343151 139.74454254621807 26.845 35.670300828729104 139.74453906579788 26.845 35.670300828729104 139.74453906579788 27.41 35.6703100343151 139.74454254621807 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e351e091-e75c-475a-8a90-8ffa55adfc9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e351e091-e75c-475a-8a90-8ffa55adfc9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e351e091-e75c-475a-8a90-8ffa55adfc9f">
											<gml:posList>35.67030924342878 139.74454569527518 27.41 35.67030924342878 139.74454569527518 26.845 35.6703100343151 139.74454254621807 26.845 35.6703100343151 139.74454254621807 27.41 35.67030924342878 139.74454569527518 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4cdc12e-f013-4055-abd4-5d9d61805ed7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4cdc12e-f013-4055-abd4-5d9d61805ed7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4cdc12e-f013-4055-abd4-5d9d61805ed7">
											<gml:posList>35.67030764681048 139.74454408429077 7.969 35.67030685592411 139.7445472333478 7.969 35.67030685592411 139.7445472333478 27.41 35.67030764681048 139.74454408429077 27.41 35.67030764681048 139.74454408429077 7.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dad8a46b-3ce7-4919-bf61-a9dcc8c82018">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dad8a46b-3ce7-4919-bf61-a9dcc8c82018">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dad8a46b-3ce7-4919-bf61-a9dcc8c82018">
											<gml:posList>35.670358003280406 139.74456413271304 27.41 35.670358003280406 139.74456413271304 26.845 35.67030924342878 139.74454569527518 26.845 35.67030924342878 139.74454569527518 27.41 35.670358003280406 139.74456413271304 27.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3829900-36d9-4d0a-9d80-d736db528794">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3829900-36d9-4d0a-9d80-d736db528794">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3829900-36d9-4d0a-9d80-d736db528794">
											<gml:posList>35.67030685592411 139.7445472333478 7.969 35.670359258337804 139.74456704753536 7.969 35.670359258337804 139.74456704753536 27.41 35.67030685592411 139.7445472333478 27.41 35.67030685592411 139.7445472333478 7.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4096</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">116.14273</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>