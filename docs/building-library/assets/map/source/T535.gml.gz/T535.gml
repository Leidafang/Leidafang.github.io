<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9b11b91c-ead3-4d7c-9336-da2dd1e56c17">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">24.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671635184493425 139.7396836419419 0 35.6716404961448 139.73967535091268 0 35.67165195224743 139.73968649442875 0 35.67171290181663 139.73959219707794 0 35.67169991225481 139.73957961932274 0 35.67170639439236 139.73956966994479 0 35.671593457231545 139.7394602214744 0 35.671589315828626 139.7394665227862 0 35.671567846896465 139.73944567018233 0 35.67150392661243 139.73954472090696 0 35.6715216068402 139.73956182217015 0 35.671516925296764 139.7395690078161 0 35.671635184493425 139.7396836419419 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671635184493425 139.7396836419419 9.57 35.671516925296764 139.7395690078161 9.57 35.6715216068402 139.73956182217015 9.57 35.67150392661243 139.73954472090696 9.57 35.671567846896465 139.73944567018233 9.57 35.671589315828626 139.7394665227862 9.57 35.671593457231545 139.7394602214744 9.57 35.67170639439236 139.73956966994479 9.57 35.67169991225481 139.73957961932274 9.57 35.67171290181663 139.73959219707794 9.57 35.67165195224743 139.73968649442875 9.57 35.6716404961448 139.73967535091268 9.57 35.671635184493425 139.7396836419419 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671635184493425 139.7396836419419 9.57 35.6716404961448 139.73967535091268 9.57 35.6716404961448 139.73967535091268 33.83 35.671635184493425 139.7396836419419 33.83 35.671635184493425 139.7396836419419 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6716404961448 139.73967535091268 9.57 35.67165195224743 139.73968649442875 9.57 35.67165195224743 139.73968649442875 33.83 35.6716404961448 139.73967535091268 33.83 35.6716404961448 139.73967535091268 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67165195224743 139.73968649442875 9.57 35.67171290181663 139.73959219707794 9.57 35.67171290181663 139.73959219707794 33.83 35.67165195224743 139.73968649442875 33.83 35.67165195224743 139.73968649442875 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67171290181663 139.73959219707794 9.57 35.67169991225481 139.73957961932274 9.57 35.67169991225481 139.73957961932274 33.83 35.67171290181663 139.73959219707794 33.83 35.67171290181663 139.73959219707794 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67169991225481 139.73957961932274 9.57 35.67170639439236 139.73956966994479 9.57 35.67170639439236 139.73956966994479 33.83 35.67169991225481 139.73957961932274 33.83 35.67169991225481 139.73957961932274 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170639439236 139.73956966994479 9.57 35.671593457231545 139.7394602214744 9.57 35.671593457231545 139.7394602214744 33.83 35.67170639439236 139.73956966994479 33.83 35.67170639439236 139.73956966994479 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671593457231545 139.7394602214744 9.57 35.671589315828626 139.7394665227862 9.57 35.671589315828626 139.7394665227862 33.83 35.671593457231545 139.7394602214744 33.83 35.671593457231545 139.7394602214744 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671589315828626 139.7394665227862 9.57 35.671567846896465 139.73944567018233 9.57 35.671567846896465 139.73944567018233 33.83 35.671589315828626 139.7394665227862 33.83 35.671589315828626 139.7394665227862 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671567846896465 139.73944567018233 9.57 35.67150392661243 139.73954472090696 9.57 35.67150392661243 139.73954472090696 33.83 35.671567846896465 139.73944567018233 33.83 35.671567846896465 139.73944567018233 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67150392661243 139.73954472090696 9.57 35.6715216068402 139.73956182217015 9.57 35.6715216068402 139.73956182217015 33.83 35.67150392661243 139.73954472090696 33.83 35.67150392661243 139.73954472090696 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715216068402 139.73956182217015 9.57 35.671516925296764 139.7395690078161 9.57 35.671516925296764 139.7395690078161 33.83 35.6715216068402 139.73956182217015 33.83 35.6715216068402 139.73956182217015 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671516925296764 139.7395690078161 9.57 35.671635184493425 139.7396836419419 9.57 35.671635184493425 139.7396836419419 33.83 35.671516925296764 139.7395690078161 33.83 35.671516925296764 139.7395690078161 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671635184493425 139.7396836419419 33.83 35.6716404961448 139.73967535091268 33.83 35.67165195224743 139.73968649442875 33.83 35.67171290181663 139.73959219707794 33.83 35.67169991225481 139.73957961932274 33.83 35.67170639439236 139.73956966994479 33.83 35.671593457231545 139.7394602214744 33.83 35.671589315828626 139.7394665227862 33.83 35.671567846896465 139.73944567018233 33.83 35.67150392661243 139.73954472090696 33.83 35.6715216068402 139.73956182217015 33.83 35.671516925296764 139.7395690078161 33.83 35.671635184493425 139.7396836419419 33.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9a69f80d-f2ef-49ea-9971-aded6b4c99aa"/>
							<gml:surfaceMember xlink:href="#poly-499d795b-baa4-4914-b358-b92a4485a003"/>
							<gml:surfaceMember xlink:href="#poly-fa8648e3-853b-4ad0-b077-ff34060a0974"/>
							<gml:surfaceMember xlink:href="#poly-d0c08de3-4128-4e27-b478-970eccae9f0b"/>
							<gml:surfaceMember xlink:href="#poly-a1d6430e-97cb-48f9-82c1-617ba0b91b02"/>
							<gml:surfaceMember xlink:href="#poly-86e232f2-542a-4b6d-a213-c68388a1b299"/>
							<gml:surfaceMember xlink:href="#poly-68583cd3-96fb-404f-be6c-532449c3f90e"/>
							<gml:surfaceMember xlink:href="#poly-cc76f3a0-1926-4a48-be5c-af1b4b19963a"/>
							<gml:surfaceMember xlink:href="#poly-769bcda2-ff9f-420d-adb5-6d514fd9adce"/>
							<gml:surfaceMember xlink:href="#poly-95aac92f-0b9f-43d7-bce2-8d48ff85ae67"/>
							<gml:surfaceMember xlink:href="#poly-91200a14-8031-429e-ad45-d3398216478f"/>
							<gml:surfaceMember xlink:href="#poly-c49c1142-daf3-48b8-bde2-d87aa196d507"/>
							<gml:surfaceMember xlink:href="#poly-1a9b430a-4687-49cc-9805-b7f06f28cb8c"/>
							<gml:surfaceMember xlink:href="#poly-35741e12-7852-44de-afac-382052cb713f"/>
							<gml:surfaceMember xlink:href="#poly-f7a84e48-dd05-4eb8-9b2a-8ac938c0e162"/>
							<gml:surfaceMember xlink:href="#poly-43a5552e-dc8f-4d43-80de-13d29272e3e5"/>
							<gml:surfaceMember xlink:href="#poly-43c8f2c7-c1af-47cf-a61a-a5b37aa4cb52"/>
							<gml:surfaceMember xlink:href="#poly-cb7a0c87-26ae-4a4c-9597-163393a85bfc"/>
							<gml:surfaceMember xlink:href="#poly-c0d4ef14-26e0-4bc2-a7ba-5ab9165673bf"/>
							<gml:surfaceMember xlink:href="#poly-abd98a19-aea0-4992-8019-ba220e84667a"/>
							<gml:surfaceMember xlink:href="#poly-2603d6d6-a703-45d9-a475-eaa11908570a"/>
							<gml:surfaceMember xlink:href="#poly-fa9651a8-6fc4-4af5-816b-d94bca435b0d"/>
							<gml:surfaceMember xlink:href="#poly-ae786976-98c0-4e95-b9cb-bcf557cd826b"/>
							<gml:surfaceMember xlink:href="#poly-3c5aed1e-e0cf-4e5a-88bd-15614012f2d1"/>
							<gml:surfaceMember xlink:href="#poly-2a8edf35-e5bd-438a-a4d3-93d40d67565c"/>
							<gml:surfaceMember xlink:href="#poly-21b0efe0-97bb-4237-987d-c7175db774ca"/>
							<gml:surfaceMember xlink:href="#poly-a82b8328-9a55-4d74-806a-5afc5b9b5d7a"/>
							<gml:surfaceMember xlink:href="#poly-0a44a616-d4a2-48e4-8fe5-f3bca711455e"/>
							<gml:surfaceMember xlink:href="#poly-00af851f-c6aa-46ce-8b18-59c4a9bdc81e"/>
							<gml:surfaceMember xlink:href="#poly-99865fe8-b932-4cd2-afdb-658ea74fbd50"/>
							<gml:surfaceMember xlink:href="#poly-5f3849dc-bb54-49e2-ac35-cd945238f2ce"/>
							<gml:surfaceMember xlink:href="#poly-1fdfa93c-50e9-4911-b7c5-a41e4b2b30cf"/>
							<gml:surfaceMember xlink:href="#poly-2bfd60ae-584b-4608-8e76-94b849bb549e"/>
							<gml:surfaceMember xlink:href="#poly-5d961b3e-aaca-40f1-8475-9b85e6a6d486"/>
							<gml:surfaceMember xlink:href="#poly-733a8714-cac4-447a-bc6f-bce11fa77156"/>
							<gml:surfaceMember xlink:href="#poly-8c948adf-6e3f-468f-8915-b5870b72ff09"/>
							<gml:surfaceMember xlink:href="#poly-9d31b75e-2238-4f77-ac3f-fe99917fae54"/>
							<gml:surfaceMember xlink:href="#poly-cd2d0ab5-5801-43a3-8acc-4103d988cc1f"/>
							<gml:surfaceMember xlink:href="#poly-49b592a2-400f-4914-8197-0f2625cac9e4"/>
							<gml:surfaceMember xlink:href="#poly-22d35adf-80b0-4d08-96e6-4e4f0c8da79f"/>
							<gml:surfaceMember xlink:href="#poly-56607820-fa61-4792-b1fe-3dd6a599afbd"/>
							<gml:surfaceMember xlink:href="#poly-5632f665-d8a9-4137-97b3-2d6935a8039d"/>
							<gml:surfaceMember xlink:href="#poly-5ebbfba5-62c4-453b-aff1-c77788e7f8db"/>
							<gml:surfaceMember xlink:href="#poly-e48a260d-8ffb-4219-bd84-36b65e7df551"/>
							<gml:surfaceMember xlink:href="#poly-f59cf5f2-fc3e-4458-ac20-b672e8ffc9ec"/>
							<gml:surfaceMember xlink:href="#poly-e4d6ad45-0e86-45e4-aeb5-0cebce00762f"/>
							<gml:surfaceMember xlink:href="#poly-678ba64c-a705-4923-b5b0-d3445877e07c"/>
							<gml:surfaceMember xlink:href="#poly-8256bad1-e38a-4676-9240-16dd505a82ae"/>
							<gml:surfaceMember xlink:href="#poly-ae5fa016-e76e-4bca-ab43-72846441d464"/>
							<gml:surfaceMember xlink:href="#poly-0f1061eb-6f67-4fcb-a68f-f5c2cdc7bfce"/>
							<gml:surfaceMember xlink:href="#poly-580b28c3-3fdf-41af-8f5b-13e7a7fce989"/>
							<gml:surfaceMember xlink:href="#poly-9748d336-1a0f-4400-9bfc-1100f9cfad94"/>
							<gml:surfaceMember xlink:href="#poly-3b420490-3b3b-427e-b08a-b2de41b827b3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9b11b91c-ead3-4d7c-9336-da2dd1e56c17_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fc269b7-057a-4037-b325-f4ff680c9805">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671547537456554 139.73955940581502 34.247 35.671553644382186 139.7395653526931 34.247 35.67154736935396 139.73957503669615 34.247 35.671541262428796 139.7395690898178 34.247 35.671547537456554 139.73955940581502 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed68a521-1475-4545-b00e-2f785a23397f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671555144673 139.73954735631824 34.247 35.671561368872226 139.73955342456944 34.247 35.671555057841694 139.739563174895 34.247 35.671548824629234 139.73955710665405 34.247 35.671555144673 139.73954735631824 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fd08515-68c8-4e20-8f13-248dbbde8626">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156258426194 139.739551545256 34.247 35.67155636007123 139.73954548805128 34.247 35.67156251805638 139.7395359809245 34.247 35.67156875126128 139.73954203811843 34.247 35.67156258426194 139.739551545256 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9ae3758-f9c4-4346-b4c1-67ef88cdd7d3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156479984144 139.73956081061291 34.247 35.67157112325973 139.73956696712125 34.247 35.67156538840954 139.73957582201288 34.247 35.6715590649917 139.73956966550432 34.247 35.67156479984144 139.73956081061291 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fd4edb6-c176-4d2d-a098-54862def975a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715764847541 139.73953009893333 34.247 35.6715702457406 139.73953972766765 34.247 35.67156401253557 139.7395336704738 34.247 35.671570260562326 139.7395240417292 34.247 35.6715764847541 139.73953009893333 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af145923-db56-403d-89a6-15d7f0cdbff0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715663393467 139.73955844487782 34.247 35.671572074187 139.7395495789384 34.247 35.67157839760585 139.7395557354464 34.247 35.671572662756496 139.73956459033965 34.247 35.6715663393467 139.73955844487782 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf7919c7-0a54-4480-b35e-a8ea4726d1de">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67157908450614 139.7396044272823 34.247 35.671575726223196 139.7396093579135 34.247 35.671566930829115 139.73960035431432 34.247 35.6715702891117 139.73959542368328 34.247 35.67157908450614 139.7396044272823 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e915f442-fbf0-42cc-9979-3d46a91e8888">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67157839760585 139.7395557354464 34.247 35.671572074187 139.7395495789384 34.247 35.671572074187 139.7395495789384 35.412 35.67157839760585 139.7395557354464 35.412 35.67157839760585 139.7395557354464 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77a86306-a81b-4479-831f-9b04701d8eee">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67157108038497 139.7395813606611 34.247 35.671576815235554 139.73957250576925 34.247 35.671582326807695 139.73957787893258 34.247 35.67157659194812 139.73958672277828 34.247 35.67157108038497 139.7395813606611 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e9d38b2-8731-4e65-809b-3b7147390191">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67157367671065 139.73954711371135 34.247 35.671580000129616 139.73955327021926 34.247 35.671580000129616 139.73955327021926 35.412 35.67157367671065 139.73954711371135 35.412 35.67157367671065 139.73954711371135 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1a97ac9-c1c1-49af-8649-921f1e52cf2e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671576958714866 139.73951369443878 34.247 35.67158319192089 139.73951975163206 34.247 35.67157784419087 139.73952799852216 34.247 35.67157161098527 139.73952194132863 34.247 35.671576958714866 139.73951369443878 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1dcf40df-5235-46b6-a293-d03f4212819b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67157984370102 139.7395375955257 34.247 35.67158616712047 139.73954375203334 34.247 35.671580000129616 139.73955327021926 34.247 35.67157367671065 139.73954711371135 34.247 35.67157984370102 139.7395375955257 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17da7bc1-a8d5-432f-b212-485b946b6c0b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67159044742953 139.73956534278915 34.247 35.67158439746911 139.73957467304785 34.247 35.67157888590543 139.73956931093096 34.247 35.67158493585682 139.73955996962607 34.247 35.67159044742953 139.73956534278915 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eac7f964-b3e9-4a83-9c03-f7a2e2bf146d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671584935282645 139.73950137938678 34.247 35.67159115947554 139.73950743659026 34.247 35.67158521756379 139.739516612077 34.247 35.671578993371334 139.73951055487328 34.247 35.671584935282645 139.73950137938678 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5378ad4d-cec2-4234-8e9f-65e57324139b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671586466356956 139.73955761494733 34.247 35.67159208417367 139.73954894797822 34.247 35.67159759573824 139.73955431009455 34.247 35.67159197792114 139.7395629770639 34.247 35.671586466356956 139.73955761494733 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a8d500d-008c-47a4-b0ae-6afef8b273b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a8d500d-008c-47a4-b0ae-6afef8b273b5_0">
											<gml:posList>35.671553644382186 139.7395653526931 34.247 35.671547537456554 139.73955940581502 34.247 35.671547537456554 139.73955940581502 35.412 35.671553644382186 139.7395653526931 35.412 35.671553644382186 139.7395653526931 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37a442a8-5058-444f-868c-6570f40dfbb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37a442a8-5058-444f-868c-6570f40dfbb2_0">
											<gml:posList>35.67156258426194 139.739551545256 34.247 35.67156258426194 139.739551545256 35.412 35.67155636007123 139.73954548805128 35.412 35.67155636007123 139.73954548805128 34.247 35.67156258426194 139.739551545256 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99f490ad-4b39-4515-b637-ae129b9284ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99f490ad-4b39-4515-b637-ae129b9284ee_0">
											<gml:posList>35.67156875126128 139.73954203811843 34.247 35.67156251805638 139.7395359809245 34.247 35.67156251805638 139.7395359809245 35.412 35.67156875126128 139.73954203811843 35.412 35.67156875126128 139.73954203811843 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54d9d31d-a1fe-4552-862a-28193062fff9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54d9d31d-a1fe-4552-862a-28193062fff9_0">
											<gml:posList>35.67156401253557 139.7395336704738 34.247 35.6715702457406 139.73953972766765 34.247 35.6715702457406 139.73953972766765 35.412 35.67156401253557 139.7395336704738 35.412 35.67156401253557 139.7395336704738 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-904cfc9c-6b6c-46cb-82be-8804175c85f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-904cfc9c-6b6c-46cb-82be-8804175c85f6_0">
											<gml:posList>35.671572662756496 139.73956459033965 34.247 35.671572662756496 139.73956459033965 35.412 35.6715663393467 139.73955844487782 35.412 35.6715663393467 139.73955844487782 34.247 35.671572662756496 139.73956459033965 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16e2d003-1250-44c9-9da0-6d1133b8773d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16e2d003-1250-44c9-9da0-6d1133b8773d_0">
											<gml:posList>35.6715764847541 139.73953009893333 34.247 35.671570260562326 139.7395240417292 34.247 35.671570260562326 139.7395240417292 35.412 35.6715764847541 139.73953009893333 35.412 35.6715764847541 139.73953009893333 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ae63b84-3433-4c53-90be-53f9c98e3995">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ae63b84-3433-4c53-90be-53f9c98e3995_0">
											<gml:posList>35.67157888590543 139.73956931093096 34.247 35.67158439746911 139.73957467304785 34.247 35.67158439746911 139.73957467304785 35.412 35.67157888590543 139.73956931093096 35.412 35.67157888590543 139.73956931093096 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3ff6d34-1023-4268-99c9-ce03aaf80b75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3ff6d34-1023-4268-99c9-ce03aaf80b75_0">
											<gml:posList>35.671578993371334 139.73951055487328 34.247 35.67158521756379 139.739516612077 34.247 35.67158521756379 139.739516612077 35.412 35.671578993371334 139.73951055487328 35.412 35.671578993371334 139.73951055487328 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd3c398c-9e23-402e-9a5e-98995ff0ae20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd3c398c-9e23-402e-9a5e-98995ff0ae20_0">
											<gml:posList>35.67159197792114 139.7395629770639 34.247 35.67159197792114 139.7395629770639 35.412 35.671586466356956 139.73955761494733 35.412 35.671586466356956 139.73955761494733 34.247 35.67159197792114 139.7395629770639 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48a26b37-ce0f-4cc5-bc53-7d3a898121fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48a26b37-ce0f-4cc5-bc53-7d3a898121fb_0">
											<gml:posList>35.671541262428796 139.7395690898178 34.247 35.67154736935396 139.73957503669615 34.247 35.67154736935396 139.73957503669615 35.412 35.671541262428796 139.7395690898178 35.412 35.671541262428796 139.7395690898178 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de7c5467-80ee-4932-b31e-5e03b4c9da28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de7c5467-80ee-4932-b31e-5e03b4c9da28_0">
											<gml:posList>35.671541262428796 139.7395690898178 34.247 35.671541262428796 139.7395690898178 35.412 35.671547537456554 139.73955940581502 35.412 35.671547537456554 139.73955940581502 34.247 35.671541262428796 139.7395690898178 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-983ca50c-7733-4f7b-9e1a-50d572507146">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-983ca50c-7733-4f7b-9e1a-50d572507146_0">
											<gml:posList>35.671547537456554 139.73955940581502 35.412 35.671541262428796 139.7395690898178 35.412 35.67154736935396 139.73957503669615 35.412 35.671553644382186 139.7395653526931 35.412 35.671547537456554 139.73955940581502 35.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6581e32a-2be4-490b-a7d9-5ecf1f4b9f54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6581e32a-2be4-490b-a7d9-5ecf1f4b9f54_0">
											<gml:posList>35.67154736935396 139.73957503669615 34.247 35.671553644382186 139.7395653526931 34.247 35.671553644382186 139.7395653526931 35.412 35.67154736935396 139.73957503669615 35.412 35.67154736935396 139.73957503669615 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d837508-ace1-42e1-9153-a225fcdbeb68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d837508-ace1-42e1-9153-a225fcdbeb68_0">
											<gml:posList>35.671548824629234 139.73955710665405 34.247 35.671555057841694 139.739563174895 34.247 35.671555057841694 139.739563174895 35.412 35.671548824629234 139.73955710665405 35.412 35.671548824629234 139.73955710665405 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff55f177-95c4-49da-b9db-0da9af37a85f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff55f177-95c4-49da-b9db-0da9af37a85f_0">
											<gml:posList>35.671548824629234 139.73955710665405 34.247 35.671548824629234 139.73955710665405 35.412 35.671555144673 139.73954735631824 35.412 35.671555144673 139.73954735631824 34.247 35.671548824629234 139.73955710665405 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40c1bf37-e7c9-4a21-84dc-c8c1fac4c4b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40c1bf37-e7c9-4a21-84dc-c8c1fac4c4b1_0">
											<gml:posList>35.671555144673 139.73954735631824 35.412 35.671548824629234 139.73955710665405 35.412 35.671555057841694 139.739563174895 35.412 35.671561368872226 139.73955342456944 35.412 35.671555144673 139.73954735631824 35.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9080651-8d2d-45e3-ae29-789f8f0b1571">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9080651-8d2d-45e3-ae29-789f8f0b1571_0">
											<gml:posList>35.671555057841694 139.739563174895 34.247 35.671561368872226 139.73955342456944 34.247 35.671561368872226 139.73955342456944 35.412 35.671555057841694 139.739563174895 35.412 35.671555057841694 139.739563174895 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4987524a-ebb3-4087-afd7-59852c31e974">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4987524a-ebb3-4087-afd7-59852c31e974_0">
											<gml:posList>35.671561368872226 139.73955342456944 34.247 35.671555144673 139.73954735631824 34.247 35.671555144673 139.73954735631824 35.412 35.671561368872226 139.73955342456944 35.412 35.671561368872226 139.73955342456944 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7adc15cb-db27-421d-a617-a173ec825064">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7adc15cb-db27-421d-a617-a173ec825064_0">
											<gml:posList>35.67156251805638 139.7395359809245 34.247 35.67155636007123 139.73954548805128 34.247 35.67155636007123 139.73954548805128 35.412 35.67156251805638 139.7395359809245 35.412 35.67156251805638 139.7395359809245 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cdeb2ef-82dd-422f-b878-930075451aa7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cdeb2ef-82dd-422f-b878-930075451aa7_0">
											<gml:posList>35.6715590649917 139.73956966550432 34.247 35.6715590649917 139.73956966550432 35.412 35.67156479984144 139.73956081061291 35.412 35.67156479984144 139.73956081061291 34.247 35.6715590649917 139.73956966550432 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b340bd72-a85f-44e3-9997-4127fe12ca67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b340bd72-a85f-44e3-9997-4127fe12ca67_0">
											<gml:posList>35.6715590649917 139.73956966550432 34.247 35.67156538840954 139.73957582201288 34.247 35.67156538840954 139.73957582201288 35.412 35.6715590649917 139.73956966550432 35.412 35.6715590649917 139.73956966550432 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a5b2b92-e98d-4555-bbab-bd464c723d73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a5b2b92-e98d-4555-bbab-bd464c723d73_0">
											<gml:posList>35.67156258426194 139.739551545256 35.412 35.67156875126128 139.73954203811843 35.412 35.67156251805638 139.7395359809245 35.412 35.67155636007123 139.73954548805128 35.412 35.67156258426194 139.739551545256 35.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21e66662-cf04-4b74-8211-39d2b52587ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21e66662-cf04-4b74-8211-39d2b52587ea_0">
											<gml:posList>35.67156479984144 139.73956081061291 35.412 35.6715590649917 139.73956966550432 35.412 35.67156538840954 139.73957582201288 35.412 35.67157112325973 139.73956696712125 35.412 35.67156479984144 139.73956081061291 35.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06650a9a-ec94-4942-9419-297590d6b5da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06650a9a-ec94-4942-9419-297590d6b5da_0">
											<gml:posList>35.67156258426194 139.739551545256 34.247 35.67156875126128 139.73954203811843 34.247 35.67156875126128 139.73954203811843 35.412 35.67156258426194 139.739551545256 35.412 35.67156258426194 139.739551545256 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0b44ec2-1e77-4717-8b9d-bcba219829e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0b44ec2-1e77-4717-8b9d-bcba219829e6_0">
											<gml:posList>35.671570260562326 139.7395240417292 34.247 35.67156401253557 139.7395336704738 34.247 35.67156401253557 139.7395336704738 35.412 35.671570260562326 139.7395240417292 35.412 35.671570260562326 139.7395240417292 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dee921e2-5fd6-4cca-9262-aeaaf4d36efb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dee921e2-5fd6-4cca-9262-aeaaf4d36efb_0">
											<gml:posList>35.67157112325973 139.73956696712125 34.247 35.67156479984144 139.73956081061291 34.247 35.67156479984144 139.73956081061291 35.412 35.67157112325973 139.73956696712125 35.412 35.67157112325973 139.73956696712125 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d64ab475-cc74-4091-bad0-f4f0fba7a062">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d64ab475-cc74-4091-bad0-f4f0fba7a062_0">
											<gml:posList>35.67156538840954 139.73957582201288 34.247 35.67157112325973 139.73956696712125 34.247 35.67157112325973 139.73956696712125 35.412 35.67156538840954 139.73957582201288 35.412 35.67156538840954 139.73957582201288 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3df45bc8-aa89-42e6-a056-a272fe5d8a15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3df45bc8-aa89-42e6-a056-a272fe5d8a15_0">
											<gml:posList>35.6715702891117 139.73959542368328 34.247 35.671566930829115 139.73960035431432 34.247 35.671566930829115 139.73960035431432 36.037 35.6715702891117 139.73959542368328 36.037 35.6715702891117 139.73959542368328 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99faa710-3c6a-4ed2-bd35-de1b2a8e4648">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99faa710-3c6a-4ed2-bd35-de1b2a8e4648_0">
											<gml:posList>35.671572074187 139.7395495789384 34.247 35.6715663393467 139.73955844487782 34.247 35.6715663393467 139.73955844487782 35.412 35.671572074187 139.7395495789384 35.412 35.671572074187 139.7395495789384 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4053745-4118-4947-9247-1d9be568c47d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4053745-4118-4947-9247-1d9be568c47d_0">
											<gml:posList>35.67156401253557 139.7395336704738 35.412 35.6715702457406 139.73953972766765 35.412 35.6715764847541 139.73953009893333 35.412 35.671570260562326 139.7395240417292 35.412 35.67156401253557 139.7395336704738 35.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbb3d36b-9a49-46f0-9d29-dc3c37508114">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbb3d36b-9a49-46f0-9d29-dc3c37508114_0">
											<gml:posList>35.671566930829115 139.73960035431432 34.247 35.671575726223196 139.7396093579135 34.247 35.671575726223196 139.7396093579135 36.037 35.671566930829115 139.73960035431432 36.037 35.671566930829115 139.73960035431432 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2cb09fa-477a-4503-a308-fa9274b0cbd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2cb09fa-477a-4503-a308-fa9274b0cbd0_0">
											<gml:posList>35.67157839760585 139.7395557354464 35.412 35.671572074187 139.7395495789384 35.412 35.6715663393467 139.73955844487782 35.412 35.671572662756496 139.73956459033965 35.412 35.67157839760585 139.7395557354464 35.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95a3f9a5-239c-4ad7-8b29-177a9403b1dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95a3f9a5-239c-4ad7-8b29-177a9403b1dd_0">
											<gml:posList>35.671566930829115 139.73960035431432 36.037 35.671575726223196 139.7396093579135 36.037 35.67157908450614 139.7396044272823 36.037 35.6715702891117 139.73959542368328 36.037 35.671566930829115 139.73960035431432 36.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f60fb53-0753-4d47-a820-d0b6895bd37d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f60fb53-0753-4d47-a820-d0b6895bd37d_0">
											<gml:posList>35.6715702457406 139.73953972766765 34.247 35.6715764847541 139.73953009893333 34.247 35.6715764847541 139.73953009893333 35.412 35.6715702457406 139.73953972766765 35.412 35.6715702457406 139.73953972766765 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ee68d05-616c-48ca-b8c6-05a70b451d67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ee68d05-616c-48ca-b8c6-05a70b451d67_0">
											<gml:posList>35.67157108038497 139.7395813606611 34.247 35.67157659194812 139.73958672277828 34.247 35.67157659194812 139.73958672277828 35.412 35.67157108038497 139.7395813606611 35.412 35.67157108038497 139.7395813606611 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09267c42-2926-4bd9-b9d4-7304332807d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09267c42-2926-4bd9-b9d4-7304332807d6_0">
											<gml:posList>35.671576815235554 139.73957250576925 34.247 35.67157108038497 139.7395813606611 34.247 35.67157108038497 139.7395813606611 35.412 35.671576815235554 139.73957250576925 35.412 35.671576815235554 139.73957250576925 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afd75bab-8562-4e56-a618-c77bb9d81f4b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afd75bab-8562-4e56-a618-c77bb9d81f4b_0">
											<gml:posList>35.671576958714866 139.73951369443878 34.247 35.67157161098527 139.73952194132863 34.247 35.67157161098527 139.73952194132863 35.412 35.671576958714866 139.73951369443878 35.412 35.671576958714866 139.73951369443878 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fba5faca-03ff-4ed5-a90c-1faf42a3304e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fba5faca-03ff-4ed5-a90c-1faf42a3304e_0">
											<gml:posList>35.67157908450614 139.7396044272823 34.247 35.6715702891117 139.73959542368328 34.247 35.6715702891117 139.73959542368328 36.037 35.67157908450614 139.7396044272823 36.037 35.67157908450614 139.7396044272823 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72036c1b-fd48-439a-be51-4a30059683f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72036c1b-fd48-439a-be51-4a30059683f2_0">
											<gml:posList>35.67157161098527 139.73952194132863 34.247 35.67157784419087 139.73952799852216 34.247 35.67157784419087 139.73952799852216 35.412 35.67157161098527 139.73952194132863 35.412 35.67157161098527 139.73952194132863 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-694637d6-a3c7-45c1-9826-7cd2cfd4f45b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-694637d6-a3c7-45c1-9826-7cd2cfd4f45b_0">
											<gml:posList>35.671572662756496 139.73956459033965 34.247 35.67157839760585 139.7395557354464 34.247 35.67157839760585 139.7395557354464 35.412 35.671572662756496 139.73956459033965 35.412 35.671572662756496 139.73956459033965 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e3b9b2e-1eda-45ff-9412-858d02132253">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e3b9b2e-1eda-45ff-9412-858d02132253_0">
											<gml:posList>35.671582326807695 139.73957787893258 35.412 35.671576815235554 139.73957250576925 35.412 35.67157108038497 139.7395813606611 35.412 35.67157659194812 139.73958672277828 35.412 35.671582326807695 139.73957787893258 35.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d003064b-78c2-4d76-b637-c971497c6a34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d003064b-78c2-4d76-b637-c971497c6a34_0">
											<gml:posList>35.67157367671065 139.73954711371135 34.247 35.67157367671065 139.73954711371135 35.412 35.67157984370102 139.7395375955257 35.412 35.67157984370102 139.7395375955257 34.247 35.67157367671065 139.73954711371135 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-985ecfe6-a800-49bd-827c-d24986d418f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-985ecfe6-a800-49bd-827c-d24986d418f9_0">
											<gml:posList>35.671575726223196 139.7396093579135 34.247 35.67157908450614 139.7396044272823 34.247 35.67157908450614 139.7396044272823 36.037 35.671575726223196 139.7396093579135 36.037 35.671575726223196 139.7396093579135 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4190ea34-f4df-4d01-b730-d818ec8c68fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4190ea34-f4df-4d01-b730-d818ec8c68fd_0">
											<gml:posList>35.67157784419087 139.73952799852216 35.412 35.67158319192089 139.73951975163206 35.412 35.671576958714866 139.73951369443878 35.412 35.67157161098527 139.73952194132863 35.412 35.67157784419087 139.73952799852216 35.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48da216f-69bf-47ea-bb75-db7239163caf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48da216f-69bf-47ea-bb75-db7239163caf_0">
											<gml:posList>35.67157659194812 139.73958672277828 34.247 35.671582326807695 139.73957787893258 34.247 35.671582326807695 139.73957787893258 35.412 35.67157659194812 139.73958672277828 35.412 35.67157659194812 139.73958672277828 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-daa18407-71dc-4291-87ab-f65b64bffc70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-daa18407-71dc-4291-87ab-f65b64bffc70_0">
											<gml:posList>35.671582326807695 139.73957787893258 34.247 35.671576815235554 139.73957250576925 34.247 35.671576815235554 139.73957250576925 35.412 35.671582326807695 139.73957787893258 35.412 35.671582326807695 139.73957787893258 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65ba4188-5512-4ab1-9025-dd71af3e9c2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65ba4188-5512-4ab1-9025-dd71af3e9c2b_0">
											<gml:posList>35.67157984370102 139.7395375955257 35.412 35.67157367671065 139.73954711371135 35.412 35.671580000129616 139.73955327021926 35.412 35.67158616712047 139.73954375203334 35.412 35.67157984370102 139.7395375955257 35.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5270435f-bfd3-471b-9dca-33f40f2db368">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5270435f-bfd3-471b-9dca-33f40f2db368_0">
											<gml:posList>35.67158319192089 139.73951975163206 34.247 35.671576958714866 139.73951369443878 34.247 35.671576958714866 139.73951369443878 35.412 35.67158319192089 139.73951975163206 35.412 35.67158319192089 139.73951975163206 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-264aff9f-a18b-4ca8-a48d-501d8a35ab7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-264aff9f-a18b-4ca8-a48d-501d8a35ab7c_0">
											<gml:posList>35.67157784419087 139.73952799852216 34.247 35.67158319192089 139.73951975163206 34.247 35.67158319192089 139.73951975163206 35.412 35.67157784419087 139.73952799852216 35.412 35.67157784419087 139.73952799852216 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11137549-1693-4432-b6ed-193b236960cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11137549-1693-4432-b6ed-193b236960cc_0">
											<gml:posList>35.67157888590543 139.73956931093096 34.247 35.67157888590543 139.73956931093096 35.412 35.67158493585682 139.73955996962607 35.412 35.67158493585682 139.73955996962607 34.247 35.67157888590543 139.73956931093096 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-256e409a-3e3d-4740-9d13-1ee3d77b05ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-256e409a-3e3d-4740-9d13-1ee3d77b05ee_0">
											<gml:posList>35.671584935282645 139.73950137938678 34.247 35.671578993371334 139.73951055487328 34.247 35.671578993371334 139.73951055487328 35.412 35.671584935282645 139.73950137938678 35.412 35.671584935282645 139.73950137938678 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36b07c3c-c247-495f-ba82-0992be956e0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36b07c3c-c247-495f-ba82-0992be956e0d_0">
											<gml:posList>35.67158616712047 139.73954375203334 34.247 35.67157984370102 139.7395375955257 34.247 35.67157984370102 139.7395375955257 35.412 35.67158616712047 139.73954375203334 35.412 35.67158616712047 139.73954375203334 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5e0dadf-49a7-4141-af7c-c2590e1adad7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5e0dadf-49a7-4141-af7c-c2590e1adad7_0">
											<gml:posList>35.671580000129616 139.73955327021926 34.247 35.67158616712047 139.73954375203334 34.247 35.67158616712047 139.73954375203334 35.412 35.671580000129616 139.73955327021926 35.412 35.671580000129616 139.73955327021926 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63099769-d76c-44ba-80b3-7b9c773d4ce8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63099769-d76c-44ba-80b3-7b9c773d4ce8_0">
											<gml:posList>35.67157888590543 139.73956931093096 35.412 35.67158439746911 139.73957467304785 35.412 35.67159044742953 139.73956534278915 35.412 35.67158493585682 139.73955996962607 35.412 35.67157888590543 139.73956931093096 35.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edf1dd4c-ab0c-4649-95c7-89d42244923c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edf1dd4c-ab0c-4649-95c7-89d42244923c_0">
											<gml:posList>35.67158521756379 139.739516612077 35.412 35.67159115947554 139.73950743659026 35.412 35.671584935282645 139.73950137938678 35.412 35.671578993371334 139.73951055487328 35.412 35.67158521756379 139.739516612077 35.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59595814-ad8f-4cd5-8104-5ffe4b43c329">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59595814-ad8f-4cd5-8104-5ffe4b43c329_0">
											<gml:posList>35.67158439746911 139.73957467304785 34.247 35.67159044742953 139.73956534278915 34.247 35.67159044742953 139.73956534278915 35.412 35.67158439746911 139.73957467304785 35.412 35.67158439746911 139.73957467304785 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a80d7ccd-6108-4889-bfb9-a3053100220f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a80d7ccd-6108-4889-bfb9-a3053100220f_0">
											<gml:posList>35.67159044742953 139.73956534278915 34.247 35.67158493585682 139.73955996962607 34.247 35.67158493585682 139.73955996962607 35.412 35.67159044742953 139.73956534278915 35.412 35.67159044742953 139.73956534278915 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29b305d8-513c-4101-86da-285523d4fc4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29b305d8-513c-4101-86da-285523d4fc4d_0">
											<gml:posList>35.67159115947554 139.73950743659026 34.247 35.671584935282645 139.73950137938678 34.247 35.671584935282645 139.73950137938678 35.412 35.67159115947554 139.73950743659026 35.412 35.67159115947554 139.73950743659026 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5a90436-6e99-40e2-82f5-97d584d816a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5a90436-6e99-40e2-82f5-97d584d816a3_0">
											<gml:posList>35.67158521756379 139.739516612077 34.247 35.67159115947554 139.73950743659026 34.247 35.67159115947554 139.73950743659026 35.412 35.67158521756379 139.739516612077 35.412 35.67158521756379 139.739516612077 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b33e7110-65c0-4990-96c8-0fa711f437fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b33e7110-65c0-4990-96c8-0fa711f437fa_0">
											<gml:posList>35.67159208417367 139.73954894797822 34.247 35.671586466356956 139.73955761494733 34.247 35.671586466356956 139.73955761494733 35.412 35.67159208417367 139.73954894797822 35.412 35.67159208417367 139.73954894797822 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4159de8f-ab3f-4ac6-8b8a-d4f61b6c08f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4159de8f-ab3f-4ac6-8b8a-d4f61b6c08f1_0">
											<gml:posList>35.671586466356956 139.73955761494733 35.412 35.67159197792114 139.7395629770639 35.412 35.67159759573824 139.73955431009455 35.412 35.67159208417367 139.73954894797822 35.412 35.671586466356956 139.73955761494733 35.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2192ad9f-1649-4409-aea1-6e7b3cf59c33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2192ad9f-1649-4409-aea1-6e7b3cf59c33_0">
											<gml:posList>35.67159197792114 139.7395629770639 34.247 35.67159759573824 139.73955431009455 34.247 35.67159759573824 139.73955431009455 35.412 35.67159197792114 139.7395629770639 35.412 35.67159197792114 139.7395629770639 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfda0ddb-a212-45ef-8f47-80312fd6d06c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfda0ddb-a212-45ef-8f47-80312fd6d06c_0">
											<gml:posList>35.67159759573824 139.73955431009455 34.247 35.67159208417367 139.73954894797822 34.247 35.67159208417367 139.73954894797822 35.412 35.67159759573824 139.73955431009455 35.412 35.67159759573824 139.73955431009455 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9b11b91c-ead3-4d7c-9336-da2dd1e56c17_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40534c5a-1777-496d-8289-73cdc73dfd69">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671639791008914 139.73961477309834 34.247 35.67162621466055 139.7396357882337 34.247 35.67159235157655 139.7396029646903 34.247 35.671605918896944 139.73958193852243 34.247 35.671639791008914 139.73961477309834 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a39f4c9e-0b6c-4e65-8d4f-57a63bc7d762">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a39f4c9e-0b6c-4e65-8d4f-57a63bc7d762_0">
											<gml:posList>35.67159235157655 139.7396029646903 34.247 35.67159235157655 139.7396029646903 36.735 35.671605918896944 139.73958193852243 36.735 35.671605918896944 139.73958193852243 34.247 35.67159235157655 139.7396029646903 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c0c3df0-c54a-4a26-b8aa-461b24f735d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c0c3df0-c54a-4a26-b8aa-461b24f735d8_0">
											<gml:posList>35.671605918896944 139.73958193852243 34.247 35.671605918896944 139.73958193852243 36.735 35.671639791008914 139.73961477309834 36.735 35.671639791008914 139.73961477309834 34.247 35.671605918896944 139.73958193852243 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c192db19-838d-44b0-a8fd-d58fde5d1f92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c192db19-838d-44b0-a8fd-d58fde5d1f92_0">
											<gml:posList>35.67159235157655 139.7396029646903 36.735 35.67162621466055 139.7396357882337 36.735 35.671639791008914 139.73961477309834 36.735 35.671605918896944 139.73958193852243 36.735 35.67159235157655 139.7396029646903 36.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3246bd5f-c29d-4760-9428-e3c31bf11658">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3246bd5f-c29d-4760-9428-e3c31bf11658_0">
											<gml:posList>35.67162621466055 139.7396357882337 36.735 35.67159235157655 139.7396029646903 36.735 35.67159235157655 139.7396029646903 34.247 35.67162621466055 139.7396357882337 34.247 35.67162621466055 139.7396357882337 36.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf18a34e-d5e1-4bde-ada7-3b5c8240ea31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf18a34e-d5e1-4bde-ada7-3b5c8240ea31_0">
											<gml:posList>35.671639791008914 139.73961477309834 34.247 35.671639791008914 139.73961477309834 36.735 35.67162621466055 139.7396357882337 36.735 35.67162621466055 139.7396357882337 34.247 35.671639791008914 139.73961477309834 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9b11b91c-ead3-4d7c-9336-da2dd1e56c17_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b4071a8-7821-4298-9c23-a8db32d0f268">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67162845310813 139.7395470717276 34.247 35.671650291825976 139.739568233242 34.247 35.67164542127802 139.7395757836524 34.247 35.67165462222246 139.73958469841202 34.247 35.671648176181485 139.7395947029723 34.247 35.67162541736346 139.73957263671988 34.247 35.67162856837229 139.73956776155867 34.247 35.671620278509174 139.73955974049912 34.247 35.67162845310813 139.7395470717276 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e7167fc-064d-4039-8018-502c49307d22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e7167fc-064d-4039-8018-502c49307d22_0">
											<gml:posList>35.671620278509174 139.73955974049912 34.247 35.671620278509174 139.73955974049912 34.601 35.67162845310813 139.7395470717276 34.601 35.67162845310813 139.7395470717276 34.247 35.671620278509174 139.73955974049912 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17715c62-0a40-4527-8918-307a1242f1f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17715c62-0a40-4527-8918-307a1242f1f0_0">
											<gml:posList>35.67162845310813 139.7395470717276 34.601 35.671650291825976 139.739568233242 34.601 35.671650291825976 139.739568233242 34.247 35.67162845310813 139.7395470717276 34.247 35.67162845310813 139.7395470717276 34.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ee7e011-1e0d-461f-af4c-3cec1ede61ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4ee7e011-1e0d-461f-af4c-3cec1ede61ca_0">
											<gml:posList>35.67162856837229 139.73956776155867 34.247 35.67162856837229 139.73956776155867 34.601 35.671620278509174 139.73955974049912 34.601 35.671620278509174 139.73955974049912 34.247 35.67162856837229 139.73956776155867 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec1f800c-f5da-4ea0-919c-59c05b1f9be2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec1f800c-f5da-4ea0-919c-59c05b1f9be2_0">
											<gml:posList>35.67162541736346 139.73957263671988 34.247 35.67162541736346 139.73957263671988 34.601 35.67162856837229 139.73956776155867 34.601 35.67162856837229 139.73956776155867 34.247 35.67162541736346 139.73957263671988 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-020ea508-f55b-48d6-85c4-21f86b718732">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-020ea508-f55b-48d6-85c4-21f86b718732_0">
											<gml:posList>35.67162856837229 139.73956776155867 34.601 35.67162541736346 139.73957263671988 34.601 35.671648176181485 139.7395947029723 34.601 35.67165462222246 139.73958469841202 34.601 35.67164542127802 139.7395757836524 34.601 35.671650291825976 139.739568233242 34.601 35.67162845310813 139.7395470717276 34.601 35.671620278509174 139.73955974049912 34.601 35.67162856837229 139.73956776155867 34.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d42b4df0-361f-4bb7-b40d-ef8fe09cf821">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d42b4df0-361f-4bb7-b40d-ef8fe09cf821_0">
											<gml:posList>35.671650291825976 139.739568233242 34.247 35.671650291825976 139.739568233242 34.601 35.67164542127802 139.7395757836524 34.601 35.67164542127802 139.7395757836524 34.247 35.671650291825976 139.739568233242 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-258c0d98-f0cf-4912-8102-fb7892c5910a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-258c0d98-f0cf-4912-8102-fb7892c5910a_0">
											<gml:posList>35.67164542127802 139.7395757836524 34.247 35.67164542127802 139.7395757836524 34.601 35.67165462222246 139.73958469841202 34.601 35.67165462222246 139.73958469841202 34.247 35.67164542127802 139.7395757836524 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09950924-b399-4584-85d5-8b92fc2e9edd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09950924-b399-4584-85d5-8b92fc2e9edd_0">
											<gml:posList>35.671648176181485 139.7395947029723 34.247 35.671648176181485 139.7395947029723 34.601 35.67162541736346 139.73957263671988 34.601 35.67162541736346 139.73957263671988 34.247 35.671648176181485 139.7395947029723 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf829db8-954e-48d2-bca5-3d7e50693a2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf829db8-954e-48d2-bca5-3d7e50693a2d_0">
											<gml:posList>35.67165462222246 139.73958469841202 34.247 35.67165462222246 139.73958469841202 34.601 35.671648176181485 139.7395947029723 34.601 35.671648176181485 139.7395947029723 34.247 35.67165462222246 139.73958469841202 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9a69f80d-f2ef-49ea-9971-aded6b4c99aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a69f80d-f2ef-49ea-9971-aded6b4c99aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a69f80d-f2ef-49ea-9971-aded6b4c99aa">
											<gml:posList>35.6716999122548 139.73957961932274 9.57 35.67171290181665 139.73959219707797 9.57 35.67165195224743 139.73968649442872 9.57 35.67164049614478 139.73967535091265 9.57 35.671635184493404 139.73968364194187 9.57 35.671516925296764 139.73956900781607 9.57 35.67152160684016 139.73956182217017 9.57 35.67150392661241 139.73954472090696 9.57 35.67156784689646 139.73944567018233 9.57 35.67158931582862 139.7394665227862 9.57 35.67159345723154 139.73946022147436 9.57 35.67170639439234 139.73956966994479 9.57 35.6716999122548 139.73957961932274 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-499d795b-baa4-4914-b358-b92a4485a003">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-499d795b-baa4-4914-b358-b92a4485a003">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-499d795b-baa4-4914-b358-b92a4485a003">
											<gml:posList>35.67156784689646 139.73944567018233 31.084 35.67150392661241 139.73954472090696 31.084 35.6715127667266 139.7395532715376 31.084 35.6715767141018 139.7394542760093 31.084 35.67156784689646 139.73944567018233 31.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa8648e3-853b-4ad0-b077-ff34060a0974">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa8648e3-853b-4ad0-b077-ff34060a0974">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa8648e3-853b-4ad0-b077-ff34060a0974">
											<gml:posList>35.67152160684016 139.73956182217017 32.93 35.67158558131512 139.73946289288455 32.93 35.6715767141018 139.7394542760093 32.93 35.6715127667266 139.7395532715376 32.93 35.67152160684016 139.73956182217017 32.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0c08de3-4128-4e27-b478-970eccae9f0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0c08de3-4128-4e27-b478-970eccae9f0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0c08de3-4128-4e27-b478-970eccae9f0b">
											<gml:posList>35.671516925296764 139.73956900781607 37.005 35.6715212784508 139.7395683951721 37.005 35.67158608123764 139.73946823876915 37.005 35.67158558131512 139.73946289288455 37.005 35.671516925296764 139.73956900781607 37.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a1d6430e-97cb-48f9-82c1-617ba0b91b02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1d6430e-97cb-48f9-82c1-617ba0b91b02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1d6430e-97cb-48f9-82c1-617ba0b91b02">
											<gml:posList>35.67162782374717 139.73967651454524 37.005 35.67162733288199 139.7396712128317 37.005 35.6715212784508 139.7395683951721 37.005 35.671516925296764 139.73956900781607 37.005 35.67162782374717 139.73967651454524 37.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-86e232f2-542a-4b6d-a213-c68388a1b299">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86e232f2-542a-4b6d-a213-c68388a1b299">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86e232f2-542a-4b6d-a213-c68388a1b299">
											<gml:posList>35.67158931582862 139.7394665227862 37.005 35.67158558131512 139.73946289288455 37.005 35.67158608123764 139.73946823876915 37.005 35.67158979770631 139.73947184659932 37.005 35.67158931582862 139.7394665227862 37.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68583cd3-96fb-404f-be6c-532449c3f90e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68583cd3-96fb-404f-be6c-532449c3f90e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68583cd3-96fb-404f-be6c-532449c3f90e">
											<gml:posList>35.67158931582862 139.7394665227862 37.005 35.67158979770631 139.73947184659932 37.005 35.67159394811461 139.7394655342308 37.005 35.67159345723154 139.73946022147436 37.005 35.67158931582862 139.7394665227862 37.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc76f3a0-1926-4a48-be5c-af1b4b19963a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc76f3a0-1926-4a48-be5c-af1b4b19963a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc76f3a0-1926-4a48-be5c-af1b4b19963a">
											<gml:posList>35.671592954224394 139.7395318802316 37.877 35.67159861421276 139.73953106722038 37.877 35.671617277140605 139.7395021479247 37.877 35.67161660472787 139.73949522260023 37.877 35.671592954224394 139.7395318802316 37.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-769bcda2-ff9f-420d-adb5-6d514fd9adce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-769bcda2-ff9f-420d-adb5-6d514fd9adce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-769bcda2-ff9f-420d-adb5-6d514fd9adce">
											<gml:posList>35.671617688543144 139.73955585518513 37.877 35.671617043174685 139.73954892982854 37.877 35.67159861421276 139.73953106722038 37.877 35.671592954224394 139.7395318802316 37.877 35.671617688543144 139.73955585518513 37.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-95aac92f-0b9f-43d7-bce2-8d48ff85ae67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95aac92f-0b9f-43d7-bce2-8d48ff85ae67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95aac92f-0b9f-43d7-bce2-8d48ff85ae67">
											<gml:posList>35.67162733288199 139.7396712128317 34.247 35.67165008436417 139.73956804569525 34.247 35.67162532298099 139.73954403762067 34.247 35.671617688543144 139.73955585518513 34.247 35.671592954224394 139.7395318802316 34.247 35.67161660472787 139.73949522260023 34.247 35.67166610945562 139.73954320561063 34.247 35.6716966109874 139.73956516339229 34.247 35.67159394811461 139.7394655342308 34.247 35.67158979770631 139.73947184659932 34.247 35.67158608123764 139.73946823876915 34.247 35.6715212784508 139.7395683951721 34.247 35.67162733288199 139.7396712128317 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-91200a14-8031-429e-ad45-d3398216478f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91200a14-8031-429e-ad45-d3398216478f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91200a14-8031-429e-ad45-d3398216478f">
											<gml:posList>35.67162532298099 139.73954403762067 37.877 35.67162467760322 139.73953710121708 37.877 35.671617043174685 139.73954892982854 37.877 35.671617688543144 139.73955585518513 37.877 35.67162532298099 139.73954403762067 37.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c49c1142-daf3-48b8-bde2-d87aa196d507">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c49c1142-daf3-48b8-bde2-d87aa196d507">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c49c1142-daf3-48b8-bde2-d87aa196d507">
											<gml:posList>35.67162467760322 139.73953710121708 37.69 35.67164942096035 139.73956110931042 37.69 35.67166045847235 139.73954400756472 37.69 35.671617277140605 139.7395021479247 37.69 35.67159861421276 139.73953106722038 37.69 35.671617043174685 139.73954892982854 37.69 35.67162467760322 139.73953710121708 37.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a9b430a-4687-49cc-9805-b7f06f28cb8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a9b430a-4687-49cc-9805-b7f06f28cb8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a9b430a-4687-49cc-9805-b7f06f28cb8c">
											<gml:posList>35.67162532298099 139.73954403762067 37.877 35.67165008436417 139.73956804569525 37.877 35.67164942096035 139.73956110931042 37.877 35.67162467760322 139.73953710121708 37.877 35.67162532298099 139.73954403762067 37.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35741e12-7852-44de-afac-382052cb713f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35741e12-7852-44de-afac-382052cb713f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35741e12-7852-44de-afac-382052cb713f">
											<gml:posList>35.67161660472787 139.73949522260023 37.877 35.671617277140605 139.7395021479247 37.877 35.67166045847235 139.73954400756472 37.877 35.67166610945562 139.73954320561063 37.877 35.67161660472787 139.73949522260023 37.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f7a84e48-dd05-4eb8-9b2a-8ac938c0e162">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7a84e48-dd05-4eb8-9b2a-8ac938c0e162">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7a84e48-dd05-4eb8-9b2a-8ac938c0e162">
											<gml:posList>35.67159345723154 139.73946022147436 37.005 35.67159394811461 139.7394655342308 37.005 35.6716966109874 139.73956516339229 37.005 35.67170143309559 139.7395648594986 37.005 35.67159345723154 139.73946022147436 37.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-43a5552e-dc8f-4d43-80de-13d29272e3e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43a5552e-dc8f-4d43-80de-13d29272e3e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43a5552e-dc8f-4d43-80de-13d29272e3e5">
											<gml:posList>35.67166610945562 139.73954320561063 37.877 35.67166045847235 139.73954400756472 37.877 35.67164942096035 139.73956110931042 37.877 35.67165008436417 139.73956804569525 37.877 35.67166610945562 139.73954320561063 37.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-43c8f2c7-c1af-47cf-a61a-a5b37aa4cb52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43c8f2c7-c1af-47cf-a61a-a5b37aa4cb52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43c8f2c7-c1af-47cf-a61a-a5b37aa4cb52">
											<gml:posList>35.67165008436417 139.73956804569525 34.247 35.67162733288199 139.7396712128317 34.247 35.6716966109874 139.73956516339229 34.247 35.67166610945562 139.73954320561063 34.247 35.67165008436417 139.73956804569525 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb7a0c87-26ae-4a4c-9597-163393a85bfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb7a0c87-26ae-4a4c-9597-163393a85bfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb7a0c87-26ae-4a4c-9597-163393a85bfc">
											<gml:posList>35.67170143309559 139.7395648594986 37.005 35.6716966109874 139.73956516339229 37.005 35.67162733288199 139.7396712128317 37.005 35.67162782374717 139.73967651454524 37.005 35.67170143309559 139.7395648594986 37.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c0d4ef14-26e0-4bc2-a7ba-5ab9165673bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0d4ef14-26e0-4bc2-a7ba-5ab9165673bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0d4ef14-26e0-4bc2-a7ba-5ab9165673bf">
											<gml:posList>35.6716999122548 139.73957961932274 32.74 35.67170639439234 139.73956966994479 32.74 35.67170143309559 139.7395648594986 32.74 35.67162782374717 139.73967651454524 32.74 35.671635184493404 139.73968364194187 32.74 35.67164049614478 139.73967535091265 32.74 35.6716999122548 139.73957961932274 32.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-abd98a19-aea0-4992-8019-ba220e84667a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abd98a19-aea0-4992-8019-ba220e84667a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abd98a19-aea0-4992-8019-ba220e84667a">
											<gml:posList>35.67165195224743 139.73968649442872 31.484 35.67171290181665 139.73959219707797 31.484 35.6716999122548 139.73957961932274 31.484 35.67164049614478 139.73967535091265 31.484 35.67165195224743 139.73968649442872 31.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2603d6d6-a703-45d9-a475-eaa11908570a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2603d6d6-a703-45d9-a475-eaa11908570a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2603d6d6-a703-45d9-a475-eaa11908570a">
											<gml:posList>35.67159394811461 139.7394655342308 37.005 35.67159394811461 139.7394655342308 34.247 35.6716966109874 139.73956516339229 34.247 35.6716966109874 139.73956516339229 37.005 35.67159394811461 139.7394655342308 37.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa9651a8-6fc4-4af5-816b-d94bca435b0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa9651a8-6fc4-4af5-816b-d94bca435b0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa9651a8-6fc4-4af5-816b-d94bca435b0d">
											<gml:posList>35.671617277140605 139.7395021479247 37.877 35.671617277140605 139.7395021479247 37.69 35.67166045847235 139.73954400756472 37.69 35.67166045847235 139.73954400756472 37.877 35.671617277140605 139.7395021479247 37.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae786976-98c0-4e95-b9cb-bcf557cd826b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae786976-98c0-4e95-b9cb-bcf557cd826b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae786976-98c0-4e95-b9cb-bcf557cd826b">
											<gml:posList>35.671617043174685 139.73954892982854 37.877 35.671617043174685 139.73954892982854 37.69 35.67159861421276 139.73953106722038 37.69 35.67159861421276 139.73953106722038 37.877 35.671617043174685 139.73954892982854 37.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c5aed1e-e0cf-4e5a-88bd-15614012f2d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c5aed1e-e0cf-4e5a-88bd-15614012f2d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c5aed1e-e0cf-4e5a-88bd-15614012f2d1">
											<gml:posList>35.67164942096035 139.73956110931042 37.877 35.67164942096035 139.73956110931042 37.69 35.67162467760322 139.73953710121708 37.69 35.67162467760322 139.73953710121708 37.877 35.67164942096035 139.73956110931042 37.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a8edf35-e5bd-438a-a4d3-93d40d67565c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a8edf35-e5bd-438a-a4d3-93d40d67565c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a8edf35-e5bd-438a-a4d3-93d40d67565c">
											<gml:posList>35.6715127667266 139.7395532715376 31.084 35.67150392661241 139.73954472090696 31.084 35.67150392661241 139.73954472090696 9.57 35.67152160684016 139.73956182217017 9.57 35.67152160684016 139.73956182217017 32.93 35.6715127667266 139.7395532715376 32.93 35.6715127667266 139.7395532715376 31.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21b0efe0-97bb-4237-987d-c7175db774ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21b0efe0-97bb-4237-987d-c7175db774ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21b0efe0-97bb-4237-987d-c7175db774ca">
											<gml:posList>35.67156784689646 139.73944567018233 9.57 35.67150392661241 139.73954472090696 9.57 35.67150392661241 139.73954472090696 31.084 35.67156784689646 139.73944567018233 31.084 35.67156784689646 139.73944567018233 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a82b8328-9a55-4d74-806a-5afc5b9b5d7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a82b8328-9a55-4d74-806a-5afc5b9b5d7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a82b8328-9a55-4d74-806a-5afc5b9b5d7a">
											<gml:posList>35.6715127667266 139.7395532715376 31.084 35.6715127667266 139.7395532715376 32.93 35.6715767141018 139.7394542760093 32.93 35.6715767141018 139.7394542760093 31.084 35.6715127667266 139.7395532715376 31.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a44a616-d4a2-48e4-8fe5-f3bca711455e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a44a616-d4a2-48e4-8fe5-f3bca711455e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a44a616-d4a2-48e4-8fe5-f3bca711455e">
											<gml:posList>35.671516925296764 139.73956900781607 37.005 35.67158558131512 139.73946289288455 37.005 35.67158558131512 139.73946289288455 32.93 35.67152160684016 139.73956182217017 32.93 35.67152160684016 139.73956182217017 9.57 35.671516925296764 139.73956900781607 9.57 35.671516925296764 139.73956900781607 37.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00af851f-c6aa-46ce-8b18-59c4a9bdc81e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00af851f-c6aa-46ce-8b18-59c4a9bdc81e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00af851f-c6aa-46ce-8b18-59c4a9bdc81e">
											<gml:posList>35.6715212784508 139.7395683951721 37.005 35.6715212784508 139.7395683951721 34.247 35.67158608123764 139.73946823876915 34.247 35.67158608123764 139.73946823876915 37.005 35.6715212784508 139.7395683951721 37.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99865fe8-b932-4cd2-afdb-658ea74fbd50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99865fe8-b932-4cd2-afdb-658ea74fbd50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99865fe8-b932-4cd2-afdb-658ea74fbd50">
											<gml:posList>35.67162733288199 139.7396712128317 37.005 35.67162733288199 139.7396712128317 34.247 35.6715212784508 139.7395683951721 34.247 35.6715212784508 139.7395683951721 37.005 35.67162733288199 139.7396712128317 37.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f3849dc-bb54-49e2-ac35-cd945238f2ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f3849dc-bb54-49e2-ac35-cd945238f2ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f3849dc-bb54-49e2-ac35-cd945238f2ce">
											<gml:posList>35.67162782374717 139.73967651454524 32.74 35.67162782374717 139.73967651454524 37.005 35.671516925296764 139.73956900781607 37.005 35.671516925296764 139.73956900781607 9.57 35.671635184493404 139.73968364194187 9.57 35.671635184493404 139.73968364194187 32.74 35.67162782374717 139.73967651454524 32.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1fdfa93c-50e9-4911-b7c5-a41e4b2b30cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1fdfa93c-50e9-4911-b7c5-a41e4b2b30cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1fdfa93c-50e9-4911-b7c5-a41e4b2b30cf">
											<gml:posList>35.67156784689646 139.73944567018233 9.57 35.67156784689646 139.73944567018233 31.084 35.6715767141018 139.7394542760093 31.084 35.6715767141018 139.7394542760093 32.93 35.67158558131512 139.73946289288455 32.93 35.67158558131512 139.73946289288455 37.005 35.67158931582862 139.7394665227862 37.005 35.67158931582862 139.7394665227862 9.57 35.67156784689646 139.73944567018233 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2bfd60ae-584b-4608-8e76-94b849bb549e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bfd60ae-584b-4608-8e76-94b849bb549e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bfd60ae-584b-4608-8e76-94b849bb549e">
											<gml:posList>35.67158608123764 139.73946823876915 37.005 35.67158608123764 139.73946823876915 34.247 35.67158979770631 139.73947184659932 34.247 35.67158979770631 139.73947184659932 37.005 35.67158608123764 139.73946823876915 37.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d961b3e-aaca-40f1-8475-9b85e6a6d486">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d961b3e-aaca-40f1-8475-9b85e6a6d486">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d961b3e-aaca-40f1-8475-9b85e6a6d486">
											<gml:posList>35.67159345723154 139.73946022147436 9.57 35.67158931582862 139.7394665227862 9.57 35.67158931582862 139.7394665227862 37.005 35.67159345723154 139.73946022147436 37.005 35.67159345723154 139.73946022147436 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-733a8714-cac4-447a-bc6f-bce11fa77156">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-733a8714-cac4-447a-bc6f-bce11fa77156">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-733a8714-cac4-447a-bc6f-bce11fa77156">
											<gml:posList>35.67158979770631 139.73947184659932 37.005 35.67158979770631 139.73947184659932 34.247 35.67159394811461 139.7394655342308 34.247 35.67159394811461 139.7394655342308 37.005 35.67158979770631 139.73947184659932 37.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c948adf-6e3f-468f-8915-b5870b72ff09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c948adf-6e3f-468f-8915-b5870b72ff09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c948adf-6e3f-468f-8915-b5870b72ff09">
											<gml:posList>35.671592954224394 139.7395318802316 37.877 35.67161660472787 139.73949522260023 37.877 35.67161660472787 139.73949522260023 34.247 35.671592954224394 139.7395318802316 34.247 35.671592954224394 139.7395318802316 37.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d31b75e-2238-4f77-ac3f-fe99917fae54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d31b75e-2238-4f77-ac3f-fe99917fae54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d31b75e-2238-4f77-ac3f-fe99917fae54">
											<gml:posList>35.67159345723154 139.73946022147436 9.57 35.67159345723154 139.73946022147436 37.005 35.67170143309559 139.7395648594986 37.005 35.67170143309559 139.7395648594986 32.74 35.67170639439234 139.73956966994479 32.74 35.67170639439234 139.73956966994479 9.57 35.67159345723154 139.73946022147436 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd2d0ab5-5801-43a3-8acc-4103d988cc1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd2d0ab5-5801-43a3-8acc-4103d988cc1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd2d0ab5-5801-43a3-8acc-4103d988cc1f">
											<gml:posList>35.67159861421276 139.73953106722038 37.877 35.67159861421276 139.73953106722038 37.69 35.671617277140605 139.7395021479247 37.69 35.671617277140605 139.7395021479247 37.877 35.67159861421276 139.73953106722038 37.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49b592a2-400f-4914-8197-0f2625cac9e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49b592a2-400f-4914-8197-0f2625cac9e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49b592a2-400f-4914-8197-0f2625cac9e4">
											<gml:posList>35.67161660472787 139.73949522260023 37.877 35.67166610945562 139.73954320561063 37.877 35.67166610945562 139.73954320561063 34.247 35.67161660472787 139.73949522260023 34.247 35.67161660472787 139.73949522260023 37.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22d35adf-80b0-4d08-96e6-4e4f0c8da79f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22d35adf-80b0-4d08-96e6-4e4f0c8da79f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22d35adf-80b0-4d08-96e6-4e4f0c8da79f">
											<gml:posList>35.67162467760322 139.73953710121708 37.877 35.67162467760322 139.73953710121708 37.69 35.671617043174685 139.73954892982854 37.69 35.671617043174685 139.73954892982854 37.877 35.67162467760322 139.73953710121708 37.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56607820-fa61-4792-b1fe-3dd6a599afbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56607820-fa61-4792-b1fe-3dd6a599afbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56607820-fa61-4792-b1fe-3dd6a599afbd">
											<gml:posList>35.671592954224394 139.7395318802316 34.247 35.671617688543144 139.73955585518513 34.247 35.671617688543144 139.73955585518513 37.877 35.671592954224394 139.7395318802316 37.877 35.671592954224394 139.7395318802316 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5632f665-d8a9-4137-97b3-2d6935a8039d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5632f665-d8a9-4137-97b3-2d6935a8039d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5632f665-d8a9-4137-97b3-2d6935a8039d">
											<gml:posList>35.671617688543144 139.73955585518513 34.247 35.67162532298099 139.73954403762067 34.247 35.67162532298099 139.73954403762067 37.877 35.671617688543144 139.73955585518513 37.877 35.671617688543144 139.73955585518513 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ebbfba5-62c4-453b-aff1-c77788e7f8db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ebbfba5-62c4-453b-aff1-c77788e7f8db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ebbfba5-62c4-453b-aff1-c77788e7f8db">
											<gml:posList>35.67166045847235 139.73954400756472 37.877 35.67166045847235 139.73954400756472 37.69 35.67164942096035 139.73956110931042 37.69 35.67164942096035 139.73956110931042 37.877 35.67166045847235 139.73954400756472 37.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e48a260d-8ffb-4219-bd84-36b65e7df551">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e48a260d-8ffb-4219-bd84-36b65e7df551">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e48a260d-8ffb-4219-bd84-36b65e7df551">
											<gml:posList>35.67165008436417 139.73956804569525 34.247 35.67166610945562 139.73954320561063 34.247 35.67166610945562 139.73954320561063 37.877 35.67165008436417 139.73956804569525 37.877 35.67165008436417 139.73956804569525 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f59cf5f2-fc3e-4458-ac20-b672e8ffc9ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f59cf5f2-fc3e-4458-ac20-b672e8ffc9ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f59cf5f2-fc3e-4458-ac20-b672e8ffc9ec">
											<gml:posList>35.67162532298099 139.73954403762067 34.247 35.67165008436417 139.73956804569525 34.247 35.67165008436417 139.73956804569525 37.877 35.67162532298099 139.73954403762067 37.877 35.67162532298099 139.73954403762067 34.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4d6ad45-0e86-45e4-aeb5-0cebce00762f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4d6ad45-0e86-45e4-aeb5-0cebce00762f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4d6ad45-0e86-45e4-aeb5-0cebce00762f">
											<gml:posList>35.67170639439234 139.73956966994479 9.57 35.67170639439234 139.73956966994479 32.74 35.6716999122548 139.73957961932274 32.74 35.6716999122548 139.73957961932274 31.484 35.6716999122548 139.73957961932274 9.57 35.67170639439234 139.73956966994479 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-678ba64c-a705-4923-b5b0-d3445877e07c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-678ba64c-a705-4923-b5b0-d3445877e07c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-678ba64c-a705-4923-b5b0-d3445877e07c">
											<gml:posList>35.67171290181665 139.73959219707797 9.57 35.6716999122548 139.73957961932274 9.57 35.6716999122548 139.73957961932274 31.484 35.67171290181665 139.73959219707797 31.484 35.67171290181665 139.73959219707797 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8256bad1-e38a-4676-9240-16dd505a82ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8256bad1-e38a-4676-9240-16dd505a82ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8256bad1-e38a-4676-9240-16dd505a82ae">
											<gml:posList>35.6716966109874 139.73956516339229 37.005 35.6716966109874 139.73956516339229 34.247 35.67162733288199 139.7396712128317 34.247 35.67162733288199 139.7396712128317 37.005 35.6716966109874 139.73956516339229 37.005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae5fa016-e76e-4bca-ab43-72846441d464">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae5fa016-e76e-4bca-ab43-72846441d464">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae5fa016-e76e-4bca-ab43-72846441d464">
											<gml:posList>35.67162782374717 139.73967651454524 32.74 35.67170143309559 139.7395648594986 32.74 35.67170143309559 139.7395648594986 37.005 35.67162782374717 139.73967651454524 37.005 35.67162782374717 139.73967651454524 32.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f1061eb-6f67-4fcb-a68f-f5c2cdc7bfce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f1061eb-6f67-4fcb-a68f-f5c2cdc7bfce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f1061eb-6f67-4fcb-a68f-f5c2cdc7bfce">
											<gml:posList>35.6716999122548 139.73957961932274 31.484 35.6716999122548 139.73957961932274 32.74 35.67164049614478 139.73967535091265 32.74 35.67164049614478 139.73967535091265 31.484 35.6716999122548 139.73957961932274 31.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-580b28c3-3fdf-41af-8f5b-13e7a7fce989">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-580b28c3-3fdf-41af-8f5b-13e7a7fce989">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-580b28c3-3fdf-41af-8f5b-13e7a7fce989">
											<gml:posList>35.67165195224743 139.73968649442872 9.57 35.67171290181665 139.73959219707797 9.57 35.67171290181665 139.73959219707797 31.484 35.67165195224743 139.73968649442872 31.484 35.67165195224743 139.73968649442872 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9748d336-1a0f-4400-9bfc-1100f9cfad94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9748d336-1a0f-4400-9bfc-1100f9cfad94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9748d336-1a0f-4400-9bfc-1100f9cfad94">
											<gml:posList>35.671635184493404 139.73968364194187 32.74 35.671635184493404 139.73968364194187 9.57 35.67164049614478 139.73967535091265 9.57 35.67164049614478 139.73967535091265 31.484 35.67164049614478 139.73967535091265 32.74 35.671635184493404 139.73968364194187 32.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b420490-3b3b-427e-b08a-b2de41b827b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b420490-3b3b-427e-b08a-b2de41b827b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b420490-3b3b-427e-b08a-b2de41b827b3">
											<gml:posList>35.67164049614478 139.73967535091265 9.57 35.67165195224743 139.73968649442872 9.57 35.67165195224743 139.73968649442872 31.484 35.67164049614478 139.73967535091265 31.484 35.67164049614478 139.73967535091265 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4030</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">262.8841</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>