<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9d982601-c101-4e5c-ad80-ddc8e77e07c6">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67040729267608 139.73859348446433 0 35.670364849428914 139.73860800521322 0 35.670383029637364 139.73868762726642 0 35.67042547280718 139.73867299609378 0 35.67040729267608 139.73859348446433 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67040729267608 139.73859348446433 20.476 35.67042547280718 139.73867299609378 20.476 35.670383029637364 139.73868762726642 20.476 35.670364849428914 139.73860800521322 20.476 35.67040729267608 139.73859348446433 20.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67040729267608 139.73859348446433 20.476 35.670364849428914 139.73860800521322 20.476 35.670364849428914 139.73860800521322 23.476 35.67040729267608 139.73859348446433 23.476 35.67040729267608 139.73859348446433 20.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670364849428914 139.73860800521322 20.476 35.670383029637364 139.73868762726642 20.476 35.670383029637364 139.73868762726642 23.476 35.670364849428914 139.73860800521322 23.476 35.670364849428914 139.73860800521322 20.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670383029637364 139.73868762726642 20.476 35.67042547280718 139.73867299609378 20.476 35.67042547280718 139.73867299609378 23.476 35.670383029637364 139.73868762726642 23.476 35.670383029637364 139.73868762726642 20.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67042547280718 139.73867299609378 20.476 35.67040729267608 139.73859348446433 20.476 35.67040729267608 139.73859348446433 23.476 35.67042547280718 139.73867299609378 23.476 35.67042547280718 139.73867299609378 20.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67040729267608 139.73859348446433 23.476 35.670364849428914 139.73860800521322 23.476 35.670383029637364 139.73868762726642 23.476 35.67042547280718 139.73867299609378 23.476 35.67040729267608 139.73859348446433 23.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-289b0f4b-fbaf-4685-b3d9-4c4ee1d4e4e8"/>
							<gml:surfaceMember xlink:href="#poly-6130dfeb-51ac-4a8a-b510-185e3f58a3a4"/>
							<gml:surfaceMember xlink:href="#poly-4386e3f0-4370-42f9-a8ec-e331e50b31b4"/>
							<gml:surfaceMember xlink:href="#poly-ba710d7a-ce38-4fe2-bb21-a779d8475318"/>
							<gml:surfaceMember xlink:href="#poly-e93c9f22-5cb9-4384-ac54-698b46458513"/>
							<gml:surfaceMember xlink:href="#poly-a4a674a9-60f3-4c51-b3d4-123497814023"/>
							<gml:surfaceMember xlink:href="#poly-dd26e8a3-bbb9-48ca-93ec-f77eefc67e1f"/>
							<gml:surfaceMember xlink:href="#poly-c7d2314a-ddc3-4dc2-aad2-bf64b9a170d5"/>
							<gml:surfaceMember xlink:href="#poly-ad0583aa-184e-4da2-a1e2-09beaf588628"/>
							<gml:surfaceMember xlink:href="#poly-6d26d9c2-69e1-4c56-98c6-262854efbd77"/>
							<gml:surfaceMember xlink:href="#poly-f47a43ad-1f7d-496b-a80b-b4167d3240b8"/>
							<gml:surfaceMember xlink:href="#poly-99918e90-742e-4f73-a51b-dc0a4df4af61"/>
							<gml:surfaceMember xlink:href="#poly-5c3cce86-e88c-4100-a2aa-e393c8efe680"/>
							<gml:surfaceMember xlink:href="#poly-c0c2ecd2-289f-4142-8cd2-9360f6d90d4a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-289b0f4b-fbaf-4685-b3d9-4c4ee1d4e4e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-289b0f4b-fbaf-4685-b3d9-4c4ee1d4e4e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-289b0f4b-fbaf-4685-b3d9-4c4ee1d4e4e8">
											<gml:posList>35.67040729267607 139.73859348446433 20.476 35.670425472807175 139.73867299609375 20.476 35.67038302963733 139.7386876272664 20.476 35.670364849428914 139.73860800521322 20.476 35.67040729267607 139.73859348446433 20.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6130dfeb-51ac-4a8a-b510-185e3f58a3a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6130dfeb-51ac-4a8a-b510-185e3f58a3a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6130dfeb-51ac-4a8a-b510-185e3f58a3a4">
											<gml:posList>35.670364849428914 139.73860800521322 25.038 35.67037053115872 139.73861191992214 25.038 35.67040409827119 139.73860043633806 25.038 35.67040729267607 139.73859348446433 25.038 35.670364849428914 139.73860800521322 25.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4386e3f0-4370-42f9-a8ec-e331e50b31b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4386e3f0-4370-42f9-a8ec-e331e50b31b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4386e3f0-4370-42f9-a8ec-e331e50b31b4">
											<gml:posList>35.67040729267607 139.73859348446433 25.038 35.67040409827119 139.73860043633806 25.038 35.67041980009312 139.7386690813672 25.038 35.670425472807175 139.73867299609375 25.038 35.67040729267607 139.73859348446433 25.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba710d7a-ce38-4fe2-bb21-a779d8475318">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba710d7a-ce38-4fe2-bb21-a779d8475318">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba710d7a-ce38-4fe2-bb21-a779d8475318">
											<gml:posList>35.67041980009312 139.7386690813672 24.054 35.67040409827119 139.73860043633806 24.054 35.67037053115872 139.73861191992214 24.054 35.6703862240299 139.73868065330547 24.054 35.67041980009312 139.7386690813672 24.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e93c9f22-5cb9-4384-ac54-698b46458513">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e93c9f22-5cb9-4384-ac54-698b46458513">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e93c9f22-5cb9-4384-ac54-698b46458513">
											<gml:posList>35.67038302963733 139.7386876272664 25.038 35.6703862240299 139.73868065330547 25.038 35.67037053115872 139.73861191992214 25.038 35.670364849428914 139.73860800521322 25.038 35.67038302963733 139.7386876272664 25.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4a674a9-60f3-4c51-b3d4-123497814023">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4a674a9-60f3-4c51-b3d4-123497814023">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4a674a9-60f3-4c51-b3d4-123497814023">
											<gml:posList>35.670425472807175 139.73867299609375 25.038 35.67041980009312 139.7386690813672 25.038 35.6703862240299 139.73868065330547 25.038 35.67038302963733 139.7386876272664 25.038 35.670425472807175 139.73867299609375 25.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd26e8a3-bbb9-48ca-93ec-f77eefc67e1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd26e8a3-bbb9-48ca-93ec-f77eefc67e1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd26e8a3-bbb9-48ca-93ec-f77eefc67e1f">
											<gml:posList>35.670364849428914 139.73860800521322 20.476 35.67038302963733 139.7386876272664 20.476 35.67038302963733 139.7386876272664 25.038 35.670364849428914 139.73860800521322 25.038 35.670364849428914 139.73860800521322 20.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7d2314a-ddc3-4dc2-aad2-bf64b9a170d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7d2314a-ddc3-4dc2-aad2-bf64b9a170d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7d2314a-ddc3-4dc2-aad2-bf64b9a170d5">
											<gml:posList>35.6703862240299 139.73868065330547 25.038 35.6703862240299 139.73868065330547 24.054 35.67037053115872 139.73861191992214 24.054 35.67037053115872 139.73861191992214 25.038 35.6703862240299 139.73868065330547 25.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad0583aa-184e-4da2-a1e2-09beaf588628">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad0583aa-184e-4da2-a1e2-09beaf588628">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad0583aa-184e-4da2-a1e2-09beaf588628">
											<gml:posList>35.67040729267607 139.73859348446433 20.476 35.670364849428914 139.73860800521322 20.476 35.670364849428914 139.73860800521322 25.038 35.67040729267607 139.73859348446433 25.038 35.67040729267607 139.73859348446433 20.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d26d9c2-69e1-4c56-98c6-262854efbd77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d26d9c2-69e1-4c56-98c6-262854efbd77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d26d9c2-69e1-4c56-98c6-262854efbd77">
											<gml:posList>35.67037053115872 139.73861191992214 25.038 35.67037053115872 139.73861191992214 24.054 35.67040409827119 139.73860043633806 24.054 35.67040409827119 139.73860043633806 25.038 35.67037053115872 139.73861191992214 25.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f47a43ad-1f7d-496b-a80b-b4167d3240b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f47a43ad-1f7d-496b-a80b-b4167d3240b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f47a43ad-1f7d-496b-a80b-b4167d3240b8">
											<gml:posList>35.67041980009312 139.7386690813672 25.038 35.67041980009312 139.7386690813672 24.054 35.6703862240299 139.73868065330547 24.054 35.6703862240299 139.73868065330547 25.038 35.67041980009312 139.7386690813672 25.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99918e90-742e-4f73-a51b-dc0a4df4af61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99918e90-742e-4f73-a51b-dc0a4df4af61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99918e90-742e-4f73-a51b-dc0a4df4af61">
											<gml:posList>35.67038302963733 139.7386876272664 20.476 35.670425472807175 139.73867299609375 20.476 35.670425472807175 139.73867299609375 25.038 35.67038302963733 139.7386876272664 25.038 35.67038302963733 139.7386876272664 20.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c3cce86-e88c-4100-a2aa-e393c8efe680">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c3cce86-e88c-4100-a2aa-e393c8efe680">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c3cce86-e88c-4100-a2aa-e393c8efe680">
											<gml:posList>35.67040409827119 139.73860043633806 25.038 35.67040409827119 139.73860043633806 24.054 35.67041980009312 139.7386690813672 24.054 35.67041980009312 139.7386690813672 25.038 35.67040409827119 139.73860043633806 25.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0c2ecd2-289f-4142-8cd2-9360f6d90d4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0c2ecd2-289f-4142-8cd2-9360f6d90d4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0c2ecd2-289f-4142-8cd2-9360f6d90d4a">
											<gml:posList>35.670425472807175 139.73867299609375 20.476 35.67040729267607 139.73859348446433 20.476 35.67040729267607 139.73859348446433 25.038 35.670425472807175 139.73867299609375 25.038 35.670425472807175 139.73867299609375 20.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1049</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>