<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9e6f61bd-2a3c-427b-a0e9-6298ace852bb">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">24.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668850056642626 139.73844885386356 0 35.6688793269779 139.7384065901675 0 35.66886571406853 139.7383924010627 0 35.66889121198103 139.73835565378755 0 35.668821352200226 139.7382828657829 0 35.66874797313217 139.73838789009503 0 35.66881779464586 139.73845794979727 0 35.66883490096362 139.738432855031 0 35.668850056642626 139.73844885386356 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668850056642626 139.73844885386356 18.19 35.66883490096362 139.738432855031 18.19 35.66881779464586 139.73845794979727 18.19 35.66874797313217 139.73838789009503 18.19 35.668821352200226 139.7382828657829 18.19 35.66889121198103 139.73835565378755 18.19 35.66886571406853 139.7383924010627 18.19 35.6688793269779 139.7384065901675 18.19 35.668850056642626 139.73844885386356 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668850056642626 139.73844885386356 18.19 35.6688793269779 139.7384065901675 18.19 35.6688793269779 139.7384065901675 42.98 35.668850056642626 139.73844885386356 42.98 35.668850056642626 139.73844885386356 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6688793269779 139.7384065901675 18.19 35.66886571406853 139.7383924010627 18.19 35.66886571406853 139.7383924010627 42.98 35.6688793269779 139.7384065901675 42.98 35.6688793269779 139.7384065901675 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66886571406853 139.7383924010627 18.19 35.66889121198103 139.73835565378755 18.19 35.66889121198103 139.73835565378755 42.98 35.66886571406853 139.7383924010627 42.98 35.66886571406853 139.7383924010627 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66889121198103 139.73835565378755 18.19 35.668821352200226 139.7382828657829 18.19 35.668821352200226 139.7382828657829 42.98 35.66889121198103 139.73835565378755 42.98 35.66889121198103 139.73835565378755 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668821352200226 139.7382828657829 18.19 35.66874797313217 139.73838789009503 18.19 35.66874797313217 139.73838789009503 42.98 35.668821352200226 139.7382828657829 42.98 35.668821352200226 139.7382828657829 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66874797313217 139.73838789009503 18.19 35.66881779464586 139.73845794979727 18.19 35.66881779464586 139.73845794979727 42.98 35.66874797313217 139.73838789009503 42.98 35.66874797313217 139.73838789009503 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881779464586 139.73845794979727 18.19 35.66883490096362 139.738432855031 18.19 35.66883490096362 139.738432855031 42.98 35.66881779464586 139.73845794979727 42.98 35.66881779464586 139.73845794979727 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66883490096362 139.738432855031 18.19 35.668850056642626 139.73844885386356 18.19 35.668850056642626 139.73844885386356 42.98 35.66883490096362 139.738432855031 42.98 35.66883490096362 139.738432855031 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668850056642626 139.73844885386356 42.98 35.6688793269779 139.7384065901675 42.98 35.66886571406853 139.7383924010627 42.98 35.66889121198103 139.73835565378755 42.98 35.668821352200226 139.7382828657829 42.98 35.66874797313217 139.73838789009503 42.98 35.66881779464586 139.73845794979727 42.98 35.66883490096362 139.738432855031 42.98 35.668850056642626 139.73844885386356 42.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a59691d1-049b-4818-9143-7b0f1ce88d96"/>
							<gml:surfaceMember xlink:href="#poly-626064d9-62dc-4acf-bd30-58a0acb6dc52"/>
							<gml:surfaceMember xlink:href="#poly-9d7ab764-4675-40e9-bfcd-1408b339f195"/>
							<gml:surfaceMember xlink:href="#poly-6eef2ecd-5952-4b81-b650-71c416e8b1cd"/>
							<gml:surfaceMember xlink:href="#poly-2199eaa1-106b-4b2c-b34a-34adfd2f845b"/>
							<gml:surfaceMember xlink:href="#poly-b0690def-5348-4ead-a189-9547bd46d33a"/>
							<gml:surfaceMember xlink:href="#poly-70c663c1-c24b-4a59-8d8d-061e63ed6b2d"/>
							<gml:surfaceMember xlink:href="#poly-004b3b7c-2229-4511-a990-5933c1e62fe1"/>
							<gml:surfaceMember xlink:href="#poly-ab6a556b-6f43-4456-adef-c22d2296a7a9"/>
							<gml:surfaceMember xlink:href="#poly-5f4b7279-70c6-4d91-86b9-e4a6176aca99"/>
							<gml:surfaceMember xlink:href="#poly-d4d6b5da-532e-4a78-b0ab-18ddba4359bd"/>
							<gml:surfaceMember xlink:href="#poly-fda66eb0-8f21-4406-8213-cd8d7364d45a"/>
							<gml:surfaceMember xlink:href="#poly-3bc94f39-5c03-467b-b4fc-ec4043d1f946"/>
							<gml:surfaceMember xlink:href="#poly-26a4c9f3-a0b8-4f2e-aacc-73186633b9ba"/>
							<gml:surfaceMember xlink:href="#poly-6e6d3b86-23be-41ba-8223-172d776d8058"/>
							<gml:surfaceMember xlink:href="#poly-b978e7c4-7214-4e4e-ae0a-6041d6406850"/>
							<gml:surfaceMember xlink:href="#poly-40b4fd46-0db2-4a4a-85d8-6b30e273c9e7"/>
							<gml:surfaceMember xlink:href="#poly-7d372426-77d2-4d35-98aa-f56b7a92f187"/>
							<gml:surfaceMember xlink:href="#poly-a129cea4-2eaa-4ff7-834e-1fc72cbd4f78"/>
							<gml:surfaceMember xlink:href="#poly-4b7b6c34-cae3-4c91-9e5b-9dd619584880"/>
							<gml:surfaceMember xlink:href="#poly-a38c59ce-b8c5-457f-9f16-8bc614b513ed"/>
							<gml:surfaceMember xlink:href="#poly-4d14aeba-b538-496f-86cd-747187d507d6"/>
							<gml:surfaceMember xlink:href="#poly-bb6ff4fb-f353-4fd8-90c3-f16342341e4d"/>
							<gml:surfaceMember xlink:href="#poly-809a3b18-1c90-435a-965b-e157c842934e"/>
							<gml:surfaceMember xlink:href="#poly-26cff279-8cbe-4170-aac7-6cea84400318"/>
							<gml:surfaceMember xlink:href="#poly-198ccc86-cb8e-41f4-abec-968591949eff"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9e6f61bd-2a3c-427b-a0e9-6298ace852bb_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b57d18f-e8d6-4170-9f24-8583e4f5080e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887846094629 139.73840568541652 18.19 35.66886571406853 139.73839240106267 18.19 35.66889121198104 139.73835565378755 18.19 35.668904797827366 139.73836980978456 18.19 35.668879326969176 139.73840657912146 18.19 35.66887846094629 139.73840568541652 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a7e9470-efa0-4832-9b7c-30381ddf37cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a7e9470-efa0-4832-9b7c-30381ddf37cc_0">
											<gml:posList>35.66887846094629 139.73840568541652 18.19 35.66887846094629 139.73840568541652 43.191 35.66886571406853 139.73839240106267 43.191 35.66886571406853 139.73839240106267 18.19 35.66887846094629 139.73840568541652 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cedd4b9-ef7b-4f65-8c95-8b6768c6c95e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0cedd4b9-ef7b-4f65-8c95-8b6768c6c95e_0">
											<gml:posList>35.66889121198104 139.73835565378755 18.19 35.66886571406853 139.73839240106267 18.19 35.66886571406853 139.73839240106267 43.191 35.66889121198104 139.73835565378755 43.191 35.66889121198104 139.73835565378755 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d336e74-cf54-49ce-bcc9-919317a466f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d336e74-cf54-49ce-bcc9-919317a466f0_0">
											<gml:posList>35.668879326969176 139.73840657912146 43.191 35.66887846094629 139.73840568541652 43.191 35.66887846094629 139.73840568541652 18.19 35.668879326969176 139.73840657912146 18.19 35.668879326969176 139.73840657912146 43.191</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84571e8b-4a42-420b-a214-66ac4bf8b46d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84571e8b-4a42-420b-a214-66ac4bf8b46d_0">
											<gml:posList>35.668904797827366 139.73836980978456 43.191 35.66889121198104 139.73835565378755 43.191 35.66886571406853 139.73839240106267 43.191 35.66887846094629 139.73840568541652 43.191 35.668879326969176 139.73840657912146 43.191 35.668904797827366 139.73836980978456 43.191</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c42c6ca9-ae81-4748-952a-f2989d8a71eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c42c6ca9-ae81-4748-952a-f2989d8a71eb_0">
											<gml:posList>35.668904797827366 139.73836980978456 18.19 35.668904797827366 139.73836980978456 43.191 35.668879326969176 139.73840657912146 43.191 35.668879326969176 139.73840657912146 18.19 35.668904797827366 139.73836980978456 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9f299e8-0f29-4497-89eb-2e929287085c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9f299e8-0f29-4497-89eb-2e929287085c_0">
											<gml:posList>35.66889121198104 139.73835565378755 18.19 35.66889121198104 139.73835565378755 43.191 35.668904797827366 139.73836980978456 43.191 35.668904797827366 139.73836980978456 18.19 35.66889121198104 139.73835565378755 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a59691d1-049b-4818-9143-7b0f1ce88d96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a59691d1-049b-4818-9143-7b0f1ce88d96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a59691d1-049b-4818-9143-7b0f1ce88d96">
											<gml:posList>35.66874797313218 139.73838789009503 18.19 35.668821352200204 139.73828286578288 18.19 35.66889121198104 139.73835565378755 18.19 35.66886571406853 139.73839240106267 18.19 35.66887932697788 139.7384065901675 18.19 35.66885005664262 139.73844885386356 18.19 35.668834900963596 139.738432855031 18.19 35.66881779464587 139.73845794979727 18.19 35.66874797313218 139.73838789009503 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-626064d9-62dc-4acf-bd30-58a0acb6dc52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-626064d9-62dc-4acf-bd30-58a0acb6dc52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-626064d9-62dc-4acf-bd30-58a0acb6dc52">
											<gml:posList>35.66881779464587 139.73845794979727 44.026 35.66881748504603 139.73845397358775 44.026 35.668751271885384 139.73838754376183 44.026 35.66874797313218 139.73838789009503 44.026 35.66881779464587 139.73845794979727 44.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d7ab764-4675-40e9-bfcd-1408b339f195">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d7ab764-4675-40e9-bfcd-1408b339f195">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d7ab764-4675-40e9-bfcd-1408b339f195">
											<gml:posList>35.66874797313218 139.73838789009503 44.026 35.668751271885384 139.73838754376183 44.026 35.668821607749514 139.7382868751941 44.026 35.668821352200204 139.73828286578288 44.026 35.66874797313218 139.73838789009503 44.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6eef2ecd-5952-4b81-b650-71c416e8b1cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6eef2ecd-5952-4b81-b650-71c416e8b1cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6eef2ecd-5952-4b81-b650-71c416e8b1cd">
											<gml:posList>35.668821607749514 139.7382868751941 43.357 35.668751271885384 139.73838754376183 43.357 35.66881748504603 139.73845397358775 43.357 35.66883462737429 139.73842882354793 43.357 35.66884979208498 139.73844484446104 43.357 35.66887605525716 139.73840692542242 43.357 35.66886244234784 139.7383927363181 43.357 35.66888793124674 139.7383559890553 43.357 35.668821607749514 139.7382868751941 43.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2199eaa1-106b-4b2c-b34a-34adfd2f845b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2199eaa1-106b-4b2c-b34a-34adfd2f845b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2199eaa1-106b-4b2c-b34a-34adfd2f845b">
											<gml:posList>35.668834900963596 139.738432855031 44.026 35.66883462737429 139.73842882354793 44.026 35.66881748504603 139.73845397358775 44.026 35.66881779464587 139.73845794979727 44.026 35.668834900963596 139.738432855031 44.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b0690def-5348-4ead-a189-9547bd46d33a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0690def-5348-4ead-a189-9547bd46d33a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0690def-5348-4ead-a189-9547bd46d33a">
											<gml:posList>35.668834900963596 139.738432855031 44.026 35.66885005664262 139.73844885386356 44.026 35.66884979208498 139.73844484446104 44.026 35.66883462737429 139.73842882354793 44.026 35.668834900963596 139.738432855031 44.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-70c663c1-c24b-4a59-8d8d-061e63ed6b2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70c663c1-c24b-4a59-8d8d-061e63ed6b2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70c663c1-c24b-4a59-8d8d-061e63ed6b2d">
											<gml:posList>35.668821352200204 139.73828286578288 44.026 35.668821607749514 139.7382868751941 44.026 35.66888793124674 139.7383559890553 44.026 35.66889121198104 139.73835565378755 44.026 35.668821352200204 139.73828286578288 44.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-004b3b7c-2229-4511-a990-5933c1e62fe1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-004b3b7c-2229-4511-a990-5933c1e62fe1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-004b3b7c-2229-4511-a990-5933c1e62fe1">
											<gml:posList>35.66887932697788 139.7384065901675 44.026 35.66887605525716 139.73840692542242 44.026 35.66884979208498 139.73844484446104 44.026 35.66885005664262 139.73844885386356 44.026 35.66887932697788 139.7384065901675 44.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab6a556b-6f43-4456-adef-c22d2296a7a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab6a556b-6f43-4456-adef-c22d2296a7a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab6a556b-6f43-4456-adef-c22d2296a7a9">
											<gml:posList>35.66886571406853 139.73839240106267 44.026 35.66886244234784 139.7383927363181 44.026 35.66887605525716 139.73840692542242 44.026 35.66887932697788 139.7384065901675 44.026 35.66886571406853 139.73839240106267 44.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f4b7279-70c6-4d91-86b9-e4a6176aca99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f4b7279-70c6-4d91-86b9-e4a6176aca99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f4b7279-70c6-4d91-86b9-e4a6176aca99">
											<gml:posList>35.66886571406853 139.73839240106267 44.026 35.66889121198104 139.73835565378755 44.026 35.66888793124674 139.7383559890553 44.026 35.66886244234784 139.7383927363181 44.026 35.66886571406853 139.73839240106267 44.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4d6b5da-532e-4a78-b0ab-18ddba4359bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4d6b5da-532e-4a78-b0ab-18ddba4359bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4d6b5da-532e-4a78-b0ab-18ddba4359bd">
											<gml:posList>35.66889121198104 139.73835565378755 18.19 35.668821352200204 139.73828286578288 18.19 35.668821352200204 139.73828286578288 44.026 35.66889121198104 139.73835565378755 44.026 35.66889121198104 139.73835565378755 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fda66eb0-8f21-4406-8213-cd8d7364d45a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fda66eb0-8f21-4406-8213-cd8d7364d45a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fda66eb0-8f21-4406-8213-cd8d7364d45a">
											<gml:posList>35.668821607749514 139.7382868751941 44.026 35.668821607749514 139.7382868751941 43.357 35.66888793124674 139.7383559890553 43.357 35.66888793124674 139.7383559890553 44.026 35.668821607749514 139.7382868751941 44.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3bc94f39-5c03-467b-b4fc-ec4043d1f946">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bc94f39-5c03-467b-b4fc-ec4043d1f946">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bc94f39-5c03-467b-b4fc-ec4043d1f946">
											<gml:posList>35.668821352200204 139.73828286578288 18.19 35.66874797313218 139.73838789009503 18.19 35.66874797313218 139.73838789009503 44.026 35.668821352200204 139.73828286578288 44.026 35.668821352200204 139.73828286578288 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26a4c9f3-a0b8-4f2e-aacc-73186633b9ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26a4c9f3-a0b8-4f2e-aacc-73186633b9ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26a4c9f3-a0b8-4f2e-aacc-73186633b9ba">
											<gml:posList>35.668751271885384 139.73838754376183 44.026 35.668751271885384 139.73838754376183 43.357 35.668821607749514 139.7382868751941 43.357 35.668821607749514 139.7382868751941 44.026 35.668751271885384 139.73838754376183 44.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e6d3b86-23be-41ba-8223-172d776d8058">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e6d3b86-23be-41ba-8223-172d776d8058">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e6d3b86-23be-41ba-8223-172d776d8058">
											<gml:posList>35.66886571406853 139.73839240106267 18.19 35.66889121198104 139.73835565378755 18.19 35.66889121198104 139.73835565378755 44.026 35.66886571406853 139.73839240106267 44.026 35.66886571406853 139.73839240106267 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b978e7c4-7214-4e4e-ae0a-6041d6406850">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b978e7c4-7214-4e4e-ae0a-6041d6406850">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b978e7c4-7214-4e4e-ae0a-6041d6406850">
											<gml:posList>35.66888793124674 139.7383559890553 44.026 35.66888793124674 139.7383559890553 43.357 35.66886244234784 139.7383927363181 43.357 35.66886244234784 139.7383927363181 44.026 35.66888793124674 139.7383559890553 44.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40b4fd46-0db2-4a4a-85d8-6b30e273c9e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40b4fd46-0db2-4a4a-85d8-6b30e273c9e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40b4fd46-0db2-4a4a-85d8-6b30e273c9e7">
											<gml:posList>35.66887932697788 139.7384065901675 18.19 35.66886571406853 139.73839240106267 18.19 35.66886571406853 139.73839240106267 44.026 35.66887932697788 139.7384065901675 44.026 35.66887932697788 139.7384065901675 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d372426-77d2-4d35-98aa-f56b7a92f187">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d372426-77d2-4d35-98aa-f56b7a92f187">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d372426-77d2-4d35-98aa-f56b7a92f187">
											<gml:posList>35.66886244234784 139.7383927363181 44.026 35.66886244234784 139.7383927363181 43.357 35.66887605525716 139.73840692542242 43.357 35.66887605525716 139.73840692542242 44.026 35.66886244234784 139.7383927363181 44.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a129cea4-2eaa-4ff7-834e-1fc72cbd4f78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a129cea4-2eaa-4ff7-834e-1fc72cbd4f78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a129cea4-2eaa-4ff7-834e-1fc72cbd4f78">
											<gml:posList>35.66881748504603 139.73845397358775 44.026 35.66881748504603 139.73845397358775 43.357 35.668751271885384 139.73838754376183 43.357 35.668751271885384 139.73838754376183 44.026 35.66881748504603 139.73845397358775 44.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b7b6c34-cae3-4c91-9e5b-9dd619584880">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b7b6c34-cae3-4c91-9e5b-9dd619584880">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b7b6c34-cae3-4c91-9e5b-9dd619584880">
											<gml:posList>35.66874797313218 139.73838789009503 18.19 35.66881779464587 139.73845794979727 18.19 35.66881779464587 139.73845794979727 44.026 35.66874797313218 139.73838789009503 44.026 35.66874797313218 139.73838789009503 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a38c59ce-b8c5-457f-9f16-8bc614b513ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a38c59ce-b8c5-457f-9f16-8bc614b513ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a38c59ce-b8c5-457f-9f16-8bc614b513ed">
											<gml:posList>35.66887605525716 139.73840692542242 44.026 35.66887605525716 139.73840692542242 43.357 35.66884979208498 139.73844484446104 43.357 35.66884979208498 139.73844484446104 44.026 35.66887605525716 139.73840692542242 44.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d14aeba-b538-496f-86cd-747187d507d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d14aeba-b538-496f-86cd-747187d507d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d14aeba-b538-496f-86cd-747187d507d6">
											<gml:posList>35.66885005664262 139.73844885386356 18.19 35.66887932697788 139.7384065901675 18.19 35.66887932697788 139.7384065901675 44.026 35.66885005664262 139.73844885386356 44.026 35.66885005664262 139.73844885386356 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb6ff4fb-f353-4fd8-90c3-f16342341e4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb6ff4fb-f353-4fd8-90c3-f16342341e4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb6ff4fb-f353-4fd8-90c3-f16342341e4d">
											<gml:posList>35.66884979208498 139.73844484446104 44.026 35.66884979208498 139.73844484446104 43.357 35.66883462737429 139.73842882354793 43.357 35.66883462737429 139.73842882354793 44.026 35.66884979208498 139.73844484446104 44.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-809a3b18-1c90-435a-965b-e157c842934e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-809a3b18-1c90-435a-965b-e157c842934e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-809a3b18-1c90-435a-965b-e157c842934e">
											<gml:posList>35.668834900963596 139.738432855031 18.19 35.66885005664262 139.73844885386356 18.19 35.66885005664262 139.73844885386356 44.026 35.668834900963596 139.738432855031 44.026 35.668834900963596 139.738432855031 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26cff279-8cbe-4170-aac7-6cea84400318">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26cff279-8cbe-4170-aac7-6cea84400318">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26cff279-8cbe-4170-aac7-6cea84400318">
											<gml:posList>35.66883462737429 139.73842882354793 44.026 35.66883462737429 139.73842882354793 43.357 35.66881748504603 139.73845397358775 43.357 35.66881748504603 139.73845397358775 44.026 35.66883462737429 139.73842882354793 44.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-198ccc86-cb8e-41f4-abec-968591949eff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-198ccc86-cb8e-41f4-abec-968591949eff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-198ccc86-cb8e-41f4-abec-968591949eff">
											<gml:posList>35.66881779464587 139.73845794979727 18.19 35.668834900963596 139.738432855031 18.19 35.668834900963596 139.738432855031 44.026 35.66881779464587 139.73845794979727 44.026 35.66881779464587 139.73845794979727 18.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6661</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">144.5843</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>