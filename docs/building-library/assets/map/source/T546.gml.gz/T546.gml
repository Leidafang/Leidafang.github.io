<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9ec43dfb-4045-4cdb-96e8-0b40387126c7">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">15.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67018513005086 139.7381690193421 0 35.67028389372896 139.7381351006055 0 35.67023505045367 139.73792141387045 0 35.67013619669813 139.73795533295657 0 35.67018513005086 139.7381690193421 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67018513005086 139.7381690193421 17.517 35.67013619669813 139.73795533295657 17.517 35.67023505045367 139.73792141387045 17.517 35.67028389372896 139.7381351006055 17.517 35.67018513005086 139.7381690193421 17.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67018513005086 139.7381690193421 17.517 35.67028389372896 139.7381351006055 17.517 35.67028389372896 139.7381351006055 33.28 35.67018513005086 139.7381690193421 33.28 35.67018513005086 139.7381690193421 17.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67028389372896 139.7381351006055 17.517 35.67023505045367 139.73792141387045 17.517 35.67023505045367 139.73792141387045 33.28 35.67028389372896 139.7381351006055 33.28 35.67028389372896 139.7381351006055 17.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67023505045367 139.73792141387045 17.517 35.67013619669813 139.73795533295657 17.517 35.67013619669813 139.73795533295657 33.28 35.67023505045367 139.73792141387045 33.28 35.67023505045367 139.73792141387045 17.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013619669813 139.73795533295657 17.517 35.67018513005086 139.7381690193421 17.517 35.67018513005086 139.7381690193421 33.28 35.67013619669813 139.73795533295657 33.28 35.67013619669813 139.73795533295657 17.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67018513005086 139.7381690193421 33.28 35.67028389372896 139.7381351006055 33.28 35.67023505045367 139.73792141387045 33.28 35.67013619669813 139.73795533295657 33.28 35.67018513005086 139.7381690193421 33.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6d61b9ea-ef04-446a-a5bf-bc481cfbdc6d"/>
							<gml:surfaceMember xlink:href="#poly-6acfc9cd-0c95-4a4c-b64f-4754ff20dbfb"/>
							<gml:surfaceMember xlink:href="#poly-26d79ad7-6dee-4232-aca9-6652b58c3d6e"/>
							<gml:surfaceMember xlink:href="#poly-d32f617f-4e7a-4c32-bd93-836636cd227e"/>
							<gml:surfaceMember xlink:href="#poly-d8f6ba3d-7b54-4fe6-b2e5-6bac0da59d69"/>
							<gml:surfaceMember xlink:href="#poly-d4cde5ad-2286-4094-8c2c-3a92d236b1d5"/>
							<gml:surfaceMember xlink:href="#poly-09b5e178-6c30-4d0d-9294-54997aaab566"/>
							<gml:surfaceMember xlink:href="#poly-5324a8be-09f1-41a3-bdc3-32c422c5a674"/>
							<gml:surfaceMember xlink:href="#poly-6fea5581-8b50-4896-afda-9b7333840040"/>
							<gml:surfaceMember xlink:href="#poly-f7718c7c-498d-422b-be6b-82d7bd4e0b4f"/>
							<gml:surfaceMember xlink:href="#poly-d7cceeb5-1cc0-4c6d-bda8-057abcc180b8"/>
							<gml:surfaceMember xlink:href="#poly-9d9591ab-935d-4090-b358-24c2aaaa40ba"/>
							<gml:surfaceMember xlink:href="#poly-9f6b15d8-b3cf-48d5-990a-2b7defcb1cfa"/>
							<gml:surfaceMember xlink:href="#poly-89ced041-3a29-42a9-b948-c3a163ec3268"/>
							<gml:surfaceMember xlink:href="#poly-71c86d76-5cd6-46b0-bf26-5b9274a060bc"/>
							<gml:surfaceMember xlink:href="#poly-db674a41-40d7-46b6-96f8-6493868e6cf6"/>
							<gml:surfaceMember xlink:href="#poly-e7f910f9-064a-4896-bb8f-4a8a79fbf936"/>
							<gml:surfaceMember xlink:href="#poly-a216150e-a3ed-42e9-8f37-b3d45c23880c"/>
							<gml:surfaceMember xlink:href="#poly-d242159f-afe9-4dbb-927c-ee448b612f10"/>
							<gml:surfaceMember xlink:href="#poly-f522ab67-068e-4950-b972-b961f46e8904"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9ec43dfb-4045-4cdb-96e8-0b40387126c7_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eeff422f-8eba-4229-b3aa-9e63713efe67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67024498025017 139.73807659068765 34.405 35.67022109049097 139.73808372180085 34.405 35.670201371323714 139.73808735734545 34.405 35.670200565895705 139.7380833043342 34.405 35.67021081140474 139.73807938179525 34.405 35.67022344232546 139.73807138035951 34.405 35.67024279022536 139.73806559123423 34.405 35.67024498025017 139.73807659068765 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06a261e7-02f0-4704-91ae-13df82ff3eb8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67024707928921 139.7380865187644 34.405 35.670250925899545 139.73810646370677 34.405 35.67024364446298 139.73810856009433 34.405 35.670239806875436 139.73808862618918 34.405 35.67024707928921 139.7380865187644 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d93ac10-47cb-459a-a056-e053ae5a0a16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021039532296 139.7380775486144 34.405 35.670182009568464 139.73808702686645 34.405 35.67018055921544 139.73808811112005 34.405 35.67018012739555 139.73808917207128 34.405 35.670180191741025 139.73809075160597 34.405 35.6701885501297 139.73812830991488 34.405 35.670183224242486 139.73812986271145 34.405 35.67017387985492 139.73808787603753 34.405 35.67017372470812 139.7380854570973 34.405 35.67017433591118 139.73808326921753 34.405 35.67017586694203 139.73808162151025 34.405 35.67020884847107 139.73807059132372 34.405 35.67021039532296 139.7380775486144 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ee56706-1bf6-4664-a40e-e3cae48905ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67022353979136 139.73810343642526 34.405 35.67020954416248 139.73810684424268 34.405 35.670208339466804 139.7380994226032 34.405 35.670222335086734 139.73809600373835 34.405 35.67022353979136 139.73810343642526 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d178acb7-d406-449a-91ad-173b9243edb4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67024415179088 139.73811179604027 34.405 35.670253965253615 139.73810864725283 34.405 35.67025801839859 139.7381276088372 34.405 35.670248204935376 139.73813075762246 34.405 35.67024415179088 139.73811179604027 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-366fdc11-94ff-4086-b0b9-9e72264888df">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67023360720286 139.7381364637688 34.405 35.67021959385127 139.7381402582202 34.405 35.67021589101187 139.73811973870892 34.405 35.67022991337656 139.7381159442434 34.405 35.67023360720286 139.7381364637688 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42b57e54-a896-4b51-be2b-5534830ca2a7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021552841907 139.73812855403625 34.405 35.67021723897303 139.7381373558558 34.405 35.670206830516484 139.73814039488232 34.405 35.670205119962745 139.73813159306383 34.405 35.67021552841907 139.73812855403625 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef24d8ef-4c9c-4227-bf96-3ab35c0151ef">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670203626619866 139.73812390665753 34.405 35.670209337507835 139.73815328286287 34.405 35.67019310818563 139.73815885838422 34.405 35.670189125037076 139.73816002296684 34.405 35.67018227801997 139.73813013999077 34.405 35.670203626619866 139.73812390665753 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c63558b5-f7df-4fa7-8442-73c0aa63f28b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c63558b5-f7df-4fa7-8442-73c0aa63f28b_0">
											<gml:posList>35.67024364446298 139.73810856009433 34.405 35.670250925899545 139.73810646370677 34.405 35.670250925899545 139.73810646370677 35.642 35.67024364446298 139.73810856009433 35.642 35.67024364446298 139.73810856009433 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e9caa7e-94dd-428c-847b-baa03256e8a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e9caa7e-94dd-428c-847b-baa03256e8a1_0">
											<gml:posList>35.670183224242486 139.73812986271145 34.405 35.6701885501297 139.73812830991488 34.405 35.6701885501297 139.73812830991488 34.803 35.670183224242486 139.73812986271145 34.803 35.670183224242486 139.73812986271145 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b8937d7-e2bc-474c-bad9-b8a3382ac90b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b8937d7-e2bc-474c-bad9-b8a3382ac90b_0">
											<gml:posList>35.67021723897303 139.7381373558558 34.405 35.67021552841907 139.73812855403625 34.405 35.67021552841907 139.73812855403625 34.874 35.67021723897303 139.7381373558558 34.874 35.67021723897303 139.7381373558558 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44f58dc4-de22-4de6-b5a5-746b4bfaf608">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44f58dc4-de22-4de6-b5a5-746b4bfaf608_0">
											<gml:posList>35.670205119962745 139.73813159306383 34.405 35.670206830516484 139.73814039488232 34.405 35.670206830516484 139.73814039488232 34.874 35.670205119962745 139.73813159306383 34.874 35.670205119962745 139.73813159306383 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05aa270b-4320-4d5a-8193-1113c9bd1a0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05aa270b-4320-4d5a-8193-1113c9bd1a0f_0">
											<gml:posList>35.67024279022536 139.73806559123423 34.405 35.67022344232546 139.73807138035951 34.405 35.67022344232546 139.73807138035951 35.35 35.67024279022536 139.73806559123423 35.35 35.67024279022536 139.73806559123423 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f18eac6f-3d8b-492c-a2eb-603a7d4c436e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f18eac6f-3d8b-492c-a2eb-603a7d4c436e_0">
											<gml:posList>35.67024279022536 139.73806559123423 34.405 35.67024279022536 139.73806559123423 35.35 35.67024498025017 139.73807659068765 35.35 35.67024498025017 139.73807659068765 34.405 35.67024279022536 139.73806559123423 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bd0c90b-ff6a-4fd0-b209-8fe400733e4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bd0c90b-ff6a-4fd0-b209-8fe400733e4a_0">
											<gml:posList>35.67021039532296 139.7380775486144 34.405 35.67020884847107 139.73807059132372 34.405 35.67020884847107 139.73807059132372 34.803 35.67021039532296 139.7380775486144 34.803 35.67021039532296 139.7380775486144 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cac05734-5c18-4893-945a-42ea3f919189">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cac05734-5c18-4893-945a-42ea3f919189_0">
											<gml:posList>35.67022344232546 139.73807138035951 34.405 35.67021081140474 139.73807938179525 34.405 35.67021081140474 139.73807938179525 35.35 35.67022344232546 139.73807138035951 35.35 35.67022344232546 139.73807138035951 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86df4f7d-cd9c-4e04-969c-e24da2c01a3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86df4f7d-cd9c-4e04-969c-e24da2c01a3a_0">
											<gml:posList>35.67020884847107 139.73807059132372 34.405 35.67017586694203 139.73808162151025 34.405 35.67017586694203 139.73808162151025 34.803 35.67020884847107 139.73807059132372 34.803 35.67020884847107 139.73807059132372 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ef90408-50fe-4155-adb0-bf4d95b9e6c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ef90408-50fe-4155-adb0-bf4d95b9e6c7_0">
											<gml:posList>35.67022344232546 139.73807138035951 35.35 35.67021081140474 139.73807938179525 35.35 35.670200565895705 139.7380833043342 35.35 35.670201371323714 139.73808735734545 35.35 35.67022109049097 139.73808372180085 35.35 35.67024498025017 139.73807659068765 35.35 35.67024279022536 139.73806559123423 35.35 35.67022344232546 139.73807138035951 35.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7735ab6a-7899-4805-8c33-35b3d78615e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7735ab6a-7899-4805-8c33-35b3d78615e4_0">
											<gml:posList>35.67022109049097 139.73808372180085 34.405 35.67024498025017 139.73807659068765 34.405 35.67024498025017 139.73807659068765 35.35 35.67022109049097 139.73808372180085 35.35 35.67022109049097 139.73808372180085 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-126091c3-0055-4c52-821e-069939b3ff28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-126091c3-0055-4c52-821e-069939b3ff28_0">
											<gml:posList>35.67021081140474 139.73807938179525 34.405 35.670200565895705 139.7380833043342 34.405 35.670200565895705 139.7380833043342 35.35 35.67021081140474 139.73807938179525 35.35 35.67021081140474 139.73807938179525 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-371036db-4aef-4bd7-b0bb-46490afb5d8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-371036db-4aef-4bd7-b0bb-46490afb5d8b_0">
											<gml:posList>35.670182009568464 139.73808702686645 34.405 35.67021039532296 139.7380775486144 34.405 35.67021039532296 139.7380775486144 34.803 35.670182009568464 139.73808702686645 34.803 35.670182009568464 139.73808702686645 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34b2fc94-ab50-4a03-99fe-bf88135d65bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34b2fc94-ab50-4a03-99fe-bf88135d65bf_0">
											<gml:posList>35.67017586694203 139.73808162151025 34.405 35.67017433591118 139.73808326921753 34.405 35.67017433591118 139.73808326921753 34.803 35.67017586694203 139.73808162151025 34.803 35.67017586694203 139.73808162151025 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6dbc3e63-7d83-427f-9e95-5196aeb12527">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6dbc3e63-7d83-427f-9e95-5196aeb12527_0">
											<gml:posList>35.67017433591118 139.73808326921753 34.405 35.67017372470812 139.7380854570973 34.405 35.67017372470812 139.7380854570973 34.803 35.67017433591118 139.73808326921753 34.803 35.67017433591118 139.73808326921753 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e71816c1-29b1-4d7e-97d2-828056db9b54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e71816c1-29b1-4d7e-97d2-828056db9b54_0">
											<gml:posList>35.670200565895705 139.7380833043342 34.405 35.670201371323714 139.73808735734545 34.405 35.670201371323714 139.73808735734545 35.35 35.670200565895705 139.7380833043342 35.35 35.670200565895705 139.7380833043342 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bea4aa87-e634-4b4b-8d10-069f32dfc143">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bea4aa87-e634-4b4b-8d10-069f32dfc143_0">
											<gml:posList>35.670201371323714 139.73808735734545 34.405 35.67022109049097 139.73808372180085 34.405 35.67022109049097 139.73808372180085 35.35 35.670201371323714 139.73808735734545 35.35 35.670201371323714 139.73808735734545 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32556e69-f96c-47b6-ae4f-3a0f40b2cc14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32556e69-f96c-47b6-ae4f-3a0f40b2cc14_0">
											<gml:posList>35.67017372470812 139.7380854570973 34.405 35.67017387985492 139.73808787603753 34.405 35.67017387985492 139.73808787603753 34.803 35.67017372470812 139.7380854570973 34.803 35.67017372470812 139.7380854570973 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-492abd4d-ce53-49eb-ac18-00f0e0aa4293">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-492abd4d-ce53-49eb-ac18-00f0e0aa4293_0">
											<gml:posList>35.67018055921544 139.73808811112005 34.405 35.670182009568464 139.73808702686645 34.405 35.670182009568464 139.73808702686645 34.803 35.67018055921544 139.73808811112005 34.803 35.67018055921544 139.73808811112005 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd16ff0e-db1e-433d-aa46-fec8af0cafc0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd16ff0e-db1e-433d-aa46-fec8af0cafc0_0">
											<gml:posList>35.67024707928921 139.7380865187644 34.405 35.670239806875436 139.73808862618918 34.405 35.670239806875436 139.73808862618918 35.642 35.67024707928921 139.7380865187644 35.642 35.67024707928921 139.7380865187644 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51458acb-d17a-49c2-afc0-22566cee8f16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51458acb-d17a-49c2-afc0-22566cee8f16_0">
											<gml:posList>35.67018012739555 139.73808917207128 34.405 35.67018055921544 139.73808811112005 34.405 35.67018055921544 139.73808811112005 34.803 35.67018012739555 139.73808917207128 34.803 35.67018012739555 139.73808917207128 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-882239df-b16c-4340-ae80-d715e0ee957e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-882239df-b16c-4340-ae80-d715e0ee957e_0">
											<gml:posList>35.670180191741025 139.73809075160597 34.405 35.67018012739555 139.73808917207128 34.405 35.67018012739555 139.73808917207128 34.803 35.670180191741025 139.73809075160597 34.803 35.670180191741025 139.73809075160597 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84fdbe16-3050-462d-a713-5536fd3dc4c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84fdbe16-3050-462d-a713-5536fd3dc4c8_0">
											<gml:posList>35.670250925899545 139.73810646370677 34.405 35.67024707928921 139.7380865187644 34.405 35.67024707928921 139.7380865187644 35.642 35.670250925899545 139.73810646370677 35.642 35.670250925899545 139.73810646370677 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3044672b-73ce-4b70-ba15-fa967571e0e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3044672b-73ce-4b70-ba15-fa967571e0e2_0">
											<gml:posList>35.67024707928921 139.7380865187644 35.642 35.670239806875436 139.73808862618918 35.642 35.67024364446298 139.73810856009433 35.642 35.670250925899545 139.73810646370677 35.642 35.67024707928921 139.7380865187644 35.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f83e8b1-7ea3-4638-94b8-2634feef7802">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f83e8b1-7ea3-4638-94b8-2634feef7802_0">
											<gml:posList>35.670222335086734 139.73809600373835 34.405 35.670208339466804 139.7380994226032 34.405 35.670208339466804 139.7380994226032 35.642 35.670222335086734 139.73809600373835 35.642 35.670222335086734 139.73809600373835 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a036dc37-8cfa-45f8-92f2-d7635f17b44c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a036dc37-8cfa-45f8-92f2-d7635f17b44c_0">
											<gml:posList>35.670239806875436 139.73808862618918 34.405 35.67024364446298 139.73810856009433 34.405 35.67024364446298 139.73810856009433 35.642 35.670239806875436 139.73808862618918 35.642 35.670239806875436 139.73808862618918 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09b01336-2448-4152-acd1-ea4da9d81224">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09b01336-2448-4152-acd1-ea4da9d81224_0">
											<gml:posList>35.67022353979136 139.73810343642526 34.405 35.670222335086734 139.73809600373835 34.405 35.670222335086734 139.73809600373835 35.642 35.67022353979136 139.73810343642526 35.642 35.67022353979136 139.73810343642526 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b98ea302-ac4f-40e3-b9b8-533334d9a539">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b98ea302-ac4f-40e3-b9b8-533334d9a539_0">
											<gml:posList>35.67017586694203 139.73808162151025 34.803 35.67017433591118 139.73808326921753 34.803 35.67017372470812 139.7380854570973 34.803 35.67017387985492 139.73808787603753 34.803 35.670183224242486 139.73812986271145 34.803 35.6701885501297 139.73812830991488 34.803 35.670180191741025 139.73809075160597 34.803 35.67018012739555 139.73808917207128 34.803 35.67018055921544 139.73808811112005 34.803 35.670182009568464 139.73808702686645 34.803 35.67021039532296 139.7380775486144 34.803 35.67020884847107 139.73807059132372 34.803 35.67017586694203 139.73808162151025 34.803</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f23385b-7aad-4c8d-b6cd-a63be64a0e59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f23385b-7aad-4c8d-b6cd-a63be64a0e59_0">
											<gml:posList>35.670208339466804 139.7380994226032 35.642 35.67020954416248 139.73810684424268 35.642 35.67022353979136 139.73810343642526 35.642 35.670222335086734 139.73809600373835 35.642 35.670208339466804 139.7380994226032 35.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ab022fc-0343-474f-a17d-e04c566bac70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ab022fc-0343-474f-a17d-e04c566bac70_0">
											<gml:posList>35.670208339466804 139.7380994226032 34.405 35.67020954416248 139.73810684424268 34.405 35.67020954416248 139.73810684424268 35.642 35.670208339466804 139.7380994226032 35.642 35.670208339466804 139.7380994226032 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53bdd6b4-5220-40b6-8b28-a2d1e3eed7a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53bdd6b4-5220-40b6-8b28-a2d1e3eed7a5_0">
											<gml:posList>35.67020954416248 139.73810684424268 34.405 35.67022353979136 139.73810343642526 34.405 35.67022353979136 139.73810343642526 35.642 35.67020954416248 139.73810684424268 35.642 35.67020954416248 139.73810684424268 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ace1eca-8f09-4d5e-81a2-bed08170e084">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ace1eca-8f09-4d5e-81a2-bed08170e084_0">
											<gml:posList>35.67017387985492 139.73808787603753 34.405 35.670183224242486 139.73812986271145 34.405 35.670183224242486 139.73812986271145 34.803 35.67017387985492 139.73808787603753 34.803 35.67017387985492 139.73808787603753 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a7bb694-50de-4941-b2bf-a5d2e6efca09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a7bb694-50de-4941-b2bf-a5d2e6efca09_0">
											<gml:posList>35.6701885501297 139.73812830991488 34.405 35.670180191741025 139.73809075160597 34.405 35.670180191741025 139.73809075160597 34.803 35.6701885501297 139.73812830991488 34.803 35.6701885501297 139.73812830991488 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c8f7b5f-2246-4d2a-ac8d-9cd28d47c54a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c8f7b5f-2246-4d2a-ac8d-9cd28d47c54a_0">
											<gml:posList>35.670253965253615 139.73810864725283 34.405 35.67024415179088 139.73811179604027 34.405 35.67024415179088 139.73811179604027 36.246 35.670253965253615 139.73810864725283 36.246 35.670253965253615 139.73810864725283 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-665a47be-5057-4cc9-9c15-39d9f44ad2d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-665a47be-5057-4cc9-9c15-39d9f44ad2d8_0">
											<gml:posList>35.67022991337656 139.7381159442434 34.405 35.67021589101187 139.73811973870892 34.405 35.67021589101187 139.73811973870892 36.93 35.67022991337656 139.7381159442434 36.93 35.67022991337656 139.7381159442434 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bb635f4-b61d-4535-8997-72d6ac2dd491">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bb635f4-b61d-4535-8997-72d6ac2dd491_0">
											<gml:posList>35.67025801839859 139.7381276088372 34.405 35.670253965253615 139.73810864725283 34.405 35.670253965253615 139.73810864725283 36.246 35.67025801839859 139.7381276088372 36.246 35.67025801839859 139.7381276088372 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf3438bb-8872-4015-8e71-28317bcf04b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf3438bb-8872-4015-8e71-28317bcf04b2_0">
											<gml:posList>35.67024415179088 139.73811179604027 36.246 35.670248204935376 139.73813075762246 36.246 35.67025801839859 139.7381276088372 36.246 35.670253965253615 139.73810864725283 36.246 35.67024415179088 139.73811179604027 36.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbb4220e-0686-41d3-a796-98359d11b85d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbb4220e-0686-41d3-a796-98359d11b85d_0">
											<gml:posList>35.67024415179088 139.73811179604027 34.405 35.670248204935376 139.73813075762246 34.405 35.670248204935376 139.73813075762246 36.246 35.67024415179088 139.73811179604027 36.246 35.67024415179088 139.73811179604027 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdfb00c9-1359-41e5-b4e5-354e243e6d37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdfb00c9-1359-41e5-b4e5-354e243e6d37_0">
											<gml:posList>35.67023360720286 139.7381364637688 34.405 35.67022991337656 139.7381159442434 34.405 35.67022991337656 139.7381159442434 36.93 35.67023360720286 139.7381364637688 36.93 35.67023360720286 139.7381364637688 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80aa9d01-ec98-4afb-9225-e82a3eff8c81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80aa9d01-ec98-4afb-9225-e82a3eff8c81_0">
											<gml:posList>35.67018227801997 139.73813013999077 34.405 35.67018227801997 139.73813013999077 35.229 35.670203626619866 139.73812390665753 35.229 35.670203626619866 139.73812390665753 34.405 35.67018227801997 139.73813013999077 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-189e5abc-de73-4e71-acd1-e4483d787969">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-189e5abc-de73-4e71-acd1-e4483d787969_0">
											<gml:posList>35.67023360720286 139.7381364637688 36.93 35.67022991337656 139.7381159442434 36.93 35.67021589101187 139.73811973870892 36.93 35.67021959385127 139.7381402582202 36.93 35.67023360720286 139.7381364637688 36.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82fbb105-b0c1-4507-8e7b-aa9c8fcf42c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82fbb105-b0c1-4507-8e7b-aa9c8fcf42c6_0">
											<gml:posList>35.670248204935376 139.73813075762246 34.405 35.67025801839859 139.7381276088372 34.405 35.67025801839859 139.7381276088372 36.246 35.670248204935376 139.73813075762246 36.246 35.670248204935376 139.73813075762246 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf81426e-5a86-4d72-814f-8dd3a803ccf6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf81426e-5a86-4d72-814f-8dd3a803ccf6_0">
											<gml:posList>35.67021589101187 139.73811973870892 34.405 35.67021959385127 139.7381402582202 34.405 35.67021959385127 139.7381402582202 36.93 35.67021589101187 139.73811973870892 36.93 35.67021589101187 139.73811973870892 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d405128-d372-4638-b4ac-9ffcad2e1f43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d405128-d372-4638-b4ac-9ffcad2e1f43_0">
											<gml:posList>35.670205119962745 139.73813159306383 34.405 35.670205119962745 139.73813159306383 34.874 35.67021552841907 139.73812855403625 34.874 35.67021552841907 139.73812855403625 34.405 35.670205119962745 139.73813159306383 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-986d8065-c43e-44b0-9f6d-c126f143534f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-986d8065-c43e-44b0-9f6d-c126f143534f_0">
											<gml:posList>35.67021552841907 139.73812855403625 34.874 35.670205119962745 139.73813159306383 34.874 35.670206830516484 139.73814039488232 34.874 35.67021723897303 139.7381373558558 34.874 35.67021552841907 139.73812855403625 34.874</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19cc556c-df3a-43fa-a02e-6ec8285e9906">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19cc556c-df3a-43fa-a02e-6ec8285e9906_0">
											<gml:posList>35.67021959385127 139.7381402582202 34.405 35.67023360720286 139.7381364637688 34.405 35.67023360720286 139.7381364637688 36.93 35.67021959385127 139.7381402582202 36.93 35.67021959385127 139.7381402582202 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84f2e1a5-3b20-4e5a-bb91-2da9769e76b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84f2e1a5-3b20-4e5a-bb91-2da9769e76b8_0">
											<gml:posList>35.670203626619866 139.73812390665753 34.405 35.670203626619866 139.73812390665753 35.229 35.670209337507835 139.73815328286287 35.229 35.670209337507835 139.73815328286287 34.405 35.670203626619866 139.73812390665753 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d23b234f-a21e-4ec9-b010-7d9ba9a7f96c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d23b234f-a21e-4ec9-b010-7d9ba9a7f96c_0">
											<gml:posList>35.670206830516484 139.73814039488232 34.405 35.67021723897303 139.7381373558558 34.405 35.67021723897303 139.7381373558558 34.874 35.670206830516484 139.73814039488232 34.874 35.670206830516484 139.73814039488232 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-614dcab6-ff14-4819-87dd-3f517fdd28f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-614dcab6-ff14-4819-87dd-3f517fdd28f7_0">
											<gml:posList>35.670189125037076 139.73816002296684 35.229 35.67019310818563 139.73815885838422 35.229 35.670209337507835 139.73815328286287 35.229 35.670203626619866 139.73812390665753 35.229 35.67018227801997 139.73813013999077 35.229 35.670189125037076 139.73816002296684 35.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fb21770-4b7d-45fc-a333-7253ae6946b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fb21770-4b7d-45fc-a333-7253ae6946b5_0">
											<gml:posList>35.670189125037076 139.73816002296684 35.229 35.67018227801997 139.73813013999077 35.229 35.67018227801997 139.73813013999077 34.405 35.670189125037076 139.73816002296684 34.405 35.670189125037076 139.73816002296684 35.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfb8f0f8-a970-40cb-9d60-e20ffbb216b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfb8f0f8-a970-40cb-9d60-e20ffbb216b2_0">
											<gml:posList>35.67019310818563 139.73815885838422 34.405 35.670209337507835 139.73815328286287 34.405 35.670209337507835 139.73815328286287 35.229 35.67019310818563 139.73815885838422 35.229 35.67019310818563 139.73815885838422 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9adda97-0d37-496c-bd7c-9c04a6d1a9e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9adda97-0d37-496c-bd7c-9c04a6d1a9e9_0">
											<gml:posList>35.67019310818563 139.73815885838422 35.229 35.670189125037076 139.73816002296684 35.229 35.670189125037076 139.73816002296684 34.405 35.67019310818563 139.73815885838422 34.405 35.67019310818563 139.73815885838422 35.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6d61b9ea-ef04-446a-a5bf-bc481cfbdc6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d61b9ea-ef04-446a-a5bf-bc481cfbdc6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d61b9ea-ef04-446a-a5bf-bc481cfbdc6d">
											<gml:posList>35.67018513005086 139.7381690193421 17.517 35.67013619669812 139.73795533295657 17.517 35.670235050453655 139.73792141387045 17.517 35.67028389372894 139.73813510060552 17.517 35.67018513005086 139.7381690193421 17.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6acfc9cd-0c95-4a4c-b64f-4754ff20dbfb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6acfc9cd-0c95-4a4c-b64f-4754ff20dbfb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6acfc9cd-0c95-4a4c-b64f-4754ff20dbfb">
											<gml:posList>35.67013619669812 139.73795533295657 35.788 35.670143375549614 139.73796028417252 35.788 35.670231019281665 139.73793022251974 35.788 35.670235050453655 139.73792141387045 35.788 35.67013619669812 139.73795533295657 35.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26d79ad7-6dee-4232-aca9-6652b58c3d6e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26d79ad7-6dee-4232-aca9-6652b58c3d6e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26d79ad7-6dee-4232-aca9-6652b58c3d6e">
											<gml:posList>35.670231019281665 139.73793022251974 30.748 35.670143375549614 139.73796028417252 30.748 35.670169606027166 139.73807481342422 30.748 35.67025717763412 139.7380446967412 30.748 35.670231019281665 139.73793022251974 30.748</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d32f617f-4e7a-4c32-bd93-836636cd227e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d32f617f-4e7a-4c32-bd93-836636cd227e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d32f617f-4e7a-4c32-bd93-836636cd227e">
											<gml:posList>35.67028389372894 139.73813510060552 35.788 35.670235050453655 139.73792141387045 35.788 35.670231019281665 139.73793022251974 35.788 35.67025717763412 139.7380446967412 35.788 35.67025854342639 139.73805066008893 35.788 35.67027670587106 139.73813014937593 35.788 35.67028389372894 139.73813510060552 35.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d8f6ba3d-7b54-4fe6-b2e5-6bac0da59d69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8f6ba3d-7b54-4fe6-b2e5-6bac0da59d69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8f6ba3d-7b54-4fe6-b2e5-6bac0da59d69">
											<gml:posList>35.67013619669812 139.73795533295657 35.788 35.67018513005086 139.7381690193421 35.788 35.67018917025411 139.73816021069914 35.788 35.670170971817946 139.73808077676594 35.788 35.670169606027166 139.73807481342422 35.788 35.670143375549614 139.73796028417252 35.788 35.67013619669812 139.73795533295657 35.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d4cde5ad-2286-4094-8c2c-3a92d236b1d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4cde5ad-2286-4094-8c2c-3a92d236b1d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4cde5ad-2286-4094-8c2c-3a92d236b1d5">
											<gml:posList>35.67025717763412 139.7380446967412 35.788 35.670169606027166 139.73807481342422 35.788 35.670170971817946 139.73808077676594 35.788 35.67025854342639 139.73805066008893 35.788 35.67025717763412 139.7380446967412 35.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09b5e178-6c30-4d0d-9294-54997aaab566">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09b5e178-6c30-4d0d-9294-54997aaab566">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09b5e178-6c30-4d0d-9294-54997aaab566">
											<gml:posList>35.67018917025411 139.73816021069914 34.405 35.67027670587106 139.73813014937593 34.405 35.67025854342639 139.73805066008893 34.405 35.670170971817946 139.73808077676594 34.405 35.67018917025411 139.73816021069914 34.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5324a8be-09f1-41a3-bdc3-32c422c5a674">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5324a8be-09f1-41a3-bdc3-32c422c5a674">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5324a8be-09f1-41a3-bdc3-32c422c5a674">
											<gml:posList>35.67028389372894 139.73813510060552 35.788 35.67027670587106 139.73813014937593 35.788 35.67018917025411 139.73816021069914 35.788 35.67018513005086 139.7381690193421 35.788 35.67028389372894 139.73813510060552 35.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6fea5581-8b50-4896-afda-9b7333840040">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fea5581-8b50-4896-afda-9b7333840040">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fea5581-8b50-4896-afda-9b7333840040">
											<gml:posList>35.670169606027166 139.73807481342422 35.788 35.670169606027166 139.73807481342422 30.748 35.670143375549614 139.73796028417252 30.748 35.670143375549614 139.73796028417252 35.788 35.670169606027166 139.73807481342422 35.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7718c7c-498d-422b-be6b-82d7bd4e0b4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7718c7c-498d-422b-be6b-82d7bd4e0b4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7718c7c-498d-422b-be6b-82d7bd4e0b4f">
											<gml:posList>35.67013619669812 139.73795533295657 17.517 35.67018513005086 139.7381690193421 17.517 35.67018513005086 139.7381690193421 35.788 35.67013619669812 139.73795533295657 35.788 35.67013619669812 139.73795533295657 17.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7cceeb5-1cc0-4c6d-bda8-057abcc180b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7cceeb5-1cc0-4c6d-bda8-057abcc180b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7cceeb5-1cc0-4c6d-bda8-057abcc180b8">
											<gml:posList>35.67018917025411 139.73816021069914 35.788 35.67018917025411 139.73816021069914 34.405 35.670170971817946 139.73808077676594 34.405 35.670170971817946 139.73808077676594 35.788 35.67018917025411 139.73816021069914 35.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d9591ab-935d-4090-b358-24c2aaaa40ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d9591ab-935d-4090-b358-24c2aaaa40ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d9591ab-935d-4090-b358-24c2aaaa40ba">
											<gml:posList>35.670235050453655 139.73792141387045 17.517 35.67013619669812 139.73795533295657 17.517 35.67013619669812 139.73795533295657 35.788 35.670235050453655 139.73792141387045 35.788 35.670235050453655 139.73792141387045 17.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f6b15d8-b3cf-48d5-990a-2b7defcb1cfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f6b15d8-b3cf-48d5-990a-2b7defcb1cfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f6b15d8-b3cf-48d5-990a-2b7defcb1cfa">
											<gml:posList>35.670143375549614 139.73796028417252 35.788 35.670143375549614 139.73796028417252 30.748 35.670231019281665 139.73793022251974 30.748 35.670231019281665 139.73793022251974 35.788 35.670143375549614 139.73796028417252 35.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-89ced041-3a29-42a9-b948-c3a163ec3268">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89ced041-3a29-42a9-b948-c3a163ec3268">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89ced041-3a29-42a9-b948-c3a163ec3268">
											<gml:posList>35.67025717763412 139.7380446967412 35.788 35.67025717763412 139.7380446967412 30.748 35.670169606027166 139.73807481342422 30.748 35.670169606027166 139.73807481342422 35.788 35.67025717763412 139.7380446967412 35.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71c86d76-5cd6-46b0-bf26-5b9274a060bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71c86d76-5cd6-46b0-bf26-5b9274a060bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71c86d76-5cd6-46b0-bf26-5b9274a060bc">
											<gml:posList>35.670170971817946 139.73808077676594 35.788 35.670170971817946 139.73808077676594 34.405 35.67025854342639 139.73805066008893 34.405 35.67025854342639 139.73805066008893 35.788 35.670170971817946 139.73808077676594 35.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db674a41-40d7-46b6-96f8-6493868e6cf6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db674a41-40d7-46b6-96f8-6493868e6cf6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db674a41-40d7-46b6-96f8-6493868e6cf6">
											<gml:posList>35.67027670587106 139.73813014937593 35.788 35.67027670587106 139.73813014937593 34.405 35.67018917025411 139.73816021069914 34.405 35.67018917025411 139.73816021069914 35.788 35.67027670587106 139.73813014937593 35.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7f910f9-064a-4896-bb8f-4a8a79fbf936">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7f910f9-064a-4896-bb8f-4a8a79fbf936">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7f910f9-064a-4896-bb8f-4a8a79fbf936">
											<gml:posList>35.67018513005086 139.7381690193421 17.517 35.67028389372894 139.73813510060552 17.517 35.67028389372894 139.73813510060552 35.788 35.67018513005086 139.7381690193421 35.788 35.67018513005086 139.7381690193421 17.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a216150e-a3ed-42e9-8f37-b3d45c23880c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a216150e-a3ed-42e9-8f37-b3d45c23880c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a216150e-a3ed-42e9-8f37-b3d45c23880c">
											<gml:posList>35.670231019281665 139.73793022251974 35.788 35.670231019281665 139.73793022251974 30.748 35.67025717763412 139.7380446967412 30.748 35.67025717763412 139.7380446967412 35.788 35.670231019281665 139.73793022251974 35.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d242159f-afe9-4dbb-927c-ee448b612f10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d242159f-afe9-4dbb-927c-ee448b612f10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d242159f-afe9-4dbb-927c-ee448b612f10">
											<gml:posList>35.67028389372894 139.73813510060552 17.517 35.670235050453655 139.73792141387045 17.517 35.670235050453655 139.73792141387045 35.788 35.67028389372894 139.73813510060552 35.788 35.67028389372894 139.73813510060552 17.517</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f522ab67-068e-4950-b972-b961f46e8904">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f522ab67-068e-4950-b972-b961f46e8904">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f522ab67-068e-4950-b972-b961f46e8904">
											<gml:posList>35.67025854342639 139.73805066008893 35.788 35.67025854342639 139.73805066008893 34.405 35.67027670587106 139.73813014937593 34.405 35.67027670587106 139.73813014937593 35.788 35.67025854342639 139.73805066008893 35.788</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9773</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">228.71205</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>