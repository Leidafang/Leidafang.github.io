<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9f44c5c5-c972-4a1e-9d48-c29e1555a1cb">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">31.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67062357249197 139.7500490967169 0 35.67068583389356 139.75008031517095 0 35.67073989361626 139.7499173259656 0 35.670676947283205 139.74988632925613 0 35.67065216007184 139.74987411575637 0 35.670588853652724 139.7498438043595 0 35.67056799484795 139.74990734222584 0 35.670565199368745 139.7499055777289 0 35.670532366966135 139.7500033714821 0 35.67062357249197 139.7500490967169 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67062357249197 139.7500490967169 6.73 35.670532366966135 139.7500033714821 6.73 35.670565199368745 139.7499055777289 6.73 35.67056799484795 139.74990734222584 6.73 35.670588853652724 139.7498438043595 6.73 35.67065216007184 139.74987411575637 6.73 35.670676947283205 139.74988632925613 6.73 35.67073989361626 139.7499173259656 6.73 35.67068583389356 139.75008031517095 6.73 35.67062357249197 139.7500490967169 6.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67062357249197 139.7500490967169 6.73 35.67068583389356 139.75008031517095 6.73 35.67068583389356 139.75008031517095 33.86 35.67062357249197 139.7500490967169 33.86 35.67062357249197 139.7500490967169 6.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67068583389356 139.75008031517095 6.73 35.67073989361626 139.7499173259656 6.73 35.67073989361626 139.7499173259656 33.86 35.67068583389356 139.75008031517095 33.86 35.67068583389356 139.75008031517095 6.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67073989361626 139.7499173259656 6.73 35.670676947283205 139.74988632925613 6.73 35.670676947283205 139.74988632925613 33.86 35.67073989361626 139.7499173259656 33.86 35.67073989361626 139.7499173259656 6.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670676947283205 139.74988632925613 6.73 35.67065216007184 139.74987411575637 6.73 35.67065216007184 139.74987411575637 33.86 35.670676947283205 139.74988632925613 33.86 35.670676947283205 139.74988632925613 6.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67065216007184 139.74987411575637 6.73 35.670588853652724 139.7498438043595 6.73 35.670588853652724 139.7498438043595 33.86 35.67065216007184 139.74987411575637 33.86 35.67065216007184 139.74987411575637 6.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670588853652724 139.7498438043595 6.73 35.67056799484795 139.74990734222584 6.73 35.67056799484795 139.74990734222584 33.86 35.670588853652724 139.7498438043595 33.86 35.670588853652724 139.7498438043595 6.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67056799484795 139.74990734222584 6.73 35.670565199368745 139.7499055777289 6.73 35.670565199368745 139.7499055777289 33.86 35.67056799484795 139.74990734222584 33.86 35.67056799484795 139.74990734222584 6.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670565199368745 139.7499055777289 6.73 35.670532366966135 139.7500033714821 6.73 35.670532366966135 139.7500033714821 33.86 35.670565199368745 139.7499055777289 33.86 35.670565199368745 139.7499055777289 6.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670532366966135 139.7500033714821 6.73 35.67062357249197 139.7500490967169 6.73 35.67062357249197 139.7500490967169 33.86 35.670532366966135 139.7500033714821 33.86 35.670532366966135 139.7500033714821 6.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67062357249197 139.7500490967169 33.86 35.67068583389356 139.75008031517095 33.86 35.67073989361626 139.7499173259656 33.86 35.670676947283205 139.74988632925613 33.86 35.67065216007184 139.74987411575637 33.86 35.670588853652724 139.7498438043595 33.86 35.67056799484795 139.74990734222584 33.86 35.670565199368745 139.7499055777289 33.86 35.670532366966135 139.7500033714821 33.86 35.67062357249197 139.7500490967169 33.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-16e5d122-6072-4bf2-9bd8-1f0a67c2fc9f"/>
							<gml:surfaceMember xlink:href="#poly-a6e3dd7c-33f7-4d92-892d-a0b57ba083d8"/>
							<gml:surfaceMember xlink:href="#poly-547bfb8e-6e4b-4d81-bafb-b8ca09b697f4"/>
							<gml:surfaceMember xlink:href="#poly-6bb93173-5678-4366-a1fc-8968bbf1c58e"/>
							<gml:surfaceMember xlink:href="#poly-f7b269cd-6316-4038-a941-a150a7f66ddb"/>
							<gml:surfaceMember xlink:href="#poly-b2ea745b-d223-46d6-91c7-448aa127ed3b"/>
							<gml:surfaceMember xlink:href="#poly-9bafb79d-4479-4326-b965-24e6c9345dd4"/>
							<gml:surfaceMember xlink:href="#poly-b2d43fcf-b849-4f4d-a14f-a577b8a3facc"/>
							<gml:surfaceMember xlink:href="#poly-4125691c-6ca7-4b25-9972-09f0d029533b"/>
							<gml:surfaceMember xlink:href="#poly-9af07214-aa4c-49c1-9b72-25fed0e12d46"/>
							<gml:surfaceMember xlink:href="#poly-4588991f-9d46-466d-9af1-e0b514099a09"/>
							<gml:surfaceMember xlink:href="#poly-522bff0d-b494-49a4-b7a6-299841fff3ba"/>
							<gml:surfaceMember xlink:href="#poly-811f5e69-a067-4f73-92fd-959fbcbf71db"/>
							<gml:surfaceMember xlink:href="#poly-bb4b78ff-4b84-40a1-ab49-776363fd4e51"/>
							<gml:surfaceMember xlink:href="#poly-950f80f8-1764-42f6-a48f-f0e193d71d20"/>
							<gml:surfaceMember xlink:href="#poly-f4517ec2-a430-40e4-a3aa-43557db5d2f7"/>
							<gml:surfaceMember xlink:href="#poly-d197a4f8-2099-4474-bfe0-5390aae134e4"/>
							<gml:surfaceMember xlink:href="#poly-cf172b12-8017-4369-a2cf-cf36df94a73e"/>
							<gml:surfaceMember xlink:href="#poly-feb8a6c7-b9c9-4117-80cf-ad82479afacf"/>
							<gml:surfaceMember xlink:href="#poly-61059940-06d2-4a21-86be-648b20446c89"/>
							<gml:surfaceMember xlink:href="#poly-9e700e3d-1557-46a7-afe7-ee2ffed035b2"/>
							<gml:surfaceMember xlink:href="#poly-5bb4a029-6bfa-4d36-9cae-37089a6f12b2"/>
							<gml:surfaceMember xlink:href="#poly-9ed6313c-8957-4587-a395-25413939f4c7"/>
							<gml:surfaceMember xlink:href="#poly-dc57f6b8-aef9-41fe-aca2-31817f393e10"/>
							<gml:surfaceMember xlink:href="#poly-579b271f-7239-42db-b4e8-93c239e09a11"/>
							<gml:surfaceMember xlink:href="#poly-5b6a20e7-7dec-4ba1-b1c5-24e0285ce4d8"/>
							<gml:surfaceMember xlink:href="#poly-0ad820cb-e384-4b2e-9ead-2494f4b74644"/>
							<gml:surfaceMember xlink:href="#poly-f54b1c36-9a89-4c0b-b0a0-052fcbc9b71d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-16e5d122-6072-4bf2-9bd8-1f0a67c2fc9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16e5d122-6072-4bf2-9bd8-1f0a67c2fc9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16e5d122-6072-4bf2-9bd8-1f0a67c2fc9f">
											<gml:posList>35.670567994847936 139.74990734222587 6.73 35.670588853652696 139.7498438043595 6.73 35.67065216007182 139.74987411575637 6.73 35.67073989361623 139.7499173259656 6.73 35.670685833893536 139.75008031517092 6.73 35.67053236696612 139.7500033714821 6.73 35.67056519936875 139.7499055777289 6.73 35.670567994847936 139.74990734222587 6.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6e3dd7c-33f7-4d92-892d-a0b57ba083d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6e3dd7c-33f7-4d92-892d-a0b57ba083d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6e3dd7c-33f7-4d92-892d-a0b57ba083d8">
											<gml:posList>35.670571620620805 139.749897584582 34.7 35.67058746999649 139.74985023474045 34.7 35.670588853652696 139.7498438043595 34.7 35.670567994847936 139.74990734222587 34.7 35.670571620620805 139.749897584582 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-547bfb8e-6e4b-4d81-bafb-b8ca09b697f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-547bfb8e-6e4b-4d81-bafb-b8ca09b697f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-547bfb8e-6e4b-4d81-bafb-b8ca09b697f4">
											<gml:posList>35.67060254929943 139.74996635974276 34.7 35.67053236696612 139.7500033714821 34.7 35.67062356347828 139.75004909672626 34.7 35.67063162855625 139.74998076701402 34.7 35.67060254929943 139.74996635974276 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6bb93173-5678-4366-a1fc-8968bbf1c58e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bb93173-5678-4366-a1fc-8968bbf1c58e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bb93173-5678-4366-a1fc-8968bbf1c58e">
											<gml:posList>35.6706132761902 139.74986306575454 36.7 35.67061332115927 139.7498629221059 36.7 35.67058746999649 139.74985023474045 36.7 35.670571620620805 139.749897584582 36.7 35.670598201920996 139.74991031538568 36.7 35.670599874846175 139.74990507770326 36.7 35.6706132761902 139.74986306575454 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f7b269cd-6316-4038-a941-a150a7f66ddb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7b269cd-6316-4038-a941-a150a7f66ddb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7b269cd-6316-4038-a941-a150a7f66ddb">
											<gml:posList>35.67053236696612 139.7500033714821 34.7 35.67060254929943 139.74996635974276 34.7 35.67061056371576 139.74994207165943 34.7 35.670639642975445 139.74995647892334 34.7 35.67063162855625 139.74998076701402 34.7 35.67062356347828 139.75004909672626 34.7 35.67067694728317 139.74988632925613 34.7 35.67065216007182 139.74987411575637 34.7 35.670588853652696 139.7498438043595 34.7 35.67058746999649 139.74985023474045 34.7 35.67061332115927 139.7498629221059 34.7 35.6706132761902 139.74986306575454 34.7 35.670651984988055 139.74988160532854 34.7 35.6706385926514 139.7499236172851 34.7 35.670599874846175 139.74990507770326 34.7 35.670598201920996 139.74991031538568 34.7 35.670571620620805 139.749897584582 34.7 35.670567994847936 139.74990734222587 34.7 35.67056519936875 139.7499055777289 34.7 35.67053236696612 139.7500033714821 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b2ea745b-d223-46d6-91c7-448aa127ed3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2ea745b-d223-46d6-91c7-448aa127ed3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2ea745b-d223-46d6-91c7-448aa127ed3b">
											<gml:posList>35.67060254929943 139.74996635974276 36.7 35.67063162855625 139.74998076701402 36.7 35.670639642975445 139.74995647892334 36.7 35.67061056371576 139.74994207165943 36.7 35.67060254929943 139.74996635974276 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9bafb79d-4479-4326-b965-24e6c9345dd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bafb79d-4479-4326-b965-24e6c9345dd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bafb79d-4479-4326-b965-24e6c9345dd4">
											<gml:posList>35.670599874846175 139.74990507770326 38.5 35.6706385926514 139.7499236172851 38.5 35.670651984988055 139.74988160532854 38.5 35.6706132761902 139.74986306575454 38.5 35.670599874846175 139.74990507770326 38.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b2d43fcf-b849-4f4d-a14f-a577b8a3facc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2d43fcf-b849-4f4d-a14f-a577b8a3facc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2d43fcf-b849-4f4d-a14f-a577b8a3facc">
											<gml:posList>35.67073989361623 139.7499173259656 23.45 35.67067694728317 139.74988632925613 34.7 35.67062356347828 139.75004909672626 34.7 35.670685833893536 139.75008031517092 23.45 35.67073989361623 139.7499173259656 23.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4125691c-6ca7-4b25-9972-09f0d029533b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4125691c-6ca7-4b25-9972-09f0d029533b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4125691c-6ca7-4b25-9972-09f0d029533b">
											<gml:posList>35.6706132761902 139.74986306575454 34.7 35.67061332115927 139.7498629221059 34.7 35.67061332115927 139.7498629221059 36.7 35.6706132761902 139.74986306575454 36.7 35.6706132761902 139.74986306575454 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9af07214-aa4c-49c1-9b72-25fed0e12d46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9af07214-aa4c-49c1-9b72-25fed0e12d46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9af07214-aa4c-49c1-9b72-25fed0e12d46">
											<gml:posList>35.67056519936875 139.7499055777289 6.73 35.67053236696612 139.7500033714821 6.73 35.67053236696612 139.7500033714821 34.7 35.67056519936875 139.7499055777289 34.7 35.67056519936875 139.7499055777289 6.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4588991f-9d46-466d-9af1-e0b514099a09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4588991f-9d46-466d-9af1-e0b514099a09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4588991f-9d46-466d-9af1-e0b514099a09">
											<gml:posList>35.670567994847936 139.74990734222587 6.73 35.67056519936875 139.7499055777289 6.73 35.67056519936875 139.7499055777289 34.7 35.670567994847936 139.74990734222587 34.7 35.670567994847936 139.74990734222587 6.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-522bff0d-b494-49a4-b7a6-299841fff3ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-522bff0d-b494-49a4-b7a6-299841fff3ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-522bff0d-b494-49a4-b7a6-299841fff3ba">
											<gml:posList>35.670588853652696 139.7498438043595 6.73 35.670567994847936 139.74990734222587 6.73 35.670567994847936 139.74990734222587 34.7 35.670588853652696 139.7498438043595 34.7 35.670588853652696 139.7498438043595 6.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-811f5e69-a067-4f73-92fd-959fbcbf71db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-811f5e69-a067-4f73-92fd-959fbcbf71db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-811f5e69-a067-4f73-92fd-959fbcbf71db">
											<gml:posList>35.670571620620805 139.749897584582 36.7 35.67058746999649 139.74985023474045 36.7 35.67058746999649 139.74985023474045 34.7 35.670571620620805 139.749897584582 34.7 35.670571620620805 139.749897584582 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb4b78ff-4b84-40a1-ab49-776363fd4e51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb4b78ff-4b84-40a1-ab49-776363fd4e51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb4b78ff-4b84-40a1-ab49-776363fd4e51">
											<gml:posList>35.670598201920996 139.74991031538568 36.7 35.670571620620805 139.749897584582 36.7 35.670571620620805 139.749897584582 34.7 35.670598201920996 139.74991031538568 34.7 35.670598201920996 139.74991031538568 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-950f80f8-1764-42f6-a48f-f0e193d71d20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-950f80f8-1764-42f6-a48f-f0e193d71d20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-950f80f8-1764-42f6-a48f-f0e193d71d20">
											<gml:posList>35.670599874846175 139.74990507770326 36.7 35.670598201920996 139.74991031538568 36.7 35.670598201920996 139.74991031538568 34.7 35.670599874846175 139.74990507770326 34.7 35.670599874846175 139.74990507770326 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4517ec2-a430-40e4-a3aa-43557db5d2f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4517ec2-a430-40e4-a3aa-43557db5d2f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4517ec2-a430-40e4-a3aa-43557db5d2f7">
											<gml:posList>35.67058746999649 139.74985023474045 36.7 35.67061332115927 139.7498629221059 36.7 35.67061332115927 139.7498629221059 34.7 35.67058746999649 139.74985023474045 34.7 35.67058746999649 139.74985023474045 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d197a4f8-2099-4474-bfe0-5390aae134e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d197a4f8-2099-4474-bfe0-5390aae134e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d197a4f8-2099-4474-bfe0-5390aae134e4">
											<gml:posList>35.67060254929943 139.74996635974276 36.7 35.67061056371576 139.74994207165943 36.7 35.67061056371576 139.74994207165943 34.7 35.67060254929943 139.74996635974276 34.7 35.67060254929943 139.74996635974276 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf172b12-8017-4369-a2cf-cf36df94a73e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf172b12-8017-4369-a2cf-cf36df94a73e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf172b12-8017-4369-a2cf-cf36df94a73e">
											<gml:posList>35.670599874846175 139.74990507770326 38.5 35.6706132761902 139.74986306575454 38.5 35.6706132761902 139.74986306575454 36.7 35.670599874846175 139.74990507770326 36.7 35.670599874846175 139.74990507770326 38.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-feb8a6c7-b9c9-4117-80cf-ad82479afacf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-feb8a6c7-b9c9-4117-80cf-ad82479afacf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-feb8a6c7-b9c9-4117-80cf-ad82479afacf">
											<gml:posList>35.67053236696612 139.7500033714821 6.73 35.670685833893536 139.75008031517092 6.73 35.670685833893536 139.75008031517092 23.45 35.67062356347828 139.75004909672626 34.7 35.67053236696612 139.7500033714821 34.7 35.67053236696612 139.7500033714821 6.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61059940-06d2-4a21-86be-648b20446c89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61059940-06d2-4a21-86be-648b20446c89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61059940-06d2-4a21-86be-648b20446c89">
											<gml:posList>35.67063162855625 139.74998076701402 36.7 35.67060254929943 139.74996635974276 36.7 35.67060254929943 139.74996635974276 34.7 35.67063162855625 139.74998076701402 34.7 35.67063162855625 139.74998076701402 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e700e3d-1557-46a7-afe7-ee2ffed035b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e700e3d-1557-46a7-afe7-ee2ffed035b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e700e3d-1557-46a7-afe7-ee2ffed035b2">
											<gml:posList>35.6706385926514 139.7499236172851 38.5 35.670599874846175 139.74990507770326 38.5 35.670599874846175 139.74990507770326 36.7 35.670599874846175 139.74990507770326 34.7 35.6706385926514 139.7499236172851 34.7 35.6706385926514 139.7499236172851 38.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5bb4a029-6bfa-4d36-9cae-37089a6f12b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bb4a029-6bfa-4d36-9cae-37089a6f12b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bb4a029-6bfa-4d36-9cae-37089a6f12b2">
											<gml:posList>35.67065216007182 139.74987411575637 6.73 35.670588853652696 139.7498438043595 6.73 35.670588853652696 139.7498438043595 34.7 35.67065216007182 139.74987411575637 34.7 35.67065216007182 139.74987411575637 6.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ed6313c-8957-4587-a395-25413939f4c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ed6313c-8957-4587-a395-25413939f4c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ed6313c-8957-4587-a395-25413939f4c7">
											<gml:posList>35.67061056371576 139.74994207165943 36.7 35.670639642975445 139.74995647892334 36.7 35.670639642975445 139.74995647892334 34.7 35.67061056371576 139.74994207165943 34.7 35.67061056371576 139.74994207165943 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc57f6b8-aef9-41fe-aca2-31817f393e10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc57f6b8-aef9-41fe-aca2-31817f393e10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc57f6b8-aef9-41fe-aca2-31817f393e10">
											<gml:posList>35.670651984988055 139.74988160532854 34.7 35.6706132761902 139.74986306575454 34.7 35.6706132761902 139.74986306575454 36.7 35.6706132761902 139.74986306575454 38.5 35.670651984988055 139.74988160532854 38.5 35.670651984988055 139.74988160532854 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-579b271f-7239-42db-b4e8-93c239e09a11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-579b271f-7239-42db-b4e8-93c239e09a11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-579b271f-7239-42db-b4e8-93c239e09a11">
											<gml:posList>35.670639642975445 139.74995647892334 36.7 35.67063162855625 139.74998076701402 36.7 35.67063162855625 139.74998076701402 34.7 35.670639642975445 139.74995647892334 34.7 35.670639642975445 139.74995647892334 36.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b6a20e7-7dec-4ba1-b1c5-24e0285ce4d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b6a20e7-7dec-4ba1-b1c5-24e0285ce4d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b6a20e7-7dec-4ba1-b1c5-24e0285ce4d8">
											<gml:posList>35.670651984988055 139.74988160532854 38.5 35.6706385926514 139.7499236172851 38.5 35.6706385926514 139.7499236172851 34.7 35.670651984988055 139.74988160532854 34.7 35.670651984988055 139.74988160532854 38.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ad820cb-e384-4b2e-9ead-2494f4b74644">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ad820cb-e384-4b2e-9ead-2494f4b74644">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ad820cb-e384-4b2e-9ead-2494f4b74644">
											<gml:posList>35.67065216007182 139.74987411575637 34.7 35.67067694728317 139.74988632925613 34.7 35.67073989361623 139.7499173259656 23.45 35.67073989361623 139.7499173259656 6.73 35.67065216007182 139.74987411575637 6.73 35.67065216007182 139.74987411575637 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f54b1c36-9a89-4c0b-b0a0-052fcbc9b71d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f54b1c36-9a89-4c0b-b0a0-052fcbc9b71d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f54b1c36-9a89-4c0b-b0a0-052fcbc9b71d">
											<gml:posList>35.670685833893536 139.75008031517092 6.73 35.67073989361623 139.7499173259656 6.73 35.67073989361623 139.7499173259656 23.45 35.670685833893536 139.75008031517092 23.45 35.670685833893536 139.75008031517092 6.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4466</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">286.92095</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>8</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>