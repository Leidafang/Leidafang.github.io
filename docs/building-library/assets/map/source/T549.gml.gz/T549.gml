<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_9f50b926-e7f5-4df1-9301-d1cafc760f34">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>虎ノ門二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:measuredHeight uom="m">3.1</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6690126713118 139.7466851975967 0 35.66899109157406 139.74665895336548 0 35.668962255219014 139.7466945528652 0 35.66903064815092 139.74677773322523 0 35.669083818032796 139.74671209524286 0 35.66907439945408 139.74670063958672 0 35.6690831260138 139.74668987127478 0 35.66907183093246 139.74667613111083 0 35.6690666166193 139.74668257661037 0 35.669054924583335 139.74666835085188 0 35.66906034602857 139.74666165106868 0 35.66901213441137 139.74660300435835 0 35.669002264126355 139.74661517675807 0 35.66903653731102 139.7466568607159 0 35.66903395266941 139.74666005582543 0 35.66903349256388 139.746659492973 0 35.6690126713118 139.7466851975967 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690126713118 139.7466851975967 6.038 35.66903349256388 139.746659492973 6.038 35.66903395266941 139.74666005582543 6.038 35.66903653731102 139.7466568607159 6.038 35.669002264126355 139.74661517675807 6.038 35.66901213441137 139.74660300435835 6.038 35.66906034602857 139.74666165106868 6.038 35.669054924583335 139.74666835085188 6.038 35.6690666166193 139.74668257661037 6.038 35.66907183093246 139.74667613111083 6.038 35.6690831260138 139.74668987127478 6.038 35.66907439945408 139.74670063958672 6.038 35.669083818032796 139.74671209524286 6.038 35.66903064815092 139.74677773322523 6.038 35.668962255219014 139.7466945528652 6.038 35.66899109157406 139.74665895336548 6.038 35.6690126713118 139.7466851975967 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690126713118 139.7466851975967 6.038 35.66899109157406 139.74665895336548 6.038 35.66899109157406 139.74665895336548 9.13 35.6690126713118 139.7466851975967 9.13 35.6690126713118 139.7466851975967 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66899109157406 139.74665895336548 6.038 35.668962255219014 139.7466945528652 6.038 35.668962255219014 139.7466945528652 9.13 35.66899109157406 139.74665895336548 9.13 35.66899109157406 139.74665895336548 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668962255219014 139.7466945528652 6.038 35.66903064815092 139.74677773322523 6.038 35.66903064815092 139.74677773322523 9.13 35.668962255219014 139.7466945528652 9.13 35.668962255219014 139.7466945528652 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903064815092 139.74677773322523 6.038 35.669083818032796 139.74671209524286 6.038 35.669083818032796 139.74671209524286 9.13 35.66903064815092 139.74677773322523 9.13 35.66903064815092 139.74677773322523 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669083818032796 139.74671209524286 6.038 35.66907439945408 139.74670063958672 6.038 35.66907439945408 139.74670063958672 9.13 35.669083818032796 139.74671209524286 9.13 35.669083818032796 139.74671209524286 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66907439945408 139.74670063958672 6.038 35.6690831260138 139.74668987127478 6.038 35.6690831260138 139.74668987127478 9.13 35.66907439945408 139.74670063958672 9.13 35.66907439945408 139.74670063958672 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690831260138 139.74668987127478 6.038 35.66907183093246 139.74667613111083 6.038 35.66907183093246 139.74667613111083 9.13 35.6690831260138 139.74668987127478 9.13 35.6690831260138 139.74668987127478 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66907183093246 139.74667613111083 6.038 35.6690666166193 139.74668257661037 6.038 35.6690666166193 139.74668257661037 9.13 35.66907183093246 139.74667613111083 9.13 35.66907183093246 139.74667613111083 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690666166193 139.74668257661037 6.038 35.669054924583335 139.74666835085188 6.038 35.669054924583335 139.74666835085188 9.13 35.6690666166193 139.74668257661037 9.13 35.6690666166193 139.74668257661037 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669054924583335 139.74666835085188 6.038 35.66906034602857 139.74666165106868 6.038 35.66906034602857 139.74666165106868 9.13 35.669054924583335 139.74666835085188 9.13 35.669054924583335 139.74666835085188 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66906034602857 139.74666165106868 6.038 35.66901213441137 139.74660300435835 6.038 35.66901213441137 139.74660300435835 9.13 35.66906034602857 139.74666165106868 9.13 35.66906034602857 139.74666165106868 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66901213441137 139.74660300435835 6.038 35.669002264126355 139.74661517675807 6.038 35.669002264126355 139.74661517675807 9.13 35.66901213441137 139.74660300435835 9.13 35.66901213441137 139.74660300435835 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669002264126355 139.74661517675807 6.038 35.66903653731102 139.7466568607159 6.038 35.66903653731102 139.7466568607159 9.13 35.669002264126355 139.74661517675807 9.13 35.669002264126355 139.74661517675807 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903653731102 139.7466568607159 6.038 35.66903395266941 139.74666005582543 6.038 35.66903395266941 139.74666005582543 9.13 35.66903653731102 139.7466568607159 9.13 35.66903653731102 139.7466568607159 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903395266941 139.74666005582543 6.038 35.66903349256388 139.746659492973 6.038 35.66903349256388 139.746659492973 9.13 35.66903395266941 139.74666005582543 9.13 35.66903395266941 139.74666005582543 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903349256388 139.746659492973 6.038 35.6690126713118 139.7466851975967 6.038 35.6690126713118 139.7466851975967 9.13 35.66903349256388 139.746659492973 9.13 35.66903349256388 139.746659492973 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690126713118 139.7466851975967 9.13 35.66899109157406 139.74665895336548 9.13 35.668962255219014 139.7466945528652 9.13 35.66903064815092 139.74677773322523 9.13 35.669083818032796 139.74671209524286 9.13 35.66907439945408 139.74670063958672 9.13 35.6690831260138 139.74668987127478 9.13 35.66907183093246 139.74667613111083 9.13 35.6690666166193 139.74668257661037 9.13 35.669054924583335 139.74666835085188 9.13 35.66906034602857 139.74666165106868 9.13 35.66901213441137 139.74660300435835 9.13 35.669002264126355 139.74661517675807 9.13 35.66903653731102 139.7466568607159 9.13 35.66903395266941 139.74666005582543 9.13 35.66903349256388 139.746659492973 9.13 35.6690126713118 139.7466851975967 9.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e0d45681-232e-4de5-8ddf-e9a0fecda743"/>
							<gml:surfaceMember xlink:href="#poly-0fe7998f-031b-4008-944e-9a06a747ac27"/>
							<gml:surfaceMember xlink:href="#poly-2cd87d2b-05da-4cf6-87d0-6eab91124781"/>
							<gml:surfaceMember xlink:href="#poly-7063e7c4-1fd5-4779-b5ea-8adff151082c"/>
							<gml:surfaceMember xlink:href="#poly-cdfd40f3-8726-4399-8daa-c64a2736982e"/>
							<gml:surfaceMember xlink:href="#poly-79ad8ee3-10e0-47cf-b227-9ef52a0213cd"/>
							<gml:surfaceMember xlink:href="#poly-dfbb3be3-b9da-43f6-8431-2c277852f297"/>
							<gml:surfaceMember xlink:href="#poly-7126aedc-a4a0-4c8e-9f1b-8a438c36568e"/>
							<gml:surfaceMember xlink:href="#poly-66b44e5f-7ed3-4bba-9949-46f367bb8643"/>
							<gml:surfaceMember xlink:href="#poly-42e66bb1-6b68-463d-978e-f12e9c098183"/>
							<gml:surfaceMember xlink:href="#poly-76170e1a-5fb1-498e-9906-a0032c4b6a68"/>
							<gml:surfaceMember xlink:href="#poly-f7d813fe-c87a-4299-80f9-4e27f9ef97c9"/>
							<gml:surfaceMember xlink:href="#poly-1849c47f-b491-4fea-905d-93b499310b7d"/>
							<gml:surfaceMember xlink:href="#poly-07909707-6d43-424a-ad3f-1bd4d20ffe83"/>
							<gml:surfaceMember xlink:href="#poly-b69716f3-fc75-495d-a605-edecc5658d95"/>
							<gml:surfaceMember xlink:href="#poly-722bb888-bdc1-4c3e-b984-caad463996d0"/>
							<gml:surfaceMember xlink:href="#poly-eee9375b-c6e2-4f4b-a7d0-1d25bd9b2505"/>
							<gml:surfaceMember xlink:href="#poly-030a665e-1823-4302-b54e-f2fcbb711aad"/>
							<gml:surfaceMember xlink:href="#poly-461f43b6-5127-40ad-8f5d-478a82ed8888"/>
							<gml:surfaceMember xlink:href="#poly-0fc7ee3d-9971-47a7-9989-a6b83aae6a72"/>
							<gml:surfaceMember xlink:href="#poly-03b6b62d-8b1c-4d4d-a4d1-30972032dc5d"/>
							<gml:surfaceMember xlink:href="#poly-64ef4f90-444f-4b2f-b40c-71a725622b9f"/>
							<gml:surfaceMember xlink:href="#poly-ae88ed15-efdf-4d78-a1de-e6a708e839e5"/>
							<gml:surfaceMember xlink:href="#poly-e8623049-8ba7-400c-acbc-948c9e2b7224"/>
							<gml:surfaceMember xlink:href="#poly-2b6cecb3-d2a8-4812-8e5e-b960147ae65e"/>
							<gml:surfaceMember xlink:href="#poly-9996175e-4d40-49e6-9577-1f32ad6ed9c9"/>
							<gml:surfaceMember xlink:href="#poly-d5319b71-dc01-45fb-899d-80b4cde1464c"/>
							<gml:surfaceMember xlink:href="#poly-b0f109a0-2334-4ac3-975c-d885f11adfec"/>
							<gml:surfaceMember xlink:href="#poly-7b91374e-e307-4479-af9f-31802bc89760"/>
							<gml:surfaceMember xlink:href="#poly-01ddb45f-6c6b-4508-8b88-6a51116964bb"/>
							<gml:surfaceMember xlink:href="#poly-d2cbb940-d445-41ef-82e4-8983763fd00c"/>
							<gml:surfaceMember xlink:href="#poly-0f020267-dc8b-451c-baa5-4635d037529e"/>
							<gml:surfaceMember xlink:href="#poly-064db6a1-3d9c-443b-9709-ae5f335e0499"/>
							<gml:surfaceMember xlink:href="#poly-a7552cd4-4021-49f2-b1fe-fe089a7cd677"/>
							<gml:surfaceMember xlink:href="#poly-57d9ee6f-518a-40e0-b1d0-f5e5139cc81c"/>
							<gml:surfaceMember xlink:href="#poly-6043c98b-29ad-4d8e-a682-6b5a87907888"/>
							<gml:surfaceMember xlink:href="#poly-302e069e-1727-4897-8794-33e79579fac2"/>
							<gml:surfaceMember xlink:href="#poly-6b4cb0fb-6144-4327-96cd-653b014dc9d1"/>
							<gml:surfaceMember xlink:href="#poly-bc6171e1-ba91-4fac-91c5-c4fa3c965565"/>
							<gml:surfaceMember xlink:href="#poly-e6cd9cc1-b0dd-4d70-bc75-701c8c6cecdc"/>
							<gml:surfaceMember xlink:href="#poly-ab21de3b-b40b-40d7-9db5-be46356e9cc9"/>
							<gml:surfaceMember xlink:href="#poly-8f5196a2-5443-48d4-a1cb-711e2c1c04c9"/>
							<gml:surfaceMember xlink:href="#poly-058f7006-cbac-40ee-bdd8-9e0f5b162637"/>
							<gml:surfaceMember xlink:href="#poly-0fd169f9-2b3f-475c-8376-a7c910615da6"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_9f50b926-e7f5-4df1-9301-d1cafc760f34_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cce996c-25ca-4252-8ace-b3a6c910058e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669027807012505 139.7467250686126 9.67 35.6690141452409 139.74674184026037 9.67 35.66897654291308 139.74669584086277 9.67 35.668990204678366 139.74667906921505 9.67 35.669027807012505 139.7467250686126 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-559af612-a62a-44cf-81c5-933c2b575caa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669061986482454 139.7467242253298 9.67 35.66904911721995 139.74674002407428 9.67 35.66901557463687 139.74669897995716 9.67 35.669028452907796 139.74668318120297 9.67 35.669061986482454 139.7467242253298 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27a45719-74e1-46c5-b3e2-db8df98db93d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669030862392944 139.74676229058224 9.67 35.66901797043667 139.74674653071014 9.67 35.66903163220891 139.74672975906236 9.67 35.669044524167354 139.74674551893443 9.67 35.669030862392944 139.74676229058224 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0eddb058-7120-4f54-ba7f-587124cff467">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0eddb058-7120-4f54-ba7f-587124cff467_0">
											<gml:posList>35.6690141452409 139.74674184026037 9.67 35.669027807012505 139.7467250686126 9.67 35.669027807012505 139.7467250686126 11.49 35.6690141452409 139.74674184026037 11.49 35.6690141452409 139.74674184026037 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9145ede3-02fc-462c-9808-2c087e2454f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9145ede3-02fc-462c-9808-2c087e2454f5_0">
											<gml:posList>35.668990204678366 139.74667906921505 9.67 35.66897654291308 139.74669584086277 9.67 35.66897654291308 139.74669584086277 11.49 35.668990204678366 139.74667906921505 11.49 35.668990204678366 139.74667906921505 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07d62e57-c46a-4f10-8539-e1070b2c0747">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07d62e57-c46a-4f10-8539-e1070b2c0747_0">
											<gml:posList>35.66897654291308 139.74669584086277 9.67 35.6690141452409 139.74674184026037 9.67 35.6690141452409 139.74674184026037 11.49 35.66897654291308 139.74669584086277 11.49 35.66897654291308 139.74669584086277 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7daea8fb-2759-43f9-a7b1-045fceba4160">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7daea8fb-2759-43f9-a7b1-045fceba4160_0">
											<gml:posList>35.66897654291308 139.74669584086277 11.49 35.6690141452409 139.74674184026037 11.49 35.669027807012505 139.7467250686126 11.49 35.668990204678366 139.74667906921505 11.49 35.66897654291308 139.74669584086277 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8827b40-bda4-4625-a019-2dd1783b58fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8827b40-bda4-4625-a019-2dd1783b58fa_0">
											<gml:posList>35.668990204678366 139.74667906921505 9.67 35.668990204678366 139.74667906921505 11.49 35.669027807012505 139.7467250686126 11.49 35.669027807012505 139.7467250686126 9.67 35.668990204678366 139.74667906921505 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15d6e67a-6251-4283-b2b8-ee42c9a4f89a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15d6e67a-6251-4283-b2b8-ee42c9a4f89a_0">
											<gml:posList>35.66901557463687 139.74669897995716 9.67 35.66901557463687 139.74669897995716 11.49 35.669028452907796 139.74668318120297 11.49 35.669028452907796 139.74668318120297 9.67 35.66901557463687 139.74669897995716 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e17eb90-2d97-4045-859f-898f86b4c2fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e17eb90-2d97-4045-859f-898f86b4c2fc_0">
											<gml:posList>35.66901797043667 139.74674653071014 9.67 35.669030862392944 139.74676229058224 9.67 35.669030862392944 139.74676229058224 11.49 35.66901797043667 139.74674653071014 11.49 35.66901797043667 139.74674653071014 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-158b5b31-2e9a-4d46-904a-1893d57d1931">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-158b5b31-2e9a-4d46-904a-1893d57d1931_0">
											<gml:posList>35.66901797043667 139.74674653071014 9.67 35.66901797043667 139.74674653071014 11.49 35.66903163220891 139.74672975906236 11.49 35.66903163220891 139.74672975906236 9.67 35.66901797043667 139.74674653071014 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4a98fb8-bf7f-40e3-ab51-075ba1144268">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4a98fb8-bf7f-40e3-ab51-075ba1144268_0">
											<gml:posList>35.669030862392944 139.74676229058224 11.49 35.669044524167354 139.74674551893443 11.49 35.66903163220891 139.74672975906236 11.49 35.66901797043667 139.74674653071014 11.49 35.669030862392944 139.74676229058224 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c94ee70-4636-4515-ad41-a97de4733e4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c94ee70-4636-4515-ad41-a97de4733e4c_0">
											<gml:posList>35.66901557463687 139.74669897995716 9.67 35.66904911721995 139.74674002407428 9.67 35.66904911721995 139.74674002407428 11.49 35.66901557463687 139.74669897995716 11.49 35.66901557463687 139.74669897995716 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd27800f-c278-4be6-9c79-d76b0b0c6ac2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd27800f-c278-4be6-9c79-d76b0b0c6ac2_0">
											<gml:posList>35.669030862392944 139.74676229058224 9.67 35.669044524167354 139.74674551893443 9.67 35.669044524167354 139.74674551893443 11.49 35.669030862392944 139.74676229058224 11.49 35.669030862392944 139.74676229058224 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-effcda53-3e34-40a6-9c5b-ea58db9f2154">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-effcda53-3e34-40a6-9c5b-ea58db9f2154_0">
											<gml:posList>35.66903163220891 139.74672975906236 9.67 35.66903163220891 139.74672975906236 11.49 35.669044524167354 139.74674551893443 11.49 35.669044524167354 139.74674551893443 9.67 35.66903163220891 139.74672975906236 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8af2a711-c903-4e89-895b-d8c5ada5cca4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8af2a711-c903-4e89-895b-d8c5ada5cca4_0">
											<gml:posList>35.66901557463687 139.74669897995716 11.49 35.66904911721995 139.74674002407428 11.49 35.669061986482454 139.7467242253298 11.49 35.669028452907796 139.74668318120297 11.49 35.66901557463687 139.74669897995716 11.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebc97369-c429-41f9-9342-ec1932a0b394">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebc97369-c429-41f9-9342-ec1932a0b394_0">
											<gml:posList>35.669028452907796 139.74668318120297 9.67 35.669028452907796 139.74668318120297 11.49 35.669061986482454 139.7467242253298 11.49 35.669061986482454 139.7467242253298 9.67 35.669028452907796 139.74668318120297 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcbf68cb-1b15-49a4-a6e3-6d0a1f4d8370">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dcbf68cb-1b15-49a4-a6e3-6d0a1f4d8370_0">
											<gml:posList>35.66904911721995 139.74674002407428 9.67 35.669061986482454 139.7467242253298 9.67 35.669061986482454 139.7467242253298 11.49 35.66904911721995 139.74674002407428 11.49 35.66904911721995 139.74674002407428 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e0d45681-232e-4de5-8ddf-e9a0fecda743">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0d45681-232e-4de5-8ddf-e9a0fecda743">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0d45681-232e-4de5-8ddf-e9a0fecda743">
											<gml:posList>35.66901213441137 139.74660300435835 6.038 35.669060346028566 139.74666165106868 6.038 35.66905492458331 139.74666835085188 6.038 35.669066616619276 139.74668257661037 6.038 35.669071830932445 139.7466761311108 6.038 35.669083126013795 139.74668987127475 6.038 35.66907439945408 139.74670063958672 6.038 35.66908381803278 139.74671209524286 6.038 35.66903064815094 139.7467777332252 6.038 35.668962255219 139.7466945528652 6.038 35.66899109157406 139.74665895336548 6.038 35.66901267131178 139.7466851975967 6.038 35.66903349256388 139.74665949297298 6.038 35.669033952669416 139.74666005582543 6.038 35.669036537311015 139.7466568607159 6.038 35.66900226412636 139.74661517675807 6.038 35.66901213441137 139.74660300435835 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0fe7998f-031b-4008-944e-9a06a747ac27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fe7998f-031b-4008-944e-9a06a747ac27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fe7998f-031b-4008-944e-9a06a747ac27">
											<gml:posList>35.668962255219 139.7466945528652 10.7 35.66896827636437 139.74669451322097 10.7 35.6689911149125 139.74666633211413 10.7 35.66899109157406 139.74665895336548 10.7 35.668962255219 139.7466945528652 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2cd87d2b-05da-4cf6-87d0-6eab91124781">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cd87d2b-05da-4cf6-87d0-6eab91124781">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cd87d2b-05da-4cf6-87d0-6eab91124781">
											<gml:posList>35.66903064815094 139.7467777332252 10.7 35.66903062481932 139.74677035447286 10.7 35.66896827636437 139.74669451322097 10.7 35.668962255219 139.7466945528652 10.7 35.66903064815094 139.7467777332252 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7063e7c4-1fd5-4779-b5ea-8adff151082c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7063e7c4-1fd5-4779-b5ea-8adff151082c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7063e7c4-1fd5-4779-b5ea-8adff151082c">
											<gml:posList>35.66901267131178 139.7466851975967 10.7 35.66899109157406 139.74665895336548 10.7 35.6689911149125 139.74666633211413 10.7 35.669012694648615 139.74669257634736 10.7 35.66901267131178 139.7466851975967 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cdfd40f3-8726-4399-8daa-c64a2736982e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdfd40f3-8726-4399-8daa-c64a2736982e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdfd40f3-8726-4399-8daa-c64a2736982e">
											<gml:posList>35.6690683692792 139.74670065714812 9.67 35.66907709584688 139.74668989988308 9.67 35.669071845264064 139.7466835209227 9.67 35.66906663094255 139.7466899553757 9.67 35.66905493890745 139.74667572961616 9.67 35.669047914433015 139.74668439733196 9.67 35.66903351590229 139.74666687172555 9.67 35.669012694648615 139.74669257634736 9.67 35.6689911149125 139.74666633211413 9.67 35.66896827636437 139.74669451322097 9.67 35.66903062481932 139.74677035447286 9.67 35.6690777878579 139.74671211280344 9.67 35.6690683692792 139.74670065714812 9.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79ad8ee3-10e0-47cf-b227-9ef52a0213cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79ad8ee3-10e0-47cf-b227-9ef52a0213cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79ad8ee3-10e0-47cf-b227-9ef52a0213cd">
											<gml:posList>35.66901267131178 139.7466851975967 10.7 35.669012694648615 139.74669257634736 10.7 35.66903351590229 139.74666687172555 10.7 35.66903349256388 139.74665949297298 10.7 35.66901267131178 139.7466851975967 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dfbb3be3-b9da-43f6-8431-2c277852f297">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfbb3be3-b9da-43f6-8431-2c277852f297">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfbb3be3-b9da-43f6-8431-2c277852f297">
											<gml:posList>35.669036537311015 139.7466568607159 10.2 35.669033952669416 139.74666005582543 10.2 35.6690479001094 139.74667701856833 10.2 35.66905492458331 139.74666835085188 10.2 35.669060346028566 139.74666165106868 10.2 35.66901213441137 139.74660300435835 10.2 35.66900226412636 139.74661517675807 10.2 35.669036537311015 139.7466568607159 10.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7126aedc-a4a0-4c8e-9f1b-8a438c36568e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7126aedc-a4a0-4c8e-9f1b-8a438c36568e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7126aedc-a4a0-4c8e-9f1b-8a438c36568e">
											<gml:posList>35.6690479001094 139.74667701856833 10.7 35.66903349256388 139.74665949297298 10.7 35.66903351590229 139.74666687172555 10.7 35.669047914433015 139.74668439733196 10.7 35.6690479001094 139.74667701856833 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66b44e5f-7ed3-4bba-9949-46f367bb8643">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66b44e5f-7ed3-4bba-9949-46f367bb8643">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66b44e5f-7ed3-4bba-9949-46f367bb8643">
											<gml:posList>35.6690479001094 139.74667701856833 10.7 35.669047914433015 139.74668439733196 10.7 35.66905493890745 139.74667572961616 10.7 35.66905492458331 139.74666835085188 10.7 35.6690479001094 139.74667701856833 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-42e66bb1-6b68-463d-978e-f12e9c098183">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42e66bb1-6b68-463d-978e-f12e9c098183">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42e66bb1-6b68-463d-978e-f12e9c098183">
											<gml:posList>35.66908381803278 139.74671209524286 10.7 35.6690777878579 139.74671211280344 10.7 35.66903062481932 139.74677035447286 10.7 35.66903064815094 139.7467777332252 10.7 35.66908381803278 139.74671209524286 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-76170e1a-5fb1-498e-9906-a0032c4b6a68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76170e1a-5fb1-498e-9906-a0032c4b6a68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76170e1a-5fb1-498e-9906-a0032c4b6a68">
											<gml:posList>35.669066616619276 139.74668257661037 10.7 35.66905492458331 139.74666835085188 10.7 35.66905493890745 139.74667572961616 10.7 35.66906663094255 139.7466899553757 10.7 35.669066616619276 139.74668257661037 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f7d813fe-c87a-4299-80f9-4e27f9ef97c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7d813fe-c87a-4299-80f9-4e27f9ef97c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7d813fe-c87a-4299-80f9-4e27f9ef97c9">
											<gml:posList>35.669066616619276 139.74668257661037 10.7 35.66906663094255 139.7466899553757 10.7 35.669071845264064 139.7466835209227 10.7 35.669071830932445 139.7466761311108 10.7 35.669066616619276 139.74668257661037 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1849c47f-b491-4fea-905d-93b499310b7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1849c47f-b491-4fea-905d-93b499310b7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1849c47f-b491-4fea-905d-93b499310b7d">
											<gml:posList>35.66907439945408 139.74670063958672 10.7 35.669083126013795 139.74668987127475 10.7 35.66907709584688 139.74668989988308 10.7 35.6690683692792 139.74670065714812 10.7 35.66907439945408 139.74670063958672 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-07909707-6d43-424a-ad3f-1bd4d20ffe83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07909707-6d43-424a-ad3f-1bd4d20ffe83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07909707-6d43-424a-ad3f-1bd4d20ffe83">
											<gml:posList>35.66907439945408 139.74670063958672 10.7 35.6690683692792 139.74670065714812 10.7 35.6690777878579 139.74671211280344 10.7 35.66908381803278 139.74671209524286 10.7 35.66907439945408 139.74670063958672 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b69716f3-fc75-495d-a605-edecc5658d95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b69716f3-fc75-495d-a605-edecc5658d95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b69716f3-fc75-495d-a605-edecc5658d95">
											<gml:posList>35.669071830932445 139.7466761311108 10.7 35.669071845264064 139.7466835209227 10.7 35.66907709584688 139.74668989988308 10.7 35.669083126013795 139.74668987127475 10.7 35.669071830932445 139.7466761311108 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-722bb888-bdc1-4c3e-b984-caad463996d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-722bb888-bdc1-4c3e-b984-caad463996d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-722bb888-bdc1-4c3e-b984-caad463996d0">
											<gml:posList>35.6689911149125 139.74666633211413 10.7 35.6689911149125 139.74666633211413 9.67 35.669012694648615 139.74669257634736 9.67 35.669012694648615 139.74669257634736 10.7 35.6689911149125 139.74666633211413 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eee9375b-c6e2-4f4b-a7d0-1d25bd9b2505">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eee9375b-c6e2-4f4b-a7d0-1d25bd9b2505">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eee9375b-c6e2-4f4b-a7d0-1d25bd9b2505">
											<gml:posList>35.669060346028566 139.74666165106868 6.038 35.66901213441137 139.74660300435835 6.038 35.66901213441137 139.74660300435835 10.2 35.669060346028566 139.74666165106868 10.2 35.669060346028566 139.74666165106868 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-030a665e-1823-4302-b54e-f2fcbb711aad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-030a665e-1823-4302-b54e-f2fcbb711aad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-030a665e-1823-4302-b54e-f2fcbb711aad">
											<gml:posList>35.66906663094255 139.7466899553757 10.7 35.66906663094255 139.7466899553757 9.67 35.669071845264064 139.7466835209227 9.67 35.669071845264064 139.7466835209227 10.7 35.66906663094255 139.7466899553757 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-461f43b6-5127-40ad-8f5d-478a82ed8888">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-461f43b6-5127-40ad-8f5d-478a82ed8888">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-461f43b6-5127-40ad-8f5d-478a82ed8888">
											<gml:posList>35.66901213441137 139.74660300435835 6.038 35.66900226412636 139.74661517675807 6.038 35.66900226412636 139.74661517675807 10.2 35.66901213441137 139.74660300435835 10.2 35.66901213441137 139.74660300435835 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fc7ee3d-9971-47a7-9989-a6b83aae6a72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fc7ee3d-9971-47a7-9989-a6b83aae6a72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fc7ee3d-9971-47a7-9989-a6b83aae6a72">
											<gml:posList>35.66900226412636 139.74661517675807 6.038 35.669036537311015 139.7466568607159 6.038 35.669036537311015 139.7466568607159 10.2 35.66900226412636 139.74661517675807 10.2 35.66900226412636 139.74661517675807 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03b6b62d-8b1c-4d4d-a4d1-30972032dc5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03b6b62d-8b1c-4d4d-a4d1-30972032dc5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03b6b62d-8b1c-4d4d-a4d1-30972032dc5d">
											<gml:posList>35.669036537311015 139.7466568607159 6.038 35.669033952669416 139.74666005582543 6.038 35.669033952669416 139.74666005582543 10.2 35.669036537311015 139.7466568607159 10.2 35.669036537311015 139.7466568607159 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64ef4f90-444f-4b2f-b40c-71a725622b9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64ef4f90-444f-4b2f-b40c-71a725622b9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64ef4f90-444f-4b2f-b40c-71a725622b9f">
											<gml:posList>35.669060346028566 139.74666165106868 6.038 35.669060346028566 139.74666165106868 10.2 35.66905492458331 139.74666835085188 10.2 35.66905492458331 139.74666835085188 6.038 35.669060346028566 139.74666165106868 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae88ed15-efdf-4d78-a1de-e6a708e839e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae88ed15-efdf-4d78-a1de-e6a708e839e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae88ed15-efdf-4d78-a1de-e6a708e839e5">
											<gml:posList>35.669033952669416 139.74666005582543 10.2 35.669033952669416 139.74666005582543 6.038 35.66903349256388 139.74665949297298 6.038 35.66903349256388 139.74665949297298 10.7 35.6690479001094 139.74667701856833 10.7 35.6690479001094 139.74667701856833 10.2 35.669033952669416 139.74666005582543 10.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8623049-8ba7-400c-acbc-948c9e2b7224">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8623049-8ba7-400c-acbc-948c9e2b7224">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8623049-8ba7-400c-acbc-948c9e2b7224">
											<gml:posList>35.66901267131178 139.7466851975967 6.038 35.66899109157406 139.74665895336548 6.038 35.66899109157406 139.74665895336548 10.7 35.66901267131178 139.7466851975967 10.7 35.66901267131178 139.7466851975967 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b6cecb3-d2a8-4812-8e5e-b960147ae65e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b6cecb3-d2a8-4812-8e5e-b960147ae65e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b6cecb3-d2a8-4812-8e5e-b960147ae65e">
											<gml:posList>35.66903349256388 139.74665949297298 6.038 35.66901267131178 139.7466851975967 6.038 35.66901267131178 139.7466851975967 10.7 35.66903349256388 139.74665949297298 10.7 35.66903349256388 139.74665949297298 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9996175e-4d40-49e6-9577-1f32ad6ed9c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9996175e-4d40-49e6-9577-1f32ad6ed9c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9996175e-4d40-49e6-9577-1f32ad6ed9c9">
											<gml:posList>35.6690479001094 139.74667701856833 10.2 35.6690479001094 139.74667701856833 10.7 35.66905492458331 139.74666835085188 10.7 35.66905492458331 139.74666835085188 10.2 35.6690479001094 139.74667701856833 10.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5319b71-dc01-45fb-899d-80b4cde1464c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5319b71-dc01-45fb-899d-80b4cde1464c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5319b71-dc01-45fb-899d-80b4cde1464c">
											<gml:posList>35.669066616619276 139.74668257661037 10.7 35.669066616619276 139.74668257661037 6.038 35.66905492458331 139.74666835085188 6.038 35.66905492458331 139.74666835085188 10.2 35.66905492458331 139.74666835085188 10.7 35.669066616619276 139.74668257661037 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0f109a0-2334-4ac3-975c-d885f11adfec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0f109a0-2334-4ac3-975c-d885f11adfec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0f109a0-2334-4ac3-975c-d885f11adfec">
											<gml:posList>35.66903351590229 139.74666687172555 10.7 35.66903351590229 139.74666687172555 9.67 35.669047914433015 139.74668439733196 9.67 35.669047914433015 139.74668439733196 10.7 35.66903351590229 139.74666687172555 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b91374e-e307-4479-af9f-31802bc89760">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b91374e-e307-4479-af9f-31802bc89760">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b91374e-e307-4479-af9f-31802bc89760">
											<gml:posList>35.66899109157406 139.74665895336548 6.038 35.668962255219 139.7466945528652 6.038 35.668962255219 139.7466945528652 10.7 35.66899109157406 139.74665895336548 10.7 35.66899109157406 139.74665895336548 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01ddb45f-6c6b-4508-8b88-6a51116964bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01ddb45f-6c6b-4508-8b88-6a51116964bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01ddb45f-6c6b-4508-8b88-6a51116964bb">
											<gml:posList>35.669071830932445 139.7466761311108 6.038 35.669066616619276 139.74668257661037 6.038 35.669066616619276 139.74668257661037 10.7 35.669071830932445 139.7466761311108 10.7 35.669071830932445 139.7466761311108 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2cbb940-d445-41ef-82e4-8983763fd00c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2cbb940-d445-41ef-82e4-8983763fd00c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2cbb940-d445-41ef-82e4-8983763fd00c">
											<gml:posList>35.669012694648615 139.74669257634736 10.7 35.669012694648615 139.74669257634736 9.67 35.66903351590229 139.74666687172555 9.67 35.66903351590229 139.74666687172555 10.7 35.669012694648615 139.74669257634736 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f020267-dc8b-451c-baa5-4635d037529e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f020267-dc8b-451c-baa5-4635d037529e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f020267-dc8b-451c-baa5-4635d037529e">
											<gml:posList>35.669047914433015 139.74668439733196 10.7 35.669047914433015 139.74668439733196 9.67 35.66905493890745 139.74667572961616 9.67 35.66905493890745 139.74667572961616 10.7 35.669047914433015 139.74668439733196 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-064db6a1-3d9c-443b-9709-ae5f335e0499">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-064db6a1-3d9c-443b-9709-ae5f335e0499">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-064db6a1-3d9c-443b-9709-ae5f335e0499">
											<gml:posList>35.66896827636437 139.74669451322097 10.7 35.66896827636437 139.74669451322097 9.67 35.6689911149125 139.74666633211413 9.67 35.6689911149125 139.74666633211413 10.7 35.66896827636437 139.74669451322097 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7552cd4-4021-49f2-b1fe-fe089a7cd677">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7552cd4-4021-49f2-b1fe-fe089a7cd677">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7552cd4-4021-49f2-b1fe-fe089a7cd677">
											<gml:posList>35.66905493890745 139.74667572961616 10.7 35.66905493890745 139.74667572961616 9.67 35.66906663094255 139.7466899553757 9.67 35.66906663094255 139.7466899553757 10.7 35.66905493890745 139.74667572961616 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57d9ee6f-518a-40e0-b1d0-f5e5139cc81c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57d9ee6f-518a-40e0-b1d0-f5e5139cc81c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57d9ee6f-518a-40e0-b1d0-f5e5139cc81c">
											<gml:posList>35.669083126013795 139.74668987127475 6.038 35.669071830932445 139.7466761311108 6.038 35.669071830932445 139.7466761311108 10.7 35.669083126013795 139.74668987127475 10.7 35.669083126013795 139.74668987127475 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6043c98b-29ad-4d8e-a682-6b5a87907888">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6043c98b-29ad-4d8e-a682-6b5a87907888">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6043c98b-29ad-4d8e-a682-6b5a87907888">
											<gml:posList>35.669071845264064 139.7466835209227 10.7 35.669071845264064 139.7466835209227 9.67 35.66907709584688 139.74668989988308 9.67 35.66907709584688 139.74668989988308 10.7 35.669071845264064 139.7466835209227 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-302e069e-1727-4897-8794-33e79579fac2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-302e069e-1727-4897-8794-33e79579fac2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-302e069e-1727-4897-8794-33e79579fac2">
											<gml:posList>35.66907439945408 139.74670063958672 6.038 35.669083126013795 139.74668987127475 6.038 35.669083126013795 139.74668987127475 10.7 35.66907439945408 139.74670063958672 10.7 35.66907439945408 139.74670063958672 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b4cb0fb-6144-4327-96cd-653b014dc9d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b4cb0fb-6144-4327-96cd-653b014dc9d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b4cb0fb-6144-4327-96cd-653b014dc9d1">
											<gml:posList>35.66907709584688 139.74668989988308 10.7 35.66907709584688 139.74668989988308 9.67 35.6690683692792 139.74670065714812 9.67 35.6690683692792 139.74670065714812 10.7 35.66907709584688 139.74668989988308 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc6171e1-ba91-4fac-91c5-c4fa3c965565">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc6171e1-ba91-4fac-91c5-c4fa3c965565">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc6171e1-ba91-4fac-91c5-c4fa3c965565">
											<gml:posList>35.66908381803278 139.74671209524286 6.038 35.66907439945408 139.74670063958672 6.038 35.66907439945408 139.74670063958672 10.7 35.66908381803278 139.74671209524286 10.7 35.66908381803278 139.74671209524286 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6cd9cc1-b0dd-4d70-bc75-701c8c6cecdc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6cd9cc1-b0dd-4d70-bc75-701c8c6cecdc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6cd9cc1-b0dd-4d70-bc75-701c8c6cecdc">
											<gml:posList>35.6690683692792 139.74670065714812 10.7 35.6690683692792 139.74670065714812 9.67 35.6690777878579 139.74671211280344 9.67 35.6690777878579 139.74671211280344 10.7 35.6690683692792 139.74670065714812 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab21de3b-b40b-40d7-9db5-be46356e9cc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab21de3b-b40b-40d7-9db5-be46356e9cc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab21de3b-b40b-40d7-9db5-be46356e9cc9">
											<gml:posList>35.66903062481932 139.74677035447286 10.7 35.66903062481932 139.74677035447286 9.67 35.66896827636437 139.74669451322097 9.67 35.66896827636437 139.74669451322097 10.7 35.66903062481932 139.74677035447286 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f5196a2-5443-48d4-a1cb-711e2c1c04c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f5196a2-5443-48d4-a1cb-711e2c1c04c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f5196a2-5443-48d4-a1cb-711e2c1c04c9">
											<gml:posList>35.668962255219 139.7466945528652 6.038 35.66903064815094 139.7467777332252 6.038 35.66903064815094 139.7467777332252 10.7 35.668962255219 139.7466945528652 10.7 35.668962255219 139.7466945528652 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-058f7006-cbac-40ee-bdd8-9e0f5b162637">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-058f7006-cbac-40ee-bdd8-9e0f5b162637">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-058f7006-cbac-40ee-bdd8-9e0f5b162637">
											<gml:posList>35.6690777878579 139.74671211280344 10.7 35.6690777878579 139.74671211280344 9.67 35.66903062481932 139.74677035447286 9.67 35.66903062481932 139.74677035447286 10.7 35.6690777878579 139.74671211280344 10.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fd169f9-2b3f-475c-8376-a7c910615da6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fd169f9-2b3f-475c-8376-a7c910615da6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fd169f9-2b3f-475c-8376-a7c910615da6">
											<gml:posList>35.66903064815094 139.7467777332252 6.038 35.66908381803278 139.74671209524286 6.038 35.66908381803278 139.74671209524286 10.7 35.66903064815094 139.7467777332252 10.7 35.66903064815094 139.7467777332252 6.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4889</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.11</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>