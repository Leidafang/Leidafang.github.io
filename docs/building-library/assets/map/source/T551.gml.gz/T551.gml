<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a05af407-2870-4d60-b240-4a6a4513f189">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66761365115376 139.73834514912983 0 35.66762714512659 139.73832282046732 0 35.66759163264182 139.73829061963608 0 35.667578147697306 139.73831295932925 0 35.66761365115376 139.73834514912983 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66761365115376 139.73834514912983 15.415 35.667578147697306 139.73831295932925 15.415 35.66759163264182 139.73829061963608 15.415 35.66762714512659 139.73832282046732 15.415 35.66761365115376 139.73834514912983 15.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66761365115376 139.73834514912983 15.415 35.66762714512659 139.73832282046732 15.415 35.66762714512659 139.73832282046732 18.82 35.66761365115376 139.73834514912983 18.82 35.66761365115376 139.73834514912983 15.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66762714512659 139.73832282046732 15.415 35.66759163264182 139.73829061963608 15.415 35.66759163264182 139.73829061963608 18.82 35.66762714512659 139.73832282046732 18.82 35.66762714512659 139.73832282046732 15.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66759163264182 139.73829061963608 15.415 35.667578147697306 139.73831295932925 15.415 35.667578147697306 139.73831295932925 18.82 35.66759163264182 139.73829061963608 18.82 35.66759163264182 139.73829061963608 15.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667578147697306 139.73831295932925 15.415 35.66761365115376 139.73834514912983 15.415 35.66761365115376 139.73834514912983 18.82 35.667578147697306 139.73831295932925 18.82 35.667578147697306 139.73831295932925 15.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66761365115376 139.73834514912983 18.82 35.66762714512659 139.73832282046732 18.82 35.66759163264182 139.73829061963608 18.82 35.667578147697306 139.73831295932925 18.82 35.66761365115376 139.73834514912983 18.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-db398d98-dbac-4c3e-997a-04df740eadaa"/>
							<gml:surfaceMember xlink:href="#poly-c0d6364e-5e54-4c0f-8ce9-8ef17c6ec26d"/>
							<gml:surfaceMember xlink:href="#poly-5f3b5c6c-8d33-4b5e-ab73-8f1a35554dea"/>
							<gml:surfaceMember xlink:href="#poly-3993378d-df4d-447c-977f-54956a545b44"/>
							<gml:surfaceMember xlink:href="#poly-e36776dc-74d4-43d3-a977-48486f747b44"/>
							<gml:surfaceMember xlink:href="#poly-2df20eef-5227-4b7e-a3c8-fb8ed8747c44"/>
							<gml:surfaceMember xlink:href="#poly-a518b94a-4d59-4d69-99c0-4b3817589858"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-db398d98-dbac-4c3e-997a-04df740eadaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db398d98-dbac-4c3e-997a-04df740eadaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db398d98-dbac-4c3e-997a-04df740eadaa">
											<gml:posList>35.66761365115375 139.73834514912986 15.415 35.667578147697306 139.73831295932925 15.415 35.6675916326418 139.73829061963608 15.415 35.66762714512656 139.73832282046732 15.415 35.66761365115375 139.73834514912986 15.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c0d6364e-5e54-4c0f-8ce9-8ef17c6ec26d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0d6364e-5e54-4c0f-8ce9-8ef17c6ec26d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0d6364e-5e54-4c0f-8ce9-8ef17c6ec26d">
											<gml:posList>35.66762714512656 139.73832282046732 18.772 35.6675916326418 139.73829061963608 18.772 35.66758489017443 139.73830179500652 19.134 35.66762039363381 139.73833398480488 19.134 35.66762714512656 139.73832282046732 18.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f3b5c6c-8d33-4b5e-ab73-8f1a35554dea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f3b5c6c-8d33-4b5e-ab73-8f1a35554dea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f3b5c6c-8d33-4b5e-ab73-8f1a35554dea">
											<gml:posList>35.667578147697306 139.73831295932925 18.772 35.66761365115375 139.73834514912986 18.772 35.66762039363381 139.73833398480488 19.134 35.66758489017443 139.73830179500652 19.134 35.667578147697306 139.73831295932925 18.772</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3993378d-df4d-447c-977f-54956a545b44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3993378d-df4d-447c-977f-54956a545b44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3993378d-df4d-447c-977f-54956a545b44">
											<gml:posList>35.66758489017443 139.73830179500652 19.134 35.6675916326418 139.73829061963608 18.772 35.6675916326418 139.73829061963608 15.415 35.667578147697306 139.73831295932925 15.415 35.667578147697306 139.73831295932925 18.772 35.66758489017443 139.73830179500652 19.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e36776dc-74d4-43d3-a977-48486f747b44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e36776dc-74d4-43d3-a977-48486f747b44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e36776dc-74d4-43d3-a977-48486f747b44">
											<gml:posList>35.66762714512656 139.73832282046732 15.415 35.6675916326418 139.73829061963608 15.415 35.6675916326418 139.73829061963608 18.772 35.66762714512656 139.73832282046732 18.772 35.66762714512656 139.73832282046732 15.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2df20eef-5227-4b7e-a3c8-fb8ed8747c44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2df20eef-5227-4b7e-a3c8-fb8ed8747c44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2df20eef-5227-4b7e-a3c8-fb8ed8747c44">
											<gml:posList>35.667578147697306 139.73831295932925 15.415 35.66761365115375 139.73834514912986 15.415 35.66761365115375 139.73834514912986 18.772 35.667578147697306 139.73831295932925 18.772 35.667578147697306 139.73831295932925 15.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a518b94a-4d59-4d69-99c0-4b3817589858">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a518b94a-4d59-4d69-99c0-4b3817589858">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a518b94a-4d59-4d69-99c0-4b3817589858">
											<gml:posList>35.66762039363381 139.73833398480488 19.134 35.66761365115375 139.73834514912986 18.772 35.66761365115375 139.73834514912986 15.415 35.66762714512656 139.73832282046732 15.415 35.66762714512656 139.73832282046732 18.772 35.66762039363381 139.73833398480488 19.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2203</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">5</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">2</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>