<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a10864af-c4f7-4d43-af88-f064e866be44">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">35</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670920471712044 139.7438370588378 0 35.67086740739894 139.74410361070758 0 35.671043845167574 139.74415634846042 0 35.67109690058953 139.7438898070949 0 35.670920471712044 139.7438370588378 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670920471712044 139.7438370588378 7.06 35.67109690058953 139.7438898070949 7.06 35.671043845167574 139.74415634846042 7.06 35.67086740739894 139.74410361070758 7.06 35.670920471712044 139.7438370588378 7.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670920471712044 139.7438370588378 7.06 35.67086740739894 139.74410361070758 7.06 35.67086740739894 139.74410361070758 38.5 35.670920471712044 139.7438370588378 38.5 35.670920471712044 139.7438370588378 7.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67086740739894 139.74410361070758 7.06 35.671043845167574 139.74415634846042 7.06 35.671043845167574 139.74415634846042 38.5 35.67086740739894 139.74410361070758 38.5 35.67086740739894 139.74410361070758 7.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671043845167574 139.74415634846042 7.06 35.67109690058953 139.7438898070949 7.06 35.67109690058953 139.7438898070949 38.5 35.671043845167574 139.74415634846042 38.5 35.671043845167574 139.74415634846042 7.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67109690058953 139.7438898070949 7.06 35.670920471712044 139.7438370588378 7.06 35.670920471712044 139.7438370588378 38.5 35.67109690058953 139.7438898070949 38.5 35.67109690058953 139.7438898070949 7.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670920471712044 139.7438370588378 38.5 35.67086740739894 139.74410361070758 38.5 35.671043845167574 139.74415634846042 38.5 35.67109690058953 139.7438898070949 38.5 35.670920471712044 139.7438370588378 38.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0a115406-ff68-480e-a66d-3c10e59014e4"/>
							<gml:surfaceMember xlink:href="#poly-b76fa5b7-4a61-4074-987e-667b443aac28"/>
							<gml:surfaceMember xlink:href="#poly-367a347b-e7ea-487e-bc09-57c749473e50"/>
							<gml:surfaceMember xlink:href="#poly-21daed21-0114-49d1-a67b-d86f75c757f1"/>
							<gml:surfaceMember xlink:href="#poly-9c6adedb-b0eb-4430-bc7b-909aff456b7f"/>
							<gml:surfaceMember xlink:href="#poly-44defc95-8785-4a90-8ea3-45fde074d811"/>
							<gml:surfaceMember xlink:href="#poly-3b9e7817-0826-4365-8364-a1584d200066"/>
							<gml:surfaceMember xlink:href="#poly-7d030de9-a8d9-47f4-9073-4978917f6c2d"/>
							<gml:surfaceMember xlink:href="#poly-e46ae777-5402-4d98-b463-42e4152112ae"/>
							<gml:surfaceMember xlink:href="#poly-c3a39ef3-bb22-4476-b4d0-e2fc3411060b"/>
							<gml:surfaceMember xlink:href="#poly-46879e81-b1bc-45d6-817a-b6b44a5b23ec"/>
							<gml:surfaceMember xlink:href="#poly-2deb280a-46c1-441a-adc7-bc392f779c38"/>
							<gml:surfaceMember xlink:href="#poly-2a10bf24-96b2-4c3f-9f3e-03dab7cce39c"/>
							<gml:surfaceMember xlink:href="#poly-1b42cd25-3ac3-4b6a-9b5e-7f80328b421f"/>
							<gml:surfaceMember xlink:href="#poly-da8de124-3d2b-4dcd-bd7f-15d73f584426"/>
							<gml:surfaceMember xlink:href="#poly-317b1556-b788-4126-818f-8b0c3e344394"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a10864af-c4f7-4d43-af88-f064e866be44_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4d90a7a-7932-40e9-8f80-8783ea5482c9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67099132329368 139.74399979181368 38.544 35.67093787804493 139.7439838120827 38.544 35.67095238114426 139.74391096740962 38.544 35.67100582640248 139.7439269470949 38.544 35.67099132329368 139.74399979181368 38.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77eedb61-12b3-4678-9010-c4062684f24e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77eedb61-12b3-4678-9010-c4062684f24e_0">
											<gml:posList>35.67095238114426 139.74391096740962 46.075 35.67095238114426 139.74391096740962 38.544 35.67093787804493 139.7439838120827 38.544 35.67093787804493 139.7439838120827 46.075 35.67095238114426 139.74391096740962 46.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5112d039-4222-4a30-9e14-6b5b17036408">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5112d039-4222-4a30-9e14-6b5b17036408_0">
											<gml:posList>35.67093787804493 139.7439838120827 46.075 35.67093787804493 139.7439838120827 38.544 35.67099132329368 139.74399979181368 38.544 35.67099132329368 139.74399979181368 46.075 35.67093787804493 139.7439838120827 46.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc070631-6962-4f47-97da-42e14e776c30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc070631-6962-4f47-97da-42e14e776c30_0">
											<gml:posList>35.67099132329368 139.74399979181368 46.075 35.67100582640248 139.7439269470949 46.075 35.67095238114426 139.74391096740962 46.075 35.67093787804493 139.7439838120827 46.075 35.67099132329368 139.74399979181368 46.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b63d663-25f8-4c56-8655-abac462be5de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b63d663-25f8-4c56-8655-abac462be5de_0">
											<gml:posList>35.67100582640248 139.7439269470949 46.075 35.67100582640248 139.7439269470949 38.544 35.67095238114426 139.74391096740962 38.544 35.67095238114426 139.74391096740962 46.075 35.67100582640248 139.7439269470949 46.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfd05dcd-f215-4f19-b293-3470a57199b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfd05dcd-f215-4f19-b293-3470a57199b2_0">
											<gml:posList>35.67099132329368 139.74399979181368 46.075 35.67099132329368 139.74399979181368 38.544 35.67100582640248 139.7439269470949 38.544 35.67100582640248 139.7439269470949 46.075 35.67099132329368 139.74399979181368 46.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a10864af-c4f7-4d43-af88-f064e866be44_BuildingInstallation_1030">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc21220e-296c-42ac-8dd8-1d9e4aa8e268">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6710618925013 139.7438793410674 19.6 35.67107342362093 139.74388278571104 19.6 35.67107090078366 139.74389627612513 19.6 35.67105933374899 139.74389301930773 19.6 35.6710618925013 139.7438793410674 19.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-862de706-5555-4acd-a575-c1e4e02b6a81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-862de706-5555-4acd-a575-c1e4e02b6a81_0">
											<gml:posList>35.6710618925013 139.7438793410674 43.893 35.6710618925013 139.7438793410674 19.6 35.67105933374899 139.74389301930773 19.6 35.67105933374899 139.74389301930773 43.893 35.6710618925013 139.7438793410674 43.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbd8ace5-6ef4-45b3-9e5b-bcc1c5ab3d14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbd8ace5-6ef4-45b3-9e5b-bcc1c5ab3d14_0">
											<gml:posList>35.67105933374899 139.74389301930773 43.893 35.67105933374899 139.74389301930773 19.6 35.67107090078366 139.74389627612513 19.6 35.67107090078366 139.74389627612513 43.893 35.67105933374899 139.74389301930773 43.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39ba3eaf-cf00-4483-a0e9-c5e8ebc36889">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39ba3eaf-cf00-4483-a0e9-c5e8ebc36889_0">
											<gml:posList>35.67105933374899 139.74389301930773 43.893 35.67107090078366 139.74389627612513 43.893 35.67107342362093 139.74388278571104 43.893 35.6710618925013 139.7438793410674 43.893 35.67105933374899 139.74389301930773 43.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f64d8bf5-9506-4931-ac9e-2338c3149189">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f64d8bf5-9506-4931-ac9e-2338c3149189_0">
											<gml:posList>35.67107342362093 139.74388278571104 43.893 35.67107342362093 139.74388278571104 19.6 35.6710618925013 139.7438793410674 19.6 35.6710618925013 139.7438793410674 43.893 35.67107342362093 139.74388278571104 43.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e356ce3d-50ae-40cb-a125-1041cd1f7bfe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e356ce3d-50ae-40cb-a125-1041cd1f7bfe_0">
											<gml:posList>35.67107090078366 139.74389627612513 43.893 35.67107090078366 139.74389627612513 19.6 35.67107342362093 139.74388278571104 19.6 35.67107342362093 139.74388278571104 43.893 35.67107090078366 139.74389627612513 43.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a10864af-c4f7-4d43-af88-f064e866be44_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc81c23d-2823-4612-90d9-40ec8521b842">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67097573201373 139.74385744393223 38.846 35.67097628877959 139.74385463754004 38.846 35.671005265343965 139.74386329867545 38.846 35.6710047085779 139.7438661050686 38.846 35.67097573201373 139.74385744393223 38.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe79e9b0-5802-4183-b818-ed7fa39872ea">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6710047085779 139.7438661050686 38.544 35.6709934117423 139.74392323832083 38.544 35.670964435182164 139.74391457716501 38.544 35.67097573201373 139.74385744393223 38.544 35.6710047085779 139.7438661050686 38.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-518321ab-5c67-4bf4-847d-e91b64c73674">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67096020307921 139.7439447162997 46.075 35.670962807340736 139.74393162348323 46.075 35.670985770401735 139.7439384797496 46.075 35.67098316614768 139.74395158361594 46.075 35.67096020307921 139.7439447162997 46.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bd1acbd-cbfd-4788-9f68-3a65576b0646">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67105659355224 139.74400227079556 19.6 35.67107056793625 139.74400645284024 19.6 35.671065215708566 139.74403335667583 19.6 35.671051241325465 139.74402917462672 19.6 35.67105659355224 139.74400227079556 19.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2bb3f6a-2114-4ceb-b5db-ed23b23a0ed5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67103766325708 139.74414621478675 19.6 35.671024185238046 139.74414284959698 19.6 35.671031570664184 139.74409847924136 19.6 35.67104504868444 139.74410184442397 19.6 35.67103766325708 139.74414621478675 19.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e21e702b-6e63-4ad6-8314-72a67f8d7d7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e21e702b-6e63-4ad6-8314-72a67f8d7d7f_0">
											<gml:posList>35.671005265343965 139.74386329867545 38.846 35.67097628877959 139.74385463754004 38.846 35.67097628877959 139.74385463754004 41.315 35.671005265343965 139.74386329867545 41.315 35.671005265343965 139.74386329867545 38.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ab01667-f8fb-4c94-8ef7-c0eb8a50abda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ab01667-f8fb-4c94-8ef7-c0eb8a50abda_0">
											<gml:posList>35.6710047085779 139.7438661050686 38.544 35.67097573201373 139.74385744393223 38.544 35.67097573201373 139.74385744393223 38.846 35.6710047085779 139.7438661050686 38.846 35.6710047085779 139.7438661050686 38.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f65cbac-e2eb-4b82-a523-aa4124af5cdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f65cbac-e2eb-4b82-a523-aa4124af5cdf_0">
											<gml:posList>35.67097573201373 139.74385744393223 38.846 35.67097573201373 139.74385744393223 38.544 35.670964435182164 139.74391457716501 38.544 35.670964435182164 139.74391457716501 41.315 35.67097628877959 139.74385463754004 41.315 35.67097628877959 139.74385463754004 38.846 35.67097573201373 139.74385744393223 38.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05d607cd-db19-49a9-959b-cc3ee1b9a130">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05d607cd-db19-49a9-959b-cc3ee1b9a130_0">
											<gml:posList>35.671005265343965 139.74386329867545 41.315 35.67097628877959 139.74385463754004 41.315 35.670964435182164 139.74391457716501 41.315 35.6709934117423 139.74392323832083 41.315 35.671005265343965 139.74386329867545 41.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-624058b2-0114-4b9a-b11f-38e30c200b00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-624058b2-0114-4b9a-b11f-38e30c200b00_0">
											<gml:posList>35.671005265343965 139.74386329867545 41.315 35.6709934117423 139.74392323832083 41.315 35.6709934117423 139.74392323832083 38.544 35.6710047085779 139.7438661050686 38.544 35.6710047085779 139.7438661050686 38.846 35.671005265343965 139.74386329867545 38.846 35.671005265343965 139.74386329867545 41.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c33ecd04-5eea-4227-8a77-21af52f53473">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c33ecd04-5eea-4227-8a77-21af52f53473_0">
											<gml:posList>35.670964435182164 139.74391457716501 38.544 35.6709934117423 139.74392323832083 38.544 35.6709934117423 139.74392323832083 41.315 35.670964435182164 139.74391457716501 41.315 35.670964435182164 139.74391457716501 38.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-399cdf1f-1ad6-428c-b886-e0996731f5ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-399cdf1f-1ad6-428c-b886-e0996731f5ca_0">
											<gml:posList>35.670985770401735 139.7439384797496 49.073 35.670985770401735 139.7439384797496 46.075 35.670962807340736 139.74393162348323 46.075 35.670962807340736 139.74393162348323 49.073 35.670985770401735 139.7439384797496 49.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77b8cdec-6661-49a8-9484-00153f605d0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77b8cdec-6661-49a8-9484-00153f605d0f_0">
											<gml:posList>35.670962807340736 139.74393162348323 49.073 35.670962807340736 139.74393162348323 46.075 35.67096020307921 139.7439447162997 46.075 35.67096020307921 139.7439447162997 49.073 35.670962807340736 139.74393162348323 49.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-adb1b566-6dc9-4eb5-aaf9-28cd21224191">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-adb1b566-6dc9-4eb5-aaf9-28cd21224191_0">
											<gml:posList>35.67098316614768 139.74395158361594 49.073 35.670985770401735 139.7439384797496 49.073 35.670962807340736 139.74393162348323 49.073 35.67096020307921 139.7439447162997 49.073 35.67098316614768 139.74395158361594 49.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36680f22-d9fe-4a6d-8ed7-6922cd93004a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36680f22-d9fe-4a6d-8ed7-6922cd93004a_0">
											<gml:posList>35.67098316614768 139.74395158361594 49.073 35.67098316614768 139.74395158361594 46.075 35.670985770401735 139.7439384797496 46.075 35.670985770401735 139.7439384797496 49.073 35.67098316614768 139.74395158361594 49.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7daedf91-b286-4637-8679-2675556dc2b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7daedf91-b286-4637-8679-2675556dc2b3_0">
											<gml:posList>35.67096020307921 139.7439447162997 49.073 35.67096020307921 139.7439447162997 46.075 35.67098316614768 139.74395158361594 46.075 35.67098316614768 139.74395158361594 49.073 35.67096020307921 139.7439447162997 49.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c6a1173-00d1-4f7e-b8c5-d2d8340eae21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c6a1173-00d1-4f7e-b8c5-d2d8340eae21_0">
											<gml:posList>35.67107056793625 139.74400645284024 19.6 35.67105659355224 139.74400227079556 19.6 35.67105659355224 139.74400227079556 20.321 35.67107056793625 139.74400645284024 20.321 35.67107056793625 139.74400645284024 19.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f93d617b-ec97-4d95-a422-01b91c175456">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f93d617b-ec97-4d95-a422-01b91c175456_0">
											<gml:posList>35.67105659355224 139.74400227079556 19.6 35.671051241325465 139.74402917462672 19.6 35.671051241325465 139.74402917462672 20.321 35.67105659355224 139.74400227079556 20.321 35.67105659355224 139.74400227079556 19.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2322c81-adb7-4130-8e55-5b6fead250dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2322c81-adb7-4130-8e55-5b6fead250dc_0">
											<gml:posList>35.67105659355224 139.74400227079556 20.321 35.671051241325465 139.74402917462672 20.321 35.671065215708566 139.74403335667583 20.321 35.67107056793625 139.74400645284024 20.321 35.67105659355224 139.74400227079556 20.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36752cbb-ee39-4293-8637-fdbb7b3ec0f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36752cbb-ee39-4293-8637-fdbb7b3ec0f7_0">
											<gml:posList>35.671065215708566 139.74403335667583 19.6 35.67107056793625 139.74400645284024 19.6 35.67107056793625 139.74400645284024 20.321 35.671065215708566 139.74403335667583 20.321 35.671065215708566 139.74403335667583 19.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b57bc7e-9c05-4acb-9592-a26944a07491">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b57bc7e-9c05-4acb-9592-a26944a07491_0">
											<gml:posList>35.671065215708566 139.74403335667583 19.6 35.671065215708566 139.74403335667583 20.321 35.671051241325465 139.74402917462672 20.321 35.671051241325465 139.74402917462672 19.6 35.671065215708566 139.74403335667583 19.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8742a9f1-947a-47c7-9773-972abc2f0321">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8742a9f1-947a-47c7-9773-972abc2f0321_0">
											<gml:posList>35.67104504868444 139.74410184442397 19.6 35.671031570664184 139.74409847924136 19.6 35.671031570664184 139.74409847924136 20.321 35.67104504868444 139.74410184442397 20.321 35.67104504868444 139.74410184442397 19.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12ebc623-156c-424f-b39d-8b5198f45a72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12ebc623-156c-424f-b39d-8b5198f45a72_0">
											<gml:posList>35.671031570664184 139.74409847924136 19.6 35.671024185238046 139.74414284959698 19.6 35.671024185238046 139.74414284959698 20.321 35.671031570664184 139.74409847924136 20.321 35.671031570664184 139.74409847924136 19.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80d922f4-b598-4866-8945-e36dfb02a35f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80d922f4-b598-4866-8945-e36dfb02a35f_0">
											<gml:posList>35.671031570664184 139.74409847924136 20.321 35.671024185238046 139.74414284959698 20.321 35.67103766325708 139.74414621478675 20.321 35.67104504868444 139.74410184442397 20.321 35.671031570664184 139.74409847924136 20.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c24df5f3-f9bc-4d3d-a95a-1a2571f4d327">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c24df5f3-f9bc-4d3d-a95a-1a2571f4d327_0">
											<gml:posList>35.67103766325708 139.74414621478675 19.6 35.67104504868444 139.74410184442397 19.6 35.67104504868444 139.74410184442397 20.321 35.67103766325708 139.74414621478675 20.321 35.67103766325708 139.74414621478675 19.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c54124e3-4dba-4c72-a7cc-a08906a3a6d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c54124e3-4dba-4c72-a7cc-a08906a3a6d4_0">
											<gml:posList>35.671024185238046 139.74414284959698 19.6 35.67103766325708 139.74414621478675 19.6 35.67103766325708 139.74414621478675 20.321 35.671024185238046 139.74414284959698 20.321 35.671024185238046 139.74414284959698 19.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0a115406-ff68-480e-a66d-3c10e59014e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a115406-ff68-480e-a66d-3c10e59014e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a115406-ff68-480e-a66d-3c10e59014e4">
											<gml:posList>35.67092047171205 139.7438370588378 7.06 35.67109690058954 139.7438898070949 7.06 35.671043845167574 139.74415634846042 7.06 35.67086740739895 139.74410361070758 7.06 35.67092047171205 139.7438370588378 7.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b76fa5b7-4a61-4074-987e-667b443aac28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b76fa5b7-4a61-4074-987e-667b443aac28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b76fa5b7-4a61-4074-987e-667b443aac28">
											<gml:posList>35.67092047171205 139.7438370588378 38.846 35.67092271950331 139.7438415963722 38.846 35.67105824400342 139.7438821177728 38.846 35.6710618925013 139.7438793410674 38.846 35.67092047171205 139.7438370588378 38.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-367a347b-e7ea-487e-bc09-57c749473e50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-367a347b-e7ea-487e-bc09-57c749473e50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-367a347b-e7ea-487e-bc09-57c749473e50">
											<gml:posList>35.67086740739895 139.74410361070758 38.846 35.67087111000898 139.74410086709767 38.846 35.67092271950331 139.7438415963722 38.846 35.67092047171205 139.7438370588378 38.846 35.67086740739895 139.74410361070758 38.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21daed21-0114-49d1-a67b-d86f75c757f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21daed21-0114-49d1-a67b-d86f75c757f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21daed21-0114-49d1-a67b-d86f75c757f1">
											<gml:posList>35.67105824400342 139.7438821177728 38.544 35.67092271950331 139.7438415963722 38.544 35.67087111000898 139.74410086709767 38.544 35.671009537480515 139.7441422472963 38.544 35.67105824400342 139.7438821177728 38.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c6adedb-b0eb-4430-bc7b-909aff456b7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c6adedb-b0eb-4430-bc7b-909aff456b7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c6adedb-b0eb-4430-bc7b-909aff456b7f">
											<gml:posList>35.6710618925013 139.7438793410674 38.846 35.67105824400342 139.7438821177728 38.846 35.671009537480515 139.7441422472963 38.846 35.67101182131514 139.74414678480423 38.846 35.6710618925013 139.7438793410674 38.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44defc95-8785-4a90-8ea3-45fde074d811">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44defc95-8785-4a90-8ea3-45fde074d811">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44defc95-8785-4a90-8ea3-45fde074d811">
											<gml:posList>35.6710618925013 139.7438793410674 19.6 35.67101182131514 139.74414678480423 19.6 35.671043845167574 139.74415634846042 19.6 35.67109690058954 139.7438898070949 19.6 35.6710618925013 139.7438793410674 19.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b9e7817-0826-4365-8364-a1584d200066">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b9e7817-0826-4365-8364-a1584d200066">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b9e7817-0826-4365-8364-a1584d200066">
											<gml:posList>35.67101182131514 139.74414678480423 38.846 35.671009537480515 139.7441422472963 38.846 35.67087111000898 139.74410086709767 38.846 35.67086740739895 139.74410361070758 38.846 35.67101182131514 139.74414678480423 38.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d030de9-a8d9-47f4-9073-4978917f6c2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d030de9-a8d9-47f4-9073-4978917f6c2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d030de9-a8d9-47f4-9073-4978917f6c2d">
											<gml:posList>35.67092271950331 139.7438415963722 38.846 35.67092271950331 139.7438415963722 38.544 35.67105824400342 139.7438821177728 38.544 35.67105824400342 139.7438821177728 38.846 35.67092271950331 139.7438415963722 38.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e46ae777-5402-4d98-b463-42e4152112ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e46ae777-5402-4d98-b463-42e4152112ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e46ae777-5402-4d98-b463-42e4152112ae">
											<gml:posList>35.67092047171205 139.7438370588378 7.06 35.67092047171205 139.7438370588378 38.846 35.6710618925013 139.7438793410674 38.846 35.6710618925013 139.7438793410674 19.6 35.67109690058954 139.7438898070949 19.6 35.67109690058954 139.7438898070949 7.06 35.67092047171205 139.7438370588378 7.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3a39ef3-bb22-4476-b4d0-e2fc3411060b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3a39ef3-bb22-4476-b4d0-e2fc3411060b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3a39ef3-bb22-4476-b4d0-e2fc3411060b">
											<gml:posList>35.67092047171205 139.7438370588378 7.06 35.67086740739895 139.74410361070758 7.06 35.67086740739895 139.74410361070758 38.846 35.67092047171205 139.7438370588378 38.846 35.67092047171205 139.7438370588378 7.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46879e81-b1bc-45d6-817a-b6b44a5b23ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46879e81-b1bc-45d6-817a-b6b44a5b23ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46879e81-b1bc-45d6-817a-b6b44a5b23ec">
											<gml:posList>35.67087111000898 139.74410086709767 38.846 35.67087111000898 139.74410086709767 38.544 35.67092271950331 139.7438415963722 38.544 35.67092271950331 139.7438415963722 38.846 35.67087111000898 139.74410086709767 38.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2deb280a-46c1-441a-adc7-bc392f779c38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2deb280a-46c1-441a-adc7-bc392f779c38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2deb280a-46c1-441a-adc7-bc392f779c38">
											<gml:posList>35.67105824400342 139.7438821177728 38.846 35.67105824400342 139.7438821177728 38.544 35.671009537480515 139.7441422472963 38.544 35.671009537480515 139.7441422472963 38.846 35.67105824400342 139.7438821177728 38.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a10bf24-96b2-4c3f-9f3e-03dab7cce39c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a10bf24-96b2-4c3f-9f3e-03dab7cce39c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a10bf24-96b2-4c3f-9f3e-03dab7cce39c">
											<gml:posList>35.67101182131514 139.74414678480423 19.6 35.6710618925013 139.7438793410674 19.6 35.6710618925013 139.7438793410674 38.846 35.67101182131514 139.74414678480423 38.846 35.67101182131514 139.74414678480423 19.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b42cd25-3ac3-4b6a-9b5e-7f80328b421f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b42cd25-3ac3-4b6a-9b5e-7f80328b421f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b42cd25-3ac3-4b6a-9b5e-7f80328b421f">
											<gml:posList>35.671043845167574 139.74415634846042 7.06 35.67109690058954 139.7438898070949 7.06 35.67109690058954 139.7438898070949 19.6 35.671043845167574 139.74415634846042 19.6 35.671043845167574 139.74415634846042 7.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da8de124-3d2b-4dcd-bd7f-15d73f584426">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da8de124-3d2b-4dcd-bd7f-15d73f584426">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da8de124-3d2b-4dcd-bd7f-15d73f584426">
											<gml:posList>35.671009537480515 139.7441422472963 38.846 35.671009537480515 139.7441422472963 38.544 35.67087111000898 139.74410086709767 38.544 35.67087111000898 139.74410086709767 38.846 35.671009537480515 139.7441422472963 38.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-317b1556-b788-4126-818f-8b0c3e344394">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-317b1556-b788-4126-818f-8b0c3e344394">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-317b1556-b788-4126-818f-8b0c3e344394">
											<gml:posList>35.67101182131514 139.74414678480423 19.6 35.67101182131514 139.74414678480423 38.846 35.67086740739895 139.74410361070758 38.846 35.67086740739895 139.74410361070758 7.06 35.671043845167574 139.74415634846042 7.06 35.671043845167574 139.74415634846042 19.6 35.67101182131514 139.74414678480423 19.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8148</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">484.8061</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.1</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>