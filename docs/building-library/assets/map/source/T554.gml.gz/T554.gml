<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a230b684-6ae4-415b-803a-131caaa01ad0">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">11.3</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66951475682614 139.7496065360331 0 35.669481852526275 139.74970429556305 0 35.66956034462453 139.74974397982513 0 35.66956613660348 139.74972544939635 0 35.66950528156286 139.74969469412304 0 35.669544770235326 139.7495772765918 0 35.66952033443144 139.74956493043854 0 35.66952437323319 139.74955290801603 0 35.66951436409274 139.74954730703496 0 35.66949738125391 139.74959775040472 0 35.66951475682614 139.7496065360331 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66951475682614 139.7496065360331 6.41 35.66949738125391 139.74959775040472 6.41 35.66951436409274 139.74954730703496 6.41 35.66952437323319 139.74955290801603 6.41 35.66952033443144 139.74956493043854 6.41 35.669544770235326 139.7495772765918 6.41 35.66950528156286 139.74969469412304 6.41 35.66956613660348 139.74972544939635 6.41 35.66956034462453 139.74974397982513 6.41 35.669481852526275 139.74970429556305 6.41 35.66951475682614 139.7496065360331 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66951475682614 139.7496065360331 6.41 35.669481852526275 139.74970429556305 6.41 35.669481852526275 139.74970429556305 17.72 35.66951475682614 139.7496065360331 17.72 35.66951475682614 139.7496065360331 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669481852526275 139.74970429556305 6.41 35.66956034462453 139.74974397982513 6.41 35.66956034462453 139.74974397982513 17.72 35.669481852526275 139.74970429556305 17.72 35.669481852526275 139.74970429556305 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66956034462453 139.74974397982513 6.41 35.66956613660348 139.74972544939635 6.41 35.66956613660348 139.74972544939635 17.72 35.66956034462453 139.74974397982513 17.72 35.66956034462453 139.74974397982513 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66956613660348 139.74972544939635 6.41 35.66950528156286 139.74969469412304 6.41 35.66950528156286 139.74969469412304 17.72 35.66956613660348 139.74972544939635 17.72 35.66956613660348 139.74972544939635 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66950528156286 139.74969469412304 6.41 35.669544770235326 139.7495772765918 6.41 35.669544770235326 139.7495772765918 17.72 35.66950528156286 139.74969469412304 17.72 35.66950528156286 139.74969469412304 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669544770235326 139.7495772765918 6.41 35.66952033443144 139.74956493043854 6.41 35.66952033443144 139.74956493043854 17.72 35.669544770235326 139.7495772765918 17.72 35.669544770235326 139.7495772765918 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66952033443144 139.74956493043854 6.41 35.66952437323319 139.74955290801603 6.41 35.66952437323319 139.74955290801603 17.72 35.66952033443144 139.74956493043854 17.72 35.66952033443144 139.74956493043854 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66952437323319 139.74955290801603 6.41 35.66951436409274 139.74954730703496 6.41 35.66951436409274 139.74954730703496 17.72 35.66952437323319 139.74955290801603 17.72 35.66952437323319 139.74955290801603 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66951436409274 139.74954730703496 6.41 35.66949738125391 139.74959775040472 6.41 35.66949738125391 139.74959775040472 17.72 35.66951436409274 139.74954730703496 17.72 35.66951436409274 139.74954730703496 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66949738125391 139.74959775040472 6.41 35.66951475682614 139.7496065360331 6.41 35.66951475682614 139.7496065360331 17.72 35.66949738125391 139.74959775040472 17.72 35.66949738125391 139.74959775040472 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66951475682614 139.7496065360331 17.72 35.669481852526275 139.74970429556305 17.72 35.66956034462453 139.74974397982513 17.72 35.66956613660348 139.74972544939635 17.72 35.66950528156286 139.74969469412304 17.72 35.669544770235326 139.7495772765918 17.72 35.66952033443144 139.74956493043854 17.72 35.66952437323319 139.74955290801603 17.72 35.66951436409274 139.74954730703496 17.72 35.66949738125391 139.74959775040472 17.72 35.66951475682614 139.7496065360331 17.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5f688772-41ae-41a9-a097-1aa8c755150c"/>
							<gml:surfaceMember xlink:href="#poly-38bee5c9-6b4f-43c4-836c-830a17225b46"/>
							<gml:surfaceMember xlink:href="#poly-159b46e6-0fc8-4057-ad62-f1f06bee7a19"/>
							<gml:surfaceMember xlink:href="#poly-11b15a2b-6210-4efa-80b5-fff0db095e5c"/>
							<gml:surfaceMember xlink:href="#poly-99da5ca0-e82f-4440-bf48-aa023b1fddec"/>
							<gml:surfaceMember xlink:href="#poly-354f2eae-8af6-4179-b2b8-4b5a5d2db3d2"/>
							<gml:surfaceMember xlink:href="#poly-b7ed3357-f17f-4415-95d5-1f4fca7f4e97"/>
							<gml:surfaceMember xlink:href="#poly-3c7ca6a7-d197-4d25-859b-2e19986f9322"/>
							<gml:surfaceMember xlink:href="#poly-a74bf4f0-b0ab-4d84-8468-a167eaacecae"/>
							<gml:surfaceMember xlink:href="#poly-58e5b5eb-dd6e-4f7d-ac14-a25b21dd7019"/>
							<gml:surfaceMember xlink:href="#poly-7db22fa8-c811-4d24-a3bc-41a6c304d4b5"/>
							<gml:surfaceMember xlink:href="#poly-127c1914-639d-46dd-a8c1-489467483af7"/>
							<gml:surfaceMember xlink:href="#poly-0802cb9f-9ec2-4a89-8aea-4d649093f7af"/>
							<gml:surfaceMember xlink:href="#poly-43684bc4-4bbb-4ae4-b7cc-9d165bb341ed"/>
							<gml:surfaceMember xlink:href="#poly-159127cf-1fa7-42e3-9dd1-695f253e53a0"/>
							<gml:surfaceMember xlink:href="#poly-825afab8-d6a9-4712-a520-78f59feb04b2"/>
							<gml:surfaceMember xlink:href="#poly-01e16369-1499-4f59-8bf5-c738f3e52462"/>
							<gml:surfaceMember xlink:href="#poly-77253120-05f1-4213-b036-c3f5086ec618"/>
							<gml:surfaceMember xlink:href="#poly-f40c08dc-3924-4930-acb3-90f74740f06f"/>
							<gml:surfaceMember xlink:href="#poly-f9d9ed10-5109-4a90-9031-5fcb216b73a7"/>
							<gml:surfaceMember xlink:href="#poly-38968bd6-a311-4a0c-a6d6-88b246e4698e"/>
							<gml:surfaceMember xlink:href="#poly-49fc8247-8321-42bf-b603-790c2a3c9e91"/>
							<gml:surfaceMember xlink:href="#poly-e2af8514-dd37-4031-a317-2cf249fe88dc"/>
							<gml:surfaceMember xlink:href="#poly-279607cc-512d-4ff1-af65-8e782091f16b"/>
							<gml:surfaceMember xlink:href="#poly-28eeef53-0be2-492d-88f9-dbc2242b5466"/>
							<gml:surfaceMember xlink:href="#poly-2fabc588-969f-42ae-ba52-66b1f4c9f99d"/>
							<gml:surfaceMember xlink:href="#poly-744d8dc0-1408-403a-bdec-e6a955c6a526"/>
							<gml:surfaceMember xlink:href="#poly-75cd94a4-d3ff-4d2b-be93-85f71aa71dc9"/>
							<gml:surfaceMember xlink:href="#poly-c27a5ba1-7ead-47c7-aaba-526589073041"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5f688772-41ae-41a9-a097-1aa8c755150c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f688772-41ae-41a9-a097-1aa8c755150c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f688772-41ae-41a9-a097-1aa8c755150c">
											<gml:posList>35.669505281562834 139.749694694123 6.41 35.66956613660347 139.74972544939635 6.41 35.669560344624514 139.74974397982513 6.41 35.66948185252623 139.74970429556302 6.41 35.66951475682612 139.74960653603307 6.41 35.6694973812539 139.7495977504047 6.41 35.66951436409274 139.74954730703496 6.41 35.669524373233216 139.74955290801603 6.41 35.66952033443141 139.74956493043854 6.41 35.66954477023532 139.7495772765918 6.41 35.669505281562834 139.749694694123 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38bee5c9-6b4f-43c4-836c-830a17225b46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38bee5c9-6b4f-43c4-836c-830a17225b46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38bee5c9-6b4f-43c4-836c-830a17225b46">
											<gml:posList>35.6694973812539 139.7495977504047 11.217 35.66950003935832 139.74959638895365 11.217 35.66951547503304 139.74955054239342 11.217 35.66951436409274 139.74954730703496 11.217 35.6694973812539 139.7495977504047 11.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-159b46e6-0fc8-4057-ad62-f1f06bee7a19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-159b46e6-0fc8-4057-ad62-f1f06bee7a19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-159b46e6-0fc8-4057-ad62-f1f06bee7a19">
											<gml:posList>35.66951475682612 139.74960653603307 11.217 35.66951553941504 139.7496042265724 11.217 35.66950003935832 139.74959638895365 11.217 35.6694973812539 139.7495977504047 11.217 35.66951475682612 139.74960653603307 11.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11b15a2b-6210-4efa-80b5-fff0db095e5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11b15a2b-6210-4efa-80b5-fff0db095e5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11b15a2b-6210-4efa-80b5-fff0db095e5c">
											<gml:posList>35.669505281562834 139.749694694123 10.968 35.6695319970612 139.74961513402215 10.968 35.66951475682612 139.74960653603307 10.136 35.66948185252623 139.74970429556302 10.136 35.669505281562834 139.749694694123 10.968</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-99da5ca0-e82f-4440-bf48-aa023b1fddec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99da5ca0-e82f-4440-bf48-aa023b1fddec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99da5ca0-e82f-4440-bf48-aa023b1fddec">
											<gml:posList>35.66951436409274 139.74954730703496 11.217 35.66951547503304 139.74955054239342 11.217 35.66952173314137 139.74955424735788 11.217 35.669524373233216 139.74955290801603 11.217 35.66951436409274 139.74954730703496 11.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-354f2eae-8af6-4179-b2b8-4b5a5d2db3d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-354f2eae-8af6-4179-b2b8-4b5a5d2db3d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-354f2eae-8af6-4179-b2b8-4b5a5d2db3d2">
											<gml:posList>35.66952033443141 139.74956493043854 11.217 35.669524373233216 139.74955290801603 11.217 35.66952173314137 139.74955424735788 11.217 35.66951770336086 139.74956628081662 11.217 35.66952033443141 139.74956493043854 11.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b7ed3357-f17f-4415-95d5-1f4fca7f4e97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7ed3357-f17f-4415-95d5-1f4fca7f4e97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7ed3357-f17f-4415-95d5-1f4fca7f4e97">
											<gml:posList>35.66951770336086 139.74956628081662 10.892 35.66952173314137 139.74955424735788 10.892 35.66951547503304 139.74955054239342 10.892 35.66950003935832 139.74959638895365 10.892 35.66951553941504 139.7496042265724 10.892 35.66953089512101 139.74961187656044 10.892 35.66954212113717 139.7495786269887 10.892 35.66951770336086 139.74956628081662 10.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3c7ca6a7-d197-4d25-859b-2e19986f9322">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c7ca6a7-d197-4d25-859b-2e19986f9322">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c7ca6a7-d197-4d25-859b-2e19986f9322">
											<gml:posList>35.66951475682612 139.74960653603307 11.217 35.6695319970612 139.74961513402215 11.217 35.66953089512101 139.74961187656044 11.217 35.66951553941504 139.7496042265724 11.217 35.66951475682612 139.74960653603307 11.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a74bf4f0-b0ab-4d84-8468-a167eaacecae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a74bf4f0-b0ab-4d84-8468-a167eaacecae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a74bf4f0-b0ab-4d84-8468-a167eaacecae">
											<gml:posList>35.669560344624514 139.74974397982513 10.136 35.66956613660347 139.74972544939635 10.968 35.669505281562834 139.749694694123 10.968 35.66948185252623 139.74970429556302 10.136 35.669560344624514 139.74974397982513 10.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-58e5b5eb-dd6e-4f7d-ac14-a25b21dd7019">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58e5b5eb-dd6e-4f7d-ac14-a25b21dd7019">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58e5b5eb-dd6e-4f7d-ac14-a25b21dd7019">
											<gml:posList>35.66952033443141 139.74956493043854 11.217 35.66951770336086 139.74956628081662 11.217 35.66954212113717 139.7495786269887 11.217 35.66954477023532 139.7495772765918 11.217 35.66952033443141 139.74956493043854 11.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7db22fa8-c811-4d24-a3bc-41a6c304d4b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7db22fa8-c811-4d24-a3bc-41a6c304d4b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7db22fa8-c811-4d24-a3bc-41a6c304d4b5">
											<gml:posList>35.66954477023532 139.7495772765918 11.217 35.66954212113717 139.7495786269887 11.217 35.66953089512101 139.74961187656044 11.217 35.6695319970612 139.74961513402215 11.217 35.66954477023532 139.7495772765918 11.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-127c1914-639d-46dd-a8c1-489467483af7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-127c1914-639d-46dd-a8c1-489467483af7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-127c1914-639d-46dd-a8c1-489467483af7">
											<gml:posList>35.66952173314137 139.74955424735788 11.217 35.66952173314137 139.74955424735788 10.892 35.66951770336086 139.74956628081662 10.892 35.66951770336086 139.74956628081662 11.217 35.66952173314137 139.74955424735788 11.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0802cb9f-9ec2-4a89-8aea-4d649093f7af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0802cb9f-9ec2-4a89-8aea-4d649093f7af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0802cb9f-9ec2-4a89-8aea-4d649093f7af">
											<gml:posList>35.669524373233216 139.74955290801603 6.41 35.66951436409274 139.74954730703496 6.41 35.66951436409274 139.74954730703496 11.217 35.669524373233216 139.74955290801603 11.217 35.669524373233216 139.74955290801603 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43684bc4-4bbb-4ae4-b7cc-9d165bb341ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43684bc4-4bbb-4ae4-b7cc-9d165bb341ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43684bc4-4bbb-4ae4-b7cc-9d165bb341ed">
											<gml:posList>35.66951547503304 139.74955054239342 11.217 35.66951547503304 139.74955054239342 10.892 35.66952173314137 139.74955424735788 10.892 35.66952173314137 139.74955424735788 11.217 35.66951547503304 139.74955054239342 11.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-159127cf-1fa7-42e3-9dd1-695f253e53a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-159127cf-1fa7-42e3-9dd1-695f253e53a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-159127cf-1fa7-42e3-9dd1-695f253e53a0">
											<gml:posList>35.66952033443141 139.74956493043854 6.41 35.669524373233216 139.74955290801603 6.41 35.669524373233216 139.74955290801603 11.217 35.66952033443141 139.74956493043854 11.217 35.66952033443141 139.74956493043854 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-825afab8-d6a9-4712-a520-78f59feb04b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-825afab8-d6a9-4712-a520-78f59feb04b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-825afab8-d6a9-4712-a520-78f59feb04b2">
											<gml:posList>35.66954477023532 139.7495772765918 6.41 35.66952033443141 139.74956493043854 6.41 35.66952033443141 139.74956493043854 11.217 35.66954477023532 139.7495772765918 11.217 35.66954477023532 139.7495772765918 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01e16369-1499-4f59-8bf5-c738f3e52462">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01e16369-1499-4f59-8bf5-c738f3e52462">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01e16369-1499-4f59-8bf5-c738f3e52462">
											<gml:posList>35.66951770336086 139.74956628081662 11.217 35.66951770336086 139.74956628081662 10.892 35.66954212113717 139.7495786269887 10.892 35.66954212113717 139.7495786269887 11.217 35.66951770336086 139.74956628081662 11.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77253120-05f1-4213-b036-c3f5086ec618">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77253120-05f1-4213-b036-c3f5086ec618">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77253120-05f1-4213-b036-c3f5086ec618">
											<gml:posList>35.66951436409274 139.74954730703496 6.41 35.6694973812539 139.7495977504047 6.41 35.6694973812539 139.7495977504047 11.217 35.66951436409274 139.74954730703496 11.217 35.66951436409274 139.74954730703496 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f40c08dc-3924-4930-acb3-90f74740f06f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f40c08dc-3924-4930-acb3-90f74740f06f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f40c08dc-3924-4930-acb3-90f74740f06f">
											<gml:posList>35.66950003935832 139.74959638895365 11.217 35.66950003935832 139.74959638895365 10.892 35.66951547503304 139.74955054239342 10.892 35.66951547503304 139.74955054239342 11.217 35.66950003935832 139.74959638895365 11.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9d9ed10-5109-4a90-9031-5fcb216b73a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9d9ed10-5109-4a90-9031-5fcb216b73a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9d9ed10-5109-4a90-9031-5fcb216b73a7">
											<gml:posList>35.66954212113717 139.7495786269887 11.217 35.66954212113717 139.7495786269887 10.892 35.66953089512101 139.74961187656044 10.892 35.66953089512101 139.74961187656044 11.217 35.66954212113717 139.7495786269887 11.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38968bd6-a311-4a0c-a6d6-88b246e4698e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38968bd6-a311-4a0c-a6d6-88b246e4698e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38968bd6-a311-4a0c-a6d6-88b246e4698e">
											<gml:posList>35.66951553941504 139.7496042265724 11.217 35.66951553941504 139.7496042265724 10.892 35.66950003935832 139.74959638895365 10.892 35.66950003935832 139.74959638895365 11.217 35.66951553941504 139.7496042265724 11.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49fc8247-8321-42bf-b603-790c2a3c9e91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49fc8247-8321-42bf-b603-790c2a3c9e91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49fc8247-8321-42bf-b603-790c2a3c9e91">
											<gml:posList>35.6694973812539 139.7495977504047 11.217 35.6694973812539 139.7495977504047 6.41 35.66951475682612 139.74960653603307 6.41 35.66951475682612 139.74960653603307 10.136 35.66951475682612 139.74960653603307 11.217 35.6694973812539 139.7495977504047 11.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2af8514-dd37-4031-a317-2cf249fe88dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2af8514-dd37-4031-a317-2cf249fe88dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2af8514-dd37-4031-a317-2cf249fe88dc">
											<gml:posList>35.66953089512101 139.74961187656044 11.217 35.66953089512101 139.74961187656044 10.892 35.66951553941504 139.7496042265724 10.892 35.66951553941504 139.7496042265724 11.217 35.66953089512101 139.74961187656044 11.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-279607cc-512d-4ff1-af65-8e782091f16b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-279607cc-512d-4ff1-af65-8e782091f16b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-279607cc-512d-4ff1-af65-8e782091f16b">
											<gml:posList>35.66951475682612 139.74960653603307 11.217 35.66951475682612 139.74960653603307 10.136 35.6695319970612 139.74961513402215 10.968 35.6695319970612 139.74961513402215 11.217 35.66951475682612 139.74960653603307 11.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28eeef53-0be2-492d-88f9-dbc2242b5466">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28eeef53-0be2-492d-88f9-dbc2242b5466">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28eeef53-0be2-492d-88f9-dbc2242b5466">
											<gml:posList>35.669505281562834 139.749694694123 6.41 35.66954477023532 139.7495772765918 6.41 35.66954477023532 139.7495772765918 11.217 35.6695319970612 139.74961513402215 11.217 35.6695319970612 139.74961513402215 10.968 35.669505281562834 139.749694694123 10.968 35.669505281562834 139.749694694123 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2fabc588-969f-42ae-ba52-66b1f4c9f99d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fabc588-969f-42ae-ba52-66b1f4c9f99d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fabc588-969f-42ae-ba52-66b1f4c9f99d">
											<gml:posList>35.66951475682612 139.74960653603307 10.136 35.66951475682612 139.74960653603307 6.41 35.66948185252623 139.74970429556302 6.41 35.66948185252623 139.74970429556302 10.136 35.66951475682612 139.74960653603307 10.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-744d8dc0-1408-403a-bdec-e6a955c6a526">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-744d8dc0-1408-403a-bdec-e6a955c6a526">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-744d8dc0-1408-403a-bdec-e6a955c6a526">
											<gml:posList>35.66956613660347 139.74972544939635 6.41 35.669505281562834 139.749694694123 6.41 35.669505281562834 139.749694694123 10.968 35.66956613660347 139.74972544939635 10.968 35.66956613660347 139.74972544939635 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75cd94a4-d3ff-4d2b-be93-85f71aa71dc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75cd94a4-d3ff-4d2b-be93-85f71aa71dc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75cd94a4-d3ff-4d2b-be93-85f71aa71dc9">
											<gml:posList>35.669560344624514 139.74974397982513 10.136 35.66948185252623 139.74970429556302 10.136 35.66948185252623 139.74970429556302 6.41 35.669560344624514 139.74974397982513 6.41 35.669560344624514 139.74974397982513 10.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c27a5ba1-7ead-47c7-aaba-526589073041">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c27a5ba1-7ead-47c7-aaba-526589073041">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c27a5ba1-7ead-47c7-aaba-526589073041">
											<gml:posList>35.66956613660347 139.74972544939635 6.41 35.66956613660347 139.74972544939635 10.968 35.669560344624514 139.74974397982513 10.136 35.669560344624514 139.74974397982513 6.41 35.66956613660347 139.74972544939635 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10028</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>