<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a28729c6-f7b2-44a0-90c3-5c03a6ddc99f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">14.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671888530353286 139.73999319941584 0 35.67188519921562 139.7399982846688 0 35.67183351060004 139.7399467578765 0 35.67177291882101 139.7400378512129 0 35.67194422182687 139.7402087617679 0 35.67200472351063 139.74011755800552 0 35.672003208076866 139.7401161016317 0 35.67194951685795 139.7400625002801 0 35.67204459093481 139.7399194481094 0 35.67198009285709 139.7398551222825 0 35.6719812632686 139.73985335348107 0 35.67188825836725 139.73975890416392 0 35.671828565959146 139.73984723504103 0 35.67187051225588 139.73988905223072 0 35.67183602990097 139.73994090031823 0 35.671888530353286 139.73999319941584 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671888530353286 139.73999319941584 8.044 35.67183602990097 139.73994090031823 8.044 35.67187051225588 139.73988905223072 8.044 35.671828565959146 139.73984723504103 8.044 35.67188825836725 139.73975890416392 8.044 35.6719812632686 139.73985335348107 8.044 35.67198009285709 139.7398551222825 8.044 35.67204459093481 139.7399194481094 8.044 35.67194951685795 139.7400625002801 8.044 35.672003208076866 139.7401161016317 8.044 35.67200472351063 139.74011755800552 8.044 35.67194422182687 139.7402087617679 8.044 35.67177291882101 139.7400378512129 8.044 35.67183351060004 139.7399467578765 8.044 35.67188519921562 139.7399982846688 8.044 35.671888530353286 139.73999319941584 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671888530353286 139.73999319941584 8.044 35.67188519921562 139.7399982846688 8.044 35.67188519921562 139.7399982846688 22.71 35.671888530353286 139.73999319941584 22.71 35.671888530353286 139.73999319941584 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67188519921562 139.7399982846688 8.044 35.67183351060004 139.7399467578765 8.044 35.67183351060004 139.7399467578765 22.71 35.67188519921562 139.7399982846688 22.71 35.67188519921562 139.7399982846688 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67183351060004 139.7399467578765 8.044 35.67177291882101 139.7400378512129 8.044 35.67177291882101 139.7400378512129 22.71 35.67183351060004 139.7399467578765 22.71 35.67183351060004 139.7399467578765 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67177291882101 139.7400378512129 8.044 35.67194422182687 139.7402087617679 8.044 35.67194422182687 139.7402087617679 22.71 35.67177291882101 139.7400378512129 22.71 35.67177291882101 139.7400378512129 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67194422182687 139.7402087617679 8.044 35.67200472351063 139.74011755800552 8.044 35.67200472351063 139.74011755800552 22.71 35.67194422182687 139.7402087617679 22.71 35.67194422182687 139.7402087617679 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67200472351063 139.74011755800552 8.044 35.672003208076866 139.7401161016317 8.044 35.672003208076866 139.7401161016317 22.71 35.67200472351063 139.74011755800552 22.71 35.67200472351063 139.74011755800552 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672003208076866 139.7401161016317 8.044 35.67194951685795 139.7400625002801 8.044 35.67194951685795 139.7400625002801 22.71 35.672003208076866 139.7401161016317 22.71 35.672003208076866 139.7401161016317 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67194951685795 139.7400625002801 8.044 35.67204459093481 139.7399194481094 8.044 35.67204459093481 139.7399194481094 22.71 35.67194951685795 139.7400625002801 22.71 35.67194951685795 139.7400625002801 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67204459093481 139.7399194481094 8.044 35.67198009285709 139.7398551222825 8.044 35.67198009285709 139.7398551222825 22.71 35.67204459093481 139.7399194481094 22.71 35.67204459093481 139.7399194481094 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67198009285709 139.7398551222825 8.044 35.6719812632686 139.73985335348107 8.044 35.6719812632686 139.73985335348107 22.71 35.67198009285709 139.7398551222825 22.71 35.67198009285709 139.7398551222825 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6719812632686 139.73985335348107 8.044 35.67188825836725 139.73975890416392 8.044 35.67188825836725 139.73975890416392 22.71 35.6719812632686 139.73985335348107 22.71 35.6719812632686 139.73985335348107 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67188825836725 139.73975890416392 8.044 35.671828565959146 139.73984723504103 8.044 35.671828565959146 139.73984723504103 22.71 35.67188825836725 139.73975890416392 22.71 35.67188825836725 139.73975890416392 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671828565959146 139.73984723504103 8.044 35.67187051225588 139.73988905223072 8.044 35.67187051225588 139.73988905223072 22.71 35.671828565959146 139.73984723504103 22.71 35.671828565959146 139.73984723504103 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67187051225588 139.73988905223072 8.044 35.67183602990097 139.73994090031823 8.044 35.67183602990097 139.73994090031823 22.71 35.67187051225588 139.73988905223072 22.71 35.67187051225588 139.73988905223072 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67183602990097 139.73994090031823 8.044 35.671888530353286 139.73999319941584 8.044 35.671888530353286 139.73999319941584 22.71 35.67183602990097 139.73994090031823 22.71 35.67183602990097 139.73994090031823 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671888530353286 139.73999319941584 22.71 35.67188519921562 139.7399982846688 22.71 35.67183351060004 139.7399467578765 22.71 35.67177291882101 139.7400378512129 22.71 35.67194422182687 139.7402087617679 22.71 35.67200472351063 139.74011755800552 22.71 35.672003208076866 139.7401161016317 22.71 35.67194951685795 139.7400625002801 22.71 35.67204459093481 139.7399194481094 22.71 35.67198009285709 139.7398551222825 22.71 35.6719812632686 139.73985335348107 22.71 35.67188825836725 139.73975890416392 22.71 35.671828565959146 139.73984723504103 22.71 35.67187051225588 139.73988905223072 22.71 35.67183602990097 139.73994090031823 22.71 35.671888530353286 139.73999319941584 22.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ea8dd627-79d2-45d5-9dec-9aeb5f752397"/>
							<gml:surfaceMember xlink:href="#poly-8fc154e5-0180-469f-8d8f-de8975c23fec"/>
							<gml:surfaceMember xlink:href="#poly-b83d5bb9-d49b-4ed2-a009-56801e3ae516"/>
							<gml:surfaceMember xlink:href="#poly-569ac2ea-8a78-4fe9-8a59-bbad487c24b8"/>
							<gml:surfaceMember xlink:href="#poly-439d471d-7cd4-47d3-afe0-a01d54224f02"/>
							<gml:surfaceMember xlink:href="#poly-c1a197c0-a5a6-42dc-a355-a58120446e4e"/>
							<gml:surfaceMember xlink:href="#poly-0800b8b4-082a-4226-a3d6-75fb6242770f"/>
							<gml:surfaceMember xlink:href="#poly-d0ed5593-e33a-4c23-b051-4a1d09534d0b"/>
							<gml:surfaceMember xlink:href="#poly-2136b1d6-138f-4e9a-867f-7fef01342d53"/>
							<gml:surfaceMember xlink:href="#poly-d114e7d9-34dd-4d94-a258-45e73318908b"/>
							<gml:surfaceMember xlink:href="#poly-9b4df195-945a-41ee-a767-19fae47bcb81"/>
							<gml:surfaceMember xlink:href="#poly-07b77233-fbbc-4c0c-9ba0-d3462c9b2d9a"/>
							<gml:surfaceMember xlink:href="#poly-cc66353f-bcfa-4539-a1d9-f95a53877cbf"/>
							<gml:surfaceMember xlink:href="#poly-2c59add2-8398-4405-bbba-a40c328d4c4c"/>
							<gml:surfaceMember xlink:href="#poly-d31f1f83-5db4-447c-888e-7ee44b814278"/>
							<gml:surfaceMember xlink:href="#poly-7a405fdd-7954-4abd-8a7d-e0081d42ddb2"/>
							<gml:surfaceMember xlink:href="#poly-6e597dba-9151-45d8-9108-3877c3ebe8ae"/>
							<gml:surfaceMember xlink:href="#poly-5046edb5-1087-4ea1-896c-af01f3491d28"/>
							<gml:surfaceMember xlink:href="#poly-87c5d48c-ea4e-41b7-a4dc-ca8048718a0c"/>
							<gml:surfaceMember xlink:href="#poly-5395ff43-a9ad-463a-b670-50bd9787b7b4"/>
							<gml:surfaceMember xlink:href="#poly-52761160-a6e4-45e1-8835-6616129bfc62"/>
							<gml:surfaceMember xlink:href="#poly-510108fa-af92-45d3-b431-e4a744b47c5f"/>
							<gml:surfaceMember xlink:href="#poly-9e688f99-c41b-40ff-a47a-6cd66632206f"/>
							<gml:surfaceMember xlink:href="#poly-357fdd87-5a91-4c09-bd5d-c813789ce6d9"/>
							<gml:surfaceMember xlink:href="#poly-93572e66-08bc-42f5-bfda-a74f6c2575d7"/>
							<gml:surfaceMember xlink:href="#poly-b4b7e13e-de52-477d-bc02-875cf6f39b3e"/>
							<gml:surfaceMember xlink:href="#poly-15bba42d-90c1-47d2-bb9b-684aef857277"/>
							<gml:surfaceMember xlink:href="#poly-ad36788a-571e-4bcd-b944-1600044e6ab5"/>
							<gml:surfaceMember xlink:href="#poly-7207423a-e542-428f-974e-834111284633"/>
							<gml:surfaceMember xlink:href="#poly-e6a9191f-5363-4c82-ae5e-3252acc654ef"/>
							<gml:surfaceMember xlink:href="#poly-db8b6f9b-e1cd-460a-b8b9-ce32d9b3e03d"/>
							<gml:surfaceMember xlink:href="#poly-af32cc2d-c8c5-414c-ae23-976b0cccd3ce"/>
							<gml:surfaceMember xlink:href="#poly-8ddc387f-1064-484a-abfb-bc90ea56b823"/>
							<gml:surfaceMember xlink:href="#poly-7c89f854-e510-441f-910a-33accd5fed36"/>
							<gml:surfaceMember xlink:href="#poly-08466284-dd15-498e-b84f-3b3c12da306c"/>
							<gml:surfaceMember xlink:href="#poly-8ee7ab0b-320c-46f6-945b-0cb21434c1e1"/>
							<gml:surfaceMember xlink:href="#poly-958b00fa-3c31-4bad-b3ac-009b1f3af262"/>
							<gml:surfaceMember xlink:href="#poly-815c42e3-ee52-4207-9d62-974a70c4d99c"/>
							<gml:surfaceMember xlink:href="#poly-cfe04e35-21cb-45af-95b9-2b4a3be34266"/>
							<gml:surfaceMember xlink:href="#poly-0eef99d5-5325-402a-ae60-3094cb3ecfc1"/>
							<gml:surfaceMember xlink:href="#poly-b1da6b68-1e85-44ad-beec-789a19771ed8"/>
							<gml:surfaceMember xlink:href="#poly-6cad1535-d61f-4b5b-a35d-110e6a29d80d"/>
							<gml:surfaceMember xlink:href="#poly-dcdb229f-23bb-4d8e-a22b-21144f06d3f4"/>
							<gml:surfaceMember xlink:href="#poly-0613447f-61cf-4db5-ad4e-8c07d5631ed9"/>
							<gml:surfaceMember xlink:href="#poly-6629e041-9677-4e99-9295-2748708a33aa"/>
							<gml:surfaceMember xlink:href="#poly-b59308a6-3e26-44a4-ac23-18550c39b043"/>
							<gml:surfaceMember xlink:href="#poly-7c75bce1-db48-450a-affb-9d9d640181cf"/>
							<gml:surfaceMember xlink:href="#poly-923b62f5-e513-408b-ad9f-9a7b2280bf5e"/>
							<gml:surfaceMember xlink:href="#poly-28f7fa01-6617-4ed9-9dc3-5badeb0072f8"/>
							<gml:surfaceMember xlink:href="#poly-042ebb3b-cf64-4bfa-ba6d-bc8f89991ebc"/>
							<gml:surfaceMember xlink:href="#poly-f2ae0693-a802-40ac-81f8-8f4eb445f4ec"/>
							<gml:surfaceMember xlink:href="#poly-13daa3d6-584f-48ed-94b9-791989880889"/>
							<gml:surfaceMember xlink:href="#poly-d1d6a3f2-d74f-4f29-8ab7-1f2f5f482207"/>
							<gml:surfaceMember xlink:href="#poly-c51573d1-26b3-4437-8946-7fbf951d0804"/>
							<gml:surfaceMember xlink:href="#poly-465fdab4-4096-467c-80bd-f7341da5d3b1"/>
							<gml:surfaceMember xlink:href="#poly-f920c62e-149c-4232-91c6-b4fe1ccc686e"/>
							<gml:surfaceMember xlink:href="#poly-585421fb-0c74-40fe-aeda-7b4b1081ba02"/>
							<gml:surfaceMember xlink:href="#poly-3ec758bd-9568-411c-a9d3-96de9798906a"/>
							<gml:surfaceMember xlink:href="#poly-701dd069-c317-437b-988e-6e75ae47a3d6"/>
							<gml:surfaceMember xlink:href="#poly-da4a12fa-69df-49ce-b541-fefe9c566a50"/>
							<gml:surfaceMember xlink:href="#poly-4ed0cc8b-6095-4cb9-85f5-d55ee8767c2a"/>
							<gml:surfaceMember xlink:href="#poly-408e6be9-8ad1-425e-94ef-d573357a2c40"/>
							<gml:surfaceMember xlink:href="#poly-d47d5bbc-c0a8-478f-833d-256f4acd21e2"/>
							<gml:surfaceMember xlink:href="#poly-062acfb2-2823-4836-be8e-12c53e6b7129"/>
							<gml:surfaceMember xlink:href="#poly-4d2f61e5-246f-43a2-bf74-b2b1c2e587b3"/>
							<gml:surfaceMember xlink:href="#poly-7b730c65-ddc9-431b-846c-39c7b24ea7f6"/>
							<gml:surfaceMember xlink:href="#poly-d49837bf-4a64-46db-abc7-87f02e38347e"/>
							<gml:surfaceMember xlink:href="#poly-e62734f9-a565-48fc-a5d0-c34f98d366ea"/>
							<gml:surfaceMember xlink:href="#poly-b701a718-9d98-426d-b10c-b6efd8085af8"/>
							<gml:surfaceMember xlink:href="#poly-512b0f11-34ea-42fc-a265-c1a64c927f04"/>
							<gml:surfaceMember xlink:href="#poly-0f32ab16-90ad-49b8-a6bd-1b10fc662bc6"/>
							<gml:surfaceMember xlink:href="#poly-0684db98-884d-47ef-8aa3-7dda3789d366"/>
							<gml:surfaceMember xlink:href="#poly-41f65404-eec5-46d5-83cc-7529909f2589"/>
							<gml:surfaceMember xlink:href="#poly-3f60d9cc-2222-47f3-89a3-22a327c401ad"/>
							<gml:surfaceMember xlink:href="#poly-1d43d7ab-4dab-4fa2-b097-45291dac65b6"/>
							<gml:surfaceMember xlink:href="#poly-1221c051-e0ee-4945-b3ff-18d323ea242c"/>
							<gml:surfaceMember xlink:href="#poly-3114ef63-e9d7-4bff-a7d4-e3e41513fff3"/>
							<gml:surfaceMember xlink:href="#poly-2a380f35-01fa-4204-bbd6-f48fd44549b9"/>
							<gml:surfaceMember xlink:href="#poly-6b07252f-4d23-4c5e-ad8c-2a6cc81a27e3"/>
							<gml:surfaceMember xlink:href="#poly-a1fc8132-06d4-4701-b6ac-8f4f723c3781"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a28729c6-f7b2-44a0-90c3-5c03a6ddc99f_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc74f16b-2197-42b2-b211-9cf27f4a53c3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67188652122051 139.7398665761045 22.891 35.67190317286022 139.7398824194216 22.891 35.671897384119156 139.73989155055196 22.891 35.67188071447034 139.73987572934803 22.891 35.67188652122051 139.7398665761045 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0dc37452-fd96-4a30-ac34-f771bfd43318">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671893917856124 139.74011769788387 22.174 35.67189891465561 139.7401101804755 22.174 35.671925146828826 139.74013634115917 22.174 35.67192014102257 139.7401438696253 22.174 35.671893917856124 139.74011769788387 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81c80ac3-a607-40b6-944a-99add4ae34af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81c80ac3-a607-40b6-944a-99add4ae34af_0">
											<gml:posList>35.67188071447034 139.73987572934803 22.891 35.67188071447034 139.73987572934803 23.407 35.67188652122051 139.7398665761045 23.407 35.67188652122051 139.7398665761045 22.891 35.67188071447034 139.73987572934803 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7685a85c-405b-4008-b99e-58b4ada5079f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7685a85c-405b-4008-b99e-58b4ada5079f_0">
											<gml:posList>35.67188652122051 139.7398665761045 22.891 35.67188652122051 139.7398665761045 23.407 35.67190317286022 139.7398824194216 23.407 35.67190317286022 139.7398824194216 22.891 35.67188652122051 139.7398665761045 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c15dfc4-f7e8-480e-ac20-5bf247aa6232">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c15dfc4-f7e8-480e-ac20-5bf247aa6232_0">
											<gml:posList>35.671897384119156 139.73989155055196 23.407 35.67190317286022 139.7398824194216 23.407 35.67188652122051 139.7398665761045 23.407 35.67188071447034 139.73987572934803 23.407 35.671897384119156 139.73989155055196 23.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51ea1189-018d-4edc-95c6-47a028a693a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51ea1189-018d-4edc-95c6-47a028a693a5_0">
											<gml:posList>35.671897384119156 139.73989155055196 22.891 35.671897384119156 139.73989155055196 23.407 35.67188071447034 139.73987572934803 23.407 35.67188071447034 139.73987572934803 22.891 35.671897384119156 139.73989155055196 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a25f991-e9b0-46df-b669-2b5b5a27594f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a25f991-e9b0-46df-b669-2b5b5a27594f_0">
											<gml:posList>35.67190317286022 139.7398824194216 22.891 35.67190317286022 139.7398824194216 23.407 35.671897384119156 139.73989155055196 23.407 35.671897384119156 139.73989155055196 22.891 35.67190317286022 139.7398824194216 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b535110b-0718-4815-b16d-7c2c37414f4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b535110b-0718-4815-b16d-7c2c37414f4a_0">
											<gml:posList>35.671893917856124 139.74011769788387 22.97 35.67189891465561 139.7401101804755 22.97 35.67189891465561 139.7401101804755 22.174 35.671893917856124 139.74011769788387 22.174 35.671893917856124 139.74011769788387 22.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bf7330e-db17-44c3-995e-223faf060cb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bf7330e-db17-44c3-995e-223faf060cb0_0">
											<gml:posList>35.67189891465561 139.7401101804755 22.174 35.67189891465561 139.7401101804755 22.97 35.671925146828826 139.74013634115917 22.97 35.671925146828826 139.74013634115917 22.174 35.67189891465561 139.7401101804755 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dffcab3-bc12-480a-bc9f-336582909963">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dffcab3-bc12-480a-bc9f-336582909963_0">
											<gml:posList>35.671925146828826 139.74013634115917 22.97 35.67189891465561 139.7401101804755 22.97 35.671893917856124 139.74011769788387 22.97 35.67192014102257 139.7401438696253 22.97 35.671925146828826 139.74013634115917 22.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1feb3eee-f674-4725-b7db-747608ddfe69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1feb3eee-f674-4725-b7db-747608ddfe69_0">
											<gml:posList>35.671893917856124 139.74011769788387 22.97 35.671893917856124 139.74011769788387 22.174 35.67192014102257 139.7401438696253 22.174 35.67192014102257 139.7401438696253 22.97 35.671893917856124 139.74011769788387 22.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04a66d9d-68f0-43ea-ab55-ca61bd6fdc00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04a66d9d-68f0-43ea-ab55-ca61bd6fdc00_0">
											<gml:posList>35.671925146828826 139.74013634115917 22.174 35.671925146828826 139.74013634115917 22.97 35.67192014102257 139.7401438696253 22.97 35.67192014102257 139.7401438696253 22.174 35.671925146828826 139.74013634115917 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a28729c6-f7b2-44a0-90c3-5c03a6ddc99f_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b597b24-f86b-481f-8efc-fd232480ab68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67189232765771 139.74004298142498 22.174 35.67190855526144 139.740058350275 22.174 35.67189343076908 139.74008232766002 22.174 35.67187720316837 139.74006695880803 22.174 35.67189232765771 139.74004298142498 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93885989-d586-4ac1-a8cf-33386bac1a7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93885989-d586-4ac1-a8cf-33386bac1a7a_0">
											<gml:posList>35.67189232765771 139.74004298142498 22.174 35.67189232765771 139.74004298142498 25.665 35.67190855526144 139.740058350275 25.665 35.67190855526144 139.740058350275 22.174 35.67189232765771 139.74004298142498 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1eda5a84-45cd-4f2e-98f1-824693e5295c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1eda5a84-45cd-4f2e-98f1-824693e5295c_0">
											<gml:posList>35.67187720316837 139.74006695880803 22.174 35.67187720316837 139.74006695880803 25.665 35.67189232765771 139.74004298142498 25.665 35.67189232765771 139.74004298142498 22.174 35.67187720316837 139.74006695880803 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a43bb232-c918-4699-a71c-2446978ea7a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a43bb232-c918-4699-a71c-2446978ea7a3_0">
											<gml:posList>35.67189232765771 139.74004298142498 25.665 35.67187720316837 139.74006695880803 25.665 35.67189343076908 139.74008232766002 25.665 35.67190855526144 139.740058350275 25.665 35.67189232765771 139.74004298142498 25.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3274cdb-11d4-45f3-8df2-9e840b59489b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3274cdb-11d4-45f3-8df2-9e840b59489b_0">
											<gml:posList>35.67190855526144 139.740058350275 22.174 35.67190855526144 139.740058350275 25.665 35.67189343076908 139.74008232766002 25.665 35.67189343076908 139.74008232766002 22.174 35.67190855526144 139.740058350275 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f6595c5-fbe4-4e1e-8e18-b3257e4b7f8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f6595c5-fbe4-4e1e-8e18-b3257e4b7f8e_0">
											<gml:posList>35.67189343076908 139.74008232766002 22.174 35.67189343076908 139.74008232766002 25.665 35.67187720316837 139.74006695880803 25.665 35.67187720316837 139.74006695880803 22.174 35.67189343076908 139.74008232766002 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a28729c6-f7b2-44a0-90c3-5c03a6ddc99f_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cef4b9d-72d4-4a77-b6d8-afeedc885792">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671790908495275 139.74003562098807 22.174 35.67179230397002 139.74003348739853 22.174 35.671835339438886 139.73996878238725 22.174 35.67183590774008 139.7399693450949 22.174 35.67179189176111 139.7400366140247 22.174 35.671790908495275 139.74003562098807 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-baa7528f-3bcf-498e-924e-dfb0890afe32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179189176111 139.7400366140247 22.885 35.67178988407225 139.74003967622866 22.885 35.67188476266852 139.74013290846665 22.885 35.671883844337806 139.74013429034252 22.885 35.6717879824939 139.74004008716022 22.885 35.671790908495275 139.74003562098807 22.885 35.67179189176111 139.7400366140247 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-536444d2-a1d2-4e3e-9233-4510a5a47ef1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67194690589499 139.74007803466182 22.885 35.67183606079346 139.73996911294103 22.885 35.67183590774008 139.7399693450949 22.885 35.671835339438886 139.73996878238725 22.885 35.67179230397002 139.74003348739853 22.885 35.67183587879744 139.7399668928145 22.885 35.67194771617162 139.7400767965141 22.885 35.67194690589499 139.74007803466182 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a3ca1ab-3683-4eb9-89f7-2769e865877b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a3ca1ab-3683-4eb9-89f7-2769e865877b_0">
											<gml:posList>35.67188476266852 139.74013290846665 22.885 35.67178988407225 139.74003967622866 22.885 35.67178988407225 139.74003967622866 24.252 35.67188476266852 139.74013290846665 24.252 35.67188476266852 139.74013290846665 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40e8ae89-aca6-4811-9b1d-cb53ef6899ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40e8ae89-aca6-4811-9b1d-cb53ef6899ea_0">
											<gml:posList>35.671835339438886 139.73996878238725 22.885 35.67183590774008 139.7399693450949 22.885 35.67183590774008 139.7399693450949 22.174 35.671835339438886 139.73996878238725 22.174 35.671835339438886 139.73996878238725 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3e34f73-326b-4619-9d47-3752ac458517">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3e34f73-326b-4619-9d47-3752ac458517_0">
											<gml:posList>35.671835339438886 139.73996878238725 22.174 35.67179230397002 139.74003348739853 22.174 35.67179230397002 139.74003348739853 22.885 35.671835339438886 139.73996878238725 22.885 35.671835339438886 139.73996878238725 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27c4e3a3-7b83-4062-9298-9bb98090c4f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27c4e3a3-7b83-4062-9298-9bb98090c4f3_0">
											<gml:posList>35.6717879824939 139.74004008716022 24.252 35.67183587879744 139.7399668928145 24.252 35.67183587879744 139.7399668928145 22.885 35.67179230397002 139.74003348739853 22.885 35.67179230397002 139.74003348739853 22.174 35.671790908495275 139.74003562098807 22.174 35.671790908495275 139.74003562098807 22.885 35.6717879824939 139.74004008716022 22.885 35.6717879824939 139.74004008716022 24.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3539f9f6-bf82-4ee0-b7b9-a4850bd9f5bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3539f9f6-bf82-4ee0-b7b9-a4850bd9f5bf_0">
											<gml:posList>35.67183606079346 139.73996911294103 24.252 35.67178988407225 139.74003967622866 24.252 35.67178988407225 139.74003967622866 22.885 35.67179189176111 139.7400366140247 22.885 35.67179189176111 139.7400366140247 22.174 35.67183590774008 139.7399693450949 22.174 35.67183590774008 139.7399693450949 22.885 35.67183606079346 139.73996911294103 22.885 35.67183606079346 139.73996911294103 24.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b052a459-0e6b-4141-b357-587c415c0c9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b052a459-0e6b-4141-b357-587c415c0c9f_0">
											<gml:posList>35.67183587879744 139.7399668928145 24.252 35.67194771617162 139.7400767965141 24.252 35.67194771617162 139.7400767965141 22.885 35.67183587879744 139.7399668928145 22.885 35.67183587879744 139.7399668928145 24.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3a2993f-5910-48a9-a2c5-83c305bb5d9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3a2993f-5910-48a9-a2c5-83c305bb5d9b_0">
											<gml:posList>35.67194690589499 139.74007803466182 22.885 35.67194690589499 139.74007803466182 24.252 35.67183606079346 139.73996911294103 24.252 35.67183606079346 139.73996911294103 22.885 35.67194690589499 139.74007803466182 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e85722ea-15b0-4875-9606-54356ef8430f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e85722ea-15b0-4875-9606-54356ef8430f_0">
											<gml:posList>35.67179189176111 139.7400366140247 22.885 35.671790908495275 139.74003562098807 22.885 35.671790908495275 139.74003562098807 22.174 35.67179189176111 139.7400366140247 22.174 35.67179189176111 139.7400366140247 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-118c7524-1cd0-4545-8de4-c5973c7b6125">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-118c7524-1cd0-4545-8de4-c5973c7b6125_0">
											<gml:posList>35.67178988407225 139.74003967622866 24.252 35.67183606079346 139.73996911294103 24.252 35.67194690589499 139.74007803466182 24.252 35.67194771617162 139.7400767965141 24.252 35.67183587879744 139.7399668928145 24.252 35.6717879824939 139.74004008716022 24.252 35.671883844337806 139.74013429034252 24.252 35.67188476266852 139.74013290846665 24.252 35.67178988407225 139.74003967622866 24.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9d99a3f-bb5c-4b15-b4a8-5ec6a74a9ecd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9d99a3f-bb5c-4b15-b4a8-5ec6a74a9ecd_0">
											<gml:posList>35.67194771617162 139.7400767965141 22.885 35.67194771617162 139.7400767965141 24.252 35.67194690589499 139.74007803466182 24.252 35.67194690589499 139.74007803466182 22.885 35.67194771617162 139.7400767965141 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7940f3ec-6b8a-45eb-b952-7ce1a728a0e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7940f3ec-6b8a-45eb-b952-7ce1a728a0e5_0">
											<gml:posList>35.6717879824939 139.74004008716022 24.252 35.6717879824939 139.74004008716022 22.885 35.671883844337806 139.74013429034252 22.885 35.671883844337806 139.74013429034252 24.252 35.6717879824939 139.74004008716022 24.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c5f8144-9100-4ab4-be1b-55f5cfed36fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c5f8144-9100-4ab4-be1b-55f5cfed36fb_0">
											<gml:posList>35.671883844337806 139.74013429034252 22.885 35.67188476266852 139.74013290846665 22.885 35.67188476266852 139.74013290846665 24.252 35.671883844337806 139.74013429034252 24.252 35.671883844337806 139.74013429034252 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a28729c6-f7b2-44a0-90c3-5c03a6ddc99f_BuildingInstallation_1051">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efb941e3-b9ab-4b95-850e-dfc3fb94d883">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672002712741275 139.7401166434853 22.885 35.67195901117879 139.7401826417643 22.885 35.671955709610536 139.74017935375034 22.885 35.67199779975923 139.74011599745515 22.885 35.67194893464539 139.7400672509419 22.885 35.67195045602183 139.7400647416221 22.885 35.672002712741275 139.7401166434853 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8aeb1e2e-4188-4ba0-9b76-ac34d11b8387">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8aeb1e2e-4188-4ba0-9b76-ac34d11b8387_0">
											<gml:posList>35.67194893464539 139.7400672509419 22.885 35.67194893464539 139.7400672509419 26.858 35.67195045602183 139.7400647416221 26.858 35.67195045602183 139.7400647416221 22.885 35.67194893464539 139.7400672509419 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6715f40d-1774-4ed8-9a05-f842c74b6499">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6715f40d-1774-4ed8-9a05-f842c74b6499_0">
											<gml:posList>35.67195045602183 139.7400647416221 26.858 35.672002712741275 139.7401166434853 26.858 35.672002712741275 139.7401166434853 22.885 35.67195045602183 139.7400647416221 22.885 35.67195045602183 139.7400647416221 26.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9278098-ea59-4567-8463-e89e4abb45aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9278098-ea59-4567-8463-e89e4abb45aa_0">
											<gml:posList>35.67199779975923 139.74011599745515 22.885 35.67199779975923 139.74011599745515 26.858 35.67194893464539 139.7400672509419 26.858 35.67194893464539 139.7400672509419 22.885 35.67199779975923 139.74011599745515 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d51cb732-f040-4ef9-9051-9ef91cf2b81a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d51cb732-f040-4ef9-9051-9ef91cf2b81a_0">
											<gml:posList>35.67194893464539 139.7400672509419 26.858 35.67199779975923 139.74011599745515 26.858 35.671955709610536 139.74017935375034 26.858 35.67195901117879 139.7401826417643 26.858 35.672002712741275 139.7401166434853 26.858 35.67195045602183 139.7400647416221 26.858 35.67194893464539 139.7400672509419 26.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68e0d08f-2031-4e4b-8f99-3d7d8011f70d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68e0d08f-2031-4e4b-8f99-3d7d8011f70d_0">
											<gml:posList>35.671955709610536 139.74017935375034 22.885 35.671955709610536 139.74017935375034 26.858 35.67199779975923 139.74011599745515 26.858 35.67199779975923 139.74011599745515 22.885 35.671955709610536 139.74017935375034 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40bda001-dbc5-4aed-a022-be9c9a6c3f79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40bda001-dbc5-4aed-a022-be9c9a6c3f79_0">
											<gml:posList>35.672002712741275 139.7401166434853 22.885 35.672002712741275 139.7401166434853 26.858 35.67195901117879 139.7401826417643 26.858 35.67195901117879 139.7401826417643 22.885 35.672002712741275 139.7401166434853 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e6c46de-44f9-4381-9346-3f1636fce273">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e6c46de-44f9-4381-9346-3f1636fce273_0">
											<gml:posList>35.67195901117879 139.7401826417643 26.858 35.671955709610536 139.74017935375034 26.858 35.671955709610536 139.74017935375034 22.885 35.67195901117879 139.7401826417643 22.885 35.67195901117879 139.7401826417643 26.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a28729c6-f7b2-44a0-90c3-5c03a6ddc99f_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbd06a99-467a-4409-a942-f442ce808398">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67182962827337 139.73998497210067 22.174 35.671837025235874 139.73999233147705 22.174 35.671807881938584 139.74003638553444 22.174 35.671800475973576 139.74002903721362 22.174 35.67182962827337 139.73998497210067 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa8396b6-4f03-4f77-8c7d-6c13a5989ac3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67185133209327 139.74000663103527 22.174 35.671823342256076 139.7400503081737 22.174 35.67181678438614 139.74004399723032 22.174 35.67184477422107 139.74000032009326 22.174 35.67185133209327 139.74000663103527 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7dc8f6af-17f6-42f1-bd81-14537d53cc7e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67185063891402 139.73993801122032 22.891 35.671855194784065 139.73993146640723 22.891 35.67186245671536 139.73993904686756 22.891 35.67185790985864 139.73994559167028 22.891 35.67185063891402 139.73993801122032 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc70368a-a69d-432b-8c8f-528c61e2d9ab">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67186259187752 139.73995061235752 22.891 35.67186731881187 139.73994381327623 22.891 35.671874301085744 139.73995109581 22.891 35.67186957415099 139.73995789489146 22.891 35.67186259187752 139.73995061235752 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf5f0422-550f-4f89-a717-83366fec7e99">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67188497030446 139.73985425005574 27.511 35.67187856039055 139.73986437609219 27.511 35.67186703232358 139.7398533983001 27.511 35.67187344224515 139.73984328331073 27.511 35.67188497030446 139.73985425005574 27.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aba0f04d-f7df-4353-a6ab-94df4d83da0f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671884583273865 139.73993628156842 22.891 35.67187985633996 139.7399430806516 22.891 35.671872901123905 139.73993582017943 22.891 35.67187761904369 139.73992902110692 22.891 35.671884583273865 139.73993628156842 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6eae35a7-cd85-47b4-bfcb-53cfcf44376c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671886695968546 139.73996401678576 22.891 35.67188196903307 139.7399708158675 22.891 35.67187450864776 139.7399630367972 22.891 35.67187922656908 139.73995623772612 22.891 35.671886695968546 139.73996401678576 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b982b64b-062f-4ebc-9a14-5710628e9947">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671874137820254 139.7398916881102 22.891 35.671881394203126 139.73988050062908 22.891 35.67189179490108 139.73989064020938 22.891 35.67188453851727 139.73990182769103 22.891 35.671874137820254 139.7398916881102 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bc94d27-281a-423d-8eb4-c067ae3d4a4e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67188810409754 139.74014111210735 26.709 35.671894892542596 139.74013089728004 26.709 35.67191105762041 139.74014701738102 26.709 35.67190426918256 139.7401572432555 26.709 35.67188810409754 139.74014111210735 26.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5850342-c12d-4bf4-9e70-a4a03cce59d9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671894463877365 139.73991504979298 22.891 35.671903124714206 139.73990168452002 22.891 35.67191154990576 139.73990989327547 22.891 35.67190288004572 139.73992324751302 22.891 35.671894463877365 139.73991504979298 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b5aa8d3-c0e1-47e4-9b4f-148593b666a2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671944704642335 139.73993602374026 20.294 35.67194987353098 139.73994120956232 20.294 35.67193789016495 139.7399591409024 20.294 35.67193271226335 139.73995395509044 20.294 35.671944704642335 139.73993602374026 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1b8f423-fb6d-4435-a212-352616a451f7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67195070136956 139.73998586949955 20.294 35.671938613743656 139.73997396442795 20.294 35.67194838209246 139.7399590734505 20.294 35.6719604697198 139.7399709785213 20.294 35.67195070136956 139.73998586949955 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7aa1e2b9-d6df-40eb-a8b2-0700f5d40441">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6719520067747 139.73994895065698 20.294 35.67195836300745 139.7399393328185 20.294 35.67196924194152 139.7399501346478 20.294 35.67196288569936 139.7399597414403 20.294 35.6719520067747 139.73994895065698 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe3fe64c-450a-4df5-a46f-324ef41cbdc6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671972758828105 139.73999861354696 20.294 35.67196298048852 139.73998899240223 20.294 35.67196804022178 139.7399812760695 20.294 35.67197781857053 139.73999090826032 20.294 35.671972758828105 139.73999861354696 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb7a5378-650c-4cee-995a-dcf943508e0b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67200409032351 139.73997507015568 20.294 35.67198948709399 139.73999704756505 20.294 35.67198663648927 139.7399941235663 20.294 35.67200123971828 139.73997214615716 20.294 35.67200409032351 139.73997507015568 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4817b522-36d4-4f4a-b66a-5e71b853defd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67198948709399 139.73999704756505 20.633 35.67200409032351 139.73997507015568 20.633 35.67200593960068 139.7399769569509 20.633 35.6719913273571 139.73999893437096 20.633 35.67198948709399 139.73999704756505 20.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-583efccc-d69a-45fb-8157-d6bb63796b9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-583efccc-d69a-45fb-8157-d6bb63796b9c_0">
											<gml:posList>35.67181678438614 139.74004399723032 22.174 35.67181678438614 139.74004399723032 24.76 35.67184477422107 139.74000032009326 24.76 35.67184477422107 139.74000032009326 22.174 35.67181678438614 139.74004399723032 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f10c451f-68b9-4273-b2cb-a68dfba26d9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f10c451f-68b9-4273-b2cb-a68dfba26d9f_0">
											<gml:posList>35.67186703232358 139.7398533983001 27.511 35.67186703232358 139.7398533983001 28.094 35.67187344224515 139.73984328331073 28.094 35.67187344224515 139.73984328331073 27.511 35.67186703232358 139.7398533983001 27.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-add5bfae-f92e-4008-8344-178beaee96b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-add5bfae-f92e-4008-8344-178beaee96b0_0">
											<gml:posList>35.67187344224515 139.73984328331073 27.511 35.67187344224515 139.73984328331073 28.094 35.67188497030446 139.73985425005574 28.094 35.67188497030446 139.73985425005574 27.511 35.67187344224515 139.73984328331073 27.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f44fbf99-9116-4538-8ded-ff805c117696">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f44fbf99-9116-4538-8ded-ff805c117696_0">
											<gml:posList>35.67186703232358 139.7398533983001 28.094 35.67187856039055 139.73986437609219 28.094 35.67188497030446 139.73985425005574 28.094 35.67187344224515 139.73984328331073 28.094 35.67186703232358 139.7398533983001 28.094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82bf46a2-399d-49e0-985a-18b0178aea94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82bf46a2-399d-49e0-985a-18b0178aea94_0">
											<gml:posList>35.67187856039055 139.73986437609219 27.511 35.67187856039055 139.73986437609219 28.094 35.67186703232358 139.7398533983001 28.094 35.67186703232358 139.7398533983001 27.511 35.67187856039055 139.73986437609219 27.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fe6ff73-cc8d-4d9c-b746-c9d173e3b75a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fe6ff73-cc8d-4d9c-b746-c9d173e3b75a_0">
											<gml:posList>35.67188497030446 139.73985425005574 28.094 35.67187856039055 139.73986437609219 28.094 35.67187856039055 139.73986437609219 27.511 35.67188497030446 139.73985425005574 27.511 35.67188497030446 139.73985425005574 28.094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8228c0d2-0916-46d3-b24e-5931a2a74a95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8228c0d2-0916-46d3-b24e-5931a2a74a95_0">
											<gml:posList>35.67189179490108 139.73989064020938 22.891 35.671881394203126 139.73988050062908 22.891 35.671881394203126 139.73988050062908 25.246 35.67189179490108 139.73989064020938 25.246 35.67189179490108 139.73989064020938 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bc0595c-2078-4ea0-bdf5-2473c2dd2d26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bc0595c-2078-4ea0-bdf5-2473c2dd2d26_0">
											<gml:posList>35.671874137820254 139.7398916881102 25.246 35.671881394203126 139.73988050062908 25.246 35.671881394203126 139.73988050062908 22.891 35.671874137820254 139.7398916881102 22.891 35.671874137820254 139.7398916881102 25.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b823135-ee79-4fa2-9add-851646d3ced6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b823135-ee79-4fa2-9add-851646d3ced6_0">
											<gml:posList>35.671874137820254 139.7398916881102 25.246 35.67188453851727 139.73990182769103 25.246 35.67189179490108 139.73989064020938 25.246 35.671881394203126 139.73988050062908 25.246 35.671874137820254 139.7398916881102 25.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-267e7e72-1f80-4c5e-b683-f8fa156a14bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-267e7e72-1f80-4c5e-b683-f8fa156a14bb_0">
											<gml:posList>35.67188453851727 139.73990182769103 22.891 35.67189179490108 139.73989064020938 22.891 35.67189179490108 139.73989064020938 25.246 35.67188453851727 139.73990182769103 25.246 35.67188453851727 139.73990182769103 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8671a655-8b97-4964-8d8c-f1e5b4d22b69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8671a655-8b97-4964-8d8c-f1e5b4d22b69_0">
											<gml:posList>35.67188453851727 139.73990182769103 25.246 35.671874137820254 139.7398916881102 25.246 35.671874137820254 139.7398916881102 22.891 35.67188453851727 139.73990182769103 22.891 35.67188453851727 139.73990182769103 25.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddec05c7-cadf-4d5f-bf60-21cb10511524">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddec05c7-cadf-4d5f-bf60-21cb10511524_0">
											<gml:posList>35.67191154990576 139.73990989327547 22.891 35.671903124714206 139.73990168452002 22.891 35.671903124714206 139.73990168452002 25.246 35.67191154990576 139.73990989327547 25.246 35.67191154990576 139.73990989327547 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1627571e-3e16-4992-8142-3d098a1ac54c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1627571e-3e16-4992-8142-3d098a1ac54c_0">
											<gml:posList>35.671894463877365 139.73991504979298 22.891 35.671894463877365 139.73991504979298 25.246 35.671903124714206 139.73990168452002 25.246 35.671903124714206 139.73990168452002 22.891 35.671894463877365 139.73991504979298 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2357d5de-6a3e-433a-b70d-caff0d737a24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2357d5de-6a3e-433a-b70d-caff0d737a24_0">
											<gml:posList>35.67191154990576 139.73990989327547 25.246 35.671903124714206 139.73990168452002 25.246 35.671894463877365 139.73991504979298 25.246 35.67190288004572 139.73992324751302 25.246 35.67191154990576 139.73990989327547 25.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9df84520-833a-4c6c-8f0a-982eced5eb08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9df84520-833a-4c6c-8f0a-982eced5eb08_0">
											<gml:posList>35.67190288004572 139.73992324751302 22.891 35.67191154990576 139.73990989327547 22.891 35.67191154990576 139.73990989327547 25.246 35.67190288004572 139.73992324751302 25.246 35.67190288004572 139.73992324751302 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e60f77f2-f9bf-445b-ab58-524375ebb5df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e60f77f2-f9bf-445b-ab58-524375ebb5df_0">
											<gml:posList>35.671894463877365 139.73991504979298 22.891 35.67190288004572 139.73992324751302 22.891 35.67190288004572 139.73992324751302 25.246 35.671894463877365 139.73991504979298 25.246 35.671894463877365 139.73991504979298 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47b32aa2-15d3-406f-81f3-53de8be8840a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47b32aa2-15d3-406f-81f3-53de8be8840a_0">
											<gml:posList>35.67187761904369 139.73992902110692 22.891 35.671872901123905 139.73993582017943 22.891 35.671872901123905 139.73993582017943 24.528 35.67187761904369 139.73992902110692 24.528 35.67187761904369 139.73992902110692 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dee36a23-076b-40ec-96c1-d77edd11ddeb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dee36a23-076b-40ec-96c1-d77edd11ddeb_0">
											<gml:posList>35.671884583273865 139.73993628156842 22.891 35.67187761904369 139.73992902110692 22.891 35.67187761904369 139.73992902110692 24.528 35.671884583273865 139.73993628156842 24.528 35.671884583273865 139.73993628156842 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b058a92-85cc-4395-a912-424447eb433d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b058a92-85cc-4395-a912-424447eb433d_0">
											<gml:posList>35.671855194784065 139.73993146640723 22.891 35.67185063891402 139.73993801122032 22.891 35.67185063891402 139.73993801122032 24.528 35.671855194784065 139.73993146640723 24.528 35.671855194784065 139.73993146640723 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cbe0c85-e79c-4042-a816-a9bcf1a66307">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cbe0c85-e79c-4042-a816-a9bcf1a66307_0">
											<gml:posList>35.671855194784065 139.73993146640723 22.891 35.671855194784065 139.73993146640723 24.528 35.67186245671536 139.73993904686756 24.528 35.67186245671536 139.73993904686756 22.891 35.671855194784065 139.73993146640723 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65c7aad3-154f-4e34-8ab0-8f8d44b14b5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65c7aad3-154f-4e34-8ab0-8f8d44b14b5b_0">
											<gml:posList>35.671884583273865 139.73993628156842 24.528 35.67187761904369 139.73992902110692 24.528 35.671872901123905 139.73993582017943 24.528 35.67187985633996 139.7399430806516 24.528 35.671884583273865 139.73993628156842 24.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-581540db-5e85-4b94-bd6a-3671657ee193">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-581540db-5e85-4b94-bd6a-3671657ee193_0">
											<gml:posList>35.67186245671536 139.73993904686756 24.528 35.671855194784065 139.73993146640723 24.528 35.67185063891402 139.73993801122032 24.528 35.67185790985864 139.73994559167028 24.528 35.67186245671536 139.73993904686756 24.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85884e01-972a-41a6-822a-b5fe6f1f27f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85884e01-972a-41a6-822a-b5fe6f1f27f0_0">
											<gml:posList>35.67194987353098 139.73994120956232 20.294 35.671944704642335 139.73993602374026 20.294 35.671944704642335 139.73993602374026 20.782 35.67194987353098 139.73994120956232 20.782 35.67194987353098 139.73994120956232 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30073338-eda4-4a08-8831-967ddb21c1fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30073338-eda4-4a08-8831-967ddb21c1fe_0">
											<gml:posList>35.671872901123905 139.73993582017943 22.891 35.67187985633996 139.7399430806516 22.891 35.67187985633996 139.7399430806516 24.528 35.671872901123905 139.73993582017943 24.528 35.671872901123905 139.73993582017943 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1f8cbbd-5bed-4673-8011-9f540b06958a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1f8cbbd-5bed-4673-8011-9f540b06958a_0">
											<gml:posList>35.671884583273865 139.73993628156842 22.891 35.671884583273865 139.73993628156842 24.528 35.67187985633996 139.7399430806516 24.528 35.67187985633996 139.7399430806516 22.891 35.671884583273865 139.73993628156842 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae846f3c-8ab0-480d-849a-78620816feff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae846f3c-8ab0-480d-849a-78620816feff_0">
											<gml:posList>35.67185063891402 139.73993801122032 22.891 35.67185790985864 139.73994559167028 22.891 35.67185790985864 139.73994559167028 24.528 35.67185063891402 139.73993801122032 24.528 35.67185063891402 139.73993801122032 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05f40b80-465b-4b5a-9234-148a82339ac0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05f40b80-465b-4b5a-9234-148a82339ac0_0">
											<gml:posList>35.67185790985864 139.73994559167028 22.891 35.67186245671536 139.73993904686756 22.891 35.67186245671536 139.73993904686756 24.528 35.67185790985864 139.73994559167028 24.528 35.67185790985864 139.73994559167028 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c65a195-1596-4a0d-9c00-04830c71b53f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c65a195-1596-4a0d-9c00-04830c71b53f_0">
											<gml:posList>35.67195836300745 139.7399393328185 20.294 35.6719520067747 139.73994895065698 20.294 35.6719520067747 139.73994895065698 21.939 35.67195836300745 139.7399393328185 21.939 35.67195836300745 139.7399393328185 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6cd8b3bf-03d7-49ea-927b-2b8e96a5f5ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6cd8b3bf-03d7-49ea-927b-2b8e96a5f5ab_0">
											<gml:posList>35.67196924194152 139.7399501346478 20.294 35.67195836300745 139.7399393328185 20.294 35.67195836300745 139.7399393328185 21.939 35.67196924194152 139.7399501346478 21.939 35.67196924194152 139.7399501346478 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7533ee44-2b4d-4834-85fa-c7a1c8f3d458">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7533ee44-2b4d-4834-85fa-c7a1c8f3d458_0">
											<gml:posList>35.671944704642335 139.73993602374026 20.294 35.67193271226335 139.73995395509044 20.294 35.67193271226335 139.73995395509044 20.782 35.671944704642335 139.73993602374026 20.782 35.671944704642335 139.73993602374026 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9dbaf6a9-d0a2-47b4-bc00-393da762cdf3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9dbaf6a9-d0a2-47b4-bc00-393da762cdf3_0">
											<gml:posList>35.67186731881187 139.73994381327623 22.891 35.67186259187752 139.73995061235752 22.891 35.67186259187752 139.73995061235752 24.528 35.67186731881187 139.73994381327623 24.528 35.67186731881187 139.73994381327623 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2b4019a-42ed-433f-8ef6-f6ac821be5f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2b4019a-42ed-433f-8ef6-f6ac821be5f9_0">
											<gml:posList>35.671874301085744 139.73995109581 22.891 35.67186731881187 139.73994381327623 22.891 35.67186731881187 139.73994381327623 24.528 35.671874301085744 139.73995109581 24.528 35.671874301085744 139.73995109581 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14210619-c9b3-4f8e-9b4c-10e4c8a1980a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14210619-c9b3-4f8e-9b4c-10e4c8a1980a_0">
											<gml:posList>35.67193789016495 139.7399591409024 20.782 35.67194987353098 139.73994120956232 20.782 35.671944704642335 139.73993602374026 20.782 35.67193271226335 139.73995395509044 20.782 35.67193789016495 139.7399591409024 20.782</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67042d08-be34-425f-b161-942130317feb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67042d08-be34-425f-b161-942130317feb_0">
											<gml:posList>35.6719520067747 139.73994895065698 21.939 35.67196288569936 139.7399597414403 21.939 35.67196924194152 139.7399501346478 21.939 35.67195836300745 139.7399393328185 21.939 35.6719520067747 139.73994895065698 21.939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0952fe5d-2980-441b-9e3f-9b8c280826ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0952fe5d-2980-441b-9e3f-9b8c280826ae_0">
											<gml:posList>35.67193789016495 139.7399591409024 20.294 35.67194987353098 139.73994120956232 20.294 35.67194987353098 139.73994120956232 20.782 35.67193789016495 139.7399591409024 20.782 35.67193789016495 139.7399591409024 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4878499-4d0d-49c0-9e7a-31153c675e3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4878499-4d0d-49c0-9e7a-31153c675e3b_0">
											<gml:posList>35.671874301085744 139.73995109581 24.528 35.67186731881187 139.73994381327623 24.528 35.67186259187752 139.73995061235752 24.528 35.67186957415099 139.73995789489146 24.528 35.671874301085744 139.73995109581 24.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2af071c3-5234-4171-ba20-9a20fe784091">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2af071c3-5234-4171-ba20-9a20fe784091_0">
											<gml:posList>35.67186957415099 139.73995789489146 22.891 35.67186957415099 139.73995789489146 24.528 35.67186259187752 139.73995061235752 24.528 35.67186259187752 139.73995061235752 22.891 35.67186957415099 139.73995789489146 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01bf8a2e-583f-4f81-82da-e8690ecaab15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01bf8a2e-583f-4f81-82da-e8690ecaab15_0">
											<gml:posList>35.6719520067747 139.73994895065698 20.294 35.67196288569936 139.7399597414403 20.294 35.67196288569936 139.7399597414403 21.939 35.6719520067747 139.73994895065698 21.939 35.6719520067747 139.73994895065698 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10e6fc5e-e6f0-454e-ac46-cdaae4230602">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10e6fc5e-e6f0-454e-ac46-cdaae4230602_0">
											<gml:posList>35.67186957415099 139.73995789489146 22.891 35.671874301085744 139.73995109581 22.891 35.671874301085744 139.73995109581 24.528 35.67186957415099 139.73995789489146 24.528 35.67186957415099 139.73995789489146 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07db0b05-0a1c-4096-8fdf-15b2d2c6d2e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07db0b05-0a1c-4096-8fdf-15b2d2c6d2e4_0">
											<gml:posList>35.67196924194152 139.7399501346478 20.294 35.67196924194152 139.7399501346478 21.939 35.67196288569936 139.7399597414403 21.939 35.67196288569936 139.7399597414403 20.294 35.67196924194152 139.7399501346478 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-442d2861-b567-4b2a-a445-8c2329547147">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-442d2861-b567-4b2a-a445-8c2329547147_0">
											<gml:posList>35.67193271226335 139.73995395509044 20.294 35.67193789016495 139.7399591409024 20.294 35.67193789016495 139.7399591409024 20.782 35.67193271226335 139.73995395509044 20.782 35.67193271226335 139.73995395509044 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c5540a4-34c5-4a08-bd8e-2ead7316996c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c5540a4-34c5-4a08-bd8e-2ead7316996c_0">
											<gml:posList>35.67187922656908 139.73995623772612 22.891 35.67187450864776 139.7399630367972 22.891 35.67187450864776 139.7399630367972 24.528 35.67187922656908 139.73995623772612 24.528 35.67187922656908 139.73995623772612 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e00106e-2f8f-4a3d-aa90-ed47c36a3ebc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e00106e-2f8f-4a3d-aa90-ed47c36a3ebc_0">
											<gml:posList>35.67187922656908 139.73995623772612 22.891 35.67187922656908 139.73995623772612 24.528 35.671886695968546 139.73996401678576 24.528 35.671886695968546 139.73996401678576 22.891 35.67187922656908 139.73995623772612 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8a2ea1c-4cd2-4456-9b79-5fcc9e3df830">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8a2ea1c-4cd2-4456-9b79-5fcc9e3df830_0">
											<gml:posList>35.67187450864776 139.7399630367972 24.528 35.67188196903307 139.7399708158675 24.528 35.671886695968546 139.73996401678576 24.528 35.67187922656908 139.73995623772612 24.528 35.67187450864776 139.7399630367972 24.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8dde640-eb94-4230-847e-73e5f2c779d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8dde640-eb94-4230-847e-73e5f2c779d8_0">
											<gml:posList>35.6719604697198 139.7399709785213 20.294 35.67194838209246 139.7399590734505 20.294 35.67194838209246 139.7399590734505 22.223 35.6719604697198 139.7399709785213 22.223 35.6719604697198 139.7399709785213 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9c77784-3eb7-4962-9f9d-8e3d683b3d00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9c77784-3eb7-4962-9f9d-8e3d683b3d00_0">
											<gml:posList>35.67194838209246 139.7399590734505 20.294 35.671938613743656 139.73997396442795 20.294 35.671938613743656 139.73997396442795 22.223 35.67194838209246 139.7399590734505 22.223 35.67194838209246 139.7399590734505 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d04de23b-1616-4c84-b148-6eada5242704">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d04de23b-1616-4c84-b148-6eada5242704_0">
											<gml:posList>35.67188196903307 139.7399708158675 22.891 35.67188196903307 139.7399708158675 24.528 35.67187450864776 139.7399630367972 24.528 35.67187450864776 139.7399630367972 22.891 35.67188196903307 139.7399708158675 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97461ce0-64a9-494f-9001-f20c2a59e44f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97461ce0-64a9-494f-9001-f20c2a59e44f_0">
											<gml:posList>35.671886695968546 139.73996401678576 22.891 35.671886695968546 139.73996401678576 24.528 35.67188196903307 139.7399708158675 24.528 35.67188196903307 139.7399708158675 22.891 35.671886695968546 139.73996401678576 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b6ce9f5-3d51-4160-bf2c-e70cd841fe64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b6ce9f5-3d51-4160-bf2c-e70cd841fe64_0">
											<gml:posList>35.67195070136956 139.73998586949955 22.223 35.6719604697198 139.7399709785213 22.223 35.67194838209246 139.7399590734505 22.223 35.671938613743656 139.73997396442795 22.223 35.67195070136956 139.73998586949955 22.223</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edc21e65-4bfd-445e-bcbd-5ec516863b92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edc21e65-4bfd-445e-bcbd-5ec516863b92_0">
											<gml:posList>35.67200123971828 139.73997214615716 20.294 35.67200123971828 139.73997214615716 21.134 35.67200593960068 139.7399769569509 21.134 35.67200593960068 139.7399769569509 20.633 35.67200409032351 139.73997507015568 20.633 35.67200409032351 139.73997507015568 20.294 35.67200123971828 139.73997214615716 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80a401ef-9026-4c94-a91e-84e942511ebe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80a401ef-9026-4c94-a91e-84e942511ebe_0">
											<gml:posList>35.6719604697198 139.7399709785213 20.294 35.6719604697198 139.7399709785213 22.223 35.67195070136956 139.73998586949955 22.223 35.67195070136956 139.73998586949955 20.294 35.6719604697198 139.7399709785213 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdda4a90-dd67-4fd0-9c97-6f1baaec830f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdda4a90-dd67-4fd0-9c97-6f1baaec830f_0">
											<gml:posList>35.671938613743656 139.73997396442795 20.294 35.67195070136956 139.73998586949955 20.294 35.67195070136956 139.73998586949955 22.223 35.671938613743656 139.73997396442795 22.223 35.671938613743656 139.73997396442795 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8aff293-a20a-4797-b81e-ebe8e34d90ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8aff293-a20a-4797-b81e-ebe8e34d90ee_0">
											<gml:posList>35.67198663648927 139.7399941235663 20.294 35.67198663648927 139.7399941235663 21.134 35.67200123971828 139.73997214615716 21.134 35.67200123971828 139.73997214615716 20.294 35.67198663648927 139.7399941235663 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74d28ba2-823d-42c1-ac71-8e6de086e995">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74d28ba2-823d-42c1-ac71-8e6de086e995_0">
											<gml:posList>35.67196804022178 139.7399812760695 20.294 35.67196298048852 139.73998899240223 20.294 35.67196298048852 139.73998899240223 22.113 35.67196804022178 139.7399812760695 22.113 35.67196804022178 139.7399812760695 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4a7c97c-f96e-48fc-a829-09470c7053c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4a7c97c-f96e-48fc-a829-09470c7053c1_0">
											<gml:posList>35.67200593960068 139.7399769569509 21.134 35.67200123971828 139.73997214615716 21.134 35.67198663648927 139.7399941235663 21.134 35.6719913273571 139.73999893437096 21.134 35.67200593960068 139.7399769569509 21.134</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98b491e2-509f-4142-b490-0557e8731d9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98b491e2-509f-4142-b490-0557e8731d9a_0">
											<gml:posList>35.67200409032351 139.73997507015568 20.633 35.67198948709399 139.73999704756505 20.633 35.67198948709399 139.73999704756505 20.294 35.67200409032351 139.73997507015568 20.294 35.67200409032351 139.73997507015568 20.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ff90278-d8b9-4062-861a-5527dce0cefd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ff90278-d8b9-4062-861a-5527dce0cefd_0">
											<gml:posList>35.67197781857053 139.73999090826032 20.294 35.67196804022178 139.7399812760695 20.294 35.67196804022178 139.7399812760695 22.113 35.67197781857053 139.73999090826032 22.113 35.67197781857053 139.73999090826032 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb31c73b-e143-4e03-8439-2c6845397392">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb31c73b-e143-4e03-8439-2c6845397392_0">
											<gml:posList>35.6719913273571 139.73999893437096 20.633 35.67200593960068 139.7399769569509 20.633 35.67200593960068 139.7399769569509 21.134 35.6719913273571 139.73999893437096 21.134 35.6719913273571 139.73999893437096 20.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0bc49df9-9af0-4fd6-818b-a2cacec50785">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0bc49df9-9af0-4fd6-818b-a2cacec50785_0">
											<gml:posList>35.671837025235874 139.73999233147705 22.174 35.67182962827337 139.73998497210067 22.174 35.67182962827337 139.73998497210067 24.725 35.671837025235874 139.73999233147705 24.725 35.671837025235874 139.73999233147705 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a3cc312-be62-4721-b9de-86c4e76531df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a3cc312-be62-4721-b9de-86c4e76531df_0">
											<gml:posList>35.671972758828105 139.73999861354696 22.113 35.67197781857053 139.73999090826032 22.113 35.67196804022178 139.7399812760695 22.113 35.67196298048852 139.73998899240223 22.113 35.671972758828105 139.73999861354696 22.113</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0c5bd23-2665-464d-857f-7a7d3b0cb739">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0c5bd23-2665-464d-857f-7a7d3b0cb739_0">
											<gml:posList>35.67196298048852 139.73998899240223 20.294 35.671972758828105 139.73999861354696 20.294 35.671972758828105 139.73999861354696 22.113 35.67196298048852 139.73998899240223 22.113 35.67196298048852 139.73998899240223 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0e31ec5-7dc8-4930-bd82-15accae4d24f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0e31ec5-7dc8-4930-bd82-15accae4d24f_0">
											<gml:posList>35.671972758828105 139.73999861354696 20.294 35.67197781857053 139.73999090826032 20.294 35.67197781857053 139.73999090826032 22.113 35.671972758828105 139.73999861354696 22.113 35.671972758828105 139.73999861354696 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4edcd4d6-f8e7-45b5-9424-ee5c3711528c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4edcd4d6-f8e7-45b5-9424-ee5c3711528c_0">
											<gml:posList>35.67198948709399 139.73999704756505 20.633 35.6719913273571 139.73999893437096 20.633 35.6719913273571 139.73999893437096 21.134 35.67198663648927 139.7399941235663 21.134 35.67198663648927 139.7399941235663 20.294 35.67198948709399 139.73999704756505 20.294 35.67198948709399 139.73999704756505 20.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35def265-bb54-4f23-a8fd-973e4bdc7aca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35def265-bb54-4f23-a8fd-973e4bdc7aca_0">
											<gml:posList>35.67185133209327 139.74000663103527 22.174 35.67184477422107 139.74000032009326 22.174 35.67184477422107 139.74000032009326 24.76 35.67185133209327 139.74000663103527 24.76 35.67185133209327 139.74000663103527 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d3b84fe-a776-4484-90d7-d12e380d074e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d3b84fe-a776-4484-90d7-d12e380d074e_0">
											<gml:posList>35.67182962827337 139.73998497210067 22.174 35.671800475973576 139.74002903721362 22.174 35.671800475973576 139.74002903721362 24.725 35.67182962827337 139.73998497210067 24.725 35.67182962827337 139.73998497210067 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df69d877-f557-4c89-824c-150c42c49100">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df69d877-f557-4c89-824c-150c42c49100_0">
											<gml:posList>35.67182962827337 139.73998497210067 24.725 35.671800475973576 139.74002903721362 24.725 35.671807881938584 139.74003638553444 24.725 35.671837025235874 139.73999233147705 24.725 35.67182962827337 139.73998497210067 24.725</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aec4713b-eb9c-493b-909c-ff34a2baf85a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aec4713b-eb9c-493b-909c-ff34a2baf85a_0">
											<gml:posList>35.671807881938584 139.74003638553444 22.174 35.671837025235874 139.73999233147705 22.174 35.671837025235874 139.73999233147705 24.725 35.671807881938584 139.74003638553444 24.725 35.671807881938584 139.74003638553444 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c78b3342-349c-4212-be99-12d229cb567c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c78b3342-349c-4212-be99-12d229cb567c_0">
											<gml:posList>35.67181678438614 139.74004399723032 24.76 35.671823342256076 139.7400503081737 24.76 35.67185133209327 139.74000663103527 24.76 35.67184477422107 139.74000032009326 24.76 35.67181678438614 139.74004399723032 24.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7754737-a241-4a7b-97a2-c275165a9ae4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7754737-a241-4a7b-97a2-c275165a9ae4_0">
											<gml:posList>35.67185133209327 139.74000663103527 22.174 35.67185133209327 139.74000663103527 24.76 35.671823342256076 139.7400503081737 24.76 35.671823342256076 139.7400503081737 22.174 35.67185133209327 139.74000663103527 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f29450fc-0bbf-4636-bb08-cf16dc866d1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f29450fc-0bbf-4636-bb08-cf16dc866d1f_0">
											<gml:posList>35.671800475973576 139.74002903721362 22.174 35.671807881938584 139.74003638553444 22.174 35.671807881938584 139.74003638553444 24.725 35.671800475973576 139.74002903721362 24.725 35.671800475973576 139.74002903721362 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-089b6874-213b-48ea-b21d-3b631b83a01a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-089b6874-213b-48ea-b21d-3b631b83a01a_0">
											<gml:posList>35.67181678438614 139.74004399723032 22.174 35.671823342256076 139.7400503081737 22.174 35.671823342256076 139.7400503081737 24.76 35.67181678438614 139.74004399723032 24.76 35.67181678438614 139.74004399723032 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52c6c12d-9b3e-43fa-ad94-16bc6d53fb7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52c6c12d-9b3e-43fa-ad94-16bc6d53fb7b_0">
											<gml:posList>35.671894892542596 139.74013089728004 26.709 35.67188810409754 139.74014111210735 26.709 35.67188810409754 139.74014111210735 27.684 35.671894892542596 139.74013089728004 27.684 35.671894892542596 139.74013089728004 26.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68d33723-08a9-4fd0-b31c-c2dc798b7fad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68d33723-08a9-4fd0-b31c-c2dc798b7fad_0">
											<gml:posList>35.67191105762041 139.74014701738102 26.709 35.671894892542596 139.74013089728004 26.709 35.671894892542596 139.74013089728004 27.684 35.67191105762041 139.74014701738102 27.684 35.67191105762041 139.74014701738102 26.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfea8952-ad72-4298-8eb4-e41965f808a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfea8952-ad72-4298-8eb4-e41965f808a2_0">
											<gml:posList>35.67188810409754 139.74014111210735 27.684 35.67190426918256 139.7401572432555 27.684 35.67191105762041 139.74014701738102 27.684 35.671894892542596 139.74013089728004 27.684 35.67188810409754 139.74014111210735 27.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94df54df-6fe8-4268-8c73-da42261bee61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94df54df-6fe8-4268-8c73-da42261bee61_0">
											<gml:posList>35.67190426918256 139.7401572432555 26.709 35.67190426918256 139.7401572432555 27.684 35.67188810409754 139.74014111210735 27.684 35.67188810409754 139.74014111210735 26.709 35.67190426918256 139.7401572432555 26.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b75b3a1d-12fe-40c7-9c41-b6bb503c375c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b75b3a1d-12fe-40c7-9c41-b6bb503c375c_0">
											<gml:posList>35.67191105762041 139.74014701738102 26.709 35.67191105762041 139.74014701738102 27.684 35.67190426918256 139.7401572432555 27.684 35.67190426918256 139.7401572432555 26.709 35.67191105762041 139.74014701738102 26.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ea8dd627-79d2-45d5-9dec-9aeb5f752397">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea8dd627-79d2-45d5-9dec-9aeb5f752397">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea8dd627-79d2-45d5-9dec-9aeb5f752397">
											<gml:posList>35.67198009285709 139.7398551222825 8.044 35.672044590934796 139.7399194481094 8.044 35.67194951685795 139.7400625002801 8.044 35.67200320807685 139.7401161016317 8.044 35.67200472351066 139.7401175580055 8.044 35.67194422182685 139.74020876176786 8.044 35.67177291882098 139.7400378512129 8.044 35.67183351060003 139.7399467578765 8.044 35.671885199215616 139.73999828466876 8.044 35.671888530353264 139.73999319941584 8.044 35.67183602990096 139.7399409003182 8.044 35.67187051225587 139.73988905223072 8.044 35.671828565959146 139.73984723504103 8.044 35.67188825836725 139.73975890416392 8.044 35.671981263268584 139.73985335348107 8.044 35.67198009285709 139.7398551222825 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8fc154e5-0180-469f-8d8f-de8975c23fec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fc154e5-0180-469f-8d8f-de8975c23fec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fc154e5-0180-469f-8d8f-de8975c23fec">
											<gml:posList>35.67183351060003 139.7399467578765 22.885 35.67177291882098 139.7400378512129 22.885 35.67179089045927 139.7400356099626 22.885 35.671835339438886 139.73996878238725 22.885 35.67183351060003 139.7399467578765 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b83d5bb9-d49b-4ed2-a009-56801e3ae516">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b83d5bb9-d49b-4ed2-a009-56801e3ae516">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b83d5bb9-d49b-4ed2-a009-56801e3ae516">
											<gml:posList>35.67187816330623 139.74014285795755 22.885 35.67188632022949 139.740130564805 22.885 35.67179089045927 139.7400356099626 22.885 35.67177291882098 139.7400378512129 22.885 35.67187816330623 139.74014285795755 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-569ac2ea-8a78-4fe9-8a59-bbad487c24b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-569ac2ea-8a78-4fe9-8a59-bbad487c24b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-569ac2ea-8a78-4fe9-8a59-bbad487c24b8">
											<gml:posList>35.67185495486683 139.73980817711794 23.301 35.671828565959146 139.73984723504103 23.301 35.67183276596689 139.7398467330529 23.301 35.67185540947378 139.73981322482103 23.301 35.67185495486683 139.73980817711794 23.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-439d471d-7cd4-47d3-afe0-a01d54224f02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-439d471d-7cd4-47d3-afe0-a01d54224f02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-439d471d-7cd4-47d3-afe0-a01d54224f02">
											<gml:posList>35.67187469422776 139.7398885392191 23.301 35.67183276596689 139.7398467330529 23.301 35.671828565959146 139.73984723504103 23.301 35.67187051225587 139.73988905223072 23.301 35.67187469422776 139.7398885392191 23.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c1a197c0-a5a6-42dc-a355-a58120446e4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1a197c0-a5a6-42dc-a355-a58120446e4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1a197c0-a5a6-42dc-a355-a58120446e4e">
											<gml:posList>35.67185697284019 139.73985318909996 22.891 35.67187053990343 139.73983177627892 22.891 35.67185540947378 139.73981322482103 22.891 35.67183276596689 139.7398467330529 22.891 35.67185697284019 139.73985318909996 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0800b8b4-082a-4226-a3d6-75fb6242770f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0800b8b4-082a-4226-a3d6-75fb6242770f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0800b8b4-082a-4226-a3d6-75fb6242770f">
											<gml:posList>35.671840211864534 139.7399403762631 23.301 35.67187469422776 139.7398885392191 23.301 35.67187051225587 139.73988905223072 23.301 35.67183602990096 139.7399409003182 23.301 35.671840211864534 139.7399403762631 23.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0ed5593-e33a-4c23-b051-4a1d09534d0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0ed5593-e33a-4c23-b051-4a1d09534d0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0ed5593-e33a-4c23-b051-4a1d09534d0b">
											<gml:posList>35.67183276596689 139.7398467330529 22.891 35.67187469422776 139.7398885392191 22.891 35.67188071447034 139.73987572934803 22.891 35.67185697284019 139.73985318909996 22.891 35.67183276596689 139.7398467330529 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2136b1d6-138f-4e9a-867f-7fef01342d53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2136b1d6-138f-4e9a-867f-7fef01342d53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2136b1d6-138f-4e9a-867f-7fef01342d53">
											<gml:posList>35.671840211864534 139.7399403762631 23.301 35.67183602990096 139.7399409003182 23.301 35.671888530353264 139.73999319941584 23.301 35.67188810274364 139.73998808539935 23.301 35.671840211864534 139.7399403762631 23.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d114e7d9-34dd-4d94-a258-45e73318908b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d114e7d9-34dd-4d94-a258-45e73318908b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d114e7d9-34dd-4d94-a258-45e73318908b">
											<gml:posList>35.67187053990343 139.73983177627892 28.217 35.67185697284019 139.73985318909996 28.217 35.671859505395446 139.73985279952086 28.217 35.67187085779396 139.73983487996477 28.217 35.67187053990343 139.73983177627892 28.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b4df195-945a-41ee-a767-19fae47bcb81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b4df195-945a-41ee-a767-19fae47bcb81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b4df195-945a-41ee-a767-19fae47bcb81">
											<gml:posList>35.67185697284019 139.73985318909996 28.217 35.67188071447034 139.73987572934803 28.217 35.671880396589444 139.73987263670807 28.217 35.671859505395446 139.73985279952086 28.217 35.67185697284019 139.73985318909996 28.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-07b77233-fbbc-4c0c-9ba0-d3462c9b2d9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07b77233-fbbc-4c0c-9ba0-d3462c9b2d9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07b77233-fbbc-4c0c-9ba0-d3462c9b2d9a">
											<gml:posList>35.671859505395446 139.73985279952086 27.511 35.671880396589444 139.73987263670807 27.511 35.67189173098057 139.73985473926405 27.511 35.67187085779396 139.73983487996477 27.511 35.671859505395446 139.73985279952086 27.511</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc66353f-bcfa-4539-a1d9-f95a53877cbf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc66353f-bcfa-4539-a1d9-f95a53877cbf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc66353f-bcfa-4539-a1d9-f95a53877cbf">
											<gml:posList>35.67189426353581 139.7398543496848 28.217 35.67187053990343 139.73983177627892 28.217 35.67187085779396 139.73983487996477 28.217 35.67189173098057 139.73985473926405 28.217 35.67189426353581 139.7398543496848 28.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c59add2-8398-4405-bbba-a40c328d4c4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c59add2-8398-4405-bbba-a40c328d4c4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c59add2-8398-4405-bbba-a40c328d4c4c">
											<gml:posList>35.671894486165186 139.74011827163946 26.858 35.67187816330623 139.74014285795755 26.858 35.67188284097399 139.74014226705768 26.858 35.67189496833046 139.74012400419582 26.858 35.671894486165186 139.74011827163946 26.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d31f1f83-5db4-447c-888e-7ee44b814278">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d31f1f83-5db4-447c-888e-7ee44b814278">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d31f1f83-5db4-447c-888e-7ee44b814278">
											<gml:posList>35.67188071447034 139.73987572934803 28.217 35.67189426353581 139.7398543496848 28.217 35.67189173098057 139.73985473926405 28.217 35.671880396589444 139.73987263670807 28.217 35.67188071447034 139.73987572934803 28.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a405fdd-7954-4abd-8a7d-e0081d42ddb2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a405fdd-7954-4abd-8a7d-e0081d42ddb2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a405fdd-7954-4abd-8a7d-e0081d42ddb2">
											<gml:posList>35.67179089045927 139.7400356099626 22.174 35.67188632022949 139.740130564805 22.174 35.671894486165186 139.74011827163946 22.174 35.67195090158861 139.7401745651663 22.174 35.67198674290904 139.74011986553282 22.174 35.671835339438886 139.73996878238725 22.174 35.67179089045927 139.7400356099626 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6e597dba-9151-45d8-9108-3877c3ebe8ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e597dba-9151-45d8-9108-3877c3ebe8ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e597dba-9151-45d8-9108-3877c3ebe8ae">
											<gml:posList>35.67194655149829 139.7398999327543 22.891 35.67189426353581 139.7398543496848 22.891 35.67188071447034 139.73987572934803 22.891 35.67187469422776 139.7398885392191 22.891 35.671840211864534 139.7399403762631 22.891 35.67188810274364 139.73998808539935 22.891 35.67194655149829 139.7398999327543 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5046edb5-1087-4ea1-896c-af01f3491d28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5046edb5-1087-4ea1-896c-af01f3491d28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5046edb5-1087-4ea1-896c-af01f3491d28">
											<gml:posList>35.67185540947378 139.73981322482103 22.891 35.67187053990343 139.73983177627892 22.891 35.67189426353581 139.7398543496848 22.891 35.67194655149829 139.7398999327543 22.891 35.67185540947378 139.73981322482103 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-87c5d48c-ea4e-41b7-a4dc-ca8048718a0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87c5d48c-ea4e-41b7-a4dc-ca8048718a0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87c5d48c-ea4e-41b7-a4dc-ca8048718a0c">
											<gml:posList>35.67188825836725 139.73975890416392 15.735 35.67185495486683 139.73980817711794 23.301 35.67195076946505 139.73989934237545 23.301 35.67188825836725 139.73975890416392 15.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5395ff43-a9ad-463a-b670-50bd9787b7b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5395ff43-a9ad-463a-b670-50bd9787b7b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5395ff43-a9ad-463a-b670-50bd9787b7b4">
											<gml:posList>35.67195076946505 139.73989934237545 23.301 35.67185495486683 139.73980817711794 23.301 35.67185540947378 139.73981322482103 23.301 35.67194655149829 139.7398999327543 23.301 35.67195076946505 139.73989934237545 23.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-52761160-a6e4-45e1-8835-6616129bfc62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52761160-a6e4-45e1-8835-6616129bfc62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52761160-a6e4-45e1-8835-6616129bfc62">
											<gml:posList>35.67187816330623 139.74014285795755 26.858 35.67194267929316 139.7402072280996 26.858 35.67194218811812 139.7402014955498 26.858 35.67188284097399 139.74014226705768 26.858 35.67187816330623 139.74014285795755 26.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-510108fa-af92-45d3-b431-e4a744b47c5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-510108fa-af92-45d3-b431-e4a744b47c5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-510108fa-af92-45d3-b431-e4a744b47c5f">
											<gml:posList>35.671885199215616 139.73999828466876 20.633 35.671889038683716 139.7399977941544 20.633 35.67189065923534 139.73999531785904 20.633 35.67194506556587 139.7399132675813 20.633 35.671944674299134 139.7399085290995 20.633 35.671888530353264 139.73999319941584 20.633 35.671885199215616 139.73999828466876 20.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e688f99-c41b-40ff-a47a-6cd66632206f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e688f99-c41b-40ff-a47a-6cd66632206f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e688f99-c41b-40ff-a47a-6cd66632206f">
											<gml:posList>35.67194951685795 139.7400625002801 20.633 35.67194911660048 139.74005778390065 20.633 35.671889038683716 139.7399977941544 20.633 35.671885199215616 139.73999828466876 20.633 35.67194951685795 139.7400625002801 20.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-357fdd87-5a91-4c09-bd5d-c813789ce6d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-357fdd87-5a91-4c09-bd5d-c813789ce6d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-357fdd87-5a91-4c09-bd5d-c813789ce6d9">
											<gml:posList>35.67194218811812 139.7402014955498 26.709 35.67195431548345 139.74018323268334 26.709 35.67189496833046 139.74012400419582 26.709 35.67188284097399 139.74014226705768 26.709 35.67194218811812 139.7402014955498 26.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93572e66-08bc-42f5-bfda-a74f6c2575d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93572e66-08bc-42f5-bfda-a74f6c2575d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93572e66-08bc-42f5-bfda-a74f6c2575d7">
											<gml:posList>35.671835339438886 139.73996878238725 22.885 35.67198674290904 139.74011986553282 22.885 35.67200472351066 139.7401175580055 22.885 35.67200320807685 139.7401161016317 22.885 35.67183351060003 139.7399467578765 22.885 35.671835339438886 139.73996878238725 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b4b7e13e-de52-477d-bc02-875cf6f39b3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4b7e13e-de52-477d-bc02-875cf6f39b3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4b7e13e-de52-477d-bc02-875cf6f39b3e">
											<gml:posList>35.671888530353264 139.73999319941584 23.301 35.67195076946505 139.73989934237545 23.301 35.67194655149829 139.7398999327543 23.301 35.67188810274364 139.73998808539935 23.301 35.671888530353264 139.73999319941584 23.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-15bba42d-90c1-47d2-bb9b-684aef857277">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15bba42d-90c1-47d2-bb9b-684aef857277">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15bba42d-90c1-47d2-bb9b-684aef857277">
											<gml:posList>35.671894486165186 139.74011827163946 26.858 35.67189496833046 139.74012400419582 26.858 35.67195431548345 139.74018323268334 26.858 35.671959002165075 139.7401826417748 26.858 35.671894486165186 139.74011827163946 26.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad36788a-571e-4bcd-b944-1600044e6ab5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad36788a-571e-4bcd-b944-1600044e6ab5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad36788a-571e-4bcd-b944-1600044e6ab5">
											<gml:posList>35.67195076946505 139.73989934237545 23.301 35.671981263268584 139.73985335348107 15.735 35.67188825836725 139.73975890416392 15.735 35.67195076946505 139.73989934237545 23.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7207423a-e542-428f-974e-834111284633">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7207423a-e542-428f-974e-834111284633">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7207423a-e542-428f-974e-834111284633">
											<gml:posList>35.67194506556587 139.7399132675813 20.294 35.67189065923534 139.73999531785904 20.294 35.671889038683716 139.7399977941544 20.294 35.67194911660048 139.74005778390065 20.294 35.67200529675739 139.73997325712756 20.294 35.67194506556587 139.7399132675813 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6a9191f-5363-4c82-ae5e-3252acc654ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6a9191f-5363-4c82-ae5e-3252acc654ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6a9191f-5363-4c82-ae5e-3252acc654ef">
											<gml:posList>35.67194267929316 139.7402072280996 26.858 35.671959002165075 139.7401826417748 26.858 35.67195431548345 139.74018323268334 26.858 35.67194218811812 139.7402014955498 26.858 35.67194267929316 139.7402072280996 26.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-db8b6f9b-e1cd-460a-b8b9-ce32d9b3e03d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db8b6f9b-e1cd-460a-b8b9-ce32d9b3e03d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db8b6f9b-e1cd-460a-b8b9-ce32d9b3e03d">
											<gml:posList>35.67200472351066 139.7401175580055 22.885 35.67198674290904 139.74011986553282 22.885 35.67195090158861 139.7401745651663 22.885 35.671959002165075 139.7401826417748 22.885 35.67194267929316 139.7402072280996 22.885 35.67194422182685 139.74020876176786 22.885 35.67200472351066 139.7401175580055 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af32cc2d-c8c5-414c-ae23-976b0cccd3ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af32cc2d-c8c5-414c-ae23-976b0cccd3ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af32cc2d-c8c5-414c-ae23-976b0cccd3ce">
											<gml:posList>35.67194506556587 139.7399132675813 20.633 35.67200529675739 139.73997325712756 20.633 35.67200916325791 139.73997275553327 20.633 35.671944674299134 139.7399085290995 20.633 35.67194506556587 139.7399132675813 20.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8ddc387f-1064-484a-abfb-bc90ea56b823">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ddc387f-1064-484a-abfb-bc90ea56b823">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ddc387f-1064-484a-abfb-bc90ea56b823">
											<gml:posList>35.67194911660048 139.74005778390065 20.633 35.67194951685795 139.7400625002801 20.633 35.67200916325791 139.73997275553327 20.633 35.67200529675739 139.73997325712756 20.633 35.67194911660048 139.74005778390065 20.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c89f854-e510-441f-910a-33accd5fed36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c89f854-e510-441f-910a-33accd5fed36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c89f854-e510-441f-910a-33accd5fed36">
											<gml:posList>35.671944674299134 139.7399085290995 17.202 35.67200916325791 139.73997275553327 17.202 35.672029501540145 139.73994215517448 17.202 35.67196508454643 139.739877762968 17.202 35.671944674299134 139.7399085290995 17.202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08466284-dd15-498e-b84f-3b3c12da306c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08466284-dd15-498e-b84f-3b3c12da306c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08466284-dd15-498e-b84f-3b3c12da306c">
											<gml:posList>35.672029501540145 139.73994215517448 17.202 35.672044590934796 139.7399194481094 15.344 35.67198009285709 139.7398551222825 15.344 35.67196508454643 139.739877762968 17.202 35.672029501540145 139.73994215517448 17.202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ee7ab0b-320c-46f6-945b-0cb21434c1e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ee7ab0b-320c-46f6-945b-0cb21434c1e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ee7ab0b-320c-46f6-945b-0cb21434c1e1">
											<gml:posList>35.67189173098057 139.73985473926405 28.217 35.67187085779396 139.73983487996477 28.217 35.67187085779396 139.73983487996477 27.511 35.67189173098057 139.73985473926405 27.511 35.67189173098057 139.73985473926405 28.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-958b00fa-3c31-4bad-b3ac-009b1f3af262">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-958b00fa-3c31-4bad-b3ac-009b1f3af262">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-958b00fa-3c31-4bad-b3ac-009b1f3af262">
											<gml:posList>35.671859505395446 139.73985279952086 28.217 35.671880396589444 139.73987263670807 28.217 35.671880396589444 139.73987263670807 27.511 35.671859505395446 139.73985279952086 27.511 35.671859505395446 139.73985279952086 28.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-815c42e3-ee52-4207-9d62-974a70c4d99c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-815c42e3-ee52-4207-9d62-974a70c4d99c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-815c42e3-ee52-4207-9d62-974a70c4d99c">
											<gml:posList>35.67198674290904 139.74011986553282 22.885 35.671835339438886 139.73996878238725 22.885 35.671835339438886 139.73996878238725 22.174 35.67198674290904 139.74011986553282 22.174 35.67198674290904 139.74011986553282 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfe04e35-21cb-45af-95b9-2b4a3be34266">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfe04e35-21cb-45af-95b9-2b4a3be34266">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfe04e35-21cb-45af-95b9-2b4a3be34266">
											<gml:posList>35.67179089045927 139.7400356099626 22.885 35.67188632022949 139.740130564805 22.885 35.67188632022949 139.740130564805 22.174 35.67179089045927 139.7400356099626 22.174 35.67179089045927 139.7400356099626 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0eef99d5-5325-402a-ae60-3094cb3ecfc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0eef99d5-5325-402a-ae60-3094cb3ecfc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0eef99d5-5325-402a-ae60-3094cb3ecfc1">
											<gml:posList>35.67189496833046 139.74012400419582 26.709 35.67195431548345 139.74018323268334 26.709 35.67195431548345 139.74018323268334 26.858 35.67189496833046 139.74012400419582 26.858 35.67189496833046 139.74012400419582 26.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1da6b68-1e85-44ad-beec-789a19771ed8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1da6b68-1e85-44ad-beec-789a19771ed8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1da6b68-1e85-44ad-beec-789a19771ed8">
											<gml:posList>35.67188284097399 139.74014226705768 26.858 35.67194218811812 139.7402014955498 26.858 35.67194218811812 139.7402014955498 26.709 35.67188284097399 139.74014226705768 26.709 35.67188284097399 139.74014226705768 26.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6cad1535-d61f-4b5b-a35d-110e6a29d80d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cad1535-d61f-4b5b-a35d-110e6a29d80d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cad1535-d61f-4b5b-a35d-110e6a29d80d">
											<gml:posList>35.671828565959146 139.73984723504103 8.044 35.671828565959146 139.73984723504103 23.301 35.67185495486683 139.73980817711794 23.301 35.67188825836725 139.73975890416392 15.735 35.67188825836725 139.73975890416392 8.044 35.671828565959146 139.73984723504103 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dcdb229f-23bb-4d8e-a22b-21144f06d3f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcdb229f-23bb-4d8e-a22b-21144f06d3f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcdb229f-23bb-4d8e-a22b-21144f06d3f4">
											<gml:posList>35.67188825836725 139.73975890416392 8.044 35.67188825836725 139.73975890416392 15.735 35.671981263268584 139.73985335348107 15.735 35.671981263268584 139.73985335348107 8.044 35.67188825836725 139.73975890416392 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0613447f-61cf-4db5-ad4e-8c07d5631ed9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0613447f-61cf-4db5-ad4e-8c07d5631ed9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0613447f-61cf-4db5-ad4e-8c07d5631ed9">
											<gml:posList>35.67183276596689 139.7398467330529 22.891 35.67185540947378 139.73981322482103 22.891 35.67185540947378 139.73981322482103 23.301 35.67183276596689 139.7398467330529 23.301 35.67183276596689 139.7398467330529 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6629e041-9677-4e99-9295-2748708a33aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6629e041-9677-4e99-9295-2748708a33aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6629e041-9677-4e99-9295-2748708a33aa">
											<gml:posList>35.67185697284019 139.73985318909996 22.891 35.67185697284019 139.73985318909996 28.217 35.67187053990343 139.73983177627892 28.217 35.67187053990343 139.73983177627892 22.891 35.67185697284019 139.73985318909996 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b59308a6-3e26-44a4-ac23-18550c39b043">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b59308a6-3e26-44a4-ac23-18550c39b043">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b59308a6-3e26-44a4-ac23-18550c39b043">
											<gml:posList>35.67189426353581 139.7398543496848 22.891 35.67187053990343 139.73983177627892 22.891 35.67187053990343 139.73983177627892 28.217 35.67189426353581 139.7398543496848 28.217 35.67189426353581 139.7398543496848 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c75bce1-db48-450a-affb-9d9d640181cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c75bce1-db48-450a-affb-9d9d640181cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c75bce1-db48-450a-affb-9d9d640181cf">
											<gml:posList>35.67187085779396 139.73983487996477 28.217 35.671859505395446 139.73985279952086 28.217 35.671859505395446 139.73985279952086 27.511 35.67187085779396 139.73983487996477 27.511 35.67187085779396 139.73983487996477 28.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-923b62f5-e513-408b-ad9f-9a7b2280bf5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-923b62f5-e513-408b-ad9f-9a7b2280bf5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-923b62f5-e513-408b-ad9f-9a7b2280bf5e">
											<gml:posList>35.67185540947378 139.73981322482103 22.891 35.67194655149829 139.7398999327543 22.891 35.67194655149829 139.7398999327543 23.301 35.67185540947378 139.73981322482103 23.301 35.67185540947378 139.73981322482103 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28f7fa01-6617-4ed9-9dc3-5badeb0072f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28f7fa01-6617-4ed9-9dc3-5badeb0072f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28f7fa01-6617-4ed9-9dc3-5badeb0072f8">
											<gml:posList>35.671880396589444 139.73987263670807 28.217 35.67189173098057 139.73985473926405 28.217 35.67189173098057 139.73985473926405 27.511 35.671880396589444 139.73987263670807 27.511 35.671880396589444 139.73987263670807 28.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-042ebb3b-cf64-4bfa-ba6d-bc8f89991ebc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-042ebb3b-cf64-4bfa-ba6d-bc8f89991ebc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-042ebb3b-cf64-4bfa-ba6d-bc8f89991ebc">
											<gml:posList>35.67188071447034 139.73987572934803 22.891 35.67188071447034 139.73987572934803 28.217 35.67185697284019 139.73985318909996 28.217 35.67185697284019 139.73985318909996 22.891 35.67188071447034 139.73987572934803 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2ae0693-a802-40ac-81f8-8f4eb445f4ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2ae0693-a802-40ac-81f8-8f4eb445f4ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2ae0693-a802-40ac-81f8-8f4eb445f4ec">
											<gml:posList>35.67189426353581 139.7398543496848 28.217 35.67188071447034 139.73987572934803 28.217 35.67188071447034 139.73987572934803 22.891 35.67189426353581 139.7398543496848 22.891 35.67189426353581 139.7398543496848 28.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13daa3d6-584f-48ed-94b9-791989880889">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13daa3d6-584f-48ed-94b9-791989880889">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13daa3d6-584f-48ed-94b9-791989880889">
											<gml:posList>35.67183276596689 139.7398467330529 23.301 35.67187469422776 139.7398885392191 23.301 35.67187469422776 139.7398885392191 22.891 35.67183276596689 139.7398467330529 22.891 35.67183276596689 139.7398467330529 23.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1d6a3f2-d74f-4f29-8ab7-1f2f5f482207">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1d6a3f2-d74f-4f29-8ab7-1f2f5f482207">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1d6a3f2-d74f-4f29-8ab7-1f2f5f482207">
											<gml:posList>35.67187051225587 139.73988905223072 8.044 35.67187051225587 139.73988905223072 23.301 35.671828565959146 139.73984723504103 23.301 35.671828565959146 139.73984723504103 8.044 35.67187051225587 139.73988905223072 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c51573d1-26b3-4437-8946-7fbf951d0804">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c51573d1-26b3-4437-8946-7fbf951d0804">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c51573d1-26b3-4437-8946-7fbf951d0804">
											<gml:posList>35.67198009285709 139.7398551222825 8.044 35.67198009285709 139.7398551222825 15.344 35.672044590934796 139.7399194481094 15.344 35.672044590934796 139.7399194481094 8.044 35.67198009285709 139.7398551222825 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-465fdab4-4096-467c-80bd-f7341da5d3b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-465fdab4-4096-467c-80bd-f7341da5d3b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-465fdab4-4096-467c-80bd-f7341da5d3b1">
											<gml:posList>35.67187469422776 139.7398885392191 23.301 35.671840211864534 139.7399403762631 23.301 35.671840211864534 139.7399403762631 22.891 35.67187469422776 139.7398885392191 22.891 35.67187469422776 139.7398885392191 23.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f920c62e-149c-4232-91c6-b4fe1ccc686e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f920c62e-149c-4232-91c6-b4fe1ccc686e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f920c62e-149c-4232-91c6-b4fe1ccc686e">
											<gml:posList>35.67183602990096 139.7399409003182 8.044 35.67183602990096 139.7399409003182 23.301 35.67187051225587 139.73988905223072 23.301 35.67187051225587 139.73988905223072 8.044 35.67183602990096 139.7399409003182 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-585421fb-0c74-40fe-aeda-7b4b1081ba02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-585421fb-0c74-40fe-aeda-7b4b1081ba02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-585421fb-0c74-40fe-aeda-7b4b1081ba02">
											<gml:posList>35.671944674299134 139.7399085290995 20.633 35.671944674299134 139.7399085290995 17.202 35.67196508454643 139.739877762968 17.202 35.67198009285709 139.7398551222825 15.344 35.67198009285709 139.7398551222825 8.044 35.671981263268584 139.73985335348107 8.044 35.671981263268584 139.73985335348107 15.735 35.67195076946505 139.73989934237545 23.301 35.671888530353264 139.73999319941584 23.301 35.671888530353264 139.73999319941584 20.633 35.671944674299134 139.7399085290995 20.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ec758bd-9568-411c-a9d3-96de9798906a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ec758bd-9568-411c-a9d3-96de9798906a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ec758bd-9568-411c-a9d3-96de9798906a">
											<gml:posList>35.67200916325791 139.73997275553327 20.633 35.67200916325791 139.73997275553327 17.202 35.671944674299134 139.7399085290995 17.202 35.671944674299134 139.7399085290995 20.633 35.67200916325791 139.73997275553327 20.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-701dd069-c317-437b-988e-6e75ae47a3d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-701dd069-c317-437b-988e-6e75ae47a3d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-701dd069-c317-437b-988e-6e75ae47a3d6">
											<gml:posList>35.67194506556587 139.7399132675813 20.294 35.67200529675739 139.73997325712756 20.294 35.67200529675739 139.73997325712756 20.633 35.67194506556587 139.7399132675813 20.633 35.67194506556587 139.7399132675813 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da4a12fa-69df-49ce-b541-fefe9c566a50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da4a12fa-69df-49ce-b541-fefe9c566a50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da4a12fa-69df-49ce-b541-fefe9c566a50">
											<gml:posList>35.67188810274364 139.73998808539935 23.301 35.67194655149829 139.7398999327543 23.301 35.67194655149829 139.7398999327543 22.891 35.67188810274364 139.73998808539935 22.891 35.67188810274364 139.73998808539935 23.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ed0cc8b-6095-4cb9-85f5-d55ee8767c2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ed0cc8b-6095-4cb9-85f5-d55ee8767c2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ed0cc8b-6095-4cb9-85f5-d55ee8767c2a">
											<gml:posList>35.67194506556587 139.7399132675813 20.633 35.67189065923534 139.73999531785904 20.633 35.67189065923534 139.73999531785904 20.294 35.67194506556587 139.7399132675813 20.294 35.67194506556587 139.7399132675813 20.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-408e6be9-8ad1-425e-94ef-d573357a2c40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-408e6be9-8ad1-425e-94ef-d573357a2c40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-408e6be9-8ad1-425e-94ef-d573357a2c40">
											<gml:posList>35.67188810274364 139.73998808539935 22.891 35.671840211864534 139.7399403762631 22.891 35.671840211864534 139.7399403762631 23.301 35.67188810274364 139.73998808539935 23.301 35.67188810274364 139.73998808539935 22.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d47d5bbc-c0a8-478f-833d-256f4acd21e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d47d5bbc-c0a8-478f-833d-256f4acd21e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d47d5bbc-c0a8-478f-833d-256f4acd21e2">
											<gml:posList>35.67183602990096 139.7399409003182 23.301 35.67183602990096 139.7399409003182 8.044 35.671888530353264 139.73999319941584 8.044 35.671888530353264 139.73999319941584 20.633 35.671888530353264 139.73999319941584 23.301 35.67183602990096 139.7399409003182 23.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-062acfb2-2823-4836-be8e-12c53e6b7129">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-062acfb2-2823-4836-be8e-12c53e6b7129">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-062acfb2-2823-4836-be8e-12c53e6b7129">
											<gml:posList>35.672044590934796 139.7399194481094 15.344 35.672029501540145 139.73994215517448 17.202 35.67200916325791 139.73997275553327 17.202 35.67200916325791 139.73997275553327 20.633 35.67194951685795 139.7400625002801 20.633 35.67194951685795 139.7400625002801 8.044 35.672044590934796 139.7399194481094 8.044 35.672044590934796 139.7399194481094 15.344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d2f61e5-246f-43a2-bf74-b2b1c2e587b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d2f61e5-246f-43a2-bf74-b2b1c2e587b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d2f61e5-246f-43a2-bf74-b2b1c2e587b3">
											<gml:posList>35.67183351060003 139.7399467578765 22.885 35.67183351060003 139.7399467578765 8.044 35.67177291882098 139.7400378512129 8.044 35.67177291882098 139.7400378512129 22.885 35.67183351060003 139.7399467578765 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b730c65-ddc9-431b-846c-39c7b24ea7f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b730c65-ddc9-431b-846c-39c7b24ea7f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b730c65-ddc9-431b-846c-39c7b24ea7f6">
											<gml:posList>35.671888530353264 139.73999319941584 20.633 35.671888530353264 139.73999319941584 8.044 35.671885199215616 139.73999828466876 8.044 35.671885199215616 139.73999828466876 20.633 35.671888530353264 139.73999319941584 20.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d49837bf-4a64-46db-abc7-87f02e38347e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d49837bf-4a64-46db-abc7-87f02e38347e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d49837bf-4a64-46db-abc7-87f02e38347e">
											<gml:posList>35.67189065923534 139.73999531785904 20.633 35.671889038683716 139.7399977941544 20.633 35.671889038683716 139.7399977941544 20.294 35.67189065923534 139.73999531785904 20.294 35.67189065923534 139.73999531785904 20.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e62734f9-a565-48fc-a5d0-c34f98d366ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e62734f9-a565-48fc-a5d0-c34f98d366ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e62734f9-a565-48fc-a5d0-c34f98d366ea">
											<gml:posList>35.67179089045927 139.7400356099626 22.174 35.671835339438886 139.73996878238725 22.174 35.671835339438886 139.73996878238725 22.885 35.67179089045927 139.7400356099626 22.885 35.67179089045927 139.7400356099626 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b701a718-9d98-426d-b10c-b6efd8085af8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b701a718-9d98-426d-b10c-b6efd8085af8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b701a718-9d98-426d-b10c-b6efd8085af8">
											<gml:posList>35.67194911660048 139.74005778390065 20.294 35.67194911660048 139.74005778390065 20.633 35.67200529675739 139.73997325712756 20.633 35.67200529675739 139.73997325712756 20.294 35.67194911660048 139.74005778390065 20.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-512b0f11-34ea-42fc-a265-c1a64c927f04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-512b0f11-34ea-42fc-a265-c1a64c927f04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-512b0f11-34ea-42fc-a265-c1a64c927f04">
											<gml:posList>35.671889038683716 139.7399977941544 20.633 35.67194911660048 139.74005778390065 20.633 35.67194911660048 139.74005778390065 20.294 35.671889038683716 139.7399977941544 20.294 35.671889038683716 139.7399977941544 20.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f32ab16-90ad-49b8-a6bd-1b10fc662bc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f32ab16-90ad-49b8-a6bd-1b10fc662bc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f32ab16-90ad-49b8-a6bd-1b10fc662bc6">
											<gml:posList>35.671885199215616 139.73999828466876 20.633 35.671885199215616 139.73999828466876 8.044 35.67183351060003 139.7399467578765 8.044 35.67183351060003 139.7399467578765 22.885 35.67200320807685 139.7401161016317 22.885 35.67200320807685 139.7401161016317 8.044 35.67194951685795 139.7400625002801 8.044 35.67194951685795 139.7400625002801 20.633 35.671885199215616 139.73999828466876 20.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0684db98-884d-47ef-8aa3-7dda3789d366">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0684db98-884d-47ef-8aa3-7dda3789d366">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0684db98-884d-47ef-8aa3-7dda3789d366">
											<gml:posList>35.67200320807685 139.7401161016317 8.044 35.67200320807685 139.7401161016317 22.885 35.67200472351066 139.7401175580055 22.885 35.67200472351066 139.7401175580055 8.044 35.67200320807685 139.7401161016317 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41f65404-eec5-46d5-83cc-7529909f2589">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41f65404-eec5-46d5-83cc-7529909f2589">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41f65404-eec5-46d5-83cc-7529909f2589">
											<gml:posList>35.67194267929316 139.7402072280996 22.885 35.67194267929316 139.7402072280996 26.858 35.67187816330623 139.74014285795755 26.858 35.67187816330623 139.74014285795755 22.885 35.67177291882098 139.7400378512129 22.885 35.67177291882098 139.7400378512129 8.044 35.67194422182685 139.74020876176786 8.044 35.67194422182685 139.74020876176786 22.885 35.67194267929316 139.7402072280996 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f60d9cc-2222-47f3-89a3-22a327c401ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f60d9cc-2222-47f3-89a3-22a327c401ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f60d9cc-2222-47f3-89a3-22a327c401ad">
											<gml:posList>35.67187816330623 139.74014285795755 26.858 35.671894486165186 139.74011827163946 26.858 35.671894486165186 139.74011827163946 22.174 35.67188632022949 139.740130564805 22.174 35.67188632022949 139.740130564805 22.885 35.67187816330623 139.74014285795755 22.885 35.67187816330623 139.74014285795755 26.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d43d7ab-4dab-4fa2-b097-45291dac65b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d43d7ab-4dab-4fa2-b097-45291dac65b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d43d7ab-4dab-4fa2-b097-45291dac65b6">
											<gml:posList>35.67188284097399 139.74014226705768 26.709 35.67189496833046 139.74012400419582 26.709 35.67189496833046 139.74012400419582 26.858 35.67188284097399 139.74014226705768 26.858 35.67188284097399 139.74014226705768 26.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1221c051-e0ee-4945-b3ff-18d323ea242c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1221c051-e0ee-4945-b3ff-18d323ea242c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1221c051-e0ee-4945-b3ff-18d323ea242c">
											<gml:posList>35.67198674290904 139.74011986553282 22.174 35.67195090158861 139.7401745651663 22.174 35.67195090158861 139.7401745651663 22.885 35.67198674290904 139.74011986553282 22.885 35.67198674290904 139.74011986553282 22.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3114ef63-e9d7-4bff-a7d4-e3e41513fff3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3114ef63-e9d7-4bff-a7d4-e3e41513fff3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3114ef63-e9d7-4bff-a7d4-e3e41513fff3">
											<gml:posList>35.671959002165075 139.7401826417748 26.858 35.671959002165075 139.7401826417748 22.885 35.67195090158861 139.7401745651663 22.885 35.67195090158861 139.7401745651663 22.174 35.671894486165186 139.74011827163946 22.174 35.671894486165186 139.74011827163946 26.858 35.671959002165075 139.7401826417748 26.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a380f35-01fa-4204-bbd6-f48fd44549b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a380f35-01fa-4204-bbd6-f48fd44549b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a380f35-01fa-4204-bbd6-f48fd44549b9">
											<gml:posList>35.67194422182685 139.74020876176786 8.044 35.67200472351066 139.7401175580055 8.044 35.67200472351066 139.7401175580055 22.885 35.67194422182685 139.74020876176786 22.885 35.67194422182685 139.74020876176786 8.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b07252f-4d23-4c5e-ad8c-2a6cc81a27e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b07252f-4d23-4c5e-ad8c-2a6cc81a27e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b07252f-4d23-4c5e-ad8c-2a6cc81a27e3">
											<gml:posList>35.67194218811812 139.7402014955498 26.858 35.67195431548345 139.74018323268334 26.858 35.67195431548345 139.74018323268334 26.709 35.67194218811812 139.7402014955498 26.709 35.67194218811812 139.7402014955498 26.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1fc8132-06d4-4701-b6ac-8f4f723c3781">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1fc8132-06d4-4701-b6ac-8f4f723c3781">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1fc8132-06d4-4701-b6ac-8f4f723c3781">
											<gml:posList>35.67194267929316 139.7402072280996 22.885 35.671959002165075 139.7401826417748 22.885 35.671959002165075 139.7401826417748 26.858 35.67194267929316 139.7402072280996 26.858 35.67194267929316 139.7402072280996 22.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1798</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">260.66847</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>