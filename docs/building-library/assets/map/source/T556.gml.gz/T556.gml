<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a28a1041-2080-4df7-8a94-6b50487f4722">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">17.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67484248038625 139.7376603057309 0 35.674885224725415 139.73779811977838 0 35.67491685129515 139.73778350020032 0 35.67492199831694 139.73779509329464 0 35.67506129432105 139.7377243375657 0 35.675015930386564 139.73757956683838 0 35.67484248038625 139.7376603057309 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67484248038625 139.7376603057309 8.38 35.675015930386564 139.73757956683838 8.38 35.67506129432105 139.7377243375657 8.38 35.67492199831694 139.73779509329464 8.38 35.67491685129515 139.73778350020032 8.38 35.674885224725415 139.73779811977838 8.38 35.67484248038625 139.7376603057309 8.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67484248038625 139.7376603057309 8.38 35.674885224725415 139.73779811977838 8.38 35.674885224725415 139.73779811977838 25.89 35.67484248038625 139.7376603057309 25.89 35.67484248038625 139.7376603057309 8.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674885224725415 139.73779811977838 8.38 35.67491685129515 139.73778350020032 8.38 35.67491685129515 139.73778350020032 25.89 35.674885224725415 139.73779811977838 25.89 35.674885224725415 139.73779811977838 8.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67491685129515 139.73778350020032 8.38 35.67492199831694 139.73779509329464 8.38 35.67492199831694 139.73779509329464 25.89 35.67491685129515 139.73778350020032 25.89 35.67491685129515 139.73778350020032 8.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67492199831694 139.73779509329464 8.38 35.67506129432105 139.7377243375657 8.38 35.67506129432105 139.7377243375657 25.89 35.67492199831694 139.73779509329464 25.89 35.67492199831694 139.73779509329464 8.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67506129432105 139.7377243375657 8.38 35.675015930386564 139.73757956683838 8.38 35.675015930386564 139.73757956683838 25.89 35.67506129432105 139.7377243375657 25.89 35.67506129432105 139.7377243375657 8.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.675015930386564 139.73757956683838 8.38 35.67484248038625 139.7376603057309 8.38 35.67484248038625 139.7376603057309 25.89 35.675015930386564 139.73757956683838 25.89 35.675015930386564 139.73757956683838 8.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67484248038625 139.7376603057309 25.89 35.674885224725415 139.73779811977838 25.89 35.67491685129515 139.73778350020032 25.89 35.67492199831694 139.73779509329464 25.89 35.67506129432105 139.7377243375657 25.89 35.675015930386564 139.73757956683838 25.89 35.67484248038625 139.7376603057309 25.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3e432145-40c8-4589-a767-82c689668d4e"/>
							<gml:surfaceMember xlink:href="#poly-39343663-2ae5-4d1c-a1de-2cca12049825"/>
							<gml:surfaceMember xlink:href="#poly-cb266186-a66e-460c-8f67-712235a4175f"/>
							<gml:surfaceMember xlink:href="#poly-66da6fa8-a398-444b-95da-65724f6d8eea"/>
							<gml:surfaceMember xlink:href="#poly-8a6e646b-c12f-438c-8e41-3d42d0b0931f"/>
							<gml:surfaceMember xlink:href="#poly-328a7e04-66f8-4a54-a1ac-ea9466f286d9"/>
							<gml:surfaceMember xlink:href="#poly-21100c58-a9c9-4655-a067-56d42c456830"/>
							<gml:surfaceMember xlink:href="#poly-ef747257-a38d-43f1-92d5-98065df72bfb"/>
							<gml:surfaceMember xlink:href="#poly-4302c28a-9351-423f-a908-02c6560c7a86"/>
							<gml:surfaceMember xlink:href="#poly-6d3768e5-33d3-45cc-9bd5-23d8345f00c3"/>
							<gml:surfaceMember xlink:href="#poly-3d6e8ac3-87aa-4762-8823-28f3e00a0aec"/>
							<gml:surfaceMember xlink:href="#poly-9c5c3d23-c15b-44f0-83ee-72cd3783c4f9"/>
							<gml:surfaceMember xlink:href="#poly-ddd7e4bd-999a-4dae-bd71-662b2d13629d"/>
							<gml:surfaceMember xlink:href="#poly-cf9358e7-9a78-4d6c-8775-083a211dd6af"/>
							<gml:surfaceMember xlink:href="#poly-8e4ca016-d37a-4a7e-97a0-803e04579a81"/>
							<gml:surfaceMember xlink:href="#poly-857d7764-b1d4-4010-bbe9-ea3e6193720c"/>
							<gml:surfaceMember xlink:href="#poly-1cffc870-c296-40b3-87ff-ede87b804b31"/>
							<gml:surfaceMember xlink:href="#poly-3c349a95-d48b-4b41-82a8-1862701081bd"/>
							<gml:surfaceMember xlink:href="#poly-b3761767-09ed-4a0f-b2ab-9291f2693e80"/>
							<gml:surfaceMember xlink:href="#poly-3d560d03-d2c8-4bdd-8043-1dcfd9183cdb"/>
							<gml:surfaceMember xlink:href="#poly-34a9d5e6-bc41-4c3c-9fcd-49705812a591"/>
							<gml:surfaceMember xlink:href="#poly-9ecb548d-1d58-4a0a-831c-418df75c30a2"/>
							<gml:surfaceMember xlink:href="#poly-3870587c-6675-42e8-b2af-498625adeca7"/>
							<gml:surfaceMember xlink:href="#poly-dfe62521-7fae-43ec-9249-f0c72be69017"/>
							<gml:surfaceMember xlink:href="#poly-59df7820-3673-47c1-9dcb-77816f2173e3"/>
							<gml:surfaceMember xlink:href="#poly-e50ce24d-9471-4569-b0d8-9b9626ba0342"/>
							<gml:surfaceMember xlink:href="#poly-fd33621c-48f5-4f57-b45c-c4e11530f49c"/>
							<gml:surfaceMember xlink:href="#poly-9810028f-ac2b-4d35-acbc-8cb3b8aae684"/>
							<gml:surfaceMember xlink:href="#poly-a512fc24-822a-4751-8caf-f25ceb453ea2"/>
							<gml:surfaceMember xlink:href="#poly-a2102016-c23a-4ab0-b3c8-f5bca2e68e28"/>
							<gml:surfaceMember xlink:href="#poly-bf6e0ccf-16a1-42fe-b940-f3265b503da4"/>
							<gml:surfaceMember xlink:href="#poly-a9b830ea-875e-4c47-bfdd-856358de714c"/>
							<gml:surfaceMember xlink:href="#poly-1653c73d-4217-422a-8575-eb363ae40b14"/>
							<gml:surfaceMember xlink:href="#poly-fd35ce36-bf59-40a1-b9fa-4f64d31c9cfa"/>
							<gml:surfaceMember xlink:href="#poly-5e06c56c-ef60-475f-995e-af09f87b8963"/>
							<gml:surfaceMember xlink:href="#poly-95ea865b-83a5-4eff-a9b7-7f8871a650f0"/>
							<gml:surfaceMember xlink:href="#poly-63f45d55-7044-49b1-bb3e-58b428dc358a"/>
							<gml:surfaceMember xlink:href="#poly-3d1b24e8-db5b-490b-afb4-ea25c2830ad4"/>
							<gml:surfaceMember xlink:href="#poly-029faf08-a947-4033-889f-09fbb7204dc6"/>
							<gml:surfaceMember xlink:href="#poly-3e2f2610-ea3d-42b3-b45f-c341e60978ac"/>
							<gml:surfaceMember xlink:href="#poly-ce0d137f-758b-4f78-b503-5ce981dd6cb3"/>
							<gml:surfaceMember xlink:href="#poly-e90aa834-46ab-40ac-a85e-bfc154672aba"/>
							<gml:surfaceMember xlink:href="#poly-9b2474ba-1f2d-4dd9-8eb9-21fa6d038642"/>
							<gml:surfaceMember xlink:href="#poly-be62b3e6-f7f8-40f4-834f-b487c036c14f"/>
							<gml:surfaceMember xlink:href="#poly-3bf69edf-d57b-4f16-9ddf-aa5dbb0812be"/>
							<gml:surfaceMember xlink:href="#poly-617b0c68-d7c2-4be2-a875-26833f84ea21"/>
							<gml:surfaceMember xlink:href="#poly-7999be9c-da7e-4a39-ab97-075af65178c4"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a28a1041-2080-4df7-8a94-6b50487f4722_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1067ee6e-a190-406e-a1be-e03b701210e6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67486298322855 139.73771278706715 31.051 35.67488630212573 139.73770193330972 31.051 35.67489954112177 139.7377446137148 31.051 35.67487622222076 139.7377554674616 31.051 35.67486298322855 139.73771278706715 31.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d24a10f-e823-42ac-85ef-22a3b6f6ad54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674924259349744 139.73766843806018 26.606 35.6749237623403 139.73766685894873 26.606 35.67494164783257 139.73765836464162 26.606 35.674942190024794 139.737660087309 26.606 35.674924259349744 139.73766843806018 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dfba93b-8093-4a58-9923-64cb3326e585">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674926274481095 139.73767482075527 26.229 35.674924259349744 139.73766843806018 26.229 35.674942190024794 139.737660087309 26.229 35.67494416899641 139.73766633748576 26.229 35.674926274481095 139.73767482075527 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9e84fe1-52f4-45c6-b712-cea9cfc46af1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67494431648034 139.7376591015981 26.229 35.67494628642074 139.73766532969205 26.229 35.67494628642074 139.73766532969205 28.39 35.6749437652656 139.73765736789457 28.39 35.6749437652656 139.73765736789457 26.606 35.67494431648034 139.7376591015981 26.606 35.67494431648034 139.7376591015981 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-057a57ce-ebfa-4fd8-a503-2c72fba75978">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67496158768746 139.73764890679917 26.606 35.67496218407625 139.7376507730118 26.606 35.67494431648034 139.7376591015981 26.606 35.6749437652656 139.73765736789457 26.606 35.67496158768746 139.73764890679917 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b9e20ce-72d9-4a27-9b51-f45085361e91">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67496218407625 139.7376507730118 26.229 35.674964108843156 139.73765686859815 26.229 35.67494628642074 139.73766532969205 26.229 35.67494431648034 139.7376591015981 26.229 35.67496218407625 139.7376507730118 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7efb5e6-9f80-4020-9a41-d139e7f07d3c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67495658620006 139.73768436223816 26.229 35.674963463247536 139.73770652514227 26.229 35.67495702081879 139.73770952653453 26.229 35.67495015278558 139.73768736362115 26.229 35.67495658620006 139.73768436223816 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ab6c862-0a22-4840-bd4e-fc2ca4e9a6b1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674965301671676 139.73764932214797 26.606 35.67496470525653 139.73764742279465 26.606 35.67498198706543 139.73763922746556 26.606 35.674982619632125 139.73764124829196 26.606 35.674965301671676 139.73764932214797 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b0fbe92-fca8-428a-a693-8dd2d9d9b203">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674982619632125 139.73764124829196 26.229 35.67498449920804 139.73764718927706 26.229 35.67496722641232 139.73765538459386 26.229 35.674965301671676 139.73764932214797 26.229 35.674982619632125 139.73764124829196 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbb411cb-126d-4781-a2ae-e295316c52c3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67498449920804 139.73764718927706 26.229 35.674982619632125 139.73764124829196 26.229 35.674982619632125 139.73764124829196 26.606 35.67498198706543 139.73763922746556 26.606 35.67498198706543 139.73763922746556 28.39 35.67498449920804 139.73764718927706 28.39 35.67498449920804 139.73764718927706 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81683493-d9da-4adf-9225-e9bb43aadfc5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.675001521441985 139.737629946848 26.606 35.675002208214046 139.7376321222666 26.606 35.674985061444616 139.7376401075471 26.606 35.67498441083291 139.73763806464842 26.606 35.675001521441985 139.737629946848 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b91bf76-f4eb-4571-8afb-e66686596710">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.675002208214046 139.7376321222666 26.229 35.67500403359398 139.73763791970796 26.229 35.674986931998085 139.7376460374962 26.229 35.674985061444616 139.7376401075471 26.229 35.675002208214046 139.7376321222666 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70f81256-6338-4739-a6c5-5b8d2415864d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70f81256-6338-4739-a6c5-5b8d2415864d_0">
											<gml:posList>35.67494416899641 139.73766633748576 26.229 35.674942190024794 139.737660087309 26.229 35.674942190024794 139.737660087309 26.606 35.67494164783257 139.73765836464162 26.606 35.67494164783257 139.73765836464162 28.39 35.67494416899641 139.73766633748576 28.39 35.67494416899641 139.73766633748576 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1de941b-71d2-4654-8dd4-c3a51e41bf7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1de941b-71d2-4654-8dd4-c3a51e41bf7c_0">
											<gml:posList>35.674964108843156 139.73765686859815 26.229 35.67496218407625 139.7376507730118 26.229 35.67496218407625 139.7376507730118 26.606 35.67496158768746 139.73764890679917 26.606 35.67496158768746 139.73764890679917 28.39 35.674964108843156 139.73765686859815 28.39 35.674964108843156 139.73765686859815 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8110fffa-4b0f-4fb1-93f8-ef6db9298126">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8110fffa-4b0f-4fb1-93f8-ef6db9298126_0">
											<gml:posList>35.674965301671676 139.73764932214797 26.229 35.67496722641232 139.73765538459386 26.229 35.67496722641232 139.73765538459386 28.39 35.67496470525653 139.73764742279465 28.39 35.67496470525653 139.73764742279465 26.606 35.674965301671676 139.73764932214797 26.606 35.674965301671676 139.73764932214797 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c110e15-5481-4af5-a8cf-34507d23dc38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c110e15-5481-4af5-a8cf-34507d23dc38_0">
											<gml:posList>35.674985061444616 139.7376401075471 26.229 35.674986931998085 139.7376460374962 26.229 35.674986931998085 139.7376460374962 28.39 35.67498441083291 139.73763806464842 28.39 35.67498441083291 139.73763806464842 26.606 35.674985061444616 139.7376401075471 26.606 35.674985061444616 139.7376401075471 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9d7907b-a209-4402-8763-19a8b5e618b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9d7907b-a209-4402-8763-19a8b5e618b1_0">
											<gml:posList>35.67487622222076 139.7377554674616 33.026 35.67486298322855 139.73771278706715 33.026 35.67486298322855 139.73771278706715 31.051 35.67487622222076 139.7377554674616 31.051 35.67487622222076 139.7377554674616 33.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6c6afc2-5442-4245-84e3-a3250939f4a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6c6afc2-5442-4245-84e3-a3250939f4a4_0">
											<gml:posList>35.67488630212573 139.73770193330972 33.026 35.67488630212573 139.73770193330972 31.051 35.67486298322855 139.73771278706715 31.051 35.67486298322855 139.73771278706715 33.026 35.67488630212573 139.73770193330972 33.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-945f2964-226b-4d17-b4ee-b0a0afbca4a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-945f2964-226b-4d17-b4ee-b0a0afbca4a1_0">
											<gml:posList>35.67489954112177 139.7377446137148 33.026 35.67488630212573 139.73770193330972 33.026 35.67486298322855 139.73771278706715 33.026 35.67487622222076 139.7377554674616 33.026 35.67489954112177 139.7377446137148 33.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84b3b713-2fff-406a-a8d9-7cb00c7e8c04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84b3b713-2fff-406a-a8d9-7cb00c7e8c04_0">
											<gml:posList>35.67487622222076 139.7377554674616 33.026 35.67487622222076 139.7377554674616 31.051 35.67489954112177 139.7377446137148 31.051 35.67489954112177 139.7377446137148 33.026 35.67487622222076 139.7377554674616 33.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a336c736-29db-4617-ad7a-0ea0d3d40aa5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a336c736-29db-4617-ad7a-0ea0d3d40aa5_0">
											<gml:posList>35.67489954112177 139.7377446137148 33.026 35.67489954112177 139.7377446137148 31.051 35.67488630212573 139.73770193330972 31.051 35.67488630212573 139.73770193330972 33.026 35.67489954112177 139.7377446137148 33.026</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffea5d4d-4a4b-413c-922c-99462b07f1df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffea5d4d-4a4b-413c-922c-99462b07f1df_0">
											<gml:posList>35.674924259349744 139.73766843806018 26.229 35.674926274481095 139.73767482075527 26.229 35.674926274481095 139.73767482075527 28.39 35.6749237623403 139.73766685894873 28.39 35.6749237623403 139.73766685894873 26.606 35.674924259349744 139.73766843806018 26.606 35.674924259349744 139.73766843806018 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f7c28ff-bb98-48e8-b756-419e93ff2a80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f7c28ff-bb98-48e8-b756-419e93ff2a80_0">
											<gml:posList>35.6749237623403 139.73766685894873 28.39 35.67494164783257 139.73765836464162 28.39 35.67494164783257 139.73765836464162 26.606 35.6749237623403 139.73766685894873 26.606 35.6749237623403 139.73766685894873 28.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02472b0c-bb02-4a3d-a60f-2c9797673973">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02472b0c-bb02-4a3d-a60f-2c9797673973_0">
											<gml:posList>35.674942190024794 139.737660087309 26.229 35.674924259349744 139.73766843806018 26.229 35.674924259349744 139.73766843806018 26.606 35.674942190024794 139.737660087309 26.606 35.674942190024794 139.737660087309 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d399e54a-c5b4-470a-b3da-25f5a758ef72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d399e54a-c5b4-470a-b3da-25f5a758ef72_0">
											<gml:posList>35.674926274481095 139.73767482075527 28.39 35.67494416899641 139.73766633748576 28.39 35.67494164783257 139.73765836464162 28.39 35.6749237623403 139.73766685894873 28.39 35.674926274481095 139.73767482075527 28.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9bb6ed9-edcd-4ecf-bc6f-70f70b2e2841">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9bb6ed9-edcd-4ecf-bc6f-70f70b2e2841_0">
											<gml:posList>35.67494416899641 139.73766633748576 28.39 35.674926274481095 139.73767482075527 28.39 35.674926274481095 139.73767482075527 26.229 35.67494416899641 139.73766633748576 26.229 35.67494416899641 139.73766633748576 28.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00a41f03-6bc7-42d8-b037-abee8269d945">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00a41f03-6bc7-42d8-b037-abee8269d945_0">
											<gml:posList>35.67496158768746 139.73764890679917 28.39 35.67496158768746 139.73764890679917 26.606 35.6749437652656 139.73765736789457 26.606 35.6749437652656 139.73765736789457 28.39 35.67496158768746 139.73764890679917 28.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-314966bc-f369-4e07-8d02-7bfa0306d33c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-314966bc-f369-4e07-8d02-7bfa0306d33c_0">
											<gml:posList>35.67496218407625 139.7376507730118 26.229 35.67494431648034 139.7376591015981 26.229 35.67494431648034 139.7376591015981 26.606 35.67496218407625 139.7376507730118 26.606 35.67496218407625 139.7376507730118 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97df1dc0-2520-4879-bf78-1d0684b987df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97df1dc0-2520-4879-bf78-1d0684b987df_0">
											<gml:posList>35.67495015278558 139.73768736362115 28.165 35.67495658620006 139.73768436223816 28.165 35.67495658620006 139.73768436223816 26.229 35.67495015278558 139.73768736362115 26.229 35.67495015278558 139.73768736362115 28.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9ee4dd2-0e1a-4288-945b-ecd7acf9a690">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9ee4dd2-0e1a-4288-945b-ecd7acf9a690_0">
											<gml:posList>35.67495015278558 139.73768736362115 26.229 35.67495702081879 139.73770952653453 26.229 35.67495702081879 139.73770952653453 28.165 35.67495015278558 139.73768736362115 28.165 35.67495015278558 139.73768736362115 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f89ed254-4be6-442f-b8bc-a8652faf4cda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f89ed254-4be6-442f-b8bc-a8652faf4cda_0">
											<gml:posList>35.67494628642074 139.73766532969205 28.39 35.674964108843156 139.73765686859815 28.39 35.67496158768746 139.73764890679917 28.39 35.6749437652656 139.73765736789457 28.39 35.67494628642074 139.73766532969205 28.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c4ffccc-c51c-4d83-8b25-37057f3eb8eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c4ffccc-c51c-4d83-8b25-37057f3eb8eb_0">
											<gml:posList>35.67494628642074 139.73766532969205 28.39 35.67494628642074 139.73766532969205 26.229 35.674964108843156 139.73765686859815 26.229 35.674964108843156 139.73765686859815 28.39 35.67494628642074 139.73766532969205 28.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88cec60d-1cd5-4040-836a-719250ca4980">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88cec60d-1cd5-4040-836a-719250ca4980_0">
											<gml:posList>35.67495702081879 139.73770952653453 28.165 35.674963463247536 139.73770652514227 28.165 35.67495658620006 139.73768436223816 28.165 35.67495015278558 139.73768736362115 28.165 35.67495702081879 139.73770952653453 28.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cbcce8f-2ed4-459e-97c5-67f0672c7244">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0cbcce8f-2ed4-459e-97c5-67f0672c7244_0">
											<gml:posList>35.674963463247536 139.73770652514227 28.165 35.674963463247536 139.73770652514227 26.229 35.67495658620006 139.73768436223816 26.229 35.67495658620006 139.73768436223816 28.165 35.674963463247536 139.73770652514227 28.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-448d0df6-dd0d-4e20-965f-b681cb3cfea3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-448d0df6-dd0d-4e20-965f-b681cb3cfea3_0">
											<gml:posList>35.674963463247536 139.73770652514227 28.165 35.67495702081879 139.73770952653453 28.165 35.67495702081879 139.73770952653453 26.229 35.674963463247536 139.73770652514227 26.229 35.674963463247536 139.73770652514227 28.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04d39efc-72fe-4e73-aa35-148f39854c4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04d39efc-72fe-4e73-aa35-148f39854c4f_0">
											<gml:posList>35.67496470525653 139.73764742279465 28.39 35.67498198706543 139.73763922746556 28.39 35.67498198706543 139.73763922746556 26.606 35.67496470525653 139.73764742279465 26.606 35.67496470525653 139.73764742279465 28.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80c6a43b-6a7e-481a-bba6-f4c00e8b7d4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80c6a43b-6a7e-481a-bba6-f4c00e8b7d4d_0">
											<gml:posList>35.674982619632125 139.73764124829196 26.229 35.674965301671676 139.73764932214797 26.229 35.674965301671676 139.73764932214797 26.606 35.674982619632125 139.73764124829196 26.606 35.674982619632125 139.73764124829196 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78741012-aa59-4d3a-b386-7052f4815039">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78741012-aa59-4d3a-b386-7052f4815039_0">
											<gml:posList>35.67496722641232 139.73765538459386 28.39 35.67498449920804 139.73764718927706 28.39 35.67498198706543 139.73763922746556 28.39 35.67496470525653 139.73764742279465 28.39 35.67496722641232 139.73765538459386 28.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2652f434-a390-4ea2-98d8-666800b7e59c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2652f434-a390-4ea2-98d8-666800b7e59c_0">
											<gml:posList>35.67498449920804 139.73764718927706 28.39 35.67496722641232 139.73765538459386 28.39 35.67496722641232 139.73765538459386 26.229 35.67498449920804 139.73764718927706 26.229 35.67498449920804 139.73764718927706 28.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-753fa7f4-9399-40d7-af12-995df00b87ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-753fa7f4-9399-40d7-af12-995df00b87ac_0">
											<gml:posList>35.67498441083291 139.73763806464842 28.39 35.675001521441985 139.737629946848 28.39 35.675001521441985 139.737629946848 26.606 35.67498441083291 139.73763806464842 26.606 35.67498441083291 139.73763806464842 28.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c15227e-fb9a-43ef-ac25-995f3ffbfc7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c15227e-fb9a-43ef-ac25-995f3ffbfc7d_0">
											<gml:posList>35.675002208214046 139.7376321222666 26.229 35.674985061444616 139.7376401075471 26.229 35.674985061444616 139.7376401075471 26.606 35.675002208214046 139.7376321222666 26.606 35.675002208214046 139.7376321222666 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d6b6b2b-7186-4fd1-bd7e-6fc1a9de7410">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d6b6b2b-7186-4fd1-bd7e-6fc1a9de7410_0">
											<gml:posList>35.67498441083291 139.73763806464842 28.39 35.674986931998085 139.7376460374962 28.39 35.67500403359398 139.73763791970796 28.39 35.675001521441985 139.737629946848 28.39 35.67498441083291 139.73763806464842 28.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-444ecef0-011a-40ad-a2f8-6c1c87df0367">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-444ecef0-011a-40ad-a2f8-6c1c87df0367_0">
											<gml:posList>35.67500403359398 139.73763791970796 28.39 35.674986931998085 139.7376460374962 28.39 35.674986931998085 139.7376460374962 26.229 35.67500403359398 139.73763791970796 26.229 35.67500403359398 139.73763791970796 28.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eababe87-26f7-413a-afe5-122457e85d4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eababe87-26f7-413a-afe5-122457e85d4f_0">
											<gml:posList>35.67500403359398 139.73763791970796 26.229 35.675002208214046 139.7376321222666 26.229 35.675002208214046 139.7376321222666 26.606 35.675001521441985 139.737629946848 26.606 35.675001521441985 139.737629946848 28.39 35.67500403359398 139.73763791970796 28.39 35.67500403359398 139.73763791970796 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a28a1041-2080-4df7-8a94-6b50487f4722_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1563c103-f101-42ab-a362-0e0281bf8e7b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67490700652952 139.73771313224356 26.229 35.674943859025475 139.73769596560925 26.229 35.674952154864535 139.7377227112776 26.229 35.6749153023648 139.7377398779014 26.229 35.67490700652952 139.73771313224356 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73456202-0fed-4f47-a24a-35380450f236">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73456202-0fed-4f47-a24a-35380450f236_0">
											<gml:posList>35.6749153023648 139.7377398779014 26.229 35.6749153023648 139.7377398779014 29.348 35.67490700652952 139.73771313224356 29.348 35.67490700652952 139.73771313224356 26.229 35.6749153023648 139.7377398779014 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be8047cd-4965-4bf2-b6d5-d9b7917764c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be8047cd-4965-4bf2-b6d5-d9b7917764c3_0">
											<gml:posList>35.674943859025475 139.73769596560925 29.348 35.674943859025475 139.73769596560925 26.229 35.67490700652952 139.73771313224356 26.229 35.67490700652952 139.73771313224356 29.348 35.674943859025475 139.73769596560925 29.348</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db727845-f6b4-4818-88bb-57a5a58428f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db727845-f6b4-4818-88bb-57a5a58428f9_0">
											<gml:posList>35.67490700652952 139.73771313224356 29.348 35.6749153023648 139.7377398779014 29.348 35.674952154864535 139.7377227112776 29.348 35.674943859025475 139.73769596560925 29.348 35.67490700652952 139.73771313224356 29.348</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a547a20f-d2e7-445e-9238-08e31339ce4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a547a20f-d2e7-445e-9238-08e31339ce4c_0">
											<gml:posList>35.6749153023648 139.7377398779014 29.348 35.6749153023648 139.7377398779014 26.229 35.674952154864535 139.7377227112776 26.229 35.674952154864535 139.7377227112776 29.348 35.6749153023648 139.7377398779014 29.348</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da34a90c-8390-4c22-a294-84cb2995d235">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da34a90c-8390-4c22-a294-84cb2995d235_0">
											<gml:posList>35.674952154864535 139.7377227112776 29.348 35.674952154864535 139.7377227112776 26.229 35.674943859025475 139.73769596560925 26.229 35.674943859025475 139.73769596560925 29.348 35.674952154864535 139.7377227112776 29.348</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3e432145-40c8-4589-a767-82c689668d4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e432145-40c8-4589-a767-82c689668d4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e432145-40c8-4589-a767-82c689668d4e">
											<gml:posList>35.67501593038654 139.73757956683838 8.38 35.67506129432104 139.7377243375657 8.38 35.6749219983169 139.73779509329464 8.38 35.67491685129514 139.7377835002003 8.38 35.674885224725394 139.73779811977835 8.38 35.67484248038625 139.7376603057309 8.38 35.67501593038654 139.73757956683838 8.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-39343663-2ae5-4d1c-a1de-2cca12049825">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39343663-2ae5-4d1c-a1de-2cca12049825">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39343663-2ae5-4d1c-a1de-2cca12049825">
											<gml:posList>35.6750517787529 139.7376939699318 26.606 35.674885224725394 139.73779811977835 23.447 35.67491685129514 139.7377835002003 23.447 35.6750517787529 139.7376939699318 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb266186-a66e-460c-8f67-712235a4175f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb266186-a66e-460c-8f67-712235a4175f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb266186-a66e-460c-8f67-712235a4175f">
											<gml:posList>35.6750517787529 139.7376939699318 26.606 35.6749219983169 139.73779509329464 22.289 35.67506129432104 139.7377243375657 22.289 35.6750517787529 139.7376939699318 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66da6fa8-a398-444b-95da-65724f6d8eea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66da6fa8-a398-444b-95da-65724f6d8eea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66da6fa8-a398-444b-95da-65724f6d8eea">
											<gml:posList>35.67501593038654 139.73757956683838 22.289 35.67484248038625 139.7376603057309 22.289 35.674853017391 139.73769429543808 26.606 35.67502654845828 139.73761345708948 26.606 35.67501593038654 139.73757956683838 22.289</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a6e646b-c12f-438c-8e41-3d42d0b0931f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a6e646b-c12f-438c-8e41-3d42d0b0931f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a6e646b-c12f-438c-8e41-3d42d0b0931f">
											<gml:posList>35.67502654845828 139.73761345708948 26.606 35.675023319551066 139.7376222874172 26.606 35.675044546603345 139.73769001272237 26.606 35.6750517787529 139.7376939699318 26.606 35.67502654845828 139.73761345708948 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-328a7e04-66f8-4a54-a1ac-ea9466f286d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-328a7e04-66f8-4a54-a1ac-ea9466f286d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-328a7e04-66f8-4a54-a1ac-ea9466f286d9">
											<gml:posList>35.67502654845828 139.73761345708948 26.606 35.674853017391 139.73769429543808 26.606 35.67489167778781 139.73768362221537 26.606 35.675023319551066 139.7376222874172 26.606 35.67502654845828 139.73761345708948 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21100c58-a9c9-4655-a067-56d42c456830">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21100c58-a9c9-4655-a067-56d42c456830">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21100c58-a9c9-4655-a067-56d42c456830">
											<gml:posList>35.67488646083872 139.7376861360819 26.229 35.674890391886954 139.7376988242574 26.229 35.67489702353334 139.73769573426603 26.229 35.674910651112356 139.7377396625102 26.229 35.674904920503124 139.73774233164252 26.229 35.67490838162211 139.73775349591415 26.229 35.674913643755175 139.73775112560696 26.229 35.675044546603345 139.73769001272237 26.229 35.675023319551066 139.7376222874172 26.229 35.67489167778781 139.73768362221537 26.229 35.67488646083872 139.7376861360819 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef747257-a38d-43f1-92d5-98065df72bfb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef747257-a38d-43f1-92d5-98065df72bfb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef747257-a38d-43f1-92d5-98065df72bfb">
											<gml:posList>35.674853017391 139.73769429543808 26.606 35.674855032599964 139.73770077754992 26.606 35.67488646083872 139.7376861360819 26.606 35.67489167778781 139.73768362221537 26.606 35.674853017391 139.73769429543808 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4302c28a-9351-423f-a908-02c6560c7a86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4302c28a-9351-423f-a908-02c6560c7a86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4302c28a-9351-423f-a908-02c6560c7a86">
											<gml:posList>35.674890391886954 139.7376988242574 31.546 35.67488646083872 139.7376861360819 31.546 35.67488540853313 139.73768903161996 31.546 35.674889330567346 139.7377017198062 31.546 35.674890391886954 139.7376988242574 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d3768e5-33d3-45cc-9bd5-23d8345f00c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d3768e5-33d3-45cc-9bd5-23d8345f00c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d3768e5-33d3-45cc-9bd5-23d8345f00c3">
											<gml:posList>35.674855032599964 139.73770077754992 31.546 35.674857395228685 139.73770207826277 31.546 35.67488540853313 139.73768903161996 31.546 35.67488646083872 139.7376861360819 31.546 35.674855032599964 139.73770077754992 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d6e8ac3-87aa-4762-8823-28f3e00a0aec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d6e8ac3-87aa-4762-8823-28f3e00a0aec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d6e8ac3-87aa-4762-8823-28f3e00a0aec">
											<gml:posList>35.674890391886954 139.7376988242574 31.546 35.674889330567346 139.7377017198062 31.546 35.67489596221379 139.7376986298151 31.546 35.67489702353334 139.73769573426603 31.546 35.674890391886954 139.7376988242574 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c5c3d23-c15b-44f0-83ee-72cd3783c4f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c5c3d23-c15b-44f0-83ee-72cd3783c4f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c5c3d23-c15b-44f0-83ee-72cd3783c4f9">
											<gml:posList>35.67489702353334 139.73769573426603 31.546 35.67489596221379 139.7376986298151 31.546 35.67490829749778 139.73773836178464 31.546 35.674910651112356 139.7377396625102 31.546 35.67489702353334 139.73769573426603 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ddd7e4bd-999a-4dae-bd71-662b2d13629d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ddd7e4bd-999a-4dae-bd71-662b2d13629d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ddd7e4bd-999a-4dae-bd71-662b2d13629d">
											<gml:posList>35.67490256688857 139.73774103091696 31.051 35.67490829749778 139.73773836178464 31.051 35.67489596221379 139.7376986298151 31.051 35.674889330567346 139.7377017198062 31.051 35.67488540853313 139.73768903161996 31.051 35.674857395228685 139.73770207826277 31.051 35.67487710465317 139.7377656737255 31.051 35.67490601900274 139.73775220624583 31.051 35.67490256688857 139.73774103091696 31.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf9358e7-9a78-4d6c-8775-083a211dd6af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf9358e7-9a78-4d6c-8775-083a211dd6af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf9358e7-9a78-4d6c-8775-083a211dd6af">
											<gml:posList>35.6750517787529 139.7376939699318 26.606 35.675044546603345 139.73769001272237 26.606 35.674913643755175 139.73775112560696 26.606 35.674878076573115 139.73777506241393 26.606 35.6750517787529 139.7376939699318 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e4ca016-d37a-4a7e-97a0-803e04579a81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e4ca016-d37a-4a7e-97a0-803e04579a81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e4ca016-d37a-4a7e-97a0-803e04579a81">
											<gml:posList>35.67487605233689 139.73776855821535 31.546 35.67487710465317 139.7377656737255 31.546 35.674857395228685 139.73770207826277 31.546 35.674855032599964 139.73770077754992 31.546 35.67487605233689 139.73776855821535 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-857d7764-b1d4-4010-bbe9-ea3e6193720c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-857d7764-b1d4-4010-bbe9-ea3e6193720c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-857d7764-b1d4-4010-bbe9-ea3e6193720c">
											<gml:posList>35.674904920503124 139.73774233164252 31.546 35.674910651112356 139.7377396625102 31.546 35.67490829749778 139.73773836178464 31.546 35.67490256688857 139.73774103091696 31.546 35.674904920503124 139.73774233164252 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1cffc870-c296-40b3-87ff-ede87b804b31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cffc870-c296-40b3-87ff-ede87b804b31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cffc870-c296-40b3-87ff-ede87b804b31">
											<gml:posList>35.6750517787529 139.7376939699318 26.606 35.67491685129514 139.7377835002003 23.447 35.6749219983169 139.73779509329464 22.289 35.6750517787529 139.7376939699318 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3c349a95-d48b-4b41-82a8-1862701081bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c349a95-d48b-4b41-82a8-1862701081bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c349a95-d48b-4b41-82a8-1862701081bd">
											<gml:posList>35.6750517787529 139.7376939699318 26.606 35.674878076573115 139.73777506241393 26.606 35.674885224725394 139.73779811977835 23.447 35.6750517787529 139.7376939699318 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b3761767-09ed-4a0f-b2ab-9291f2693e80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3761767-09ed-4a0f-b2ab-9291f2693e80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3761767-09ed-4a0f-b2ab-9291f2693e80">
											<gml:posList>35.674904920503124 139.73774233164252 31.546 35.67490256688857 139.73774103091696 31.546 35.67490601900274 139.73775220624583 31.546 35.67490838162211 139.73775349591415 31.546 35.674904920503124 139.73774233164252 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d560d03-d2c8-4bdd-8043-1dcfd9183cdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d560d03-d2c8-4bdd-8043-1dcfd9183cdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d560d03-d2c8-4bdd-8043-1dcfd9183cdb">
											<gml:posList>35.67490838162211 139.73775349591415 31.546 35.67490601900274 139.73775220624583 31.546 35.67487710465317 139.7377656737255 31.546 35.67487605233689 139.73776855821535 31.546 35.67490838162211 139.73775349591415 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-34a9d5e6-bc41-4c3c-9fcd-49705812a591">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34a9d5e6-bc41-4c3c-9fcd-49705812a591">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34a9d5e6-bc41-4c3c-9fcd-49705812a591">
											<gml:posList>35.67490838162211 139.73775349591415 26.606 35.67487605233689 139.73776855821535 26.606 35.674878076573115 139.73777506241393 26.606 35.674913643755175 139.73775112560696 26.606 35.67490838162211 139.73775349591415 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ecb548d-1d58-4a0a-831c-418df75c30a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ecb548d-1d58-4a0a-831c-418df75c30a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ecb548d-1d58-4a0a-831c-418df75c30a2">
											<gml:posList>35.67488540853313 139.73768903161996 31.546 35.67488540853313 139.73768903161996 31.051 35.674889330567346 139.7377017198062 31.051 35.674889330567346 139.7377017198062 31.546 35.67488540853313 139.73768903161996 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3870587c-6675-42e8-b2af-498625adeca7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3870587c-6675-42e8-b2af-498625adeca7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3870587c-6675-42e8-b2af-498625adeca7">
											<gml:posList>35.67501593038654 139.73757956683838 8.38 35.67484248038625 139.7376603057309 8.38 35.67484248038625 139.7376603057309 22.289 35.67501593038654 139.73757956683838 22.289 35.67501593038654 139.73757956683838 8.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dfe62521-7fae-43ec-9249-f0c72be69017">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfe62521-7fae-43ec-9249-f0c72be69017">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfe62521-7fae-43ec-9249-f0c72be69017">
											<gml:posList>35.67489167778781 139.73768362221537 26.606 35.67489167778781 139.73768362221537 26.229 35.675023319551066 139.7376222874172 26.229 35.675023319551066 139.7376222874172 26.606 35.67489167778781 139.73768362221537 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59df7820-3673-47c1-9dcb-77816f2173e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59df7820-3673-47c1-9dcb-77816f2173e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59df7820-3673-47c1-9dcb-77816f2173e3">
											<gml:posList>35.67488646083872 139.7376861360819 26.606 35.67488646083872 139.7376861360819 26.229 35.67489167778781 139.73768362221537 26.229 35.67489167778781 139.73768362221537 26.606 35.67488646083872 139.7376861360819 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e50ce24d-9471-4569-b0d8-9b9626ba0342">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e50ce24d-9471-4569-b0d8-9b9626ba0342">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e50ce24d-9471-4569-b0d8-9b9626ba0342">
											<gml:posList>35.674890391886954 139.7376988242574 31.546 35.674890391886954 139.7376988242574 26.229 35.67488646083872 139.7376861360819 26.229 35.67488646083872 139.7376861360819 26.606 35.67488646083872 139.7376861360819 31.546 35.674890391886954 139.7376988242574 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd33621c-48f5-4f57-b45c-c4e11530f49c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd33621c-48f5-4f57-b45c-c4e11530f49c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd33621c-48f5-4f57-b45c-c4e11530f49c">
											<gml:posList>35.674855032599964 139.73770077754992 26.606 35.674855032599964 139.73770077754992 31.546 35.67488646083872 139.7376861360819 31.546 35.67488646083872 139.7376861360819 26.606 35.674855032599964 139.73770077754992 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9810028f-ac2b-4d35-acbc-8cb3b8aae684">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9810028f-ac2b-4d35-acbc-8cb3b8aae684">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9810028f-ac2b-4d35-acbc-8cb3b8aae684">
											<gml:posList>35.674857395228685 139.73770207826277 31.546 35.674857395228685 139.73770207826277 31.051 35.67488540853313 139.73768903161996 31.051 35.67488540853313 139.73768903161996 31.546 35.674857395228685 139.73770207826277 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a512fc24-822a-4751-8caf-f25ceb453ea2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a512fc24-822a-4751-8caf-f25ceb453ea2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a512fc24-822a-4751-8caf-f25ceb453ea2">
											<gml:posList>35.674890391886954 139.7376988242574 31.546 35.67489702353334 139.73769573426603 31.546 35.67489702353334 139.73769573426603 26.229 35.674890391886954 139.7376988242574 26.229 35.674890391886954 139.7376988242574 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2102016-c23a-4ab0-b3c8-f5bca2e68e28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2102016-c23a-4ab0-b3c8-f5bca2e68e28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2102016-c23a-4ab0-b3c8-f5bca2e68e28">
											<gml:posList>35.674889330567346 139.7377017198062 31.546 35.674889330567346 139.7377017198062 31.051 35.67489596221379 139.7376986298151 31.051 35.67489596221379 139.7376986298151 31.546 35.674889330567346 139.7377017198062 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf6e0ccf-16a1-42fe-b940-f3265b503da4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf6e0ccf-16a1-42fe-b940-f3265b503da4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf6e0ccf-16a1-42fe-b940-f3265b503da4">
											<gml:posList>35.67489702353334 139.73769573426603 31.546 35.674910651112356 139.7377396625102 31.546 35.674910651112356 139.7377396625102 26.229 35.67489702353334 139.73769573426603 26.229 35.67489702353334 139.73769573426603 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9b830ea-875e-4c47-bfdd-856358de714c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9b830ea-875e-4c47-bfdd-856358de714c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9b830ea-875e-4c47-bfdd-856358de714c">
											<gml:posList>35.67489596221379 139.7376986298151 31.546 35.67489596221379 139.7376986298151 31.051 35.67490829749778 139.73773836178464 31.051 35.67490829749778 139.73773836178464 31.546 35.67489596221379 139.7376986298151 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1653c73d-4217-422a-8575-eb363ae40b14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1653c73d-4217-422a-8575-eb363ae40b14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1653c73d-4217-422a-8575-eb363ae40b14">
											<gml:posList>35.675044546603345 139.73769001272237 26.606 35.675044546603345 139.73769001272237 26.229 35.674913643755175 139.73775112560696 26.229 35.674913643755175 139.73775112560696 26.606 35.675044546603345 139.73769001272237 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd35ce36-bf59-40a1-b9fa-4f64d31c9cfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd35ce36-bf59-40a1-b9fa-4f64d31c9cfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd35ce36-bf59-40a1-b9fa-4f64d31c9cfa">
											<gml:posList>35.67487605233689 139.73776855821535 26.606 35.67487605233689 139.73776855821535 31.546 35.674855032599964 139.73770077754992 31.546 35.674855032599964 139.73770077754992 26.606 35.674853017391 139.73769429543808 26.606 35.67484248038625 139.7376603057309 22.289 35.67484248038625 139.7376603057309 8.38 35.674885224725394 139.73779811977835 8.38 35.674885224725394 139.73779811977835 23.447 35.674878076573115 139.73777506241393 26.606 35.67487605233689 139.73776855821535 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e06c56c-ef60-475f-995e-af09f87b8963">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e06c56c-ef60-475f-995e-af09f87b8963">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e06c56c-ef60-475f-995e-af09f87b8963">
											<gml:posList>35.67487710465317 139.7377656737255 31.546 35.67487710465317 139.7377656737255 31.051 35.674857395228685 139.73770207826277 31.051 35.674857395228685 139.73770207826277 31.546 35.67487710465317 139.7377656737255 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95ea865b-83a5-4eff-a9b7-7f8871a650f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95ea865b-83a5-4eff-a9b7-7f8871a650f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95ea865b-83a5-4eff-a9b7-7f8871a650f0">
											<gml:posList>35.67490829749778 139.73773836178464 31.546 35.67490829749778 139.73773836178464 31.051 35.67490256688857 139.73774103091696 31.051 35.67490256688857 139.73774103091696 31.546 35.67490829749778 139.73773836178464 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63f45d55-7044-49b1-bb3e-58b428dc358a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63f45d55-7044-49b1-bb3e-58b428dc358a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63f45d55-7044-49b1-bb3e-58b428dc358a">
											<gml:posList>35.674904920503124 139.73774233164252 26.229 35.674910651112356 139.7377396625102 26.229 35.674910651112356 139.7377396625102 31.546 35.674904920503124 139.73774233164252 31.546 35.674904920503124 139.73774233164252 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d1b24e8-db5b-490b-afb4-ea25c2830ad4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d1b24e8-db5b-490b-afb4-ea25c2830ad4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d1b24e8-db5b-490b-afb4-ea25c2830ad4">
											<gml:posList>35.67490256688857 139.73774103091696 31.546 35.67490256688857 139.73774103091696 31.051 35.67490601900274 139.73775220624583 31.051 35.67490601900274 139.73775220624583 31.546 35.67490256688857 139.73774103091696 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-029faf08-a947-4033-889f-09fbb7204dc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-029faf08-a947-4033-889f-09fbb7204dc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-029faf08-a947-4033-889f-09fbb7204dc6">
											<gml:posList>35.674904920503124 139.73774233164252 26.229 35.674904920503124 139.73774233164252 31.546 35.67490838162211 139.73775349591415 31.546 35.67490838162211 139.73775349591415 26.606 35.67490838162211 139.73775349591415 26.229 35.674904920503124 139.73774233164252 26.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e2f2610-ea3d-42b3-b45f-c341e60978ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e2f2610-ea3d-42b3-b45f-c341e60978ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e2f2610-ea3d-42b3-b45f-c341e60978ac">
											<gml:posList>35.674913643755175 139.73775112560696 26.606 35.674913643755175 139.73775112560696 26.229 35.67490838162211 139.73775349591415 26.229 35.67490838162211 139.73775349591415 26.606 35.674913643755175 139.73775112560696 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce0d137f-758b-4f78-b503-5ce981dd6cb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce0d137f-758b-4f78-b503-5ce981dd6cb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce0d137f-758b-4f78-b503-5ce981dd6cb3">
											<gml:posList>35.67490601900274 139.73775220624583 31.546 35.67490601900274 139.73775220624583 31.051 35.67487710465317 139.7377656737255 31.051 35.67487710465317 139.7377656737255 31.546 35.67490601900274 139.73775220624583 31.546</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e90aa834-46ab-40ac-a85e-bfc154672aba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e90aa834-46ab-40ac-a85e-bfc154672aba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e90aa834-46ab-40ac-a85e-bfc154672aba">
											<gml:posList>35.6749219983169 139.73779509329464 8.38 35.67506129432104 139.7377243375657 8.38 35.67506129432104 139.7377243375657 22.289 35.6749219983169 139.73779509329464 22.289 35.6749219983169 139.73779509329464 8.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b2474ba-1f2d-4dd9-8eb9-21fa6d038642">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b2474ba-1f2d-4dd9-8eb9-21fa6d038642">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b2474ba-1f2d-4dd9-8eb9-21fa6d038642">
											<gml:posList>35.67490838162211 139.73775349591415 26.606 35.67490838162211 139.73775349591415 31.546 35.67487605233689 139.73776855821535 31.546 35.67487605233689 139.73776855821535 26.606 35.67490838162211 139.73775349591415 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be62b3e6-f7f8-40f4-834f-b487c036c14f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be62b3e6-f7f8-40f4-834f-b487c036c14f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be62b3e6-f7f8-40f4-834f-b487c036c14f">
											<gml:posList>35.67491685129514 139.7377835002003 8.38 35.6749219983169 139.73779509329464 8.38 35.6749219983169 139.73779509329464 22.289 35.67491685129514 139.7377835002003 23.447 35.67491685129514 139.7377835002003 8.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3bf69edf-d57b-4f16-9ddf-aa5dbb0812be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bf69edf-d57b-4f16-9ddf-aa5dbb0812be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bf69edf-d57b-4f16-9ddf-aa5dbb0812be">
											<gml:posList>35.674885224725394 139.73779811977835 8.38 35.67491685129514 139.7377835002003 8.38 35.67491685129514 139.7377835002003 23.447 35.674885224725394 139.73779811977835 23.447 35.674885224725394 139.73779811977835 8.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-617b0c68-d7c2-4be2-a875-26833f84ea21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-617b0c68-d7c2-4be2-a875-26833f84ea21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-617b0c68-d7c2-4be2-a875-26833f84ea21">
											<gml:posList>35.67506129432104 139.7377243375657 22.289 35.67506129432104 139.7377243375657 8.38 35.67501593038654 139.73757956683838 8.38 35.67501593038654 139.73757956683838 22.289 35.67502654845828 139.73761345708948 26.606 35.6750517787529 139.7376939699318 26.606 35.67506129432104 139.7377243375657 22.289</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7999be9c-da7e-4a39-ab97-075af65178c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7999be9c-da7e-4a39-ab97-075af65178c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7999be9c-da7e-4a39-ab97-075af65178c4">
											<gml:posList>35.675023319551066 139.7376222874172 26.606 35.675023319551066 139.7376222874172 26.229 35.675044546603345 139.73769001272237 26.229 35.675044546603345 139.73769001272237 26.606 35.675023319551066 139.7376222874172 26.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8596</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">290.8917</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.34</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>