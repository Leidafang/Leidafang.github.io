<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a2be89da-77c5-4adb-b0f4-0f2c9d05f453">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">24</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66927613402421 139.74745313655603 0 35.66934921197513 139.74754672936484 0 35.669407122131005 139.74747917557542 0 35.66933250935068 139.74738216011005 0 35.669297359130724 139.7473868371566 0 35.66927613402421 139.74745313655603 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927613402421 139.74745313655603 6.388 35.669297359130724 139.7473868371566 6.388 35.66933250935068 139.74738216011005 6.388 35.669407122131005 139.74747917557542 6.388 35.66934921197513 139.74754672936484 6.388 35.66927613402421 139.74745313655603 6.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927613402421 139.74745313655603 6.388 35.66934921197513 139.74754672936484 6.388 35.66934921197513 139.74754672936484 28.6 35.66927613402421 139.74745313655603 28.6 35.66927613402421 139.74745313655603 6.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66934921197513 139.74754672936484 6.388 35.669407122131005 139.74747917557542 6.388 35.669407122131005 139.74747917557542 28.6 35.66934921197513 139.74754672936484 28.6 35.66934921197513 139.74754672936484 6.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669407122131005 139.74747917557542 6.388 35.66933250935068 139.74738216011005 6.388 35.66933250935068 139.74738216011005 28.6 35.669407122131005 139.74747917557542 28.6 35.669407122131005 139.74747917557542 6.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66933250935068 139.74738216011005 6.388 35.669297359130724 139.7473868371566 6.388 35.669297359130724 139.7473868371566 28.6 35.66933250935068 139.74738216011005 28.6 35.66933250935068 139.74738216011005 6.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669297359130724 139.7473868371566 6.388 35.66927613402421 139.74745313655603 6.388 35.66927613402421 139.74745313655603 28.6 35.669297359130724 139.7473868371566 28.6 35.669297359130724 139.7473868371566 6.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927613402421 139.74745313655603 28.6 35.66934921197513 139.74754672936484 28.6 35.669407122131005 139.74747917557542 28.6 35.66933250935068 139.74738216011005 28.6 35.669297359130724 139.7473868371566 28.6 35.66927613402421 139.74745313655603 28.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6b0d8f22-1be3-448a-8881-6d9aaf1f75aa"/>
							<gml:surfaceMember xlink:href="#poly-810bc023-757f-41e8-b3e3-dea67298330c"/>
							<gml:surfaceMember xlink:href="#poly-a155f34f-b889-4bfe-be29-c92425096ab6"/>
							<gml:surfaceMember xlink:href="#poly-7aa923c7-9f5a-4f97-8e94-3a317a099054"/>
							<gml:surfaceMember xlink:href="#poly-47361c77-6f1b-45bc-93a1-7cfefd2cbcf4"/>
							<gml:surfaceMember xlink:href="#poly-2970b129-c39b-435b-b92a-b7e2cc452db8"/>
							<gml:surfaceMember xlink:href="#poly-b310ef20-5f20-4e6e-9caf-4e33066aaf27"/>
							<gml:surfaceMember xlink:href="#poly-def9e5e9-2fb2-4d22-b9dd-112f9a0fb1d7"/>
							<gml:surfaceMember xlink:href="#poly-3df7801b-ef27-436f-a631-ddaa20c341b1"/>
							<gml:surfaceMember xlink:href="#poly-e0bdb478-efb6-41ce-9bd5-1fc4648d2ec1"/>
							<gml:surfaceMember xlink:href="#poly-c98c88b9-4835-4b1b-bfaa-985ef92e9f8a"/>
							<gml:surfaceMember xlink:href="#poly-8ab9d6ad-5640-45cb-b61f-e4d0e0dc7087"/>
							<gml:surfaceMember xlink:href="#poly-6ff75c80-2f51-4104-b0eb-706d7f944bd0"/>
							<gml:surfaceMember xlink:href="#poly-83f74f07-4569-42dc-8702-43e507f409b3"/>
							<gml:surfaceMember xlink:href="#poly-93d48a10-5a9a-4115-9c96-a013daccab64"/>
							<gml:surfaceMember xlink:href="#poly-f8a8e412-a2df-4f40-99ef-3eb98f69b36c"/>
							<gml:surfaceMember xlink:href="#poly-a60c867a-010e-4caa-88b6-0641eac89115"/>
							<gml:surfaceMember xlink:href="#poly-66eb3445-159d-4a3e-b7d1-cb6b68ec23fe"/>
							<gml:surfaceMember xlink:href="#poly-29d503d7-5d4e-46d1-a169-595f75ec7963"/>
							<gml:surfaceMember xlink:href="#poly-420839a9-9463-4767-8fba-c3d9d5367266"/>
							<gml:surfaceMember xlink:href="#poly-8c80a6ce-27a6-4cbc-9e0a-b099da30095d"/>
							<gml:surfaceMember xlink:href="#poly-3225f46c-07a1-40c6-bf08-0c0c3793016c"/>
							<gml:surfaceMember xlink:href="#poly-83fad8ea-c9f6-4f0d-a64e-39ebaa6600e6"/>
							<gml:surfaceMember xlink:href="#poly-60c18979-e9b7-439c-a57e-c86854828e6b"/>
							<gml:surfaceMember xlink:href="#poly-1f71fd02-1fcc-462d-8f39-9a302c478771"/>
							<gml:surfaceMember xlink:href="#poly-cf2fdc88-ad88-466c-87bc-58f3b93cf25e"/>
							<gml:surfaceMember xlink:href="#poly-e28d989a-3809-4444-9d68-b7edb4a62fce"/>
							<gml:surfaceMember xlink:href="#poly-096c1176-e63d-40ed-a4a5-7544023ab86b"/>
							<gml:surfaceMember xlink:href="#poly-01e3f8a3-8d62-4cb6-a652-a093a6d2e586"/>
							<gml:surfaceMember xlink:href="#poly-1f02f6d2-4a20-4a89-a7a3-5eae98b43c5b"/>
							<gml:surfaceMember xlink:href="#poly-7d2fde56-036b-40f4-9ef8-18e8ce536f01"/>
							<gml:surfaceMember xlink:href="#poly-6ffedd94-86ab-4b91-b2b3-751b0f680676"/>
							<gml:surfaceMember xlink:href="#poly-1735cc78-aec4-4310-a449-bc11d3650282"/>
							<gml:surfaceMember xlink:href="#poly-84f03cd1-65cb-418d-82a7-b16c3654da81"/>
							<gml:surfaceMember xlink:href="#poly-e1cde5b5-4147-45fd-877e-5bd09c3d66be"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a2be89da-77c5-4adb-b0f4-0f2c9d05f453_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2b942c0-68a5-4967-9225-d614f64c62b6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66937040964604 139.74746716356768 28.295 35.669365095228606 139.74745969103552 28.295 35.66935517865467 139.74747027279201 28.295 35.66935012588754 139.74746315345664 28.295 35.669365356509644 139.74744688830225 28.295 35.669375732709234 139.7474614801606 28.295 35.66937040964604 139.74746716356768 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a8d0215-c709-4833-a1dc-f5033d00744e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a8d0215-c709-4833-a1dc-f5033d00744e_0">
											<gml:posList>35.669365356509644 139.74744688830225 28.295 35.669365356509644 139.74744688830225 29.975 35.669375732709234 139.7474614801606 29.975 35.669375732709234 139.7474614801606 28.295 35.669365356509644 139.74744688830225 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-321d23a9-31fe-4cf6-936c-c652b5ccea39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-321d23a9-31fe-4cf6-936c-c652b5ccea39_0">
											<gml:posList>35.66935012588754 139.74746315345664 28.295 35.66935012588754 139.74746315345664 29.975 35.669365356509644 139.74744688830225 29.975 35.669365356509644 139.74744688830225 28.295 35.66935012588754 139.74746315345664 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8475bf4d-06ae-432f-a685-4aafdfa06705">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8475bf4d-06ae-432f-a685-4aafdfa06705_0">
											<gml:posList>35.669365356509644 139.74744688830225 29.975 35.66935012588754 139.74746315345664 29.975 35.66935517865467 139.74747027279201 29.975 35.669365095228606 139.74745969103552 29.975 35.66937040964604 139.74746716356768 29.975 35.669375732709234 139.7474614801606 29.975 35.669365356509644 139.74744688830225 29.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53b3808b-12aa-46c7-aa9d-e2d5fed8c65d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53b3808b-12aa-46c7-aa9d-e2d5fed8c65d_0">
											<gml:posList>35.66937040964604 139.74746716356768 28.295 35.66937040964604 139.74746716356768 29.975 35.669365095228606 139.74745969103552 29.975 35.669365095228606 139.74745969103552 28.295 35.66937040964604 139.74746716356768 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d7f95ff-0749-48b4-8693-24c8c41b8632">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d7f95ff-0749-48b4-8693-24c8c41b8632_0">
											<gml:posList>35.669375732709234 139.7474614801606 28.295 35.669375732709234 139.7474614801606 29.975 35.66937040964604 139.74746716356768 29.975 35.66937040964604 139.74746716356768 28.295 35.669375732709234 139.7474614801606 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a4817e0-0ced-4818-8e7a-f772effeb6e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a4817e0-0ced-4818-8e7a-f772effeb6e7_0">
											<gml:posList>35.669365095228606 139.74745969103552 28.295 35.669365095228606 139.74745969103552 29.975 35.66935517865467 139.74747027279201 29.975 35.66935517865467 139.74747027279201 28.295 35.669365095228606 139.74745969103552 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ff231e3-e812-4875-8cdd-f64e254862ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ff231e3-e812-4875-8cdd-f64e254862ae_0">
											<gml:posList>35.66935517865467 139.74747027279201 29.975 35.66935012588754 139.74746315345664 29.975 35.66935012588754 139.74746315345664 28.295 35.66935517865467 139.74747027279201 28.295 35.66935517865467 139.74747027279201 29.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a2be89da-77c5-4adb-b0f4-0f2c9d05f453_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5efd09d-92ce-49f7-8741-843c3f78d054">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66938856759066 139.74747317530557 28.295 35.669373760279434 139.74748897606935 28.295 35.66936350137187 139.7474745387279 28.295 35.669378308681225 139.7474587379635 28.295 35.66938856759066 139.74747317530557 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c831508-e54d-4351-9cb0-bb0e3ea9b057">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669370521615406 139.74751043110385 35.599 35.66935864237479 139.7475242846066 35.599 35.66934673332188 139.7475089542941 35.599 35.66935861256076 139.74749510079113 35.599 35.669370521615406 139.74751043110385 35.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04c0e47f-49e8-4493-8ca8-a4101a6907f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04c0e47f-49e8-4493-8ca8-a4101a6907f4_0">
											<gml:posList>35.66938856759066 139.74747317530557 28.295 35.669378308681225 139.7474587379635 28.295 35.669378308681225 139.7474587379635 31.797 35.66938856759066 139.74747317530557 31.797 35.66938856759066 139.74747317530557 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce1d4998-a18c-4695-afa7-772b3e26bada">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce1d4998-a18c-4695-afa7-772b3e26bada_0">
											<gml:posList>35.66936350137187 139.7474745387279 28.295 35.66936350137187 139.7474745387279 31.797 35.669378308681225 139.7474587379635 31.797 35.669378308681225 139.7474587379635 28.295 35.66936350137187 139.7474745387279 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8c72f0a-c19d-41ef-b510-2c966556ff77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8c72f0a-c19d-41ef-b510-2c966556ff77_0">
											<gml:posList>35.66936350137187 139.7474745387279 31.797 35.669373760279434 139.74748897606935 31.797 35.66938856759066 139.74747317530557 31.797 35.669378308681225 139.7474587379635 31.797 35.66936350137187 139.7474745387279 31.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2cb545b4-1d60-485f-981e-2aa7a2e4122a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2cb545b4-1d60-485f-981e-2aa7a2e4122a_0">
											<gml:posList>35.669373760279434 139.74748897606935 28.295 35.66938856759066 139.74747317530557 28.295 35.66938856759066 139.74747317530557 31.797 35.669373760279434 139.74748897606935 31.797 35.669373760279434 139.74748897606935 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a4d6eed-7dd6-41ac-a8d4-c0b54c036a92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a4d6eed-7dd6-41ac-a8d4-c0b54c036a92_0">
											<gml:posList>35.66936350137187 139.7474745387279 28.295 35.669373760279434 139.74748897606935 28.295 35.669373760279434 139.74748897606935 31.797 35.66936350137187 139.7474745387279 31.797 35.66936350137187 139.7474745387279 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee4d788c-78c0-4db0-b9c8-ba1d907d88be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee4d788c-78c0-4db0-b9c8-ba1d907d88be_0">
											<gml:posList>35.66935861256076 139.74749510079113 35.599 35.66934673332188 139.7475089542941 35.599 35.66934673332188 139.7475089542941 36.824 35.66935861256076 139.74749510079113 36.824 35.66935861256076 139.74749510079113 35.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ce6ca19-243f-42f6-bbc4-0b3a7b6114df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ce6ca19-243f-42f6-bbc4-0b3a7b6114df_0">
											<gml:posList>35.669370521615406 139.74751043110385 35.599 35.66935861256076 139.74749510079113 35.599 35.66935861256076 139.74749510079113 36.824 35.669370521615406 139.74751043110385 36.824 35.669370521615406 139.74751043110385 35.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c8bc279-3b6b-42a3-b264-38ded5335b53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c8bc279-3b6b-42a3-b264-38ded5335b53_0">
											<gml:posList>35.66934673332188 139.7475089542941 36.824 35.66935864237479 139.7475242846066 36.824 35.669370521615406 139.74751043110385 36.824 35.66935861256076 139.74749510079113 36.824 35.66934673332188 139.7475089542941 36.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e64481d0-f1de-4978-ba0d-27d1a1fb7b84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e64481d0-f1de-4978-ba0d-27d1a1fb7b84_0">
											<gml:posList>35.66935864237479 139.7475242846066 35.599 35.66935864237479 139.7475242846066 36.824 35.66934673332188 139.7475089542941 36.824 35.66934673332188 139.7475089542941 35.599 35.66935864237479 139.7475242846066 35.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aec3a7df-5b0c-4bf5-b7ef-1985a0031b5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aec3a7df-5b0c-4bf5-b7ef-1985a0031b5e_0">
											<gml:posList>35.66935864237479 139.7475242846066 35.599 35.669370521615406 139.74751043110385 35.599 35.669370521615406 139.74751043110385 36.824 35.66935864237479 139.7475242846066 36.824 35.66935864237479 139.7475242846066 35.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6b0d8f22-1be3-448a-8881-6d9aaf1f75aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b0d8f22-1be3-448a-8881-6d9aaf1f75aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b0d8f22-1be3-448a-8881-6d9aaf1f75aa">
											<gml:posList>35.66927613402419 139.74745313655603 6.388 35.66929735913072 139.74738683715657 6.388 35.66933250935066 139.74738216011005 6.388 35.66940712213099 139.74747917557542 6.388 35.6693492119751 139.74754672936484 6.388 35.66927613402419 139.74745313655603 6.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-810bc023-757f-41e8-b3e3-dea67298330c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-810bc023-757f-41e8-b3e3-dea67298330c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-810bc023-757f-41e8-b3e3-dea67298330c">
											<gml:posList>35.66927613402419 139.74745313655603 28.8 35.66927986507653 139.7474522488711 28.8 35.669299633207174 139.7473905020279 28.8 35.66929735913072 139.74738683715657 28.8 35.66927613402419 139.74745313655603 28.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a155f34f-b889-4bfe-be29-c92425096ab6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a155f34f-b889-4bfe-be29-c92425096ab6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a155f34f-b889-4bfe-be29-c92425096ab6">
											<gml:posList>35.66927613402419 139.74745313655603 28.8 35.6693492119751 139.74754672936484 28.8 35.66934930717546 139.7475411841117 28.8 35.66927986507653 139.7474522488711 28.8 35.66927613402419 139.74745313655603 28.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7aa923c7-9f5a-4f97-8e94-3a317a099054">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7aa923c7-9f5a-4f97-8e94-3a317a099054">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7aa923c7-9f5a-4f97-8e94-3a317a099054">
											<gml:posList>35.66933250935066 139.74738216011005 28.8 35.66929735913072 139.74738683715657 28.8 35.669299633207174 139.7473905020279 28.8 35.669331268405266 139.74738629268754 28.8 35.66933250935066 139.74738216011005 28.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-47361c77-6f1b-45bc-93a1-7cfefd2cbcf4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47361c77-6f1b-45bc-93a1-7cfefd2cbcf4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47361c77-6f1b-45bc-93a1-7cfefd2cbcf4">
											<gml:posList>35.669331268405266 139.74738629268754 28.295 35.669299633207174 139.7473905020279 28.295 35.66927986507653 139.7474522488711 28.295 35.66934930717546 139.7475411841117 28.295 35.66935249539006 139.74753746920453 28.295 35.66935482801681 139.74753476040942 28.295 35.66933531340342 139.74750962928482 28.295 35.66935943212165 139.74748149109448 28.295 35.669378946732955 139.7475066111737 28.295 35.66938126133155 139.74750390239606 28.295 35.6694025881166 139.7474790257845 28.295 35.669331268405266 139.74738629268754 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2970b129-c39b-435b-b92a-b7e2cc452db8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2970b129-c39b-435b-b92a-b7e2cc452db8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2970b129-c39b-435b-b92a-b7e2cc452db8">
											<gml:posList>35.66935703841026 139.7475376079429 35.784 35.66935709961742 139.7475349568088 35.784 35.66933747674489 139.74750969324592 35.784 35.66933531340342 139.74750962928482 35.784 35.66935703841026 139.7475376079429 35.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b310ef20-5f20-4e6e-9caf-4e33066aaf27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b310ef20-5f20-4e6e-9caf-4e33066aaf27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b310ef20-5f20-4e6e-9caf-4e33066aaf27">
											<gml:posList>35.66933531340342 139.74750962928482 35.784 35.66933747674489 139.74750969324592 35.784 35.669359379937276 139.74748415326516 35.784 35.66935943212165 139.74748149109448 35.784 35.66933531340342 139.74750962928482 35.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-def9e5e9-2fb2-4d22-b9dd-112f9a0fb1d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-def9e5e9-2fb2-4d22-b9dd-112f9a0fb1d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-def9e5e9-2fb2-4d22-b9dd-112f9a0fb1d7">
											<gml:posList>35.66935703841026 139.7475376079429 28.8 35.66935249539006 139.74753746920453 28.8 35.66934930717546 139.7475411841117 28.8 35.6693492119751 139.74754672936484 28.8 35.66935703841026 139.7475376079429 28.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3df7801b-ef27-436f-a631-ddaa20c341b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3df7801b-ef27-436f-a631-ddaa20c341b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3df7801b-ef27-436f-a631-ddaa20c341b1">
											<gml:posList>35.66935249539006 139.74753746920453 28.8 35.66935703841026 139.7475376079429 28.8 35.66935482801681 139.74753476040942 28.8 35.66935249539006 139.74753746920453 28.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e0bdb478-efb6-41ce-9bd5-1fc4648d2ec1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0bdb478-efb6-41ce-9bd5-1fc4648d2ec1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0bdb478-efb6-41ce-9bd5-1fc4648d2ec1">
											<gml:posList>35.669378984779755 139.74750940580188 35.599 35.669359379937276 139.74748415326516 35.599 35.66933747674489 139.74750969324592 35.599 35.66935709961742 139.7475349568088 35.599 35.669378984779755 139.74750940580188 35.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c98c88b9-4835-4b1b-bfaa-985ef92e9f8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c98c88b9-4835-4b1b-bfaa-985ef92e9f8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c98c88b9-4835-4b1b-bfaa-985ef92e9f8a">
											<gml:posList>35.66938115712708 139.74750945870724 35.784 35.669378984779755 139.74750940580188 35.784 35.66935709961742 139.7475349568088 35.784 35.66935703841026 139.7475376079429 35.784 35.66938115712708 139.74750945870724 35.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8ab9d6ad-5640-45cb-b61f-e4d0e0dc7087">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ab9d6ad-5640-45cb-b61f-e4d0e0dc7087">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ab9d6ad-5640-45cb-b61f-e4d0e0dc7087">
											<gml:posList>35.66933250935066 139.74738216011005 28.8 35.669331268405266 139.74738629268754 28.8 35.6694025881166 139.7474790257845 28.8 35.66940712213099 139.74747917557542 28.8 35.66933250935066 139.74738216011005 28.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ff75c80-2f51-4104-b0eb-706d7f944bd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ff75c80-2f51-4104-b0eb-706d7f944bd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ff75c80-2f51-4104-b0eb-706d7f944bd0">
											<gml:posList>35.66935943212165 139.74748149109448 35.784 35.669359379937276 139.74748415326516 35.784 35.669378984779755 139.74750940580188 35.784 35.66938115712708 139.74750945870724 35.784 35.66935943212165 139.74748149109448 35.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-83f74f07-4569-42dc-8702-43e507f409b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83f74f07-4569-42dc-8702-43e507f409b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83f74f07-4569-42dc-8702-43e507f409b3">
											<gml:posList>35.669378946732955 139.7475066111737 28.8 35.66938115712708 139.74750945870724 28.8 35.66938126133155 139.74750390239606 28.8 35.669378946732955 139.7475066111737 28.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93d48a10-5a9a-4115-9c96-a013daccab64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93d48a10-5a9a-4115-9c96-a013daccab64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93d48a10-5a9a-4115-9c96-a013daccab64">
											<gml:posList>35.66940712213099 139.74747917557542 28.8 35.6694025881166 139.7474790257845 28.8 35.66938126133155 139.74750390239606 28.8 35.66938115712708 139.74750945870724 28.8 35.66940712213099 139.74747917557542 28.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8a8e412-a2df-4f40-99ef-3eb98f69b36c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8a8e412-a2df-4f40-99ef-3eb98f69b36c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8a8e412-a2df-4f40-99ef-3eb98f69b36c">
											<gml:posList>35.66934930717546 139.7475411841117 28.8 35.66934930717546 139.7475411841117 28.295 35.66927986507653 139.7474522488711 28.295 35.66927986507653 139.7474522488711 28.8 35.66934930717546 139.7475411841117 28.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a60c867a-010e-4caa-88b6-0641eac89115">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a60c867a-010e-4caa-88b6-0641eac89115">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a60c867a-010e-4caa-88b6-0641eac89115">
											<gml:posList>35.669359379937276 139.74748415326516 35.784 35.669359379937276 139.74748415326516 35.599 35.669378984779755 139.74750940580188 35.599 35.669378984779755 139.74750940580188 35.784 35.669359379937276 139.74748415326516 35.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66eb3445-159d-4a3e-b7d1-cb6b68ec23fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66eb3445-159d-4a3e-b7d1-cb6b68ec23fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66eb3445-159d-4a3e-b7d1-cb6b68ec23fe">
											<gml:posList>35.66933747674489 139.74750969324592 35.784 35.66933747674489 139.74750969324592 35.599 35.669359379937276 139.74748415326516 35.599 35.669359379937276 139.74748415326516 35.784 35.66933747674489 139.74750969324592 35.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29d503d7-5d4e-46d1-a169-595f75ec7963">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29d503d7-5d4e-46d1-a169-595f75ec7963">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29d503d7-5d4e-46d1-a169-595f75ec7963">
											<gml:posList>35.669378984779755 139.74750940580188 35.784 35.669378984779755 139.74750940580188 35.599 35.66935709961742 139.7475349568088 35.599 35.66935709961742 139.7475349568088 35.784 35.669378984779755 139.74750940580188 35.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-420839a9-9463-4767-8fba-c3d9d5367266">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-420839a9-9463-4767-8fba-c3d9d5367266">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-420839a9-9463-4767-8fba-c3d9d5367266">
											<gml:posList>35.66935709961742 139.7475349568088 35.784 35.66935709961742 139.7475349568088 35.599 35.66933747674489 139.74750969324592 35.599 35.66933747674489 139.74750969324592 35.784 35.66935709961742 139.7475349568088 35.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c80a6ce-27a6-4cbc-9e0a-b099da30095d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c80a6ce-27a6-4cbc-9e0a-b099da30095d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c80a6ce-27a6-4cbc-9e0a-b099da30095d">
											<gml:posList>35.66933250935066 139.74738216011005 6.388 35.66929735913072 139.74738683715657 6.388 35.66929735913072 139.74738683715657 28.8 35.66933250935066 139.74738216011005 28.8 35.66933250935066 139.74738216011005 6.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3225f46c-07a1-40c6-bf08-0c0c3793016c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3225f46c-07a1-40c6-bf08-0c0c3793016c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3225f46c-07a1-40c6-bf08-0c0c3793016c">
											<gml:posList>35.669299633207174 139.7473905020279 28.8 35.669299633207174 139.7473905020279 28.295 35.669331268405266 139.74738629268754 28.295 35.669331268405266 139.74738629268754 28.8 35.669299633207174 139.7473905020279 28.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83fad8ea-c9f6-4f0d-a64e-39ebaa6600e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83fad8ea-c9f6-4f0d-a64e-39ebaa6600e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83fad8ea-c9f6-4f0d-a64e-39ebaa6600e6">
											<gml:posList>35.66929735913072 139.74738683715657 6.388 35.66927613402419 139.74745313655603 6.388 35.66927613402419 139.74745313655603 28.8 35.66929735913072 139.74738683715657 28.8 35.66929735913072 139.74738683715657 6.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60c18979-e9b7-439c-a57e-c86854828e6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60c18979-e9b7-439c-a57e-c86854828e6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60c18979-e9b7-439c-a57e-c86854828e6b">
											<gml:posList>35.66927986507653 139.7474522488711 28.8 35.66927986507653 139.7474522488711 28.295 35.669299633207174 139.7473905020279 28.295 35.669299633207174 139.7473905020279 28.8 35.66927986507653 139.7474522488711 28.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f71fd02-1fcc-462d-8f39-9a302c478771">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f71fd02-1fcc-462d-8f39-9a302c478771">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f71fd02-1fcc-462d-8f39-9a302c478771">
											<gml:posList>35.66940712213099 139.74747917557542 6.388 35.66933250935066 139.74738216011005 6.388 35.66933250935066 139.74738216011005 28.8 35.66940712213099 139.74747917557542 28.8 35.66940712213099 139.74747917557542 6.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf2fdc88-ad88-466c-87bc-58f3b93cf25e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf2fdc88-ad88-466c-87bc-58f3b93cf25e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf2fdc88-ad88-466c-87bc-58f3b93cf25e">
											<gml:posList>35.669331268405266 139.74738629268754 28.8 35.669331268405266 139.74738629268754 28.295 35.6694025881166 139.7474790257845 28.295 35.6694025881166 139.7474790257845 28.8 35.669331268405266 139.74738629268754 28.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e28d989a-3809-4444-9d68-b7edb4a62fce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e28d989a-3809-4444-9d68-b7edb4a62fce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e28d989a-3809-4444-9d68-b7edb4a62fce">
											<gml:posList>35.6694025881166 139.7474790257845 28.8 35.6694025881166 139.7474790257845 28.295 35.66938126133155 139.74750390239606 28.295 35.66938126133155 139.74750390239606 28.8 35.6694025881166 139.7474790257845 28.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-096c1176-e63d-40ed-a4a5-7544023ab86b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-096c1176-e63d-40ed-a4a5-7544023ab86b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-096c1176-e63d-40ed-a4a5-7544023ab86b">
											<gml:posList>35.66935943212165 139.74748149109448 28.295 35.66935943212165 139.74748149109448 35.784 35.66938115712708 139.74750945870724 35.784 35.66938115712708 139.74750945870724 28.8 35.669378946732955 139.7475066111737 28.8 35.669378946732955 139.7475066111737 28.295 35.66935943212165 139.74748149109448 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01e3f8a3-8d62-4cb6-a652-a093a6d2e586">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01e3f8a3-8d62-4cb6-a652-a093a6d2e586">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01e3f8a3-8d62-4cb6-a652-a093a6d2e586">
											<gml:posList>35.66933531340342 139.74750962928482 35.784 35.66935943212165 139.74748149109448 35.784 35.66935943212165 139.74748149109448 28.295 35.66933531340342 139.74750962928482 28.295 35.66933531340342 139.74750962928482 35.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f02f6d2-4a20-4a89-a7a3-5eae98b43c5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f02f6d2-4a20-4a89-a7a3-5eae98b43c5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f02f6d2-4a20-4a89-a7a3-5eae98b43c5b">
											<gml:posList>35.66927613402419 139.74745313655603 6.388 35.6693492119751 139.74754672936484 6.388 35.6693492119751 139.74754672936484 28.8 35.66927613402419 139.74745313655603 28.8 35.66927613402419 139.74745313655603 6.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d2fde56-036b-40f4-9ef8-18e8ce536f01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d2fde56-036b-40f4-9ef8-18e8ce536f01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d2fde56-036b-40f4-9ef8-18e8ce536f01">
											<gml:posList>35.66938126133155 139.74750390239606 28.8 35.66938126133155 139.74750390239606 28.295 35.669378946732955 139.7475066111737 28.295 35.669378946732955 139.7475066111737 28.8 35.66938126133155 139.74750390239606 28.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ffedd94-86ab-4b91-b2b3-751b0f680676">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ffedd94-86ab-4b91-b2b3-751b0f680676">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ffedd94-86ab-4b91-b2b3-751b0f680676">
											<gml:posList>35.66938115712708 139.74750945870724 28.8 35.66938115712708 139.74750945870724 35.784 35.66935703841026 139.7475376079429 35.784 35.66935703841026 139.7475376079429 28.8 35.6693492119751 139.74754672936484 28.8 35.6693492119751 139.74754672936484 6.388 35.66940712213099 139.74747917557542 6.388 35.66940712213099 139.74747917557542 28.8 35.66938115712708 139.74750945870724 28.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1735cc78-aec4-4310-a449-bc11d3650282">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1735cc78-aec4-4310-a449-bc11d3650282">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1735cc78-aec4-4310-a449-bc11d3650282">
											<gml:posList>35.66935703841026 139.7475376079429 35.784 35.66933531340342 139.74750962928482 35.784 35.66933531340342 139.74750962928482 28.295 35.66935482801681 139.74753476040942 28.295 35.66935482801681 139.74753476040942 28.8 35.66935703841026 139.7475376079429 28.8 35.66935703841026 139.7475376079429 35.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84f03cd1-65cb-418d-82a7-b16c3654da81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84f03cd1-65cb-418d-82a7-b16c3654da81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84f03cd1-65cb-418d-82a7-b16c3654da81">
											<gml:posList>35.66935482801681 139.74753476040942 28.8 35.66935482801681 139.74753476040942 28.295 35.66935249539006 139.74753746920453 28.295 35.66935249539006 139.74753746920453 28.8 35.66935482801681 139.74753476040942 28.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1cde5b5-4147-45fd-877e-5bd09c3d66be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1cde5b5-4147-45fd-877e-5bd09c3d66be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1cde5b5-4147-45fd-877e-5bd09c3d66be">
											<gml:posList>35.66935249539006 139.74753746920453 28.8 35.66935249539006 139.74753746920453 28.295 35.66934930717546 139.7475411841117 28.295 35.66934930717546 139.7475411841117 28.8 35.66935249539006 139.74753746920453 28.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7797</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">117.2725</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>