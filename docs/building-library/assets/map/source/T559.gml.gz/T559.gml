<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a30ba5e5-84e8-4b82-864b-aac9e53f6267">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">15.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66890495940554 139.74810282133615 0 35.668920879056245 139.74805387037213 0 35.66884721140018 139.74801793860343 0 35.66883129176382 139.74806688952953 0 35.66890495940554 139.74810282133615 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890495940554 139.74810282133615 5.7 35.66883129176382 139.74806688952953 5.7 35.66884721140018 139.74801793860343 5.7 35.668920879056245 139.74805387037213 5.7 35.66890495940554 139.74810282133615 5.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890495940554 139.74810282133615 5.7 35.668920879056245 139.74805387037213 5.7 35.668920879056245 139.74805387037213 21.59 35.66890495940554 139.74810282133615 21.59 35.66890495940554 139.74810282133615 5.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668920879056245 139.74805387037213 5.7 35.66884721140018 139.74801793860343 5.7 35.66884721140018 139.74801793860343 21.59 35.668920879056245 139.74805387037213 21.59 35.668920879056245 139.74805387037213 5.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884721140018 139.74801793860343 5.7 35.66883129176382 139.74806688952953 5.7 35.66883129176382 139.74806688952953 21.59 35.66884721140018 139.74801793860343 21.59 35.66884721140018 139.74801793860343 5.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66883129176382 139.74806688952953 5.7 35.66890495940554 139.74810282133615 5.7 35.66890495940554 139.74810282133615 21.59 35.66883129176382 139.74806688952953 21.59 35.66883129176382 139.74806688952953 5.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890495940554 139.74810282133615 21.59 35.668920879056245 139.74805387037213 21.59 35.66884721140018 139.74801793860343 21.59 35.66883129176382 139.74806688952953 21.59 35.66890495940554 139.74810282133615 21.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b1f49e9e-ef01-4a66-8bf8-ba2d8009a5d8"/>
							<gml:surfaceMember xlink:href="#poly-cd44a1c0-7774-4182-907f-9b385baf671a"/>
							<gml:surfaceMember xlink:href="#poly-cd8b9edb-1823-4f1f-9516-7152106b33e3"/>
							<gml:surfaceMember xlink:href="#poly-73d2aaf6-229d-48ac-8bc2-2bd041baf1f1"/>
							<gml:surfaceMember xlink:href="#poly-2969f3ea-dbcf-440b-a9e5-a203091eeeaa"/>
							<gml:surfaceMember xlink:href="#poly-650b551f-18e5-46b1-aefb-803a2506a5c2"/>
							<gml:surfaceMember xlink:href="#poly-701c9178-fae7-4e75-aef8-caf9e4d2481f"/>
							<gml:surfaceMember xlink:href="#poly-7c6d508e-fd35-46dc-b1ea-e7089ebeffaa"/>
							<gml:surfaceMember xlink:href="#poly-7f70ed0c-f2bc-49f7-9fd0-62df42f0b4de"/>
							<gml:surfaceMember xlink:href="#poly-4d8f61c4-a011-421e-a59f-126f5bacb50d"/>
							<gml:surfaceMember xlink:href="#poly-cdd5b3fe-eb8e-400a-95f6-9bc90ad49f80"/>
							<gml:surfaceMember xlink:href="#poly-45a55e87-a325-440b-b782-c4894c9e7777"/>
							<gml:surfaceMember xlink:href="#poly-f5748b5d-544c-41a0-979c-315aebac54da"/>
							<gml:surfaceMember xlink:href="#poly-cbf0b10b-5669-40b2-ab74-8bd546d1740b"/>
							<gml:surfaceMember xlink:href="#poly-9e5b81da-9a1d-4c13-bbf7-0df1ac595ef2"/>
							<gml:surfaceMember xlink:href="#poly-42d1aa79-6a9d-4c69-91b1-330447752d4d"/>
							<gml:surfaceMember xlink:href="#poly-94cfbd99-36cf-4f20-85c2-f207b512d29f"/>
							<gml:surfaceMember xlink:href="#poly-277e81fe-fbf3-4666-b1e4-dc7e50a414a8"/>
							<gml:surfaceMember xlink:href="#poly-834c504d-9475-427f-8bf0-fcee91a57d57"/>
							<gml:surfaceMember xlink:href="#poly-5fd29f18-6486-466e-ad49-600e2c04eb9b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b1f49e9e-ef01-4a66-8bf8-ba2d8009a5d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1f49e9e-ef01-4a66-8bf8-ba2d8009a5d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1f49e9e-ef01-4a66-8bf8-ba2d8009a5d8">
											<gml:posList>35.66890495940552 139.74810282133612 5.7 35.6688312917638 139.74806688952953 5.7 35.668847211400134 139.74801793860343 5.7 35.66892087905623 139.74805387037213 5.7 35.66890495940552 139.74810282133612 5.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd44a1c0-7774-4182-907f-9b385baf671a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd44a1c0-7774-4182-907f-9b385baf671a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd44a1c0-7774-4182-907f-9b385baf671a">
											<gml:posList>35.6688312917638 139.74806688952953 26.3 35.66883273342822 139.74806613686525 26.3 35.668847834599475 139.74801970530817 26.3 35.668847211400134 139.74801793860343 26.3 35.6688312917638 139.74806688952953 26.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd8b9edb-1823-4f1f-9516-7152106b33e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd8b9edb-1823-4f1f-9516-7152106b33e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd8b9edb-1823-4f1f-9516-7152106b33e3">
											<gml:posList>35.668851002590905 139.74807650072398 26.3 35.66885038841395 139.7480747450552 26.3 35.66883273342822 139.74806613686525 26.3 35.6688312917638 139.74806688952953 26.3 35.668851002590905 139.74807650072398 26.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-73d2aaf6-229d-48ac-8bc2-2bd041baf1f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73d2aaf6-229d-48ac-8bc2-2bd041baf1f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73d2aaf6-229d-48ac-8bc2-2bd041baf1f1">
											<gml:posList>35.66886547155319 139.74802830246264 25.996 35.668847834599475 139.74801970530817 25.996 35.66883273342822 139.74806613686525 25.996 35.66885038841395 139.7480747450552 25.996 35.66886547155319 139.74802830246264 25.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2969f3ea-dbcf-440b-a9e5-a203091eeeaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2969f3ea-dbcf-440b-a9e5-a203091eeeaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2969f3ea-dbcf-440b-a9e5-a203091eeeaa">
											<gml:posList>35.668847211400134 139.74801793860343 26.3 35.668847834599475 139.74801970530817 26.3 35.66886547155319 139.74802830246264 26.3 35.66886690419581 139.7480275387609 26.3 35.668847211400134 139.74801793860343 26.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-650b551f-18e5-46b1-aefb-803a2506a5c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-650b551f-18e5-46b1-aefb-803a2506a5c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-650b551f-18e5-46b1-aefb-803a2506a5c2">
											<gml:posList>35.66886690419581 139.7480275387609 26.3 35.66886547155319 139.74802830246264 26.3 35.66885038841395 139.7480747450552 26.3 35.668851002590905 139.74807650072398 26.3 35.66886690419581 139.7480275387609 26.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-701c9178-fae7-4e75-aef8-caf9e4d2481f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-701c9178-fae7-4e75-aef8-caf9e4d2481f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-701c9178-fae7-4e75-aef8-caf9e4d2481f">
											<gml:posList>35.668903713454945 139.74809991754762 22.068 35.66891839185436 139.74805470147186 22.068 35.66886632856934 139.74802930674156 22.068 35.66885165919302 139.74807452278296 22.068 35.668903713454945 139.74809991754762 22.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c6d508e-fd35-46dc-b1ea-e7089ebeffaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c6d508e-fd35-46dc-b1ea-e7089ebeffaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c6d508e-fd35-46dc-b1ea-e7089ebeffaa">
											<gml:posList>35.66892087905623 139.74805387037213 22.3 35.66886690419581 139.7480275387609 22.3 35.66886632856934 139.74802930674156 22.3 35.66891839185436 139.74805470147186 22.3 35.668903713454945 139.74809991754762 22.3 35.66885165919302 139.74807452278296 22.3 35.668851002590905 139.74807650072398 22.3 35.66890495940552 139.74810282133612 22.3 35.66892087905623 139.74805387037213 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f70ed0c-f2bc-49f7-9fd0-62df42f0b4de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f70ed0c-f2bc-49f7-9fd0-62df42f0b4de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f70ed0c-f2bc-49f7-9fd0-62df42f0b4de">
											<gml:posList>35.66883273342822 139.74806613686525 26.3 35.66883273342822 139.74806613686525 25.996 35.668847834599475 139.74801970530817 25.996 35.668847834599475 139.74801970530817 26.3 35.66883273342822 139.74806613686525 26.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d8f61c4-a011-421e-a59f-126f5bacb50d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d8f61c4-a011-421e-a59f-126f5bacb50d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d8f61c4-a011-421e-a59f-126f5bacb50d">
											<gml:posList>35.66886547155319 139.74802830246264 26.3 35.66886547155319 139.74802830246264 25.996 35.66885038841395 139.7480747450552 25.996 35.66885038841395 139.7480747450552 26.3 35.66886547155319 139.74802830246264 26.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdd5b3fe-eb8e-400a-95f6-9bc90ad49f80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdd5b3fe-eb8e-400a-95f6-9bc90ad49f80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdd5b3fe-eb8e-400a-95f6-9bc90ad49f80">
											<gml:posList>35.668847834599475 139.74801970530817 26.3 35.668847834599475 139.74801970530817 25.996 35.66886547155319 139.74802830246264 25.996 35.66886547155319 139.74802830246264 26.3 35.668847834599475 139.74801970530817 26.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45a55e87-a325-440b-b782-c4894c9e7777">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45a55e87-a325-440b-b782-c4894c9e7777">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45a55e87-a325-440b-b782-c4894c9e7777">
											<gml:posList>35.668847211400134 139.74801793860343 5.7 35.668847211400134 139.74801793860343 26.3 35.66886690419581 139.7480275387609 26.3 35.66886690419581 139.7480275387609 22.3 35.66892087905623 139.74805387037213 22.3 35.66892087905623 139.74805387037213 5.7 35.668847211400134 139.74801793860343 5.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5748b5d-544c-41a0-979c-315aebac54da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5748b5d-544c-41a0-979c-315aebac54da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5748b5d-544c-41a0-979c-315aebac54da">
											<gml:posList>35.66886632856934 139.74802930674156 22.3 35.66886632856934 139.74802930674156 22.068 35.66891839185436 139.74805470147186 22.068 35.66891839185436 139.74805470147186 22.3 35.66886632856934 139.74802930674156 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbf0b10b-5669-40b2-ab74-8bd546d1740b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbf0b10b-5669-40b2-ab74-8bd546d1740b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbf0b10b-5669-40b2-ab74-8bd546d1740b">
											<gml:posList>35.668847211400134 139.74801793860343 5.7 35.6688312917638 139.74806688952953 5.7 35.6688312917638 139.74806688952953 26.3 35.668847211400134 139.74801793860343 26.3 35.668847211400134 139.74801793860343 5.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e5b81da-9a1d-4c13-bbf7-0df1ac595ef2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e5b81da-9a1d-4c13-bbf7-0df1ac595ef2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e5b81da-9a1d-4c13-bbf7-0df1ac595ef2">
											<gml:posList>35.66885165919302 139.74807452278296 22.3 35.66885165919302 139.74807452278296 22.068 35.66886632856934 139.74802930674156 22.068 35.66886632856934 139.74802930674156 22.3 35.66886690419581 139.7480275387609 22.3 35.66886690419581 139.7480275387609 26.3 35.668851002590905 139.74807650072398 26.3 35.668851002590905 139.74807650072398 22.3 35.66885165919302 139.74807452278296 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-42d1aa79-6a9d-4c69-91b1-330447752d4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42d1aa79-6a9d-4c69-91b1-330447752d4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42d1aa79-6a9d-4c69-91b1-330447752d4d">
											<gml:posList>35.66885038841395 139.7480747450552 26.3 35.66885038841395 139.7480747450552 25.996 35.66883273342822 139.74806613686525 25.996 35.66883273342822 139.74806613686525 26.3 35.66885038841395 139.7480747450552 26.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94cfbd99-36cf-4f20-85c2-f207b512d29f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94cfbd99-36cf-4f20-85c2-f207b512d29f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94cfbd99-36cf-4f20-85c2-f207b512d29f">
											<gml:posList>35.66891839185436 139.74805470147186 22.3 35.66891839185436 139.74805470147186 22.068 35.668903713454945 139.74809991754762 22.068 35.668903713454945 139.74809991754762 22.3 35.66891839185436 139.74805470147186 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-277e81fe-fbf3-4666-b1e4-dc7e50a414a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-277e81fe-fbf3-4666-b1e4-dc7e50a414a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-277e81fe-fbf3-4666-b1e4-dc7e50a414a8">
											<gml:posList>35.66890495940552 139.74810282133612 5.7 35.66892087905623 139.74805387037213 5.7 35.66892087905623 139.74805387037213 22.3 35.66890495940552 139.74810282133612 22.3 35.66890495940552 139.74810282133612 5.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-834c504d-9475-427f-8bf0-fcee91a57d57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-834c504d-9475-427f-8bf0-fcee91a57d57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-834c504d-9475-427f-8bf0-fcee91a57d57">
											<gml:posList>35.668851002590905 139.74807650072398 22.3 35.668851002590905 139.74807650072398 26.3 35.6688312917638 139.74806688952953 26.3 35.6688312917638 139.74806688952953 5.7 35.66890495940552 139.74810282133612 5.7 35.66890495940552 139.74810282133612 22.3 35.668851002590905 139.74807650072398 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5fd29f18-6486-466e-ad49-600e2c04eb9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fd29f18-6486-466e-ad49-600e2c04eb9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fd29f18-6486-466e-ad49-600e2c04eb9b">
											<gml:posList>35.668903713454945 139.74809991754762 22.3 35.668903713454945 139.74809991754762 22.068 35.66885165919302 139.74807452278296 22.068 35.66885165919302 139.74807452278296 22.3 35.668903713454945 139.74809991754762 22.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10901</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">38.16078</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>