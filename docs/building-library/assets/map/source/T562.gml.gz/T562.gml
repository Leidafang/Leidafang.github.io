<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a41b1cb2-3f53-40e9-984e-231c70aed0bb">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.9</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669744878635896 139.74850073953166 0 35.669798153321835 139.7484417959794 0 35.66974873781133 139.74837473175063 0 35.66969546315784 139.748433675311 0 35.669744878635896 139.74850073953166 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669744878635896 139.74850073953166 6.44 35.66969546315784 139.748433675311 6.44 35.66974873781133 139.74837473175063 6.44 35.669798153321835 139.7484417959794 6.44 35.669744878635896 139.74850073953166 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669744878635896 139.74850073953166 6.44 35.669798153321835 139.7484417959794 6.44 35.669798153321835 139.7484417959794 10.38 35.669744878635896 139.74850073953166 10.38 35.669744878635896 139.74850073953166 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669798153321835 139.7484417959794 6.44 35.66974873781133 139.74837473175063 6.44 35.66974873781133 139.74837473175063 10.38 35.669798153321835 139.7484417959794 10.38 35.669798153321835 139.7484417959794 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66974873781133 139.74837473175063 6.44 35.66969546315784 139.748433675311 6.44 35.66969546315784 139.748433675311 10.38 35.66974873781133 139.74837473175063 10.38 35.66974873781133 139.74837473175063 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66969546315784 139.748433675311 6.44 35.669744878635896 139.74850073953166 6.44 35.669744878635896 139.74850073953166 10.38 35.66969546315784 139.748433675311 10.38 35.66969546315784 139.748433675311 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669744878635896 139.74850073953166 10.38 35.669798153321835 139.7484417959794 10.38 35.66974873781133 139.74837473175063 10.38 35.66969546315784 139.748433675311 10.38 35.669744878635896 139.74850073953166 10.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c2e49cc6-151c-476d-a9f1-a7074f9839e3"/>
							<gml:surfaceMember xlink:href="#poly-4feda0d3-f1d5-4dc4-8698-248953e084cc"/>
							<gml:surfaceMember xlink:href="#poly-6ff322bd-d09a-4124-bfdb-937635dd57a0"/>
							<gml:surfaceMember xlink:href="#poly-d3130fed-01a1-4500-8970-e023c6e92962"/>
							<gml:surfaceMember xlink:href="#poly-bc0e28b4-35f9-4ab4-93d4-7f69a1b31a42"/>
							<gml:surfaceMember xlink:href="#poly-4b45df8d-729a-4b42-98d8-f8b3de380d57"/>
							<gml:surfaceMember xlink:href="#poly-5634fe8f-0c74-43f5-a168-e3eac4b7735f"/>
							<gml:surfaceMember xlink:href="#poly-80c01317-0c46-480a-9046-004543abe6fb"/>
							<gml:surfaceMember xlink:href="#poly-1b736a98-f2a8-4a4c-a054-13261b4bb514"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c2e49cc6-151c-476d-a9f1-a7074f9839e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2e49cc6-151c-476d-a9f1-a7074f9839e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2e49cc6-151c-476d-a9f1-a7074f9839e3">
											<gml:posList>35.6697448786359 139.74850073953166 6.44 35.66969546315782 139.74843367531096 6.44 35.66974873781133 139.7483747317506 6.44 35.669798153321814 139.74844179597937 6.44 35.6697448786359 139.74850073953166 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4feda0d3-f1d5-4dc4-8698-248953e084cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4feda0d3-f1d5-4dc4-8698-248953e084cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4feda0d3-f1d5-4dc4-8698-248953e084cc">
											<gml:posList>35.669723158779064 139.74840303704872 11.027 35.66969546315782 139.74843367531096 10.09 35.6697448786359 139.74850073953166 10.09 35.669723158779064 139.74840303704872 11.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ff322bd-d09a-4124-bfdb-937635dd57a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ff322bd-d09a-4124-bfdb-937635dd57a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ff322bd-d09a-4124-bfdb-937635dd57a0">
											<gml:posList>35.6697448786359 139.74850073953166 10.09 35.66977471786689 139.74846772407676 11.027 35.669723158779064 139.74840303704872 11.027 35.6697448786359 139.74850073953166 10.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3130fed-01a1-4500-8970-e023c6e92962">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3130fed-01a1-4500-8970-e023c6e92962">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3130fed-01a1-4500-8970-e023c6e92962">
											<gml:posList>35.66974873781133 139.7483747317506 10.09 35.669723158779064 139.74840303704872 11.027 35.66977471786689 139.74846772407676 11.027 35.66974873781133 139.7483747317506 10.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc0e28b4-35f9-4ab4-93d4-7f69a1b31a42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc0e28b4-35f9-4ab4-93d4-7f69a1b31a42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc0e28b4-35f9-4ab4-93d4-7f69a1b31a42">
											<gml:posList>35.66977471786689 139.74846772407676 11.027 35.669798153321814 139.74844179597937 10.09 35.66974873781133 139.7483747317506 10.09 35.66977471786689 139.74846772407676 11.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b45df8d-729a-4b42-98d8-f8b3de380d57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b45df8d-729a-4b42-98d8-f8b3de380d57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b45df8d-729a-4b42-98d8-f8b3de380d57">
											<gml:posList>35.669723158779064 139.74840303704872 11.027 35.66974873781133 139.7483747317506 10.09 35.66974873781133 139.7483747317506 6.44 35.66969546315782 139.74843367531096 6.44 35.66969546315782 139.74843367531096 10.09 35.669723158779064 139.74840303704872 11.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5634fe8f-0c74-43f5-a168-e3eac4b7735f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5634fe8f-0c74-43f5-a168-e3eac4b7735f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5634fe8f-0c74-43f5-a168-e3eac4b7735f">
											<gml:posList>35.669798153321814 139.74844179597937 6.44 35.66974873781133 139.7483747317506 6.44 35.66974873781133 139.7483747317506 10.09 35.669798153321814 139.74844179597937 10.09 35.669798153321814 139.74844179597937 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80c01317-0c46-480a-9046-004543abe6fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80c01317-0c46-480a-9046-004543abe6fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80c01317-0c46-480a-9046-004543abe6fb">
											<gml:posList>35.66969546315782 139.74843367531096 6.44 35.6697448786359 139.74850073953166 6.44 35.6697448786359 139.74850073953166 10.09 35.66969546315782 139.74843367531096 10.09 35.66969546315782 139.74843367531096 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b736a98-f2a8-4a4c-a054-13261b4bb514">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b736a98-f2a8-4a4c-a054-13261b4bb514">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b736a98-f2a8-4a4c-a054-13261b4bb514">
											<gml:posList>35.66977471786689 139.74846772407676 11.027 35.6697448786359 139.74850073953166 10.09 35.6697448786359 139.74850073953166 6.44 35.669798153321814 139.74844179597937 6.44 35.669798153321814 139.74844179597937 10.09 35.66977471786689 139.74846772407676 11.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11418</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>