<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a4fcafb1-3c86-4fa2-9945-c152e49f65d7">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">26.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670452607200176 139.7428149947594 0 35.67042458437699 139.74280415687096 0 35.67036679455639 139.74302851638748 0 35.67044979002365 139.74306062278362 0 35.67051210958494 139.7428186501781 0 35.67047761987342 139.74277845858808 0 35.670452607200176 139.7428149947594 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670452607200176 139.7428149947594 7.456 35.67047761987342 139.74277845858808 7.456 35.67051210958494 139.7428186501781 7.456 35.67044979002365 139.74306062278362 7.456 35.67036679455639 139.74302851638748 7.456 35.67042458437699 139.74280415687096 7.456 35.670452607200176 139.7428149947594 7.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670452607200176 139.7428149947594 7.456 35.67042458437699 139.74280415687096 7.456 35.67042458437699 139.74280415687096 33.69 35.670452607200176 139.7428149947594 33.69 35.670452607200176 139.7428149947594 7.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67042458437699 139.74280415687096 7.456 35.67036679455639 139.74302851638748 7.456 35.67036679455639 139.74302851638748 33.69 35.67042458437699 139.74280415687096 33.69 35.67042458437699 139.74280415687096 7.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67036679455639 139.74302851638748 7.456 35.67044979002365 139.74306062278362 7.456 35.67044979002365 139.74306062278362 33.69 35.67036679455639 139.74302851638748 33.69 35.67036679455639 139.74302851638748 7.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67044979002365 139.74306062278362 7.456 35.67051210958494 139.7428186501781 7.456 35.67051210958494 139.7428186501781 33.69 35.67044979002365 139.74306062278362 33.69 35.67044979002365 139.74306062278362 7.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67051210958494 139.7428186501781 7.456 35.67047761987342 139.74277845858808 7.456 35.67047761987342 139.74277845858808 33.69 35.67051210958494 139.7428186501781 33.69 35.67051210958494 139.7428186501781 7.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67047761987342 139.74277845858808 7.456 35.670452607200176 139.7428149947594 7.456 35.670452607200176 139.7428149947594 33.69 35.67047761987342 139.74277845858808 33.69 35.67047761987342 139.74277845858808 7.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670452607200176 139.7428149947594 33.69 35.67042458437699 139.74280415687096 33.69 35.67036679455639 139.74302851638748 33.69 35.67044979002365 139.74306062278362 33.69 35.67051210958494 139.7428186501781 33.69 35.67047761987342 139.74277845858808 33.69 35.670452607200176 139.7428149947594 33.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-51633cb0-9489-47aa-b1a3-c62defa3b889"/>
							<gml:surfaceMember xlink:href="#poly-dc9efae8-5948-4887-83f4-3bebbd7cc820"/>
							<gml:surfaceMember xlink:href="#poly-418f662d-783c-485e-8c8a-70475251c292"/>
							<gml:surfaceMember xlink:href="#poly-d674a944-3b3b-4df7-ab5e-f6ec1602777d"/>
							<gml:surfaceMember xlink:href="#poly-fdd771d3-55c9-49ad-939f-b75aae4ecabc"/>
							<gml:surfaceMember xlink:href="#poly-ba5f6b45-25d8-4bcf-a35e-f20418660bf8"/>
							<gml:surfaceMember xlink:href="#poly-d37aad15-c6e3-4475-bb0d-24990fd16ce0"/>
							<gml:surfaceMember xlink:href="#poly-31826f41-7790-4110-8177-efef2f3b4617"/>
							<gml:surfaceMember xlink:href="#poly-ad5194b9-df3c-477c-9d2f-73e3d675ed95"/>
							<gml:surfaceMember xlink:href="#poly-946479ff-386c-47d1-beb6-52f6a7beb66b"/>
							<gml:surfaceMember xlink:href="#poly-510bddb2-2f36-44e8-aecf-b310f728a791"/>
							<gml:surfaceMember xlink:href="#poly-74e4917c-4d39-4d81-976a-81a80699fcd1"/>
							<gml:surfaceMember xlink:href="#poly-f408a673-f8b1-48a0-ac1d-26e6d061a129"/>
							<gml:surfaceMember xlink:href="#poly-0fed92dc-c443-4361-834e-5817fe9a3726"/>
							<gml:surfaceMember xlink:href="#poly-86c24bed-9d80-4f8b-8dc7-6c79e3531c9f"/>
							<gml:surfaceMember xlink:href="#poly-3597f9c0-c0fc-48c1-8f63-dfa1624823b1"/>
							<gml:surfaceMember xlink:href="#poly-b6e29d05-4564-40d1-840f-99577518bae2"/>
							<gml:surfaceMember xlink:href="#poly-74105b5a-47c1-43ac-8213-f2290fa12615"/>
							<gml:surfaceMember xlink:href="#poly-754d88dc-485e-4fa8-982b-6272692d3172"/>
							<gml:surfaceMember xlink:href="#poly-ad73578c-fa6e-4956-abfc-47dcd06f6dfe"/>
							<gml:surfaceMember xlink:href="#poly-4e1dd7c9-24c6-421b-908f-6861f755f1ea"/>
							<gml:surfaceMember xlink:href="#poly-9d87d23c-c795-4e81-9755-baa7f4c3ebd3"/>
							<gml:surfaceMember xlink:href="#poly-7484fb16-0fc0-41dd-87c4-3aad98d8e08c"/>
							<gml:surfaceMember xlink:href="#poly-edaeda80-26c3-48f1-9d9a-bc04efbd619e"/>
							<gml:surfaceMember xlink:href="#poly-6e86c705-eb42-4465-83f4-7f912df44d31"/>
							<gml:surfaceMember xlink:href="#poly-e96e61d7-6a18-4fe6-9002-92f177efe99c"/>
							<gml:surfaceMember xlink:href="#poly-92611bfb-ce02-41da-b9a3-032a38208873"/>
							<gml:surfaceMember xlink:href="#poly-343144bc-70df-4c7f-b9f6-2e750be6d5b4"/>
							<gml:surfaceMember xlink:href="#poly-da43c787-0079-49d1-8f14-24b47b9ebfaf"/>
							<gml:surfaceMember xlink:href="#poly-e03fcb36-1a51-461f-a693-a4c3230c8a70"/>
							<gml:surfaceMember xlink:href="#poly-4d32b3d5-08b6-4f1a-a856-4359b54b8dd1"/>
							<gml:surfaceMember xlink:href="#poly-de06cc23-f846-49c2-b382-6df93abaf623"/>
							<gml:surfaceMember xlink:href="#poly-9c4bbfa2-0af7-4adf-965e-b0ce26d43b27"/>
							<gml:surfaceMember xlink:href="#poly-160be3c3-6465-4acf-8a0f-68c972482578"/>
							<gml:surfaceMember xlink:href="#poly-508796d8-dcc1-4358-add0-88ab36dcd094"/>
							<gml:surfaceMember xlink:href="#poly-7c3aa521-065a-4cf1-9dba-fa2d50685de5"/>
							<gml:surfaceMember xlink:href="#poly-c7bd949a-c9a0-41a2-bc16-496739fcf67b"/>
							<gml:surfaceMember xlink:href="#poly-8e208fc3-e276-4e75-9832-77cfe81a8a9f"/>
							<gml:surfaceMember xlink:href="#poly-af8f976a-6be7-4a2c-8016-2fd066f5e635"/>
							<gml:surfaceMember xlink:href="#poly-88705a39-9228-4524-b552-ab5e24205770"/>
							<gml:surfaceMember xlink:href="#poly-0b98dd3a-bcf2-4e09-be5a-9b9dcfe79d21"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a4fcafb1-3c86-4fa2-9945-c152e49f65d7_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69d9eaaf-adc9-4df1-bdb3-8a268f749cdb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67043596132415 139.7428782755254 34.154 35.67045347137642 139.74288544689242 34.154 35.67044903084297 139.74290175619507 34.154 35.67043151177793 139.74289458483506 34.154 35.67043596132415 139.7428782755254 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6a5c376-2481-45ee-824f-91cfe4f84c0f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67043022512946 139.74294568631558 34.154 35.670408207821026 139.7429379897985 34.154 35.670410615720016 139.7429276256882 34.154 35.67043264204283 139.74293532219252 34.154 35.67043022512946 139.74294568631558 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fded83c-b053-4604-b6b2-5144eb6e640f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67043022512946 139.74294568631558 34.154 35.67043022512946 139.74294568631558 35.864 35.670408207821026 139.7429379897985 35.864 35.670408207821026 139.7429379897985 34.154 35.67043022512946 139.74294568631558 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44f2eb57-ab85-4279-a6aa-d9c2f3fc68fa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670428992977335 139.7429493219263 34.154 35.670406641879424 139.74294125021166 34.154 35.670406641879424 139.74294125021166 35.864 35.670428992977335 139.7429493219263 35.864 35.670428992977335 139.7429493219263 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a69e5a3-7574-4b0c-8ef2-012efc39deb9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67040416182801 139.74295155917105 34.154 35.670406641879424 139.74294125021166 34.154 35.670428992977335 139.7429493219263 34.154 35.670426512925246 139.74295963088832 34.154 35.67040416182801 139.74295155917105 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31f63b59-c940-4418-abb6-0c915bb41511">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67043742319584 139.7429885266728 34.154 35.67044861882177 139.74294124707188 34.154 35.67046580358024 139.74294735837842 34.154 35.670454598938235 139.7429946379988 34.154 35.67043742319584 139.7429885266728 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ef5c511-cddf-4ec8-80ca-532c9b071273">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6703995694532 139.7429697354495 34.154 35.67042151491512 139.74297778553597 34.154 35.67041933129403 139.7429867354715 34.154 35.67039737681897 139.74297868539296 34.154 35.6703995694532 139.7429697354495 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55ffc642-425f-4535-81d7-89fff5be208d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67039635300095 139.7429836794571 34.154 35.67040692910699 139.74298767733282 34.154 35.67040468235593 139.74299658315255 34.154 35.67039410625019 139.74299258527577 34.154 35.67039635300095 139.7429836794571 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fea2f419-3683-4bf7-be16-ae72c91aa9c9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670386603074554 139.74301161539077 34.154 35.67040323767768 139.7430173075694 34.154 35.67040117131489 139.7430263678324 34.154 35.67038453671218 139.74302067565202 34.154 35.670386603074554 139.74301161539077 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76885091-22ec-4685-b77e-4a246c853cad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67042917760763 139.74302720894286 34.154 35.67043425662442 139.7430088885113 34.154 35.67044979213331 139.74301535516972 34.154 35.670444713123835 139.74303368665068 34.154 35.67042917760763 139.74302720894286 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a7ad0f1-af34-4abc-835c-b05c3e45d30f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a7ad0f1-af34-4abc-835c-b05c3e45d30f_0">
											<gml:posList>35.67039635300095 139.7429836794571 34.154 35.67039635300095 139.7429836794571 35.864 35.67040692910699 139.74298767733282 35.864 35.67040692910699 139.74298767733282 34.154 35.67039635300095 139.7429836794571 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6b4991c-180a-402d-a218-d80005a772ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6b4991c-180a-402d-a218-d80005a772ec_0">
											<gml:posList>35.67045347137642 139.74288544689242 34.154 35.67043596132415 139.7428782755254 34.154 35.67043596132415 139.7428782755254 36.349 35.67045347137642 139.74288544689242 36.349 35.67045347137642 139.74288544689242 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45580e05-1f5a-4f52-83af-32e83ca553e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45580e05-1f5a-4f52-83af-32e83ca553e8_0">
											<gml:posList>35.67043596132415 139.7428782755254 34.154 35.67043151177793 139.74289458483506 34.154 35.67043151177793 139.74289458483506 36.349 35.67043596132415 139.7428782755254 36.349 35.67043596132415 139.7428782755254 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1f341a4-5339-40a4-90a6-fe733f37faff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1f341a4-5339-40a4-90a6-fe733f37faff_0">
											<gml:posList>35.67044903084297 139.74290175619507 36.349 35.67045347137642 139.74288544689242 36.349 35.67043596132415 139.7428782755254 36.349 35.67043151177793 139.74289458483506 36.349 35.67044903084297 139.74290175619507 36.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81199bc9-e322-4589-a711-865ea0713789">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81199bc9-e322-4589-a711-865ea0713789_0">
											<gml:posList>35.67044903084297 139.74290175619507 34.154 35.67045347137642 139.74288544689242 34.154 35.67045347137642 139.74288544689242 36.349 35.67044903084297 139.74290175619507 36.349 35.67044903084297 139.74290175619507 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec202bf5-d14d-4caf-8594-e976a3d4b503">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec202bf5-d14d-4caf-8594-e976a3d4b503_0">
											<gml:posList>35.67043151177793 139.74289458483506 34.154 35.67044903084297 139.74290175619507 34.154 35.67044903084297 139.74290175619507 36.349 35.67043151177793 139.74289458483506 36.349 35.67043151177793 139.74289458483506 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4a8b02b-789d-4704-ac41-d105cd0996be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4a8b02b-789d-4704-ac41-d105cd0996be_0">
											<gml:posList>35.67043264204283 139.74293532219252 34.154 35.670410615720016 139.7429276256882 34.154 35.670410615720016 139.7429276256882 35.864 35.67043264204283 139.74293532219252 35.864 35.67043264204283 139.74293532219252 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63f335ba-b2fc-4e6c-bf10-7d9249844cb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63f335ba-b2fc-4e6c-bf10-7d9249844cb2_0">
											<gml:posList>35.670410615720016 139.7429276256882 34.154 35.670408207821026 139.7429379897985 34.154 35.670408207821026 139.7429379897985 35.864 35.670410615720016 139.7429276256882 35.864 35.670410615720016 139.7429276256882 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e26818a-ea28-4a07-866d-0297d8792db6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e26818a-ea28-4a07-866d-0297d8792db6_0">
											<gml:posList>35.670410615720016 139.7429276256882 35.864 35.670408207821026 139.7429379897985 35.864 35.67043022512946 139.74294568631558 35.864 35.67043264204283 139.74293532219252 35.864 35.670410615720016 139.7429276256882 35.864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8fcad54-1fb7-4a1a-b352-1dc652cedf49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8fcad54-1fb7-4a1a-b352-1dc652cedf49_0">
											<gml:posList>35.67043022512946 139.74294568631558 34.154 35.67043264204283 139.74293532219252 34.154 35.67043264204283 139.74293532219252 35.864 35.67043022512946 139.74294568631558 35.864 35.67043022512946 139.74294568631558 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9654a5d6-251a-414e-ab7c-c8bee82dbcb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9654a5d6-251a-414e-ab7c-c8bee82dbcb0_0">
											<gml:posList>35.67044861882177 139.74294124707188 34.154 35.67044861882177 139.74294124707188 36.349 35.67046580358024 139.74294735837842 36.349 35.67046580358024 139.74294735837842 34.154 35.67044861882177 139.74294124707188 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fea15207-06d5-4b63-a228-4bf4b9547ef7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fea15207-06d5-4b63-a228-4bf4b9547ef7_0">
											<gml:posList>35.670406641879424 139.74294125021166 34.154 35.67040416182801 139.74295155917105 34.154 35.67040416182801 139.74295155917105 35.864 35.670406641879424 139.74294125021166 35.864 35.670406641879424 139.74294125021166 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e15ef4d-1842-47da-b0a9-b0ae27228003">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e15ef4d-1842-47da-b0a9-b0ae27228003_0">
											<gml:posList>35.67040416182801 139.74295155917105 35.864 35.670426512925246 139.74295963088832 35.864 35.670428992977335 139.7429493219263 35.864 35.670406641879424 139.74294125021166 35.864 35.67040416182801 139.74295155917105 35.864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94c3af51-e8af-4c48-82f4-7d5027169a12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94c3af51-e8af-4c48-82f4-7d5027169a12_0">
											<gml:posList>35.670428992977335 139.7429493219263 34.154 35.670428992977335 139.7429493219263 35.864 35.670426512925246 139.74295963088832 35.864 35.670426512925246 139.74295963088832 34.154 35.670428992977335 139.7429493219263 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b21d2755-1dfb-45ea-b6c6-1f3581d7a957">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b21d2755-1dfb-45ea-b6c6-1f3581d7a957_0">
											<gml:posList>35.67040416182801 139.74295155917105 34.154 35.670426512925246 139.74295963088832 34.154 35.670426512925246 139.74295963088832 35.864 35.67040416182801 139.74295155917105 35.864 35.67040416182801 139.74295155917105 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5977b52d-8bab-4feb-8a90-8b10d24d81c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5977b52d-8bab-4feb-8a90-8b10d24d81c0_0">
											<gml:posList>35.67044861882177 139.74294124707188 34.154 35.67043742319584 139.7429885266728 34.154 35.67043742319584 139.7429885266728 36.349 35.67044861882177 139.74294124707188 36.349 35.67044861882177 139.74294124707188 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a222214-cdd0-490b-94f7-3212a1053a12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a222214-cdd0-490b-94f7-3212a1053a12_0">
											<gml:posList>35.67046580358024 139.74294735837842 36.349 35.67044861882177 139.74294124707188 36.349 35.67043742319584 139.7429885266728 36.349 35.670454598938235 139.7429946379988 36.349 35.67046580358024 139.74294735837842 36.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a95f586e-6f9a-44ca-9756-38d41575745a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a95f586e-6f9a-44ca-9756-38d41575745a_0">
											<gml:posList>35.670454598938235 139.7429946379988 34.154 35.67046580358024 139.74294735837842 34.154 35.67046580358024 139.74294735837842 36.349 35.670454598938235 139.7429946379988 36.349 35.670454598938235 139.7429946379988 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f2e3c15-446c-46dc-a586-b06857e174a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f2e3c15-446c-46dc-a586-b06857e174a4_0">
											<gml:posList>35.6703995694532 139.7429697354495 34.154 35.6703995694532 139.7429697354495 35.864 35.67042151491512 139.74297778553597 35.864 35.67042151491512 139.74297778553597 34.154 35.6703995694532 139.7429697354495 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f32db73-9fbe-43ac-aea2-6cc0861f0ecc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f32db73-9fbe-43ac-aea2-6cc0861f0ecc_0">
											<gml:posList>35.6703995694532 139.7429697354495 34.154 35.67039737681897 139.74297868539296 34.154 35.67039737681897 139.74297868539296 35.864 35.6703995694532 139.7429697354495 35.864 35.6703995694532 139.7429697354495 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca7e545b-969e-4e36-8e44-cf2ff82731ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca7e545b-969e-4e36-8e44-cf2ff82731ab_0">
											<gml:posList>35.67041933129403 139.7429867354715 35.864 35.67042151491512 139.74297778553597 35.864 35.6703995694532 139.7429697354495 35.864 35.67039737681897 139.74297868539296 35.864 35.67041933129403 139.7429867354715 35.864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-450ffa90-6149-4247-9cc2-42f6a9f2d443">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-450ffa90-6149-4247-9cc2-42f6a9f2d443_0">
											<gml:posList>35.67041933129403 139.7429867354715 34.154 35.67042151491512 139.74297778553597 34.154 35.67042151491512 139.74297778553597 35.864 35.67041933129403 139.7429867354715 35.864 35.67041933129403 139.7429867354715 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92472891-7cb6-4e29-b84b-45cdfbf1c7dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92472891-7cb6-4e29-b84b-45cdfbf1c7dd_0">
											<gml:posList>35.67039737681897 139.74297868539296 34.154 35.67041933129403 139.7429867354715 34.154 35.67041933129403 139.7429867354715 35.864 35.67039737681897 139.74297868539296 35.864 35.67039737681897 139.74297868539296 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7002007d-4af7-4189-92ab-6e1135adf230">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7002007d-4af7-4189-92ab-6e1135adf230_0">
											<gml:posList>35.67039635300095 139.7429836794571 34.154 35.67039410625019 139.74299258527577 34.154 35.67039410625019 139.74299258527577 35.864 35.67039635300095 139.7429836794571 35.864 35.67039635300095 139.7429836794571 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da569e32-f299-4d08-abd8-b74afc4d377e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da569e32-f299-4d08-abd8-b74afc4d377e_0">
											<gml:posList>35.67040468235593 139.74299658315255 35.864 35.67040692910699 139.74298767733282 35.864 35.67039635300095 139.7429836794571 35.864 35.67039410625019 139.74299258527577 35.864 35.67040468235593 139.74299658315255 35.864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0bd39942-d951-44a9-9b2a-77be586d6b7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0bd39942-d951-44a9-9b2a-77be586d6b7a_0">
											<gml:posList>35.67043742319584 139.7429885266728 34.154 35.670454598938235 139.7429946379988 34.154 35.670454598938235 139.7429946379988 36.349 35.67043742319584 139.7429885266728 36.349 35.67043742319584 139.7429885266728 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-157defe8-2f07-4895-ac1d-544340f98daa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-157defe8-2f07-4895-ac1d-544340f98daa_0">
											<gml:posList>35.67040468235593 139.74299658315255 34.154 35.67040692910699 139.74298767733282 34.154 35.67040692910699 139.74298767733282 35.864 35.67040468235593 139.74299658315255 35.864 35.67040468235593 139.74299658315255 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b50a6d60-9bfd-4f1e-8ef1-d395ccef58a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b50a6d60-9bfd-4f1e-8ef1-d395ccef58a8_0">
											<gml:posList>35.67039410625019 139.74299258527577 34.154 35.67040468235593 139.74299658315255 34.154 35.67040468235593 139.74299658315255 35.864 35.67039410625019 139.74299258527577 35.864 35.67039410625019 139.74299258527577 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea564e91-444b-43a0-a22c-b9581d501346">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea564e91-444b-43a0-a22c-b9581d501346_0">
											<gml:posList>35.67044979213331 139.74301535516972 34.154 35.67043425662442 139.7430088885113 34.154 35.67043425662442 139.7430088885113 36.349 35.67044979213331 139.74301535516972 36.349 35.67044979213331 139.74301535516972 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7586e14e-a4c0-41b6-8775-607d73290604">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7586e14e-a4c0-41b6-8775-607d73290604_0">
											<gml:posList>35.67040323767768 139.7430173075694 34.154 35.670386603074554 139.74301161539077 34.154 35.670386603074554 139.74301161539077 35.864 35.67040323767768 139.7430173075694 35.864 35.67040323767768 139.7430173075694 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64200300-70a7-4252-8d4f-813e855459db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64200300-70a7-4252-8d4f-813e855459db_0">
											<gml:posList>35.670386603074554 139.74301161539077 34.154 35.67038453671218 139.74302067565202 34.154 35.67038453671218 139.74302067565202 35.864 35.670386603074554 139.74301161539077 35.864 35.670386603074554 139.74301161539077 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-787fb56b-83b1-4461-a150-4ce61d8955b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-787fb56b-83b1-4461-a150-4ce61d8955b5_0">
											<gml:posList>35.67043425662442 139.7430088885113 34.154 35.67042917760763 139.74302720894286 34.154 35.67042917760763 139.74302720894286 36.349 35.67043425662442 139.7430088885113 36.349 35.67043425662442 139.7430088885113 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d071bc33-3731-4167-93a1-fdd3a11926b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d071bc33-3731-4167-93a1-fdd3a11926b8_0">
											<gml:posList>35.67040117131489 139.7430263678324 35.864 35.67040323767768 139.7430173075694 35.864 35.670386603074554 139.74301161539077 35.864 35.67038453671218 139.74302067565202 35.864 35.67040117131489 139.7430263678324 35.864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed2f2f2f-a90d-4fc6-b8ee-1b314c62f91f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed2f2f2f-a90d-4fc6-b8ee-1b314c62f91f_0">
											<gml:posList>35.67042917760763 139.74302720894286 36.349 35.670444713123835 139.74303368665068 36.349 35.67044979213331 139.74301535516972 36.349 35.67043425662442 139.7430088885113 36.349 35.67042917760763 139.74302720894286 36.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10077e56-1e68-4830-8295-a4110c5c77a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10077e56-1e68-4830-8295-a4110c5c77a5_0">
											<gml:posList>35.67040117131489 139.7430263678324 34.154 35.67040323767768 139.7430173075694 34.154 35.67040323767768 139.7430173075694 35.864 35.67040117131489 139.7430263678324 35.864 35.67040117131489 139.7430263678324 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d69c57b-ca70-48fc-a817-bbc34884c8a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d69c57b-ca70-48fc-a817-bbc34884c8a6_0">
											<gml:posList>35.67038453671218 139.74302067565202 34.154 35.67040117131489 139.7430263678324 34.154 35.67040117131489 139.7430263678324 35.864 35.67038453671218 139.74302067565202 35.864 35.67038453671218 139.74302067565202 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5c036e7-88a0-4ea4-aa84-c0d18aa2bf40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5c036e7-88a0-4ea4-aa84-c0d18aa2bf40_0">
											<gml:posList>35.670444713123835 139.74303368665068 34.154 35.67044979213331 139.74301535516972 34.154 35.67044979213331 139.74301535516972 36.349 35.670444713123835 139.74303368665068 36.349 35.670444713123835 139.74303368665068 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-806c442f-6a85-43da-ab7b-caad72bb0ecb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-806c442f-6a85-43da-ab7b-caad72bb0ecb_0">
											<gml:posList>35.67042917760763 139.74302720894286 34.154 35.670444713123835 139.74303368665068 34.154 35.670444713123835 139.74303368665068 36.349 35.67042917760763 139.74302720894286 36.349 35.67042917760763 139.74302720894286 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-51633cb0-9489-47aa-b1a3-c62defa3b889">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51633cb0-9489-47aa-b1a3-c62defa3b889">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51633cb0-9489-47aa-b1a3-c62defa3b889">
											<gml:posList>35.67051210958492 139.74281865017812 7.456 35.67044979002365 139.74306062278362 7.456 35.67036679455639 139.74302851638748 7.456 35.670424584376995 139.74280415687096 7.456 35.670452607200154 139.7428149947594 7.456 35.670477619873395 139.74277845858808 7.456 35.67051210958492 139.74281865017812 7.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc9efae8-5948-4887-83f4-3bebbd7cc820">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc9efae8-5948-4887-83f4-3bebbd7cc820">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc9efae8-5948-4887-83f4-3bebbd7cc820">
											<gml:posList>35.67040839787451 139.74286699524822 34.8 35.67036679455639 139.74302851638748 34.8 35.67036979469309 139.7430266020057 34.8 35.67041067002989 139.74286792057063 34.8 35.67040839787451 139.74286699524822 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-418f662d-783c-485e-8c8a-70475251c292">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-418f662d-783c-485e-8c8a-70475251c292">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-418f662d-783c-485e-8c8a-70475251c292">
											<gml:posList>35.67044979002365 139.74306062278362 34.8 35.67044823690552 139.7430569461247 34.8 35.67036979469309 139.7430266020057 34.8 35.67036679455639 139.74302851638748 34.8 35.67044979002365 139.74306062278362 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d674a944-3b3b-4df7-ab5e-f6ec1602777d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d674a944-3b3b-4df7-ab5e-f6ec1602777d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d674a944-3b3b-4df7-ab5e-f6ec1602777d">
											<gml:posList>35.67040839787451 139.74286699524822 37.807 35.67041060691722 139.74286789854935 37.807 35.670411182110804 139.74286565550875 37.807 35.67040839787451 139.74286699524822 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fdd771d3-55c9-49ad-939f-b75aae4ecabc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdd771d3-55c9-49ad-939f-b75aae4ecabc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdd771d3-55c9-49ad-939f-b75aae4ecabc">
											<gml:posList>35.67041465318214 139.74284270850097 37.807 35.67040839787451 139.74286699524822 37.807 35.670411182110804 139.74286565550875 37.807 35.67041687120555 139.7428435676063 37.807 35.67041465318214 139.74284270850097 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba5f6b45-25d8-4bcf-a35e-f20418660bf8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba5f6b45-25d8-4bcf-a35e-f20418660bf8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba5f6b45-25d8-4bcf-a35e-f20418660bf8">
											<gml:posList>35.67041756322842 139.7428408604904 37.807 35.67041465318214 139.74284270850097 37.807 35.67041687120555 139.7428435676063 37.807 35.67041756322842 139.7428408604904 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d37aad15-c6e3-4475-bb0d-24990fd16ce0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d37aad15-c6e3-4475-bb0d-24990fd16ce0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d37aad15-c6e3-4475-bb0d-24990fd16ce0">
											<gml:posList>35.67041465318214 139.74284270850097 37.807 35.67041756322842 139.7428408604904 37.807 35.67042609235947 139.74280773415848 37.807 35.670424584376995 139.74280415687096 37.807 35.67041465318214 139.74284270850097 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-31826f41-7790-4110-8177-efef2f3b4617">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31826f41-7790-4110-8177-efef2f3b4617">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31826f41-7790-4110-8177-efef2f3b4617">
											<gml:posList>35.67036979469309 139.7430266020057 34.154 35.67044823690552 139.7430569461247 34.154 35.67048868983953 139.74289986673597 34.154 35.67041067002989 139.74286792057063 34.154 35.67036979469309 139.7430266020057 34.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad5194b9-df3c-477c-9d2f-73e3d675ed95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad5194b9-df3c-477c-9d2f-73e3d675ed95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad5194b9-df3c-477c-9d2f-73e3d675ed95">
											<gml:posList>35.67041060691722 139.74286789854935 37.807 35.670488743938456 139.74289988876754 37.807 35.670411182110804 139.74286565550875 37.807 35.67041060691722 139.74286789854935 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-946479ff-386c-47d1-beb6-52f6a7beb66b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-946479ff-386c-47d1-beb6-52f6a7beb66b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-946479ff-386c-47d1-beb6-52f6a7beb66b">
											<gml:posList>35.670488743938456 139.74289988876754 37.807 35.670489310143786 139.74289767887393 37.807 35.670411182110804 139.74286565550875 37.807 35.670488743938456 139.74289988876754 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-510bddb2-2f36-44e8-aecf-b310f728a791">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-510bddb2-2f36-44e8-aecf-b310f728a791">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-510bddb2-2f36-44e8-aecf-b310f728a791">
											<gml:posList>35.670495421652845 139.7428739445806 34.8 35.67041686219183 139.74284356761646 34.8 35.670411182110804 139.74286565550875 34.8 35.670489310143786 139.74289767887393 34.8 35.670495421652845 139.7428739445806 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74e4917c-4d39-4d81-976a-81a80699fcd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74e4917c-4d39-4d81-976a-81a80699fcd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74e4917c-4d39-4d81-976a-81a80699fcd1">
											<gml:posList>35.67041756322842 139.7428408604904 37.807 35.67041687120555 139.7428435676063 37.807 35.670495421652845 139.7428739445806 37.807 35.670497639676015 139.7428748036876 37.807 35.6704961226901 139.7428712374521 37.807 35.67041756322842 139.7428408604904 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f408a673-f8b1-48a0-ac1d-26e6d061a129">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f408a673-f8b1-48a0-ac1d-26e6d061a129">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f408a673-f8b1-48a0-ac1d-26e6d061a129">
											<gml:posList>35.67050465183766 139.74283812213721 37.084 35.67042609235947 139.74280773415848 37.084 35.67041756322842 139.7428408604904 37.084 35.6704961226901 139.7428712374521 37.084 35.67050465183766 139.74283812213721 37.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0fed92dc-c443-4361-834e-5817fe9a3726">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fed92dc-c443-4361-834e-5817fe9a3726">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fed92dc-c443-4361-834e-5817fe9a3726">
											<gml:posList>35.670424584376995 139.74280415687096 37.807 35.67042609235947 139.74280773415848 37.807 35.67050465183766 139.74283812213721 37.807 35.67050757088924 139.74283626306791 37.807 35.670424584376995 139.74280415687096 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-86c24bed-9d80-4f8b-8dc7-6c79e3531c9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86c24bed-9d80-4f8b-8dc7-6c79e3531c9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86c24bed-9d80-4f8b-8dc7-6c79e3531c9f">
											<gml:posList>35.67044823690552 139.7430569461247 34.8 35.67044979002365 139.74306062278362 34.8 35.67049094396718 139.7429007920806 34.8 35.670488680825805 139.74289986674617 34.8 35.67044823690552 139.7430569461247 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3597f9c0-c0fc-48c1-8f63-dfa1624823b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3597f9c0-c0fc-48c1-8f63-dfa1624823b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3597f9c0-c0fc-48c1-8f63-dfa1624823b1">
											<gml:posList>35.67050757088924 139.74283626306791 34.8 35.67051210958492 139.74281865017812 34.8 35.670477619873395 139.74277845858808 34.8 35.670452607200154 139.7428149947594 34.8 35.67050757088924 139.74283626306791 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6e29d05-4564-40d1-840f-99577518bae2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6e29d05-4564-40d1-840f-99577518bae2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6e29d05-4564-40d1-840f-99577518bae2">
											<gml:posList>35.67049094396718 139.7429007920806 37.807 35.670489310143786 139.74289767887393 37.807 35.670488743938456 139.74289988876754 37.807 35.67049094396718 139.7429007920806 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74105b5a-47c1-43ac-8213-f2290fa12615">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74105b5a-47c1-43ac-8213-f2290fa12615">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74105b5a-47c1-43ac-8213-f2290fa12615">
											<gml:posList>35.67049094396718 139.7429007920806 37.807 35.670497639676015 139.7428748036876 37.807 35.670495421652845 139.7428739445806 37.807 35.670489310143786 139.74289767887393 37.807 35.67049094396718 139.7429007920806 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-754d88dc-485e-4fa8-982b-6272692d3172">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-754d88dc-485e-4fa8-982b-6272692d3172">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-754d88dc-485e-4fa8-982b-6272692d3172">
											<gml:posList>35.67050757088924 139.74283626306791 37.807 35.67050465183766 139.74283812213721 37.807 35.6704961226901 139.7428712374521 37.807 35.670497639676015 139.7428748036876 37.807 35.67050757088924 139.74283626306791 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad73578c-fa6e-4956-abfc-47dcd06f6dfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad73578c-fa6e-4956-abfc-47dcd06f6dfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad73578c-fa6e-4956-abfc-47dcd06f6dfe">
											<gml:posList>35.670411182110804 139.74286565550875 37.807 35.670489310143786 139.74289767887393 37.807 35.670489310143786 139.74289767887393 34.8 35.670411182110804 139.74286565550875 34.8 35.670411182110804 139.74286565550875 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e1dd7c9-24c6-421b-908f-6861f755f1ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e1dd7c9-24c6-421b-908f-6861f755f1ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e1dd7c9-24c6-421b-908f-6861f755f1ea">
											<gml:posList>35.670495421652845 139.7428739445806 37.807 35.67041687120555 139.7428435676063 37.807 35.67041686219183 139.74284356761646 34.8 35.670495421652845 139.7428739445806 34.8 35.670495421652845 139.7428739445806 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d87d23c-c795-4e81-9755-baa7f4c3ebd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d87d23c-c795-4e81-9755-baa7f4c3ebd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d87d23c-c795-4e81-9755-baa7f4c3ebd3">
											<gml:posList>35.6704961226901 139.7428712374521 37.807 35.6704961226901 139.7428712374521 37.084 35.67041756322842 139.7428408604904 37.084 35.67041756322842 139.7428408604904 37.807 35.6704961226901 139.7428712374521 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7484fb16-0fc0-41dd-87c4-3aad98d8e08c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7484fb16-0fc0-41dd-87c4-3aad98d8e08c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7484fb16-0fc0-41dd-87c4-3aad98d8e08c">
											<gml:posList>35.670477619873395 139.74277845858808 34.8 35.670477619873395 139.74277845858808 7.456 35.670452607200154 139.7428149947594 7.456 35.670452607200154 139.7428149947594 34.8 35.670477619873395 139.74277845858808 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edaeda80-26c3-48f1-9d9a-bc04efbd619e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edaeda80-26c3-48f1-9d9a-bc04efbd619e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edaeda80-26c3-48f1-9d9a-bc04efbd619e">
											<gml:posList>35.67051210958492 139.74281865017812 7.456 35.670477619873395 139.74277845858808 7.456 35.670477619873395 139.74277845858808 34.8 35.67051210958492 139.74281865017812 34.8 35.67051210958492 139.74281865017812 7.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e86c705-eb42-4465-83f4-7f912df44d31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e86c705-eb42-4465-83f4-7f912df44d31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e86c705-eb42-4465-83f4-7f912df44d31">
											<gml:posList>35.670452607200154 139.7428149947594 34.8 35.670452607200154 139.7428149947594 7.456 35.670424584376995 139.74280415687096 7.456 35.670424584376995 139.74280415687096 37.807 35.67050757088924 139.74283626306791 37.807 35.67050757088924 139.74283626306791 34.8 35.670452607200154 139.7428149947594 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e96e61d7-6a18-4fe6-9002-92f177efe99c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e96e61d7-6a18-4fe6-9002-92f177efe99c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e96e61d7-6a18-4fe6-9002-92f177efe99c">
											<gml:posList>35.67042609235947 139.74280773415848 37.807 35.67042609235947 139.74280773415848 37.084 35.67050465183766 139.74283812213721 37.084 35.67050465183766 139.74283812213721 37.807 35.67042609235947 139.74280773415848 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92611bfb-ce02-41da-b9a3-032a38208873">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92611bfb-ce02-41da-b9a3-032a38208873">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92611bfb-ce02-41da-b9a3-032a38208873">
											<gml:posList>35.67041756322842 139.7428408604904 37.807 35.67041756322842 139.7428408604904 37.084 35.67042609235947 139.74280773415848 37.084 35.67042609235947 139.74280773415848 37.807 35.67041756322842 139.7428408604904 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-343144bc-70df-4c7f-b9f6-2e750be6d5b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-343144bc-70df-4c7f-b9f6-2e750be6d5b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-343144bc-70df-4c7f-b9f6-2e750be6d5b4">
											<gml:posList>35.67041687120555 139.7428435676063 37.807 35.670411182110804 139.74286565550875 37.807 35.670411182110804 139.74286565550875 34.8 35.67041686219183 139.74284356761646 34.8 35.67041687120555 139.7428435676063 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da43c787-0079-49d1-8f14-24b47b9ebfaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da43c787-0079-49d1-8f14-24b47b9ebfaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da43c787-0079-49d1-8f14-24b47b9ebfaf">
											<gml:posList>35.67050465183766 139.74283812213721 37.807 35.67050465183766 139.74283812213721 37.084 35.6704961226901 139.7428712374521 37.084 35.6704961226901 139.7428712374521 37.807 35.67050465183766 139.74283812213721 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e03fcb36-1a51-461f-a693-a4c3230c8a70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e03fcb36-1a51-461f-a693-a4c3230c8a70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e03fcb36-1a51-461f-a693-a4c3230c8a70">
											<gml:posList>35.67041060691722 139.74286789854935 37.807 35.67040839787451 139.74286699524822 37.807 35.67040839787451 139.74286699524822 34.8 35.67041060691722 139.74286789854935 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d32b3d5-08b6-4f1a-a856-4359b54b8dd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d32b3d5-08b6-4f1a-a856-4359b54b8dd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d32b3d5-08b6-4f1a-a856-4359b54b8dd1">
											<gml:posList>35.67041060691722 139.74286789854935 37.807 35.67040839787451 139.74286699524822 34.8 35.67041067002989 139.74286792057063 34.8 35.67041060691722 139.74286789854935 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de06cc23-f846-49c2-b382-6df93abaf623">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de06cc23-f846-49c2-b382-6df93abaf623">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de06cc23-f846-49c2-b382-6df93abaf623">
											<gml:posList>35.67041067002989 139.74286792057063 34.8 35.67041067002989 139.74286792057063 34.154 35.67048868983953 139.74289986673597 34.154 35.670488680825805 139.74289986674617 34.8 35.670488743938456 139.74289988876754 37.807 35.67041060691722 139.74286789854935 37.807 35.67041067002989 139.74286792057063 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c4bbfa2-0af7-4adf-965e-b0ce26d43b27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c4bbfa2-0af7-4adf-965e-b0ce26d43b27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c4bbfa2-0af7-4adf-965e-b0ce26d43b27">
											<gml:posList>35.670489310143786 139.74289767887393 37.807 35.670495421652845 139.7428739445806 37.807 35.670495421652845 139.7428739445806 34.8 35.670489310143786 139.74289767887393 34.8 35.670489310143786 139.74289767887393 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-160be3c3-6465-4acf-8a0f-68c972482578">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-160be3c3-6465-4acf-8a0f-68c972482578">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-160be3c3-6465-4acf-8a0f-68c972482578">
											<gml:posList>35.670488680825805 139.74289986674617 34.8 35.67049094396718 139.7429007920806 37.807 35.670488743938456 139.74289988876754 37.807 35.670488680825805 139.74289986674617 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-508796d8-dcc1-4358-add0-88ab36dcd094">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-508796d8-dcc1-4358-add0-88ab36dcd094">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-508796d8-dcc1-4358-add0-88ab36dcd094">
											<gml:posList>35.670488680825805 139.74289986674617 34.8 35.67049094396718 139.7429007920806 34.8 35.67049094396718 139.7429007920806 37.807 35.670488680825805 139.74289986674617 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c3aa521-065a-4cf1-9dba-fa2d50685de5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c3aa521-065a-4cf1-9dba-fa2d50685de5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c3aa521-065a-4cf1-9dba-fa2d50685de5">
											<gml:posList>35.67040839787451 139.74286699524822 34.8 35.67040839787451 139.74286699524822 37.807 35.67041465318214 139.74284270850097 37.807 35.670424584376995 139.74280415687096 37.807 35.670424584376995 139.74280415687096 7.456 35.67036679455639 139.74302851638748 7.456 35.67036679455639 139.74302851638748 34.8 35.67040839787451 139.74286699524822 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7bd949a-c9a0-41a2-bc16-496739fcf67b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7bd949a-c9a0-41a2-bc16-496739fcf67b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7bd949a-c9a0-41a2-bc16-496739fcf67b">
											<gml:posList>35.670497639676015 139.7428748036876 37.807 35.67049094396718 139.7429007920806 37.807 35.67049094396718 139.7429007920806 34.8 35.67044979002365 139.74306062278362 34.8 35.67044979002365 139.74306062278362 7.456 35.67051210958492 139.74281865017812 7.456 35.67051210958492 139.74281865017812 34.8 35.67050757088924 139.74283626306791 34.8 35.67050757088924 139.74283626306791 37.807 35.670497639676015 139.7428748036876 37.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e208fc3-e276-4e75-9832-77cfe81a8a9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e208fc3-e276-4e75-9832-77cfe81a8a9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e208fc3-e276-4e75-9832-77cfe81a8a9f">
											<gml:posList>35.67036979469309 139.7430266020057 34.8 35.67036979469309 139.7430266020057 34.154 35.67041067002989 139.74286792057063 34.154 35.67041067002989 139.74286792057063 34.8 35.67036979469309 139.7430266020057 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af8f976a-6be7-4a2c-8016-2fd066f5e635">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af8f976a-6be7-4a2c-8016-2fd066f5e635">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af8f976a-6be7-4a2c-8016-2fd066f5e635">
											<gml:posList>35.67044823690552 139.7430569461247 34.8 35.670488680825805 139.74289986674617 34.8 35.67048868983953 139.74289986673597 34.154 35.67044823690552 139.7430569461247 34.154 35.67044823690552 139.7430569461247 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88705a39-9228-4524-b552-ab5e24205770">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88705a39-9228-4524-b552-ab5e24205770">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88705a39-9228-4524-b552-ab5e24205770">
											<gml:posList>35.67044823690552 139.7430569461247 34.8 35.67044823690552 139.7430569461247 34.154 35.67036979469309 139.7430266020057 34.154 35.67036979469309 139.7430266020057 34.8 35.67044823690552 139.7430569461247 34.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b98dd3a-bcf2-4e09-be5a-9b9dcfe79d21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b98dd3a-bcf2-4e09-be5a-9b9dcfe79d21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b98dd3a-bcf2-4e09-be5a-9b9dcfe79d21">
											<gml:posList>35.67036679455639 139.74302851638748 7.456 35.67044979002365 139.74306062278362 7.456 35.67044979002365 139.74306062278362 34.8 35.67036679455639 139.74302851638748 34.8 35.67036679455639 139.74302851638748 7.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-690</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">229.41685</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>