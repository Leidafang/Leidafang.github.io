<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a52e3191-5cee-41da-8e20-9ee74b636092">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">12.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66866575935602 139.73826283600474 0 35.6686073876016 139.73819585590363 0 35.66857812318599 139.7382341098239 0 35.668558725966484 139.73821170943276 0 35.668486150260065 139.73830668065503 0 35.668563919143466 139.7383960611623 0 35.66866575935602 139.73826283600474 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866575935602 139.73826283600474 19.31 35.668563919143466 139.7383960611623 19.31 35.668486150260065 139.73830668065503 19.31 35.668558725966484 139.73821170943276 19.31 35.66857812318599 139.7382341098239 19.31 35.6686073876016 139.73819585590363 19.31 35.66866575935602 139.73826283600474 19.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866575935602 139.73826283600474 19.31 35.6686073876016 139.73819585590363 19.31 35.6686073876016 139.73819585590363 32.02 35.66866575935602 139.73826283600474 32.02 35.66866575935602 139.73826283600474 19.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6686073876016 139.73819585590363 19.31 35.66857812318599 139.7382341098239 19.31 35.66857812318599 139.7382341098239 32.02 35.6686073876016 139.73819585590363 32.02 35.6686073876016 139.73819585590363 19.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66857812318599 139.7382341098239 19.31 35.668558725966484 139.73821170943276 19.31 35.668558725966484 139.73821170943276 32.02 35.66857812318599 139.7382341098239 32.02 35.66857812318599 139.7382341098239 19.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668558725966484 139.73821170943276 19.31 35.668486150260065 139.73830668065503 19.31 35.668486150260065 139.73830668065503 32.02 35.668558725966484 139.73821170943276 32.02 35.668558725966484 139.73821170943276 19.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668486150260065 139.73830668065503 19.31 35.668563919143466 139.7383960611623 19.31 35.668563919143466 139.7383960611623 32.02 35.668486150260065 139.73830668065503 32.02 35.668486150260065 139.73830668065503 19.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668563919143466 139.7383960611623 19.31 35.66866575935602 139.73826283600474 19.31 35.66866575935602 139.73826283600474 32.02 35.668563919143466 139.7383960611623 32.02 35.668563919143466 139.7383960611623 19.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866575935602 139.73826283600474 32.02 35.6686073876016 139.73819585590363 32.02 35.66857812318599 139.7382341098239 32.02 35.668558725966484 139.73821170943276 32.02 35.668486150260065 139.73830668065503 32.02 35.668563919143466 139.7383960611623 32.02 35.66866575935602 139.73826283600474 32.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-4fc254e5-2850-46f1-8b0c-7183656b5a86"/>
							<gml:surfaceMember xlink:href="#poly-6d66815a-93e6-4eea-a30e-87753390a7e5"/>
							<gml:surfaceMember xlink:href="#poly-9e72fe96-ff44-427b-a994-778524c83894"/>
							<gml:surfaceMember xlink:href="#poly-93487fb2-1c1f-4e96-a005-3427e36d0d7a"/>
							<gml:surfaceMember xlink:href="#poly-658ca794-e866-4250-a828-ae85c0da9713"/>
							<gml:surfaceMember xlink:href="#poly-4bb412d2-a9b1-4607-8f68-6990f55e24d7"/>
							<gml:surfaceMember xlink:href="#poly-218e1d6d-4079-4ca6-bc03-91f54837b4c2"/>
							<gml:surfaceMember xlink:href="#poly-501e33e9-73b0-42ec-b695-b26c8e6164e9"/>
							<gml:surfaceMember xlink:href="#poly-14755da4-3bfe-4a39-bafd-3569167b7dda"/>
							<gml:surfaceMember xlink:href="#poly-0c4fa686-bbed-4717-b21b-ba709335c70b"/>
							<gml:surfaceMember xlink:href="#poly-c1955086-3d35-44c9-87ae-a92653b30d2b"/>
							<gml:surfaceMember xlink:href="#poly-79106108-127f-4d99-8d86-e496e75cefd6"/>
							<gml:surfaceMember xlink:href="#poly-14616ce9-99ba-4459-93e8-e9363e8d92d2"/>
							<gml:surfaceMember xlink:href="#poly-321b8873-e031-452c-bd9d-8cd50f36108e"/>
							<gml:surfaceMember xlink:href="#poly-ea9c13f9-0d90-4ddd-8528-2bbc70f259e2"/>
							<gml:surfaceMember xlink:href="#poly-f6b7f1e7-217d-4de5-92e2-635334a0d883"/>
							<gml:surfaceMember xlink:href="#poly-a9a51563-e6e3-4872-adcf-bfa39897114c"/>
							<gml:surfaceMember xlink:href="#poly-8ff32631-98ce-45e3-b3d4-52dae960d4ad"/>
							<gml:surfaceMember xlink:href="#poly-e5c38458-c894-4352-998e-a901f9832e53"/>
							<gml:surfaceMember xlink:href="#poly-25c9c2be-bcac-408b-97eb-2d2676853244"/>
							<gml:surfaceMember xlink:href="#poly-5b64134d-7e0d-4a5b-b426-1b33f9133b12"/>
							<gml:surfaceMember xlink:href="#poly-11e4e1be-27d4-4b32-bd76-1217379133ae"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a52e3191-5cee-41da-8e20-9ee74b636092_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-516b63fe-a24d-4e7c-9e20-9c63ee4f6a15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858644572272 139.73828339830516 32.316 35.66857745113038 139.7382733902356 32.316 35.668587238636796 139.73826018969353 32.316 35.66858841145012 139.7382614917324 32.316 35.668597172480865 139.73824967315605 32.316 35.668602937318454 139.73825608405423 32.316 35.668594059222045 139.73826804636772 32.316 35.668596125178865 139.73827034148908 32.316 35.66858644572272 139.73828339830516 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-495712e7-6e52-40b5-8c6a-d58497bb5362">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-495712e7-6e52-40b5-8c6a-d58497bb5362_0">
											<gml:posList>35.66858644572272 139.73828339830516 32.316 35.66858644572272 139.73828339830516 32.586 35.66857745113038 139.7382733902356 32.586 35.66857745113038 139.7382733902356 32.316 35.66858644572272 139.73828339830516 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b17e053a-a692-4d37-8d2c-8acbe9b3ec89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b17e053a-a692-4d37-8d2c-8acbe9b3ec89_0">
											<gml:posList>35.66857745113038 139.7382733902356 32.316 35.66857745113038 139.7382733902356 32.586 35.668587238636796 139.73826018969353 32.586 35.668587238636796 139.73826018969353 32.316 35.66857745113038 139.7382733902356 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a892658-d309-43b0-bbf5-a8ef309d8d9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a892658-d309-43b0-bbf5-a8ef309d8d9e_0">
											<gml:posList>35.668587238636796 139.73826018969353 32.316 35.668587238636796 139.73826018969353 32.586 35.66858841145012 139.7382614917324 32.586 35.66858841145012 139.7382614917324 32.316 35.668587238636796 139.73826018969353 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fceb244-7dc6-41ec-bdad-a2f2d3318645">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fceb244-7dc6-41ec-bdad-a2f2d3318645_0">
											<gml:posList>35.668594059222045 139.73826804636772 32.586 35.668602937318454 139.73825608405423 32.586 35.668597172480865 139.73824967315605 32.586 35.66858841145012 139.7382614917324 32.586 35.668587238636796 139.73826018969353 32.586 35.66857745113038 139.7382733902356 32.586 35.66858644572272 139.73828339830516 32.586 35.668596125178865 139.73827034148908 32.586 35.668594059222045 139.73826804636772 32.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b27d20a2-a350-4e91-9771-05c076e37613">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b27d20a2-a350-4e91-9771-05c076e37613_0">
											<gml:posList>35.668596125178865 139.73827034148908 32.316 35.668596125178865 139.73827034148908 32.586 35.66858644572272 139.73828339830516 32.586 35.66858644572272 139.73828339830516 32.316 35.668596125178865 139.73827034148908 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd591e8c-e9c3-4e0f-9956-56b7d997e668">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd591e8c-e9c3-4e0f-9956-56b7d997e668_0">
											<gml:posList>35.66858841145012 139.7382614917324 32.316 35.66858841145012 139.7382614917324 32.586 35.668597172480865 139.73824967315605 32.586 35.668597172480865 139.73824967315605 32.316 35.66858841145012 139.7382614917324 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8ef02c0-9c15-4c84-aa55-e8223ffd82dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8ef02c0-9c15-4c84-aa55-e8223ffd82dc_0">
											<gml:posList>35.668594059222045 139.73826804636772 32.586 35.668596125178865 139.73827034148908 32.586 35.668596125178865 139.73827034148908 32.316 35.668594059222045 139.73826804636772 32.316 35.668594059222045 139.73826804636772 32.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50f4aaf6-3f4f-45b5-9b79-0efb4fb99286">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50f4aaf6-3f4f-45b5-9b79-0efb4fb99286_0">
											<gml:posList>35.668602937318454 139.73825608405423 32.316 35.668602937318454 139.73825608405423 32.586 35.668594059222045 139.73826804636772 32.586 35.668594059222045 139.73826804636772 32.316 35.668602937318454 139.73825608405423 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a524d959-55ab-4baa-9e13-6961bb740aa2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a524d959-55ab-4baa-9e13-6961bb740aa2_0">
											<gml:posList>35.668597172480865 139.73824967315605 32.316 35.668597172480865 139.73824967315605 32.586 35.668602937318454 139.73825608405423 32.586 35.668602937318454 139.73825608405423 32.316 35.668597172480865 139.73824967315605 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a52e3191-5cee-41da-8e20-9ee74b636092_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8dfbb185-712a-4273-8cdb-187e36891764">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8dfbb185-712a-4273-8cdb-187e36891764_0">
											<gml:posList>35.668563026101104 139.73826951914194 38.705 35.668571745052475 139.73828432150435 38.705 35.66857395998741 139.73828122599588 38.705 35.668563026101104 139.73826951914194 38.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b190c2d0-eb3a-4b1d-bc97-dffcb968625c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b190c2d0-eb3a-4b1d-bc97-dffcb968625c_0">
											<gml:posList>35.668553842260344 139.73828239862902 38.705 35.668571745052475 139.73828432150435 38.705 35.668563026101104 139.73826951914194 38.705 35.668553842260344 139.73828239862902 38.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3c702a7-a34f-4f14-b891-7118dcc39e32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3c702a7-a34f-4f14-b891-7118dcc39e32_0">
											<gml:posList>35.66857395998741 139.73828122599588 39.565 35.668571745052475 139.73828432150435 38.705 35.66857395998741 139.73828122599588 38.705 35.66857395998741 139.73828122599588 39.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a728e902-4c39-4a6b-898a-b9fb31c86fc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a728e902-4c39-4a6b-898a-b9fb31c86fc2_0">
											<gml:posList>35.66856469510907 139.73829421603955 39.565 35.668571745052475 139.73828432150435 38.705 35.66857395998741 139.73828122599588 39.565 35.66856469510907 139.73829421603955 39.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-685ddc87-b1ef-4dc2-9a96-6ac5848db623">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-685ddc87-b1ef-4dc2-9a96-6ac5848db623_0">
											<gml:posList>35.668571745052475 139.73828432150435 38.705 35.668553842260344 139.73828239862902 38.705 35.66856469510907 139.73829421603955 38.705 35.668571745052475 139.73828432150435 38.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9165f00-8aef-43fc-91a3-67bef7aed94e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9165f00-8aef-43fc-91a3-67bef7aed94e_0">
											<gml:posList>35.668571745052475 139.73828432150435 38.705 35.66856469510907 139.73829421603955 39.565 35.66856469510907 139.73829421603955 38.705 35.668571745052475 139.73828432150435 38.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22949294-8697-4f57-94c1-b4d04b5f2b29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22949294-8697-4f57-94c1-b4d04b5f2b29_0">
											<gml:posList>35.66856394183838 139.73826487873248 39.654 35.66858244526807 139.7382854796975 38.705 35.66858244526807 139.7382854796975 39.654 35.66856394183838 139.73826487873248 39.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4d3a4be-2b45-4cb2-8f8e-5b3d40f2e884">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4d3a4be-2b45-4cb2-8f8e-5b3d40f2e884_0">
											<gml:posList>35.66856394183838 139.73826487873248 39.654 35.66856394183838 139.73826487873248 38.705 35.66858244526807 139.7382854796975 38.705 35.66856394183838 139.73826487873248 39.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6575f2cf-9d44-4406-8752-78b359ece0b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6575f2cf-9d44-4406-8752-78b359ece0b1_0">
											<gml:posList>35.66855376123272 139.73828252023117 39.565 35.668563026101104 139.73826951914194 38.705 35.66855376123272 139.73828252023117 38.705 35.66855376123272 139.73828252023117 39.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a6ff64f-62ef-4ff5-b1bc-cebe2bdd8df1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a6ff64f-62ef-4ff5-b1bc-cebe2bdd8df1_0">
											<gml:posList>35.66855376123272 139.73828252023117 39.565 35.668563026101104 139.73826951914194 39.565 35.668563026101104 139.73826951914194 38.705 35.66855376123272 139.73828252023117 39.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfcf4065-1a53-499d-9c26-999ca25c8968">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfcf4065-1a53-499d-9c26-999ca25c8968_0">
											<gml:posList>35.66856966838414 139.73830271557236 39.654 35.66855116495736 139.7382821146066 38.705 35.66855116495736 139.7382821146066 39.654 35.66856966838414 139.73830271557236 39.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae979f04-8a5f-41df-9631-51ddcd92b7a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae979f04-8a5f-41df-9631-51ddcd92b7a0_0">
											<gml:posList>35.66856966838414 139.73830271557236 39.654 35.66856966838414 139.73830271557236 38.705 35.66855116495736 139.7382821146066 38.705 35.66856966838414 139.73830271557236 39.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95d5f45d-0b8d-4eaf-ac50-e7315d448b36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95d5f45d-0b8d-4eaf-ac50-e7315d448b36_0">
											<gml:posList>35.668548109444124 139.7382822949648 32.316 35.66856379465364 139.7382611232639 39.654 35.66856379465364 139.7382611232639 32.316 35.668548109444124 139.7382822949648 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-948337cc-a663-427d-8640-bd97d153e553">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-948337cc-a663-427d-8640-bd97d153e553_0">
											<gml:posList>35.668548109444124 139.7382822949648 32.316 35.668548109444124 139.7382822949648 39.654 35.66856379465364 139.7382611232639 39.654 35.668548109444124 139.7382822949648 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdb7bfc4-bf04-452f-a116-9d257f4e59fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdb7bfc4-bf04-452f-a116-9d257f4e59fb_0">
											<gml:posList>35.66856379465364 139.7382611232639 32.316 35.66858550078128 139.73828529933934 39.654 35.66858550078128 139.73828529933934 32.316 35.66856379465364 139.7382611232639 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-689815a8-5f0d-4df3-8672-010c441cae42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-689815a8-5f0d-4df3-8672-010c441cae42_0">
											<gml:posList>35.66856379465364 139.7382611232639 32.316 35.66856379465364 139.7382611232639 39.654 35.66858550078128 139.73828529933934 39.654 35.66856379465364 139.7382611232639 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f7452c7-282d-45e1-a44b-0ea0e9d36efa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f7452c7-282d-45e1-a44b-0ea0e9d36efa_0">
											<gml:posList>35.66856394183838 139.73826487873248 39.654 35.66855116495736 139.7382821146066 38.705 35.66856394183838 139.73826487873248 38.705 35.66856394183838 139.73826487873248 39.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b8a7755-37c7-4892-8ec8-cb975289df2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b8a7755-37c7-4892-8ec8-cb975289df2d_0">
											<gml:posList>35.66856394183838 139.73826487873248 39.654 35.66855116495736 139.7382821146066 39.654 35.66855116495736 139.7382821146066 38.705 35.66856394183838 139.73826487873248 39.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52c2aba8-1c12-4d8c-ae5f-82fe8eb1c212">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52c2aba8-1c12-4d8c-ae5f-82fe8eb1c212_0">
											<gml:posList>35.66856469510907 139.73829421603955 39.565 35.668563026101104 139.73826951914194 39.565 35.66855376123272 139.73828252023117 39.565 35.66856469510907 139.73829421603955 39.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27ad3514-f4b4-45c7-be67-f4e4f83f648c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27ad3514-f4b4-45c7-be67-f4e4f83f648c_0">
											<gml:posList>35.66856469510907 139.73829421603955 39.565 35.66857395998741 139.73828122599588 39.565 35.668563026101104 139.73826951914194 39.565 35.66856469510907 139.73829421603955 39.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c850f82-786b-43a4-8b60-f62c303052aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c850f82-786b-43a4-8b60-f62c303052aa_0">
											<gml:posList>35.66856981555887 139.73830645999524 39.654 35.66856966838414 139.73830271557236 39.654 35.668548109444124 139.7382822949648 39.654 35.66856981555887 139.73830645999524 39.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57009441-0610-4af8-9215-33a3d32d24b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57009441-0610-4af8-9215-33a3d32d24b4_0">
											<gml:posList>35.668548109444124 139.7382822949648 39.654 35.66856394183838 139.73826487873248 39.654 35.66856379465364 139.7382611232639 39.654 35.668548109444124 139.7382822949648 39.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4802ed6-d7c5-4e21-9dcb-519da0f8d061">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4802ed6-d7c5-4e21-9dcb-519da0f8d061_0">
											<gml:posList>35.66858550078128 139.73828529933934 39.654 35.66858244526807 139.7382854796975 39.654 35.66856981555887 139.73830645999524 39.654 35.66858550078128 139.73828529933934 39.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-153f5f84-58ca-40d3-95bc-005f8562319e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-153f5f84-58ca-40d3-95bc-005f8562319e_0">
											<gml:posList>35.66856394183838 139.73826487873248 39.654 35.66858550078128 139.73828529933934 39.654 35.66856379465364 139.7382611232639 39.654 35.66856394183838 139.73826487873248 39.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f0c7080-8f11-41f0-816e-450e144df78b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f0c7080-8f11-41f0-816e-450e144df78b_0">
											<gml:posList>35.668548109444124 139.7382822949648 39.654 35.66856966838414 139.73830271557236 39.654 35.66855116495736 139.7382821146066 39.654 35.668548109444124 139.7382822949648 39.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f3de3fa-0e9f-482d-a345-75308273f248">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f3de3fa-0e9f-482d-a345-75308273f248_0">
											<gml:posList>35.66856981555887 139.73830645999524 39.654 35.66858244526807 139.7382854796975 39.654 35.66856966838414 139.73830271557236 39.654 35.66856981555887 139.73830645999524 39.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea450654-f65d-4d96-b6a7-61e62022f9c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea450654-f65d-4d96-b6a7-61e62022f9c4_0">
											<gml:posList>35.668548109444124 139.7382822949648 39.654 35.66855116495736 139.7382821146066 39.654 35.66856394183838 139.73826487873248 39.654 35.668548109444124 139.7382822949648 39.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-179c3db3-01b2-4694-91db-a2ebb7c7657c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-179c3db3-01b2-4694-91db-a2ebb7c7657c_0">
											<gml:posList>35.66856394183838 139.73826487873248 39.654 35.66858244526807 139.7382854796975 39.654 35.66858550078128 139.73828529933934 39.654 35.66856394183838 139.73826487873248 39.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a4b331c-e381-4ce2-a811-e6c87b21d0f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a4b331c-e381-4ce2-a811-e6c87b21d0f1_0">
											<gml:posList>35.66855116495736 139.7382821146066 38.705 35.66856966838414 139.73830271557236 38.705 35.66856469510907 139.73829421603955 38.705 35.66855116495736 139.7382821146066 38.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24a2ec8e-0231-4a90-aa4b-639b0dec57f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24a2ec8e-0231-4a90-aa4b-639b0dec57f9_0">
											<gml:posList>35.66857395998741 139.73828122599588 38.705 35.66856966838414 139.73830271557236 38.705 35.66858244526807 139.7382854796975 38.705 35.66857395998741 139.73828122599588 38.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cd0b90e-f84d-4458-8737-d319132eb065">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cd0b90e-f84d-4458-8737-d319132eb065_0">
											<gml:posList>35.668563026101104 139.73826951914194 38.705 35.66856394183838 139.73826487873248 38.705 35.66855116495736 139.7382821146066 38.705 35.668563026101104 139.73826951914194 38.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-844a92c1-1cb7-4671-821f-4d7c97557a0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-844a92c1-1cb7-4671-821f-4d7c97557a0f_0">
											<gml:posList>35.66857395998741 139.73828122599588 38.705 35.66858244526807 139.7382854796975 38.705 35.66856394183838 139.73826487873248 38.705 35.66857395998741 139.73828122599588 38.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31dc2daf-c6f1-4ddd-9a43-9efddde958d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31dc2daf-c6f1-4ddd-9a43-9efddde958d7_0">
											<gml:posList>35.66856469510907 139.73829421603955 38.705 35.66856966838414 139.73830271557236 38.705 35.668571745052475 139.73828432150435 38.705 35.66856469510907 139.73829421603955 38.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e3ec2ba-7a7e-4a7c-a693-289aa2049296">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e3ec2ba-7a7e-4a7c-a693-289aa2049296_0">
											<gml:posList>35.66855376123272 139.73828252023117 38.705 35.66855116495736 139.7382821146066 38.705 35.66856469510907 139.73829421603955 38.705 35.66855376123272 139.73828252023117 38.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35f350ef-13d4-462a-a945-9a1862e4fd2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35f350ef-13d4-462a-a945-9a1862e4fd2a_0">
											<gml:posList>35.668563026101104 139.73826951914194 38.705 35.66855116495736 139.7382821146066 38.705 35.66855376123272 139.73828252023117 38.705 35.668563026101104 139.73826951914194 38.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6917154d-372c-48bb-8d13-ab196d973ec6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6917154d-372c-48bb-8d13-ab196d973ec6_0">
											<gml:posList>35.66857395998741 139.73828122599588 38.705 35.66856394183838 139.73826487873248 38.705 35.668563026101104 139.73826951914194 38.705 35.66857395998741 139.73828122599588 38.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac970c6e-a737-4cc0-b84b-f0aba62d9205">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac970c6e-a737-4cc0-b84b-f0aba62d9205_0">
											<gml:posList>35.66856966838414 139.73830271557236 38.705 35.66857395998741 139.73828122599588 38.705 35.668571745052475 139.73828432150435 38.705 35.66856966838414 139.73830271557236 38.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5e07336-358c-49a4-8fba-939c4da45713">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5e07336-358c-49a4-8fba-939c4da45713_0">
											<gml:posList>35.66856966838414 139.73830271557236 39.654 35.66858244526807 139.7382854796975 38.705 35.66856966838414 139.73830271557236 38.705 35.66856966838414 139.73830271557236 39.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a313cb4-01c0-4bbb-8d28-6e9d2c219a1d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a313cb4-01c0-4bbb-8d28-6e9d2c219a1d_0">
											<gml:posList>35.66856966838414 139.73830271557236 39.654 35.66858244526807 139.7382854796975 39.654 35.66858244526807 139.7382854796975 38.705 35.66856966838414 139.73830271557236 39.654</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f1f44d3-974c-437d-a928-86684c750e28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f1f44d3-974c-437d-a928-86684c750e28_0">
											<gml:posList>35.668548109444124 139.7382822949648 32.316 35.66856981555887 139.73830645999524 39.654 35.668548109444124 139.7382822949648 39.654 35.668548109444124 139.7382822949648 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c678e156-2fd4-4df5-9490-9a9a513c0d41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c678e156-2fd4-4df5-9490-9a9a513c0d41_0">
											<gml:posList>35.668548109444124 139.7382822949648 32.316 35.66856981555887 139.73830645999524 32.316 35.66856981555887 139.73830645999524 39.654 35.668548109444124 139.7382822949648 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8097a44e-f5bc-41c4-bcfc-e3a4cd3d452d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8097a44e-f5bc-41c4-bcfc-e3a4cd3d452d_0">
											<gml:posList>35.66856981555887 139.73830645999524 32.316 35.66858550078128 139.73828529933934 39.654 35.66856981555887 139.73830645999524 39.654 35.66856981555887 139.73830645999524 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-894bfeea-3c89-4fb5-8d6d-c608e3ea1069">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-894bfeea-3c89-4fb5-8d6d-c608e3ea1069_0">
											<gml:posList>35.66856981555887 139.73830645999524 32.316 35.66858550078128 139.73828529933934 32.316 35.66858550078128 139.73828529933934 39.654 35.66856981555887 139.73830645999524 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3119933a-fb80-4fc1-b2dc-c6e7a393a0ca">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66857395998741 139.73828122599588 38.705 35.668563026101104 139.73826951914194 39.565 35.66857395998741 139.73828122599588 39.565 35.66857395998741 139.73828122599588 38.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b2f15a0-5dff-437e-9d01-ad470143a8d7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668563026101104 139.73826951914194 39.565 35.66857395998741 139.73828122599588 38.705 35.668563026101104 139.73826951914194 38.705 35.668563026101104 139.73826951914194 39.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50f52c5f-91bb-4560-b2e6-51284d67042c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66856469510907 139.73829421603955 38.705 35.668553842260344 139.73828239862902 38.705 35.66855376123272 139.73828252023117 38.705 35.66856469510907 139.73829421603955 38.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6c2cba2-187a-4a68-9f84-f568350dd206">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668548109444124 139.7382822949648 32.316 35.66856379465364 139.7382611232639 32.316 35.66858550078128 139.73828529933934 32.316 35.668548109444124 139.7382822949648 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e25f4da-30a1-4502-b04e-6afe7d84c46a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66856981555887 139.73830645999524 32.316 35.668548109444124 139.7382822949648 32.316 35.66858550078128 139.73828529933934 32.316 35.66856981555887 139.73830645999524 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c2ef42d-fd8e-4f86-a396-0d8629b86422">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66856469510907 139.73829421603955 38.705 35.66855376123272 139.73828252023117 39.565 35.66855376123272 139.73828252023117 38.705 35.66856469510907 139.73829421603955 38.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffe6bb0a-af5c-45a5-8761-7debadf2292e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66856469510907 139.73829421603955 38.705 35.66856469510907 139.73829421603955 39.565 35.66855376123272 139.73828252023117 39.565 35.66856469510907 139.73829421603955 38.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a52e3191-5cee-41da-8e20-9ee74b636092_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41f3e6db-8226-44d6-a700-4419e11b7b4a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858644572272 139.73828339830516 32.316 35.6685965933955 139.7382697113112 32.316 35.66861165055603 139.73828648340336 32.316 35.66858272022076 139.7383254990716 32.316 35.66854425185761 139.73828266405587 32.316 35.668563025486876 139.73825732434887 32.316 35.66858644572272 139.73828339830516 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a737d48-d08a-40d3-9d68-c05282ea6275">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a737d48-d08a-40d3-9d68-c05282ea6275_0">
											<gml:posList>35.66854425185761 139.73828266405587 37.011 35.668563025486876 139.73825732434887 37.011 35.668563025486876 139.73825732434887 32.316 35.66854425185761 139.73828266405587 32.316 35.66854425185761 139.73828266405587 37.011</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fbffbbf-8a78-4762-bc8e-9d5b1916f335">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fbffbbf-8a78-4762-bc8e-9d5b1916f335_0">
											<gml:posList>35.66858644572272 139.73828339830516 37.011 35.66858644572272 139.73828339830516 32.316 35.668563025486876 139.73825732434887 32.316 35.668563025486876 139.73825732434887 37.011 35.66858644572272 139.73828339830516 37.011</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-398fdda5-16e0-40a8-b0b8-3e1d9b88479b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-398fdda5-16e0-40a8-b0b8-3e1d9b88479b_0">
											<gml:posList>35.6685965933955 139.7382697113112 37.011 35.6685965933955 139.7382697113112 32.316 35.66858644572272 139.73828339830516 32.316 35.66858644572272 139.73828339830516 37.011 35.6685965933955 139.7382697113112 37.011</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfcf17a7-eded-4952-84e9-5dcd293326c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfcf17a7-eded-4952-84e9-5dcd293326c6_0">
											<gml:posList>35.6685965933955 139.7382697113112 32.316 35.6685965933955 139.7382697113112 37.011 35.66861165055603 139.73828648340336 37.011 35.66861165055603 139.73828648340336 32.316 35.6685965933955 139.7382697113112 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a269634-1a77-4695-a88e-4f6171b42827">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a269634-1a77-4695-a88e-4f6171b42827_0">
											<gml:posList>35.66854425185761 139.73828266405587 37.011 35.66858272022076 139.7383254990716 37.011 35.66861165055603 139.73828648340336 37.011 35.6685965933955 139.7382697113112 37.011 35.66858644572272 139.73828339830516 37.011 35.668563025486876 139.73825732434887 37.011 35.66854425185761 139.73828266405587 37.011</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b8e23cc-1b46-4ec1-9c1f-4fd28ae18dfe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b8e23cc-1b46-4ec1-9c1f-4fd28ae18dfe_0">
											<gml:posList>35.66858272022076 139.7383254990716 32.316 35.66858272022076 139.7383254990716 37.011 35.66854425185761 139.73828266405587 37.011 35.66854425185761 139.73828266405587 32.316 35.66858272022076 139.7383254990716 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66730a2b-e621-4cae-b12e-ab5eba6b22b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66730a2b-e621-4cae-b12e-ab5eba6b22b7_0">
											<gml:posList>35.66861165055603 139.73828648340336 32.316 35.66861165055603 139.73828648340336 37.011 35.66858272022076 139.7383254990716 37.011 35.66858272022076 139.7383254990716 32.316 35.66861165055603 139.73828648340336 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-4fc254e5-2850-46f1-8b0c-7183656b5a86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fc254e5-2850-46f1-8b0c-7183656b5a86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fc254e5-2850-46f1-8b0c-7183656b5a86">
											<gml:posList>35.66856391914346 139.7383960611623 19.31 35.668486150260065 139.738306680655 19.31 35.668558725966456 139.73821170943276 19.31 35.66857812318597 139.7382341098239 19.31 35.668607387601604 139.7381958559036 19.31 35.668665759356 139.73826283600474 19.31 35.66856391914346 139.7383960611623 19.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d66815a-93e6-4eea-a30e-87753390a7e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d66815a-93e6-4eea-a30e-87753390a7e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d66815a-93e6-4eea-a30e-87753390a7e5">
											<gml:posList>35.66855691813524 139.7383880058657 32.646 35.66855672437889 139.738382339493 32.646 35.668490720070444 139.73830648745724 32.646 35.668486150260065 139.738306680655 32.646 35.66855691813524 139.7383880058657 32.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e72fe96-ff44-427b-a994-778524c83894">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e72fe96-ff44-427b-a994-778524c83894">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e72fe96-ff44-427b-a994-778524c83894">
											<gml:posList>35.668486150260065 139.738306680655 32.646 35.668490720070444 139.73830648745724 32.646 35.66855886560488 139.73821732063934 32.646 35.668558725966456 139.73821170943276 32.646 35.668486150260065 139.738306680655 32.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93487fb2-1c1f-4e96-a005-3427e36d0d7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93487fb2-1c1f-4e96-a005-3427e36d0d7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93487fb2-1c1f-4e96-a005-3427e36d0d7a">
											<gml:posList>35.66857812318597 139.7382341098239 32.646 35.668558725966456 139.73821170943276 32.646 35.66855886560488 139.73821732063934 32.646 35.66857825380961 139.73823972104256 32.646 35.66857812318597 139.7382341098239 32.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-658ca794-e866-4250-a828-ae85c0da9713">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-658ca794-e866-4250-a828-ae85c0da9713">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-658ca794-e866-4250-a828-ae85c0da9713">
											<gml:posList>35.66855672437889 139.738382339493 32.316 35.66865218567653 139.73825268975924 32.316 35.66860752723203 139.73820145606754 32.316 35.66857825380961 139.73823972104256 32.316 35.66855886560488 139.73821732063934 32.316 35.668490720070444 139.73830648745724 32.316 35.66855672437889 139.738382339493 32.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4bb412d2-a9b1-4607-8f68-6990f55e24d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4bb412d2-a9b1-4607-8f68-6990f55e24d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4bb412d2-a9b1-4607-8f68-6990f55e24d7">
											<gml:posList>35.66857812318597 139.7382341098239 32.646 35.66857825380961 139.73823972104256 32.646 35.66860752723203 139.73820145606754 32.646 35.668607387601604 139.7381958559036 32.646 35.66857812318597 139.7382341098239 32.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-218e1d6d-4079-4ca6-bc03-91f54837b4c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-218e1d6d-4079-4ca6-bc03-91f54837b4c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-218e1d6d-4079-4ca6-bc03-91f54837b4c2">
											<gml:posList>35.66865671940562 139.7382524634627 32.646 35.66865218567653 139.73825268975924 32.646 35.66855672437889 139.738382339493 32.646 35.66855691813524 139.7383880058657 32.646 35.66865671940562 139.7382524634627 32.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-501e33e9-73b0-42ec-b695-b26c8e6164e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-501e33e9-73b0-42ec-b695-b26c8e6164e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-501e33e9-73b0-42ec-b695-b26c8e6164e9">
											<gml:posList>35.66865671940562 139.7382524634627 32.646 35.66855691813524 139.7383880058657 32.646 35.66856391914346 139.7383960611623 30.304 35.66865671940562 139.7382524634627 32.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-14755da4-3bfe-4a39-bafd-3569167b7dda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14755da4-3bfe-4a39-bafd-3569167b7dda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14755da4-3bfe-4a39-bafd-3569167b7dda">
											<gml:posList>35.66856391914346 139.7383960611623 30.304 35.668665759356 139.73826283600474 30.304 35.66865671940562 139.7382524634627 32.646 35.66856391914346 139.7383960611623 30.304</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0c4fa686-bbed-4717-b21b-ba709335c70b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c4fa686-bbed-4717-b21b-ba709335c70b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c4fa686-bbed-4717-b21b-ba709335c70b">
											<gml:posList>35.668607387601604 139.7381958559036 32.646 35.66860752723203 139.73820145606754 32.646 35.66865218567653 139.73825268975924 32.646 35.66865671940562 139.7382524634627 32.646 35.668607387601604 139.7381958559036 32.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1955086-3d35-44c9-87ae-a92653b30d2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1955086-3d35-44c9-87ae-a92653b30d2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1955086-3d35-44c9-87ae-a92653b30d2b">
											<gml:posList>35.668607387601604 139.7381958559036 19.31 35.66857812318597 139.7382341098239 19.31 35.66857812318597 139.7382341098239 32.646 35.668607387601604 139.7381958559036 32.646 35.668607387601604 139.7381958559036 19.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79106108-127f-4d99-8d86-e496e75cefd6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79106108-127f-4d99-8d86-e496e75cefd6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79106108-127f-4d99-8d86-e496e75cefd6">
											<gml:posList>35.66857825380961 139.73823972104256 32.646 35.66857825380961 139.73823972104256 32.316 35.66860752723203 139.73820145606754 32.316 35.66860752723203 139.73820145606754 32.646 35.66857825380961 139.73823972104256 32.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14616ce9-99ba-4459-93e8-e9363e8d92d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14616ce9-99ba-4459-93e8-e9363e8d92d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14616ce9-99ba-4459-93e8-e9363e8d92d2">
											<gml:posList>35.66857812318597 139.7382341098239 19.31 35.668558725966456 139.73821170943276 19.31 35.668558725966456 139.73821170943276 32.646 35.66857812318597 139.7382341098239 32.646 35.66857812318597 139.7382341098239 19.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-321b8873-e031-452c-bd9d-8cd50f36108e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-321b8873-e031-452c-bd9d-8cd50f36108e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-321b8873-e031-452c-bd9d-8cd50f36108e">
											<gml:posList>35.66860752723203 139.73820145606754 32.646 35.66860752723203 139.73820145606754 32.316 35.66865218567653 139.73825268975924 32.316 35.66865218567653 139.73825268975924 32.646 35.66860752723203 139.73820145606754 32.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea9c13f9-0d90-4ddd-8528-2bbc70f259e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea9c13f9-0d90-4ddd-8528-2bbc70f259e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea9c13f9-0d90-4ddd-8528-2bbc70f259e2">
											<gml:posList>35.66855886560488 139.73821732063934 32.646 35.66855886560488 139.73821732063934 32.316 35.66857825380961 139.73823972104256 32.316 35.66857825380961 139.73823972104256 32.646 35.66855886560488 139.73821732063934 32.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6b7f1e7-217d-4de5-92e2-635334a0d883">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6b7f1e7-217d-4de5-92e2-635334a0d883">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6b7f1e7-217d-4de5-92e2-635334a0d883">
											<gml:posList>35.668607387601604 139.7381958559036 32.646 35.66865671940562 139.7382524634627 32.646 35.668665759356 139.73826283600474 30.304 35.668665759356 139.73826283600474 19.31 35.668607387601604 139.7381958559036 19.31 35.668607387601604 139.7381958559036 32.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9a51563-e6e3-4872-adcf-bfa39897114c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9a51563-e6e3-4872-adcf-bfa39897114c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9a51563-e6e3-4872-adcf-bfa39897114c">
											<gml:posList>35.668558725966456 139.73821170943276 19.31 35.668486150260065 139.738306680655 19.31 35.668486150260065 139.738306680655 32.646 35.668558725966456 139.73821170943276 32.646 35.668558725966456 139.73821170943276 19.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ff32631-98ce-45e3-b3d4-52dae960d4ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ff32631-98ce-45e3-b3d4-52dae960d4ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ff32631-98ce-45e3-b3d4-52dae960d4ad">
											<gml:posList>35.668490720070444 139.73830648745724 32.646 35.668490720070444 139.73830648745724 32.316 35.66855886560488 139.73821732063934 32.316 35.66855886560488 139.73821732063934 32.646 35.668490720070444 139.73830648745724 32.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5c38458-c894-4352-998e-a901f9832e53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5c38458-c894-4352-998e-a901f9832e53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5c38458-c894-4352-998e-a901f9832e53">
											<gml:posList>35.66865218567653 139.73825268975924 32.646 35.66865218567653 139.73825268975924 32.316 35.66855672437889 139.738382339493 32.316 35.66855672437889 139.738382339493 32.646 35.66865218567653 139.73825268975924 32.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25c9c2be-bcac-408b-97eb-2d2676853244">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25c9c2be-bcac-408b-97eb-2d2676853244">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25c9c2be-bcac-408b-97eb-2d2676853244">
											<gml:posList>35.66856391914346 139.7383960611623 19.31 35.668665759356 139.73826283600474 19.31 35.668665759356 139.73826283600474 30.304 35.66856391914346 139.7383960611623 30.304 35.66856391914346 139.7383960611623 19.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b64134d-7e0d-4a5b-b426-1b33f9133b12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b64134d-7e0d-4a5b-b426-1b33f9133b12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b64134d-7e0d-4a5b-b426-1b33f9133b12">
											<gml:posList>35.66855672437889 139.738382339493 32.646 35.66855672437889 139.738382339493 32.316 35.668490720070444 139.73830648745724 32.316 35.668490720070444 139.73830648745724 32.646 35.66855672437889 139.738382339493 32.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11e4e1be-27d4-4b32-bd76-1217379133ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11e4e1be-27d4-4b32-bd76-1217379133ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11e4e1be-27d4-4b32-bd76-1217379133ae">
											<gml:posList>35.66855691813524 139.7383880058657 32.646 35.668486150260065 139.738306680655 32.646 35.668486150260065 139.738306680655 19.31 35.66856391914346 139.7383960611623 19.31 35.66856391914346 139.7383960611623 30.304 35.66855691813524 139.7383880058657 32.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9635</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">181.41865</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>