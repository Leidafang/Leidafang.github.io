<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a61d487d-5896-42ac-a002-fc5b5af3bfea">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67344539625227 139.74046713423436 0 35.67350245142909 139.74038314644105 0 35.67348598840513 139.74036634142405 0 35.67342893323984 139.74045032921202 0 35.67344539625227 139.74046713423436 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67344539625227 139.74046713423436 8.194 35.67342893323984 139.74045032921202 8.194 35.67348598840513 139.74036634142405 8.194 35.67350245142909 139.74038314644105 8.194 35.67344539625227 139.74046713423436 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67344539625227 139.74046713423436 8.194 35.67350245142909 139.74038314644105 8.194 35.67350245142909 139.74038314644105 11.194 35.67344539625227 139.74046713423436 11.194 35.67344539625227 139.74046713423436 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67350245142909 139.74038314644105 8.194 35.67348598840513 139.74036634142405 8.194 35.67348598840513 139.74036634142405 11.194 35.67350245142909 139.74038314644105 11.194 35.67350245142909 139.74038314644105 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67348598840513 139.74036634142405 8.194 35.67342893323984 139.74045032921202 8.194 35.67342893323984 139.74045032921202 11.194 35.67348598840513 139.74036634142405 11.194 35.67348598840513 139.74036634142405 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67342893323984 139.74045032921202 8.194 35.67344539625227 139.74046713423436 8.194 35.67344539625227 139.74046713423436 11.194 35.67342893323984 139.74045032921202 11.194 35.67342893323984 139.74045032921202 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67344539625227 139.74046713423436 11.194 35.67350245142909 139.74038314644105 11.194 35.67348598840513 139.74036634142405 11.194 35.67342893323984 139.74045032921202 11.194 35.67344539625227 139.74046713423436 11.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6916782e-ab3a-4095-b33f-d7d4208a1fc2"/>
							<gml:surfaceMember xlink:href="#poly-58ec8886-c1c3-4d78-bc89-c3249b8cb417"/>
							<gml:surfaceMember xlink:href="#poly-2ba3018d-48fe-4093-85ba-0af1eb7118eb"/>
							<gml:surfaceMember xlink:href="#poly-55489daf-aaa3-43e4-8fee-212c856db9b3"/>
							<gml:surfaceMember xlink:href="#poly-6777d4e4-1a80-4b2a-a190-e6462bb4c19b"/>
							<gml:surfaceMember xlink:href="#poly-b11ba963-cc62-43f1-94d0-f92a112953b3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6916782e-ab3a-4095-b33f-d7d4208a1fc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6916782e-ab3a-4095-b33f-d7d4208a1fc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6916782e-ab3a-4095-b33f-d7d4208a1fc2">
											<gml:posList>35.67350245142909 139.74038314644102 8.194 35.67344590063708 139.7404666365494 8.194 35.67342942861939 139.74044984258416 8.194 35.67348598840512 139.74036634142402 8.194 35.67350245142909 139.74038314644102 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-58ec8886-c1c3-4d78-bc89-c3249b8cb417">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58ec8886-c1c3-4d78-bc89-c3249b8cb417">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58ec8886-c1c3-4d78-bc89-c3249b8cb417">
											<gml:posList>35.67344590063708 139.7404666365494 11.65 35.67350245142909 139.74038314644102 11.65 35.67348598840512 139.74036634142402 11.65 35.67342942861939 139.74044984258416 11.65 35.67344590063708 139.7404666365494 11.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ba3018d-48fe-4093-85ba-0af1eb7118eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ba3018d-48fe-4093-85ba-0af1eb7118eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ba3018d-48fe-4093-85ba-0af1eb7118eb">
											<gml:posList>35.67342942861939 139.74044984258416 8.194 35.67344590063708 139.7404666365494 8.194 35.67344590063708 139.7404666365494 11.65 35.67342942861939 139.74044984258416 11.65 35.67342942861939 139.74044984258416 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55489daf-aaa3-43e4-8fee-212c856db9b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55489daf-aaa3-43e4-8fee-212c856db9b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55489daf-aaa3-43e4-8fee-212c856db9b3">
											<gml:posList>35.67348598840512 139.74036634142402 8.194 35.67342942861939 139.74044984258416 8.194 35.67342942861939 139.74044984258416 11.65 35.67348598840512 139.74036634142402 11.65 35.67348598840512 139.74036634142402 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6777d4e4-1a80-4b2a-a190-e6462bb4c19b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6777d4e4-1a80-4b2a-a190-e6462bb4c19b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6777d4e4-1a80-4b2a-a190-e6462bb4c19b">
											<gml:posList>35.67344590063708 139.7404666365494 8.194 35.67350245142909 139.74038314644102 8.194 35.67350245142909 139.74038314644102 11.65 35.67344590063708 139.7404666365494 11.65 35.67344590063708 139.7404666365494 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b11ba963-cc62-43f1-94d0-f92a112953b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b11ba963-cc62-43f1-94d0-f92a112953b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b11ba963-cc62-43f1-94d0-f92a112953b3">
											<gml:posList>35.67350245142909 139.74038314644102 8.194 35.67348598840512 139.74036634142402 8.194 35.67348598840512 139.74036634142402 11.65 35.67350245142909 139.74038314644102 11.65 35.67350245142909 139.74038314644102 8.194</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4513</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">1.25</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>