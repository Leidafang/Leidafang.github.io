<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a69dd95c-7c82-4d6a-96d5-8390bfd7c0c4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>霞が関三丁目南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:measuredHeight uom="m">6.2</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67064177797466 139.74741588379092 0 35.670573369641225 139.7474241313494 0 35.67057555247682 139.74745152380234 0 35.67064396081215 139.74744327626703 0 35.67064177797466 139.74741588379092 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064177797466 139.74741588379092 8.559 35.67064396081215 139.74744327626703 8.559 35.67057555247682 139.74745152380234 8.559 35.670573369641225 139.7474241313494 8.559 35.67064177797466 139.74741588379092 8.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064177797466 139.74741588379092 8.559 35.670573369641225 139.7474241313494 8.559 35.670573369641225 139.7474241313494 14.72 35.67064177797466 139.74741588379092 14.72 35.67064177797466 139.74741588379092 8.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670573369641225 139.7474241313494 8.559 35.67057555247682 139.74745152380234 8.559 35.67057555247682 139.74745152380234 14.72 35.670573369641225 139.7474241313494 14.72 35.670573369641225 139.7474241313494 8.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67057555247682 139.74745152380234 8.559 35.67064396081215 139.74744327626703 8.559 35.67064396081215 139.74744327626703 14.72 35.67057555247682 139.74745152380234 14.72 35.67057555247682 139.74745152380234 8.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064396081215 139.74744327626703 8.559 35.67064177797466 139.74741588379092 8.559 35.67064177797466 139.74741588379092 14.72 35.67064396081215 139.74744327626703 14.72 35.67064396081215 139.74744327626703 8.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064177797466 139.74741588379092 14.72 35.670573369641225 139.7474241313494 14.72 35.67057555247682 139.74745152380234 14.72 35.67064396081215 139.74744327626703 14.72 35.67064177797466 139.74741588379092 14.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-414491cd-f02c-4454-b279-f5e448b211b3"/>
							<gml:surfaceMember xlink:href="#poly-af91befc-4ca2-4fbf-9b81-954e3bc83585"/>
							<gml:surfaceMember xlink:href="#poly-f54a3472-7c82-4c6d-8d0c-7a193fa0efbd"/>
							<gml:surfaceMember xlink:href="#poly-9a9774fd-dcac-4ec6-9b61-8cef4291dca1"/>
							<gml:surfaceMember xlink:href="#poly-ef23a69a-51ba-4ec5-8254-7fca52ebffbc"/>
							<gml:surfaceMember xlink:href="#poly-2d7a167d-dad9-4bbf-8a25-9deafe6d6429"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-414491cd-f02c-4454-b279-f5e448b211b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-414491cd-f02c-4454-b279-f5e448b211b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-414491cd-f02c-4454-b279-f5e448b211b3">
											<gml:posList>35.670641777974645 139.74741588379092 8.559 35.670643960812136 139.74744327626703 8.559 35.670575552476826 139.7474515238023 8.559 35.67057336964122 139.7474241313494 8.559 35.670641777974645 139.74741588379092 8.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af91befc-4ca2-4fbf-9b81-954e3bc83585">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af91befc-4ca2-4fbf-9b81-954e3bc83585">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af91befc-4ca2-4fbf-9b81-954e3bc83585">
											<gml:posList>35.670643960812136 139.74744327626703 15 35.670641777974645 139.74741588379092 15 35.67057336964122 139.7474241313494 15 35.670575552476826 139.7474515238023 15 35.670643960812136 139.74744327626703 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f54a3472-7c82-4c6d-8d0c-7a193fa0efbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f54a3472-7c82-4c6d-8d0c-7a193fa0efbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f54a3472-7c82-4c6d-8d0c-7a193fa0efbd">
											<gml:posList>35.670641777974645 139.74741588379092 8.559 35.67057336964122 139.7474241313494 8.559 35.67057336964122 139.7474241313494 15 35.670641777974645 139.74741588379092 15 35.670641777974645 139.74741588379092 8.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a9774fd-dcac-4ec6-9b61-8cef4291dca1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a9774fd-dcac-4ec6-9b61-8cef4291dca1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a9774fd-dcac-4ec6-9b61-8cef4291dca1">
											<gml:posList>35.670643960812136 139.74744327626703 8.559 35.670641777974645 139.74741588379092 8.559 35.670641777974645 139.74741588379092 15 35.670643960812136 139.74744327626703 15 35.670643960812136 139.74744327626703 8.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef23a69a-51ba-4ec5-8254-7fca52ebffbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef23a69a-51ba-4ec5-8254-7fca52ebffbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef23a69a-51ba-4ec5-8254-7fca52ebffbc">
											<gml:posList>35.67057336964122 139.7474241313494 8.559 35.670575552476826 139.7474515238023 8.559 35.670575552476826 139.7474515238023 15 35.67057336964122 139.7474241313494 15 35.67057336964122 139.7474241313494 8.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d7a167d-dad9-4bbf-8a25-9deafe6d6429">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d7a167d-dad9-4bbf-8a25-9deafe6d6429">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d7a167d-dad9-4bbf-8a25-9deafe6d6429">
											<gml:posList>35.670575552476826 139.7474515238023 8.559 35.670643960812136 139.74744327626703 8.559 35.670643960812136 139.74744327626703 15 35.670575552476826 139.7474515238023 15 35.670575552476826 139.7474515238023 8.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-1057</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>