<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a717dd43-46c1-475b-8df9-b1b4ee84ceb5">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">10</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668789178205124 139.74823055931873 0 35.66881880741492 139.74813009722936 0 35.66878486908488 139.7481150664938 0 35.668755239887346 139.74821552854618 0 35.668789178205124 139.74823055931873 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668789178205124 139.74823055931873 5.63 35.668755239887346 139.74821552854618 5.63 35.66878486908488 139.7481150664938 5.63 35.66881880741492 139.74813009722936 5.63 35.668789178205124 139.74823055931873 5.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668789178205124 139.74823055931873 5.63 35.66881880741492 139.74813009722936 5.63 35.66881880741492 139.74813009722936 15.59 35.668789178205124 139.74823055931873 15.59 35.668789178205124 139.74823055931873 5.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881880741492 139.74813009722936 5.63 35.66878486908488 139.7481150664938 5.63 35.66878486908488 139.7481150664938 15.59 35.66881880741492 139.74813009722936 15.59 35.66881880741492 139.74813009722936 5.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66878486908488 139.7481150664938 5.63 35.668755239887346 139.74821552854618 5.63 35.668755239887346 139.74821552854618 15.59 35.66878486908488 139.7481150664938 15.59 35.66878486908488 139.7481150664938 5.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668755239887346 139.74821552854618 5.63 35.668789178205124 139.74823055931873 5.63 35.668789178205124 139.74823055931873 15.59 35.668755239887346 139.74821552854618 15.59 35.668755239887346 139.74821552854618 5.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668789178205124 139.74823055931873 15.59 35.66881880741492 139.74813009722936 15.59 35.66878486908488 139.7481150664938 15.59 35.668755239887346 139.74821552854618 15.59 35.668789178205124 139.74823055931873 15.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ab7ae56d-ae87-4076-82cd-88b86a928583"/>
							<gml:surfaceMember xlink:href="#poly-34a240cf-bc5b-4bc4-8abc-caf2291fd21b"/>
							<gml:surfaceMember xlink:href="#poly-dcec9059-cf69-42e4-861a-4b1e72087624"/>
							<gml:surfaceMember xlink:href="#poly-eb66d44f-7922-4f93-b1a2-fa57dbbecb1b"/>
							<gml:surfaceMember xlink:href="#poly-79e890bf-6135-40b9-a1ca-c504a29f28d0"/>
							<gml:surfaceMember xlink:href="#poly-99d4875e-4222-4891-8089-f1d3a1c1fa26"/>
							<gml:surfaceMember xlink:href="#poly-362fca3f-0c49-4db5-a159-ffaa52ec67a7"/>
							<gml:surfaceMember xlink:href="#poly-a714ee3c-11c1-453e-ad0e-14cc42c9ede6"/>
							<gml:surfaceMember xlink:href="#poly-373e67e3-976c-4bbb-81b8-50c00e5c70e7"/>
							<gml:surfaceMember xlink:href="#poly-afd983a2-23a9-41bc-99cd-6b921ca7d66e"/>
							<gml:surfaceMember xlink:href="#poly-f211ff65-9178-4864-a5f6-24b13af7c1d4"/>
							<gml:surfaceMember xlink:href="#poly-f292f2dc-43b2-4c20-b21a-b7e5a77cc15c"/>
							<gml:surfaceMember xlink:href="#poly-2d9929d1-8390-4201-9e9e-d3b1d002ecac"/>
							<gml:surfaceMember xlink:href="#poly-52d68f2a-66a1-40e2-8723-904e7c767a9b"/>
							<gml:surfaceMember xlink:href="#poly-3c29d90a-afc6-4d54-88c1-18be37bfa3f7"/>
							<gml:surfaceMember xlink:href="#poly-7b7d966f-1b6d-4412-abf2-95a026f3ffa9"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a717dd43-46c1-475b-8df9-b1b4ee84ceb5_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af5fb463-9f05-44d0-b04a-252c6a915352">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668798081854085 139.74817684401137 15.504 35.668793325449414 139.74819361695396 15.504 35.66877678908801 139.74818629994263 15.504 35.66878147355372 139.74816977009235 15.504 35.668798081854085 139.74817684401137 15.504</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d794053-2481-4550-bde1-2f9eb8f73538">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668793325449414 139.74819361695396 15.8 35.66879252522706 139.74819644559025 15.8 35.66877591693565 139.7481893827137 15.8 35.66877678908801 139.74818629994263 15.8 35.668793325449414 139.74819361695396 15.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c24bb4f-5e31-4ed8-aed4-27f8d67cb836">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c24bb4f-5e31-4ed8-aed4-27f8d67cb836_0">
											<gml:posList>35.66878147355372 139.74816977009235 15.504 35.66878147355372 139.74816977009235 18.316 35.668798081854085 139.74817684401137 18.316 35.668798081854085 139.74817684401137 15.504 35.66878147355372 139.74816977009235 15.504</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b783a5e-5ca4-4083-adbb-8a178a9d510a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b783a5e-5ca4-4083-adbb-8a178a9d510a_0">
											<gml:posList>35.66877678908801 139.74818629994263 15.8 35.66877591693565 139.7481893827137 15.8 35.66877591693565 139.7481893827137 18.316 35.66878147355372 139.74816977009235 18.316 35.66878147355372 139.74816977009235 15.504 35.66877678908801 139.74818629994263 15.504 35.66877678908801 139.74818629994263 15.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a4f15dc-0818-4106-9a22-e78ae49e10fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a4f15dc-0818-4106-9a22-e78ae49e10fb_0">
											<gml:posList>35.668798081854085 139.74817684401137 18.316 35.66878147355372 139.74816977009235 18.316 35.66877591693565 139.7481893827137 18.316 35.66879252522706 139.74819644559025 18.316 35.668798081854085 139.74817684401137 18.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f964e469-2725-4a77-85bb-e1e3c2be3b3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f964e469-2725-4a77-85bb-e1e3c2be3b3f_0">
											<gml:posList>35.668798081854085 139.74817684401137 15.504 35.668798081854085 139.74817684401137 18.316 35.66879252522706 139.74819644559025 18.316 35.66879252522706 139.74819644559025 15.8 35.668793325449414 139.74819361695396 15.8 35.668793325449414 139.74819361695396 15.504 35.668798081854085 139.74817684401137 15.504</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a46c436-9af7-4e38-bbb6-bf3d2242de92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a46c436-9af7-4e38-bbb6-bf3d2242de92_0">
											<gml:posList>35.66877678908801 139.74818629994263 15.504 35.668793325449414 139.74819361695396 15.504 35.668793325449414 139.74819361695396 15.8 35.66877678908801 139.74818629994263 15.8 35.66877678908801 139.74818629994263 15.504</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-394191d6-2a50-4263-aaac-12137ba4c637">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-394191d6-2a50-4263-aaac-12137ba4c637_0">
											<gml:posList>35.66879252522706 139.74819644559025 15.8 35.66879252522706 139.74819644559025 18.316 35.66877591693565 139.7481893827137 18.316 35.66877591693565 139.7481893827137 15.8 35.66879252522706 139.74819644559025 15.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ab7ae56d-ae87-4076-82cd-88b86a928583">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab7ae56d-ae87-4076-82cd-88b86a928583">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab7ae56d-ae87-4076-82cd-88b86a928583">
											<gml:posList>35.668789178205124 139.74823055931873 5.63 35.668755239887375 139.74821552854615 5.63 35.66878486908485 139.7481150664938 5.63 35.66881880741492 139.74813009722934 5.63 35.668789178205124 139.74823055931873 5.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-34a240cf-bc5b-4bc4-8abc-caf2291fd21b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34a240cf-bc5b-4bc4-8abc-caf2291fd21b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34a240cf-bc5b-4bc4-8abc-caf2291fd21b">
											<gml:posList>35.66877765736521 139.74813950799765 15.748 35.668765356089104 139.74818123090617 15.748 35.668766420044776 139.7481817047559 15.748 35.66877872132104 139.7481399818469 15.748 35.66877765736521 139.74813950799765 15.748</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dcec9059-cf69-42e4-861a-4b1e72087624">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcec9059-cf69-42e4-861a-4b1e72087624">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcec9059-cf69-42e4-861a-4b1e72087624">
											<gml:posList>35.668755239887375 139.74821552854615 15.8 35.668789178205124 139.74823055931873 15.8 35.668799294411066 139.74819626166612 15.8 35.66879753617981 139.748195479264 15.8 35.668766420044776 139.7481817047559 15.8 35.668765356089104 139.74818123090617 15.8 35.668755239887375 139.74821552854615 15.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eb66d44f-7922-4f93-b1a2-fa57dbbecb1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb66d44f-7922-4f93-b1a2-fa57dbbecb1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb66d44f-7922-4f93-b1a2-fa57dbbecb1b">
											<gml:posList>35.66879753617981 139.748195479264 15.504 35.668809837460756 139.74815375634088 15.504 35.66877872132104 139.7481399818469 15.504 35.668766420044776 139.7481817047559 15.504 35.66879753617981 139.748195479264 15.504</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79e890bf-6135-40b9-a1ca-c504a29f28d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79e890bf-6135-40b9-a1ca-c504a29f28d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79e890bf-6135-40b9-a1ca-c504a29f28d0">
											<gml:posList>35.66881159569228 139.7481545387422 17.6 35.66881880741492 139.74813009722934 17.6 35.66878486908485 139.7481150664938 17.6 35.66877765736521 139.74813950799765 17.6 35.66881159569228 139.7481545387422 17.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-99d4875e-4222-4891-8089-f1d3a1c1fa26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99d4875e-4222-4891-8089-f1d3a1c1fa26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99d4875e-4222-4891-8089-f1d3a1c1fa26">
											<gml:posList>35.668799294411066 139.74819626166612 15.748 35.66881159569228 139.7481545387422 15.748 35.668809837460756 139.74815375634088 15.748 35.66879753617981 139.748195479264 15.748 35.668799294411066 139.74819626166612 15.748</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-362fca3f-0c49-4db5-a159-ffaa52ec67a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-362fca3f-0c49-4db5-a159-ffaa52ec67a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-362fca3f-0c49-4db5-a159-ffaa52ec67a7">
											<gml:posList>35.668766420044776 139.7481817047559 15.8 35.668766420044776 139.7481817047559 15.748 35.668765356089104 139.74818123090617 15.748 35.668765356089104 139.74818123090617 15.8 35.668766420044776 139.7481817047559 15.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a714ee3c-11c1-453e-ad0e-14cc42c9ede6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a714ee3c-11c1-453e-ad0e-14cc42c9ede6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a714ee3c-11c1-453e-ad0e-14cc42c9ede6">
											<gml:posList>35.668799294411066 139.74819626166612 15.8 35.668799294411066 139.74819626166612 15.748 35.66879753617981 139.748195479264 15.748 35.66879753617981 139.748195479264 15.8 35.668799294411066 139.74819626166612 15.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-373e67e3-976c-4bbb-81b8-50c00e5c70e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-373e67e3-976c-4bbb-81b8-50c00e5c70e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-373e67e3-976c-4bbb-81b8-50c00e5c70e7">
											<gml:posList>35.66878486908485 139.7481150664938 17.6 35.66881880741492 139.74813009722934 17.6 35.66881880741492 139.74813009722934 5.63 35.66878486908485 139.7481150664938 5.63 35.66878486908485 139.7481150664938 17.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afd983a2-23a9-41bc-99cd-6b921ca7d66e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afd983a2-23a9-41bc-99cd-6b921ca7d66e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afd983a2-23a9-41bc-99cd-6b921ca7d66e">
											<gml:posList>35.66877872132104 139.7481399818469 15.748 35.66877872132104 139.7481399818469 15.504 35.668809837460756 139.74815375634088 15.504 35.668809837460756 139.74815375634088 15.748 35.66881159569228 139.7481545387422 15.748 35.66881159569228 139.7481545387422 17.6 35.66877765736521 139.74813950799765 17.6 35.66877765736521 139.74813950799765 15.748 35.66877872132104 139.7481399818469 15.748</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f211ff65-9178-4864-a5f6-24b13af7c1d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f211ff65-9178-4864-a5f6-24b13af7c1d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f211ff65-9178-4864-a5f6-24b13af7c1d4">
											<gml:posList>35.668766420044776 139.7481817047559 15.748 35.668766420044776 139.7481817047559 15.504 35.66877872132104 139.7481399818469 15.504 35.66877872132104 139.7481399818469 15.748 35.668766420044776 139.7481817047559 15.748</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f292f2dc-43b2-4c20-b21a-b7e5a77cc15c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f292f2dc-43b2-4c20-b21a-b7e5a77cc15c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f292f2dc-43b2-4c20-b21a-b7e5a77cc15c">
											<gml:posList>35.66877765736521 139.74813950799765 15.748 35.66877765736521 139.74813950799765 17.6 35.66878486908485 139.7481150664938 17.6 35.66878486908485 139.7481150664938 5.63 35.668755239887375 139.74821552854615 5.63 35.668755239887375 139.74821552854615 15.8 35.668765356089104 139.74818123090617 15.8 35.668765356089104 139.74818123090617 15.748 35.66877765736521 139.74813950799765 15.748</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d9929d1-8390-4201-9e9e-d3b1d002ecac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d9929d1-8390-4201-9e9e-d3b1d002ecac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d9929d1-8390-4201-9e9e-d3b1d002ecac">
											<gml:posList>35.668809837460756 139.74815375634088 15.748 35.668809837460756 139.74815375634088 15.504 35.66879753617981 139.748195479264 15.504 35.66879753617981 139.748195479264 15.748 35.668809837460756 139.74815375634088 15.748</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52d68f2a-66a1-40e2-8723-904e7c767a9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52d68f2a-66a1-40e2-8723-904e7c767a9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52d68f2a-66a1-40e2-8723-904e7c767a9b">
											<gml:posList>35.66881880741492 139.74813009722934 17.6 35.66881159569228 139.7481545387422 17.6 35.66881159569228 139.7481545387422 15.748 35.668799294411066 139.74819626166612 15.748 35.668799294411066 139.74819626166612 15.8 35.668789178205124 139.74823055931873 15.8 35.668789178205124 139.74823055931873 5.63 35.66881880741492 139.74813009722934 5.63 35.66881880741492 139.74813009722934 17.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c29d90a-afc6-4d54-88c1-18be37bfa3f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c29d90a-afc6-4d54-88c1-18be37bfa3f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c29d90a-afc6-4d54-88c1-18be37bfa3f7">
											<gml:posList>35.668766420044776 139.7481817047559 15.748 35.668766420044776 139.7481817047559 15.8 35.66879753617981 139.748195479264 15.8 35.66879753617981 139.748195479264 15.748 35.66879753617981 139.748195479264 15.504 35.668766420044776 139.7481817047559 15.504 35.668766420044776 139.7481817047559 15.748</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b7d966f-1b6d-4412-abf2-95a026f3ffa9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b7d966f-1b6d-4412-abf2-95a026f3ffa9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b7d966f-1b6d-4412-abf2-95a026f3ffa9">
											<gml:posList>35.668755239887375 139.74821552854615 5.63 35.668789178205124 139.74823055931873 5.63 35.668789178205124 139.74823055931873 15.8 35.668755239887375 139.74821552854615 15.8 35.668755239887375 139.74821552854615 5.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-842</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">25.61363</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.25</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>