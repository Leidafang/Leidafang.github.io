<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a7ce41f7-fb2d-41f3-8be5-45dd8b0ac0d4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">28.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66902111414607 139.74984514961085 0 35.66902713143088 139.7498265417569 0 35.66894742318967 139.74978785308966 0 35.66890802738261 139.74990951123146 0 35.66898773566184 139.74994831046146 0 35.669006012431765 139.7498918128933 0 35.66898355182014 139.74988113262722 0 35.668998581213735 139.7498341711873 0 35.66902111414607 139.74984514961085 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66902111414607 139.74984514961085 6.05 35.668998581213735 139.7498341711873 6.05 35.66898355182014 139.74988113262722 6.05 35.669006012431765 139.7498918128933 6.05 35.66898773566184 139.74994831046146 6.05 35.66890802738261 139.74990951123146 6.05 35.66894742318967 139.74978785308966 6.05 35.66902713143088 139.7498265417569 6.05 35.66902111414607 139.74984514961085 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66902111414607 139.74984514961085 6.05 35.66902713143088 139.7498265417569 6.05 35.66902713143088 139.7498265417569 31.27 35.66902111414607 139.74984514961085 31.27 35.66902111414607 139.74984514961085 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66902713143088 139.7498265417569 6.05 35.66894742318967 139.74978785308966 6.05 35.66894742318967 139.74978785308966 31.27 35.66902713143088 139.7498265417569 31.27 35.66902713143088 139.7498265417569 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66894742318967 139.74978785308966 6.05 35.66890802738261 139.74990951123146 6.05 35.66890802738261 139.74990951123146 31.27 35.66894742318967 139.74978785308966 31.27 35.66894742318967 139.74978785308966 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890802738261 139.74990951123146 6.05 35.66898773566184 139.74994831046146 6.05 35.66898773566184 139.74994831046146 31.27 35.66890802738261 139.74990951123146 31.27 35.66890802738261 139.74990951123146 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898773566184 139.74994831046146 6.05 35.669006012431765 139.7498918128933 6.05 35.669006012431765 139.7498918128933 31.27 35.66898773566184 139.74994831046146 31.27 35.66898773566184 139.74994831046146 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669006012431765 139.7498918128933 6.05 35.66898355182014 139.74988113262722 6.05 35.66898355182014 139.74988113262722 31.27 35.669006012431765 139.7498918128933 31.27 35.669006012431765 139.7498918128933 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898355182014 139.74988113262722 6.05 35.668998581213735 139.7498341711873 6.05 35.668998581213735 139.7498341711873 31.27 35.66898355182014 139.74988113262722 31.27 35.66898355182014 139.74988113262722 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668998581213735 139.7498341711873 6.05 35.66902111414607 139.74984514961085 6.05 35.66902111414607 139.74984514961085 31.27 35.668998581213735 139.7498341711873 31.27 35.668998581213735 139.7498341711873 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66902111414607 139.74984514961085 31.27 35.66902713143088 139.7498265417569 31.27 35.66894742318967 139.74978785308966 31.27 35.66890802738261 139.74990951123146 31.27 35.66898773566184 139.74994831046146 31.27 35.669006012431765 139.7498918128933 31.27 35.66898355182014 139.74988113262722 31.27 35.668998581213735 139.7498341711873 31.27 35.66902111414607 139.74984514961085 31.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d76063fd-ead2-4761-b56a-93512d01dfde"/>
							<gml:surfaceMember xlink:href="#poly-a506acbe-4c1c-4692-93cb-8b2e652fd04e"/>
							<gml:surfaceMember xlink:href="#poly-5588bde9-ca49-46f9-a022-e9dd31a68727"/>
							<gml:surfaceMember xlink:href="#poly-9beda39a-afa0-4fc4-8ecb-5744c04fe255"/>
							<gml:surfaceMember xlink:href="#poly-9db894cd-b10a-4760-8450-c6a0e6e2f5da"/>
							<gml:surfaceMember xlink:href="#poly-e9785336-f06b-431d-ba52-e13777503a6f"/>
							<gml:surfaceMember xlink:href="#poly-0a556233-fdad-49ee-8030-00da0f759deb"/>
							<gml:surfaceMember xlink:href="#poly-677974dd-d07f-4cf8-8b11-d78693d64f4c"/>
							<gml:surfaceMember xlink:href="#poly-942b9347-f4cd-40ea-b1b4-99d030a90eda"/>
							<gml:surfaceMember xlink:href="#poly-8049ee65-8d61-40bf-bc9e-fe9f6baf30f9"/>
							<gml:surfaceMember xlink:href="#poly-dbb6001f-4f2c-43c3-96fd-029449176ba7"/>
							<gml:surfaceMember xlink:href="#poly-c5c128a0-afd9-4c2b-ab84-517f8620480a"/>
							<gml:surfaceMember xlink:href="#poly-8412a1b7-e051-4d39-9539-434de5ef745d"/>
							<gml:surfaceMember xlink:href="#poly-fa7fa359-7339-48d1-9994-a0ef090b3396"/>
							<gml:surfaceMember xlink:href="#poly-e047e8e6-31b5-427b-a66a-837f812d62df"/>
							<gml:surfaceMember xlink:href="#poly-db50420f-bbe4-4a30-88ed-a3acad7591ed"/>
							<gml:surfaceMember xlink:href="#poly-31752549-bf6b-4fa3-b14c-1c030a799b20"/>
							<gml:surfaceMember xlink:href="#poly-306136ad-382b-4709-b7c9-63400c3f706c"/>
							<gml:surfaceMember xlink:href="#poly-3d038281-de95-4f5e-9adc-8a385503113b"/>
							<gml:surfaceMember xlink:href="#poly-a0256743-2369-4b49-89be-a4a219429a0d"/>
							<gml:surfaceMember xlink:href="#poly-9532452a-d1db-43f2-a756-fd60fb754c2d"/>
							<gml:surfaceMember xlink:href="#poly-64c4b041-27b7-4569-9252-0d4d9156eeb0"/>
							<gml:surfaceMember xlink:href="#poly-fdbfcabd-b4b1-4a13-919f-ad58cc7a7ac0"/>
							<gml:surfaceMember xlink:href="#poly-f3e48f5f-19af-4d0d-b3d1-65995c3ae3d7"/>
							<gml:surfaceMember xlink:href="#poly-c9325fec-f865-4718-ae4d-e654a18852f1"/>
							<gml:surfaceMember xlink:href="#poly-4914db3f-f525-41eb-a40e-7b804482cd15"/>
							<gml:surfaceMember xlink:href="#poly-fa684942-8dec-491f-9d9b-27b32693463d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a7ce41f7-fb2d-41f3-8be5-45dd8b0ac0d4_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96473136-fec8-4a4f-810d-0014312bfe49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66893756154523 139.74989095625787 31.123 35.66894878742433 139.74989641237673 31.123 35.66894229338823 139.74991644564525 31.123 35.66893106750236 139.74991097847797 31.123 35.66893756154523 139.74989095625787 31.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6dfb2ad3-313b-4c1f-926e-2e60c8f3afa6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66896877309395 139.74992564156219 31.123 35.66897256791119 139.7499126805788 31.123 35.66898643525509 139.74991877462705 31.123 35.66898264945859 139.7499317466491 31.123 35.66896877309395 139.74992564156219 31.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af1c4462-1aa6-4352-b42b-9006522343fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af1c4462-1aa6-4352-b42b-9006522343fc_0">
											<gml:posList>35.66893756154523 139.74989095625787 31.123 35.66893756154523 139.74989095625787 34.273 35.66894878742433 139.74989641237673 34.273 35.66894878742433 139.74989641237673 31.123 35.66893756154523 139.74989095625787 31.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6f3d306-4e5f-4bd4-afdb-9c8dbbdec938">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6f3d306-4e5f-4bd4-afdb-9c8dbbdec938_0">
											<gml:posList>35.66893756154523 139.74989095625787 31.123 35.66893106750236 139.74991097847797 31.123 35.66893106750236 139.74991097847797 34.273 35.66893756154523 139.74989095625787 34.273 35.66893756154523 139.74989095625787 31.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74fe358e-1417-4ec4-8ba6-fe88db6a3dd7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74fe358e-1417-4ec4-8ba6-fe88db6a3dd7_0">
											<gml:posList>35.66893756154523 139.74989095625787 34.273 35.66893106750236 139.74991097847797 34.273 35.66894229338823 139.74991644564525 34.273 35.66894878742433 139.74989641237673 34.273 35.66893756154523 139.74989095625787 34.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7987d14d-6176-43d4-a9a8-d653724404c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7987d14d-6176-43d4-a9a8-d653724404c4_0">
											<gml:posList>35.66894229338823 139.74991644564525 31.123 35.66894878742433 139.74989641237673 31.123 35.66894878742433 139.74989641237673 34.273 35.66894229338823 139.74991644564525 34.273 35.66894229338823 139.74991644564525 31.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ac5a64a-4dfc-466f-92ca-c71c5de27333">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ac5a64a-4dfc-466f-92ca-c71c5de27333_0">
											<gml:posList>35.66893106750236 139.74991097847797 31.123 35.66894229338823 139.74991644564525 31.123 35.66894229338823 139.74991644564525 34.273 35.66893106750236 139.74991097847797 34.273 35.66893106750236 139.74991097847797 31.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1f9de2e-e15f-4146-9b1d-f5a59f3d144a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1f9de2e-e15f-4146-9b1d-f5a59f3d144a_0">
											<gml:posList>35.66897256791119 139.7499126805788 31.123 35.66897256791119 139.7499126805788 38.558 35.66898643525509 139.74991877462705 38.558 35.66898643525509 139.74991877462705 31.123 35.66897256791119 139.7499126805788 31.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64fc2fe1-4774-48d2-877b-0db7783d217d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64fc2fe1-4774-48d2-877b-0db7783d217d_0">
											<gml:posList>35.66896877309395 139.74992564156219 31.123 35.66896877309395 139.74992564156219 38.558 35.66897256791119 139.7499126805788 38.558 35.66897256791119 139.7499126805788 31.123 35.66896877309395 139.74992564156219 31.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52a79329-76d4-4ba4-b873-3cc7ed6c3f8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52a79329-76d4-4ba4-b873-3cc7ed6c3f8b_0">
											<gml:posList>35.66896877309395 139.74992564156219 38.558 35.66898264945859 139.7499317466491 38.558 35.66898643525509 139.74991877462705 38.558 35.66897256791119 139.7499126805788 38.558 35.66896877309395 139.74992564156219 38.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4f613db-2817-489a-a21d-4f89dee9a07c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4f613db-2817-489a-a21d-4f89dee9a07c_0">
											<gml:posList>35.66898264945859 139.7499317466491 31.123 35.66898643525509 139.74991877462705 31.123 35.66898643525509 139.74991877462705 38.558 35.66898264945859 139.7499317466491 38.558 35.66898264945859 139.7499317466491 31.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b5b4d3c-c1c1-4cfa-893f-5cd6ed385273">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b5b4d3c-c1c1-4cfa-893f-5cd6ed385273_0">
											<gml:posList>35.66896877309395 139.74992564156219 31.123 35.66898264945859 139.7499317466491 31.123 35.66898264945859 139.7499317466491 38.558 35.66896877309395 139.74992564156219 38.558 35.66896877309395 139.74992564156219 31.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a7ce41f7-fb2d-41f3-8be5-45dd8b0ac0d4_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-064ec528-7db8-4e4a-8300-469dc338f24d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898355182012 139.74988113262722 6.05 35.66899858121372 139.7498341711873 6.05 35.66902111414607 139.74984514961085 6.05 35.66900601243177 139.7498918128933 6.05 35.66898355182012 139.74988113262722 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc486d95-b00e-4205-ba01-dce0319c4af9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc486d95-b00e-4205-ba01-dce0319c4af9_0">
											<gml:posList>35.66902111414607 139.74984514961085 31.6 35.66902111414607 139.74984514961085 6.05 35.66899858121372 139.7498341711873 6.05 35.66899858121372 139.7498341711873 31.6 35.66902111414607 139.74984514961085 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26ef0c16-f8a5-4856-b130-02754952d98d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26ef0c16-f8a5-4856-b130-02754952d98d_0">
											<gml:posList>35.66899858121372 139.7498341711873 31.6 35.66899858121372 139.7498341711873 6.05 35.66898355182012 139.74988113262722 6.05 35.66898355182012 139.74988113262722 31.6 35.66899858121372 139.7498341711873 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b9b0c64-cace-4a1a-8fb5-fab2058f72d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b9b0c64-cace-4a1a-8fb5-fab2058f72d7_0">
											<gml:posList>35.66900601243177 139.7498918128933 31.6 35.66902111414607 139.74984514961085 31.6 35.66899858121372 139.7498341711873 31.6 35.66898355182012 139.74988113262722 31.6 35.66900601243177 139.7498918128933 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6612dd20-4243-4ae0-bb3b-6985a687f7f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6612dd20-4243-4ae0-bb3b-6985a687f7f3_0">
											<gml:posList>35.66900601243177 139.7498918128933 31.6 35.66900601243177 139.7498918128933 6.05 35.66902111414607 139.74984514961085 6.05 35.66902111414607 139.74984514961085 31.6 35.66900601243177 139.7498918128933 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee458409-944a-4737-89f1-9f31b3c40653">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee458409-944a-4737-89f1-9f31b3c40653_0">
											<gml:posList>35.66898355182012 139.74988113262722 31.6 35.66898355182012 139.74988113262722 6.05 35.66900601243177 139.7498918128933 6.05 35.66900601243177 139.7498918128933 31.6 35.66898355182012 139.74988113262722 31.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a7ce41f7-fb2d-41f3-8be5-45dd8b0ac0d4_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14a0a5a3-73fb-40c8-92db-c5192d8a5d66">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66899683307876 139.74991296462338 31.123 35.66896224471227 139.74989610012938 31.123 35.66896124219849 139.74989322919572 31.123 35.66899829215466 139.74991130619486 31.123 35.66899683307876 139.74991296462338 31.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ab7a36f-df53-46e4-9504-aa01cc1c732a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6689499000632 139.74992813551273 31.123 35.66896124219849 139.74989322919572 31.123 35.66896224471227 139.74989610012938 31.123 35.66895190997134 139.74992791250077 31.123 35.66898650735482 139.749944788043 31.123 35.66899683307876 139.74991296462338 31.123 35.66899829215466 139.74991130619486 31.123 35.668986995075215 139.74994620143255 31.123 35.6689499000632 139.74992813551273 31.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-125cada9-8054-4146-aed7-fb9b6acde2b4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668999175798376 139.74991173607225 31.384 35.66898751888109 139.74994765896884 31.384 35.668949729154335 139.7499286438094 31.384 35.668986995075215 139.74994620143255 31.384 35.66899829215466 139.74991130619486 31.384 35.668999175798376 139.74991173607225 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28cd9869-5a2d-44ab-8723-dc91ba22c606">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28cd9869-5a2d-44ab-8723-dc91ba22c606_0">
											<gml:posList>35.668949729154335 139.7499286438094 31.384 35.66894956725154 139.74992914105067 40.374 35.66896124219849 139.74989322919572 40.374 35.66896124219849 139.74989322919572 31.123 35.6689499000632 139.74992813551273 31.123 35.668949729154335 139.7499286438094 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8a3fac0-d51b-45e0-8d74-7f2361e46169">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8a3fac0-d51b-45e0-8d74-7f2361e46169_0">
											<gml:posList>35.66896124219849 139.74989322919572 40.374 35.66894956725154 139.74992914105067 40.374 35.66895190997134 139.74992791250077 40.374 35.66896224471227 139.74989610012938 40.374 35.66896124219849 139.74989322919572 40.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1e2c9c1-c8a4-4e1d-aa96-7bd96156890f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1e2c9c1-c8a4-4e1d-aa96-7bd96156890f_0">
											<gml:posList>35.66896224471227 139.74989610012938 40.374 35.66895190997134 139.74992791250077 40.374 35.66895190997134 139.74992791250077 31.123 35.66896224471227 139.74989610012938 31.123 35.66896224471227 139.74989610012938 40.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-adf71e9d-2425-4724-8100-6e2ad2914bc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-adf71e9d-2425-4724-8100-6e2ad2914bc6_0">
											<gml:posList>35.668986995075215 139.74994620143255 31.384 35.668949729154335 139.7499286438094 31.384 35.6689499000632 139.74992813551273 31.123 35.668986995075215 139.74994620143255 31.123 35.668986995075215 139.74994620143255 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a646785-2e38-4692-842d-983303bcef56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a646785-2e38-4692-842d-983303bcef56_0">
											<gml:posList>35.66894956725154 139.74992914105067 40.374 35.66898751888109 139.74994765896884 40.374 35.66898650735482 139.749944788043 40.374 35.66895190997134 139.74992791250077 40.374 35.66894956725154 139.74992914105067 40.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6d36971-9871-463c-a6dc-ede1c4dd1e58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6d36971-9871-463c-a6dc-ede1c4dd1e58_0">
											<gml:posList>35.66898751888109 139.74994765896884 31.384 35.66898751888109 139.74994765896884 40.374 35.66894956725154 139.74992914105067 40.374 35.668949729154335 139.7499286438094 31.384 35.66898751888109 139.74994765896884 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-904ccfe3-d2f0-4867-b01f-61d5ded7c29a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-904ccfe3-d2f0-4867-b01f-61d5ded7c29a_0">
											<gml:posList>35.66895190997134 139.74992791250077 40.374 35.66898650735482 139.749944788043 40.374 35.66898650735482 139.749944788043 31.123 35.66895190997134 139.74992791250077 31.123 35.66895190997134 139.74992791250077 40.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-025e542e-8869-482b-9d95-2b9001a96317">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-025e542e-8869-482b-9d95-2b9001a96317_0">
											<gml:posList>35.66899683307876 139.74991296462338 40.374 35.66896224471227 139.74989610012938 40.374 35.66896224471227 139.74989610012938 31.123 35.66899683307876 139.74991296462338 31.123 35.66899683307876 139.74991296462338 40.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24114ae5-6721-4c63-b3f0-554d2d6525a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24114ae5-6721-4c63-b3f0-554d2d6525a4_0">
											<gml:posList>35.668999175798376 139.74991173607225 40.374 35.66896124219849 139.74989322919572 40.374 35.66896224471227 139.74989610012938 40.374 35.66899683307876 139.74991296462338 40.374 35.668999175798376 139.74991173607225 40.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c67af415-9d1b-4640-ac14-1b82bb7753f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c67af415-9d1b-4640-ac14-1b82bb7753f7_0">
											<gml:posList>35.66896124219849 139.74989322919572 31.123 35.66896124219849 139.74989322919572 40.374 35.668999175798376 139.74991173607225 40.374 35.668999175798376 139.74991173607225 31.384 35.66899829215466 139.74991130619486 31.384 35.66899829215466 139.74991130619486 31.123 35.66896124219849 139.74989322919572 31.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27eb4759-38b4-4d1d-91cb-181747a9ddaa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27eb4759-38b4-4d1d-91cb-181747a9ddaa_0">
											<gml:posList>35.66898650735482 139.749944788043 40.374 35.66899683307876 139.74991296462338 40.374 35.66899683307876 139.74991296462338 31.123 35.66898650735482 139.749944788043 31.123 35.66898650735482 139.749944788043 40.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45d40a35-ba73-4361-914d-55ed1c78bc05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45d40a35-ba73-4361-914d-55ed1c78bc05_0">
											<gml:posList>35.668986995075215 139.74994620143255 31.123 35.66899829215466 139.74991130619486 31.123 35.66899829215466 139.74991130619486 31.384 35.668986995075215 139.74994620143255 31.384 35.668986995075215 139.74994620143255 31.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65d78d47-4aed-4008-be1f-04a327832286">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65d78d47-4aed-4008-be1f-04a327832286_0">
											<gml:posList>35.66898751888109 139.74994765896884 40.374 35.668999175798376 139.74991173607225 40.374 35.66899683307876 139.74991296462338 40.374 35.66898650735482 139.749944788043 40.374 35.66898751888109 139.74994765896884 40.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26fa1c60-be31-40ae-9169-50908b2c5b0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26fa1c60-be31-40ae-9169-50908b2c5b0d_0">
											<gml:posList>35.668999175798376 139.74991173607225 31.384 35.668999175798376 139.74991173607225 40.374 35.66898751888109 139.74994765896884 40.374 35.66898751888109 139.74994765896884 31.384 35.668999175798376 139.74991173607225 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d76063fd-ead2-4761-b56a-93512d01dfde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d76063fd-ead2-4761-b56a-93512d01dfde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d76063fd-ead2-4761-b56a-93512d01dfde">
											<gml:posList>35.66894742318965 139.74978785308966 6.05 35.669027131430845 139.7498265417569 6.05 35.66902111414607 139.74984514961085 6.05 35.66899858121372 139.7498341711873 6.05 35.66898355182012 139.74988113262722 6.05 35.66900601243177 139.7498918128933 6.05 35.668987735661844 139.74994831046143 6.05 35.66890802738258 139.74990951123146 6.05 35.66894742318965 139.74978785308966 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a506acbe-4c1c-4692-93cb-8b2e652fd04e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a506acbe-4c1c-4692-93cb-8b2e652fd04e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a506acbe-4c1c-4692-93cb-8b2e652fd04e">
											<gml:posList>35.66890802738258 139.74990951123146 31.384 35.668909748369295 139.7499085926181 31.384 35.668929338375776 139.74984812819292 31.384 35.66892858878133 139.74984603022196 31.384 35.66890802738258 139.74990951123146 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5588bde9-ca49-46f9-a022-e9dd31a68727">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5588bde9-ca49-46f9-a022-e9dd31a68727">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5588bde9-ca49-46f9-a022-e9dd31a68727">
											<gml:posList>35.668987735661844 139.74994831046143 31.384 35.668986995075215 139.74994620143255 31.384 35.668909748369295 139.7499085926181 31.384 35.66890802738258 139.74990951123146 31.384 35.668987735661844 139.74994831046143 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9beda39a-afa0-4fc4-8ecb-5744c04fe255">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9beda39a-afa0-4fc4-8ecb-5744c04fe255">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9beda39a-afa0-4fc4-8ecb-5744c04fe255">
											<gml:posList>35.668986995075215 139.74994620143255 31.123 35.66900430045129 139.74989272045266 31.123 35.668981839847355 139.74988205123265 31.123 35.66898425031276 139.74987452635156 31.123 35.668929338375776 139.74984812819292 31.123 35.668909748369295 139.7499085926181 31.123 35.668986995075215 139.74994620143255 31.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9db894cd-b10a-4760-8450-c6a0e6e2f5da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9db894cd-b10a-4760-8450-c6a0e6e2f5da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9db894cd-b10a-4760-8450-c6a0e6e2f5da">
											<gml:posList>35.66892858878133 139.74984603022196 31.384 35.668929338375776 139.74984812819292 31.384 35.66898425031276 139.74987452635156 31.384 35.66898596228546 139.74987360774594 31.384 35.66892858878133 139.74984603022196 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e9785336-f06b-431d-ba52-e13777503a6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9785336-f06b-431d-ba52-e13777503a6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9785336-f06b-431d-ba52-e13777503a6f">
											<gml:posList>35.66899858121372 139.7498341711873 26.248 35.66894742318965 139.74978785308966 24.036 35.66892858878133 139.74984603022196 31.384 35.66899858121372 139.7498341711873 26.248</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a556233-fdad-49ee-8030-00da0f759deb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a556233-fdad-49ee-8030-00da0f759deb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a556233-fdad-49ee-8030-00da0f759deb">
											<gml:posList>35.66899858121372 139.7498341711873 26.248 35.66892858878133 139.74984603022196 31.384 35.66898596228546 139.74987360774594 31.384 35.66899858121372 139.7498341711873 26.248</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-677974dd-d07f-4cf8-8b11-d78693d64f4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-677974dd-d07f-4cf8-8b11-d78693d64f4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-677974dd-d07f-4cf8-8b11-d78693d64f4c">
											<gml:posList>35.66899858121372 139.7498341711873 26.248 35.669004580492356 139.74981559649473 24.036 35.66894742318965 139.74978785308966 24.036 35.66899858121372 139.7498341711873 26.248</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-942b9347-f4cd-40ea-b1b4-99d030a90eda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-942b9347-f4cd-40ea-b1b4-99d030a90eda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-942b9347-f4cd-40ea-b1b4-99d030a90eda">
											<gml:posList>35.66898355182012 139.74988113262722 31.384 35.66898596228546 139.74987360774594 31.384 35.66898425031276 139.74987452635156 31.384 35.668981839847355 139.74988205123265 31.384 35.66898355182012 139.74988113262722 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8049ee65-8d61-40bf-bc9e-fe9f6baf30f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8049ee65-8d61-40bf-bc9e-fe9f6baf30f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8049ee65-8d61-40bf-bc9e-fe9f6baf30f9">
											<gml:posList>35.66898355182012 139.74988113262722 31.384 35.668981839847355 139.74988205123265 31.384 35.66900430045129 139.74989272045266 31.384 35.66900601243177 139.7498918128933 31.384 35.66898355182012 139.74988113262722 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dbb6001f-4f2c-43c3-96fd-029449176ba7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbb6001f-4f2c-43c3-96fd-029449176ba7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbb6001f-4f2c-43c3-96fd-029449176ba7">
											<gml:posList>35.66900601243177 139.7498918128933 31.384 35.66900430045129 139.74989272045266 31.384 35.668986995075215 139.74994620143255 31.384 35.668987735661844 139.74994831046143 31.384 35.66900601243177 139.7498918128933 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c5c128a0-afd9-4c2b-ab84-517f8620480a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5c128a0-afd9-4c2b-ab84-517f8620480a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5c128a0-afd9-4c2b-ab84-517f8620480a">
											<gml:posList>35.66902111414607 139.74984514961085 22.5 35.669027131430845 139.7498265417569 22.5 35.669004580492356 139.74981559649473 22.5 35.66899858121372 139.7498341711873 22.5 35.66902111414607 139.74984514961085 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8412a1b7-e051-4d39-9539-434de5ef745d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8412a1b7-e051-4d39-9539-434de5ef745d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8412a1b7-e051-4d39-9539-434de5ef745d">
											<gml:posList>35.668909748369295 139.7499085926181 31.384 35.668909748369295 139.7499085926181 31.123 35.668929338375776 139.74984812819292 31.123 35.668929338375776 139.74984812819292 31.384 35.668909748369295 139.7499085926181 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa7fa359-7339-48d1-9994-a0ef090b3396">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa7fa359-7339-48d1-9994-a0ef090b3396">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa7fa359-7339-48d1-9994-a0ef090b3396">
											<gml:posList>35.66894742318965 139.74978785308966 24.036 35.66894742318965 139.74978785308966 6.05 35.66890802738258 139.74990951123146 6.05 35.66890802738258 139.74990951123146 31.384 35.66892858878133 139.74984603022196 31.384 35.66894742318965 139.74978785308966 24.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e047e8e6-31b5-427b-a66a-837f812d62df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e047e8e6-31b5-427b-a66a-837f812d62df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e047e8e6-31b5-427b-a66a-837f812d62df">
											<gml:posList>35.66890802738258 139.74990951123146 6.05 35.668987735661844 139.74994831046143 6.05 35.668987735661844 139.74994831046143 31.384 35.66890802738258 139.74990951123146 31.384 35.66890802738258 139.74990951123146 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db50420f-bbe4-4a30-88ed-a3acad7591ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db50420f-bbe4-4a30-88ed-a3acad7591ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db50420f-bbe4-4a30-88ed-a3acad7591ed">
											<gml:posList>35.668986995075215 139.74994620143255 31.384 35.668986995075215 139.74994620143255 31.123 35.668909748369295 139.7499085926181 31.123 35.668909748369295 139.7499085926181 31.384 35.668986995075215 139.74994620143255 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31752549-bf6b-4fa3-b14c-1c030a799b20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31752549-bf6b-4fa3-b14c-1c030a799b20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31752549-bf6b-4fa3-b14c-1c030a799b20">
											<gml:posList>35.668929338375776 139.74984812819292 31.384 35.668929338375776 139.74984812819292 31.123 35.66898425031276 139.74987452635156 31.123 35.66898425031276 139.74987452635156 31.384 35.668929338375776 139.74984812819292 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-306136ad-382b-4709-b7c9-63400c3f706c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-306136ad-382b-4709-b7c9-63400c3f706c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-306136ad-382b-4709-b7c9-63400c3f706c">
											<gml:posList>35.66898425031276 139.74987452635156 31.384 35.66898425031276 139.74987452635156 31.123 35.668981839847355 139.74988205123265 31.123 35.668981839847355 139.74988205123265 31.384 35.66898425031276 139.74987452635156 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d038281-de95-4f5e-9adc-8a385503113b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d038281-de95-4f5e-9adc-8a385503113b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d038281-de95-4f5e-9adc-8a385503113b">
											<gml:posList>35.669027131430845 139.7498265417569 6.05 35.66894742318965 139.74978785308966 6.05 35.66894742318965 139.74978785308966 24.036 35.669004580492356 139.74981559649473 24.036 35.669004580492356 139.74981559649473 22.5 35.669027131430845 139.7498265417569 22.5 35.669027131430845 139.7498265417569 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0256743-2369-4b49-89be-a4a219429a0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0256743-2369-4b49-89be-a4a219429a0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0256743-2369-4b49-89be-a4a219429a0d">
											<gml:posList>35.66898596228546 139.74987360774594 31.384 35.66898355182012 139.74988113262722 31.384 35.66898355182012 139.74988113262722 6.05 35.66899858121372 139.7498341711873 6.05 35.66899858121372 139.7498341711873 22.5 35.66899858121372 139.7498341711873 26.248 35.66898596228546 139.74987360774594 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9532452a-d1db-43f2-a756-fd60fb754c2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9532452a-d1db-43f2-a756-fd60fb754c2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9532452a-d1db-43f2-a756-fd60fb754c2d">
											<gml:posList>35.668981839847355 139.74988205123265 31.384 35.668981839847355 139.74988205123265 31.123 35.66900430045129 139.74989272045266 31.123 35.66900430045129 139.74989272045266 31.384 35.668981839847355 139.74988205123265 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64c4b041-27b7-4569-9252-0d4d9156eeb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64c4b041-27b7-4569-9252-0d4d9156eeb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64c4b041-27b7-4569-9252-0d4d9156eeb0">
											<gml:posList>35.66900601243177 139.7498918128933 6.05 35.66898355182012 139.74988113262722 6.05 35.66898355182012 139.74988113262722 31.384 35.66900601243177 139.7498918128933 31.384 35.66900601243177 139.7498918128933 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fdbfcabd-b4b1-4a13-919f-ad58cc7a7ac0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdbfcabd-b4b1-4a13-919f-ad58cc7a7ac0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdbfcabd-b4b1-4a13-919f-ad58cc7a7ac0">
											<gml:posList>35.66900430045129 139.74989272045266 31.384 35.66900430045129 139.74989272045266 31.123 35.668986995075215 139.74994620143255 31.123 35.668986995075215 139.74994620143255 31.384 35.66900430045129 139.74989272045266 31.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3e48f5f-19af-4d0d-b3d1-65995c3ae3d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3e48f5f-19af-4d0d-b3d1-65995c3ae3d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3e48f5f-19af-4d0d-b3d1-65995c3ae3d7">
											<gml:posList>35.668987735661844 139.74994831046143 6.05 35.66900601243177 139.7498918128933 6.05 35.66900601243177 139.7498918128933 31.384 35.668987735661844 139.74994831046143 31.384 35.668987735661844 139.74994831046143 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9325fec-f865-4718-ae4d-e654a18852f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9325fec-f865-4718-ae4d-e654a18852f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9325fec-f865-4718-ae4d-e654a18852f1">
											<gml:posList>35.66899858121372 139.7498341711873 22.5 35.669004580492356 139.74981559649473 22.5 35.669004580492356 139.74981559649473 24.036 35.66899858121372 139.7498341711873 26.248 35.66899858121372 139.7498341711873 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4914db3f-f525-41eb-a40e-7b804482cd15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4914db3f-f525-41eb-a40e-7b804482cd15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4914db3f-f525-41eb-a40e-7b804482cd15">
											<gml:posList>35.66899858121372 139.7498341711873 6.05 35.66902111414607 139.74984514961085 6.05 35.66902111414607 139.74984514961085 22.5 35.66899858121372 139.7498341711873 22.5 35.66899858121372 139.7498341711873 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa684942-8dec-491f-9d9b-27b32693463d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa684942-8dec-491f-9d9b-27b32693463d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa684942-8dec-491f-9d9b-27b32693463d">
											<gml:posList>35.66902111414607 139.74984514961085 6.05 35.669027131430845 139.7498265417569 6.05 35.669027131430845 139.7498265417569 22.5 35.66902111414607 139.74984514961085 22.5 35.66902111414607 139.74984514961085 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3856</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">112.7683</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>