<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a87ca39c-c817-4ea5-aa9a-86c4a9a86c5b">
			<core:creationDate>2023-08-22</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門一・二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">431</bldg:usage>
			<bldg:measuredHeight uom="m">9.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66689367503488 139.74783060075936 0 35.66683307989955 139.74780099863753 0 35.666798233071226 139.7479080538221 0 35.6668630065969 139.74793970165823 0 35.66692369367013 139.74796934908574 0 35.66695854055201 139.7478622937601 0 35.66695519078718 139.74786065703103 0 35.666983668823704 139.74777313185103 0 35.66692216838111 139.7477430866654 0 35.66689367503488 139.74783060075936 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66689367503488 139.74783060075936 5.566 35.66692216838111 139.7477430866654 5.566 35.666983668823704 139.74777313185103 5.566 35.66695519078718 139.74786065703103 5.566 35.66695854055201 139.7478622937601 5.566 35.66692369367013 139.74796934908574 5.566 35.6668630065969 139.74793970165823 5.566 35.666798233071226 139.7479080538221 5.566 35.66683307989955 139.74780099863753 5.566 35.66689367503488 139.74783060075936 5.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66689367503488 139.74783060075936 5.566 35.66683307989955 139.74780099863753 5.566 35.66683307989955 139.74780099863753 14.358 35.66689367503488 139.74783060075936 14.358 35.66689367503488 139.74783060075936 5.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66683307989955 139.74780099863753 5.566 35.666798233071226 139.7479080538221 5.566 35.666798233071226 139.7479080538221 14.358 35.66683307989955 139.74780099863753 14.358 35.66683307989955 139.74780099863753 5.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666798233071226 139.7479080538221 5.566 35.6668630065969 139.74793970165823 5.566 35.6668630065969 139.74793970165823 14.358 35.666798233071226 139.7479080538221 14.358 35.666798233071226 139.7479080538221 5.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6668630065969 139.74793970165823 5.566 35.66692369367013 139.74796934908574 5.566 35.66692369367013 139.74796934908574 14.358 35.6668630065969 139.74793970165823 14.358 35.6668630065969 139.74793970165823 5.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66692369367013 139.74796934908574 5.566 35.66695854055201 139.7478622937601 5.566 35.66695854055201 139.7478622937601 14.358 35.66692369367013 139.74796934908574 14.358 35.66692369367013 139.74796934908574 5.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66695854055201 139.7478622937601 5.566 35.66695519078718 139.74786065703103 5.566 35.66695519078718 139.74786065703103 14.358 35.66695854055201 139.7478622937601 14.358 35.66695854055201 139.7478622937601 5.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66695519078718 139.74786065703103 5.566 35.666983668823704 139.74777313185103 5.566 35.666983668823704 139.74777313185103 14.358 35.66695519078718 139.74786065703103 14.358 35.66695519078718 139.74786065703103 5.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666983668823704 139.74777313185103 5.566 35.66692216838111 139.7477430866654 5.566 35.66692216838111 139.7477430866654 14.358 35.666983668823704 139.74777313185103 14.358 35.666983668823704 139.74777313185103 5.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66692216838111 139.7477430866654 5.566 35.66689367503488 139.74783060075936 5.566 35.66689367503488 139.74783060075936 14.358 35.66692216838111 139.7477430866654 14.358 35.66692216838111 139.7477430866654 5.566</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66689367503488 139.74783060075936 14.358 35.66683307989955 139.74780099863753 14.358 35.666798233071226 139.7479080538221 14.358 35.6668630065969 139.74793970165823 14.358 35.66692369367013 139.74796934908574 14.358 35.66695854055201 139.7478622937601 14.358 35.66695519078718 139.74786065703103 14.358 35.666983668823704 139.74777313185103 14.358 35.66692216838111 139.7477430866654 14.358 35.66689367503488 139.74783060075936 14.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly_TMmnt0002_p45_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0002_p45_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0002_p45_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0002_p45_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0002_p45_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0002_p45_5"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0002_p45_6"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0002_p44_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0002_p44_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0002_p44_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0002_p44_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0002_p44_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0002_b_0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:ClosureSurface gml:id="gml_df2d52cc-ec76-4557-b3db-7e9750b4008a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_63c242c9-0b49-4f5d-b7a7-8e983616af2e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f706920c-60f7-4555-9827-3f50c5618129">
											<gml:posList>35.66694109910502 139.74778431170736 6.298749561377377 35.6669199701319 139.74777389708254 9.047254200049252 35.66694109910502 139.74778431170736 9.047254200049252 35.66694109910502 139.74778431170736 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6ac51d28-cec2-4f95-8246-5a5075f6514c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_de1b97fb-230f-44e8-8ca3-3ce3742f6738">
											<gml:posList>35.6669199701319 139.74777389708254 6.298749561377377 35.6669199701319 139.74777389708254 9.047254200049252 35.66694109910502 139.74778431170736 6.298749561377377 35.6669199701319 139.74777389708254 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:ClosureSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gml_fc7a35ca-8d75-4de7-93be-4dc4e6ba90e1">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_21a129a8-d60e-432e-a3dd-fb870d559662">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a42b0dd7-2802-4626-b600-274f3d7e5836">
											<gml:posList>35.66692546027154 139.74775717068897 6.298749561377377 35.66691895467701 139.7477539639789 6.298749561377377 35.66692219422904 139.74774409421767 6.298749561377377 35.66692546027154 139.74775717068897 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c5e890a8-d240-4320-8f77-4d2c558b0cfc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4d15abfa-7acc-4578-9b6e-c507ecc6e15d">
											<gml:posList>35.66692546027154 139.74775717068897 6.298749561377377 35.66692219422904 139.74774409421767 6.298749561377377 35.66692869983242 139.74774730092705 6.298749561377377 35.66692546027154 139.74775717068897 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gnd_TMmnt0002_b_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0002_b_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0002_b_0">
											<gml:posList>35.66683309396758 139.74780100222443 5.56496106 35.6668937060207 139.74783061628884 5.56773835 35.66692218477571 139.7477430900374 5.56834468 35.666983668686306 139.74777313192877 5.57117037 35.66695519043436 139.747860656624 5.57056403 35.66695854047667 139.74786229340438 5.57071823 35.66692370846183 139.74796935198188 5.56999217 35.66679826200648 139.7479080606612 5.56423503 35.66683309396758 139.74780100222443 5.56496106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gml_38300743-7c6f-4f18-a761-ac8731dcb60d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0265f053-338d-4f60-840b-d20fb9fd5aba">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c5996b6c-5a94-4835-914b-74a9187cdd72">
											<gml:posList>35.66689353206189 139.74783141741605 6.298749561377377 35.6669199701319 139.74777389708254 6.298749561377377 35.66694109910502 139.74778431170736 6.298749561377377 35.66689353206189 139.74783141741605 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f4135923-75d7-42b8-9dca-150726498d9b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9310cb0c-589b-4f2c-bcad-a2f954b3715b">
											<gml:posList>35.6669199701319 139.74777389708254 6.298749561377377 35.666914894067766 139.74776633515313 6.298749561377377 35.66692139966627 139.74776954186405 6.298749561377377 35.6669199701319 139.74777389708254 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5ff5f6bc-ee4d-47a0-a836-67e810919bb4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fef62813-86ab-4069-97f3-4c6d04b175d5">
											<gml:posList>35.666914894067766 139.74776633515313 6.298749561377377 35.6669199701319 139.74777389708254 6.298749561377377 35.66689353206189 139.74783141741605 6.298749561377377 35.666914894067766 139.74776633515313 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_57ce284c-5517-469c-a64c-01af30ced218">
									<gml:exterior>
										<gml:LinearRing gml:id="line_89d12510-e84c-458e-8ecb-ec9a491e453c">
											<gml:posList>35.666982718999726 139.74777392721228 6.298749561377377 35.66694109910502 139.74778431170736 6.298749561377377 35.66694982880769 139.74775771537745 6.298749561377377 35.666982718999726 139.74777392721228 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9f98618a-51e3-451c-b2b8-91e1389d9ba1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e3836fa7-3227-45c8-9886-5f9f04077824">
											<gml:posList>35.66695438469724 139.7478602514853 6.298749561377377 35.66689353206189 139.74783141741605 6.298749561377377 35.66694109910502 139.74778431170736 6.298749561377377 35.66695438469724 139.7478602514853 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0e4d7346-6e76-4761-b957-28d367a3ba3a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_94a5ab82-c11b-4cf4-8f03-49e31598cacf">
											<gml:posList>35.66694109910502 139.74778431170736 6.298749561377377 35.666982718999726 139.74777392721228 6.298749561377377 35.66695438469724 139.7478602514853 6.298749561377377 35.66694109910502 139.74778431170736 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6b2ceea0-cdbd-4d8b-a825-94d8c6ef8c40">
									<gml:exterior>
										<gml:LinearRing gml:id="line_187911ff-3647-4f96-ac2e-5c565eca6bc2">
											<gml:posList>35.66689353206189 139.74783141741605 6.298749561377377 35.66695438469724 139.7478602514853 6.298749561377377 35.66692340143323 139.74796925358973 6.298749561377377 35.66689353206189 139.74783141741605 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1abdd340-0608-45cc-89b2-d70a175ea7de">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2e55f2e0-118f-4b76-9a2f-623e6b3c65ca">
											<gml:posList>35.66692340143323 139.74796925358973 6.298749561377377 35.66695438469724 139.7478602514853 6.298749561377377 35.66695851174128 139.74786228564236 6.298749561377377 35.66692340143323 139.74796925358973 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2222264b-1a01-4e44-a07c-16563b6882ee">
									<gml:exterior>
										<gml:LinearRing gml:id="line_764ac3b9-f128-445b-8ca0-ff287023a557">
											<gml:posList>35.66689353206189 139.74783141741605 6.298749561377377 35.66692340143323 139.74796925358973 6.298749561377377 35.66680202752375 139.74790942762223 6.298749561377377 35.66689353206189 139.74783141741605 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0dd93e02-db4a-4a53-99a3-3ca3a1771684">
									<gml:exterior>
										<gml:LinearRing gml:id="line_89c393e1-ecc3-4ede-ad81-e61072ad3942">
											<gml:posList>35.66689353206189 139.74783141741605 6.298749561377377 35.66680202752375 139.74790942762223 6.298749561377377 35.66683680990699 139.74780345879026 6.298749561377377 35.66689353206189 139.74783141741605 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_5ef0cd27-d6a4-44be-9037-73fc884e1185">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1dde1abe-5ebf-43ba-ae87-416d5052d2d5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f3e4874c-b09e-49c3-8ff4-6f1fc37f110f">
											<gml:posList>35.66692139966627 139.74776954186405 9.047254200049252 35.66694109910502 139.74778431170736 9.047254200049252 35.6669199701319 139.74777389708254 9.047254200049252 35.66692139966627 139.74776954186405 9.047254200049252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9eec35ab-3662-4952-9cd3-c4ee792e8f13">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a52dd480-ff38-4abc-ade9-2769d37dce81">
											<gml:posList>35.66694109910502 139.74778431170736 9.047254200049252 35.66692139966627 139.74776954186405 9.047254200049252 35.66692546027154 139.74775717068897 9.047254200049252 35.66694109910502 139.74778431170736 9.047254200049252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_322bd7b9-eac3-441a-a4c6-9ab24afa1e1d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6fae6439-a065-4104-9296-924dd0be373c">
											<gml:posList>35.66692139966627 139.74776954186405 9.047254200049252 35.66691895467701 139.7477539639789 9.047254200049252 35.66692546027154 139.74775717068897 9.047254200049252 35.66692139966627 139.74776954186405 9.047254200049252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_84233e98-8d00-40a0-a1b1-b8ad5758993a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e668b3b2-51b1-4cfb-b7e3-e09c6278ad2e">
											<gml:posList>35.66691895467701 139.7477539639789 9.047254200049252 35.66692139966627 139.74776954186405 9.047254200049252 35.666914894067766 139.74776633515313 9.047254200049252 35.66691895467701 139.7477539639789 9.047254200049252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3d8d5c7c-5d8c-4361-b77d-8c68468b5b8f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ac98a2ff-4939-4d82-a4eb-38e2895d20b1">
											<gml:posList>35.66694982880769 139.74775771537745 9.047254200049252 35.66692546027154 139.74775717068897 9.047254200049252 35.66692869983242 139.74774730092705 9.047254200049252 35.66694982880769 139.74775771537745 9.047254200049252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ab3e9913-fe03-4b09-ae66-672023d179b3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_62c0e4aa-2fc3-4f24-af30-72a0d7635bfa">
											<gml:posList>35.66694109910502 139.74778431170736 9.047254200049252 35.66692546027154 139.74775717068897 9.047254200049252 35.66694982880769 139.74775771537745 9.047254200049252 35.66694109910502 139.74778431170736 9.047254200049252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0002_p45_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0002_p45_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0002_p45_1">
											<gml:posList>35.666798233277305 139.74790805345958 13.92480729 35.66686300697944 139.74793970178465 14.97777564 35.6668964754146 139.7478368342579 14.97847294 35.66689231023542 139.74783479903397 14.91076248 35.66689367377518 139.74783060835423 14.91079241 35.66683306519261 139.74780099516312 13.92553332 35.666798233277305 139.74790805345958 13.92480729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0002_p45_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0002_p45_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0002_p45_0">
											<gml:posList>35.666955161298205 139.7478606494349 13.98911548 35.66695379723252 139.74786484173046 13.98908799 35.6668964754146 139.7478368342579 14.97847294 35.66686300697944 139.74793970178465 14.97777564 35.66692367956773 139.7479693447 13.93056442 35.66695851153679 139.74786228626266 13.93129049 35.666955161298205 139.7478606494349 13.98911548</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_95417161-d914-4762-952b-2e97b561bf6d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7e7a6808-419a-4089-89b9-2b00b930be77">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f72f2516-585b-4233-bfb7-466ddf8e8a2f">
											<gml:posList>35.66689353206189 139.74783141741605 15.055760974951596 35.66680202752375 139.74790942762223 14.313748951025815 35.66686306829769 139.74793951498793 15.112249012060971 35.66689353206189 139.74783141741605 15.055760974951596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4450009d-449a-43c2-8517-096dce5aec5d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_254fea31-3e1f-4353-90a9-802843ab0cdf">
											<gml:posList>35.66680202752375 139.74790942762223 14.313748951025815 35.66689353206189 139.74783141741605 15.055760974951596 35.66683680990699 139.74780345879026 14.313748951025815 35.66680202752375 139.74790942762223 14.313748951025815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_292e738e-f5d8-46d3-b374-5e56529718e0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c438cbfa-baea-4cc1-8cd7-f6f89c3fb3fe">
											<gml:posList>35.66689353206189 139.74783141741605 15.055760974951596 35.66686306829769 139.74793951498793 15.112249012060971 35.66689817857761 139.74783254710815 15.112249012060971 35.66689353206189 139.74783141741605 15.055760974951596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_056c05dd-7b11-49b2-b54d-d3bbc2ba600d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5f66c510-f4f0-4222-b339-a82ca1a4c5e3">
											<gml:posList>35.66689353206189 139.74783141741605 15.055760974951596 35.66689817857761 139.74783254710815 15.112249012060971 35.666893859949724 139.74783041843597 15.055760974951596 35.66689353206189 139.74783141741605 15.055760974951596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_f4165d2e-f8ee-48a4-8e8a-2687351faf9f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_560a7dd6-fc15-4852-a3a0-eb3e90404382">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e29396f2-9463-4ea7-bbcd-8fa1110c7b21">
											<gml:posList>35.66695438469724 139.7478602514853 14.368367786475034 35.66686306829769 139.74793951498793 15.112249012060971 35.66692340143323 139.74796925358973 14.313748951025815 35.66695438469724 139.7478602514853 14.368367786475034</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7da05933-6444-4b6a-8a1d-5d83f8b7ac4b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6cc0cde4-ae9d-4e2f-bbea-99c8d53298c1">
											<gml:posList>35.66686306829769 139.74793951498793 15.112249012060971 35.66695438469724 139.7478602514853 14.368367786475034 35.66689817857761 139.74783254710815 15.112249012060971 35.66686306829769 139.74793951498793 15.112249012060971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_305d3f4b-11c8-49a4-8243-69a0296a3659">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4f895b22-0041-424e-b2f1-a28b19baed60">
											<gml:posList>35.66695438469724 139.7478602514853 14.368367786475034 35.66692340143323 139.74796925358973 14.313748951025815 35.66695851174128 139.74786228564236 14.313748951025815 35.66695438469724 139.7478602514853 14.368367786475034</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0002_p44_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0002_p44_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0002_p44_1">
											<gml:posList>35.6669537927439 139.74786484062204 15.28610742 35.66698363501762 139.74777312376526 15.28674252 35.66692215120107 139.74774308191968 15.28391683 35.66689230894983 139.74783479871735 15.28328176 35.6669537927439 139.74786484062204 15.28610742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_d12a7b50-3a95-47bc-925f-7129efcc7eea">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_31c8ebf2-0b0c-4ccc-938d-7c2cd0f8edee">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5229c758-52bb-4e12-9c74-9b7a5e306a8a">
											<gml:posList>35.66692219422904 139.74774409421767 15.464994068213315 35.666893859949724 139.74783041843597 15.464994068213315 35.66695438469724 139.7478602514853 15.464994068213315 35.66692219422904 139.74774409421767 15.464994068213315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5cc7aa8f-bb2f-499d-b3a5-3999a7b4f692">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c802efed-1483-475d-834c-3363de3154ef">
											<gml:posList>35.66692219422904 139.74774409421767 15.464994068213315 35.66695438469724 139.7478602514853 15.464994068213315 35.666982718999726 139.74777392721228 15.464994068213315 35.66692219422904 139.74774409421767 15.464994068213315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0002_p45_5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0002_p45_5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0002_p45_5">
											<gml:posList>35.66695851153679 139.74786228626266 13.93129049 35.66692367956773 139.7479693447 13.93056442 35.66692370846183 139.74796935198188 5.56999217 35.66695854047667 139.74786229340438 5.57071823 35.66695851153679 139.74786228626266 13.93129049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_6c09f0cb-e6be-4b06-a41e-fa06132df9e9">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_661dfeda-ae61-4f8d-90dc-07b2a48f19cf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7a86d16d-3244-4cc5-9b1f-b435d9d13437">
											<gml:posList>35.66692139966627 139.74776954186405 6.298749561377377 35.66692139966627 139.74776954186405 9.047254200049252 35.6669199701319 139.74777389708254 6.298749561377377 35.66692139966627 139.74776954186405 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dddba107-8312-420c-a5d5-ebf52d46ff1e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cf183d58-4b14-4ab9-b1d1-7143591e69b6">
											<gml:posList>35.6669199701319 139.74777389708254 6.298749561377377 35.66692139966627 139.74776954186405 9.047254200049252 35.6669199701319 139.74777389708254 9.047254200049252 35.6669199701319 139.74777389708254 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0002_p44_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0002_p44_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0002_p44_4">
											<gml:posList>35.66689231023542 139.74783479903397 14.91076248 35.6668964754146 139.7478368342579 14.97847294 35.66695379723252 139.74786484173046 13.98908799 35.6669537927439 139.74786484062204 15.28610742 35.66689230894983 139.74783479871735 15.28328176 35.66689231023542 139.74783479903397 14.91076248</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_d8c612f1-a603-4397-be1c-609866841530">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0a6de9b1-35bf-4024-a049-1ad5d8a06efb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d64e55e6-a76f-4f76-9b04-aa2cc11655f1">
											<gml:posList>35.66695438469724 139.7478602514853 6.298749561377377 35.66695438469724 139.7478602514853 14.368367786475034 35.66695851174128 139.74786228564236 6.298749561377377 35.66695438469724 139.7478602514853 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1addc974-27ec-4355-86da-d112f757288e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_55e66723-688b-4786-a50f-b46ad727f817">
											<gml:posList>35.66695851174128 139.74786228564236 6.298749561377377 35.66695438469724 139.7478602514853 14.368367786475034 35.66695851174128 139.74786228564236 14.313748951025815 35.66695851174128 139.74786228564236 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0002_p45_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0002_p45_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0002_p45_4">
											<gml:posList>35.66695519043436 139.747860656624 5.57056403 35.666955161298205 139.7478606494349 13.98911548 35.66695851153679 139.74786228626266 13.93129049 35.66695854047667 139.74786229340438 5.57071823 35.66695519043436 139.747860656624 5.57056403</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_4344c8ce-ad5d-4218-ad8a-5070f1938265">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8f9b881d-3aec-4e3a-ac0d-fbfbb2c75ce5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fa2c2571-8575-4184-9451-767caaa591ab">
											<gml:posList>35.666893859949724 139.74783041843597 15.464994068213315 35.66689817857761 139.74783254710815 15.112249012060971 35.66695438469724 139.7478602514853 15.464994068213315 35.666893859949724 139.74783041843597 15.464994068213315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_47f77b95-72d9-4ebd-b616-f64ec91961eb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_50dea6d6-47c4-4620-a468-410004f0ae66">
											<gml:posList>35.66689817857761 139.74783254710815 15.112249012060971 35.666893859949724 139.74783041843597 15.464994068213315 35.666893859949724 139.74783041843597 15.055760974951596 35.66689817857761 139.74783254710815 15.112249012060971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_505d259b-81fc-4bfa-86a4-03fb29841d1c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_39a018de-9af3-458c-90e4-06a999ff1875">
											<gml:posList>35.66695438469724 139.7478602514853 15.464994068213315 35.66689817857761 139.74783254710815 15.112249012060971 35.66695438469724 139.7478602514853 14.368367786475034 35.66695438469724 139.7478602514853 15.464994068213315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_2e822203-3327-4b5a-ab10-701a1be28b2f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_94580602-c962-4adb-acbd-704ab72ab4f8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2896612a-6062-44fe-b607-fb530467674b">
											<gml:posList>35.66692219422904 139.74774409421767 15.464994068213315 35.66690602035797 139.74779337017887 12.692128772803159 35.666893859949724 139.74783041843597 15.464994068213315 35.66692219422904 139.74774409421767 15.464994068213315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f0c2c498-9bd4-4aef-8d43-a07605121643">
									<gml:exterior>
										<gml:LinearRing gml:id="line_91d00852-3432-4938-9129-4d14366f2598">
											<gml:posList>35.66692219422904 139.74774409421767 15.464994068213315 35.66691229950663 139.74777423982937 12.692128772803159 35.66690602035797 139.74779337017887 12.692128772803159 35.66692219422904 139.74774409421767 15.464994068213315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_09a94c28-d181-4c3d-b865-684d85813439">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6d6bac34-b998-4639-bb10-77f93c24bfa7">
											<gml:posList>35.66691229950663 139.74777423982937 12.692128772803159 35.66692219422904 139.74774409421767 15.464994068213315 35.66691229950663 139.74777423982937 11.622090931006284 35.66691229950663 139.74777423982937 12.692128772803159</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_06a70805-cb80-44bc-8ca7-8a97086867a1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a1f9415a-728c-473f-9bfa-da6b55015709">
											<gml:posList>35.66692219422904 139.74774409421767 15.464994068213315 35.66691895467701 139.7477539639789 9.047254200049252 35.66691229950663 139.74777423982937 11.622090931006284 35.66692219422904 139.74774409421767 15.464994068213315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3a0ee78d-fcc5-4279-b876-a266be7958c2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_432c9840-0d5d-426e-910e-78cc231058b2">
											<gml:posList>35.66691895467701 139.7477539639789 9.047254200049252 35.66692219422904 139.74774409421767 6.298749561377377 35.66691895467701 139.7477539639789 6.298749561377377 35.66691895467701 139.7477539639789 9.047254200049252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eec11342-db61-48e7-baba-cfd4f3b7b827">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f4ea0f32-129e-4fe9-82da-3f4941fde9c8">
											<gml:posList>35.66692219422904 139.74774409421767 6.298749561377377 35.66691895467701 139.7477539639789 9.047254200049252 35.66692219422904 139.74774409421767 15.464994068213315 35.66692219422904 139.74774409421767 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_205bc838-114b-40ac-8ad4-0fd0088e1591">
									<gml:exterior>
										<gml:LinearRing gml:id="line_356e72e4-8aa3-486e-b049-9c7ecde34c5f">
											<gml:posList>35.66691229950663 139.74777423982937 11.622090931006284 35.66691895467701 139.7477539639789 9.047254200049252 35.666914894067766 139.74776633515313 9.047254200049252 35.66691229950663 139.74777423982937 11.622090931006284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9a22b832-8c01-4374-953b-fc0a99b9cb3b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5e1b9b48-3d80-46ef-a295-32bc6af88610">
											<gml:posList>35.666893859949724 139.74783041843597 15.464994068213315 35.66690602035797 139.74779337017887 12.692128772803159 35.66690136852442 139.74780754254851 12.692128772803159 35.666893859949724 139.74783041843597 15.464994068213315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a433b07d-2ed8-4a08-9de6-ecb3c2d58523">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7b9a0a99-d37d-42f4-9c3f-3186ac6d88d7">
											<gml:posList>35.66690136852442 139.74780754254851 12.692128772803159 35.66690602035797 139.74779337017887 12.692128772803159 35.66690602035797 139.74779337017887 11.622090931006284 35.66690136852442 139.74780754254851 12.692128772803159</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e3bef672-a703-4015-8941-48f5dea4a368">
									<gml:exterior>
										<gml:LinearRing gml:id="line_afc30dc8-30e8-4bc9-b54e-f21a6ee8ced1">
											<gml:posList>35.666893859949724 139.74783041843597 15.464994068213315 35.66690136852442 139.74780754254851 12.692128772803159 35.666893859949724 139.74783041843597 15.055760974951596 35.666893859949724 139.74783041843597 15.464994068213315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_81c2bb5b-8f95-418d-b86f-5f7394c69fe2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0cd046f8-c118-4180-8894-0defd36ee2f2">
											<gml:posList>35.666893859949724 139.74783041843597 15.055760974951596 35.66690136852442 139.74780754254851 12.692128772803159 35.66689508937046 139.74782667289284 12.692128772803159 35.666893859949724 139.74783041843597 15.055760974951596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c617d5d6-35f9-474f-87b7-7d8f2e4c1fe2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6d2d197d-34b3-4257-be34-64fac4840e11">
											<gml:posList>35.666914894067766 139.74776633515313 9.047254200049252 35.66689353206189 139.74783141741605 6.298749561377377 35.66690602035797 139.74779337017887 11.622090931006284 35.666914894067766 139.74776633515313 9.047254200049252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_aeae2178-d533-4578-92ca-5cc7b4819151">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fbd50763-4a7b-43d7-883a-70ed756a1460">
											<gml:posList>35.66689353206189 139.74783141741605 6.298749561377377 35.666914894067766 139.74776633515313 9.047254200049252 35.666914894067766 139.74776633515313 6.298749561377377 35.66689353206189 139.74783141741605 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cb0c3d57-f1d3-4352-bb05-a18f90efbcdd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7bfd2ff8-d2cc-43d3-8e94-d56be6db6b6a">
											<gml:posList>35.666914894067766 139.74776633515313 9.047254200049252 35.66690602035797 139.74779337017887 11.622090931006284 35.66691229950663 139.74777423982937 11.622090931006284 35.666914894067766 139.74776633515313 9.047254200049252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ca17b8fe-d7fc-4803-b7e0-292aefaf27d7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e65462a0-5a2e-4576-b80c-2bd3d16b1947">
											<gml:posList>35.66690602035797 139.74779337017887 11.622090931006284 35.66689353206189 139.74783141741605 6.298749561377377 35.66690136852442 139.74780754254851 11.622090931006284 35.66690602035797 139.74779337017887 11.622090931006284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1451eb15-af84-4b99-992b-aa75fa0544c8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_14ae0141-1ebf-44e4-a30a-6b6081a6be4f">
											<gml:posList>35.66690602035797 139.74779337017887 11.622090931006284 35.66690136852442 139.74780754254851 11.622090931006284 35.66690136852442 139.74780754254851 12.692128772803159 35.66690602035797 139.74779337017887 11.622090931006284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0ce001ff-3703-4eed-9298-b9f4142422f3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_58990703-fb8c-49bd-9f41-cabac60c3bb0">
											<gml:posList>35.66690136852442 139.74780754254851 11.622090931006284 35.66689353206189 139.74783141741605 6.298749561377377 35.66689508937046 139.74782667289284 11.622090931006284 35.66690136852442 139.74780754254851 11.622090931006284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7f973a3e-6f16-4b40-9170-ff4cc495c0ec">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ef056afc-3b18-4a3f-b9cd-8bab2cad3d8c">
											<gml:posList>35.66689508937046 139.74782667289284 11.622090931006284 35.66689353206189 139.74783141741605 6.298749561377377 35.66689353206189 139.74783141741605 15.055760974951596 35.66689508937046 139.74782667289284 11.622090931006284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2abb2d12-5a6f-440d-9ffc-80350572c7bb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f0709e79-28cc-4706-a452-50bae05e3eeb">
											<gml:posList>35.66689508937046 139.74782667289284 11.622090931006284 35.66689353206189 139.74783141741605 15.055760974951596 35.66689508937046 139.74782667289284 12.692128772803159 35.66689508937046 139.74782667289284 11.622090931006284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_17f2fcc0-1019-4af7-a57e-a392db7c247a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_783f35dc-e686-4c5a-b9bb-4e92cab8b9fe">
											<gml:posList>35.66689508937046 139.74782667289284 12.692128772803159 35.66689353206189 139.74783141741605 15.055760974951596 35.666893859949724 139.74783041843597 15.055760974951596 35.66689508937046 139.74782667289284 12.692128772803159</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_ae009ee3-22ee-45f9-b0c3-5e12ade3dc26">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_a8cfecb0-1bf5-40bb-ace9-20e85221c39a">
											<gml:exterior>
												<gml:LinearRing gml:id="line_26d7cf46-4d73-4023-ac3c-80b3e8d5dc9c">
													<gml:posList>35.66690602035797 139.74779337017887 11.622090931006284 35.66690602035797 139.74779337017887 12.692128772803159 35.66691229950663 139.74777423982937 11.622090931006284 35.66690602035797 139.74779337017887 11.622090931006284</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_7804648d-d042-4013-8b80-4ae01797586b">
											<gml:exterior>
												<gml:LinearRing gml:id="line_6b1a1220-5d01-4d60-93df-d7ce05e86242">
													<gml:posList>35.66691229950663 139.74777423982937 11.622090931006284 35.66690602035797 139.74779337017887 12.692128772803159 35.66691229950663 139.74777423982937 12.692128772803159 35.66691229950663 139.74777423982937 11.622090931006284</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_11b90e21-89aa-4032-b805-7a302bd29d9c">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_3b73105e-f7f3-4f27-b18d-9231f6f6a1ad">
											<gml:exterior>
												<gml:LinearRing gml:id="line_cc3a5280-15e4-4131-b7ab-fb1fc04321b1">
													<gml:posList>35.66689508937046 139.74782667289284 11.622090931006284 35.66689508937046 139.74782667289284 12.692128772803159 35.66690136852442 139.74780754254851 11.622090931006284 35.66689508937046 139.74782667289284 11.622090931006284</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_f8ce8733-94e2-44b3-a06e-afd61c91af9d">
											<gml:exterior>
												<gml:LinearRing gml:id="line_4c92d815-5521-4681-9351-73bd9a15a156">
													<gml:posList>35.66690136852442 139.74780754254851 11.622090931006284 35.66689508937046 139.74782667289284 12.692128772803159 35.66690136852442 139.74780754254851 12.692128772803159 35.66690136852442 139.74780754254851 11.622090931006284</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_89850a18-2db9-4376-a3d6-13eee64135c1">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_32ec3b93-035b-4f9f-8a10-2160dbd3313f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d91c4dbc-7a08-420d-aadd-106e53a260e3">
											<gml:posList>35.666831192224635 139.7478205737946 11.702535266943784 35.66682852662862 139.7478286947799 12.47582780844769 35.666831192224635 139.7478205737946 12.47582780844769 35.666831192224635 139.7478205737946 11.702535266943784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5e84c17d-c16e-46e3-b6b7-2b3f58f37aa3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7dca0e66-5676-4ce0-aa32-0c19dbc75650">
											<gml:posList>35.66682852662862 139.7478286947799 12.47582780844769 35.666831192224635 139.7478205737946 11.702535266943784 35.66682852662862 139.7478286947799 11.702535266943784 35.66682852662862 139.7478286947799 12.47582780844769</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4e31c579-92fd-4919-846d-b85cd3397d09">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4847e74b-a31e-4fe8-bacb-d8e5ee5d51ec">
											<gml:posList>35.66683680990699 139.74780345879026 6.298749561377377 35.66682852662862 139.7478286947799 11.702535266943784 35.666831192224635 139.7478205737946 11.702535266943784 35.66683680990699 139.74780345879026 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c50e34fd-4e20-4b11-b7b0-f270d6655afd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ec7eba1c-7874-4b69-8cc2-c5dd4b9c267a">
											<gml:posList>35.66682852662862 139.7478286947799 11.702535266943784 35.66683680990699 139.74780345879026 6.298749561377377 35.66682608972859 139.74783611926108 11.702535266943784 35.66682852662862 139.7478286947799 11.702535266943784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4150ab4d-1f29-481c-9d8a-31838e7f490f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9e79bf03-1f64-458c-8cf4-ab254cec8c0e">
											<gml:posList>35.66683680990699 139.74780345879026 6.298749561377377 35.66683362912382 139.74781314948103 11.702535266943784 35.66683680990699 139.74780345879026 14.313748951025815 35.66683680990699 139.74780345879026 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_38bb7290-ad06-433e-b174-08a5d4621c6e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_256d2fbc-5c79-46f1-aa4c-123797f6bdae">
											<gml:posList>35.66683362912382 139.74781314948103 11.702535266943784 35.66683680990699 139.74780345879026 6.298749561377377 35.666831192224635 139.7478205737946 11.702535266943784 35.66683362912382 139.74781314948103 11.702535266943784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a58b395e-7e07-4017-93c4-3e736fce3514">
									<gml:exterior>
										<gml:LinearRing gml:id="line_433f75bd-69aa-4e2d-a337-34aed5b91787">
											<gml:posList>35.66683680990699 139.74780345879026 14.313748951025815 35.66683362912382 139.74781314948103 11.702535266943784 35.66683362912382 139.74781314948103 12.47582780844769 35.66683680990699 139.74780345879026 14.313748951025815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_92a1cba2-ad16-4058-940e-9d0c401627fc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b9c20ad4-0af5-4843-9dba-b06f1ddac8e3">
											<gml:posList>35.66683680990699 139.74780345879026 14.313748951025815 35.66683362912382 139.74781314948103 12.47582780844769 35.666831192224635 139.7478205737946 12.47582780844769 35.66683680990699 139.74780345879026 14.313748951025815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d3ea8b12-46f5-467e-9b28-342745f695d2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b0969a35-66a4-4768-9b8a-0a6d77114f9d">
											<gml:posList>35.66680581935067 139.7478978753823 11.853345508643002 35.66680202752375 139.74790942762223 6.298749561377377 35.66680202752375 139.74790942762223 14.313748951025815 35.66680581935067 139.7478978753823 11.853345508643002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e8f50e4e-5030-4663-8533-ae515903a906">
									<gml:exterior>
										<gml:LinearRing gml:id="line_84b3050f-7aca-43ea-9cf4-f2943f357479">
											<gml:posList>35.66680202752375 139.74790942762223 6.298749561377377 35.66680581935067 139.7478978753823 11.853345508643002 35.66680825625463 139.7478904510734 11.853345508643002 35.66680202752375 139.74790942762223 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_39e9b091-ad11-4e29-9791-90337fdacdb1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_541f80ed-efe8-4997-a6fd-4c1d9d8999f5">
											<gml:posList>35.66680202752375 139.74790942762223 6.298749561377377 35.66680825625463 139.7478904510734 11.853345508643002 35.666810930518174 139.7478823036214 11.853345508643002 35.66680202752375 139.74790942762223 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ffb8fe8c-af42-4cbf-84c1-375249e75163">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d807cfef-4f64-4fca-b839-57545baec6ea">
											<gml:posList>35.66680581935067 139.7478978753823 11.853345508643002 35.66680202752375 139.74790942762223 14.313748951025815 35.66680581935067 139.7478978753823 12.626638050146909 35.66680581935067 139.7478978753823 11.853345508643002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_17a8b39a-de93-4d7a-8bb3-7f14f6b989eb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d64241f5-12f6-45ba-9dd1-215874ca98ec">
											<gml:posList>35.66680581935067 139.7478978753823 12.626638050146909 35.66680202752375 139.74790942762223 14.313748951025815 35.66680825625463 139.7478904510734 12.626638050146909 35.66680581935067 139.7478978753823 12.626638050146909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_16f6eeed-c6ce-45b1-990f-fe6cc6c90f98">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d79e7e4f-be86-4528-a571-7df8c10974c5">
											<gml:posList>35.66680825625463 139.7478904510734 12.626638050146909 35.66680202752375 139.74790942762223 14.313748951025815 35.666810930518174 139.7478823036214 12.626638050146909 35.66680825625463 139.7478904510734 12.626638050146909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_883a328d-d759-4037-9ef3-e76bcb8c2e80">
									<gml:exterior>
										<gml:LinearRing gml:id="line_66f6afd7-725f-4683-bab1-d22946bb7f92">
											<gml:posList>35.666810930518174 139.7478823036214 12.626638050146909 35.66680202752375 139.74790942762223 14.313748951025815 35.666813367421184 139.74787487931155 12.626638050146909 35.666810930518174 139.7478823036214 12.626638050146909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_521c105a-895e-42cc-a957-b0c0a28bdcf9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0aa6b6c8-f7bc-4cab-990a-93ef8d947b80">
											<gml:posList>35.666813367421184 139.74787487931155 12.626638050146909 35.66680202752375 139.74790942762223 14.313748951025815 35.666815998246605 139.74786686421268 12.626638050146909 35.666813367421184 139.74787487931155 12.626638050146909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1988a638-4f31-4c96-97a3-56c132edcff3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_742c7ce2-e71c-4c72-a84a-3490f7fcf64d">
											<gml:posList>35.666815998246605 139.74786686421268 12.626638050146909 35.66680202752375 139.74790942762223 14.313748951025815 35.666818435148656 139.7478594399019 12.626638050146909 35.666815998246605 139.74786686421268 12.626638050146909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3428a000-70e4-4e18-bdfe-a63069200b2b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fe35fa35-5e09-4cf2-99ce-d5cfa97c71aa">
											<gml:posList>35.666818435148656 139.7478594399019 12.626638050146909 35.66680202752375 139.74790942762223 14.313748951025815 35.66683680990699 139.74780345879026 14.313748951025815 35.666818435148656 139.7478594399019 12.626638050146909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7d3171f1-cd45-43e5-9be8-09bd11fb72c1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_320e9ad6-3b82-4563-b52d-8f4d601b3290">
											<gml:posList>35.666818435148656 139.7478594399019 12.626638050146909 35.66683680990699 139.74780345879026 14.313748951025815 35.66682098663 139.7478516664117 12.626638050146909 35.666818435148656 139.7478594399019 12.626638050146909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_60f0d7f3-be4f-4ba6-adca-0e69975aa23a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fa0a901a-4b80-421c-b299-53481c970a94">
											<gml:posList>35.66682098663 139.7478516664117 12.626638050146909 35.66683680990699 139.74780345879026 14.313748951025815 35.666823423531106 139.7478442421 12.626638050146909 35.66682098663 139.7478516664117 12.626638050146909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b876147a-9d9d-41e9-b027-cfcb756cc53a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5333a19d-ade2-49b5-bced-a7116d6c228e">
											<gml:posList>35.666810930518174 139.7478823036214 11.853345508643002 35.66680825625463 139.7478904510734 12.626638050146909 35.666810930518174 139.7478823036214 12.626638050146909 35.666810930518174 139.7478823036214 11.853345508643002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0fd21176-bff1-4fb4-b43d-6d834397ce92">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d2c513d0-385c-4a9b-9966-413ae7243dea">
											<gml:posList>35.66680825625463 139.7478904510734 12.626638050146909 35.666810930518174 139.7478823036214 11.853345508643002 35.66680825625463 139.7478904510734 11.853345508643002 35.66680825625463 139.7478904510734 12.626638050146909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_97e4abeb-0b50-40d8-a268-195f6bac3eef">
									<gml:exterior>
										<gml:LinearRing gml:id="line_01d0e3ce-5161-4f6d-bcb1-b8bbfea227d6">
											<gml:posList>35.666815998246605 139.74786686421268 11.853345508643002 35.666813367421184 139.74787487931155 12.626638050146909 35.666815998246605 139.74786686421268 12.626638050146909 35.666815998246605 139.74786686421268 11.853345508643002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_51c5511e-158b-490d-a15a-719d9c489ad3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7dd7984b-3bf6-4d45-9c10-97ba8eaca9d7">
											<gml:posList>35.666813367421184 139.74787487931155 12.626638050146909 35.666815998246605 139.74786686421268 11.853345508643002 35.666813367421184 139.74787487931155 11.853345508643002 35.666813367421184 139.74787487931155 12.626638050146909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_765e1eae-0585-47dd-8120-a94a40b0242f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0a038353-5502-4809-8d2b-8434826e31ec">
											<gml:posList>35.66682098663 139.7478516664117 11.853345508643002 35.666818435148656 139.7478594399019 12.626638050146909 35.66682098663 139.7478516664117 12.626638050146909 35.66682098663 139.7478516664117 11.853345508643002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6eafd497-b559-4c59-bd24-b87fca4c9ae6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8e65dde3-bf58-4b73-a6a0-4aaec0f0f158">
											<gml:posList>35.666818435148656 139.7478594399019 12.626638050146909 35.66682098663 139.7478516664117 11.853345508643002 35.666818435148656 139.7478594399019 11.853345508643002 35.666818435148656 139.7478594399019 12.626638050146909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fd377ac6-2d63-4684-9cac-2141df6623fd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4ed0b81b-0787-492e-8fc3-45521697d3e3">
											<gml:posList>35.66680202752375 139.74790942762223 6.298749561377377 35.666813367421184 139.74787487931155 11.853345508643002 35.666815998246605 139.74786686421268 11.853345508643002 35.66680202752375 139.74790942762223 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_91b060f7-4199-4027-9c58-c760cd941fe3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0eb691af-de91-461e-9f27-4f8daaeb1b36">
											<gml:posList>35.666813367421184 139.74787487931155 11.853345508643002 35.66680202752375 139.74790942762223 6.298749561377377 35.666810930518174 139.7478823036214 11.853345508643002 35.666813367421184 139.74787487931155 11.853345508643002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c1526ac6-16b7-4614-b379-5b4dbd19c4cd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d79830e2-fe90-4deb-beb1-0f8f38ace961">
											<gml:posList>35.66680202752375 139.74790942762223 6.298749561377377 35.666818435148656 139.7478594399019 11.853345508643002 35.66683680990699 139.74780345879026 6.298749561377377 35.66680202752375 139.74790942762223 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cb93ab0d-7105-4084-a819-f4a04420ee3a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a1ce9e12-3dc0-4594-a450-bef68dcbd30a">
											<gml:posList>35.666818435148656 139.7478594399019 11.853345508643002 35.66680202752375 139.74790942762223 6.298749561377377 35.666815998246605 139.74786686421268 11.853345508643002 35.666818435148656 139.7478594399019 11.853345508643002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6e3bc8c6-2808-451a-b0b3-587b833bfbc0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3f105d05-977d-488b-837b-6960525c3705">
											<gml:posList>35.66682608972859 139.74783611926108 11.702535266943784 35.666823423531106 139.7478442421 11.853345508643002 35.66682608972859 139.74783611926108 12.47582780844769 35.66682608972859 139.74783611926108 11.702535266943784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e34c9c89-0628-462b-907a-a42530a5dec5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_155f9345-0960-491e-a281-5dcf07003713">
											<gml:posList>35.666823423531106 139.7478442421 11.853345508643002 35.66682608972859 139.74783611926108 11.702535266943784 35.66683680990699 139.74780345879026 6.298749561377377 35.666823423531106 139.7478442421 11.853345508643002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b558f84e-eb62-437a-9635-6d6829cdc885">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d2ac6682-6036-47e6-955a-217b2acfde02">
											<gml:posList>35.66683680990699 139.74780345879026 6.298749561377377 35.66682098663 139.7478516664117 11.853345508643002 35.666823423531106 139.7478442421 11.853345508643002 35.66683680990699 139.74780345879026 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5850dc8e-eae1-4eee-977f-bf9f5a046835">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1fdba91e-9818-433e-afba-0f423703cd0c">
											<gml:posList>35.66682098663 139.7478516664117 11.853345508643002 35.66683680990699 139.74780345879026 6.298749561377377 35.666818435148656 139.7478594399019 11.853345508643002 35.66682098663 139.7478516664117 11.853345508643002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c4da7ed7-42ab-4905-a853-7a2ef03a9cfb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a281f81d-6155-4447-8d53-590a0168f2a7">
											<gml:posList>35.66682608972859 139.74783611926108 12.47582780844769 35.666823423531106 139.7478442421 11.853345508643002 35.666823423531106 139.7478442421 12.626638050146909 35.66682608972859 139.74783611926108 12.47582780844769</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_56b33638-eff1-474c-a86f-c1538a0fe29f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ae198b1b-df10-4429-b914-b3f9a46ec67a">
											<gml:posList>35.66682608972859 139.74783611926108 12.47582780844769 35.666823423531106 139.7478442421 12.626638050146909 35.66683680990699 139.74780345879026 14.313748951025815 35.66682608972859 139.74783611926108 12.47582780844769</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fa07ad5d-b82e-49b0-a47d-f05e3fce8b65">
									<gml:exterior>
										<gml:LinearRing gml:id="line_13535967-f775-4d8b-93ca-eedfd93aa1eb">
											<gml:posList>35.66682608972859 139.74783611926108 12.47582780844769 35.66683680990699 139.74780345879026 14.313748951025815 35.66682852662862 139.7478286947799 12.47582780844769 35.66682608972859 139.74783611926108 12.47582780844769</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_17682a8f-5704-48f5-a0f8-6361b1bb36a6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_50758397-3952-4e46-bfb4-29dbcd6ddd04">
											<gml:posList>35.66682852662862 139.7478286947799 12.47582780844769 35.66683680990699 139.74780345879026 14.313748951025815 35.666831192224635 139.7478205737946 12.47582780844769 35.66682852662862 139.7478286947799 12.47582780844769</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_d574f055-4c31-49ca-8f18-54e8d3ff2a80">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_8bde2eda-f4c4-47e4-877b-7c79b3470ed0">
											<gml:exterior>
												<gml:LinearRing gml:id="line_cce134e8-c223-4fb9-8f04-cffdab76a1ef">
													<gml:posList>35.66682608972859 139.74783611926108 12.47582780844769 35.66682852662862 139.7478286947799 12.47582780844769 35.66682608972859 139.74783611926108 11.702535266943784 35.66682608972859 139.74783611926108 12.47582780844769</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_caac8bfc-b08d-418d-9cbd-411633e6d11f">
											<gml:exterior>
												<gml:LinearRing gml:id="line_f034129d-cd04-4d89-8137-707a44ad2413">
													<gml:posList>35.66682608972859 139.74783611926108 11.702535266943784 35.66682852662862 139.7478286947799 12.47582780844769 35.66682852662862 139.7478286947799 11.702535266943784 35.66682608972859 139.74783611926108 11.702535266943784</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_23aa6d7d-ef90-4803-a450-59d5090d3e9d">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_c1d57bcf-08ac-4118-a031-57ef554faa7f">
											<gml:exterior>
												<gml:LinearRing gml:id="line_25a2b019-0f16-47fc-be92-ea92c7059497">
													<gml:posList>35.666810930518174 139.7478823036214 12.626638050146909 35.666813367421184 139.74787487931155 12.626638050146909 35.666810930518174 139.7478823036214 11.853345508643002 35.666810930518174 139.7478823036214 12.626638050146909</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_aa25b340-4955-476e-a11c-65f8b2e3950b">
											<gml:exterior>
												<gml:LinearRing gml:id="line_58ce04f7-4828-498a-8cd3-1dffa0dfc1fd">
													<gml:posList>35.666810930518174 139.7478823036214 11.853345508643002 35.666813367421184 139.74787487931155 12.626638050146909 35.666813367421184 139.74787487931155 11.853345508643002 35.666810930518174 139.7478823036214 11.853345508643002</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_f3fd3b29-3e87-4129-88b2-6a4325ff21d9">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_818f46a4-ec7e-4f69-9e31-ca9388bcfc09">
											<gml:exterior>
												<gml:LinearRing gml:id="line_9b6bc301-8699-4c68-871a-ca57503354eb">
													<gml:posList>35.66680581935067 139.7478978753823 12.626638050146909 35.66680825625463 139.7478904510734 12.626638050146909 35.66680581935067 139.7478978753823 11.853345508643002 35.66680581935067 139.7478978753823 12.626638050146909</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_83e8b094-8461-4dd7-ac99-2372b0f0ca6a">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e3308f1c-62a5-414a-a80e-9f9e0bd3269f">
													<gml:posList>35.66680581935067 139.7478978753823 11.853345508643002 35.66680825625463 139.7478904510734 12.626638050146909 35.66680825625463 139.7478904510734 11.853345508643002 35.66680581935067 139.7478978753823 11.853345508643002</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_fb57fef4-96e8-4758-b316-a6c9e8976565">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_024c4c20-7c81-46fd-b17b-873ffbc5997c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_209c3124-efba-4972-8a20-a02d379c9763">
													<gml:posList>35.666831192224635 139.7478205737946 12.47582780844769 35.66683362912382 139.74781314948103 12.47582780844769 35.666831192224635 139.7478205737946 11.702535266943784 35.666831192224635 139.7478205737946 12.47582780844769</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e77a73c3-7de4-40fc-9eb6-f31cbf6f5c83">
											<gml:exterior>
												<gml:LinearRing gml:id="line_00ba5cf1-a33d-4435-9ab8-e640eb50f80e">
													<gml:posList>35.666831192224635 139.7478205737946 11.702535266943784 35.66683362912382 139.74781314948103 12.47582780844769 35.66683362912382 139.74781314948103 11.702535266943784 35.666831192224635 139.7478205737946 11.702535266943784</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_9c6b2198-b6d3-490b-8aa1-2836d1ad772d">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_ecfd2e28-2489-4c5a-af51-9c789e54b7b2">
											<gml:exterior>
												<gml:LinearRing gml:id="line_c3bc2365-46eb-4c90-a79a-89faa0a1f418">
													<gml:posList>35.666815998246605 139.74786686421268 12.626638050146909 35.666818435148656 139.7478594399019 12.626638050146909 35.666815998246605 139.74786686421268 11.853345508643002 35.666815998246605 139.74786686421268 12.626638050146909</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_2c450c4e-5f09-4f46-ad64-4e031d74901f">
											<gml:exterior>
												<gml:LinearRing gml:id="line_2af4eb31-2719-41c9-98a7-6f151129f704">
													<gml:posList>35.666815998246605 139.74786686421268 11.853345508643002 35.666818435148656 139.7478594399019 12.626638050146909 35.666818435148656 139.7478594399019 11.853345508643002 35.666815998246605 139.74786686421268 11.853345508643002</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_090f110b-631c-4729-a80a-2427a937e1a2">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_ed79d47c-6c98-43c2-8c05-ecfeaedebe5a">
											<gml:exterior>
												<gml:LinearRing gml:id="line_3dc24c7d-0876-42ea-93f9-f15c29180b37">
													<gml:posList>35.66682098663 139.7478516664117 12.626638050146909 35.666823423531106 139.7478442421 12.626638050146909 35.66682098663 139.7478516664117 11.853345508643002 35.66682098663 139.7478516664117 12.626638050146909</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0e3cc7d7-751c-4fea-b577-f20fdda74041">
											<gml:exterior>
												<gml:LinearRing gml:id="line_aefd5f98-8b58-4f60-b47b-da30c81716d3">
													<gml:posList>35.66682098663 139.7478516664117 11.853345508643002 35.666823423531106 139.7478442421 12.626638050146909 35.666823423531106 139.7478442421 11.853345508643002 35.66682098663 139.7478516664117 11.853345508643002</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_be02ff30-332a-490b-9615-cf9ed7ee76e4">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ba6e9264-900a-4585-8c38-53559705f45b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e1a81c05-bac9-4f52-b17e-8130c6a16f0f">
											<gml:posList>35.66689353206189 139.74783141741605 6.298749561377377 35.66688743229471 139.74782841083731 11.636579151221127 35.66689353206189 139.74783141741605 15.055760974951596 35.66689353206189 139.74783141741605 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b1d7816f-8242-443d-bf57-cd2507bc61d7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e384491e-275a-443e-86e2-357ce527e78b">
											<gml:posList>35.66688743229471 139.74782841083731 11.636579151221127 35.66689353206189 139.74783141741605 6.298749561377377 35.66687174716883 139.74782067954058 11.636579151221127 35.66688743229471 139.74782841083731 11.636579151221127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_36dba550-795d-4e95-9950-0677787a0eca">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f1d86c58-3661-4bcc-bda2-d3e4196304ea">
											<gml:posList>35.66689353206189 139.74783141741605 15.055760974951596 35.66688743229471 139.74782841083731 11.636579151221127 35.66688743229471 139.74782841083731 12.987989063330502 35.66689353206189 139.74783141741605 15.055760974951596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0a7dac47-178a-4714-99a6-942ca0c4d1f0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b7c3ee38-4a36-4220-8bd8-5e34c3c2f393">
											<gml:posList>35.66689353206189 139.74783141741605 15.055760974951596 35.66688743229471 139.74782841083731 12.987989063330502 35.66687174716883 139.74782067954058 12.987989063330502 35.66689353206189 139.74783141741605 15.055760974951596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c9d2ec81-065e-4c74-ba39-b737ac02ad94">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6797067f-6458-4015-8ac9-3fd22c482b9b">
											<gml:posList>35.66689353206189 139.74783141741605 15.055760974951596 35.66687174716883 139.74782067954058 12.987989063330502 35.666859115963504 139.747814453469 12.987989063330502 35.66689353206189 139.74783141741605 15.055760974951596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_65e1dc25-d707-4545-9e49-50fdf3bb6b93">
									<gml:exterior>
										<gml:LinearRing gml:id="line_49035da0-8e0f-466b-b85e-206384f592c4">
											<gml:posList>35.66689353206189 139.74783141741605 15.055760974951596 35.666859115963504 139.747814453469 12.987989063330502 35.66683680990699 139.74780345879026 14.313748951025815 35.66689353206189 139.74783141741605 15.055760974951596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_88fcac2a-7daf-4568-9d41-8508ac2f7a7a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fb72249f-2eef-4095-9e2d-7e0723dbf049">
											<gml:posList>35.666859115963504 139.747814453469 11.636579151221127 35.66683680990699 139.74780345879026 6.298749561377377 35.66684343084538 139.7478067223463 11.636579151221127 35.666859115963504 139.747814453469 11.636579151221127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4dfe20bd-4f33-4ea5-b0bb-1f9c8ef55b53">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2abadd22-0444-4b41-8925-0287bb7d8892">
											<gml:posList>35.66683680990699 139.74780345879026 6.298749561377377 35.666859115963504 139.747814453469 11.636579151221127 35.66689353206189 139.74783141741605 6.298749561377377 35.66683680990699 139.74780345879026 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_780dd872-ba36-4b98-a139-d30db0a960ec">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f74c5823-0393-43ae-bf82-2843f27ae710">
											<gml:posList>35.66684343084538 139.7478067223463 11.636579151221127 35.66683680990699 139.74780345879026 6.298749561377377 35.66683680990699 139.74780345879026 14.313748951025815 35.66684343084538 139.7478067223463 11.636579151221127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_194add3a-2524-4cdb-a94f-6031dba379a2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ab1fa0d5-5721-4a5a-927f-3fef417f79f0">
											<gml:posList>35.66687174716883 139.74782067954058 11.636579151221127 35.66689353206189 139.74783141741605 6.298749561377377 35.666859115963504 139.747814453469 11.636579151221127 35.66687174716883 139.74782067954058 11.636579151221127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_25345925-4f2f-487b-9c58-98b5ec5e8af7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e26799df-62b8-4494-ba3e-61ab88e10c61">
											<gml:posList>35.66684343084538 139.7478067223463 11.636579151221127 35.66683680990699 139.74780345879026 14.313748951025815 35.66684343084538 139.7478067223463 12.987989063330502 35.66684343084538 139.7478067223463 11.636579151221127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_208031e6-f763-422b-9efa-cf9d362c1d13">
									<gml:exterior>
										<gml:LinearRing gml:id="line_74c07ab6-8fc3-4b69-8313-d0f41fb077d9">
											<gml:posList>35.66684343084538 139.7478067223463 12.987989063330502 35.66683680990699 139.74780345879026 14.313748951025815 35.666859115963504 139.747814453469 12.987989063330502 35.66684343084538 139.7478067223463 12.987989063330502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_14c3eb2c-65f3-4430-bfb9-b486b2fab0ce">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d40f79c1-e502-454b-b084-e8211369f7ef">
											<gml:posList>35.66687174716883 139.74782067954058 12.987989063330502 35.666859115963504 139.747814453469 11.636579151221127 35.666859115963504 139.747814453469 12.987989063330502 35.66687174716883 139.74782067954058 12.987989063330502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fcb86555-1b9a-4df4-a382-697ab5ee6df1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cbd9afc0-5432-4926-ae06-b34e76a86391">
											<gml:posList>35.666859115963504 139.747814453469 11.636579151221127 35.66687174716883 139.74782067954058 12.987989063330502 35.66687174716883 139.74782067954058 11.636579151221127 35.666859115963504 139.747814453469 11.636579151221127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_5802270a-f9f8-446d-8b35-584755c3c052">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_aca73295-d3d3-4ead-a1b0-cfd3c6587cfb">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e5378a80-7bc3-489a-8eef-6afcec473cca">
													<gml:posList>35.66684343084538 139.7478067223463 12.987989063330502 35.666859115963504 139.747814453469 12.987989063330502 35.66684343084538 139.7478067223463 11.636579151221127 35.66684343084538 139.7478067223463 12.987989063330502</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_77b23e7d-28e9-47d2-bd43-aa46c0e6ba56">
											<gml:exterior>
												<gml:LinearRing gml:id="line_1215ed66-9486-4092-96e4-a2af0a673e26">
													<gml:posList>35.66684343084538 139.7478067223463 11.636579151221127 35.666859115963504 139.747814453469 12.987989063330502 35.666859115963504 139.747814453469 11.636579151221127 35.66684343084538 139.7478067223463 11.636579151221127</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_6abf4aa6-230c-4a70-a188-9484b1f49a33">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_33c23c82-2984-4063-a73b-1dab07376aec">
											<gml:exterior>
												<gml:LinearRing gml:id="line_aff5e317-e864-4b1f-b77b-deca25ea040c">
													<gml:posList>35.66687174716883 139.74782067954058 12.987989063330502 35.66688743229471 139.74782841083731 12.987989063330502 35.66687174716883 139.74782067954058 11.636579151221127 35.66687174716883 139.74782067954058 12.987989063330502</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_9caa4fc2-0328-467d-8b84-552b2668e2df">
											<gml:exterior>
												<gml:LinearRing gml:id="line_c6a0ce94-a88a-472a-9bb3-d4268e362304">
													<gml:posList>35.66687174716883 139.74782067954058 11.636579151221127 35.66688743229471 139.74782841083731 12.987989063330502 35.66688743229471 139.74782841083731 11.636579151221127 35.66687174716883 139.74782067954058 11.636579151221127</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e883ca4c-6d3c-41ae-9c2a-49a66c630f93">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1371b554-2efc-46a5-9897-8dcb89d009ee">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dff3cbd9-139d-482e-909c-25b9015f95c7">
											<gml:posList>35.666914894067766 139.74776633515313 9.047254200049252 35.66692139966627 139.74776954186405 9.047254200049252 35.666914894067766 139.74776633515313 6.298749561377377 35.666914894067766 139.74776633515313 9.047254200049252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_de72a6fd-33fc-4747-b4a8-f3c734348930">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a95e73ac-d15e-4123-b47a-c7b5bac4240e">
											<gml:posList>35.666914894067766 139.74776633515313 6.298749561377377 35.66692139966627 139.74776954186405 9.047254200049252 35.66692139966627 139.74776954186405 6.298749561377377 35.666914894067766 139.74776633515313 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_da5f0e42-098f-4799-bd16-de7266c8a9da">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eef9bdbb-cbaf-4552-b06b-11523fad9141">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bc0842fa-9d0b-49be-ad01-59aa07215433">
											<gml:posList>35.66686306829769 139.74793951498793 15.112249012060971 35.66680202752375 139.74790942762223 6.298749561377377 35.66692340143323 139.74796925358973 6.298749561377377 35.66686306829769 139.74793951498793 15.112249012060971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c15e6478-bcf0-4578-bcfb-dcf139f3c703">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0e46ab7a-2cd4-4fb2-a778-b546612ff85d">
											<gml:posList>35.66680202752375 139.74790942762223 6.298749561377377 35.66686306829769 139.74793951498793 15.112249012060971 35.66680202752375 139.74790942762223 14.313748951025815 35.66680202752375 139.74790942762223 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6330a772-f9d3-4dff-b4c7-d081ca972b1f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7346a1be-8e7f-47be-b722-bd0e707e1a11">
											<gml:posList>35.66686306829769 139.74793951498793 15.112249012060971 35.66692340143323 139.74796925358973 6.298749561377377 35.66692340143323 139.74796925358973 14.313748951025815 35.66686306829769 139.74793951498793 15.112249012060971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_c473ac18-bcfb-477f-8b71-1e91304efb27">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2fd3354b-8f82-46a8-a475-7cf35044b1ef">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c5040ae9-80bb-4096-8faf-b82f03098646">
											<gml:posList>35.66695438469724 139.7478602514853 14.368367786475034 35.666982718999726 139.74777392721228 6.298749561377377 35.666982718999726 139.74777392721228 15.464994068213315 35.66695438469724 139.7478602514853 14.368367786475034</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_008528b8-e211-42d9-9015-fd0edb1aebf9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e1e8a593-d081-4a51-8dd5-23fad408aac0">
											<gml:posList>35.666982718999726 139.74777392721228 6.298749561377377 35.66695438469724 139.7478602514853 14.368367786475034 35.66695438469724 139.7478602514853 6.298749561377377 35.666982718999726 139.74777392721228 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6f24ebff-66df-4c4b-b484-97abb5db04e1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_71f89397-3a35-40c2-a4c0-d208bda8a910">
											<gml:posList>35.66695438469724 139.7478602514853 14.368367786475034 35.666982718999726 139.74777392721228 15.464994068213315 35.66695438469724 139.7478602514853 15.464994068213315 35.66695438469724 139.7478602514853 14.368367786475034</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0002_p44_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0002_p44_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0002_p44_3">
											<gml:posList>35.66698363501762 139.74777312376526 15.28674252 35.6669537927439 139.74786484062204 15.28610742 35.66695379723252 139.74786484173046 13.98908799 35.666955161298205 139.7478606494349 13.98911548 35.66695519043436 139.747860656624 5.57056403 35.666983668686306 139.74777313192877 5.57117037 35.66698363501762 139.74777312376526 15.28674252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_5ddd5c9b-e8d2-48f0-b3e7-5a8787c57bcc">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_07ec0dc1-2a14-4464-b1f9-88147f93b50d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_17ac204a-c7ba-4161-80d7-34ba7fd9e29f">
											<gml:posList>35.66695851174128 139.74786228564236 14.313748951025815 35.66692340143323 139.74796925358973 14.313748951025815 35.66695851174128 139.74786228564236 6.298749561377377 35.66695851174128 139.74786228564236 14.313748951025815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4947f2be-52c7-45fe-88c1-df1272681298">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9e181dd5-b8f3-4197-b2c3-b98d7ae1032e">
											<gml:posList>35.66695851174128 139.74786228564236 6.298749561377377 35.66692340143323 139.74796925358973 14.313748951025815 35.66692340143323 139.74796925358973 6.298749561377377 35.66695851174128 139.74786228564236 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_b377a180-a3fc-42ec-ac38-39582f44f372">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_67a5b627-9799-4986-a54f-06442d1306a7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_808d696f-04a4-465b-b909-af84fae8faf1">
											<gml:posList>35.66692869983242 139.74774730092705 9.047254200049252 35.66692546027154 139.74775717068897 9.047254200049252 35.66692869983242 139.74774730092705 6.298749561377377 35.66692869983242 139.74774730092705 9.047254200049252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_43e57ec9-4f96-45e4-b945-c727b90d549b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_11179d7d-4dbc-486a-8d04-5870452d26a2">
											<gml:posList>35.66692869983242 139.74774730092705 6.298749561377377 35.66692546027154 139.74775717068897 9.047254200049252 35.66692546027154 139.74775717068897 6.298749561377377 35.66692869983242 139.74774730092705 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0002_p45_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0002_p45_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0002_p45_3">
											<gml:posList>35.66683309396758 139.74780100222443 5.56496106 35.66683306519261 139.74780099516312 13.92553332 35.66689367377518 139.74783060835423 14.91079241 35.6668937060207 139.74783061628884 5.56773835 35.66683309396758 139.74780100222443 5.56496106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0002_p44_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0002_p44_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0002_p44_2">
											<gml:posList>35.66692215120107 139.74774308191968 15.28391683 35.66698363501762 139.74777312376526 15.28674252 35.666983668686306 139.74777313192877 5.57117037 35.66692218477571 139.7477430900374 5.56834468 35.66692215120107 139.74774308191968 15.28391683</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_3446da2d-43bf-4e06-a8be-726ba9b23d7e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5d0a1680-dd95-412d-9b05-b74bf60de588">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ced85fd7-033b-4ce7-accf-829415feecf2">
											<gml:posList>35.66691895467701 139.7477539639789 9.047254200049252 35.66691895467701 139.7477539639789 6.298749561377377 35.66692546027154 139.74775717068897 9.047254200049252 35.66691895467701 139.7477539639789 9.047254200049252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d0fad529-5dd5-4875-ba06-8604c0a0811e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_998338c0-fc8b-4f23-9428-c42e12fcb26a">
											<gml:posList>35.66692546027154 139.74775717068897 9.047254200049252 35.66691895467701 139.7477539639789 6.298749561377377 35.66692546027154 139.74775717068897 6.298749561377377 35.66692546027154 139.74775717068897 9.047254200049252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0002_p44_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0002_p44_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0002_p44_0">
											<gml:posList>35.6668937060207 139.74783061628884 5.56773835 35.66689367377518 139.74783060835423 14.91079241 35.66689231023542 139.74783479903397 14.91076248 35.66689230894983 139.74783479871735 15.28328176 35.66692215120107 139.74774308191968 15.28391683 35.66692218477571 139.7477430900374 5.56834468 35.6668937060207 139.74783061628884 5.56773835</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_c5f01ce5-be1c-495a-926e-c30d524a0e50">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_af208e62-aa6e-4b97-afac-590905e376a3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_00254a4c-8b7a-4f3f-8055-b325b66612d1">
											<gml:posList>35.666982718999726 139.74777392721228 15.464994068213315 35.66694469840722 139.74775518660496 12.523236866064877 35.66692219422904 139.74774409421767 15.464994068213315 35.666982718999726 139.74777392721228 15.464994068213315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b1675a71-3b8a-4e73-a819-1b810f8a295e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c522174e-b632-40a5-b3de-102f7976e107">
											<gml:posList>35.66692219422904 139.74774409421767 15.464994068213315 35.66694469840722 139.74775518660496 12.523236866064877 35.66693415793922 139.74774999115226 12.523236866064877 35.66692219422904 139.74774409421767 15.464994068213315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_844fd332-1fcd-491c-8470-bafb19b57304">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a01d2d19-16c4-4792-8d24-337a0904deee">
											<gml:posList>35.66692219422904 139.74774409421767 15.464994068213315 35.66693415793922 139.74774999115226 12.523236866064877 35.66693415793922 139.74774999115226 11.739431018896909 35.66692219422904 139.74774409421767 15.464994068213315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8460998f-5522-4f6f-a686-7e2a0e6cc631">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8f71868b-9bd2-4a9c-b8eb-2efe790089f1">
											<gml:posList>35.66692219422904 139.74774409421767 15.464994068213315 35.66693415793922 139.74774999115226 11.739431018896909 35.66692869983242 139.74774730092705 9.047254200049252 35.66692219422904 139.74774409421767 15.464994068213315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_28a56518-9102-4b04-bf7d-388a805cab66">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bb383f1d-705c-4609-b13b-0fb386682a3f">
											<gml:posList>35.66694982880769 139.74775771537745 9.047254200049252 35.666982718999726 139.74777392721228 6.298749561377377 35.66694982880769 139.74775771537745 6.298749561377377 35.66694982880769 139.74775771537745 9.047254200049252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_78d189a1-4f0a-4a0f-9990-2136f072ad45">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a01df23f-0b45-4648-a19b-55abbe909a75">
											<gml:posList>35.666982718999726 139.74777392721228 6.298749561377377 35.66694982880769 139.74775771537745 9.047254200049252 35.666982718999726 139.74777392721228 15.464994068213315 35.666982718999726 139.74777392721228 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_86d5cef3-8312-4e33-a7c0-673c10a6ed87">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8feef3db-da94-4c37-8bfa-25443a2466b3">
											<gml:posList>35.66694469840722 139.74775518660496 11.739431018896909 35.66694982880769 139.74775771537745 9.047254200049252 35.66693415793922 139.74774999115226 11.739431018896909 35.66694469840722 139.74775518660496 11.739431018896909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_26f53b33-da23-4eec-94b4-87c41307d701">
									<gml:exterior>
										<gml:LinearRing gml:id="line_936183ff-9662-4aae-8a98-1cee417890f5">
											<gml:posList>35.66694982880769 139.74775771537745 9.047254200049252 35.66694469840722 139.74775518660496 11.739431018896909 35.666982718999726 139.74777392721228 15.464994068213315 35.66694982880769 139.74775771537745 9.047254200049252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_82452260-36a7-4e2e-bbe3-81ff0619497f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bb5b59f4-9608-455b-8ccf-c1e85d8b4b59">
											<gml:posList>35.66693415793922 139.74774999115226 11.739431018896909 35.66694982880769 139.74775771537745 9.047254200049252 35.66692869983242 139.74774730092705 9.047254200049252 35.66693415793922 139.74774999115226 11.739431018896909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d0b3d0a3-5dac-476f-b106-5242b7e8d9fc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_45b4b30e-40f1-4ea6-9973-177d607ad1df">
											<gml:posList>35.66694469840722 139.74775518660496 12.523236866064877 35.666982718999726 139.74777392721228 15.464994068213315 35.66694469840722 139.74775518660496 11.739431018896909 35.66694469840722 139.74775518660496 12.523236866064877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_002aca25-4e09-4824-8b8b-c66aa30320bb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_05ea159f-b5fd-4051-9ab3-ac92676ebf6f">
											<gml:posList>35.66692219422904 139.74774409421767 15.464994068213315 35.66692869983242 139.74774730092705 9.047254200049252 35.66692219422904 139.74774409421767 6.298749561377377 35.66692219422904 139.74774409421767 15.464994068213315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c5b169cd-e317-4c8b-b379-8937e4dc98c2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_05fe7dc0-f459-4dc5-a6ea-741dcd7a8000">
											<gml:posList>35.66692219422904 139.74774409421767 6.298749561377377 35.66692869983242 139.74774730092705 9.047254200049252 35.66692869983242 139.74774730092705 6.298749561377377 35.66692219422904 139.74774409421767 6.298749561377377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_609a75d2-c071-4081-8a72-9b7c10c6d81b">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_45a128c4-9ae5-451e-9345-7b7521dd9289">
											<gml:exterior>
												<gml:LinearRing gml:id="line_31b0acd1-532c-4932-ad88-51ac1e2279de">
													<gml:posList>35.66693415793922 139.74774999115226 11.739431018896909 35.66693415793922 139.74774999115226 12.523236866064877 35.66694469840722 139.74775518660496 11.739431018896909 35.66693415793922 139.74774999115226 11.739431018896909</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_adc89ed0-0b02-496f-b37e-d4768372aee3">
											<gml:exterior>
												<gml:LinearRing gml:id="line_535d040b-df06-4401-8e04-a2a9ac34c4f9">
													<gml:posList>35.66694469840722 139.74775518660496 11.739431018896909 35.66693415793922 139.74774999115226 12.523236866064877 35.66694469840722 139.74775518660496 12.523236866064877 35.66694469840722 139.74775518660496 11.739431018896909</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0002_p45_6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0002_p45_6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0002_p45_6">
											<gml:posList>35.66692370846183 139.74796935198188 5.56999217 35.66692367956773 139.7479693447 13.93056442 35.66686300697944 139.74793970178465 14.97777564 35.666798233277305 139.74790805345958 13.92480729 35.66679826200648 139.7479080606612 5.56423503 35.66692370846183 139.74796935198188 5.56999217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0002_p45_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0002_p45_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0002_p45_2">
											<gml:posList>35.666798233277305 139.74790805345958 13.92480729 35.66683306519261 139.74780099516312 13.92553332 35.66683309396758 139.74780100222443 5.56496106 35.66679826200648 139.7479080606612 5.56423503 35.666798233277305 139.74790805345958 13.92480729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_6bf2e567-b473-4694-8014-74c12433d444">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_094b489f-f325-4610-9c4c-f2d5cd0b3b4f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1a2b2f52-4537-46ca-b5fb-49cfd7179fce">
											<gml:posList>35.66694982880769 139.74775771537745 9.047254200049252 35.66694109910502 139.74778431170736 6.298749561377377 35.66694109910502 139.74778431170736 9.047254200049252 35.66694982880769 139.74775771537745 9.047254200049252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9a1f9853-dd8c-43f8-bcec-1333c941fda5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9aee02b7-3126-417b-8ff6-08ddc7ab9501">
											<gml:posList>35.66694982880769 139.74775771537745 9.047254200049252 35.66694982880769 139.74775771537745 6.298749561377377 35.66694109910502 139.74778431170736 6.298749561377377 35.66694982880769 139.74775771537745 9.047254200049252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:lod3Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#Poly_0a6de9b1-35bf-4024-a049-1ad5d8a06efb"/>
							<gml:surfaceMember xlink:href="#Poly_1addc974-27ec-4355-86da-d112f757288e"/>
							<gml:surfaceMember xlink:href="#Poly_eef9bdbb-cbaf-4552-b06b-11523fad9141"/>
							<gml:surfaceMember xlink:href="#Poly_c15e6478-bcf0-4578-bcfb-dcf139f3c703"/>
							<gml:surfaceMember xlink:href="#Poly_6330a772-f9d3-4dff-b4c7-d081ca972b1f"/>
							<gml:surfaceMember xlink:href="#Poly_07ec0dc1-2a14-4464-b1f9-88147f93b50d"/>
							<gml:surfaceMember xlink:href="#Poly_4947f2be-52c7-45fe-88c1-df1272681298"/>
							<gml:surfaceMember xlink:href="#Poly_2fd3354b-8f82-46a8-a475-7cf35044b1ef"/>
							<gml:surfaceMember xlink:href="#Poly_008528b8-e211-42d9-9015-fd0edb1aebf9"/>
							<gml:surfaceMember xlink:href="#Poly_6f24ebff-66df-4c4b-b484-97abb5db04e1"/>
							<gml:surfaceMember xlink:href="#Poly_32ec3b93-035b-4f9f-8a10-2160dbd3313f"/>
							<gml:surfaceMember xlink:href="#Poly_5e84c17d-c16e-46e3-b6b7-2b3f58f37aa3"/>
							<gml:surfaceMember xlink:href="#Poly_4e31c579-92fd-4919-846d-b85cd3397d09"/>
							<gml:surfaceMember xlink:href="#Poly_c50e34fd-4e20-4b11-b7b0-f270d6655afd"/>
							<gml:surfaceMember xlink:href="#Poly_4150ab4d-1f29-481c-9d8a-31838e7f490f"/>
							<gml:surfaceMember xlink:href="#Poly_38bb7290-ad06-433e-b174-08a5d4621c6e"/>
							<gml:surfaceMember xlink:href="#Poly_a58b395e-7e07-4017-93c4-3e736fce3514"/>
							<gml:surfaceMember xlink:href="#Poly_92a1cba2-ad16-4058-940e-9d0c401627fc"/>
							<gml:surfaceMember xlink:href="#Poly_d3ea8b12-46f5-467e-9b28-342745f695d2"/>
							<gml:surfaceMember xlink:href="#Poly_e8f50e4e-5030-4663-8533-ae515903a906"/>
							<gml:surfaceMember xlink:href="#Poly_39e9b091-ad11-4e29-9791-90337fdacdb1"/>
							<gml:surfaceMember xlink:href="#Poly_ffb8fe8c-af42-4cbf-84c1-375249e75163"/>
							<gml:surfaceMember xlink:href="#Poly_17a8b39a-de93-4d7a-8bb3-7f14f6b989eb"/>
							<gml:surfaceMember xlink:href="#Poly_16f6eeed-c6ce-45b1-990f-fe6cc6c90f98"/>
							<gml:surfaceMember xlink:href="#Poly_883a328d-d759-4037-9ef3-e76bcb8c2e80"/>
							<gml:surfaceMember xlink:href="#Poly_521c105a-895e-42cc-a957-b0c0a28bdcf9"/>
							<gml:surfaceMember xlink:href="#Poly_1988a638-4f31-4c96-97a3-56c132edcff3"/>
							<gml:surfaceMember xlink:href="#Poly_3428a000-70e4-4e18-bdfe-a63069200b2b"/>
							<gml:surfaceMember xlink:href="#Poly_7d3171f1-cd45-43e5-9be8-09bd11fb72c1"/>
							<gml:surfaceMember xlink:href="#Poly_60f0d7f3-be4f-4ba6-adca-0e69975aa23a"/>
							<gml:surfaceMember xlink:href="#Poly_b876147a-9d9d-41e9-b027-cfcb756cc53a"/>
							<gml:surfaceMember xlink:href="#Poly_0fd21176-bff1-4fb4-b43d-6d834397ce92"/>
							<gml:surfaceMember xlink:href="#Poly_97e4abeb-0b50-40d8-a268-195f6bac3eef"/>
							<gml:surfaceMember xlink:href="#Poly_51c5511e-158b-490d-a15a-719d9c489ad3"/>
							<gml:surfaceMember xlink:href="#Poly_765e1eae-0585-47dd-8120-a94a40b0242f"/>
							<gml:surfaceMember xlink:href="#Poly_6eafd497-b559-4c59-bd24-b87fca4c9ae6"/>
							<gml:surfaceMember xlink:href="#Poly_fd377ac6-2d63-4684-9cac-2141df6623fd"/>
							<gml:surfaceMember xlink:href="#Poly_91b060f7-4199-4027-9c58-c760cd941fe3"/>
							<gml:surfaceMember xlink:href="#Poly_c1526ac6-16b7-4614-b379-5b4dbd19c4cd"/>
							<gml:surfaceMember xlink:href="#Poly_cb93ab0d-7105-4084-a819-f4a04420ee3a"/>
							<gml:surfaceMember xlink:href="#Poly_6e3bc8c6-2808-451a-b0b3-587b833bfbc0"/>
							<gml:surfaceMember xlink:href="#Poly_e34c9c89-0628-462b-907a-a42530a5dec5"/>
							<gml:surfaceMember xlink:href="#Poly_b558f84e-eb62-437a-9635-6d6829cdc885"/>
							<gml:surfaceMember xlink:href="#Poly_5850dc8e-eae1-4eee-977f-bf9f5a046835"/>
							<gml:surfaceMember xlink:href="#Poly_c4da7ed7-42ab-4905-a853-7a2ef03a9cfb"/>
							<gml:surfaceMember xlink:href="#Poly_56b33638-eff1-474c-a86f-c1538a0fe29f"/>
							<gml:surfaceMember xlink:href="#Poly_fa07ad5d-b82e-49b0-a47d-f05e3fce8b65"/>
							<gml:surfaceMember xlink:href="#Poly_17682a8f-5704-48f5-a0f8-6361b1bb36a6"/>
							<gml:surfaceMember xlink:href="#Poly_818f46a4-ec7e-4f69-9e31-ca9388bcfc09"/>
							<gml:surfaceMember xlink:href="#Poly_83e8b094-8461-4dd7-ac99-2372b0f0ca6a"/>
							<gml:surfaceMember xlink:href="#Poly_c1d57bcf-08ac-4118-a031-57ef554faa7f"/>
							<gml:surfaceMember xlink:href="#Poly_aa25b340-4955-476e-a11c-65f8b2e3950b"/>
							<gml:surfaceMember xlink:href="#Poly_ecfd2e28-2489-4c5a-af51-9c789e54b7b2"/>
							<gml:surfaceMember xlink:href="#Poly_2c450c4e-5f09-4f46-ad64-4e031d74901f"/>
							<gml:surfaceMember xlink:href="#Poly_ed79d47c-6c98-43c2-8c05-ecfeaedebe5a"/>
							<gml:surfaceMember xlink:href="#Poly_0e3cc7d7-751c-4fea-b577-f20fdda74041"/>
							<gml:surfaceMember xlink:href="#Poly_8bde2eda-f4c4-47e4-877b-7c79b3470ed0"/>
							<gml:surfaceMember xlink:href="#Poly_caac8bfc-b08d-418d-9cbd-411633e6d11f"/>
							<gml:surfaceMember xlink:href="#Poly_ba6e9264-900a-4585-8c38-53559705f45b"/>
							<gml:surfaceMember xlink:href="#Poly_b1d7816f-8242-443d-bf57-cd2507bc61d7"/>
							<gml:surfaceMember xlink:href="#Poly_36dba550-795d-4e95-9950-0677787a0eca"/>
							<gml:surfaceMember xlink:href="#Poly_0a7dac47-178a-4714-99a6-942ca0c4d1f0"/>
							<gml:surfaceMember xlink:href="#Poly_c9d2ec81-065e-4c74-ba39-b737ac02ad94"/>
							<gml:surfaceMember xlink:href="#Poly_65e1dc25-d707-4545-9e49-50fdf3bb6b93"/>
							<gml:surfaceMember xlink:href="#Poly_88fcac2a-7daf-4568-9d41-8508ac2f7a7a"/>
							<gml:surfaceMember xlink:href="#Poly_4dfe20bd-4f33-4ea5-b0bb-1f9c8ef55b53"/>
							<gml:surfaceMember xlink:href="#Poly_780dd872-ba36-4b98-a139-d30db0a960ec"/>
							<gml:surfaceMember xlink:href="#Poly_194add3a-2524-4cdb-a94f-6031dba379a2"/>
							<gml:surfaceMember xlink:href="#Poly_25345925-4f2f-487b-9c58-98b5ec5e8af7"/>
							<gml:surfaceMember xlink:href="#Poly_208031e6-f763-422b-9efa-cf9d362c1d13"/>
							<gml:surfaceMember xlink:href="#Poly_14c3eb2c-65f3-4430-bfb9-b486b2fab0ce"/>
							<gml:surfaceMember xlink:href="#Poly_fcb86555-1b9a-4df4-a382-697ab5ee6df1"/>
							<gml:surfaceMember xlink:href="#Poly_aca73295-d3d3-4ead-a1b0-cfd3c6587cfb"/>
							<gml:surfaceMember xlink:href="#Poly_77b23e7d-28e9-47d2-bd43-aa46c0e6ba56"/>
							<gml:surfaceMember xlink:href="#Poly_3b73105e-f7f3-4f27-b18d-9231f6f6a1ad"/>
							<gml:surfaceMember xlink:href="#Poly_f8ce8733-94e2-44b3-a06e-afd61c91af9d"/>
							<gml:surfaceMember xlink:href="#Poly_21a129a8-d60e-432e-a3dd-fb870d559662"/>
							<gml:surfaceMember xlink:href="#Poly_c5e890a8-d240-4320-8f77-4d2c558b0cfc"/>
							<gml:surfaceMember xlink:href="#Poly_67a5b627-9799-4986-a54f-06442d1306a7"/>
							<gml:surfaceMember xlink:href="#Poly_43e57ec9-4f96-45e4-b945-c727b90d549b"/>
							<gml:surfaceMember xlink:href="#Poly_45a128c4-9ae5-451e-9345-7b7521dd9289"/>
							<gml:surfaceMember xlink:href="#Poly_adc89ed0-0b02-496f-b37e-d4768372aee3"/>
							<gml:surfaceMember xlink:href="#Poly_7e7a6808-419a-4089-89b9-2b00b930be77"/>
							<gml:surfaceMember xlink:href="#Poly_4450009d-449a-43c2-8517-096dce5aec5d"/>
							<gml:surfaceMember xlink:href="#Poly_292e738e-f5d8-46d3-b374-5e56529718e0"/>
							<gml:surfaceMember xlink:href="#Poly_056c05dd-7b11-49b2-b54d-d3bbc2ba600d"/>
							<gml:surfaceMember xlink:href="#Poly_33c23c82-2984-4063-a73b-1dab07376aec"/>
							<gml:surfaceMember xlink:href="#Poly_9caa4fc2-0328-467d-8b84-552b2668e2df"/>
							<gml:surfaceMember xlink:href="#Poly_a8cfecb0-1bf5-40bb-ace9-20e85221c39a"/>
							<gml:surfaceMember xlink:href="#Poly_7804648d-d042-4013-8b80-4ae01797586b"/>
							<gml:surfaceMember xlink:href="#Poly_024c4c20-7c81-46fd-b17b-873ffbc5997c"/>
							<gml:surfaceMember xlink:href="#Poly_e77a73c3-7de4-40fc-9eb6-f31cbf6f5c83"/>
							<gml:surfaceMember xlink:href="#Poly_1371b554-2efc-46a5-9897-8dcb89d009ee"/>
							<gml:surfaceMember xlink:href="#Poly_de72a6fd-33fc-4747-b4a8-f3c734348930"/>
							<gml:surfaceMember xlink:href="#Poly_5d0a1680-dd95-412d-9b05-b74bf60de588"/>
							<gml:surfaceMember xlink:href="#Poly_d0fad529-5dd5-4875-ba06-8604c0a0811e"/>
							<gml:surfaceMember xlink:href="#Poly_8f9b881d-3aec-4e3a-ac0d-fbfbb2c75ce5"/>
							<gml:surfaceMember xlink:href="#Poly_47f77b95-72d9-4ebd-b616-f64ec91961eb"/>
							<gml:surfaceMember xlink:href="#Poly_505d259b-81fc-4bfa-86a4-03fb29841d1c"/>
							<gml:surfaceMember xlink:href="#Poly_560a7dd6-fc15-4852-a3a0-eb3e90404382"/>
							<gml:surfaceMember xlink:href="#Poly_7da05933-6444-4b6a-8a1d-5d83f8b7ac4b"/>
							<gml:surfaceMember xlink:href="#Poly_305d3f4b-11c8-49a4-8243-69a0296a3659"/>
							<gml:surfaceMember xlink:href="#Poly_63c242c9-0b49-4f5d-b7a7-8e983616af2e"/>
							<gml:surfaceMember xlink:href="#Poly_6ac51d28-cec2-4f95-8246-5a5075f6514c"/>
							<gml:surfaceMember xlink:href="#Poly_661dfeda-ae61-4f8d-90dc-07b2a48f19cf"/>
							<gml:surfaceMember xlink:href="#Poly_dddba107-8312-420c-a5d5-ebf52d46ff1e"/>
							<gml:surfaceMember xlink:href="#Poly_94580602-c962-4adb-acbd-704ab72ab4f8"/>
							<gml:surfaceMember xlink:href="#Poly_f0c2c498-9bd4-4aef-8d43-a07605121643"/>
							<gml:surfaceMember xlink:href="#Poly_09a94c28-d181-4c3d-b865-684d85813439"/>
							<gml:surfaceMember xlink:href="#Poly_06a70805-cb80-44bc-8ca7-8a97086867a1"/>
							<gml:surfaceMember xlink:href="#Poly_3a0ee78d-fcc5-4279-b876-a266be7958c2"/>
							<gml:surfaceMember xlink:href="#Poly_eec11342-db61-48e7-baba-cfd4f3b7b827"/>
							<gml:surfaceMember xlink:href="#Poly_205bc838-114b-40ac-8ad4-0fd0088e1591"/>
							<gml:surfaceMember xlink:href="#Poly_9a22b832-8c01-4374-953b-fc0a99b9cb3b"/>
							<gml:surfaceMember xlink:href="#Poly_a433b07d-2ed8-4a08-9de6-ecb3c2d58523"/>
							<gml:surfaceMember xlink:href="#Poly_e3bef672-a703-4015-8941-48f5dea4a368"/>
							<gml:surfaceMember xlink:href="#Poly_81c2bb5b-8f95-418d-b86f-5f7394c69fe2"/>
							<gml:surfaceMember xlink:href="#Poly_c617d5d6-35f9-474f-87b7-7d8f2e4c1fe2"/>
							<gml:surfaceMember xlink:href="#Poly_aeae2178-d533-4578-92ca-5cc7b4819151"/>
							<gml:surfaceMember xlink:href="#Poly_cb0c3d57-f1d3-4352-bb05-a18f90efbcdd"/>
							<gml:surfaceMember xlink:href="#Poly_ca17b8fe-d7fc-4803-b7e0-292aefaf27d7"/>
							<gml:surfaceMember xlink:href="#Poly_1451eb15-af84-4b99-992b-aa75fa0544c8"/>
							<gml:surfaceMember xlink:href="#Poly_0ce001ff-3703-4eed-9298-b9f4142422f3"/>
							<gml:surfaceMember xlink:href="#Poly_7f973a3e-6f16-4b40-9170-ff4cc495c0ec"/>
							<gml:surfaceMember xlink:href="#Poly_2abb2d12-5a6f-440d-9ffc-80350572c7bb"/>
							<gml:surfaceMember xlink:href="#Poly_17f2fcc0-1019-4af7-a57e-a392db7c247a"/>
							<gml:surfaceMember xlink:href="#Poly_af208e62-aa6e-4b97-afac-590905e376a3"/>
							<gml:surfaceMember xlink:href="#Poly_b1675a71-3b8a-4e73-a819-1b810f8a295e"/>
							<gml:surfaceMember xlink:href="#Poly_844fd332-1fcd-491c-8470-bafb19b57304"/>
							<gml:surfaceMember xlink:href="#Poly_8460998f-5522-4f6f-a686-7e2a0e6cc631"/>
							<gml:surfaceMember xlink:href="#Poly_28a56518-9102-4b04-bf7d-388a805cab66"/>
							<gml:surfaceMember xlink:href="#Poly_78d189a1-4f0a-4a0f-9990-2136f072ad45"/>
							<gml:surfaceMember xlink:href="#Poly_86d5cef3-8312-4e33-a7c0-673c10a6ed87"/>
							<gml:surfaceMember xlink:href="#Poly_26f53b33-da23-4eec-94b4-87c41307d701"/>
							<gml:surfaceMember xlink:href="#Poly_82452260-36a7-4e2e-bbe3-81ff0619497f"/>
							<gml:surfaceMember xlink:href="#Poly_d0b3d0a3-5dac-476f-b106-5242b7e8d9fc"/>
							<gml:surfaceMember xlink:href="#Poly_002aca25-4e09-4824-8b8b-c66aa30320bb"/>
							<gml:surfaceMember xlink:href="#Poly_c5b169cd-e317-4c8b-b379-8937e4dc98c2"/>
							<gml:surfaceMember xlink:href="#Poly_094b489f-f325-4610-9c4c-f2d5cd0b3b4f"/>
							<gml:surfaceMember xlink:href="#Poly_9a1f9853-dd8c-43f8-bcec-1333c941fda5"/>
							<gml:surfaceMember xlink:href="#Poly_0265f053-338d-4f60-840b-d20fb9fd5aba"/>
							<gml:surfaceMember xlink:href="#Poly_f4135923-75d7-42b8-9dca-150726498d9b"/>
							<gml:surfaceMember xlink:href="#Poly_5ff5f6bc-ee4d-47a0-a836-67e810919bb4"/>
							<gml:surfaceMember xlink:href="#Poly_57ce284c-5517-469c-a64c-01af30ced218"/>
							<gml:surfaceMember xlink:href="#Poly_9f98618a-51e3-451c-b2b8-91e1389d9ba1"/>
							<gml:surfaceMember xlink:href="#Poly_0e4d7346-6e76-4761-b957-28d367a3ba3a"/>
							<gml:surfaceMember xlink:href="#Poly_6b2ceea0-cdbd-4d8b-a825-94d8c6ef8c40"/>
							<gml:surfaceMember xlink:href="#Poly_1abdd340-0608-45cc-89b2-d70a175ea7de"/>
							<gml:surfaceMember xlink:href="#Poly_2222264b-1a01-4e44-a07c-16563b6882ee"/>
							<gml:surfaceMember xlink:href="#Poly_0dd93e02-db4a-4a53-99a3-3ca3a1771684"/>
							<gml:surfaceMember xlink:href="#Poly_1dde1abe-5ebf-43ba-ae87-416d5052d2d5"/>
							<gml:surfaceMember xlink:href="#Poly_9eec35ab-3662-4952-9cd3-c4ee792e8f13"/>
							<gml:surfaceMember xlink:href="#Poly_322bd7b9-eac3-441a-a4c6-9ab24afa1e1d"/>
							<gml:surfaceMember xlink:href="#Poly_84233e98-8d00-40a0-a1b1-b8ad5758993a"/>
							<gml:surfaceMember xlink:href="#Poly_3d8d5c7c-5d8c-4361-b77d-8c68468b5b8f"/>
							<gml:surfaceMember xlink:href="#Poly_ab3e9913-fe03-4b09-ae66-672023d179b3"/>
							<gml:surfaceMember xlink:href="#Poly_31c8ebf2-0b0c-4ccc-938d-7c2cd0f8edee"/>
							<gml:surfaceMember xlink:href="#Poly_5cc7aa8f-bb2f-499d-b3a5-3999a7b4f692"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod3Solid>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">3</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">2</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">2</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
					<uro:lodType>3.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">234.0034</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">9</uro:districtsAndZonesType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">216</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1431</uro:detailedUsage>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2739700000</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>