<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a981e070-bab4-479b-8f07-0bb490fe6e55">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="説明注記">
				<gen:value>集合住宅付属施設</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">3.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66830773957747 139.73762147837962 0 35.668345015272514 139.73762639352964 0 35.66834756117874 139.7375974500255 0 35.66836997964106 139.73763311282733 0 35.66840239574244 139.737602509893 0 35.66837004960161 139.73755105214187 0 35.66834996406188 139.7375700199896 0 35.66835068759374 139.73756174568678 0 35.66833311798999 139.73755943597084 0 35.66833632490202 139.73752295832244 0 35.66831661880736 139.737520352927 0 35.66830773957747 139.73762147837962 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66830773957747 139.73762147837962 28.609 35.66831661880736 139.737520352927 28.609 35.66833632490202 139.73752295832244 28.609 35.66833311798999 139.73755943597084 28.609 35.66835068759374 139.73756174568678 28.609 35.66834996406188 139.7375700199896 28.609 35.66837004960161 139.73755105214187 28.609 35.66840239574244 139.737602509893 28.609 35.66836997964106 139.73763311282733 28.609 35.66834756117874 139.7375974500255 28.609 35.668345015272514 139.73762639352964 28.609 35.66830773957747 139.73762147837962 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66830773957747 139.73762147837962 28.609 35.668345015272514 139.73762639352964 28.609 35.668345015272514 139.73762639352964 31.85 35.66830773957747 139.73762147837962 31.85 35.66830773957747 139.73762147837962 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668345015272514 139.73762639352964 28.609 35.66834756117874 139.7375974500255 28.609 35.66834756117874 139.7375974500255 31.85 35.668345015272514 139.73762639352964 31.85 35.668345015272514 139.73762639352964 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66834756117874 139.7375974500255 28.609 35.66836997964106 139.73763311282733 28.609 35.66836997964106 139.73763311282733 31.85 35.66834756117874 139.7375974500255 31.85 35.66834756117874 139.7375974500255 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66836997964106 139.73763311282733 28.609 35.66840239574244 139.737602509893 28.609 35.66840239574244 139.737602509893 31.85 35.66836997964106 139.73763311282733 31.85 35.66836997964106 139.73763311282733 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66840239574244 139.737602509893 28.609 35.66837004960161 139.73755105214187 28.609 35.66837004960161 139.73755105214187 31.85 35.66840239574244 139.737602509893 31.85 35.66840239574244 139.737602509893 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66837004960161 139.73755105214187 28.609 35.66834996406188 139.7375700199896 28.609 35.66834996406188 139.7375700199896 31.85 35.66837004960161 139.73755105214187 31.85 35.66837004960161 139.73755105214187 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66834996406188 139.7375700199896 28.609 35.66835068759374 139.73756174568678 28.609 35.66835068759374 139.73756174568678 31.85 35.66834996406188 139.7375700199896 31.85 35.66834996406188 139.7375700199896 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66835068759374 139.73756174568678 28.609 35.66833311798999 139.73755943597084 28.609 35.66833311798999 139.73755943597084 31.85 35.66835068759374 139.73756174568678 31.85 35.66835068759374 139.73756174568678 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66833311798999 139.73755943597084 28.609 35.66833632490202 139.73752295832244 28.609 35.66833632490202 139.73752295832244 31.85 35.66833311798999 139.73755943597084 31.85 35.66833311798999 139.73755943597084 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66833632490202 139.73752295832244 28.609 35.66831661880736 139.737520352927 28.609 35.66831661880736 139.737520352927 31.85 35.66833632490202 139.73752295832244 31.85 35.66833632490202 139.73752295832244 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66831661880736 139.737520352927 28.609 35.66830773957747 139.73762147837962 28.609 35.66830773957747 139.73762147837962 31.85 35.66831661880736 139.737520352927 31.85 35.66831661880736 139.737520352927 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66830773957747 139.73762147837962 31.85 35.668345015272514 139.73762639352964 31.85 35.66834756117874 139.7375974500255 31.85 35.66836997964106 139.73763311282733 31.85 35.66840239574244 139.737602509893 31.85 35.66837004960161 139.73755105214187 31.85 35.66834996406188 139.7375700199896 31.85 35.66835068759374 139.73756174568678 31.85 35.66833311798999 139.73755943597084 31.85 35.66833632490202 139.73752295832244 31.85 35.66831661880736 139.737520352927 31.85 35.66830773957747 139.73762147837962 31.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-da6bb7ed-18c1-4a7f-84cc-25498233acd9"/>
							<gml:surfaceMember xlink:href="#poly-309826f5-612b-4303-8ac2-b1de68fd4b0b"/>
							<gml:surfaceMember xlink:href="#poly-c0468c9b-5714-4144-8598-99140127f627"/>
							<gml:surfaceMember xlink:href="#poly-66783385-4d8b-48bc-829a-53caf538e72a"/>
							<gml:surfaceMember xlink:href="#poly-ca8b8e6e-4e76-4516-8c2b-e28635e6924d"/>
							<gml:surfaceMember xlink:href="#poly-c0f3c05a-7172-4ea0-ac71-0215e68ef79c"/>
							<gml:surfaceMember xlink:href="#poly-3019a2cd-1a48-4994-8400-86d326b29c7f"/>
							<gml:surfaceMember xlink:href="#poly-16613531-3a89-45d9-a9a0-730dd7cb03db"/>
							<gml:surfaceMember xlink:href="#poly-37a99e3b-e01d-4342-9a5b-368d28e77924"/>
							<gml:surfaceMember xlink:href="#poly-f4be3300-b53b-43e8-a299-604889f9d95e"/>
							<gml:surfaceMember xlink:href="#poly-6b90bddd-9a4c-42d5-8026-32d120c0f102"/>
							<gml:surfaceMember xlink:href="#poly-c4e6bfea-601a-4edd-afef-93598199ff6f"/>
							<gml:surfaceMember xlink:href="#poly-7f353957-ca52-40df-b803-a5877a71fc1a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-da6bb7ed-18c1-4a7f-84cc-25498233acd9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da6bb7ed-18c1-4a7f-84cc-25498233acd9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da6bb7ed-18c1-4a7f-84cc-25498233acd9">
											<gml:posList>35.66831661880734 139.737520352927 28.609 35.668336324902 139.73752295832244 28.609 35.668333117989974 139.7375594359708 28.609 35.668350687593716 139.73756174568678 28.609 35.66834996406189 139.7375700199896 28.609 35.66837004960161 139.73755105214187 28.609 35.66840239574243 139.737602509893 28.609 35.668369979641035 139.7376331128273 28.609 35.66834756117874 139.7375974500255 28.609 35.668345015272514 139.7376263935296 28.609 35.66830773957744 139.73762147837962 28.609 35.66831661880734 139.737520352927 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-309826f5-612b-4303-8ac2-b1de68fd4b0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-309826f5-612b-4303-8ac2-b1de68fd4b0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-309826f5-612b-4303-8ac2-b1de68fd4b0b">
											<gml:posList>35.66834756117874 139.7375974500255 31.529 35.668369979641035 139.7376331128273 31.529 35.66840239574243 139.737602509893 31.529 35.66837004960161 139.73755105214187 31.529 35.66834996406189 139.7375700199896 31.529 35.668350687593716 139.73756174568678 31.529 35.668333117989974 139.7375594359708 31.529 35.668336324902 139.73752295832244 31.529 35.66831661880734 139.737520352927 31.529 35.66830773957744 139.73762147837962 31.529 35.668345015272514 139.7376263935296 31.529 35.66834756117874 139.7375974500255 31.529</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0468c9b-5714-4144-8598-99140127f627">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0468c9b-5714-4144-8598-99140127f627">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0468c9b-5714-4144-8598-99140127f627">
											<gml:posList>35.668336324902 139.73752295832244 28.609 35.66831661880734 139.737520352927 28.609 35.66831661880734 139.737520352927 31.529 35.668336324902 139.73752295832244 31.529 35.668336324902 139.73752295832244 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66783385-4d8b-48bc-829a-53caf538e72a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66783385-4d8b-48bc-829a-53caf538e72a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66783385-4d8b-48bc-829a-53caf538e72a">
											<gml:posList>35.668333117989974 139.7375594359708 28.609 35.668336324902 139.73752295832244 28.609 35.668336324902 139.73752295832244 31.529 35.668333117989974 139.7375594359708 31.529 35.668333117989974 139.7375594359708 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca8b8e6e-4e76-4516-8c2b-e28635e6924d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca8b8e6e-4e76-4516-8c2b-e28635e6924d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca8b8e6e-4e76-4516-8c2b-e28635e6924d">
											<gml:posList>35.66837004960161 139.73755105214187 28.609 35.66834996406189 139.7375700199896 28.609 35.66834996406189 139.7375700199896 31.529 35.66837004960161 139.73755105214187 31.529 35.66837004960161 139.73755105214187 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0f3c05a-7172-4ea0-ac71-0215e68ef79c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0f3c05a-7172-4ea0-ac71-0215e68ef79c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0f3c05a-7172-4ea0-ac71-0215e68ef79c">
											<gml:posList>35.668350687593716 139.73756174568678 28.609 35.668333117989974 139.7375594359708 28.609 35.668333117989974 139.7375594359708 31.529 35.668350687593716 139.73756174568678 31.529 35.668350687593716 139.73756174568678 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3019a2cd-1a48-4994-8400-86d326b29c7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3019a2cd-1a48-4994-8400-86d326b29c7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3019a2cd-1a48-4994-8400-86d326b29c7f">
											<gml:posList>35.66834996406189 139.7375700199896 28.609 35.668350687593716 139.73756174568678 28.609 35.668350687593716 139.73756174568678 31.529 35.66834996406189 139.7375700199896 31.529 35.66834996406189 139.7375700199896 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16613531-3a89-45d9-a9a0-730dd7cb03db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16613531-3a89-45d9-a9a0-730dd7cb03db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16613531-3a89-45d9-a9a0-730dd7cb03db">
											<gml:posList>35.66831661880734 139.737520352927 28.609 35.66830773957744 139.73762147837962 28.609 35.66830773957744 139.73762147837962 31.529 35.66831661880734 139.737520352927 31.529 35.66831661880734 139.737520352927 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37a99e3b-e01d-4342-9a5b-368d28e77924">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37a99e3b-e01d-4342-9a5b-368d28e77924">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37a99e3b-e01d-4342-9a5b-368d28e77924">
											<gml:posList>35.66840239574243 139.737602509893 28.609 35.66837004960161 139.73755105214187 28.609 35.66837004960161 139.73755105214187 31.529 35.66840239574243 139.737602509893 31.529 35.66840239574243 139.737602509893 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4be3300-b53b-43e8-a299-604889f9d95e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4be3300-b53b-43e8-a299-604889f9d95e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4be3300-b53b-43e8-a299-604889f9d95e">
											<gml:posList>35.668345015272514 139.7376263935296 28.609 35.66834756117874 139.7375974500255 28.609 35.66834756117874 139.7375974500255 31.529 35.668345015272514 139.7376263935296 31.529 35.668345015272514 139.7376263935296 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b90bddd-9a4c-42d5-8026-32d120c0f102">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b90bddd-9a4c-42d5-8026-32d120c0f102">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b90bddd-9a4c-42d5-8026-32d120c0f102">
											<gml:posList>35.66834756117874 139.7375974500255 28.609 35.668369979641035 139.7376331128273 28.609 35.668369979641035 139.7376331128273 31.529 35.66834756117874 139.7375974500255 31.529 35.66834756117874 139.7375974500255 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4e6bfea-601a-4edd-afef-93598199ff6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4e6bfea-601a-4edd-afef-93598199ff6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4e6bfea-601a-4edd-afef-93598199ff6f">
											<gml:posList>35.668369979641035 139.7376331128273 28.609 35.66840239574243 139.737602509893 28.609 35.66840239574243 139.737602509893 31.529 35.668369979641035 139.7376331128273 31.529 35.668369979641035 139.7376331128273 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f353957-ca52-40df-b803-a5877a71fc1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f353957-ca52-40df-b803-a5877a71fc1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f353957-ca52-40df-b803-a5877a71fc1a">
											<gml:posList>35.66830773957744 139.73762147837962 28.609 35.668345015272514 139.7376263935296 28.609 35.668345015272514 139.7376263935296 31.529 35.66830773957744 139.73762147837962 31.529 35.66830773957744 139.73762147837962 28.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-94</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">101.15319</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">3</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>