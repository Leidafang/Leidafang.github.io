<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_a9ff0440-3fc9-4ebe-b96d-668a8a412bb8">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">12</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67021826284399 139.7390376560898 0 35.67024802154912 139.73916995505954 0 35.67032813228915 139.7391426871946 0 35.67033129763288 139.73915615990418 0 35.67043384605535 139.7391205809338 0 35.67041962836278 139.73905911413078 0 35.670394882017206 139.73906595877125 0 35.67037571708774 139.73898317854903 0 35.67021826284399 139.7390376560898 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021826284399 139.7390376560898 18.996 35.67037571708774 139.73898317854903 18.996 35.670394882017206 139.73906595877125 18.996 35.67041962836278 139.73905911413078 18.996 35.67043384605535 139.7391205809338 18.996 35.67033129763288 139.73915615990418 18.996 35.67032813228915 139.7391426871946 18.996 35.67024802154912 139.73916995505954 18.996 35.67021826284399 139.7390376560898 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021826284399 139.7390376560898 18.996 35.67024802154912 139.73916995505954 18.996 35.67024802154912 139.73916995505954 30.98 35.67021826284399 139.7390376560898 30.98 35.67021826284399 139.7390376560898 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67024802154912 139.73916995505954 18.996 35.67032813228915 139.7391426871946 18.996 35.67032813228915 139.7391426871946 30.98 35.67024802154912 139.73916995505954 30.98 35.67024802154912 139.73916995505954 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67032813228915 139.7391426871946 18.996 35.67033129763288 139.73915615990418 18.996 35.67033129763288 139.73915615990418 30.98 35.67032813228915 139.7391426871946 30.98 35.67032813228915 139.7391426871946 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033129763288 139.73915615990418 18.996 35.67043384605535 139.7391205809338 18.996 35.67043384605535 139.7391205809338 30.98 35.67033129763288 139.73915615990418 30.98 35.67033129763288 139.73915615990418 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67043384605535 139.7391205809338 18.996 35.67041962836278 139.73905911413078 18.996 35.67041962836278 139.73905911413078 30.98 35.67043384605535 139.7391205809338 30.98 35.67043384605535 139.7391205809338 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67041962836278 139.73905911413078 18.996 35.670394882017206 139.73906595877125 18.996 35.670394882017206 139.73906595877125 30.98 35.67041962836278 139.73905911413078 30.98 35.67041962836278 139.73905911413078 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670394882017206 139.73906595877125 18.996 35.67037571708774 139.73898317854903 18.996 35.67037571708774 139.73898317854903 30.98 35.670394882017206 139.73906595877125 30.98 35.670394882017206 139.73906595877125 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67037571708774 139.73898317854903 18.996 35.67021826284399 139.7390376560898 18.996 35.67021826284399 139.7390376560898 30.98 35.67037571708774 139.73898317854903 30.98 35.67037571708774 139.73898317854903 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021826284399 139.7390376560898 30.98 35.67024802154912 139.73916995505954 30.98 35.67032813228915 139.7391426871946 30.98 35.67033129763288 139.73915615990418 30.98 35.67043384605535 139.7391205809338 30.98 35.67041962836278 139.73905911413078 30.98 35.670394882017206 139.73906595877125 30.98 35.67037571708774 139.73898317854903 30.98 35.67021826284399 139.7390376560898 30.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7a51b0d2-3279-45f1-8012-34d70a049120"/>
							<gml:surfaceMember xlink:href="#poly-2a10c1e0-d356-4667-9cad-e1bf7d9e4239"/>
							<gml:surfaceMember xlink:href="#poly-a1f850d0-d19d-4cab-874f-1d05d22295f0"/>
							<gml:surfaceMember xlink:href="#poly-8a6daf58-2ad8-407f-a651-6d92508e8cad"/>
							<gml:surfaceMember xlink:href="#poly-3ef0e6ec-29bb-4744-b06c-d161e7647a24"/>
							<gml:surfaceMember xlink:href="#poly-10f84339-790c-4ae9-a46f-0f6479cab50a"/>
							<gml:surfaceMember xlink:href="#poly-2394f26a-e00f-40c8-9e83-336322f474ad"/>
							<gml:surfaceMember xlink:href="#poly-f2e6fc58-60bb-42d9-808b-9c49b36a9473"/>
							<gml:surfaceMember xlink:href="#poly-3b23dec9-3e3c-45b7-87fb-1ccc28085516"/>
							<gml:surfaceMember xlink:href="#poly-b6a06e1b-ad55-40b7-8da6-d90f54fd0d6c"/>
							<gml:surfaceMember xlink:href="#poly-67be9bc9-2eab-4986-adc7-07e8a3b24217"/>
							<gml:surfaceMember xlink:href="#poly-62332302-d63e-4b4d-be29-bd8aaa27975b"/>
							<gml:surfaceMember xlink:href="#poly-91ef02bf-a4cc-4eb0-a62f-5bf9bdeb30d8"/>
							<gml:surfaceMember xlink:href="#poly-e8e11295-3263-4a3e-8918-6203504cdc72"/>
							<gml:surfaceMember xlink:href="#poly-c87344be-09ff-4023-b71a-a77eddf5bb2e"/>
							<gml:surfaceMember xlink:href="#poly-8646553d-8589-4388-ae56-718c30390cb6"/>
							<gml:surfaceMember xlink:href="#poly-741481af-db4c-4cf9-bd0a-d8bd9dac04e1"/>
							<gml:surfaceMember xlink:href="#poly-082f9881-64b0-47da-b2e9-eaf4bfca6e2b"/>
							<gml:surfaceMember xlink:href="#poly-a3a553f3-914c-4ee8-9752-2736368da39f"/>
							<gml:surfaceMember xlink:href="#poly-b672fd4d-f854-41c3-af72-effc9fbfe743"/>
							<gml:surfaceMember xlink:href="#poly-dd5f3c9a-4057-4b55-9fac-d4d881a05bb1"/>
							<gml:surfaceMember xlink:href="#poly-bc4c60fa-78c2-434c-aef2-4f8520540cc3"/>
							<gml:surfaceMember xlink:href="#poly-76c6cc06-9a8e-4b43-9a05-8fbffd5193cc"/>
							<gml:surfaceMember xlink:href="#poly-d56f6df5-058f-4848-92ed-13323001da67"/>
							<gml:surfaceMember xlink:href="#poly-d826a14b-84a1-427c-899e-1535ce84a90a"/>
							<gml:surfaceMember xlink:href="#poly-40826d08-a4c5-49fe-9630-889ecc42ac17"/>
							<gml:surfaceMember xlink:href="#poly-813a92e6-46fa-44c2-88cf-9830864d4fea"/>
							<gml:surfaceMember xlink:href="#poly-1b145b97-adae-45ff-bde8-71f3053c1726"/>
							<gml:surfaceMember xlink:href="#poly-faca2d11-32fe-4f48-89be-7d83bcb87735"/>
							<gml:surfaceMember xlink:href="#poly-4fc38ac4-9fcb-475e-93d6-9efc60d44e10"/>
							<gml:surfaceMember xlink:href="#poly-293eb4b4-3257-450c-a1f0-7843f4427c23"/>
							<gml:surfaceMember xlink:href="#poly-dd307bf4-f368-46a9-b2e5-f7b3aec4faa0"/>
							<gml:surfaceMember xlink:href="#poly-c2904c4c-a9ea-475a-86c3-c8faae342433"/>
							<gml:surfaceMember xlink:href="#poly-fea637f2-a625-4846-84f4-bb3fc638521f"/>
							<gml:surfaceMember xlink:href="#poly-84509ca1-6d01-4a79-830f-b8ca637a27f9"/>
							<gml:surfaceMember xlink:href="#poly-6de8d770-c0e8-4fc6-b7eb-95355c460276"/>
							<gml:surfaceMember xlink:href="#poly-6be17cb3-a6eb-4051-8178-6e005b1ad791"/>
							<gml:surfaceMember xlink:href="#poly-fe933b61-dab3-442d-859e-f5d14b5e6c94"/>
							<gml:surfaceMember xlink:href="#poly-0491dc6c-cfca-43f7-9234-b848e5173287"/>
							<gml:surfaceMember xlink:href="#poly-3f6ae5cb-2fa1-48c4-a8aa-16169371c416"/>
							<gml:surfaceMember xlink:href="#poly-f6faa981-84b1-4884-a6a6-28bcd8e4213f"/>
							<gml:surfaceMember xlink:href="#poly-ffa92895-1015-466b-832d-28b97e43baea"/>
							<gml:surfaceMember xlink:href="#poly-e5839f95-b885-4408-898f-84740a868560"/>
							<gml:surfaceMember xlink:href="#poly-334d3049-370b-4e36-999d-5afbc82b627b"/>
							<gml:surfaceMember xlink:href="#poly-264a3635-8308-467d-830d-a64b301c915b"/>
							<gml:surfaceMember xlink:href="#poly-0cf90aff-6d60-4a4b-9249-6d208fea5829"/>
							<gml:surfaceMember xlink:href="#poly-51476fb4-abcf-41ae-b4e7-bcf39e45b29d"/>
							<gml:surfaceMember xlink:href="#poly-1ddd2f70-6980-4db2-bf6c-cc10780af9aa"/>
							<gml:surfaceMember xlink:href="#poly-3c874b46-05f3-4609-a01e-199a72b45071"/>
							<gml:surfaceMember xlink:href="#poly-ffb5ab94-fe86-40c6-8ba4-0088eeea5fe7"/>
							<gml:surfaceMember xlink:href="#poly-cb939c43-8abb-4517-bf31-f7fda5aa3930"/>
							<gml:surfaceMember xlink:href="#poly-a6a3c9b4-b1d3-4ef6-954b-c49f76694f2d"/>
							<gml:surfaceMember xlink:href="#poly-4d3b8c5f-e404-4117-a7de-796e83335337"/>
							<gml:surfaceMember xlink:href="#poly-0ef464b4-c20d-4c18-98e6-7fed0fbec55d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a9ff0440-3fc9-4ebe-b96d-668a8a412bb8_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-698ee35d-bd82-4a32-a193-4d6f2ca8d447">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67025155977558 139.73913005187947 27.625 35.67024068816374 139.7390826320979 27.625 35.67025603441753 139.7390773560468 27.625 35.670266906031436 139.73912477583673 27.625 35.67025155977558 139.73913005187947 27.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-421fb867-bd79-489e-a54c-84c91eeb153a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-421fb867-bd79-489e-a54c-84c91eeb153a_0">
											<gml:posList>35.67024068816374 139.7390826320979 27.625 35.67024068816374 139.7390826320979 29.619 35.67025603441753 139.7390773560468 29.619 35.67025603441753 139.7390773560468 27.625 35.67024068816374 139.7390826320979 27.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72290177-3b19-4324-8901-a65095668a2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72290177-3b19-4324-8901-a65095668a2c_0">
											<gml:posList>35.670266906031436 139.73912477583673 29.599 35.670256911748936 139.7390811880615 28.91 35.67025789760804 139.7390854838909 28.116 35.670266906031436 139.73912477583673 28.116 35.670266906031436 139.73912477583673 27.625 35.67025603441753 139.7390773560468 27.625 35.67025603441753 139.7390773560468 29.619 35.670266906031436 139.73912477583673 29.619 35.670266906031436 139.73912477583673 29.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca2e8fd8-3c22-41e4-9bb4-b0e274f4c559">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca2e8fd8-3c22-41e4-9bb4-b0e274f4c559_0">
											<gml:posList>35.670266906031436 139.73912477583673 29.599 35.670266906031436 139.73912477583673 28.116 35.67025789760804 139.7390854838909 28.116 35.670256911748936 139.7390811880615 28.91 35.670266906031436 139.73912477583673 29.599</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45e60924-597f-4fa9-a887-58d66edf6ef6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45e60924-597f-4fa9-a887-58d66edf6ef6_0">
											<gml:posList>35.67025603441753 139.7390773560468 29.619 35.67024068816374 139.7390826320979 29.619 35.67025155977558 139.73913005187947 29.619 35.670266906031436 139.73912477583673 29.619 35.67025603441753 139.7390773560468 29.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e4d42dc-5b6f-4443-a30c-7294b07cee51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e4d42dc-5b6f-4443-a30c-7294b07cee51_0">
											<gml:posList>35.67025155977558 139.73913005187947 27.625 35.67025155977558 139.73913005187947 29.619 35.67024068816374 139.7390826320979 29.619 35.67024068816374 139.7390826320979 27.625 35.67025155977558 139.73913005187947 27.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-485af15e-e29b-44e9-bf0f-7131b8b75a53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-485af15e-e29b-44e9-bf0f-7131b8b75a53_0">
											<gml:posList>35.67025155977558 139.73913005187947 29.619 35.67025155977558 139.73913005187947 27.625 35.670266906031436 139.73912477583673 27.625 35.670266906031436 139.73912477583673 28.116 35.670266906031436 139.73912477583673 29.599 35.670266906031436 139.73912477583673 29.619 35.67025155977558 139.73913005187947 29.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a9ff0440-3fc9-4ebe-b96d-668a8a412bb8_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-176e8ab7-445e-433b-b94f-89d177c6e83d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670248482135776 139.73904438084907 27.625 35.670224259753844 139.73905271610533 27.625 35.670221410700556 139.7390402924384 27.625 35.67024562405927 139.73903194614306 27.625 35.670248482135776 139.73904438084907 27.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a9e191f-9f07-45ed-bcfe-872caac5e222">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a9e191f-9f07-45ed-bcfe-872caac5e222_0">
											<gml:posList>35.67024562405927 139.73903194614306 29.344 35.67024562405927 139.73903194614306 27.625 35.670221410700556 139.7390402924384 27.625 35.670221410700556 139.7390402924384 29.344 35.67024562405927 139.73903194614306 29.344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c87cc0a-dcb5-4556-8999-be79685ed25b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c87cc0a-dcb5-4556-8999-be79685ed25b_0">
											<gml:posList>35.670248482135776 139.73904438084907 29.344 35.670248482135776 139.73904438084907 27.625 35.67024562405927 139.73903194614306 27.625 35.67024562405927 139.73903194614306 29.344 35.670248482135776 139.73904438084907 29.344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-907268fa-1c0e-4c2b-85e3-c6f060037646">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-907268fa-1c0e-4c2b-85e3-c6f060037646_0">
											<gml:posList>35.67024562405927 139.73903194614306 29.344 35.670221410700556 139.7390402924384 29.344 35.670224259753844 139.73905271610533 29.344 35.670248482135776 139.73904438084907 29.344 35.67024562405927 139.73903194614306 29.344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8525ff69-44b5-418e-bde8-d09b8897923c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8525ff69-44b5-418e-bde8-d09b8897923c_0">
											<gml:posList>35.670221410700556 139.7390402924384 29.344 35.670221410700556 139.7390402924384 27.625 35.670224259753844 139.73905271610533 27.625 35.670224259753844 139.73905271610533 29.344 35.670221410700556 139.7390402924384 29.344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-035f4d10-6b8b-47c2-9aaf-5eacbc0b25dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-035f4d10-6b8b-47c2-9aaf-5eacbc0b25dc_0">
											<gml:posList>35.670224259753844 139.73905271610533 29.344 35.670224259753844 139.73905271610533 27.625 35.670248482135776 139.73904438084907 27.625 35.670248482135776 139.73904438084907 29.344 35.670224259753844 139.73905271610533 29.344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_a9ff0440-3fc9-4ebe-b96d-668a8a412bb8_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d069f479-b9d5-4fd8-b7ac-b6d61f2729ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d069f479-b9d5-4fd8-b7ac-b6d61f2729ec_0">
											<gml:posList>35.67037571708774 139.73898317854903 30.127 35.670394882017206 139.73906595877125 18.996 35.670394882017206 139.73906595877125 40.702 35.67037571708774 139.73898317854903 30.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f539d910-a88e-494c-b923-c9bf13682237">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f539d910-a88e-494c-b923-c9bf13682237_0">
											<gml:posList>35.67037571708774 139.73898317854903 30.127 35.67037571708774 139.73898317854903 18.996 35.670394882017206 139.73906595877125 18.996 35.67037571708774 139.73898317854903 30.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea7704b8-7c2b-4a89-b83c-d8a12cbcfc1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea7704b8-7c2b-4a89-b83c-d8a12cbcfc1a_0">
											<gml:posList>35.67040011061239 139.73897469945308 30.127 35.67037571708774 139.73898317854903 18.996 35.67037571708774 139.73898317854903 30.127 35.67040011061239 139.73897469945308 30.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c0a32d5-92f7-45e2-a691-ad721c5d01cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c0a32d5-92f7-45e2-a691-ad721c5d01cf_0">
											<gml:posList>35.67040011061239 139.73897469945308 30.127 35.67040011061239 139.73897469945308 18.996 35.67037571708774 139.73898317854903 18.996 35.67040011061239 139.73897469945308 30.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-318e4b77-1c12-438d-b934-a99ad7277e74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-318e4b77-1c12-438d-b934-a99ad7277e74_0">
											<gml:posList>35.670394882017206 139.73906595877125 40.702 35.67041962836279 139.73905911413078 40.702 35.67040011061239 139.73897469945308 30.127 35.670394882017206 139.73906595877125 40.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-538a3266-8f5b-4a60-8750-5b2cd25f2b10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-538a3266-8f5b-4a60-8750-5b2cd25f2b10_0">
											<gml:posList>35.67037571708774 139.73898317854903 30.127 35.670394882017206 139.73906595877125 40.702 35.67040011061239 139.73897469945308 30.127 35.67037571708774 139.73898317854903 30.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f64f35c6-179b-45e7-93df-fb3692dc321d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f64f35c6-179b-45e7-93df-fb3692dc321d_0">
											<gml:posList>35.670394882017206 139.73906595877125 40.702 35.67041962836279 139.73905911413078 18.996 35.67041962836279 139.73905911413078 40.702 35.670394882017206 139.73906595877125 40.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9036ad1c-67df-4337-a3d0-aecc206e7317">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9036ad1c-67df-4337-a3d0-aecc206e7317_0">
											<gml:posList>35.670394882017206 139.73906595877125 40.702 35.670394882017206 139.73906595877125 18.996 35.67041962836279 139.73905911413078 18.996 35.670394882017206 139.73906595877125 40.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7372dbf3-ea36-47fa-bd2c-86d879fb62a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7372dbf3-ea36-47fa-bd2c-86d879fb62a4_0">
											<gml:posList>35.67041962836279 139.73905911413078 18.996 35.67040011061239 139.73897469945308 18.996 35.67040011061239 139.73897469945308 30.127 35.67041962836279 139.73905911413078 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1dfa353d-ae12-4f69-b6de-a0dd93602529">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1dfa353d-ae12-4f69-b6de-a0dd93602529_0">
											<gml:posList>35.67041962836279 139.73905911413078 40.702 35.67041962836279 139.73905911413078 18.996 35.67040011061239 139.73897469945308 30.127 35.67041962836279 139.73905911413078 40.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28a0c00a-be29-4709-bf53-c5f6bea3e29f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67040011061239 139.73897469945308 18.996 35.67041962836279 139.73905911413078 18.996 35.670394882017206 139.73906595877125 18.996 35.67037571708774 139.73898317854903 18.996 35.67040011061239 139.73897469945308 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7a51b0d2-3279-45f1-8012-34d70a049120">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a51b0d2-3279-45f1-8012-34d70a049120">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a51b0d2-3279-45f1-8012-34d70a049120">
											<gml:posList>35.67021826284399 139.7390376560898 18.996 35.67037571708774 139.73898317854903 18.996 35.670394882017206 139.73906595877125 18.996 35.67041962836279 139.73905911413078 18.996 35.67043384605534 139.73912058093376 18.996 35.67033129763287 139.73915615990418 18.996 35.67032813228914 139.7391426871946 18.996 35.67024802154911 139.7391699550595 18.996 35.67021826284399 139.7390376560898 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2a10c1e0-d356-4667-9cad-e1bf7d9e4239">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a10c1e0-d356-4667-9cad-e1bf7d9e4239">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a10c1e0-d356-4667-9cad-e1bf7d9e4239">
											<gml:posList>35.67024483717494 139.73902851168774 30.168 35.67024846265518 139.7390310149202 30.168 35.670274649499255 139.73902200352316 30.168 35.67027667410009 139.73901754950492 30.168 35.67024483717494 139.73902851168774 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a1f850d0-d19d-4cab-874f-1d05d22295f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1f850d0-d19d-4cab-874f-1d05d22295f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1f850d0-d19d-4cab-874f-1d05d22295f0">
											<gml:posList>35.67024483717494 139.73902851168774 28.116 35.67021826284399 139.7390376560898 28.116 35.67022086922845 139.7390394646074 28.116 35.67024540699461 139.7390310074679 28.116 35.67024483717494 139.73902851168774 28.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a6daf58-2ad8-407f-a651-6d92508e8cad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a6daf58-2ad8-407f-a651-6d92508e8cad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a6daf58-2ad8-407f-a651-6d92508e8cad">
											<gml:posList>35.670297472182014 139.73901038916333 30.127 35.670315045282955 139.73908627832216 40.702 35.6703932902057 139.73905906777586 40.702 35.67037571708774 139.73898317854903 30.127 35.670297472182014 139.73901038916333 30.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ef0e6ec-29bb-4744-b06c-d161e7647a24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ef0e6ec-29bb-4744-b06c-d161e7647a24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ef0e6ec-29bb-4744-b06c-d161e7647a24">
											<gml:posList>35.67028809669878 139.73906640466316 25.862 35.67030878658435 139.73905920027542 25.862 35.670297472182014 139.73901038916333 25.862 35.67027667410009 139.73901754950492 25.862 35.67028809669878 139.73906640466316 25.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-10f84339-790c-4ae9-a46f-0f6479cab50a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10f84339-790c-4ae9-a46f-0f6479cab50a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10f84339-790c-4ae9-a46f-0f6479cab50a">
											<gml:posList>35.67028809669878 139.73906640466316 30.168 35.67027667410009 139.73901754950492 30.168 35.670274649499255 139.73902200352316 30.168 35.6702860721048 139.73907086972704 30.168 35.67028809669878 139.73906640466316 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2394f26a-e00f-40c8-9e83-336322f474ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2394f26a-e00f-40c8-9e83-336322f474ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2394f26a-e00f-40c8-9e83-336322f474ad">
											<gml:posList>35.67028809669878 139.73906640466316 30.168 35.6702860721048 139.73907086972704 30.168 35.670306752976906 139.73906366535124 30.168 35.67030878658435 139.73905920027542 30.168 35.67028809669878 139.73906640466316 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f2e6fc58-60bb-42d9-808b-9c49b36a9473">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2e6fc58-60bb-42d9-808b-9c49b36a9473">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2e6fc58-60bb-42d9-808b-9c49b36a9473">
											<gml:posList>35.67030878658435 139.73905920027542 30.168 35.670306752976906 139.73906366535124 30.168 35.670316213303714 139.73910450326247 30.168 35.67031985679249 139.73910698438695 30.168 35.67030878658435 139.73905920027542 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b23dec9-3e3c-45b7-87fb-1ccc28085516">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b23dec9-3e3c-45b7-87fb-1ccc28085516">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b23dec9-3e3c-45b7-87fb-1ccc28085516">
											<gml:posList>35.67029482954033 139.73911194042583 29.667 35.670316213303714 139.73910450326247 29.667 35.670306752976906 139.73906366535124 29.667 35.6702860721048 139.73907086972704 29.667 35.670274649499255 139.73902200352316 29.667 35.67024846265518 139.7390310149202 29.667 35.67027717928634 139.73915627870304 29.667 35.67030285257355 139.7391475441032 29.667 35.67029482954033 139.73911194042583 29.667</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6a06e1b-ad55-40b7-8da6-d90f54fd0d6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6a06e1b-ad55-40b7-8da6-d90f54fd0d6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6a06e1b-ad55-40b7-8da6-d90f54fd0d6c">
											<gml:posList>35.6704094885581 139.73912903785404 49.953 35.67043384605534 139.73912058093376 49.953 35.67041962836279 139.73905911413078 40.702 35.6704094885581 139.73912903785404 49.953</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67be9bc9-2eab-4986-adc7-07e8a3b24217">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67be9bc9-2eab-4986-adc7-07e8a3b24217">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67be9bc9-2eab-4986-adc7-07e8a3b24217">
											<gml:posList>35.67041962836279 139.73905911413078 40.702 35.670394882017206 139.73906595877125 40.702 35.6704094885581 139.73912903785404 49.953 35.67041962836279 139.73905911413078 40.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-62332302-d63e-4b4d-be29-bd8aaa27975b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62332302-d63e-4b4d-be29-bd8aaa27975b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62332302-d63e-4b4d-be29-bd8aaa27975b">
											<gml:posList>35.67027514565801 139.73916072168214 30.168 35.67027717928634 139.73915627870304 30.168 35.67024846265518 139.7390310149202 30.168 35.67024483717494 139.73902851168774 30.168 35.67027514565801 139.73916072168214 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-91ef02bf-a4cc-4eb0-a62f-5bf9bdeb30d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91ef02bf-a4cc-4eb0-a62f-5bf9bdeb30d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91ef02bf-a4cc-4eb0-a62f-5bf9bdeb30d8">
											<gml:posList>35.670274575832416 139.7391582148539 27.625 35.67024540699461 139.7390310074679 27.625 35.67022086922845 139.7390394646074 27.625 35.670249497303146 139.7391667609626 27.625 35.670274575832416 139.7391582148539 27.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e8e11295-3263-4a3e-8918-6203504cdc72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8e11295-3263-4a3e-8918-6203504cdc72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8e11295-3263-4a3e-8918-6203504cdc72">
											<gml:posList>35.67024802154911 139.7391699550595 28.116 35.670249497303146 139.7391667609626 28.116 35.67022086922845 139.7390394646074 28.116 35.67021826284399 139.7390376560898 28.116 35.67024802154911 139.7391699550595 28.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c87344be-09ff-4023-b71a-a77eddf5bb2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c87344be-09ff-4023-b71a-a77eddf5bb2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c87344be-09ff-4023-b71a-a77eddf5bb2e">
											<gml:posList>35.670315045282955 139.73908627832216 40.702 35.67033129763287 139.73915615990418 49.953 35.6704094885581 139.73912903785404 49.953 35.6703932902057 139.73905906777586 40.702 35.670315045282955 139.73908627832216 40.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8646553d-8589-4388-ae56-718c30390cb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8646553d-8589-4388-ae56-718c30390cb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8646553d-8589-4388-ae56-718c30390cb6">
											<gml:posList>35.67029845501017 139.7391144326174 30.168 35.67031985679249 139.73910698438695 30.168 35.670316213303714 139.73910450326247 30.168 35.67029482954033 139.73911194042583 30.168 35.67029845501017 139.7391144326174 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-741481af-db4c-4cf9-bd0a-d8bd9dac04e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-741481af-db4c-4cf9-bd0a-d8bd9dac04e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-741481af-db4c-4cf9-bd0a-d8bd9dac04e1">
											<gml:posList>35.67032813228914 139.7391426871946 28.527 35.67031985679249 139.73910698438695 28.527 35.67029845501017 139.7391144326174 28.527 35.67030648707363 139.7391500583785 28.527 35.67032813228914 139.7391426871946 28.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-082f9881-64b0-47da-b2e9-eaf4bfca6e2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-082f9881-64b0-47da-b2e9-eaf4bfca6e2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-082f9881-64b0-47da-b2e9-eaf4bfca6e2b">
											<gml:posList>35.67029845501017 139.7391144326174 30.168 35.67029482954033 139.73911194042583 30.168 35.67030285257355 139.7391475441032 30.168 35.67030648707363 139.7391500583785 30.168 35.67029845501017 139.7391144326174 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3a553f3-914c-4ee8-9752-2736368da39f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3a553f3-914c-4ee8-9752-2736368da39f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3a553f3-914c-4ee8-9752-2736368da39f">
											<gml:posList>35.67030648707363 139.7391500583785 30.168 35.67030285257355 139.7391475441032 30.168 35.67027717928634 139.73915627870304 30.168 35.67027514565801 139.73916072168214 30.168 35.67030648707363 139.7391500583785 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b672fd4d-f854-41c3-af72-effc9fbfe743">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b672fd4d-f854-41c3-af72-effc9fbfe743">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b672fd4d-f854-41c3-af72-effc9fbfe743">
											<gml:posList>35.67027514565801 139.73916072168214 28.116 35.670274575832416 139.7391582148539 28.116 35.670249497303146 139.7391667609626 28.116 35.67024802154911 139.7391699550595 28.116 35.67027514565801 139.73916072168214 28.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd5f3c9a-4057-4b55-9fac-d4d881a05bb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd5f3c9a-4057-4b55-9fac-d4d881a05bb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd5f3c9a-4057-4b55-9fac-d4d881a05bb1">
											<gml:posList>35.670274649499255 139.73902200352316 30.168 35.670274649499255 139.73902200352316 29.667 35.6702860721048 139.73907086972704 29.667 35.6702860721048 139.73907086972704 30.168 35.670274649499255 139.73902200352316 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc4c60fa-78c2-434c-aef2-4f8520540cc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc4c60fa-78c2-434c-aef2-4f8520540cc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc4c60fa-78c2-434c-aef2-4f8520540cc3">
											<gml:posList>35.67021826284399 139.7390376560898 18.996 35.67024802154911 139.7391699550595 18.996 35.67024802154911 139.7391699550595 28.116 35.67021826284399 139.7390376560898 28.116 35.67021826284399 139.7390376560898 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76c6cc06-9a8e-4b43-9a05-8fbffd5193cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76c6cc06-9a8e-4b43-9a05-8fbffd5193cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76c6cc06-9a8e-4b43-9a05-8fbffd5193cc">
											<gml:posList>35.67022086922845 139.7390394646074 28.116 35.67022086922845 139.7390394646074 27.625 35.67024540699461 139.7390310074679 27.625 35.67024540699461 139.7390310074679 28.116 35.67022086922845 139.7390394646074 28.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d56f6df5-058f-4848-92ed-13323001da67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d56f6df5-058f-4848-92ed-13323001da67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d56f6df5-058f-4848-92ed-13323001da67">
											<gml:posList>35.670249497303146 139.7391667609626 28.116 35.670249497303146 139.7391667609626 27.625 35.67022086922845 139.7390394646074 27.625 35.67022086922845 139.7390394646074 28.116 35.670249497303146 139.7391667609626 28.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d826a14b-84a1-427c-899e-1535ce84a90a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d826a14b-84a1-427c-899e-1535ce84a90a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d826a14b-84a1-427c-899e-1535ce84a90a">
											<gml:posList>35.67024540699461 139.7390310074679 28.116 35.67024540699461 139.7390310074679 27.625 35.670274575832416 139.7391582148539 27.625 35.670274575832416 139.7391582148539 28.116 35.67027514565801 139.73916072168214 28.116 35.67027514565801 139.73916072168214 30.168 35.67024483717494 139.73902851168774 30.168 35.67024483717494 139.73902851168774 28.116 35.67024540699461 139.7390310074679 28.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40826d08-a4c5-49fe-9630-889ecc42ac17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40826d08-a4c5-49fe-9630-889ecc42ac17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40826d08-a4c5-49fe-9630-889ecc42ac17">
											<gml:posList>35.67024846265518 139.7390310149202 30.168 35.67024846265518 139.7390310149202 29.667 35.670274649499255 139.73902200352316 29.667 35.670274649499255 139.73902200352316 30.168 35.67024846265518 139.7390310149202 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-813a92e6-46fa-44c2-88cf-9830864d4fea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-813a92e6-46fa-44c2-88cf-9830864d4fea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-813a92e6-46fa-44c2-88cf-9830864d4fea">
											<gml:posList>35.670274575832416 139.7391582148539 28.116 35.670274575832416 139.7391582148539 27.625 35.670249497303146 139.7391667609626 27.625 35.670249497303146 139.7391667609626 28.116 35.670274575832416 139.7391582148539 28.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b145b97-adae-45ff-bde8-71f3053c1726">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b145b97-adae-45ff-bde8-71f3053c1726">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b145b97-adae-45ff-bde8-71f3053c1726">
											<gml:posList>35.67027717928634 139.73915627870304 30.168 35.67027717928634 139.73915627870304 29.667 35.67024846265518 139.7390310149202 29.667 35.67024846265518 139.7390310149202 30.168 35.67027717928634 139.73915627870304 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-faca2d11-32fe-4f48-89be-7d83bcb87735">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-faca2d11-32fe-4f48-89be-7d83bcb87735">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-faca2d11-32fe-4f48-89be-7d83bcb87735">
											<gml:posList>35.67027667410009 139.73901754950492 30.168 35.67028809669878 139.73906640466316 30.168 35.67028809669878 139.73906640466316 25.862 35.67027667410009 139.73901754950492 25.862 35.67027667410009 139.73901754950492 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fc38ac4-9fcb-475e-93d6-9efc60d44e10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fc38ac4-9fcb-475e-93d6-9efc60d44e10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fc38ac4-9fcb-475e-93d6-9efc60d44e10">
											<gml:posList>35.67024802154911 139.7391699550595 18.996 35.67032813228914 139.7391426871946 18.996 35.67032813228914 139.7391426871946 28.527 35.67030648707363 139.7391500583785 28.527 35.67030648707363 139.7391500583785 30.168 35.67027514565801 139.73916072168214 30.168 35.67027514565801 139.73916072168214 28.116 35.67024802154911 139.7391699550595 28.116 35.67024802154911 139.7391699550595 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-293eb4b4-3257-450c-a1f0-7843f4427c23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-293eb4b4-3257-450c-a1f0-7843f4427c23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-293eb4b4-3257-450c-a1f0-7843f4427c23">
											<gml:posList>35.67030285257355 139.7391475441032 30.168 35.67030285257355 139.7391475441032 29.667 35.67027717928634 139.73915627870304 29.667 35.67027717928634 139.73915627870304 30.168 35.67030285257355 139.7391475441032 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd307bf4-f368-46a9-b2e5-f7b3aec4faa0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd307bf4-f368-46a9-b2e5-f7b3aec4faa0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd307bf4-f368-46a9-b2e5-f7b3aec4faa0">
											<gml:posList>35.6702860721048 139.73907086972704 30.168 35.6702860721048 139.73907086972704 29.667 35.670306752976906 139.73906366535124 29.667 35.670306752976906 139.73906366535124 30.168 35.6702860721048 139.73907086972704 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2904c4c-a9ea-475a-86c3-c8faae342433">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2904c4c-a9ea-475a-86c3-c8faae342433">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2904c4c-a9ea-475a-86c3-c8faae342433">
											<gml:posList>35.67024483717494 139.73902851168774 30.168 35.67027667410009 139.73901754950492 30.168 35.67027667410009 139.73901754950492 25.862 35.670297472182014 139.73901038916333 25.862 35.670297472182014 139.73901038916333 30.127 35.67037571708774 139.73898317854903 30.127 35.67037571708774 139.73898317854903 18.996 35.67021826284399 139.7390376560898 18.996 35.67021826284399 139.7390376560898 28.116 35.67024483717494 139.73902851168774 28.116 35.67024483717494 139.73902851168774 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fea637f2-a625-4846-84f4-bb3fc638521f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fea637f2-a625-4846-84f4-bb3fc638521f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fea637f2-a625-4846-84f4-bb3fc638521f">
											<gml:posList>35.67028809669878 139.73906640466316 30.168 35.67030878658435 139.73905920027542 30.168 35.67030878658435 139.73905920027542 30.127 35.67030878658435 139.73905920027542 25.862 35.67028809669878 139.73906640466316 25.862 35.67028809669878 139.73906640466316 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84509ca1-6d01-4a79-830f-b8ca637a27f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84509ca1-6d01-4a79-830f-b8ca637a27f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84509ca1-6d01-4a79-830f-b8ca637a27f9">
											<gml:posList>35.67029482954033 139.73911194042583 30.168 35.67029482954033 139.73911194042583 29.667 35.67030285257355 139.7391475441032 29.667 35.67030285257355 139.7391475441032 30.168 35.67029482954033 139.73911194042583 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6de8d770-c0e8-4fc6-b7eb-95355c460276">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6de8d770-c0e8-4fc6-b7eb-95355c460276">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6de8d770-c0e8-4fc6-b7eb-95355c460276">
											<gml:posList>35.67029845501017 139.7391144326174 28.527 35.67029845501017 139.7391144326174 30.168 35.67030648707363 139.7391500583785 30.168 35.67030648707363 139.7391500583785 28.527 35.67029845501017 139.7391144326174 28.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6be17cb3-a6eb-4051-8178-6e005b1ad791">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6be17cb3-a6eb-4051-8178-6e005b1ad791">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6be17cb3-a6eb-4051-8178-6e005b1ad791">
											<gml:posList>35.670297472182014 139.73901038916333 30.127 35.670297472182014 139.73901038916333 25.862 35.67030878658435 139.73905920027542 25.862 35.67030878658435 139.73905920027542 30.127 35.670297472182014 139.73901038916333 30.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe933b61-dab3-442d-859e-f5d14b5e6c94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe933b61-dab3-442d-859e-f5d14b5e6c94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe933b61-dab3-442d-859e-f5d14b5e6c94">
											<gml:posList>35.670316213303714 139.73910450326247 30.168 35.670316213303714 139.73910450326247 29.667 35.67029482954033 139.73911194042583 29.667 35.67029482954033 139.73911194042583 30.168 35.670316213303714 139.73910450326247 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0491dc6c-cfca-43f7-9234-b848e5173287">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0491dc6c-cfca-43f7-9234-b848e5173287">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0491dc6c-cfca-43f7-9234-b848e5173287">
											<gml:posList>35.67029845501017 139.7391144326174 30.168 35.67029845501017 139.7391144326174 28.527 35.67031985679249 139.73910698438695 28.527 35.67031985679249 139.73910698438695 30.127 35.67031985679249 139.73910698438695 30.168 35.67029845501017 139.7391144326174 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f6ae5cb-2fa1-48c4-a8aa-16169371c416">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f6ae5cb-2fa1-48c4-a8aa-16169371c416">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f6ae5cb-2fa1-48c4-a8aa-16169371c416">
											<gml:posList>35.670306752976906 139.73906366535124 30.168 35.670306752976906 139.73906366535124 29.667 35.670316213303714 139.73910450326247 29.667 35.670316213303714 139.73910450326247 30.168 35.670306752976906 139.73906366535124 30.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6faa981-84b1-4884-a6a6-28bcd8e4213f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6faa981-84b1-4884-a6a6-28bcd8e4213f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6faa981-84b1-4884-a6a6-28bcd8e4213f">
											<gml:posList>35.670297472182014 139.73901038916333 30.127 35.67030878658435 139.73905920027542 30.127 35.67030878658435 139.73905920027542 30.168 35.67031985679249 139.73910698438695 30.168 35.67033129763287 139.73915615990418 30.127 35.67033129763287 139.73915615990418 40.702 35.670315045282955 139.73908627832216 40.702 35.670297472182014 139.73901038916333 30.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffa92895-1015-466b-832d-28b97e43baea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffa92895-1015-466b-832d-28b97e43baea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffa92895-1015-466b-832d-28b97e43baea">
											<gml:posList>35.670315045282955 139.73908627832216 40.702 35.67033129763287 139.73915615990418 40.702 35.67033129763287 139.73915615990418 49.953 35.670315045282955 139.73908627832216 40.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5839f95-b885-4408-898f-84740a868560">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5839f95-b885-4408-898f-84740a868560">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5839f95-b885-4408-898f-84740a868560">
											<gml:posList>35.67033129763287 139.73915615990418 30.127 35.67031985679249 139.73910698438695 30.168 35.67031985679249 139.73910698438695 30.127 35.67031985679249 139.73910698438695 28.527 35.67032813228914 139.7391426871946 28.527 35.67032813228914 139.7391426871946 18.996 35.67033129763287 139.73915615990418 18.996 35.67033129763287 139.73915615990418 30.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-334d3049-370b-4e36-999d-5afbc82b627b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-334d3049-370b-4e36-999d-5afbc82b627b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-334d3049-370b-4e36-999d-5afbc82b627b">
											<gml:posList>35.67033129763287 139.73915615990418 18.996 35.67043384605534 139.73912058093376 18.996 35.67043384605534 139.73912058093376 30.127 35.67033129763287 139.73915615990418 30.127 35.67033129763287 139.73915615990418 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-264a3635-8308-467d-830d-a64b301c915b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-264a3635-8308-467d-830d-a64b301c915b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-264a3635-8308-467d-830d-a64b301c915b">
											<gml:posList>35.67043384605534 139.73912058093376 30.127 35.67043384605534 139.73912058093376 40.702 35.67033129763287 139.73915615990418 40.702 35.67033129763287 139.73915615990418 30.127 35.67043384605534 139.73912058093376 30.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0cf90aff-6d60-4a4b-9249-6d208fea5829">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cf90aff-6d60-4a4b-9249-6d208fea5829">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cf90aff-6d60-4a4b-9249-6d208fea5829">
											<gml:posList>35.67033129763287 139.73915615990418 40.702 35.67043384605534 139.73912058093376 40.702 35.67043384605534 139.73912058093376 49.953 35.6704094885581 139.73912903785404 49.953 35.67033129763287 139.73915615990418 49.953 35.67033129763287 139.73915615990418 40.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51476fb4-abcf-41ae-b4e7-bcf39e45b29d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51476fb4-abcf-41ae-b4e7-bcf39e45b29d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51476fb4-abcf-41ae-b4e7-bcf39e45b29d">
											<gml:posList>35.6703932902057 139.73905906777586 40.702 35.670394882017206 139.73906595877125 40.702 35.670394882017206 139.73906595877125 30.127 35.67037571708774 139.73898317854903 30.127 35.6703932902057 139.73905906777586 40.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ddd2f70-6980-4db2-bf6c-cc10780af9aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ddd2f70-6980-4db2-bf6c-cc10780af9aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ddd2f70-6980-4db2-bf6c-cc10780af9aa">
											<gml:posList>35.670394882017206 139.73906595877125 18.996 35.67037571708774 139.73898317854903 18.996 35.67037571708774 139.73898317854903 30.127 35.670394882017206 139.73906595877125 30.127 35.670394882017206 139.73906595877125 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c874b46-05f3-4609-a01e-199a72b45071">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c874b46-05f3-4609-a01e-199a72b45071">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c874b46-05f3-4609-a01e-199a72b45071">
											<gml:posList>35.670394882017206 139.73906595877125 40.702 35.6703932902057 139.73905906777586 40.702 35.6704094885581 139.73912903785404 49.953 35.670394882017206 139.73906595877125 40.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffb5ab94-fe86-40c6-8ba4-0088eeea5fe7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffb5ab94-fe86-40c6-8ba4-0088eeea5fe7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffb5ab94-fe86-40c6-8ba4-0088eeea5fe7">
											<gml:posList>35.67041962836279 139.73905911413078 18.996 35.670394882017206 139.73906595877125 18.996 35.670394882017206 139.73906595877125 30.127 35.67041962836279 139.73905911413078 30.127 35.67041962836279 139.73905911413078 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb939c43-8abb-4517-bf31-f7fda5aa3930">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb939c43-8abb-4517-bf31-f7fda5aa3930">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb939c43-8abb-4517-bf31-f7fda5aa3930">
											<gml:posList>35.670394882017206 139.73906595877125 30.127 35.670394882017206 139.73906595877125 40.702 35.67041962836279 139.73905911413078 40.702 35.67041962836279 139.73905911413078 30.127 35.670394882017206 139.73906595877125 30.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6a3c9b4-b1d3-4ef6-954b-c49f76694f2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6a3c9b4-b1d3-4ef6-954b-c49f76694f2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6a3c9b4-b1d3-4ef6-954b-c49f76694f2d">
											<gml:posList>35.67041962836279 139.73905911413078 30.127 35.67041962836279 139.73905911413078 40.702 35.67043384605534 139.73912058093376 40.702 35.67043384605534 139.73912058093376 30.127 35.67041962836279 139.73905911413078 30.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d3b8c5f-e404-4117-a7de-796e83335337">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d3b8c5f-e404-4117-a7de-796e83335337">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d3b8c5f-e404-4117-a7de-796e83335337">
											<gml:posList>35.67043384605534 139.73912058093376 18.996 35.67041962836279 139.73905911413078 18.996 35.67041962836279 139.73905911413078 30.127 35.67043384605534 139.73912058093376 30.127 35.67043384605534 139.73912058093376 18.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ef464b4-c20d-4c18-98e6-7fed0fbec55d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ef464b4-c20d-4c18-98e6-7fed0fbec55d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ef464b4-c20d-4c18-98e6-7fed0fbec55d">
											<gml:posList>35.67043384605534 139.73912058093376 40.702 35.67041962836279 139.73905911413078 40.702 35.67043384605534 139.73912058093376 49.953 35.67043384605534 139.73912058093376 40.702</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2888</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">162.22138</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>