<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ab1dbacf-0cf6-4839-9bf1-ae7714742e0f">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67287707672699 139.7465139854329 0 35.67288855850676 139.74649911531424 0 35.67286438149822 139.7464710831311 0 35.67285289972985 139.74648596429583 0 35.67287707672699 139.7465139854329 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67287707672699 139.7465139854329 11.08 35.67285289972985 139.74648596429583 11.08 35.67286438149822 139.7464710831311 11.08 35.67288855850676 139.74649911531424 11.08 35.67287707672699 139.7465139854329 11.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67287707672699 139.7465139854329 11.08 35.67288855850676 139.74649911531424 11.08 35.67288855850676 139.74649911531424 14.08 35.67287707672699 139.7465139854329 14.08 35.67287707672699 139.7465139854329 11.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67288855850676 139.74649911531424 11.08 35.67286438149822 139.7464710831311 11.08 35.67286438149822 139.7464710831311 14.08 35.67288855850676 139.74649911531424 14.08 35.67288855850676 139.74649911531424 11.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67286438149822 139.7464710831311 11.08 35.67285289972985 139.74648596429583 11.08 35.67285289972985 139.74648596429583 14.08 35.67286438149822 139.7464710831311 14.08 35.67286438149822 139.7464710831311 11.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67285289972985 139.74648596429583 11.08 35.67287707672699 139.7465139854329 11.08 35.67287707672699 139.7465139854329 14.08 35.67285289972985 139.74648596429583 14.08 35.67285289972985 139.74648596429583 11.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67287707672699 139.7465139854329 14.08 35.67288855850676 139.74649911531424 14.08 35.67286438149822 139.7464710831311 14.08 35.67285289972985 139.74648596429583 14.08 35.67287707672699 139.7465139854329 14.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1e49dc60-8fa3-446a-9690-9f62bcaec0af"/>
							<gml:surfaceMember xlink:href="#poly-bfabc7c1-9fbd-4514-a864-599474ec2a90"/>
							<gml:surfaceMember xlink:href="#poly-75da5cd1-7937-48bf-a269-64f92bfc7427"/>
							<gml:surfaceMember xlink:href="#poly-61edbaff-1420-47a6-ae5e-0341e8d099cd"/>
							<gml:surfaceMember xlink:href="#poly-964d63bc-8a2e-433a-b6ad-b8c8a491082f"/>
							<gml:surfaceMember xlink:href="#poly-190a3d21-4033-42c7-82a7-ec4ddae850ba"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1e49dc60-8fa3-446a-9690-9f62bcaec0af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e49dc60-8fa3-446a-9690-9f62bcaec0af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e49dc60-8fa3-446a-9690-9f62bcaec0af">
											<gml:posList>35.672888558506756 139.74649911531424 11.08 35.67287707672698 139.7465139854329 11.08 35.67285289972985 139.74648596429583 11.08 35.672864381498236 139.74647108313107 11.08 35.672888558506756 139.74649911531424 11.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bfabc7c1-9fbd-4514-a864-599474ec2a90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfabc7c1-9fbd-4514-a864-599474ec2a90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfabc7c1-9fbd-4514-a864-599474ec2a90">
											<gml:posList>35.67287707672698 139.7465139854329 14.443 35.672888558506756 139.74649911531424 14.443 35.672864381498236 139.74647108313107 14.443 35.67285289972985 139.74648596429583 14.443 35.67287707672698 139.7465139854329 14.443</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75da5cd1-7937-48bf-a269-64f92bfc7427">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75da5cd1-7937-48bf-a269-64f92bfc7427">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75da5cd1-7937-48bf-a269-64f92bfc7427">
											<gml:posList>35.672864381498236 139.74647108313107 11.08 35.67285289972985 139.74648596429583 11.08 35.67285289972985 139.74648596429583 14.443 35.672864381498236 139.74647108313107 14.443 35.672864381498236 139.74647108313107 11.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61edbaff-1420-47a6-ae5e-0341e8d099cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61edbaff-1420-47a6-ae5e-0341e8d099cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61edbaff-1420-47a6-ae5e-0341e8d099cd">
											<gml:posList>35.672888558506756 139.74649911531424 11.08 35.672864381498236 139.74647108313107 11.08 35.672864381498236 139.74647108313107 14.443 35.672888558506756 139.74649911531424 14.443 35.672888558506756 139.74649911531424 11.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-964d63bc-8a2e-433a-b6ad-b8c8a491082f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-964d63bc-8a2e-433a-b6ad-b8c8a491082f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-964d63bc-8a2e-433a-b6ad-b8c8a491082f">
											<gml:posList>35.67285289972985 139.74648596429583 11.08 35.67287707672698 139.7465139854329 11.08 35.67287707672698 139.7465139854329 14.443 35.67285289972985 139.74648596429583 14.443 35.67285289972985 139.74648596429583 11.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-190a3d21-4033-42c7-82a7-ec4ddae850ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-190a3d21-4033-42c7-82a7-ec4ddae850ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-190a3d21-4033-42c7-82a7-ec4ddae850ba">
											<gml:posList>35.67287707672698 139.7465139854329 11.08 35.672888558506756 139.74649911531424 11.08 35.672888558506756 139.74649911531424 14.443 35.67287707672698 139.7465139854329 14.443 35.67287707672698 139.7465139854329 11.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4522</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.26</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>