<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_aba266eb-8721-4b1f-8b97-6567a3a1dd81">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67128260907424 139.73894047750613 0 35.67128517788877 139.73896335154296 0 35.67133942434962 139.73895419651183 0 35.671336846519594 139.7389313224704 0 35.67128260907424 139.73894047750613 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67128260907424 139.73894047750613 16.82 35.671336846519594 139.7389313224704 16.82 35.67133942434962 139.73895419651183 16.82 35.67128517788877 139.73896335154296 16.82 35.67128260907424 139.73894047750613 16.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67128260907424 139.73894047750613 16.82 35.67128517788877 139.73896335154296 16.82 35.67128517788877 139.73896335154296 20.22 35.67128260907424 139.73894047750613 20.22 35.67128260907424 139.73894047750613 16.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67128517788877 139.73896335154296 16.82 35.67133942434962 139.73895419651183 16.82 35.67133942434962 139.73895419651183 20.22 35.67128517788877 139.73896335154296 20.22 35.67128517788877 139.73896335154296 16.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67133942434962 139.73895419651183 16.82 35.671336846519594 139.7389313224704 16.82 35.671336846519594 139.7389313224704 20.22 35.67133942434962 139.73895419651183 20.22 35.67133942434962 139.73895419651183 16.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671336846519594 139.7389313224704 16.82 35.67128260907424 139.73894047750613 16.82 35.67128260907424 139.73894047750613 20.22 35.671336846519594 139.7389313224704 20.22 35.671336846519594 139.7389313224704 16.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67128260907424 139.73894047750613 20.22 35.67128517788877 139.73896335154296 20.22 35.67133942434962 139.73895419651183 20.22 35.671336846519594 139.7389313224704 20.22 35.67128260907424 139.73894047750613 20.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0a219022-2195-44ad-9aee-8ffc692bef0b"/>
							<gml:surfaceMember xlink:href="#poly-d5037b73-6bb3-4215-af52-bf8dc4068c49"/>
							<gml:surfaceMember xlink:href="#poly-eabf2d38-7378-4e5a-bfa1-d7b945861255"/>
							<gml:surfaceMember xlink:href="#poly-dc3bad7a-3da5-47e6-82da-ccce066d8259"/>
							<gml:surfaceMember xlink:href="#poly-7537f794-0c9d-437d-9e23-166fd0d6d14e"/>
							<gml:surfaceMember xlink:href="#poly-83445802-6b9b-41e3-b97b-c5483e6f0919"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0a219022-2195-44ad-9aee-8ffc692bef0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a219022-2195-44ad-9aee-8ffc692bef0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a219022-2195-44ad-9aee-8ffc692bef0b">
											<gml:posList>35.671282609074225 139.73894047750613 16.82 35.67133684651959 139.7389313224704 16.82 35.67133942434958 139.73895419651183 16.82 35.67128517788877 139.73896335154296 16.82 35.671282609074225 139.73894047750613 16.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5037b73-6bb3-4215-af52-bf8dc4068c49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5037b73-6bb3-4215-af52-bf8dc4068c49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5037b73-6bb3-4215-af52-bf8dc4068c49">
											<gml:posList>35.67133684651959 139.7389313224704 20.484 35.671282609074225 139.73894047750613 20.484 35.67128517788877 139.73896335154296 20.484 35.67133942434958 139.73895419651183 20.484 35.67133684651959 139.7389313224704 20.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eabf2d38-7378-4e5a-bfa1-d7b945861255">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eabf2d38-7378-4e5a-bfa1-d7b945861255">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eabf2d38-7378-4e5a-bfa1-d7b945861255">
											<gml:posList>35.67133684651959 139.7389313224704 16.82 35.671282609074225 139.73894047750613 16.82 35.671282609074225 139.73894047750613 20.484 35.67133684651959 139.7389313224704 20.484 35.67133684651959 139.7389313224704 16.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc3bad7a-3da5-47e6-82da-ccce066d8259">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc3bad7a-3da5-47e6-82da-ccce066d8259">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc3bad7a-3da5-47e6-82da-ccce066d8259">
											<gml:posList>35.67133942434958 139.73895419651183 16.82 35.67133684651959 139.7389313224704 16.82 35.67133684651959 139.7389313224704 20.484 35.67133942434958 139.73895419651183 20.484 35.67133942434958 139.73895419651183 16.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7537f794-0c9d-437d-9e23-166fd0d6d14e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7537f794-0c9d-437d-9e23-166fd0d6d14e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7537f794-0c9d-437d-9e23-166fd0d6d14e">
											<gml:posList>35.671282609074225 139.73894047750613 16.82 35.67128517788877 139.73896335154296 16.82 35.67128517788877 139.73896335154296 20.484 35.671282609074225 139.73894047750613 20.484 35.671282609074225 139.73894047750613 16.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83445802-6b9b-41e3-b97b-c5483e6f0919">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83445802-6b9b-41e3-b97b-c5483e6f0919">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83445802-6b9b-41e3-b97b-c5483e6f0919">
											<gml:posList>35.67128517788877 139.73896335154296 16.82 35.67133942434958 139.73895419651183 16.82 35.67133942434958 139.73895419651183 20.484 35.67128517788877 139.73896335154296 20.484 35.67128517788877 139.73896335154296 16.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10668</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>