<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_abdd829a-92b9-42d6-a06f-f2f16bdda3b3">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6709373292936 139.73836747975702 0 35.67094011583396 139.73838055531874 0 35.67096285172965 139.73837327094736 0 35.670960065188446 139.73836019538223 0 35.6709373292936 139.73836747975702 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6709373292936 139.73836747975702 17.79 35.670960065188446 139.73836019538223 17.79 35.67096285172965 139.73837327094736 17.79 35.67094011583396 139.73838055531874 17.79 35.6709373292936 139.73836747975702 17.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6709373292936 139.73836747975702 17.79 35.67094011583396 139.73838055531874 17.79 35.67094011583396 139.73838055531874 20.79 35.6709373292936 139.73836747975702 20.79 35.6709373292936 139.73836747975702 17.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67094011583396 139.73838055531874 17.79 35.67096285172965 139.73837327094736 17.79 35.67096285172965 139.73837327094736 20.79 35.67094011583396 139.73838055531874 20.79 35.67094011583396 139.73838055531874 17.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67096285172965 139.73837327094736 17.79 35.670960065188446 139.73836019538223 17.79 35.670960065188446 139.73836019538223 20.79 35.67096285172965 139.73837327094736 20.79 35.67096285172965 139.73837327094736 17.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670960065188446 139.73836019538223 17.79 35.6709373292936 139.73836747975702 17.79 35.6709373292936 139.73836747975702 20.79 35.670960065188446 139.73836019538223 20.79 35.670960065188446 139.73836019538223 17.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6709373292936 139.73836747975702 20.79 35.67094011583396 139.73838055531874 20.79 35.67096285172965 139.73837327094736 20.79 35.670960065188446 139.73836019538223 20.79 35.6709373292936 139.73836747975702 20.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f8d830dc-2209-4f88-a5a3-8f1e98ab4dd1"/>
							<gml:surfaceMember xlink:href="#poly-7762de54-9247-4c02-b63f-465aadc5245d"/>
							<gml:surfaceMember xlink:href="#poly-6e6a2911-59d2-44b5-8fbf-d02da7dc99d3"/>
							<gml:surfaceMember xlink:href="#poly-108938cf-4931-4e54-be45-6690719b1b66"/>
							<gml:surfaceMember xlink:href="#poly-510fa93a-f52d-46c9-8fde-a92d82765a1c"/>
							<gml:surfaceMember xlink:href="#poly-8d78edb4-8e37-4b54-b6a9-6b7fef15fc0d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f8d830dc-2209-4f88-a5a3-8f1e98ab4dd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8d830dc-2209-4f88-a5a3-8f1e98ab4dd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8d830dc-2209-4f88-a5a3-8f1e98ab4dd1">
											<gml:posList>35.67093732929356 139.73836747975702 17.79 35.67096006518844 139.73836019538223 17.79 35.670962851729605 139.73837327094736 17.79 35.670940115833936 139.7383805553187 17.79 35.67093732929356 139.73836747975702 17.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7762de54-9247-4c02-b63f-465aadc5245d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7762de54-9247-4c02-b63f-465aadc5245d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7762de54-9247-4c02-b63f-465aadc5245d">
											<gml:posList>35.67096006518844 139.73836019538223 20.846 35.67093732929356 139.73836747975702 20.846 35.670940115833936 139.7383805553187 20.846 35.670962851729605 139.73837327094736 20.846 35.67096006518844 139.73836019538223 20.846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e6a2911-59d2-44b5-8fbf-d02da7dc99d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e6a2911-59d2-44b5-8fbf-d02da7dc99d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e6a2911-59d2-44b5-8fbf-d02da7dc99d3">
											<gml:posList>35.67096006518844 139.73836019538223 17.79 35.67093732929356 139.73836747975702 17.79 35.67093732929356 139.73836747975702 20.846 35.67096006518844 139.73836019538223 20.846 35.67096006518844 139.73836019538223 17.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-108938cf-4931-4e54-be45-6690719b1b66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-108938cf-4931-4e54-be45-6690719b1b66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-108938cf-4931-4e54-be45-6690719b1b66">
											<gml:posList>35.670962851729605 139.73837327094736 17.79 35.67096006518844 139.73836019538223 17.79 35.67096006518844 139.73836019538223 20.846 35.670962851729605 139.73837327094736 20.846 35.670962851729605 139.73837327094736 17.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-510fa93a-f52d-46c9-8fde-a92d82765a1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-510fa93a-f52d-46c9-8fde-a92d82765a1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-510fa93a-f52d-46c9-8fde-a92d82765a1c">
											<gml:posList>35.67093732929356 139.73836747975702 17.79 35.670940115833936 139.7383805553187 17.79 35.670940115833936 139.7383805553187 20.846 35.67093732929356 139.73836747975702 20.846 35.67093732929356 139.73836747975702 17.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d78edb4-8e37-4b54-b6a9-6b7fef15fc0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d78edb4-8e37-4b54-b6a9-6b7fef15fc0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d78edb4-8e37-4b54-b6a9-6b7fef15fc0d">
											<gml:posList>35.670940115833936 139.7383805553187 17.79 35.670962851729605 139.73837327094736 17.79 35.670962851729605 139.73837327094736 20.846 35.670940115833936 139.7383805553187 20.846 35.670940115833936 139.7383805553187 17.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6275</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>