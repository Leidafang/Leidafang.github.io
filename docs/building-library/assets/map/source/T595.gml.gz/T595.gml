<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_abecf617-0cb1-49d7-81ec-854bfc44ea83">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="説明注記">
				<gen:value>集合住宅付属施設</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">6.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66839047517209 139.73761963435578 0 35.6683663793825 139.73767373319907 0 35.66842760614469 139.73771468496236 0 35.66845170195234 139.73766058608996 0 35.66839047517209 139.73761963435578 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66839047517209 139.73761963435578 25.18 35.66845170195234 139.73766058608996 25.18 35.66842760614469 139.73771468496236 25.18 35.6683663793825 139.73767373319907 25.18 35.66839047517209 139.73761963435578 25.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66839047517209 139.73761963435578 25.18 35.6683663793825 139.73767373319907 25.18 35.6683663793825 139.73767373319907 32.05 35.66839047517209 139.73761963435578 32.05 35.66839047517209 139.73761963435578 25.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6683663793825 139.73767373319907 25.18 35.66842760614469 139.73771468496236 25.18 35.66842760614469 139.73771468496236 32.05 35.6683663793825 139.73767373319907 32.05 35.6683663793825 139.73767373319907 25.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66842760614469 139.73771468496236 25.18 35.66845170195234 139.73766058608996 25.18 35.66845170195234 139.73766058608996 32.05 35.66842760614469 139.73771468496236 32.05 35.66842760614469 139.73771468496236 25.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66845170195234 139.73766058608996 25.18 35.66839047517209 139.73761963435578 25.18 35.66839047517209 139.73761963435578 32.05 35.66845170195234 139.73766058608996 32.05 35.66845170195234 139.73766058608996 25.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66839047517209 139.73761963435578 32.05 35.6683663793825 139.73767373319907 32.05 35.66842760614469 139.73771468496236 32.05 35.66845170195234 139.73766058608996 32.05 35.66839047517209 139.73761963435578 32.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a60ea81e-60d4-4c66-8edd-0bce29268b3e"/>
							<gml:surfaceMember xlink:href="#poly-b8df034a-eed1-409c-bf6f-1db8917be2aa"/>
							<gml:surfaceMember xlink:href="#poly-e2f7bbf5-931b-44d3-b5af-2a1f9746e5f2"/>
							<gml:surfaceMember xlink:href="#poly-7f22ea63-9167-423b-a9bd-c664532e81c2"/>
							<gml:surfaceMember xlink:href="#poly-698e0977-074e-45c6-b933-cdd6d67ac67d"/>
							<gml:surfaceMember xlink:href="#poly-f1f583d4-06d3-4f2d-a49e-ddcbb58ea981"/>
							<gml:surfaceMember xlink:href="#poly-a2a04d1e-5fad-45ac-b531-d8af585ae83d"/>
							<gml:surfaceMember xlink:href="#poly-eae3efb5-84db-4a18-bbfd-41c8b8f0bc4d"/>
							<gml:surfaceMember xlink:href="#poly-2efb72c1-2930-4e70-8327-b1b0e7722229"/>
							<gml:surfaceMember xlink:href="#poly-2eedf96a-ba4d-4cc6-b7cd-781786331509"/>
							<gml:surfaceMember xlink:href="#poly-bfe4dcf9-9328-4e69-9bc7-d3477c222058"/>
							<gml:surfaceMember xlink:href="#poly-2b0b9a34-8ffb-4561-b668-555f64f8cd3f"/>
							<gml:surfaceMember xlink:href="#poly-3df5f229-dce9-4154-9465-d4d0b816e18c"/>
							<gml:surfaceMember xlink:href="#poly-6738b361-5916-4dec-a616-85903cd8d695"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a60ea81e-60d4-4c66-8edd-0bce29268b3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a60ea81e-60d4-4c66-8edd-0bce29268b3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a60ea81e-60d4-4c66-8edd-0bce29268b3e">
											<gml:posList>35.668390475172046 139.73761963435578 25.18 35.66845170195234 139.73766058609 25.18 35.668427606144675 139.73771468496236 25.18 35.66836637938248 139.73767373319907 25.18 35.668390475172046 139.73761963435578 25.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8df034a-eed1-409c-bf6f-1db8917be2aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8df034a-eed1-409c-bf6f-1db8917be2aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8df034a-eed1-409c-bf6f-1db8917be2aa">
											<gml:posList>35.668390475172046 139.73761963435578 32.174 35.66839081884377 139.73762108096957 32.174 35.668450521496666 139.73766101829221 32.174 35.66845170195234 139.73766058609 32.174 35.668390475172046 139.73761963435578 32.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2f7bbf5-931b-44d3-b5af-2a1f9746e5f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2f7bbf5-931b-44d3-b5af-2a1f9746e5f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2f7bbf5-931b-44d3-b5af-2a1f9746e5f2">
											<gml:posList>35.66836637938248 139.73767373319907 32.174 35.668367550833274 139.7376733120542 32.174 35.66839081884377 139.73762108096957 32.174 35.668390475172046 139.73761963435578 32.174 35.66836637938248 139.73767373319907 32.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f22ea63-9167-423b-a9bd-c664532e81c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f22ea63-9167-423b-a9bd-c664532e81c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f22ea63-9167-423b-a9bd-c664532e81c2">
											<gml:posList>35.668450521496666 139.73766101829221 32.033 35.66839081884377 139.73762108096957 32.033 35.668367550833274 139.7376733120542 32.033 35.668427253469126 139.73771324940418 32.033 35.668450521496666 139.73766101829221 32.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-698e0977-074e-45c6-b933-cdd6d67ac67d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-698e0977-074e-45c6-b933-cdd6d67ac67d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-698e0977-074e-45c6-b933-cdd6d67ac67d">
											<gml:posList>35.66845170195234 139.73766058609 32.174 35.668450521496666 139.73766101829221 32.174 35.668427253469126 139.73771324940418 32.174 35.668427606144675 139.73771468496236 32.174 35.66845170195234 139.73766058609 32.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f1f583d4-06d3-4f2d-a49e-ddcbb58ea981">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1f583d4-06d3-4f2d-a49e-ddcbb58ea981">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1f583d4-06d3-4f2d-a49e-ddcbb58ea981">
											<gml:posList>35.668427606144675 139.73771468496236 32.174 35.668427253469126 139.73771324940418 32.174 35.668367550833274 139.7376733120542 32.174 35.66836637938248 139.73767373319907 32.174 35.668427606144675 139.73771468496236 32.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2a04d1e-5fad-45ac-b531-d8af585ae83d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2a04d1e-5fad-45ac-b531-d8af585ae83d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2a04d1e-5fad-45ac-b531-d8af585ae83d">
											<gml:posList>35.66845170195234 139.73766058609 25.18 35.668390475172046 139.73761963435578 25.18 35.668390475172046 139.73761963435578 32.174 35.66845170195234 139.73766058609 32.174 35.66845170195234 139.73766058609 25.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eae3efb5-84db-4a18-bbfd-41c8b8f0bc4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eae3efb5-84db-4a18-bbfd-41c8b8f0bc4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eae3efb5-84db-4a18-bbfd-41c8b8f0bc4d">
											<gml:posList>35.66839081884377 139.73762108096957 32.174 35.66839081884377 139.73762108096957 32.033 35.668450521496666 139.73766101829221 32.033 35.668450521496666 139.73766101829221 32.174 35.66839081884377 139.73762108096957 32.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2efb72c1-2930-4e70-8327-b1b0e7722229">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2efb72c1-2930-4e70-8327-b1b0e7722229">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2efb72c1-2930-4e70-8327-b1b0e7722229">
											<gml:posList>35.668390475172046 139.73761963435578 25.18 35.66836637938248 139.73767373319907 25.18 35.66836637938248 139.73767373319907 32.174 35.668390475172046 139.73761963435578 32.174 35.668390475172046 139.73761963435578 25.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2eedf96a-ba4d-4cc6-b7cd-781786331509">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2eedf96a-ba4d-4cc6-b7cd-781786331509">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2eedf96a-ba4d-4cc6-b7cd-781786331509">
											<gml:posList>35.668367550833274 139.7376733120542 32.174 35.668367550833274 139.7376733120542 32.033 35.66839081884377 139.73762108096957 32.033 35.66839081884377 139.73762108096957 32.174 35.668367550833274 139.7376733120542 32.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bfe4dcf9-9328-4e69-9bc7-d3477c222058">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfe4dcf9-9328-4e69-9bc7-d3477c222058">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfe4dcf9-9328-4e69-9bc7-d3477c222058">
											<gml:posList>35.668450521496666 139.73766101829221 32.174 35.668450521496666 139.73766101829221 32.033 35.668427253469126 139.73771324940418 32.033 35.668427253469126 139.73771324940418 32.174 35.668450521496666 139.73766101829221 32.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b0b9a34-8ffb-4561-b668-555f64f8cd3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b0b9a34-8ffb-4561-b668-555f64f8cd3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b0b9a34-8ffb-4561-b668-555f64f8cd3f">
											<gml:posList>35.668427606144675 139.73771468496236 25.18 35.66845170195234 139.73766058609 25.18 35.66845170195234 139.73766058609 32.174 35.668427606144675 139.73771468496236 32.174 35.668427606144675 139.73771468496236 25.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3df5f229-dce9-4154-9465-d4d0b816e18c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3df5f229-dce9-4154-9465-d4d0b816e18c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3df5f229-dce9-4154-9465-d4d0b816e18c">
											<gml:posList>35.668427253469126 139.73771324940418 32.174 35.668427253469126 139.73771324940418 32.033 35.668367550833274 139.7376733120542 32.033 35.668367550833274 139.7376733120542 32.174 35.668427253469126 139.73771324940418 32.174</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6738b361-5916-4dec-a616-85903cd8d695">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6738b361-5916-4dec-a616-85903cd8d695">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6738b361-5916-4dec-a616-85903cd8d695">
											<gml:posList>35.66836637938248 139.73767373319907 25.18 35.668427606144675 139.73771468496236 25.18 35.668427606144675 139.73771468496236 32.174 35.66836637938248 139.73767373319907 32.174 35.66836637938248 139.73767373319907 25.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9198</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">101.15319</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">3</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>