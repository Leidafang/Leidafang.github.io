<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ac0d079d-948f-4312-9704-0429ece39023">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">13.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6703838656488 139.7437876845341 0 35.67029514513869 139.74375354025176 0 35.67027267727749 139.743842929476 0 35.670362208751655 139.74387674155528 0 35.6703838656488 139.7437876845341 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6703838656488 139.7437876845341 7.698 35.670362208751655 139.74387674155528 7.698 35.67027267727749 139.743842929476 7.698 35.67029514513869 139.74375354025176 7.698 35.6703838656488 139.7437876845341 7.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6703838656488 139.7437876845341 7.698 35.67029514513869 139.74375354025176 7.698 35.67029514513869 139.74375354025176 20.88 35.6703838656488 139.7437876845341 20.88 35.6703838656488 139.7437876845341 7.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67029514513869 139.74375354025176 7.698 35.67027267727749 139.743842929476 7.698 35.67027267727749 139.743842929476 20.88 35.67029514513869 139.74375354025176 20.88 35.67029514513869 139.74375354025176 7.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67027267727749 139.743842929476 7.698 35.670362208751655 139.74387674155528 7.698 35.670362208751655 139.74387674155528 20.88 35.67027267727749 139.743842929476 20.88 35.67027267727749 139.743842929476 7.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670362208751655 139.74387674155528 7.698 35.6703838656488 139.7437876845341 7.698 35.6703838656488 139.7437876845341 20.88 35.670362208751655 139.74387674155528 20.88 35.670362208751655 139.74387674155528 7.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6703838656488 139.7437876845341 20.88 35.67029514513869 139.74375354025176 20.88 35.67027267727749 139.743842929476 20.88 35.670362208751655 139.74387674155528 20.88 35.6703838656488 139.7437876845341 20.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-65a036dc-f171-4455-a94c-28212d2392da"/>
							<gml:surfaceMember xlink:href="#poly-ea44ff4a-3368-4f84-a728-aa303dbc04de"/>
							<gml:surfaceMember xlink:href="#poly-b5dd03d9-9ade-4a85-8e62-899abd5d2238"/>
							<gml:surfaceMember xlink:href="#poly-dc45ae9f-cc36-4a6c-8f17-8000a86fff0b"/>
							<gml:surfaceMember xlink:href="#poly-66a37cd0-81b3-43c9-9dff-49145d1702bb"/>
							<gml:surfaceMember xlink:href="#poly-bdf64325-27b8-489e-81e6-7d654b751ccb"/>
							<gml:surfaceMember xlink:href="#poly-9c49367f-7bc7-4325-b6d9-96e73d33f66a"/>
							<gml:surfaceMember xlink:href="#poly-6412a8fa-e90d-4fbd-8530-4dd36343beb6"/>
							<gml:surfaceMember xlink:href="#poly-1a80c73e-2511-4316-a713-9b84de4c36b2"/>
							<gml:surfaceMember xlink:href="#poly-04eead05-e14c-4daa-8678-f909c6044f8c"/>
							<gml:surfaceMember xlink:href="#poly-689ee507-6f25-4047-9aa2-d73d4c81a549"/>
							<gml:surfaceMember xlink:href="#poly-3442900e-3d5b-4882-b497-ff3d8042a238"/>
							<gml:surfaceMember xlink:href="#poly-c29af5ef-1b40-400b-b298-0f649e91bff9"/>
							<gml:surfaceMember xlink:href="#poly-5f7ae824-3755-4a49-8c9c-0572f2486806"/>
							<gml:surfaceMember xlink:href="#poly-1f805dcb-4066-4eaf-841c-6ab642414176"/>
							<gml:surfaceMember xlink:href="#poly-55327944-a9a0-4268-849a-08fe49eab531"/>
							<gml:surfaceMember xlink:href="#poly-6b36de2d-9192-4188-877c-0aaba8089348"/>
							<gml:surfaceMember xlink:href="#poly-fd6f8617-3513-4f06-a86e-dc0aa7b0e07f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ac0d079d-948f-4312-9704-0429ece39023_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-074f5579-8527-4dcc-b513-eb0f91d4ece3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670344264785335 139.7437950413827 20.357 35.67034411208594 139.74379575955976 20.357 35.67034390529598 139.743796466751 20.357 35.67034365341276 139.74379714085381 20.357 35.670343356444484 139.74379779291448 20.357 35.670343005369226 139.74379841189682 20.357 35.67034261820621 139.7437989867344 20.357 35.67034219495546 139.74379951742725 20.357 35.670341726603226 139.74380000398546 20.357 35.67034123116875 139.74380043534262 20.357 35.67034070865204 139.74380081149874 20.357 35.67034015905308 139.74380113245385 20.357 35.670339591377406 139.7438013871516 20.357 35.67033900564142 139.7438015976845 20.357 35.6703384018205 139.74380173091384 20.357 35.670337797950296 139.74380179786564 20.357 35.67033718502531 139.74380180959636 20.357 35.670336581056546 139.74380174399326 20.357 35.67033597704672 139.74380162315896 20.357 35.670335391015065 139.743801436027 20.357 35.670334813947846 139.7438011826076 20.357 35.670334263880726 139.74380087392674 20.357 35.67033373179999 139.74380050999454 20.357 35.67033322671115 139.7438000797547 20.357 35.670332757644346 139.7437996052896 20.357 35.67033232459958 139.74379908659927 20.357 35.67033193658236 139.74379851262742 20.357 35.67033157558166 139.74379790548662 20.357 35.67033126863867 139.74379726514672 20.357 35.670331006739644 139.74379659161775 20.357 35.67033079889833 139.74379588488966 20.357 35.67033063611739 139.743795167065 20.357 35.6703305274106 139.74379443813373 20.357 35.67033046376419 139.74379369810583 20.357 35.67033046320564 139.74379294696126 20.357 35.67033050772391 139.7437922068126 20.357 35.67033060632452 139.74379146660354 20.357 35.67033075902389 139.74379074842656 20.357 35.67033096581382 139.74379004123543 20.357 35.670331217697004 139.74378936713268 20.357 35.67033152367895 139.74378871506204 20.357 35.67033186574044 139.74378809608982 20.357 35.67033225290339 139.74378752125227 20.357 35.67033268516783 139.74378699054935 20.357 35.67033314450629 139.7437865040012 20.357 35.67033363994072 139.74378607264399 20.357 35.67033416245738 139.74378569648778 20.357 35.67033471205629 139.7437853755326 20.357 35.67033528873744 139.74378510977843 20.357 35.67033587448161 139.74378491029168 20.357 35.6703364692888 139.7437847770723 20.357 35.6703370821727 139.74378471011028 20.357 35.67033768608397 139.7437846983895 20.357 35.67033829005274 139.74378476399247 20.357 35.67033889406259 139.74378488482668 20.357 35.670339489108 139.74378507194842 20.357 35.670340057161525 139.74378532537781 20.357 35.670340616242406 139.7437856340485 20.357 35.67034113930946 139.7437859979907 20.357 35.67034164439835 139.74378642823052 20.357 35.670342113465196 139.74378690269558 20.357 35.67034254651002 139.74378742138592 20.357 35.67034294354103 139.7437879953477 20.357 35.67034329552804 139.7437886024986 20.357 35.67034360247108 139.74378924283857 20.357 35.670343864370146 139.74378991636763 20.357 35.67034408121702 139.7437906120395 20.357 35.67034424400617 139.74379134091052 20.357 35.67034435271301 139.74379206984193 20.357 35.670344407345695 139.74379280988 20.357 35.67034441691796 139.74379356101466 20.357 35.67034436338596 139.7437943011735 20.357 35.670344264785335 139.7437950413827 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca4d2fa2-3f24-404c-b58d-7e56fd6dc1c1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670368357394565 139.74382994274552 16.8 35.67035698821535 139.7438260892473 16.8 35.67036705943496 139.7437814732145 16.8 35.67037895195372 139.74378605517552 16.8 35.670368357394565 139.74382994274552 16.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1da650dd-18dc-4b67-887f-e50bbfa121e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1da650dd-18dc-4b67-887f-e50bbfa121e5_0">
											<gml:posList>35.67037895195372 139.74378605517552 16.8 35.67036705943496 139.7437814732145 16.8 35.67036705943496 139.7437814732145 18.274 35.67037895195372 139.74378605517552 18.274 35.67037895195372 139.74378605517552 16.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21170f99-6f5b-4bb0-9691-ea32559f4375">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21170f99-6f5b-4bb0-9691-ea32559f4375_0">
											<gml:posList>35.67033768608397 139.7437846983895 20.357 35.6703370821727 139.74378471011028 20.357 35.6703370821727 139.74378471011028 22.415 35.67033768608397 139.7437846983895 22.415 35.67033768608397 139.7437846983895 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bdfd41b-b10c-4e4c-9832-805eb3e3cf1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bdfd41b-b10c-4e4c-9832-805eb3e3cf1a_0">
											<gml:posList>35.67033829005274 139.74378476399247 20.357 35.67033768608397 139.7437846983895 20.357 35.67033768608397 139.7437846983895 22.415 35.67033829005274 139.74378476399247 22.415 35.67033829005274 139.74378476399247 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0a310c9-bd7e-4f1a-8f28-94efcbccf8d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0a310c9-bd7e-4f1a-8f28-94efcbccf8d0_0">
											<gml:posList>35.6703370821727 139.74378471011028 20.357 35.6703364692888 139.7437847770723 20.357 35.6703364692888 139.7437847770723 22.415 35.6703370821727 139.74378471011028 22.415 35.6703370821727 139.74378471011028 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e98f6269-8132-4939-9f4e-733fd39b9b88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e98f6269-8132-4939-9f4e-733fd39b9b88_0">
											<gml:posList>35.67033889406259 139.74378488482668 20.357 35.67033829005274 139.74378476399247 20.357 35.67033829005274 139.74378476399247 22.415 35.67033889406259 139.74378488482668 22.415 35.67033889406259 139.74378488482668 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18bbb149-580b-4050-b98f-13f147e86217">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18bbb149-580b-4050-b98f-13f147e86217_0">
											<gml:posList>35.6703364692888 139.7437847770723 20.357 35.67033587448161 139.74378491029168 20.357 35.67033587448161 139.74378491029168 22.415 35.6703364692888 139.7437847770723 22.415 35.6703364692888 139.7437847770723 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd6cabf0-ccf7-46ab-a70c-897abec75602">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd6cabf0-ccf7-46ab-a70c-897abec75602_0">
											<gml:posList>35.670339489108 139.74378507194842 20.357 35.67033889406259 139.74378488482668 20.357 35.67033889406259 139.74378488482668 22.415 35.670339489108 139.74378507194842 22.415 35.670339489108 139.74378507194842 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c27a6d6a-4fec-4afc-9089-62ebb4bf65c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c27a6d6a-4fec-4afc-9089-62ebb4bf65c3_0">
											<gml:posList>35.67033587448161 139.74378491029168 20.357 35.67033528873744 139.74378510977843 20.357 35.67033528873744 139.74378510977843 22.415 35.67033587448161 139.74378491029168 22.415 35.67033587448161 139.74378491029168 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba3b28a3-b5e0-43cd-9cf3-7882e7adcea8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba3b28a3-b5e0-43cd-9cf3-7882e7adcea8_0">
											<gml:posList>35.670340057161525 139.74378532537781 20.357 35.670339489108 139.74378507194842 20.357 35.670339489108 139.74378507194842 22.415 35.670340057161525 139.74378532537781 22.415 35.670340057161525 139.74378532537781 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90619406-d76e-4826-8a93-0e257d29f0d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90619406-d76e-4826-8a93-0e257d29f0d7_0">
											<gml:posList>35.67033528873744 139.74378510977843 20.357 35.67033471205629 139.7437853755326 20.357 35.67033471205629 139.7437853755326 22.415 35.67033528873744 139.74378510977843 22.415 35.67033528873744 139.74378510977843 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74cbf8af-07ce-4206-9db6-8ca9a71e3bcb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74cbf8af-07ce-4206-9db6-8ca9a71e3bcb_0">
											<gml:posList>35.670340616242406 139.7437856340485 20.357 35.670340057161525 139.74378532537781 20.357 35.670340057161525 139.74378532537781 22.415 35.670340616242406 139.7437856340485 22.415 35.670340616242406 139.7437856340485 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81a0c5ff-b0f2-4825-a2cf-e99059df711f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81a0c5ff-b0f2-4825-a2cf-e99059df711f_0">
											<gml:posList>35.67033471205629 139.7437853755326 20.357 35.67033416245738 139.74378569648778 20.357 35.67033416245738 139.74378569648778 22.415 35.67033471205629 139.7437853755326 22.415 35.67033471205629 139.7437853755326 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8f4eebe-1c38-48c1-8f60-de5c0fa07c75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8f4eebe-1c38-48c1-8f60-de5c0fa07c75_0">
											<gml:posList>35.67034113930946 139.7437859979907 20.357 35.670340616242406 139.7437856340485 20.357 35.670340616242406 139.7437856340485 22.415 35.67034113930946 139.7437859979907 22.415 35.67034113930946 139.7437859979907 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36991e7b-1d9f-4ce8-ac72-6abfcdaf82ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36991e7b-1d9f-4ce8-ac72-6abfcdaf82ba_0">
											<gml:posList>35.67033416245738 139.74378569648778 20.357 35.67033363994072 139.74378607264399 20.357 35.67033363994072 139.74378607264399 22.415 35.67033416245738 139.74378569648778 22.415 35.67033416245738 139.74378569648778 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1fa84ca-12d5-417a-857d-5b9d74665dd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1fa84ca-12d5-417a-857d-5b9d74665dd8_0">
											<gml:posList>35.67034164439835 139.74378642823052 20.357 35.67034113930946 139.7437859979907 20.357 35.67034113930946 139.7437859979907 22.415 35.67034164439835 139.74378642823052 22.415 35.67034164439835 139.74378642823052 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b895d4a-6ece-45af-a0ce-21573c102549">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b895d4a-6ece-45af-a0ce-21573c102549_0">
											<gml:posList>35.67033363994072 139.74378607264399 20.357 35.67033314450629 139.7437865040012 20.357 35.67033314450629 139.7437865040012 22.415 35.67033363994072 139.74378607264399 22.415 35.67033363994072 139.74378607264399 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7932cfc-9ccd-4764-9b63-f41de6e0b0c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7932cfc-9ccd-4764-9b63-f41de6e0b0c3_0">
											<gml:posList>35.670342113465196 139.74378690269558 20.357 35.67034164439835 139.74378642823052 20.357 35.67034164439835 139.74378642823052 22.415 35.670342113465196 139.74378690269558 22.415 35.670342113465196 139.74378690269558 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70cc2b24-3f6f-4229-a4ef-9319d934e4fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70cc2b24-3f6f-4229-a4ef-9319d934e4fc_0">
											<gml:posList>35.67033314450629 139.7437865040012 20.357 35.67033268516783 139.74378699054935 20.357 35.67033268516783 139.74378699054935 22.415 35.67033314450629 139.7437865040012 22.415 35.67033314450629 139.7437865040012 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01cffec9-c865-4a03-961d-7b6e151dfb26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01cffec9-c865-4a03-961d-7b6e151dfb26_0">
											<gml:posList>35.67034254651002 139.74378742138592 20.357 35.670342113465196 139.74378690269558 20.357 35.670342113465196 139.74378690269558 22.415 35.67034254651002 139.74378742138592 22.415 35.67034254651002 139.74378742138592 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19e2ac18-b030-4bef-a811-fc7ebed5b2bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19e2ac18-b030-4bef-a811-fc7ebed5b2bb_0">
											<gml:posList>35.67033268516783 139.74378699054935 20.357 35.67033225290339 139.74378752125227 20.357 35.67033225290339 139.74378752125227 22.415 35.67033268516783 139.74378699054935 22.415 35.67033268516783 139.74378699054935 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7be96c86-b347-4322-9ee8-7048e69ebe58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7be96c86-b347-4322-9ee8-7048e69ebe58_0">
											<gml:posList>35.67034294354103 139.7437879953477 20.357 35.67034254651002 139.74378742138592 20.357 35.67034254651002 139.74378742138592 22.415 35.67034294354103 139.7437879953477 22.415 35.67034294354103 139.7437879953477 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32f4d044-8a41-4a8b-9d72-e7ee552306b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32f4d044-8a41-4a8b-9d72-e7ee552306b8_0">
											<gml:posList>35.67033225290339 139.74378752125227 20.357 35.67033186574044 139.74378809608982 20.357 35.67033186574044 139.74378809608982 22.415 35.67033225290339 139.74378752125227 22.415 35.67033225290339 139.74378752125227 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06373a1f-baf0-47c5-be34-ba7ff3b44d95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06373a1f-baf0-47c5-be34-ba7ff3b44d95_0">
											<gml:posList>35.67034329552804 139.7437886024986 20.357 35.67034294354103 139.7437879953477 20.357 35.67034294354103 139.7437879953477 22.415 35.67034329552804 139.7437886024986 22.415 35.67034329552804 139.7437886024986 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4a5c24e-4048-4c97-ac37-c24b2e021763">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4a5c24e-4048-4c97-ac37-c24b2e021763_0">
											<gml:posList>35.67033186574044 139.74378809608982 20.357 35.67033152367895 139.74378871506204 20.357 35.67033152367895 139.74378871506204 22.415 35.67033186574044 139.74378809608982 22.415 35.67033186574044 139.74378809608982 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37b75336-7c98-413e-a550-7c9425c928be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37b75336-7c98-413e-a550-7c9425c928be_0">
											<gml:posList>35.67034360247108 139.74378924283857 20.357 35.67034329552804 139.7437886024986 20.357 35.67034329552804 139.7437886024986 22.415 35.67034360247108 139.74378924283857 22.415 35.67034360247108 139.74378924283857 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3425a157-fcb6-411e-ad5d-bec8d3657c9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3425a157-fcb6-411e-ad5d-bec8d3657c9d_0">
											<gml:posList>35.67033152367895 139.74378871506204 20.357 35.670331217697004 139.74378936713268 20.357 35.670331217697004 139.74378936713268 22.415 35.67033152367895 139.74378871506204 22.415 35.67033152367895 139.74378871506204 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2b6f4c2-d740-499a-836b-69ef6c2ab0d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2b6f4c2-d740-499a-836b-69ef6c2ab0d4_0">
											<gml:posList>35.670343864370146 139.74378991636763 20.357 35.67034360247108 139.74378924283857 20.357 35.67034360247108 139.74378924283857 22.415 35.670343864370146 139.74378991636763 22.415 35.670343864370146 139.74378991636763 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aeacea1c-304a-44ce-9c7f-106f83235e3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aeacea1c-304a-44ce-9c7f-106f83235e3d_0">
											<gml:posList>35.670331217697004 139.74378936713268 20.357 35.67033096581382 139.74379004123543 20.357 35.67033096581382 139.74379004123543 22.415 35.670331217697004 139.74378936713268 22.415 35.670331217697004 139.74378936713268 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0a0fde2-d903-4b8d-add4-c4e39c4c08d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0a0fde2-d903-4b8d-add4-c4e39c4c08d9_0">
											<gml:posList>35.670343864370146 139.74378991636763 20.357 35.670343864370146 139.74378991636763 22.415 35.67034408121702 139.7437906120395 22.415 35.67034408121702 139.7437906120395 20.357 35.670343864370146 139.74378991636763 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5799d183-eccb-4e48-b9c4-1d23e5b28c04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5799d183-eccb-4e48-b9c4-1d23e5b28c04_0">
											<gml:posList>35.67033075902389 139.74379074842656 20.357 35.67033075902389 139.74379074842656 22.415 35.67033096581382 139.74379004123543 22.415 35.67033096581382 139.74379004123543 20.357 35.67033075902389 139.74379074842656 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0bac6834-8c05-4a33-97ff-de2c6efffd8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0bac6834-8c05-4a33-97ff-de2c6efffd8e_0">
											<gml:posList>35.67034408121702 139.7437906120395 20.357 35.67034408121702 139.7437906120395 22.415 35.67034424400617 139.74379134091052 22.415 35.67034424400617 139.74379134091052 20.357 35.67034408121702 139.7437906120395 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d8a7c04-d5eb-4820-9051-a6c0b33963f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d8a7c04-d5eb-4820-9051-a6c0b33963f7_0">
											<gml:posList>35.67033075902389 139.74379074842656 20.357 35.67033060632452 139.74379146660354 20.357 35.67033060632452 139.74379146660354 22.415 35.67033075902389 139.74379074842656 22.415 35.67033075902389 139.74379074842656 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-451e5c73-dd0a-41e7-8f44-0608637123e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-451e5c73-dd0a-41e7-8f44-0608637123e0_0">
											<gml:posList>35.67034435271301 139.74379206984193 20.357 35.67034424400617 139.74379134091052 20.357 35.67034424400617 139.74379134091052 22.415 35.67034435271301 139.74379206984193 22.415 35.67034435271301 139.74379206984193 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97c43335-5aa0-4bb5-b605-f252d7f582bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97c43335-5aa0-4bb5-b605-f252d7f582bb_0">
											<gml:posList>35.67033050772391 139.7437922068126 20.357 35.67033050772391 139.7437922068126 22.415 35.67033060632452 139.74379146660354 22.415 35.67033060632452 139.74379146660354 20.357 35.67033050772391 139.7437922068126 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f856ca0-42a6-4c96-b900-51f381acd7c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f856ca0-42a6-4c96-b900-51f381acd7c6_0">
											<gml:posList>35.670344407345695 139.74379280988 20.357 35.67034435271301 139.74379206984193 20.357 35.67034435271301 139.74379206984193 22.415 35.670344407345695 139.74379280988 22.415 35.670344407345695 139.74379280988 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40c4d69d-4fde-42d5-bb87-81e09d9cbd76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40c4d69d-4fde-42d5-bb87-81e09d9cbd76_0">
											<gml:posList>35.67033050772391 139.7437922068126 20.357 35.67033046320564 139.74379294696126 20.357 35.67033046320564 139.74379294696126 22.415 35.67033050772391 139.7437922068126 22.415 35.67033050772391 139.7437922068126 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1871386-e4a8-48e5-93c9-b96ba4db55d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1871386-e4a8-48e5-93c9-b96ba4db55d1_0">
											<gml:posList>35.67034441691796 139.74379356101466 20.357 35.670344407345695 139.74379280988 20.357 35.670344407345695 139.74379280988 22.415 35.67034441691796 139.74379356101466 22.415 35.67034441691796 139.74379356101466 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cf6ddaa-682a-44c2-9b88-0bfa589a980e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4cf6ddaa-682a-44c2-9b88-0bfa589a980e_0">
											<gml:posList>35.67034441691796 139.74379356101466 22.415 35.670344407345695 139.74379280988 22.415 35.67034435271301 139.74379206984193 22.415 35.67034424400617 139.74379134091052 22.415 35.67034408121702 139.7437906120395 22.415 35.670343864370146 139.74378991636763 22.415 35.67034360247108 139.74378924283857 22.415 35.67034329552804 139.7437886024986 22.415 35.67034294354103 139.7437879953477 22.415 35.67034254651002 139.74378742138592 22.415 35.670342113465196 139.74378690269558 22.415 35.67034164439835 139.74378642823052 22.415 35.67034113930946 139.7437859979907 22.415 35.670340616242406 139.7437856340485 22.415 35.670340057161525 139.74378532537781 22.415 35.670339489108 139.74378507194842 22.415 35.67033889406259 139.74378488482668 22.415 35.67033829005274 139.74378476399247 22.415 35.67033768608397 139.7437846983895 22.415 35.6703370821727 139.74378471011028 22.415 35.6703364692888 139.7437847770723 22.415 35.67033587448161 139.74378491029168 22.415 35.67033528873744 139.74378510977843 22.415 35.67033471205629 139.7437853755326 22.415 35.67033416245738 139.74378569648778 22.415 35.67033363994072 139.74378607264399 22.415 35.67033314450629 139.7437865040012 22.415 35.67033268516783 139.74378699054935 22.415 35.67033225290339 139.74378752125227 22.415 35.67033186574044 139.74378809608982 22.415 35.67033152367895 139.74378871506204 22.415 35.670331217697004 139.74378936713268 22.415 35.67033096581382 139.74379004123543 22.415 35.67033075902389 139.74379074842656 22.415 35.67033060632452 139.74379146660354 22.415 35.67033050772391 139.7437922068126 22.415 35.67033046320564 139.74379294696126 22.415 35.67033046376419 139.74379369810583 22.415 35.6703305274106 139.74379443813373 22.415 35.67033063611739 139.743795167065 22.415 35.67033079889833 139.74379588488966 22.415 35.670331006739644 139.74379659161775 22.415 35.67033126863867 139.74379726514672 22.415 35.67033157558166 139.74379790548662 22.415 35.67033193658236 139.74379851262742 22.415 35.67033232459958 139.74379908659927 22.415 35.670332757644346 139.7437996052896 22.415 35.67033322671115 139.7438000797547 22.415 35.67033373179999 139.74380050999454 22.415 35.670334263880726 139.74380087392674 22.415 35.670334813947846 139.7438011826076 22.415 35.670335391015065 139.743801436027 22.415 35.67033597704672 139.74380162315896 22.415 35.670336581056546 139.74380174399326 22.415 35.67033718502531 139.74380180959636 22.415 35.670337797950296 139.74380179786564 22.415 35.6703384018205 139.74380173091384 22.415 35.67033900564142 139.7438015976845 22.415 35.670339591377406 139.7438013871516 22.415 35.67034015905308 139.74380113245385 22.415 35.67034070865204 139.74380081149874 22.415 35.67034123116875 139.74380043534262 22.415 35.670341726603226 139.74380000398546 22.415 35.67034219495546 139.74379951742725 22.415 35.67034261820621 139.7437989867344 22.415 35.670343005369226 139.74379841189682 22.415 35.670343356444484 139.74379779291448 22.415 35.67034365341276 139.74379714085381 22.415 35.67034390529598 139.743796466751 22.415 35.67034411208594 139.74379575955976 22.415 35.670344264785335 139.7437950413827 22.415 35.67034436338596 139.7437943011735 22.415 35.67034441691796 139.74379356101466 22.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abdb1cd0-8808-41ad-bbd9-8effa3d6d9da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abdb1cd0-8808-41ad-bbd9-8effa3d6d9da_0">
											<gml:posList>35.67033046320564 139.74379294696126 20.357 35.67033046376419 139.74379369810583 20.357 35.67033046376419 139.74379369810583 22.415 35.67033046320564 139.74379294696126 22.415 35.67033046320564 139.74379294696126 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b86d4766-c22a-4361-a538-91bb4c894664">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b86d4766-c22a-4361-a538-91bb4c894664_0">
											<gml:posList>35.67034436338596 139.7437943011735 20.357 35.67034441691796 139.74379356101466 20.357 35.67034441691796 139.74379356101466 22.415 35.67034436338596 139.7437943011735 22.415 35.67034436338596 139.7437943011735 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7afe034-09ed-4389-8847-cbe1ae51f3b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7afe034-09ed-4389-8847-cbe1ae51f3b0_0">
											<gml:posList>35.67033046376419 139.74379369810583 20.357 35.6703305274106 139.74379443813373 20.357 35.6703305274106 139.74379443813373 22.415 35.67033046376419 139.74379369810583 22.415 35.67033046376419 139.74379369810583 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e393ce4-ed48-4731-8e59-5ff63ec220cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e393ce4-ed48-4731-8e59-5ff63ec220cc_0">
											<gml:posList>35.670344264785335 139.7437950413827 20.357 35.67034436338596 139.7437943011735 20.357 35.67034436338596 139.7437943011735 22.415 35.670344264785335 139.7437950413827 22.415 35.670344264785335 139.7437950413827 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bef858be-6983-421f-813f-071b7b8db820">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bef858be-6983-421f-813f-071b7b8db820_0">
											<gml:posList>35.6703305274106 139.74379443813373 20.357 35.67033063611739 139.743795167065 20.357 35.67033063611739 139.743795167065 22.415 35.6703305274106 139.74379443813373 22.415 35.6703305274106 139.74379443813373 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0cf497d-6777-425c-b7bb-f18064deb206">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0cf497d-6777-425c-b7bb-f18064deb206_0">
											<gml:posList>35.67034411208594 139.74379575955976 20.357 35.670344264785335 139.7437950413827 20.357 35.670344264785335 139.7437950413827 22.415 35.67034411208594 139.74379575955976 22.415 35.67034411208594 139.74379575955976 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e716210-0672-4c29-8c55-f4e99d5686c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e716210-0672-4c29-8c55-f4e99d5686c2_0">
											<gml:posList>35.67033079889833 139.74379588488966 20.357 35.67033079889833 139.74379588488966 22.415 35.67033063611739 139.743795167065 22.415 35.67033063611739 139.743795167065 20.357 35.67033079889833 139.74379588488966 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af8080cd-e30e-4ac1-8101-7365d0e41a77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af8080cd-e30e-4ac1-8101-7365d0e41a77_0">
											<gml:posList>35.67034390529598 139.743796466751 20.357 35.67034411208594 139.74379575955976 20.357 35.67034411208594 139.74379575955976 22.415 35.67034390529598 139.743796466751 22.415 35.67034390529598 139.743796466751 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4ddb69b-3bc5-4b43-9c48-5a4a1dd044b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4ddb69b-3bc5-4b43-9c48-5a4a1dd044b3_0">
											<gml:posList>35.67033079889833 139.74379588488966 20.357 35.670331006739644 139.74379659161775 20.357 35.670331006739644 139.74379659161775 22.415 35.67033079889833 139.74379588488966 22.415 35.67033079889833 139.74379588488966 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-743e5c59-2f6c-4abd-903b-b80625f8f71a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-743e5c59-2f6c-4abd-903b-b80625f8f71a_0">
											<gml:posList>35.67034365341276 139.74379714085381 20.357 35.67034390529598 139.743796466751 20.357 35.67034390529598 139.743796466751 22.415 35.67034365341276 139.74379714085381 22.415 35.67034365341276 139.74379714085381 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83e04309-2840-4ac3-a3f5-687ca7046943">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83e04309-2840-4ac3-a3f5-687ca7046943_0">
											<gml:posList>35.67033126863867 139.74379726514672 20.357 35.67033126863867 139.74379726514672 22.415 35.670331006739644 139.74379659161775 22.415 35.670331006739644 139.74379659161775 20.357 35.67033126863867 139.74379726514672 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82ff0e4c-9828-47e5-9ea2-f9558f6268b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82ff0e4c-9828-47e5-9ea2-f9558f6268b3_0">
											<gml:posList>35.67034365341276 139.74379714085381 20.357 35.67034365341276 139.74379714085381 22.415 35.670343356444484 139.74379779291448 22.415 35.670343356444484 139.74379779291448 20.357 35.67034365341276 139.74379714085381 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16af7d96-9221-4cc9-ac6f-29bb8a8bb25e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16af7d96-9221-4cc9-ac6f-29bb8a8bb25e_0">
											<gml:posList>35.67033126863867 139.74379726514672 20.357 35.67033157558166 139.74379790548662 20.357 35.67033157558166 139.74379790548662 22.415 35.67033126863867 139.74379726514672 22.415 35.67033126863867 139.74379726514672 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d231428-8f0f-421c-9306-387d5f111b9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d231428-8f0f-421c-9306-387d5f111b9c_0">
											<gml:posList>35.670343005369226 139.74379841189682 20.357 35.670343356444484 139.74379779291448 20.357 35.670343356444484 139.74379779291448 22.415 35.670343005369226 139.74379841189682 22.415 35.670343005369226 139.74379841189682 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aef7d2a5-9f13-49ba-9dc3-4506d8fd8d07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aef7d2a5-9f13-49ba-9dc3-4506d8fd8d07_0">
											<gml:posList>35.67033193658236 139.74379851262742 20.357 35.67033193658236 139.74379851262742 22.415 35.67033157558166 139.74379790548662 22.415 35.67033157558166 139.74379790548662 20.357 35.67033193658236 139.74379851262742 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48350d0f-2cfe-4f6e-98ef-a061ba27eea2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48350d0f-2cfe-4f6e-98ef-a061ba27eea2_0">
											<gml:posList>35.67034261820621 139.7437989867344 20.357 35.670343005369226 139.74379841189682 20.357 35.670343005369226 139.74379841189682 22.415 35.67034261820621 139.7437989867344 22.415 35.67034261820621 139.7437989867344 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba52d9c6-5fef-41e1-b448-0f62803f2ab8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba52d9c6-5fef-41e1-b448-0f62803f2ab8_0">
											<gml:posList>35.67033193658236 139.74379851262742 20.357 35.67033232459958 139.74379908659927 20.357 35.67033232459958 139.74379908659927 22.415 35.67033193658236 139.74379851262742 22.415 35.67033193658236 139.74379851262742 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-341a2e5f-6964-4977-b933-625464b75af2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-341a2e5f-6964-4977-b933-625464b75af2_0">
											<gml:posList>35.67034219495546 139.74379951742725 20.357 35.67034261820621 139.7437989867344 20.357 35.67034261820621 139.7437989867344 22.415 35.67034219495546 139.74379951742725 22.415 35.67034219495546 139.74379951742725 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0d9cf14-e9a6-4858-9970-c1bca0d93dc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0d9cf14-e9a6-4858-9970-c1bca0d93dc2_0">
											<gml:posList>35.67033232459958 139.74379908659927 20.357 35.670332757644346 139.7437996052896 20.357 35.670332757644346 139.7437996052896 22.415 35.67033232459958 139.74379908659927 22.415 35.67033232459958 139.74379908659927 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0496bd2-8e0d-4721-8e8d-3ed3308fc7e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0496bd2-8e0d-4721-8e8d-3ed3308fc7e7_0">
											<gml:posList>35.67034219495546 139.74379951742725 20.357 35.67034219495546 139.74379951742725 22.415 35.670341726603226 139.74380000398546 22.415 35.670341726603226 139.74380000398546 20.357 35.67034219495546 139.74379951742725 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42805229-8d6b-49ec-b4f0-226f9ac511cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42805229-8d6b-49ec-b4f0-226f9ac511cd_0">
											<gml:posList>35.670332757644346 139.7437996052896 20.357 35.67033322671115 139.7438000797547 20.357 35.67033322671115 139.7438000797547 22.415 35.670332757644346 139.7437996052896 22.415 35.670332757644346 139.7437996052896 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8646deb5-b56f-42f6-ac4c-f6d44dd5da27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8646deb5-b56f-42f6-ac4c-f6d44dd5da27_0">
											<gml:posList>35.67034123116875 139.74380043534262 20.357 35.670341726603226 139.74380000398546 20.357 35.670341726603226 139.74380000398546 22.415 35.67034123116875 139.74380043534262 22.415 35.67034123116875 139.74380043534262 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26df4dd4-5d12-4eb2-8d1e-9d273ec4a532">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26df4dd4-5d12-4eb2-8d1e-9d273ec4a532_0">
											<gml:posList>35.67033322671115 139.7438000797547 20.357 35.67033373179999 139.74380050999454 20.357 35.67033373179999 139.74380050999454 22.415 35.67033322671115 139.7438000797547 22.415 35.67033322671115 139.7438000797547 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d040cfa-fe81-4247-8bb2-abffd65790fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d040cfa-fe81-4247-8bb2-abffd65790fc_0">
											<gml:posList>35.67034070865204 139.74380081149874 20.357 35.67034123116875 139.74380043534262 20.357 35.67034123116875 139.74380043534262 22.415 35.67034070865204 139.74380081149874 22.415 35.67034070865204 139.74380081149874 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-048d1e4d-48e7-4b65-a0ea-1ac61ba73a5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-048d1e4d-48e7-4b65-a0ea-1ac61ba73a5f_0">
											<gml:posList>35.67033373179999 139.74380050999454 20.357 35.670334263880726 139.74380087392674 20.357 35.670334263880726 139.74380087392674 22.415 35.67033373179999 139.74380050999454 22.415 35.67033373179999 139.74380050999454 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f443d424-6834-442b-863a-b77210929726">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f443d424-6834-442b-863a-b77210929726_0">
											<gml:posList>35.67034015905308 139.74380113245385 20.357 35.67034070865204 139.74380081149874 20.357 35.67034070865204 139.74380081149874 22.415 35.67034015905308 139.74380113245385 22.415 35.67034015905308 139.74380113245385 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ec0ef67-9b9b-4377-bee6-64b2b5aa14cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ec0ef67-9b9b-4377-bee6-64b2b5aa14cc_0">
											<gml:posList>35.670334263880726 139.74380087392674 20.357 35.670334813947846 139.7438011826076 20.357 35.670334813947846 139.7438011826076 22.415 35.670334263880726 139.74380087392674 22.415 35.670334263880726 139.74380087392674 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-121b3faf-0f77-4bca-ad5f-ba5e49c6cc55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-121b3faf-0f77-4bca-ad5f-ba5e49c6cc55_0">
											<gml:posList>35.670339591377406 139.7438013871516 20.357 35.67034015905308 139.74380113245385 20.357 35.67034015905308 139.74380113245385 22.415 35.670339591377406 139.7438013871516 22.415 35.670339591377406 139.7438013871516 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84d1435a-f11e-4c6d-bdc6-5792bbec979e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84d1435a-f11e-4c6d-bdc6-5792bbec979e_0">
											<gml:posList>35.670334813947846 139.7438011826076 20.357 35.670335391015065 139.743801436027 20.357 35.670335391015065 139.743801436027 22.415 35.670334813947846 139.7438011826076 22.415 35.670334813947846 139.7438011826076 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b55fa8a5-22b9-4000-9f1d-871ae3679c7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b55fa8a5-22b9-4000-9f1d-871ae3679c7c_0">
											<gml:posList>35.67033900564142 139.7438015976845 20.357 35.670339591377406 139.7438013871516 20.357 35.670339591377406 139.7438013871516 22.415 35.67033900564142 139.7438015976845 22.415 35.67033900564142 139.7438015976845 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19cbb30d-a754-4cce-b50d-4964ac2b4759">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19cbb30d-a754-4cce-b50d-4964ac2b4759_0">
											<gml:posList>35.670335391015065 139.743801436027 20.357 35.67033597704672 139.74380162315896 20.357 35.67033597704672 139.74380162315896 22.415 35.670335391015065 139.743801436027 22.415 35.670335391015065 139.743801436027 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b610906d-83a3-44a3-bb0a-3deedfade8fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b610906d-83a3-44a3-bb0a-3deedfade8fa_0">
											<gml:posList>35.6703384018205 139.74380173091384 20.357 35.67033900564142 139.7438015976845 20.357 35.67033900564142 139.7438015976845 22.415 35.6703384018205 139.74380173091384 22.415 35.6703384018205 139.74380173091384 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c93887a-04e9-4430-8160-6a2043591916">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c93887a-04e9-4430-8160-6a2043591916_0">
											<gml:posList>35.67033597704672 139.74380162315896 20.357 35.670336581056546 139.74380174399326 20.357 35.670336581056546 139.74380174399326 22.415 35.67033597704672 139.74380162315896 22.415 35.67033597704672 139.74380162315896 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2017f0c0-4b2e-433f-a9b5-546ef2edc5b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2017f0c0-4b2e-433f-a9b5-546ef2edc5b5_0">
											<gml:posList>35.670337797950296 139.74380179786564 20.357 35.6703384018205 139.74380173091384 20.357 35.6703384018205 139.74380173091384 22.415 35.670337797950296 139.74380179786564 22.415 35.670337797950296 139.74380179786564 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b7c1c9e-6e3d-4bb8-871f-c0ad3663294b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b7c1c9e-6e3d-4bb8-871f-c0ad3663294b_0">
											<gml:posList>35.670336581056546 139.74380174399326 20.357 35.67033718502531 139.74380180959636 20.357 35.67033718502531 139.74380180959636 22.415 35.670336581056546 139.74380174399326 22.415 35.670336581056546 139.74380174399326 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36953e24-c95e-44af-bdf5-75e2d55ca687">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36953e24-c95e-44af-bdf5-75e2d55ca687_0">
											<gml:posList>35.67033718502531 139.74380180959636 20.357 35.670337797950296 139.74380179786564 20.357 35.670337797950296 139.74380179786564 22.415 35.67033718502531 139.74380180959636 22.415 35.67033718502531 139.74380180959636 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-402c60f9-9ebe-4862-8e1b-6b422c345b80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-402c60f9-9ebe-4862-8e1b-6b422c345b80_0">
											<gml:posList>35.67036705943496 139.7437814732145 16.8 35.67035698821535 139.7438260892473 16.8 35.67035698821535 139.7438260892473 18.274 35.67036705943496 139.7437814732145 18.274 35.67036705943496 139.7437814732145 16.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ecbda3b-143f-41ee-b11f-76d2a59943b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ecbda3b-143f-41ee-b11f-76d2a59943b4_0">
											<gml:posList>35.670368357394565 139.74382994274552 18.274 35.67037895195372 139.74378605517552 18.274 35.67036705943496 139.7437814732145 18.274 35.67035698821535 139.7438260892473 18.274 35.670368357394565 139.74382994274552 18.274</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4680bc25-366d-481e-a0a6-f9cdbd24ae65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4680bc25-366d-481e-a0a6-f9cdbd24ae65_0">
											<gml:posList>35.67037895195372 139.74378605517552 16.8 35.67037895195372 139.74378605517552 18.274 35.670368357394565 139.74382994274552 18.274 35.670368357394565 139.74382994274552 16.8 35.67037895195372 139.74378605517552 16.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcf930c3-3cac-453b-930c-c36fbeaeb66f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcf930c3-3cac-453b-930c-c36fbeaeb66f_0">
											<gml:posList>35.670368357394565 139.74382994274552 16.8 35.670368357394565 139.74382994274552 18.274 35.67035698821535 139.7438260892473 18.274 35.67035698821535 139.7438260892473 16.8 35.670368357394565 139.74382994274552 16.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-65a036dc-f171-4455-a94c-28212d2392da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65a036dc-f171-4455-a94c-28212d2392da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65a036dc-f171-4455-a94c-28212d2392da">
											<gml:posList>35.670383865648816 139.7437876845341 7.698 35.670362208751634 139.74387674155528 7.698 35.670272677277445 139.74384292947602 7.698 35.67029514513868 139.74375354025173 7.698 35.670383865648816 139.7437876845341 7.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ea44ff4a-3368-4f84-a728-aa303dbc04de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea44ff4a-3368-4f84-a728-aa303dbc04de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea44ff4a-3368-4f84-a728-aa303dbc04de">
											<gml:posList>35.670272677277445 139.74384292947602 21.1 35.67027439807772 139.74384182293082 21.1 35.67029605709433 139.74375564906626 21.1 35.67029514513868 139.74375354025173 21.1 35.670272677277445 139.74384292947602 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b5dd03d9-9ade-4a85-8e62-899abd5d2238">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5dd03d9-9ade-4a85-8e62-899abd5d2238">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5dd03d9-9ade-4a85-8e62-899abd5d2238">
											<gml:posList>35.67033602552854 139.74386685123287 21.1 35.670335095547394 139.74386474243616 21.1 35.67027439807772 139.74384182293082 21.1 35.670272677277445 139.74384292947602 21.1 35.67033602552854 139.74386685123287 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc45ae9f-cc36-4a6c-8f17-8000a86fff0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc45ae9f-cc36-4a6c-8f17-8000a86fff0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc45ae9f-cc36-4a6c-8f17-8000a86fff0b">
											<gml:posList>35.67035503279459 139.7437783495105 20.357 35.67029605709433 139.74375564906626 20.357 35.67027439807772 139.74384182293082 20.357 35.670335095547394 139.74386474243616 20.357 35.67035503279459 139.7437783495105 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66a37cd0-81b3-43c9-9dff-49145d1702bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66a37cd0-81b3-43c9-9dff-49145d1702bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66a37cd0-81b3-43c9-9dff-49145d1702bb">
											<gml:posList>35.67029514513868 139.74375354025173 21.1 35.67029605709433 139.74375564906626 21.1 35.67035503279459 139.7437783495105 21.1 35.67035670851741 139.74377723196687 21.1 35.67029514513868 139.74375354025173 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bdf64325-27b8-489e-81e6-7d654b751ccb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdf64325-27b8-489e-81e6-7d654b751ccb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdf64325-27b8-489e-81e6-7d654b751ccb">
											<gml:posList>35.67035670851741 139.74377723196687 21.1 35.67035503279459 139.7437783495105 21.1 35.670335095547394 139.74386474243616 21.1 35.67033602552854 139.74386685123287 21.1 35.67035670851741 139.74377723196687 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c49367f-7bc7-4325-b6d9-96e73d33f66a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c49367f-7bc7-4325-b6d9-96e73d33f66a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c49367f-7bc7-4325-b6d9-96e73d33f66a">
											<gml:posList>35.67036709530912 139.74378123015677 19.054 35.67035670851741 139.74377723196687 19.054 35.67033602552854 139.74386685123287 19.054 35.6703468720911 139.74387094833662 19.054 35.67036709530912 139.74378123015677 19.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6412a8fa-e90d-4fbd-8530-4dd36343beb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6412a8fa-e90d-4fbd-8530-4dd36343beb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6412a8fa-e90d-4fbd-8530-4dd36343beb6">
											<gml:posList>35.670383865648816 139.7437876845341 16.8 35.67036709530912 139.74378123015677 16.8 35.6703468720911 139.74387094833662 16.8 35.670362208751634 139.74387674155528 16.8 35.670383865648816 139.7437876845341 16.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a80c73e-2511-4316-a713-9b84de4c36b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a80c73e-2511-4316-a713-9b84de4c36b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a80c73e-2511-4316-a713-9b84de4c36b2">
											<gml:posList>35.67029605709433 139.74375564906626 21.1 35.67029605709433 139.74375564906626 20.357 35.67035503279459 139.7437783495105 20.357 35.67035503279459 139.7437783495105 21.1 35.67029605709433 139.74375564906626 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04eead05-e14c-4daa-8678-f909c6044f8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04eead05-e14c-4daa-8678-f909c6044f8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04eead05-e14c-4daa-8678-f909c6044f8c">
											<gml:posList>35.670383865648816 139.7437876845341 7.698 35.67029514513868 139.74375354025173 7.698 35.67029514513868 139.74375354025173 21.1 35.67035670851741 139.74377723196687 21.1 35.67035670851741 139.74377723196687 19.054 35.67036709530912 139.74378123015677 19.054 35.67036709530912 139.74378123015677 16.8 35.670383865648816 139.7437876845341 16.8 35.670383865648816 139.7437876845341 7.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-689ee507-6f25-4047-9aa2-d73d4c81a549">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-689ee507-6f25-4047-9aa2-d73d4c81a549">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-689ee507-6f25-4047-9aa2-d73d4c81a549">
											<gml:posList>35.67029514513868 139.74375354025173 7.698 35.670272677277445 139.74384292947602 7.698 35.670272677277445 139.74384292947602 21.1 35.67029514513868 139.74375354025173 21.1 35.67029514513868 139.74375354025173 7.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3442900e-3d5b-4882-b497-ff3d8042a238">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3442900e-3d5b-4882-b497-ff3d8042a238">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3442900e-3d5b-4882-b497-ff3d8042a238">
											<gml:posList>35.67027439807772 139.74384182293082 21.1 35.67027439807772 139.74384182293082 20.357 35.67029605709433 139.74375564906626 20.357 35.67029605709433 139.74375564906626 21.1 35.67027439807772 139.74384182293082 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c29af5ef-1b40-400b-b298-0f649e91bff9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c29af5ef-1b40-400b-b298-0f649e91bff9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c29af5ef-1b40-400b-b298-0f649e91bff9">
											<gml:posList>35.67035503279459 139.7437783495105 21.1 35.67035503279459 139.7437783495105 20.357 35.670335095547394 139.74386474243616 20.357 35.670335095547394 139.74386474243616 21.1 35.67035503279459 139.7437783495105 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f7ae824-3755-4a49-8c9c-0572f2486806">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f7ae824-3755-4a49-8c9c-0572f2486806">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f7ae824-3755-4a49-8c9c-0572f2486806">
											<gml:posList>35.67035670851741 139.74377723196687 19.054 35.67035670851741 139.74377723196687 21.1 35.67033602552854 139.74386685123287 21.1 35.67033602552854 139.74386685123287 19.054 35.67035670851741 139.74377723196687 19.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f805dcb-4066-4eaf-841c-6ab642414176">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f805dcb-4066-4eaf-841c-6ab642414176">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f805dcb-4066-4eaf-841c-6ab642414176">
											<gml:posList>35.67036709530912 139.74378123015677 16.8 35.67036709530912 139.74378123015677 19.054 35.6703468720911 139.74387094833662 19.054 35.6703468720911 139.74387094833662 16.8 35.67036709530912 139.74378123015677 16.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55327944-a9a0-4268-849a-08fe49eab531">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55327944-a9a0-4268-849a-08fe49eab531">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55327944-a9a0-4268-849a-08fe49eab531">
											<gml:posList>35.670362208751634 139.74387674155528 7.698 35.670383865648816 139.7437876845341 7.698 35.670383865648816 139.7437876845341 16.8 35.670362208751634 139.74387674155528 16.8 35.670362208751634 139.74387674155528 7.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b36de2d-9192-4188-877c-0aaba8089348">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b36de2d-9192-4188-877c-0aaba8089348">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b36de2d-9192-4188-877c-0aaba8089348">
											<gml:posList>35.670335095547394 139.74386474243616 21.1 35.670335095547394 139.74386474243616 20.357 35.67027439807772 139.74384182293082 20.357 35.67027439807772 139.74384182293082 21.1 35.670335095547394 139.74386474243616 21.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd6f8617-3513-4f06-a86e-dc0aa7b0e07f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd6f8617-3513-4f06-a86e-dc0aa7b0e07f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd6f8617-3513-4f06-a86e-dc0aa7b0e07f">
											<gml:posList>35.670362208751634 139.74387674155528 7.698 35.670362208751634 139.74387674155528 16.8 35.6703468720911 139.74387094833662 16.8 35.6703468720911 139.74387094833662 19.054 35.67033602552854 139.74386685123287 19.054 35.67033602552854 139.74386685123287 21.1 35.670272677277445 139.74384292947602 21.1 35.670272677277445 139.74384292947602 7.698 35.670362208751634 139.74387674155528 7.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4357</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">87.39505</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>