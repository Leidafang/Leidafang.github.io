<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ac9bc3b3-bc65-4ed0-886f-a50b0ecac0fe">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">38.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>2</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67473728038673 139.73878897845634 0 35.674777920013106 139.73877335444686 0 35.67478162665357 139.7387873795941 0 35.67481866183426 139.73877308545138 0 35.674821734391884 139.73878313447995 0 35.67488075644363 139.73876041876323 0 35.67488446499417 139.73877687423922 0 35.67489508890277 139.73877270808055 0 35.674945469106994 139.73875294100387 0 35.674934050876004 139.73869832762057 0 35.674918778268044 139.73862527050832 0 35.67471539994034 139.73870339112293 0 35.67473728038673 139.73878897845634 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67473728038673 139.73878897845634 8.24 35.67471539994034 139.73870339112293 8.24 35.674918778268044 139.73862527050832 8.24 35.674934050876004 139.73869832762057 8.24 35.674945469106994 139.73875294100387 8.24 35.67489508890277 139.73877270808055 8.24 35.67488446499417 139.73877687423922 8.24 35.67488075644363 139.73876041876323 8.24 35.674821734391884 139.73878313447995 8.24 35.67481866183426 139.73877308545138 8.24 35.67478162665357 139.7387873795941 8.24 35.674777920013106 139.73877335444686 8.24 35.67473728038673 139.73878897845634 8.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67473728038673 139.73878897845634 8.24 35.674777920013106 139.73877335444686 8.24 35.674777920013106 139.73877335444686 42.95 35.67473728038673 139.73878897845634 42.95 35.67473728038673 139.73878897845634 8.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674777920013106 139.73877335444686 8.24 35.67478162665357 139.7387873795941 8.24 35.67478162665357 139.7387873795941 42.95 35.674777920013106 139.73877335444686 42.95 35.674777920013106 139.73877335444686 8.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67478162665357 139.7387873795941 8.24 35.67481866183426 139.73877308545138 8.24 35.67481866183426 139.73877308545138 42.95 35.67478162665357 139.7387873795941 42.95 35.67478162665357 139.7387873795941 8.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67481866183426 139.73877308545138 8.24 35.674821734391884 139.73878313447995 8.24 35.674821734391884 139.73878313447995 42.95 35.67481866183426 139.73877308545138 42.95 35.67481866183426 139.73877308545138 8.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674821734391884 139.73878313447995 8.24 35.67488075644363 139.73876041876323 8.24 35.67488075644363 139.73876041876323 42.95 35.674821734391884 139.73878313447995 42.95 35.674821734391884 139.73878313447995 8.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67488075644363 139.73876041876323 8.24 35.67488446499417 139.73877687423922 8.24 35.67488446499417 139.73877687423922 42.95 35.67488075644363 139.73876041876323 42.95 35.67488075644363 139.73876041876323 8.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67488446499417 139.73877687423922 8.24 35.67489508890277 139.73877270808055 8.24 35.67489508890277 139.73877270808055 42.95 35.67488446499417 139.73877687423922 42.95 35.67488446499417 139.73877687423922 8.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67489508890277 139.73877270808055 8.24 35.674945469106994 139.73875294100387 8.24 35.674945469106994 139.73875294100387 42.95 35.67489508890277 139.73877270808055 42.95 35.67489508890277 139.73877270808055 8.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674945469106994 139.73875294100387 8.24 35.674934050876004 139.73869832762057 8.24 35.674934050876004 139.73869832762057 42.95 35.674945469106994 139.73875294100387 42.95 35.674945469106994 139.73875294100387 8.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674934050876004 139.73869832762057 8.24 35.674918778268044 139.73862527050832 8.24 35.674918778268044 139.73862527050832 42.95 35.674934050876004 139.73869832762057 42.95 35.674934050876004 139.73869832762057 8.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674918778268044 139.73862527050832 8.24 35.67471539994034 139.73870339112293 8.24 35.67471539994034 139.73870339112293 42.95 35.674918778268044 139.73862527050832 42.95 35.674918778268044 139.73862527050832 8.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67471539994034 139.73870339112293 8.24 35.67473728038673 139.73878897845634 8.24 35.67473728038673 139.73878897845634 42.95 35.67471539994034 139.73870339112293 42.95 35.67471539994034 139.73870339112293 8.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67473728038673 139.73878897845634 42.95 35.674777920013106 139.73877335444686 42.95 35.67478162665357 139.7387873795941 42.95 35.67481866183426 139.73877308545138 42.95 35.674821734391884 139.73878313447995 42.95 35.67488075644363 139.73876041876323 42.95 35.67488446499417 139.73877687423922 42.95 35.67489508890277 139.73877270808055 42.95 35.674945469106994 139.73875294100387 42.95 35.674934050876004 139.73869832762057 42.95 35.674918778268044 139.73862527050832 42.95 35.67471539994034 139.73870339112293 42.95 35.67473728038673 139.73878897845634 42.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2e571fd6-4a05-4e8d-a9eb-526b0da89731"/>
							<gml:surfaceMember xlink:href="#poly-966d11e0-98bf-4688-bf27-908112aa73f8"/>
							<gml:surfaceMember xlink:href="#poly-dc48fefb-4b44-4855-849f-56cd4baad084"/>
							<gml:surfaceMember xlink:href="#poly-4631039b-b584-4c7b-95be-5550a3191266"/>
							<gml:surfaceMember xlink:href="#poly-cba43f0d-b9d6-4c3e-aabb-e93741142fb3"/>
							<gml:surfaceMember xlink:href="#poly-5958e279-336e-46c2-baed-c62dc30c6533"/>
							<gml:surfaceMember xlink:href="#poly-7f234e02-8a65-4e9e-a0bc-2aea700be14c"/>
							<gml:surfaceMember xlink:href="#poly-01fbf0da-c670-4947-9d4d-380624e57df5"/>
							<gml:surfaceMember xlink:href="#poly-eb7753a8-a59c-4aae-aa0f-7e36ab3d29c8"/>
							<gml:surfaceMember xlink:href="#poly-5368cd43-4fd9-4ce4-b9fe-be1e63e94fdf"/>
							<gml:surfaceMember xlink:href="#poly-a4e02ab6-154b-4526-92bd-4a58a6ca3f59"/>
							<gml:surfaceMember xlink:href="#poly-84d9f023-2ea0-4aef-9b55-cf20af9e0ca0"/>
							<gml:surfaceMember xlink:href="#poly-a4d80426-f7d5-48d5-9493-5c5e0eb12e51"/>
							<gml:surfaceMember xlink:href="#poly-e1ad6240-5feb-4f58-87be-8334c981b039"/>
							<gml:surfaceMember xlink:href="#poly-49c9d332-e489-4e8b-a673-71c8316c89f0"/>
							<gml:surfaceMember xlink:href="#poly-7c5ed660-de46-40f1-9e76-db3705480556"/>
							<gml:surfaceMember xlink:href="#poly-54648f7b-4f51-483f-9fec-39ac4002af95"/>
							<gml:surfaceMember xlink:href="#poly-7028a796-43f8-4f0b-be4f-2809fa22ecce"/>
							<gml:surfaceMember xlink:href="#poly-7d502c30-73d8-42ac-94da-2506496f5586"/>
							<gml:surfaceMember xlink:href="#poly-7ba4730e-2758-47bb-a5b7-830a7471a0ce"/>
							<gml:surfaceMember xlink:href="#poly-5ad9bec6-fa81-467a-8294-a127c1871b65"/>
							<gml:surfaceMember xlink:href="#poly-93bc80d7-d778-4754-916b-2db60342c942"/>
							<gml:surfaceMember xlink:href="#poly-b7a2b4fc-fb84-49b1-9566-19d28b90651a"/>
							<gml:surfaceMember xlink:href="#poly-8012903e-c373-44e3-9512-306f365bc1f0"/>
							<gml:surfaceMember xlink:href="#poly-d772a06f-1f0d-4c98-934e-52fc17b85e49"/>
							<gml:surfaceMember xlink:href="#poly-4d2b4a77-ebe2-4e74-bfb5-43e766b53766"/>
							<gml:surfaceMember xlink:href="#poly-4187c197-71dc-4a17-8662-0349169725a4"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2e571fd6-4a05-4e8d-a9eb-526b0da89731">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e571fd6-4a05-4e8d-a9eb-526b0da89731">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e571fd6-4a05-4e8d-a9eb-526b0da89731">
											<gml:posList>35.67473728038673 139.73878897845634 8.24 35.67471539994031 139.73870339112293 8.24 35.674918778268044 139.73862527050832 8.24 35.674945469106966 139.73875294100384 8.24 35.67488446499414 139.7387768742392 8.24 35.67488075644362 139.73876041876323 8.24 35.67482173439185 139.73878313447992 8.24 35.67481866183422 139.73877308545138 8.24 35.67478162665356 139.73878737959407 8.24 35.67477792001308 139.73877335444686 8.24 35.67473728038673 139.73878897845634 8.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-966d11e0-98bf-4688-bf27-908112aa73f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-966d11e0-98bf-4688-bf27-908112aa73f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-966d11e0-98bf-4688-bf27-908112aa73f8">
											<gml:posList>35.674911203553734 139.73865560315275 43.7 35.67491917907129 139.73868792796472 43.7 35.67493405087598 139.73869832762057 43.7 35.674918778268044 139.73862527050832 43.7 35.674911203553734 139.73865560315275 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc48fefb-4b44-4855-849f-56cd4baad084">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc48fefb-4b44-4855-849f-56cd4baad084">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc48fefb-4b44-4855-849f-56cd4baad084">
											<gml:posList>35.67491917907129 139.73868792796472 46.45 35.674911203553734 139.73865560315275 46.45 35.6748569657556 139.7386757062434 46.45 35.6748649412678 139.73870803103554 46.45 35.67491917907129 139.73868792796472 46.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4631039b-b584-4c7b-95be-5550a3191266">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4631039b-b584-4c7b-95be-5550a3191266">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4631039b-b584-4c7b-95be-5550a3191266">
											<gml:posList>35.674881246390534 139.7387186057465 43.7 35.67493405087598 139.73869832762057 43.7 35.67491917907129 139.73868792796472 43.7 35.6748649412678 139.73870803103554 43.7 35.6748569657556 139.7386757062434 43.7 35.674911203553734 139.73865560315275 43.7 35.674918778268044 139.73862527050832 43.7 35.67471539994031 139.73870339112293 43.7 35.67473728038673 139.73878897845634 43.7 35.67477792001308 139.73877335444686 43.7 35.67478162665356 139.73878737959407 43.7 35.67481866183422 139.73877308545138 43.7 35.67482173439185 139.73878313447992 43.7 35.674843878462504 139.73876828345666 43.7 35.67483740479756 139.73874302689376 43.7 35.674859743063735 139.7387344281594 43.7 35.67486621673048 139.73875968472865 43.7 35.67488075644362 139.73876041876323 43.7 35.67488446499414 139.7387768742392 43.7 35.674895079889055 139.73877270809115 43.7 35.674881246390534 139.7387186057465 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cba43f0d-b9d6-4c3e-aabb-e93741142fb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cba43f0d-b9d6-4c3e-aabb-e93741142fb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cba43f0d-b9d6-4c3e-aabb-e93741142fb3">
											<gml:posList>35.674945469106966 139.73875294100384 46.7 35.67493405087598 139.73869832762057 46.7 35.674881246390534 139.7387186057465 46.7 35.674895079889055 139.73877270809115 46.7 35.674945469106966 139.73875294100384 46.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5958e279-336e-46c2-baed-c62dc30c6533">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5958e279-336e-46c2-baed-c62dc30c6533">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5958e279-336e-46c2-baed-c62dc30c6533">
											<gml:posList>35.67483740479756 139.73874302689376 45.05 35.674843878462504 139.73876828345666 45.05 35.67486621673048 139.73875968472865 45.05 35.674859743063735 139.7387344281594 45.05 35.67483740479756 139.73874302689376 45.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f234e02-8a65-4e9e-a0bc-2aea700be14c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f234e02-8a65-4e9e-a0bc-2aea700be14c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f234e02-8a65-4e9e-a0bc-2aea700be14c">
											<gml:posList>35.67488075644362 139.73876041876323 43.7 35.67486621673048 139.73875968472865 43.7 35.674843878462504 139.73876828345666 43.7 35.67482173439185 139.73878313447992 43.7 35.67488075644362 139.73876041876323 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01fbf0da-c670-4947-9d4d-380624e57df5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01fbf0da-c670-4947-9d4d-380624e57df5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01fbf0da-c670-4947-9d4d-380624e57df5">
											<gml:posList>35.67471539994031 139.73870339112293 43.7 35.674918778268044 139.73862527050832 43.7 35.674918778268044 139.73862527050832 8.24 35.67471539994031 139.73870339112293 8.24 35.67471539994031 139.73870339112293 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb7753a8-a59c-4aae-aa0f-7e36ab3d29c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb7753a8-a59c-4aae-aa0f-7e36ab3d29c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb7753a8-a59c-4aae-aa0f-7e36ab3d29c8">
											<gml:posList>35.674911203553734 139.73865560315275 43.7 35.6748569657556 139.7386757062434 43.7 35.6748569657556 139.7386757062434 46.45 35.674911203553734 139.73865560315275 46.45 35.674911203553734 139.73865560315275 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5368cd43-4fd9-4ce4-b9fe-be1e63e94fdf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5368cd43-4fd9-4ce4-b9fe-be1e63e94fdf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5368cd43-4fd9-4ce4-b9fe-be1e63e94fdf">
											<gml:posList>35.67491917907129 139.73868792796472 43.7 35.674911203553734 139.73865560315275 43.7 35.674911203553734 139.73865560315275 46.45 35.67491917907129 139.73868792796472 46.45 35.67491917907129 139.73868792796472 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4e02ab6-154b-4526-92bd-4a58a6ca3f59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4e02ab6-154b-4526-92bd-4a58a6ca3f59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4e02ab6-154b-4526-92bd-4a58a6ca3f59">
											<gml:posList>35.67493405087598 139.73869832762057 46.7 35.674945469106966 139.73875294100384 46.7 35.674945469106966 139.73875294100384 8.24 35.674918778268044 139.73862527050832 8.24 35.674918778268044 139.73862527050832 43.7 35.67493405087598 139.73869832762057 43.7 35.67493405087598 139.73869832762057 46.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84d9f023-2ea0-4aef-9b55-cf20af9e0ca0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84d9f023-2ea0-4aef-9b55-cf20af9e0ca0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84d9f023-2ea0-4aef-9b55-cf20af9e0ca0">
											<gml:posList>35.6748569657556 139.7386757062434 43.7 35.6748649412678 139.73870803103554 43.7 35.6748649412678 139.73870803103554 46.45 35.6748569657556 139.7386757062434 46.45 35.6748569657556 139.7386757062434 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4d80426-f7d5-48d5-9493-5c5e0eb12e51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4d80426-f7d5-48d5-9493-5c5e0eb12e51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4d80426-f7d5-48d5-9493-5c5e0eb12e51">
											<gml:posList>35.6748649412678 139.73870803103554 43.7 35.67491917907129 139.73868792796472 43.7 35.67491917907129 139.73868792796472 46.45 35.6748649412678 139.73870803103554 46.45 35.6748649412678 139.73870803103554 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1ad6240-5feb-4f58-87be-8334c981b039">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1ad6240-5feb-4f58-87be-8334c981b039">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1ad6240-5feb-4f58-87be-8334c981b039">
											<gml:posList>35.67493405087598 139.73869832762057 46.7 35.67493405087598 139.73869832762057 43.7 35.674881246390534 139.7387186057465 43.7 35.674881246390534 139.7387186057465 46.7 35.67493405087598 139.73869832762057 46.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49c9d332-e489-4e8b-a673-71c8316c89f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49c9d332-e489-4e8b-a673-71c8316c89f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49c9d332-e489-4e8b-a673-71c8316c89f0">
											<gml:posList>35.674859743063735 139.7387344281594 43.7 35.67483740479756 139.73874302689376 43.7 35.67483740479756 139.73874302689376 45.05 35.674859743063735 139.7387344281594 45.05 35.674859743063735 139.7387344281594 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c5ed660-de46-40f1-9e76-db3705480556">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c5ed660-de46-40f1-9e76-db3705480556">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c5ed660-de46-40f1-9e76-db3705480556">
											<gml:posList>35.674881246390534 139.7387186057465 46.7 35.674881246390534 139.7387186057465 43.7 35.674895079889055 139.73877270809115 43.7 35.674895079889055 139.73877270809115 46.7 35.674881246390534 139.7387186057465 46.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54648f7b-4f51-483f-9fec-39ac4002af95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54648f7b-4f51-483f-9fec-39ac4002af95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54648f7b-4f51-483f-9fec-39ac4002af95">
											<gml:posList>35.67473728038673 139.73878897845634 43.7 35.67471539994031 139.73870339112293 43.7 35.67471539994031 139.73870339112293 8.24 35.67473728038673 139.73878897845634 8.24 35.67473728038673 139.73878897845634 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7028a796-43f8-4f0b-be4f-2809fa22ecce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7028a796-43f8-4f0b-be4f-2809fa22ecce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7028a796-43f8-4f0b-be4f-2809fa22ecce">
											<gml:posList>35.67486621673048 139.73875968472865 43.7 35.674859743063735 139.7387344281594 43.7 35.674859743063735 139.7387344281594 45.05 35.67486621673048 139.73875968472865 45.05 35.67486621673048 139.73875968472865 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d502c30-73d8-42ac-94da-2506496f5586">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d502c30-73d8-42ac-94da-2506496f5586">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d502c30-73d8-42ac-94da-2506496f5586">
											<gml:posList>35.67483740479756 139.73874302689376 43.7 35.674843878462504 139.73876828345666 43.7 35.674843878462504 139.73876828345666 45.05 35.67483740479756 139.73874302689376 45.05 35.67483740479756 139.73874302689376 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ba4730e-2758-47bb-a5b7-830a7471a0ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ba4730e-2758-47bb-a5b7-830a7471a0ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ba4730e-2758-47bb-a5b7-830a7471a0ce">
											<gml:posList>35.674843878462504 139.73876828345666 43.7 35.67486621673048 139.73875968472865 43.7 35.67486621673048 139.73875968472865 45.05 35.674843878462504 139.73876828345666 45.05 35.674843878462504 139.73876828345666 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ad9bec6-fa81-467a-8294-a127c1871b65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ad9bec6-fa81-467a-8294-a127c1871b65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ad9bec6-fa81-467a-8294-a127c1871b65">
											<gml:posList>35.67488446499414 139.7387768742392 43.7 35.67488446499414 139.7387768742392 8.24 35.674945469106966 139.73875294100384 8.24 35.674945469106966 139.73875294100384 46.7 35.674895079889055 139.73877270809115 46.7 35.674895079889055 139.73877270809115 43.7 35.67488446499414 139.7387768742392 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-93bc80d7-d778-4754-916b-2db60342c942">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93bc80d7-d778-4754-916b-2db60342c942">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93bc80d7-d778-4754-916b-2db60342c942">
											<gml:posList>35.67488446499414 139.7387768742392 43.7 35.67488075644362 139.73876041876323 43.7 35.67488075644362 139.73876041876323 8.24 35.67488446499414 139.7387768742392 8.24 35.67488446499414 139.7387768742392 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7a2b4fc-fb84-49b1-9566-19d28b90651a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7a2b4fc-fb84-49b1-9566-19d28b90651a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7a2b4fc-fb84-49b1-9566-19d28b90651a">
											<gml:posList>35.67488075644362 139.73876041876323 43.7 35.67482173439185 139.73878313447992 43.7 35.67482173439185 139.73878313447992 8.24 35.67488075644362 139.73876041876323 8.24 35.67488075644362 139.73876041876323 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8012903e-c373-44e3-9512-306f365bc1f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8012903e-c373-44e3-9512-306f365bc1f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8012903e-c373-44e3-9512-306f365bc1f0">
											<gml:posList>35.67482173439185 139.73878313447992 43.7 35.67481866183422 139.73877308545138 43.7 35.67481866183422 139.73877308545138 8.24 35.67482173439185 139.73878313447992 8.24 35.67482173439185 139.73878313447992 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d772a06f-1f0d-4c98-934e-52fc17b85e49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d772a06f-1f0d-4c98-934e-52fc17b85e49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d772a06f-1f0d-4c98-934e-52fc17b85e49">
											<gml:posList>35.67481866183422 139.73877308545138 43.7 35.67478162665356 139.73878737959407 43.7 35.67478162665356 139.73878737959407 8.24 35.67481866183422 139.73877308545138 8.24 35.67481866183422 139.73877308545138 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d2b4a77-ebe2-4e74-bfb5-43e766b53766">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d2b4a77-ebe2-4e74-bfb5-43e766b53766">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d2b4a77-ebe2-4e74-bfb5-43e766b53766">
											<gml:posList>35.67478162665356 139.73878737959407 43.7 35.67477792001308 139.73877335444686 43.7 35.67477792001308 139.73877335444686 8.24 35.67478162665356 139.73878737959407 8.24 35.67478162665356 139.73878737959407 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4187c197-71dc-4a17-8662-0349169725a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4187c197-71dc-4a17-8662-0349169725a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4187c197-71dc-4a17-8662-0349169725a4">
											<gml:posList>35.67477792001308 139.73877335444686 43.7 35.67473728038673 139.73878897845634 43.7 35.67473728038673 139.73878897845634 8.24 35.67477792001308 139.73877335444686 8.24 35.67477792001308 139.73877335444686 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4615</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">239.1619</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.15</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>