<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_acce2f36-6ecf-4dd3-ab01-a1eb01135d76">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">91.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>26</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>3</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667722664576274 139.74188656534696 0 35.667878206027055 139.741602728866 0 35.66768852818479 139.74144664652852 0 35.667556030300595 139.74168848200716 0 35.66761889539498 139.74174021533148 0 35.66759585217308 139.74178221598166 0 35.667722664576274 139.74188656534696 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667722664576274 139.74188656534696 22.44 35.66759585217308 139.74178221598166 22.44 35.66761889539498 139.74174021533148 22.44 35.667556030300595 139.74168848200716 22.44 35.66768852818479 139.74144664652852 22.44 35.667878206027055 139.741602728866 22.44 35.667722664576274 139.74188656534696 22.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667722664576274 139.74188656534696 22.44 35.667878206027055 139.741602728866 22.44 35.667878206027055 139.741602728866 113.71 35.667722664576274 139.74188656534696 113.71 35.667722664576274 139.74188656534696 22.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667878206027055 139.741602728866 22.44 35.66768852818479 139.74144664652852 22.44 35.66768852818479 139.74144664652852 113.71 35.667878206027055 139.741602728866 113.71 35.667878206027055 139.741602728866 22.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66768852818479 139.74144664652852 22.44 35.667556030300595 139.74168848200716 22.44 35.667556030300595 139.74168848200716 113.71 35.66768852818479 139.74144664652852 113.71 35.66768852818479 139.74144664652852 22.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667556030300595 139.74168848200716 22.44 35.66761889539498 139.74174021533148 22.44 35.66761889539498 139.74174021533148 113.71 35.667556030300595 139.74168848200716 113.71 35.667556030300595 139.74168848200716 22.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66761889539498 139.74174021533148 22.44 35.66759585217308 139.74178221598166 22.44 35.66759585217308 139.74178221598166 113.71 35.66761889539498 139.74174021533148 113.71 35.66761889539498 139.74174021533148 22.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66759585217308 139.74178221598166 22.44 35.667722664576274 139.74188656534696 22.44 35.667722664576274 139.74188656534696 113.71 35.66759585217308 139.74178221598166 113.71 35.66759585217308 139.74178221598166 22.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667722664576274 139.74188656534696 113.71 35.667878206027055 139.741602728866 113.71 35.66768852818479 139.74144664652852 113.71 35.667556030300595 139.74168848200716 113.71 35.66761889539498 139.74174021533148 113.71 35.66759585217308 139.74178221598166 113.71 35.667722664576274 139.74188656534696 113.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b0c280b3-88e8-4ab1-8214-324135d3b450"/>
							<gml:surfaceMember xlink:href="#poly-1184baa3-293a-4198-aa6f-5af80f8ba074"/>
							<gml:surfaceMember xlink:href="#poly-6872fe94-4aee-48d1-affe-7b7ed789e74e"/>
							<gml:surfaceMember xlink:href="#poly-6c0fd230-7b86-4d4b-bec8-6395f9789298"/>
							<gml:surfaceMember xlink:href="#poly-169b9081-9dad-4eee-bfca-9e0599027520"/>
							<gml:surfaceMember xlink:href="#poly-a701cf11-f497-4eb4-b927-bc49617efc43"/>
							<gml:surfaceMember xlink:href="#poly-153a4962-dee1-46db-974b-17d9f95283a8"/>
							<gml:surfaceMember xlink:href="#poly-48ff3224-7be4-4d96-a32f-f7d35fa6337c"/>
							<gml:surfaceMember xlink:href="#poly-1f4d2a19-42f9-4f1f-8375-7aea3ebe8452"/>
							<gml:surfaceMember xlink:href="#poly-34c8dad0-806c-4313-86d6-a038ffe2d1ad"/>
							<gml:surfaceMember xlink:href="#poly-c57723dd-65cd-41b0-a171-9e223d2e8fc4"/>
							<gml:surfaceMember xlink:href="#poly-2db39202-e454-4f9a-94b3-d9bc54efbb17"/>
							<gml:surfaceMember xlink:href="#poly-a8fc4a4d-e182-4dfc-a202-f966a9660464"/>
							<gml:surfaceMember xlink:href="#poly-b1c3cabd-e70b-47e4-99f2-de2ad26a485d"/>
							<gml:surfaceMember xlink:href="#poly-b616ceea-16a5-4c1b-ad93-3b3b487176d2"/>
							<gml:surfaceMember xlink:href="#poly-a5d82bad-cedd-4cca-a7b9-b23063943d7d"/>
							<gml:surfaceMember xlink:href="#poly-ef53f5e7-39db-40ad-9afc-e733b93cbc23"/>
							<gml:surfaceMember xlink:href="#poly-e3552708-7fc7-41c2-9063-27e07a66348b"/>
							<gml:surfaceMember xlink:href="#poly-dbb33bb3-85bb-4687-843f-f9ea334f5c92"/>
							<gml:surfaceMember xlink:href="#poly-4f7316e1-291e-4f59-9575-ee9ff3317b83"/>
							<gml:surfaceMember xlink:href="#poly-13c2d633-0d68-4c50-9912-6bd1ae817ddb"/>
							<gml:surfaceMember xlink:href="#poly-29837b8d-77c9-4c7e-b9af-2d32e9780b89"/>
							<gml:surfaceMember xlink:href="#poly-11dc7b21-65cb-4c8e-b4f8-805c5865e80f"/>
							<gml:surfaceMember xlink:href="#poly-79890b84-7cc4-43a6-9d09-c5bec48466fb"/>
							<gml:surfaceMember xlink:href="#poly-7ad36042-2413-4862-ac37-a79fc23eff3a"/>
							<gml:surfaceMember xlink:href="#poly-cc1935c5-7d7f-4944-9446-8334ba1f9bc9"/>
							<gml:surfaceMember xlink:href="#poly-082d7ee1-246c-4fe7-847c-1879e1a935a4"/>
							<gml:surfaceMember xlink:href="#poly-9ef83dc6-d886-4cb2-a6cc-1ed764c74d87"/>
							<gml:surfaceMember xlink:href="#poly-220a9d2c-5e94-4e5a-b21d-199f0dd518df"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_acce2f36-6ecf-4dd3-ab01-a1eb01135d76_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ded91f9e-a268-4f83-8751-b80ca5c8464f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66767883904516 139.74157749616782 118.9 35.667690979146926 139.74158748985147 118.9 35.66768904388864 139.74159102675017 118.9 35.66769385122627 139.74159498672427 118.9 35.66769016072284 139.74160171789288 118.9 35.6676785166886 139.74159213233742 118.9 35.66767338600013 139.7416015051194 118.9 35.66766807358264 139.74159713702593 118.9 35.66767883904516 139.74157749616782 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-045cb588-769d-4215-b03c-e8bbd0aec286">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667683990561805 139.74153632224795 114 35.66768948129741 139.7415262973409 114 35.667707592700815 139.74154180712782 114 35.66770195764327 139.74155169965056 114 35.667683990561805 139.74153632224795 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-258b95b8-e9c6-4838-94dd-55c13a737dc6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66770949995653 139.74153701102753 114 35.667700516760384 139.7415297752074 114 35.66770564730008 139.7415202146377 114 35.66771463049678 139.74152745045723 114 35.66770949995653 139.74153701102753 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a65f8e24-0b50-413f-af72-5ecd33633f1f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66774186312423 139.7416012169098 118.9 35.667748916284644 139.74160701898282 118.9 35.66773866388485 139.7416257203663 118.9 35.66773161073373 139.74161992933824 118.9 35.66774186312423 139.7416012169098 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1b980bf-fa69-4755-9147-2fa9c3187e7c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66774299589252 139.74158549730356 114 35.66772501986065 139.741570197217 114 35.66773919742928 139.74154518413036 114 35.667757173464274 139.74156048421398 114 35.66774299589252 139.74158549730356 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01da7dbd-cb9b-4710-a8d0-7c39ed28dce9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66774186312423 139.7416012169098 114 35.667748830079816 139.74158851720387 114 35.66775587421869 139.7415943082407 114 35.667748916284644 139.74160701898282 114 35.66774186312423 139.7416012169098 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce442be9-fffb-4492-901a-c26bfdea3e0b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66778372110291 139.7416106795457 114 35.66779325225065 139.7415917801487 114 35.66780079207698 139.74159748225472 114 35.66779125191463 139.74161638166308 114 35.66778372110291 139.7416106795457 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-931f309a-1303-46fe-811c-e70a68bc016e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-931f309a-1303-46fe-811c-e70a68bc016e_0">
											<gml:posList>35.66771463049678 139.74152745045723 114 35.66770564730008 139.7415202146377 114 35.66770564730008 139.7415202146377 116.115 35.66771463049678 139.74152745045723 116.115 35.66771463049678 139.74152745045723 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ea48787-012d-4e14-b8ce-8c366118a560">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ea48787-012d-4e14-b8ce-8c366118a560_0">
											<gml:posList>35.66770564730008 139.7415202146377 114 35.667700516760384 139.7415297752074 114 35.667700516760384 139.7415297752074 116.115 35.66770564730008 139.7415202146377 116.115 35.66770564730008 139.7415202146377 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fea1a324-1138-4b70-ab0f-d25f6f7ef1f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fea1a324-1138-4b70-ab0f-d25f6f7ef1f1_0">
											<gml:posList>35.66770949995653 139.74153701102753 116.115 35.66771463049678 139.74152745045723 116.115 35.66770564730008 139.7415202146377 116.115 35.667700516760384 139.7415297752074 116.115 35.66770949995653 139.74153701102753 116.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-308e363b-09de-456f-8ddb-834375eeb948">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-308e363b-09de-456f-8ddb-834375eeb948_0">
											<gml:posList>35.667683990561805 139.74153632224795 115.842 35.66768948129741 139.7415262973409 115.842 35.66768948129741 139.7415262973409 114 35.667683990561805 139.74153632224795 114 35.667683990561805 139.74153632224795 115.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b95d954-f560-4982-afca-466528b27cba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b95d954-f560-4982-afca-466528b27cba_0">
											<gml:posList>35.66770949995653 139.74153701102753 114 35.66771463049678 139.74152745045723 114 35.66771463049678 139.74152745045723 116.115 35.66770949995653 139.74153701102753 116.115 35.66770949995653 139.74153701102753 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1eef646-64d5-4e3c-9aad-0673bf9622b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1eef646-64d5-4e3c-9aad-0673bf9622b8_0">
											<gml:posList>35.667700516760384 139.7415297752074 114 35.66770949995653 139.74153701102753 114 35.66770949995653 139.74153701102753 116.115 35.667700516760384 139.7415297752074 116.115 35.667700516760384 139.7415297752074 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e9902b9-6fef-40e1-96cf-d503412884bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e9902b9-6fef-40e1-96cf-d503412884bc_0">
											<gml:posList>35.66768948129741 139.7415262973409 114 35.66768948129741 139.7415262973409 115.842 35.667707592700815 139.74154180712782 115.842 35.667707592700815 139.74154180712782 114 35.66768948129741 139.7415262973409 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2b8adc4-e3d9-4a7c-8e3a-6465daf3db40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2b8adc4-e3d9-4a7c-8e3a-6465daf3db40_0">
											<gml:posList>35.667683990561805 139.74153632224795 115.842 35.66770195764327 139.74155169965056 115.842 35.667707592700815 139.74154180712782 115.842 35.66768948129741 139.7415262973409 115.842 35.667683990561805 139.74153632224795 115.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1b9891b-85c5-4518-b78c-9ad019778f5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1b9891b-85c5-4518-b78c-9ad019778f5b_0">
											<gml:posList>35.667683990561805 139.74153632224795 115.842 35.667683990561805 139.74153632224795 114 35.66770195764327 139.74155169965056 114 35.66770195764327 139.74155169965056 115.842 35.667683990561805 139.74153632224795 115.842</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fb83a47-68f1-496d-9bff-f297a2d595fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fb83a47-68f1-496d-9bff-f297a2d595fc_0">
											<gml:posList>35.66770195764327 139.74155169965056 114 35.667707592700815 139.74154180712782 114 35.667707592700815 139.74154180712782 115.842 35.66770195764327 139.74155169965056 115.842 35.66770195764327 139.74155169965056 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ad0b051-f2f6-434d-aeaf-4952d9725d11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ad0b051-f2f6-434d-aeaf-4952d9725d11_0">
											<gml:posList>35.667757173464274 139.74156048421398 114 35.66773919742928 139.74154518413036 114 35.66773919742928 139.74154518413036 117.093 35.667757173464274 139.74156048421398 117.093 35.667757173464274 139.74156048421398 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acaf7d04-383e-47b3-a329-c82f7d8f22f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acaf7d04-383e-47b3-a329-c82f7d8f22f0_0">
											<gml:posList>35.66772501986065 139.741570197217 114 35.66772501986065 139.741570197217 117.093 35.66773919742928 139.74154518413036 117.093 35.66773919742928 139.74154518413036 114 35.66772501986065 139.741570197217 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f41db923-f0ab-4de4-a0b1-95cc427b9f27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f41db923-f0ab-4de4-a0b1-95cc427b9f27_0">
											<gml:posList>35.66774299589252 139.74158549730356 117.093 35.667757173464274 139.74156048421398 117.093 35.66773919742928 139.74154518413036 117.093 35.66772501986065 139.741570197217 117.093 35.66774299589252 139.74158549730356 117.093</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f88fe79-177b-4906-93cc-ed7cedbb8764">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f88fe79-177b-4906-93cc-ed7cedbb8764_0">
											<gml:posList>35.66774299589252 139.74158549730356 114 35.667757173464274 139.74156048421398 114 35.667757173464274 139.74156048421398 117.093 35.66774299589252 139.74158549730356 117.093 35.66774299589252 139.74158549730356 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4992958-270a-433a-8a69-10526281049e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4992958-270a-433a-8a69-10526281049e_0">
											<gml:posList>35.66772501986065 139.741570197217 114 35.66774299589252 139.74158549730356 114 35.66774299589252 139.74158549730356 117.093 35.66772501986065 139.741570197217 117.093 35.66772501986065 139.741570197217 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f0ef0ca-ab89-4dd0-b318-4d49220c4b7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f0ef0ca-ab89-4dd0-b318-4d49220c4b7a_0">
											<gml:posList>35.667690979146926 139.74158748985147 118.9 35.66767883904516 139.74157749616782 118.9 35.66767883904516 139.74157749616782 120.677 35.667690979146926 139.74158748985147 120.677 35.667690979146926 139.74158748985147 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f064f2eb-5272-423d-8cbe-e4cd3f5ec40e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f064f2eb-5272-423d-8cbe-e4cd3f5ec40e_0">
											<gml:posList>35.66767883904516 139.74157749616782 118.9 35.66766807358264 139.74159713702593 118.9 35.66766807358264 139.74159713702593 120.677 35.66767883904516 139.74157749616782 120.677 35.66767883904516 139.74157749616782 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c28647a3-088d-4f7c-b0f4-94ce5b1ac525">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c28647a3-088d-4f7c-b0f4-94ce5b1ac525_0">
											<gml:posList>35.66768904388864 139.74159102675017 118.9 35.667690979146926 139.74158748985147 118.9 35.667690979146926 139.74158748985147 120.677 35.66768904388864 139.74159102675017 120.677 35.66768904388864 139.74159102675017 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68b3fdb4-13b9-4e88-9ace-6d5ecb5a76d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68b3fdb4-13b9-4e88-9ace-6d5ecb5a76d6_0">
											<gml:posList>35.66767338600013 139.7416015051194 120.677 35.6676785166886 139.74159213233742 120.677 35.66769016072284 139.74160171789288 120.677 35.66769385122627 139.74159498672427 120.677 35.66768904388864 139.74159102675017 120.677 35.667690979146926 139.74158748985147 120.677 35.66767883904516 139.74157749616782 120.677 35.66766807358264 139.74159713702593 120.677 35.66767338600013 139.7416015051194 120.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f134e18f-b779-41ff-92be-40e4f0738087">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f134e18f-b779-41ff-92be-40e4f0738087_0">
											<gml:posList>35.66775587421869 139.7415943082407 114 35.667748830079816 139.74158851720387 114 35.667748830079816 139.74158851720387 120.335 35.66775587421869 139.7415943082407 120.335 35.66775587421869 139.7415943082407 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-882ceb52-ddab-40b4-9cdb-75a40978decd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-882ceb52-ddab-40b4-9cdb-75a40978decd_0">
											<gml:posList>35.66768904388864 139.74159102675017 118.9 35.66768904388864 139.74159102675017 120.677 35.66769385122627 139.74159498672427 120.677 35.66769385122627 139.74159498672427 118.9 35.66768904388864 139.74159102675017 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3f0334a-6e40-4dd0-957a-d543f1078209">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3f0334a-6e40-4dd0-957a-d543f1078209_0">
											<gml:posList>35.66780079207698 139.74159748225472 114 35.66779325225065 139.7415917801487 114 35.66779325225065 139.7415917801487 116.326 35.66780079207698 139.74159748225472 116.326 35.66780079207698 139.74159748225472 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb12d489-a7de-4a52-a1ce-c0b6d396b828">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb12d489-a7de-4a52-a1ce-c0b6d396b828_0">
											<gml:posList>35.66767338600013 139.7416015051194 118.9 35.6676785166886 139.74159213233742 118.9 35.6676785166886 139.74159213233742 120.677 35.66767338600013 139.7416015051194 120.677 35.66767338600013 139.7416015051194 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-721514a1-79c1-45ea-9ecc-d4e16df2eeb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-721514a1-79c1-45ea-9ecc-d4e16df2eeb5_0">
											<gml:posList>35.66769016072284 139.74160171789288 118.9 35.66769016072284 139.74160171789288 120.677 35.6676785166886 139.74159213233742 120.677 35.6676785166886 139.74159213233742 118.9 35.66769016072284 139.74160171789288 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dd49845-2101-4195-8c9c-a8bc4975e988">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dd49845-2101-4195-8c9c-a8bc4975e988_0">
											<gml:posList>35.66769385122627 139.74159498672427 120.677 35.66769016072284 139.74160171789288 120.677 35.66769016072284 139.74160171789288 118.9 35.66769385122627 139.74159498672427 118.9 35.66769385122627 139.74159498672427 120.677</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cadbf32b-c15f-43c4-8dfd-f5d5a13b5eea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cadbf32b-c15f-43c4-8dfd-f5d5a13b5eea_0">
											<gml:posList>35.66767338600013 139.7416015051194 118.9 35.66767338600013 139.7416015051194 120.677 35.66766807358264 139.74159713702593 120.677 35.66766807358264 139.74159713702593 118.9 35.66767338600013 139.7416015051194 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02fdc2b5-f327-495d-9169-952b672a66b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02fdc2b5-f327-495d-9169-952b672a66b1_0">
											<gml:posList>35.66778372110291 139.7416106795457 114 35.66778372110291 139.7416106795457 116.326 35.66779325225065 139.7415917801487 116.326 35.66779325225065 139.7415917801487 114 35.66778372110291 139.7416106795457 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-270c1889-d64c-4130-829c-d6d2f28aaaac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-270c1889-d64c-4130-829c-d6d2f28aaaac_0">
											<gml:posList>35.667748916284644 139.74160701898282 118.9 35.66774186312423 139.7416012169098 118.9 35.66774186312423 139.7416012169098 114 35.667748916284644 139.74160701898282 114 35.667748916284644 139.74160701898282 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76f64f3e-7aba-4d40-9b8f-fe45786ced9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76f64f3e-7aba-4d40-9b8f-fe45786ced9c_0">
											<gml:posList>35.66780079207698 139.74159748225472 116.326 35.66779325225065 139.7415917801487 116.326 35.66778372110291 139.7416106795457 116.326 35.66779125191463 139.74161638166308 116.326 35.66780079207698 139.74159748225472 116.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e33a94f-57f0-4374-97cc-d4875b113dd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e33a94f-57f0-4374-97cc-d4875b113dd4_0">
											<gml:posList>35.66773161073373 139.74161992933824 120.335 35.667748830079816 139.74158851720387 120.335 35.667748830079816 139.74158851720387 114 35.66774186312423 139.7416012169098 114 35.66774186312423 139.7416012169098 118.9 35.66773161073373 139.74161992933824 118.9 35.66773161073373 139.74161992933824 120.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acae9cab-d384-401e-a44c-5cc13c35d1bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acae9cab-d384-401e-a44c-5cc13c35d1bd_0">
											<gml:posList>35.66779125191463 139.74161638166308 114 35.66780079207698 139.74159748225472 114 35.66780079207698 139.74159748225472 116.326 35.66779125191463 139.74161638166308 116.326 35.66779125191463 139.74161638166308 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0cc9633-4c34-4663-9344-a04d8ac7646d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0cc9633-4c34-4663-9344-a04d8ac7646d_0">
											<gml:posList>35.66775587421869 139.7415943082407 120.335 35.667748830079816 139.74158851720387 120.335 35.66773161073373 139.74161992933824 120.335 35.66773866388485 139.7416257203663 120.335 35.66775587421869 139.7415943082407 120.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c8e6011-f72e-4785-9d35-7e5ad1d0eaa8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c8e6011-f72e-4785-9d35-7e5ad1d0eaa8_0">
											<gml:posList>35.667748916284644 139.74160701898282 118.9 35.667748916284644 139.74160701898282 114 35.66775587421869 139.7415943082407 114 35.66775587421869 139.7415943082407 120.335 35.66773866388485 139.7416257203663 120.335 35.66773866388485 139.7416257203663 118.9 35.667748916284644 139.74160701898282 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23148cff-ab6c-4886-9f3e-2f9fb5915487">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23148cff-ab6c-4886-9f3e-2f9fb5915487_0">
											<gml:posList>35.66778372110291 139.7416106795457 114 35.66779125191463 139.74161638166308 114 35.66779125191463 139.74161638166308 116.326 35.66778372110291 139.7416106795457 116.326 35.66778372110291 139.7416106795457 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4e2a860-93d4-40b4-b94e-02ccdc6a50ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4e2a860-93d4-40b4-b94e-02ccdc6a50ff_0">
											<gml:posList>35.66773866388485 139.7416257203663 120.335 35.66773161073373 139.74161992933824 120.335 35.66773161073373 139.74161992933824 118.9 35.66773866388485 139.7416257203663 118.9 35.66773866388485 139.7416257203663 120.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_acce2f36-6ecf-4dd3-ab01-a1eb01135d76_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a2c4c7d-369d-4c6c-bef2-ea05986fe86e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66772042837801 139.74153013901704 114 35.667732776355074 139.74154086148977 114 35.66772015572088 139.74156266948438 114 35.66770781676787 139.74155195804553 114 35.66772042837801 139.74153013901704 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1f232a8-b7f0-47ea-9f16-209012933dc8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667778853522115 139.74161046419562 114 35.667753887386546 139.74158930672215 114 35.667765562425934 139.74156860439464 114 35.667790528565085 139.74158976186473 114 35.667778853522115 139.74161046419562 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d843d0d-76b0-4d66-a933-747d22d758fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d843d0d-76b0-4d66-a933-747d22d758fd_0">
											<gml:posList>35.66770781676787 139.74155195804553 114 35.66772015572088 139.74156266948438 114 35.66772015572088 139.74156266948438 116.518 35.66770781676787 139.74155195804553 116.518 35.66770781676787 139.74155195804553 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28a3a7f3-f43f-4c4d-899f-c968c2cfa45c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28a3a7f3-f43f-4c4d-899f-c968c2cfa45c_0">
											<gml:posList>35.66772042837801 139.74153013901704 114 35.66770781676787 139.74155195804553 114 35.66770781676787 139.74155195804553 116.518 35.66772042837801 139.74153013901704 116.518 35.66772042837801 139.74153013901704 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8752a08c-9c38-48d8-9704-04fd70963196">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8752a08c-9c38-48d8-9704-04fd70963196_0">
											<gml:posList>35.66772042837801 139.74153013901704 116.518 35.66770781676787 139.74155195804553 116.518 35.66772015572088 139.74156266948438 116.518 35.667732776355074 139.74154086148977 116.518 35.66772042837801 139.74153013901704 116.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0baa428-5435-4a26-a455-8244093a9f5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0baa428-5435-4a26-a455-8244093a9f5b_0">
											<gml:posList>35.66772015572088 139.74156266948438 114 35.667732776355074 139.74154086148977 114 35.667732776355074 139.74154086148977 116.518 35.66772015572088 139.74156266948438 116.518 35.66772015572088 139.74156266948438 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ccfca75-5c79-4429-bb9d-cc14045d0c3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ccfca75-5c79-4429-bb9d-cc14045d0c3b_0">
											<gml:posList>35.66772042837801 139.74153013901704 114 35.66772042837801 139.74153013901704 116.518 35.667732776355074 139.74154086148977 116.518 35.667732776355074 139.74154086148977 114 35.66772042837801 139.74153013901704 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf6ec846-c9f0-4022-a1a9-772acec9c8c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf6ec846-c9f0-4022-a1a9-772acec9c8c9_0">
											<gml:posList>35.667753887386546 139.74158930672215 114 35.667753887386546 139.74158930672215 117.189 35.667765562425934 139.74156860439464 117.189 35.667765562425934 139.74156860439464 114 35.667753887386546 139.74158930672215 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9aba9114-055a-4d46-a2e4-89209213bc9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9aba9114-055a-4d46-a2e4-89209213bc9b_0">
											<gml:posList>35.667753887386546 139.74158930672215 114 35.667778853522115 139.74161046419562 114 35.667778853522115 139.74161046419562 117.189 35.667753887386546 139.74158930672215 117.189 35.667753887386546 139.74158930672215 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad585216-9c81-4ff7-8db0-68d2e8590eec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad585216-9c81-4ff7-8db0-68d2e8590eec_0">
											<gml:posList>35.667778853522115 139.74161046419562 117.189 35.667790528565085 139.74158976186473 117.189 35.667765562425934 139.74156860439464 117.189 35.667753887386546 139.74158930672215 117.189 35.667778853522115 139.74161046419562 117.189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5758a9b-db74-4648-8ccc-2149ff6f20cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5758a9b-db74-4648-8ccc-2149ff6f20cc_0">
											<gml:posList>35.667790528565085 139.74158976186473 114 35.667765562425934 139.74156860439464 114 35.667765562425934 139.74156860439464 117.189 35.667790528565085 139.74158976186473 117.189 35.667790528565085 139.74158976186473 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a071bc6-d47c-4f1b-8e97-ed2ff26fc7a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a071bc6-d47c-4f1b-8e97-ed2ff26fc7a0_0">
											<gml:posList>35.667778853522115 139.74161046419562 114 35.667790528565085 139.74158976186473 114 35.667790528565085 139.74158976186473 117.189 35.667778853522115 139.74161046419562 117.189 35.667778853522115 139.74161046419562 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_acce2f36-6ecf-4dd3-ab01-a1eb01135d76_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e97d5f1f-564b-46f3-9cea-d58e7f5f08c3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66775061751464 139.7416039131396 114 35.66775587421869 139.7415943082407 114 35.6678006915626 139.7416311944693 114 35.667795434847235 139.74164078832527 114 35.66775061751464 139.7416039131396 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc79ea18-423f-49c5-b668-25fd4090df1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc79ea18-423f-49c5-b668-25fd4090df1a_0">
											<gml:posList>35.66775061751464 139.7416039131396 114 35.66775061751464 139.7416039131396 120.335 35.66775587421869 139.7415943082407 120.335 35.66775587421869 139.7415943082407 114 35.66775061751464 139.7416039131396 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b73a4cf4-c3eb-4306-b477-f541bda8d0d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b73a4cf4-c3eb-4306-b477-f541bda8d0d0_0">
											<gml:posList>35.66775587421869 139.7415943082407 114 35.66775587421869 139.7415943082407 120.335 35.6678006915626 139.7416311944693 120.335 35.6678006915626 139.7416311944693 114 35.66775587421869 139.7415943082407 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd3c9986-6e0f-47a9-bdda-e84f527ecfb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd3c9986-6e0f-47a9-bdda-e84f527ecfb1_0">
											<gml:posList>35.6678006915626 139.7416311944693 120.335 35.66775587421869 139.7415943082407 120.335 35.66775061751464 139.7416039131396 120.335 35.667795434847235 139.74164078832527 120.335 35.6678006915626 139.7416311944693 120.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae90f687-d101-4c7d-983a-0bfd433442e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae90f687-d101-4c7d-983a-0bfd433442e4_0">
											<gml:posList>35.667795434847235 139.74164078832527 114 35.667795434847235 139.74164078832527 120.335 35.66775061751464 139.7416039131396 120.335 35.66775061751464 139.7416039131396 114 35.667795434847235 139.74164078832527 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c32f836-6e61-486d-adcd-cbdd0581f613">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c32f836-6e61-486d-adcd-cbdd0581f613_0">
											<gml:posList>35.6678006915626 139.7416311944693 114 35.6678006915626 139.7416311944693 120.335 35.667795434847235 139.74164078832527 120.335 35.667795434847235 139.74164078832527 114 35.6678006915626 139.7416311944693 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b0c280b3-88e8-4ab1-8214-324135d3b450">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0c280b3-88e8-4ab1-8214-324135d3b450">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0c280b3-88e8-4ab1-8214-324135d3b450">
											<gml:posList>35.66772266457627 139.74188656534693 22.44 35.667595852173044 139.74178221598166 22.44 35.66761889539496 139.74174021533148 22.44 35.66755603030059 139.74168848200713 22.44 35.66768852818477 139.74144664652852 22.44 35.667878206027034 139.74160272886598 22.44 35.66772266457627 139.74188656534693 22.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1184baa3-293a-4198-aa6f-5af80f8ba074">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1184baa3-293a-4198-aa6f-5af80f8ba074">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1184baa3-293a-4198-aa6f-5af80f8ba074">
											<gml:posList>35.66768852818477 139.74144664652852 118.9 35.66755603030059 139.74168848200713 118.9 35.66760739917168 139.74167610714383 118.9 35.66763135143069 139.74163238226018 118.9 35.66767746467807 139.74154822613937 118.9 35.66769863553175 139.74150959651996 118.9 35.66768852818477 139.74144664652852 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6872fe94-4aee-48d1-affe-7b7ed789e74e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6872fe94-4aee-48d1-affe-7b7ed789e74e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6872fe94-4aee-48d1-affe-7b7ed789e74e">
											<gml:posList>35.66774568979818 139.74184455363488 118.9 35.667735600662134 139.7417816145892 118.9 35.66760739917168 139.74167610714383 118.9 35.66755603030059 139.74168848200713 118.9 35.66774568979818 139.74184455363488 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c0fd230-7b86-4d4b-bec8-6395f9789298">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c0fd230-7b86-4d4b-bec8-6395f9789298">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c0fd230-7b86-4d4b-bec8-6395f9789298">
											<gml:posList>35.66761889539496 139.74174021533148 34.1 35.667595852173044 139.74178221598166 34.1 35.66772266457627 139.74188656534693 34.1 35.66774568979818 139.74184455363488 34.1 35.66761889539496 139.74174021533148 34.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-169b9081-9dad-4eee-bfca-9e0599027520">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-169b9081-9dad-4eee-bfca-9e0599027520">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-169b9081-9dad-4eee-bfca-9e0599027520">
											<gml:posList>35.66760739917168 139.74167610714383 114 35.667735600662134 139.7417816145892 114 35.667759561964225 139.7417378786108 114 35.66763135143069 139.74163238226018 114 35.66760739917168 139.74167610714383 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a701cf11-f497-4eb4-b927-bc49617efc43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a701cf11-f497-4eb4-b927-bc49617efc43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a701cf11-f497-4eb4-b927-bc49617efc43">
											<gml:posList>35.667759561964225 139.7417378786108 118.9 35.66774833681759 139.7417101772777 118.9 35.66766727961168 139.74164347542532 118.9 35.66763135143069 139.74163238226018 118.9 35.667759561964225 139.7417378786108 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-153a4962-dee1-46db-974b-17d9f95283a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-153a4962-dee1-46db-974b-17d9f95283a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-153a4962-dee1-46db-974b-17d9f95283a8">
											<gml:posList>35.66767746467807 139.74154822613937 118.9 35.66763135143069 139.74163238226018 118.9 35.66766727961168 139.74164347542532 118.9 35.667696164531016 139.7415907535019 118.9 35.667777230787834 139.74165746636046 118.9 35.66774833681759 139.7417101772777 118.9 35.667759561964225 139.7417378786108 118.9 35.667805675284235 139.74165372241575 118.9 35.66767746467807 139.74154822613937 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-48ff3224-7be4-4d96-a32f-f7d35fa6337c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48ff3224-7be4-4d96-a32f-f7d35fa6337c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48ff3224-7be4-4d96-a32f-f7d35fa6337c">
											<gml:posList>35.667777230787834 139.74165746636046 123.096 35.667696164531016 139.7415907535019 123.096 35.66766727961168 139.74164347542532 123.096 35.66774833681759 139.7417101772777 123.096 35.667777230787834 139.74165746636046 123.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f4d2a19-42f9-4f1f-8375-7aea3ebe8452">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f4d2a19-42f9-4f1f-8375-7aea3ebe8452">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f4d2a19-42f9-4f1f-8375-7aea3ebe8452">
											<gml:posList>35.66782684617966 139.7416151038082 114 35.66769863553175 139.74150959651996 114 35.66767746467807 139.74154822613937 114 35.667805675284235 139.74165372241575 114 35.66782684617966 139.7416151038082 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-34c8dad0-806c-4313-86d6-a038ffe2d1ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34c8dad0-806c-4313-86d6-a038ffe2d1ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34c8dad0-806c-4313-86d6-a038ffe2d1ad">
											<gml:posList>35.66768852818477 139.74144664652852 118.9 35.66769863553175 139.74150959651996 118.9 35.66782684617966 139.7416151038082 118.9 35.667878206027034 139.74160272886598 118.9 35.66768852818477 139.74144664652852 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c57723dd-65cd-41b0-a171-9e223d2e8fc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c57723dd-65cd-41b0-a171-9e223d2e8fc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c57723dd-65cd-41b0-a171-9e223d2e8fc4">
											<gml:posList>35.667735600662134 139.7417816145892 118.9 35.66774568979818 139.74184455363488 118.9 35.667878206027034 139.74160272886598 118.9 35.66782684617966 139.7416151038082 118.9 35.667805675284235 139.74165372241575 118.9 35.667759561964225 139.7417378786108 118.9 35.667735600662134 139.7417816145892 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2db39202-e454-4f9a-94b3-d9bc54efbb17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2db39202-e454-4f9a-94b3-d9bc54efbb17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2db39202-e454-4f9a-94b3-d9bc54efbb17">
											<gml:posList>35.66763135143069 139.74163238226018 114 35.667759561964225 139.7417378786108 114 35.667759561964225 139.7417378786108 118.9 35.66763135143069 139.74163238226018 118.9 35.66763135143069 139.74163238226018 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8fc4a4d-e182-4dfc-a202-f966a9660464">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8fc4a4d-e182-4dfc-a202-f966a9660464">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8fc4a4d-e182-4dfc-a202-f966a9660464">
											<gml:posList>35.667805675284235 139.74165372241575 118.9 35.667805675284235 139.74165372241575 114 35.66767746467807 139.74154822613937 114 35.66767746467807 139.74154822613937 118.9 35.667805675284235 139.74165372241575 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1c3cabd-e70b-47e4-99f2-de2ad26a485d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1c3cabd-e70b-47e4-99f2-de2ad26a485d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1c3cabd-e70b-47e4-99f2-de2ad26a485d">
											<gml:posList>35.667878206027034 139.74160272886598 22.44 35.66768852818477 139.74144664652852 22.44 35.66768852818477 139.74144664652852 118.9 35.667878206027034 139.74160272886598 118.9 35.667878206027034 139.74160272886598 22.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b616ceea-16a5-4c1b-ad93-3b3b487176d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b616ceea-16a5-4c1b-ad93-3b3b487176d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b616ceea-16a5-4c1b-ad93-3b3b487176d2">
											<gml:posList>35.66767746467807 139.74154822613937 118.9 35.66767746467807 139.74154822613937 114 35.66769863553175 139.74150959651996 114 35.66769863553175 139.74150959651996 118.9 35.66767746467807 139.74154822613937 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5d82bad-cedd-4cca-a7b9-b23063943d7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5d82bad-cedd-4cca-a7b9-b23063943d7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5d82bad-cedd-4cca-a7b9-b23063943d7d">
											<gml:posList>35.66769863553175 139.74150959651996 118.9 35.66769863553175 139.74150959651996 114 35.66782684617966 139.7416151038082 114 35.66782684617966 139.7416151038082 118.9 35.66769863553175 139.74150959651996 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef53f5e7-39db-40ad-9afc-e733b93cbc23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef53f5e7-39db-40ad-9afc-e733b93cbc23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef53f5e7-39db-40ad-9afc-e733b93cbc23">
											<gml:posList>35.66768852818477 139.74144664652852 22.44 35.66755603030059 139.74168848200713 22.44 35.66755603030059 139.74168848200713 118.9 35.66768852818477 139.74144664652852 118.9 35.66768852818477 139.74144664652852 22.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3552708-7fc7-41c2-9063-27e07a66348b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3552708-7fc7-41c2-9063-27e07a66348b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3552708-7fc7-41c2-9063-27e07a66348b">
											<gml:posList>35.66766727961168 139.74164347542532 118.9 35.66766727961168 139.74164347542532 123.096 35.667696164531016 139.7415907535019 123.096 35.667696164531016 139.7415907535019 118.9 35.66766727961168 139.74164347542532 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbb33bb3-85bb-4687-843f-f9ea334f5c92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbb33bb3-85bb-4687-843f-f9ea334f5c92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbb33bb3-85bb-4687-843f-f9ea334f5c92">
											<gml:posList>35.667696164531016 139.7415907535019 118.9 35.667696164531016 139.7415907535019 123.096 35.667777230787834 139.74165746636046 123.096 35.667777230787834 139.74165746636046 118.9 35.667696164531016 139.7415907535019 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f7316e1-291e-4f59-9575-ee9ff3317b83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f7316e1-291e-4f59-9575-ee9ff3317b83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f7316e1-291e-4f59-9575-ee9ff3317b83">
											<gml:posList>35.66760739917168 139.74167610714383 114 35.66763135143069 139.74163238226018 114 35.66763135143069 139.74163238226018 118.9 35.66760739917168 139.74167610714383 118.9 35.66760739917168 139.74167610714383 114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13c2d633-0d68-4c50-9912-6bd1ae817ddb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13c2d633-0d68-4c50-9912-6bd1ae817ddb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13c2d633-0d68-4c50-9912-6bd1ae817ddb">
											<gml:posList>35.66774833681759 139.7417101772777 118.9 35.66774833681759 139.7417101772777 123.096 35.66766727961168 139.74164347542532 123.096 35.66766727961168 139.74164347542532 118.9 35.66774833681759 139.7417101772777 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29837b8d-77c9-4c7e-b9af-2d32e9780b89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29837b8d-77c9-4c7e-b9af-2d32e9780b89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29837b8d-77c9-4c7e-b9af-2d32e9780b89">
											<gml:posList>35.667777230787834 139.74165746636046 118.9 35.667777230787834 139.74165746636046 123.096 35.66774833681759 139.7417101772777 123.096 35.66774833681759 139.7417101772777 118.9 35.667777230787834 139.74165746636046 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11dc7b21-65cb-4c8e-b4f8-805c5865e80f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11dc7b21-65cb-4c8e-b4f8-805c5865e80f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11dc7b21-65cb-4c8e-b4f8-805c5865e80f">
											<gml:posList>35.66760739917168 139.74167610714383 118.9 35.667735600662134 139.7417816145892 118.9 35.667735600662134 139.7417816145892 114 35.66760739917168 139.74167610714383 114 35.66760739917168 139.74167610714383 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79890b84-7cc4-43a6-9d09-c5bec48466fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79890b84-7cc4-43a6-9d09-c5bec48466fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79890b84-7cc4-43a6-9d09-c5bec48466fb">
											<gml:posList>35.667735600662134 139.7417816145892 118.9 35.667759561964225 139.7417378786108 118.9 35.667759561964225 139.7417378786108 114 35.667735600662134 139.7417816145892 114 35.667735600662134 139.7417816145892 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ad36042-2413-4862-ac37-a79fc23eff3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ad36042-2413-4862-ac37-a79fc23eff3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ad36042-2413-4862-ac37-a79fc23eff3a">
											<gml:posList>35.66761889539496 139.74174021533148 22.44 35.667595852173044 139.74178221598166 22.44 35.667595852173044 139.74178221598166 34.1 35.66761889539496 139.74174021533148 34.1 35.66761889539496 139.74174021533148 22.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc1935c5-7d7f-4944-9446-8334ba1f9bc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc1935c5-7d7f-4944-9446-8334ba1f9bc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc1935c5-7d7f-4944-9446-8334ba1f9bc9">
											<gml:posList>35.66774568979818 139.74184455363488 118.9 35.66755603030059 139.74168848200713 118.9 35.66755603030059 139.74168848200713 22.44 35.66761889539496 139.74174021533148 22.44 35.66761889539496 139.74174021533148 34.1 35.66774568979818 139.74184455363488 34.1 35.66774568979818 139.74184455363488 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-082d7ee1-246c-4fe7-847c-1879e1a935a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-082d7ee1-246c-4fe7-847c-1879e1a935a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-082d7ee1-246c-4fe7-847c-1879e1a935a4">
											<gml:posList>35.667595852173044 139.74178221598166 22.44 35.66772266457627 139.74188656534693 22.44 35.66772266457627 139.74188656534693 34.1 35.667595852173044 139.74178221598166 34.1 35.667595852173044 139.74178221598166 22.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ef83dc6-d886-4cb2-a6cc-1ed764c74d87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ef83dc6-d886-4cb2-a6cc-1ed764c74d87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ef83dc6-d886-4cb2-a6cc-1ed764c74d87">
											<gml:posList>35.66782684617966 139.7416151038082 118.9 35.66782684617966 139.7416151038082 114 35.667805675284235 139.74165372241575 114 35.667805675284235 139.74165372241575 118.9 35.66782684617966 139.7416151038082 118.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-220a9d2c-5e94-4e5a-b21d-199f0dd518df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-220a9d2c-5e94-4e5a-b21d-199f0dd518df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-220a9d2c-5e94-4e5a-b21d-199f0dd518df">
											<gml:posList>35.667878206027034 139.74160272886598 22.44 35.667878206027034 139.74160272886598 118.9 35.66774568979818 139.74184455363488 118.9 35.66774568979818 139.74184455363488 34.1 35.66772266457627 139.74188656534693 34.1 35.66772266457627 139.74188656534693 22.44 35.667878206027034 139.74160272886598 22.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1928</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">746.0342</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>