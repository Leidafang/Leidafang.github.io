<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ad1e2887-04a9-4343-9073-6cc6a5a161db">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="地区計画">
				<gen:value>虎ノ門二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">47</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66949787375494 139.7449642040608 0 35.669554701946524 139.74489819593597 0 35.66904595641241 139.74415071678501 0 35.669014615802496 139.74418742460185 0 35.66897329342898 139.74413411804534 0 35.668796866558004 139.7443397706883 0 35.6688334972167 139.74438700711227 0 35.66881188287484 139.74441221606895 0 35.6693625129593 139.74512187091256 0 35.669494901819675 139.74496774210039 0 35.66949787375494 139.7449642040608 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66949787375494 139.7449642040608 6.5 35.669494901819675 139.74496774210039 6.5 35.6693625129593 139.74512187091256 6.5 35.66881188287484 139.74441221606895 6.5 35.6688334972167 139.74438700711227 6.5 35.668796866558004 139.7443397706883 6.5 35.66897329342898 139.74413411804534 6.5 35.669014615802496 139.74418742460185 6.5 35.66904595641241 139.74415071678501 6.5 35.669554701946524 139.74489819593597 6.5 35.66949787375494 139.7449642040608 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66949787375494 139.7449642040608 6.5 35.669554701946524 139.74489819593597 6.5 35.669554701946524 139.74489819593597 43.4 35.66949787375494 139.7449642040608 43.4 35.66949787375494 139.7449642040608 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669554701946524 139.74489819593597 6.5 35.66904595641241 139.74415071678501 6.5 35.66904595641241 139.74415071678501 43.4 35.669554701946524 139.74489819593597 43.4 35.669554701946524 139.74489819593597 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66904595641241 139.74415071678501 6.5 35.669014615802496 139.74418742460185 6.5 35.669014615802496 139.74418742460185 43.4 35.66904595641241 139.74415071678501 43.4 35.66904595641241 139.74415071678501 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669014615802496 139.74418742460185 6.5 35.66897329342898 139.74413411804534 6.5 35.66897329342898 139.74413411804534 43.4 35.669014615802496 139.74418742460185 43.4 35.669014615802496 139.74418742460185 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66897329342898 139.74413411804534 6.5 35.668796866558004 139.7443397706883 6.5 35.668796866558004 139.7443397706883 43.4 35.66897329342898 139.74413411804534 43.4 35.66897329342898 139.74413411804534 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668796866558004 139.7443397706883 6.5 35.6688334972167 139.74438700711227 6.5 35.6688334972167 139.74438700711227 43.4 35.668796866558004 139.7443397706883 43.4 35.668796866558004 139.7443397706883 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6688334972167 139.74438700711227 6.5 35.66881188287484 139.74441221606895 6.5 35.66881188287484 139.74441221606895 43.4 35.6688334972167 139.74438700711227 43.4 35.6688334972167 139.74438700711227 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881188287484 139.74441221606895 6.5 35.6693625129593 139.74512187091256 6.5 35.6693625129593 139.74512187091256 43.4 35.66881188287484 139.74441221606895 43.4 35.66881188287484 139.74441221606895 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6693625129593 139.74512187091256 6.5 35.669494901819675 139.74496774210039 6.5 35.669494901819675 139.74496774210039 43.4 35.6693625129593 139.74512187091256 43.4 35.6693625129593 139.74512187091256 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669494901819675 139.74496774210039 6.5 35.66949787375494 139.7449642040608 6.5 35.66949787375494 139.7449642040608 43.4 35.669494901819675 139.74496774210039 43.4 35.669494901819675 139.74496774210039 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66949787375494 139.7449642040608 43.4 35.669554701946524 139.74489819593597 43.4 35.66904595641241 139.74415071678501 43.4 35.669014615802496 139.74418742460185 43.4 35.66897329342898 139.74413411804534 43.4 35.668796866558004 139.7443397706883 43.4 35.6688334972167 139.74438700711227 43.4 35.66881188287484 139.74441221606895 43.4 35.6693625129593 139.74512187091256 43.4 35.669494901819675 139.74496774210039 43.4 35.66949787375494 139.7449642040608 43.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-28e6dcc5-a2f8-4c83-bdd6-6d50aec81bb9"/>
							<gml:surfaceMember xlink:href="#poly-12b7405b-da5d-46ef-8c5a-d4dac2a9bfb6"/>
							<gml:surfaceMember xlink:href="#poly-ff43e0f1-0c91-40d2-99f0-70941d19b058"/>
							<gml:surfaceMember xlink:href="#poly-9a5cf250-c904-48ef-bf08-68fbdc21e5a7"/>
							<gml:surfaceMember xlink:href="#poly-50a1dd7f-fc0b-4929-92aa-cfcef36f1d5f"/>
							<gml:surfaceMember xlink:href="#poly-e7647d5d-c824-4ca1-abeb-1bfd4fa3d2a5"/>
							<gml:surfaceMember xlink:href="#poly-972d6261-5b66-4d37-8b1d-99173f360145"/>
							<gml:surfaceMember xlink:href="#poly-6db6e57a-6cd0-4a7d-955c-a1cffa8e4c1b"/>
							<gml:surfaceMember xlink:href="#poly-c470ee39-b7ba-45df-b09a-c969686ac41d"/>
							<gml:surfaceMember xlink:href="#poly-271e4583-49dd-4f0f-95b5-ad9b3f8e8996"/>
							<gml:surfaceMember xlink:href="#poly-fb627aaf-87d7-499b-9def-907e6dc7b5ec"/>
							<gml:surfaceMember xlink:href="#poly-c35ec6a2-0253-436f-9596-f29f79f6ffd1"/>
							<gml:surfaceMember xlink:href="#poly-afae1cef-eeee-4ea3-a493-aaabdf2115b5"/>
							<gml:surfaceMember xlink:href="#poly-c102ad34-a940-4496-860a-4bb2b5942a35"/>
							<gml:surfaceMember xlink:href="#poly-f7a3cef9-c736-4423-b6a7-10273314b9a0"/>
							<gml:surfaceMember xlink:href="#poly-0e3cba16-ff56-43ae-b64e-2c51317475be"/>
							<gml:surfaceMember xlink:href="#poly-2055c308-a546-45c1-b580-d410e7adce1e"/>
							<gml:surfaceMember xlink:href="#poly-9de09a5d-4c15-4ef4-a57c-e116cf18a1b9"/>
							<gml:surfaceMember xlink:href="#poly-6c2d529f-f980-495e-8325-bee5c6b7e096"/>
							<gml:surfaceMember xlink:href="#poly-032c8c45-168d-4311-bdf6-d972dab59781"/>
							<gml:surfaceMember xlink:href="#poly-734a8738-fee6-4e0f-a587-b7f99537508a"/>
							<gml:surfaceMember xlink:href="#poly-6c592d0e-ab83-4acf-bc41-82d29bce42c5"/>
							<gml:surfaceMember xlink:href="#poly-c22852e7-52ec-4de4-9ad0-7b19a2680e2b"/>
							<gml:surfaceMember xlink:href="#poly-5de54855-76cb-46d5-b45d-906e4f209daf"/>
							<gml:surfaceMember xlink:href="#poly-3b3dfe12-b1f0-40a3-88f1-2d0252d4351e"/>
							<gml:surfaceMember xlink:href="#poly-6bbf935c-8831-4698-b46a-f6e0df29f878"/>
							<gml:surfaceMember xlink:href="#poly-2136db78-9ab9-47e4-b396-adb504a7a55b"/>
							<gml:surfaceMember xlink:href="#poly-35f7e778-733b-4fae-83f9-acd68dd9dee4"/>
							<gml:surfaceMember xlink:href="#poly-ac80a47e-06b8-40bf-829f-6fe86dd9895d"/>
							<gml:surfaceMember xlink:href="#poly-557d7cb9-48c7-47fa-be34-2a4d2955a9f8"/>
							<gml:surfaceMember xlink:href="#poly-5e28fc69-338e-4e6e-a2f2-40378ccd0ec2"/>
							<gml:surfaceMember xlink:href="#poly-198caf12-59e1-4e81-85c4-59a3338f9f53"/>
							<gml:surfaceMember xlink:href="#poly-01485f35-3541-4917-afa3-f28b8930c1c9"/>
							<gml:surfaceMember xlink:href="#poly-79c94d6d-7984-4417-9180-8fa0cde31e44"/>
							<gml:surfaceMember xlink:href="#poly-4291a8fe-1a08-4fc0-b6bd-09fa0a7292cb"/>
							<gml:surfaceMember xlink:href="#poly-cfa321c9-756b-4838-bb69-754c719c92ed"/>
							<gml:surfaceMember xlink:href="#poly-3890472c-05e2-43d4-a0d7-b1bc5fe97861"/>
							<gml:surfaceMember xlink:href="#poly-be596c6c-9ee9-4712-b022-9e53e09ea8a9"/>
							<gml:surfaceMember xlink:href="#poly-20d8d9f5-589f-45b8-bb5c-d2b9e2f5a369"/>
							<gml:surfaceMember xlink:href="#poly-eb39c4ce-9c79-4f53-b81f-cd73b30ce14a"/>
							<gml:surfaceMember xlink:href="#poly-36ea000b-cf16-4b56-95eb-4f7fa1b91279"/>
							<gml:surfaceMember xlink:href="#poly-ca438e6f-2156-45b3-a692-3457352b3b59"/>
							<gml:surfaceMember xlink:href="#poly-364b02c0-a754-4730-bdb2-8359ca747dfb"/>
							<gml:surfaceMember xlink:href="#poly-32bd75a0-417b-4226-ab8f-14805185da3a"/>
							<gml:surfaceMember xlink:href="#poly-d3b0ddd8-14eb-4c68-a26f-801e5a431f37"/>
							<gml:surfaceMember xlink:href="#poly-9977307a-63a9-4de1-8309-412ffd17f200"/>
							<gml:surfaceMember xlink:href="#poly-ca1c18b0-bf70-4958-a137-a952f803fba9"/>
							<gml:surfaceMember xlink:href="#poly-30b4f656-c26f-4e6e-a4bb-0273a01c0dbc"/>
							<gml:surfaceMember xlink:href="#poly-188dc5d5-c985-4eb7-a482-3cd7ea22423e"/>
							<gml:surfaceMember xlink:href="#poly-d4b69de3-7f01-4d0b-b60c-304ed365eb88"/>
							<gml:surfaceMember xlink:href="#poly-8ed2a240-1ec7-4314-bca6-cceb327bba3c"/>
							<gml:surfaceMember xlink:href="#poly-eca8359f-58d4-4c56-ae27-7667b512c70c"/>
							<gml:surfaceMember xlink:href="#poly-7ef8519b-d91b-4152-a2aa-14a7fb73d21d"/>
							<gml:surfaceMember xlink:href="#poly-e23badda-7301-40f1-9f6d-d2524be6dfd7"/>
							<gml:surfaceMember xlink:href="#poly-fccc5f03-a398-4949-8e15-4fd940abc5f3"/>
							<gml:surfaceMember xlink:href="#poly-a54eaa7e-c080-4074-8139-51218a5c0f7d"/>
							<gml:surfaceMember xlink:href="#poly-172887fe-abc9-4fa7-bd47-d76ee7491481"/>
							<gml:surfaceMember xlink:href="#poly-89e06648-11e9-458d-a860-debeaef9f4ca"/>
							<gml:surfaceMember xlink:href="#poly-7a68f98b-1034-4fb5-a871-07e0f193c369"/>
							<gml:surfaceMember xlink:href="#poly-a1e836db-add3-4ecc-8c36-b7ed17f34c69"/>
							<gml:surfaceMember xlink:href="#poly-691de7d9-c5aa-41b5-b1c4-eee6c18570bc"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ad1e2887-04a9-4343-9073-6cc6a5a161db_BuildingInstallation_1030">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2463da1f-32ca-45b2-af21-cbbf115c4b9f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66918313934248 139.74472855111821 55.682 35.66919479679546 139.7447444667073 55.682 35.66918651987763 139.74475357783473 55.682 35.66917486241771 139.7447376511999 55.682 35.66918313934248 139.74472855111821 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b2c21d1-cd37-4030-bf7f-304fa214d399">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66919479679546 139.7447444667073 53.1 35.66918313934248 139.74472855111821 53.1 35.66918678695079 139.74472453735476 53.1 35.6691984444043 139.74474045294394 53.1 35.66919479679546 139.7447444667073 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2b5d409-7cdf-4e77-801f-b68e2f52c738">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2b5d409-7cdf-4e77-801f-b68e2f52c738_0">
											<gml:posList>35.66918678695079 139.74472453735476 59.967 35.66917486241771 139.7447376511999 59.967 35.66918651987763 139.74475357783473 59.967 35.6691984444043 139.74474045294394 59.967 35.66918678695079 139.74472453735476 59.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b848d53f-0e11-4a19-970f-49ee64a5ecda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b848d53f-0e11-4a19-970f-49ee64a5ecda_0">
											<gml:posList>35.66918651987763 139.74475357783473 55.682 35.66918651987763 139.74475357783473 59.967 35.66917486241771 139.7447376511999 59.967 35.66917486241771 139.7447376511999 55.682 35.66918651987763 139.74475357783473 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdd10074-29e4-4dda-9d13-72a2a4015750">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdd10074-29e4-4dda-9d13-72a2a4015750_0">
											<gml:posList>35.66918678695079 139.74472453735476 53.1 35.66918678695079 139.74472453735476 59.967 35.6691984444043 139.74474045294394 59.967 35.6691984444043 139.74474045294394 53.1 35.66918678695079 139.74472453735476 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fda930e-0a75-4f79-aa88-cd73558b3ec7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fda930e-0a75-4f79-aa88-cd73558b3ec7_0">
											<gml:posList>35.66919479679546 139.7447444667073 55.682 35.66918313934248 139.74472855111821 55.682 35.66918313934248 139.74472855111821 53.1 35.66919479679546 139.7447444667073 53.1 35.66919479679546 139.7447444667073 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a0f37b0-9686-4143-922d-ed44ba17a9ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a0f37b0-9686-4143-922d-ed44ba17a9ec_0">
											<gml:posList>35.66918313934248 139.74472855111821 55.682 35.66917486241771 139.7447376511999 55.682 35.66917486241771 139.7447376511999 59.967 35.66918678695079 139.74472453735476 59.967 35.66918678695079 139.74472453735476 53.1 35.66918313934248 139.74472855111821 53.1 35.66918313934248 139.74472855111821 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9aff15fe-3a6e-43ce-bad4-7c43fe9d6bf0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9aff15fe-3a6e-43ce-bad4-7c43fe9d6bf0_0">
											<gml:posList>35.6691984444043 139.74474045294394 53.1 35.6691984444043 139.74474045294394 59.967 35.66918651987763 139.74475357783473 59.967 35.66918651987763 139.74475357783473 55.682 35.66919479679546 139.7447444667073 55.682 35.66919479679546 139.7447444667073 53.1 35.6691984444043 139.74474045294394 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_ad1e2887-04a9-4343-9073-6cc6a5a161db_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8eb02d0-61d5-469c-9429-791600a0d9b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8eb02d0-61d5-469c-9429-791600a0d9b0_0">
											<gml:posList>35.669124493089804 139.74454105337077 42.495 35.66902038066489 139.74440153526152 45.944 35.66902038066489 139.74440153526152 42.495 35.669124493089804 139.74454105337077 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3acc5318-5fc8-4c62-b044-80f512826f43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3acc5318-5fc8-4c62-b044-80f512826f43_0">
											<gml:posList>35.669124493089804 139.74454105337077 42.495 35.669124493089804 139.74454105337077 45.944 35.66902038066489 139.74440153526152 45.944 35.669124493089804 139.74454105337077 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d936b1d-a027-4b5b-b25c-eb583b9a9f9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d936b1d-a027-4b5b-b25c-eb583b9a9f9c_0">
											<gml:posList>35.66911925142647 139.7445469246471 42.495 35.66901514802199 139.7444074065293 45.944 35.66911925142647 139.7445469246471 45.944 35.66911925142647 139.7445469246471 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17dde491-aef1-4510-bbcd-2190f89c34ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17dde491-aef1-4510-bbcd-2190f89c34ff_0">
											<gml:posList>35.66911925142647 139.7445469246471 42.495 35.66901514802199 139.7444074065293 42.495 35.66901514802199 139.7444074065293 45.944 35.66911925142647 139.7445469246471 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5fec55f-a057-4a35-afc7-a0d86b002250">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5fec55f-a057-4a35-afc7-a0d86b002250_0">
											<gml:posList>35.669027514032464 139.74454064159912 42.495 35.66904276169332 139.7445602425442 46.083 35.669027514032464 139.74454064159912 46.083 35.669027514032464 139.74454064159912 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fddab9e7-2fd5-4ea8-bdd8-b3e5287ade5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fddab9e7-2fd5-4ea8-bdd8-b3e5287ade5e_0">
											<gml:posList>35.669027514032464 139.74454064159912 42.495 35.66904276169332 139.7445602425442 42.495 35.66904276169332 139.7445602425442 46.083 35.669027514032464 139.74454064159912 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db3ce773-1017-4014-ad97-15f82f0f4faf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db3ce773-1017-4014-ad97-15f82f0f4faf_0">
											<gml:posList>35.66903960425159 139.7445688951168 42.495 35.669021135637806 139.74454515546017 46.083 35.66903960425159 139.7445688951168 46.083 35.66903960425159 139.7445688951168 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58b93571-9058-42eb-91d5-3d2e1d3c4fb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58b93571-9058-42eb-91d5-3d2e1d3c4fb2_0">
											<gml:posList>35.66903960425159 139.7445688951168 42.495 35.669021135637806 139.74454515546017 42.495 35.669021135637806 139.74454515546017 46.083 35.66903960425159 139.7445688951168 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-636831a4-aa14-4e87-ad16-407e77983f6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-636831a4-aa14-4e87-ad16-407e77983f6e_0">
											<gml:posList>35.66902655896546 139.74439460252097 42.495 35.66902038066489 139.74440153526152 45.944 35.66902655896546 139.74439460252097 45.944 35.66902655896546 139.74439460252097 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-840a2e0a-1a0f-42e5-98fe-5104e62fcab6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-840a2e0a-1a0f-42e5-98fe-5104e62fcab6_0">
											<gml:posList>35.66902655896546 139.74439460252097 42.495 35.66902038066489 139.74440153526152 42.495 35.66902038066489 139.74440153526152 45.944 35.66902655896546 139.74439460252097 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bfa91c4-8594-4369-985e-950f29c7144f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bfa91c4-8594-4369-985e-950f29c7144f_0">
											<gml:posList>35.66901514802199 139.7444074065293 42.495 35.6690084653517 139.74441488108465 45.944 35.66901514802199 139.7444074065293 45.944 35.66901514802199 139.7444074065293 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d775ff0-5240-425a-8a27-679ec9b8f523">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d775ff0-5240-425a-8a27-679ec9b8f523_0">
											<gml:posList>35.66901514802199 139.7444074065293 42.495 35.6690084653517 139.74441488108465 42.495 35.6690084653517 139.74441488108465 45.944 35.66901514802199 139.7444074065293 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2e4525d-a21c-42a8-b7d7-b1d675a64110">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2e4525d-a21c-42a8-b7d7-b1d675a64110_0">
											<gml:posList>35.669033764182046 139.7445333442687 42.495 35.669027514032464 139.74454064159912 46.083 35.669033764182046 139.7445333442687 46.083 35.669033764182046 139.7445333442687 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a99d38db-0e4f-4753-b0c0-f7e8ae5d46b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a99d38db-0e4f-4753-b0c0-f7e8ae5d46b5_0">
											<gml:posList>35.669033764182046 139.7445333442687 42.495 35.669027514032464 139.74454064159912 42.495 35.669027514032464 139.74454064159912 46.083 35.669033764182046 139.7445333442687 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d22c0a3b-db27-4047-a3f4-6a6abdb2bea5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d22c0a3b-db27-4047-a3f4-6a6abdb2bea5_0">
											<gml:posList>35.669049011835924 139.74455293416779 42.495 35.669033764182046 139.7445333442687 46.083 35.669049011835924 139.74455293416779 46.083 35.669049011835924 139.74455293416779 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7eb22b06-3dfe-41c8-9b12-770100de5ddc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7eb22b06-3dfe-41c8-9b12-770100de5ddc_0">
											<gml:posList>35.669049011835924 139.74455293416779 42.495 35.669033764182046 139.7445333442687 42.495 35.669033764182046 139.7445333442687 46.083 35.669049011835924 139.74455293416779 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b4cb2ab-039a-4484-b2d9-34c7f6a8354c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b4cb2ab-039a-4484-b2d9-34c7f6a8354c_0">
											<gml:posList>35.66904276169332 139.7445602425442 46.083 35.669049011835924 139.74455293416779 46.083 35.669033764182046 139.7445333442687 46.083 35.66904276169332 139.7445602425442 46.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c35b0d2-0c58-4d21-9ce0-6bbba4cd3e20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c35b0d2-0c58-4d21-9ce0-6bbba4cd3e20_0">
											<gml:posList>35.669027514032464 139.74454064159912 46.083 35.66904276169332 139.7445602425442 46.083 35.669033764182046 139.7445333442687 46.083 35.669027514032464 139.74454064159912 46.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b049309e-a27c-409d-884b-8cab4e52738f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b049309e-a27c-409d-884b-8cab4e52738f_0">
											<gml:posList>35.669021135637806 139.74454515546017 42.495 35.66901552491636 139.74455171199375 46.083 35.669021135637806 139.74454515546017 46.083 35.669021135637806 139.74454515546017 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a4ef19c-b802-4688-af35-f93b999f0443">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a4ef19c-b802-4688-af35-f93b999f0443_0">
											<gml:posList>35.669021135637806 139.74454515546017 42.495 35.66901552491636 139.74455171199375 42.495 35.66901552491636 139.74455171199375 46.083 35.669021135637806 139.74454515546017 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f9b39a1-0976-421a-ade3-09bf9a1711a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f9b39a1-0976-421a-ade3-09bf9a1711a5_0">
											<gml:posList>35.66904276169332 139.7445602425442 42.495 35.669049011835924 139.74455293416779 46.083 35.66904276169332 139.7445602425442 46.083 35.66904276169332 139.7445602425442 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-caa9e77b-8285-498b-b0e0-e5c0397e3345">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-caa9e77b-8285-498b-b0e0-e5c0397e3345_0">
											<gml:posList>35.66904276169332 139.7445602425442 42.495 35.669049011835924 139.74455293416779 42.495 35.669049011835924 139.74455293416779 46.083 35.66904276169332 139.7445602425442 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fab42a56-e63d-4cec-ba5d-c7a97762d6b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fab42a56-e63d-4cec-ba5d-c7a97762d6b2_0">
											<gml:posList>35.66901552491636 139.74455171199375 46.083 35.66903960425159 139.7445688951168 46.083 35.669021135637806 139.74454515546017 46.083 35.66901552491636 139.74455171199375 46.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-639a7800-95ca-4e25-b125-c941c04f8dc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-639a7800-95ca-4e25-b125-c941c04f8dc7_0">
											<gml:posList>35.66901552491636 139.74455171199375 46.083 35.66903399352887 139.74457545165023 46.083 35.66903960425159 139.7445688951168 46.083 35.66901552491636 139.74455171199375 46.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecb21d76-f752-41d2-bdd5-f7ca6b459441">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ecb21d76-f752-41d2-bdd5-f7ca6b459441_0">
											<gml:posList>35.66901552491636 139.74455171199375 42.495 35.66903399352887 139.74457545165023 46.083 35.66901552491636 139.74455171199375 46.083 35.66901552491636 139.74455171199375 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bed66dc-f53d-4e7f-99a9-f63cd81e5138">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bed66dc-f53d-4e7f-99a9-f63cd81e5138_0">
											<gml:posList>35.66901552491636 139.74455171199375 42.495 35.66903399352887 139.74457545165023 42.495 35.66903399352887 139.74457545165023 46.083 35.66901552491636 139.74455171199375 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33ab5701-5c3e-42e2-9bc8-a15857aabc58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33ab5701-5c3e-42e2-9bc8-a15857aabc58_0">
											<gml:posList>35.66903399352887 139.74457545165023 42.495 35.66903960425159 139.7445688951168 46.083 35.66903399352887 139.74457545165023 46.083 35.66903399352887 139.74457545165023 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fee769b-0330-42f9-bf47-1de5ea9aaa20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fee769b-0330-42f9-bf47-1de5ea9aaa20_0">
											<gml:posList>35.66903399352887 139.74457545165023 42.495 35.66903960425159 139.7445688951168 42.495 35.66903960425159 139.7445688951168 46.083 35.66903399352887 139.74457545165023 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6389770-ed47-467b-aa78-8d1f347ae367">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6389770-ed47-467b-aa78-8d1f347ae367_0">
											<gml:posList>35.6690662048294 139.7446192468343 42.495 35.66905285022339 139.74459986469887 47.204 35.66905285022339 139.74459986469887 42.495 35.6690662048294 139.7446192468343 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80e6d2ac-c93c-4639-8516-cd0ee603d74a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80e6d2ac-c93c-4639-8516-cd0ee603d74a_0">
											<gml:posList>35.6690662048294 139.7446192468343 42.495 35.6690662048294 139.7446192468343 47.204 35.66905285022339 139.74459986469887 47.204 35.6690662048294 139.7446192468343 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d08282e0-c0a6-41ac-83fa-ce17ec550a44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d08282e0-c0a6-41ac-83fa-ce17ec550a44_0">
											<gml:posList>35.66911257776952 139.74455441023667 42.495 35.6690084653517 139.74441488108465 45.944 35.6690084653517 139.74441488108465 42.495 35.66911257776952 139.74455441023667 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38ef8eca-d285-432d-9553-df9c42d63070">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38ef8eca-d285-432d-9553-df9c42d63070_0">
											<gml:posList>35.66911257776952 139.74455441023667 42.495 35.66911257776952 139.74455441023667 45.944 35.6690084653517 139.74441488108465 45.944 35.66911257776952 139.74455441023667 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b34c4482-d5c6-4cfb-99c6-b57eabb65602">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b34c4482-d5c6-4cfb-99c6-b57eabb65602_0">
											<gml:posList>35.66911257776952 139.74455441023667 45.944 35.66911925142647 139.7445469246471 45.944 35.66901514802199 139.7444074065293 45.944 35.66911257776952 139.74455441023667 45.944</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c744f5a-9e96-48cd-856a-c8b76514abe7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c744f5a-9e96-48cd-856a-c8b76514abe7_0">
											<gml:posList>35.6690084653517 139.74441488108465 45.944 35.66911257776952 139.74455441023667 45.944 35.66901514802199 139.7444074065293 45.944 35.6690084653517 139.74441488108465 45.944</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d447ac7-e52d-4f7e-8009-2d9b11d160f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d447ac7-e52d-4f7e-8009-2d9b11d160f0_0">
											<gml:posList>35.66907723179301 139.74457461951536 42.495 35.66905285022339 139.74459986469887 47.204 35.66907723179301 139.74457461951536 47.204 35.66907723179301 139.74457461951536 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97e3e1f3-28e7-4dd1-bd6d-42e36ebb2fb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97e3e1f3-28e7-4dd1-bd6d-42e36ebb2fb3_0">
											<gml:posList>35.66907723179301 139.74457461951536 42.495 35.66905285022339 139.74459986469887 42.495 35.66905285022339 139.74459986469887 47.204 35.66907723179301 139.74457461951536 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-307940b3-84f8-4059-b662-91af9aa1ba43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-307940b3-84f8-4059-b662-91af9aa1ba43_0">
											<gml:posList>35.66909058640304 139.74459400165247 47.204 35.66907723179301 139.74457461951536 47.204 35.66905285022339 139.74459986469887 47.204 35.66909058640304 139.74459400165247 47.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81bfd9d6-d81f-42bf-8bdc-c573cf08a2d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81bfd9d6-d81f-42bf-8bdc-c573cf08a2d8_0">
											<gml:posList>35.6690662048294 139.7446192468343 47.204 35.66909058640304 139.74459400165247 47.204 35.66905285022339 139.74459986469887 47.204 35.6690662048294 139.7446192468343 47.204</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fb64ce0-b7c1-4cd9-b56c-a6516059f0b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fb64ce0-b7c1-4cd9-b56c-a6516059f0b7_0">
											<gml:posList>35.66902038066489 139.74440153526152 45.944 35.66913067139831 139.74453412063195 45.944 35.66902655896546 139.74439460252097 45.944 35.66902038066489 139.74440153526152 45.944</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b9836da-0408-4a41-9f9c-db981cd54ea1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b9836da-0408-4a41-9f9c-db981cd54ea1_0">
											<gml:posList>35.66902038066489 139.74440153526152 45.944 35.669124493089804 139.74454105337077 45.944 35.66913067139831 139.74453412063195 45.944 35.66902038066489 139.74440153526152 45.944</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02a2bea0-0148-40d0-beb2-649a7c5758fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02a2bea0-0148-40d0-beb2-649a7c5758fa_0">
											<gml:posList>35.6690662048294 139.7446192468343 42.495 35.66909058640304 139.74459400165247 47.204 35.6690662048294 139.7446192468343 47.204 35.6690662048294 139.7446192468343 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6af03edc-7132-4d99-9925-0d8e5cdb1a36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6af03edc-7132-4d99-9925-0d8e5cdb1a36_0">
											<gml:posList>35.6690662048294 139.7446192468343 42.495 35.66909058640304 139.74459400165247 42.495 35.66909058640304 139.74459400165247 47.204 35.6690662048294 139.7446192468343 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d68851ab-8b1b-4ba8-a50c-b6e3ad6286af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d68851ab-8b1b-4ba8-a50c-b6e3ad6286af_0">
											<gml:posList>35.66913067139831 139.74453412063195 42.495 35.66902655896546 139.74439460252097 45.944 35.66913067139831 139.74453412063195 45.944 35.66913067139831 139.74453412063195 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0df3916e-0677-4c05-9dfb-52a1e6a02168">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0df3916e-0677-4c05-9dfb-52a1e6a02168_0">
											<gml:posList>35.66913067139831 139.74453412063195 42.495 35.66902655896546 139.74439460252097 42.495 35.66902655896546 139.74439460252097 45.944 35.66913067139831 139.74453412063195 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7eaced5b-a0d5-4fab-b5b8-a24992a7e111">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7eaced5b-a0d5-4fab-b5b8-a24992a7e111_0">
											<gml:posList>35.66909058640304 139.74459400165247 42.495 35.66907723179301 139.74457461951536 47.204 35.66909058640304 139.74459400165247 47.204 35.66909058640304 139.74459400165247 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f64b4c1a-3f68-455f-8c60-6e10155e8668">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f64b4c1a-3f68-455f-8c60-6e10155e8668_0">
											<gml:posList>35.66909058640304 139.74459400165247 42.495 35.66907723179301 139.74457461951536 42.495 35.66907723179301 139.74457461951536 47.204 35.66909058640304 139.74459400165247 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d34468d-a2dc-48e6-8b3a-3b53cee281a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d34468d-a2dc-48e6-8b3a-3b53cee281a3_0">
											<gml:posList>35.66911257776952 139.74455441023667 42.495 35.66911925142647 139.7445469246471 45.944 35.66911257776952 139.74455441023667 45.944 35.66911257776952 139.74455441023667 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09ca9650-3d93-4d55-b076-ffe5c92c7e2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09ca9650-3d93-4d55-b076-ffe5c92c7e2f_0">
											<gml:posList>35.66911257776952 139.74455441023667 42.495 35.66911925142647 139.7445469246471 42.495 35.66911925142647 139.7445469246471 45.944 35.66911257776952 139.74455441023667 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f6b0da6-ee44-45a3-8621-5f4d7087cd27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f6b0da6-ee44-45a3-8621-5f4d7087cd27_0">
											<gml:posList>35.669124493089804 139.74454105337077 42.495 35.66913067139831 139.74453412063195 45.944 35.669124493089804 139.74454105337077 45.944 35.669124493089804 139.74454105337077 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-958e6203-5e54-4bed-8d65-6515cf9e2bdb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-958e6203-5e54-4bed-8d65-6515cf9e2bdb_0">
											<gml:posList>35.669124493089804 139.74454105337077 42.495 35.66913067139831 139.74453412063195 42.495 35.66913067139831 139.74453412063195 45.944 35.669124493089804 139.74454105337077 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e9c94c7-601d-4399-b981-4b1e66273e3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e9c94c7-601d-4399-b981-4b1e66273e3e_0">
											<gml:posList>35.66916603370436 139.74462166593688 53.1 35.66913893342948 139.74465159768286 56.996 35.66916603370436 139.74462166593688 56.996 35.66916603370436 139.74462166593688 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b72e3a8-1696-4a71-9cde-01e2e98787fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b72e3a8-1696-4a71-9cde-01e2e98787fe_0">
											<gml:posList>35.66916603370436 139.74462166593688 53.1 35.66913893342948 139.74465159768286 53.1 35.66913893342948 139.74465159768286 56.996 35.66916603370436 139.74462166593688 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e70066b-b789-4989-8dd8-c8609ea13a70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e70066b-b789-4989-8dd8-c8609ea13a70_0">
											<gml:posList>35.66916611902341 139.74468856097926 53.1 35.66913893342948 139.74465159768286 56.996 35.66913893342948 139.74465159768286 53.1 35.66916611902341 139.74468856097926 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2761337-52e4-4782-b40e-2116162cf948">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2761337-52e4-4782-b40e-2116162cf948_0">
											<gml:posList>35.66916611902341 139.74468856097926 53.1 35.66916611902341 139.74468856097926 56.996 35.66913893342948 139.74465159768286 56.996 35.66916611902341 139.74468856097926 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6454832-e995-4da6-932f-29c1feba95a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6454832-e995-4da6-932f-29c1feba95a6_0">
											<gml:posList>35.66916611902341 139.74468856097926 56.996 35.66919321929923 139.74465861818948 56.996 35.66916603370436 139.74462166593688 56.996 35.66916611902341 139.74468856097926 56.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a66fb4c8-0c4b-4bb6-8c00-067a4f12d585">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a66fb4c8-0c4b-4bb6-8c00-067a4f12d585_0">
											<gml:posList>35.66913893342948 139.74465159768286 56.996 35.66916611902341 139.74468856097926 56.996 35.66916603370436 139.74462166593688 56.996 35.66913893342948 139.74465159768286 56.996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-879be248-e811-47eb-9069-d219c1e6badd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-879be248-e811-47eb-9069-d219c1e6badd_0">
											<gml:posList>35.66917311018656 139.74472055378317 55.682 35.66918082468444 139.74473109427782 58.422 35.66917311018656 139.74472055378317 58.422 35.66917311018656 139.74472055378317 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81ed25bb-65cf-402e-b72e-4aef9f45a7aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81ed25bb-65cf-402e-b72e-4aef9f45a7aa_0">
											<gml:posList>35.66917311018656 139.74472055378317 55.682 35.66918082468444 139.74473109427782 55.682 35.66918082468444 139.74473109427782 58.422 35.66917311018656 139.74472055378317 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4302c3c8-419f-49fd-b206-6f3d3fb41836">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4302c3c8-419f-49fd-b206-6f3d3fb41836_0">
											<gml:posList>35.669175415830665 139.74471801063348 53.1 35.669175415830665 139.74471801063348 55.682 35.66918102684555 139.74471184071143 53.1 35.669175415830665 139.74471801063348 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd4b8c19-94bb-48d2-b6bb-1c0935173c63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd4b8c19-94bb-48d2-b6bb-1c0935173c63_0">
											<gml:posList>35.66918102684555 139.74471184071143 53.1 35.669175415830665 139.74471801063348 55.682 35.66918102684555 139.74471184071143 58.422 35.66918102684555 139.74471184071143 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-963d8263-f6b8-4416-b2fa-8f9e2070cf61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-963d8263-f6b8-4416-b2fa-8f9e2070cf61_0">
											<gml:posList>35.66918102684555 139.74471184071143 58.422 35.669175415830665 139.74471801063348 55.682 35.66917311018656 139.74472055378317 58.422 35.66918102684555 139.74471184071143 58.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70c9b9a2-a77d-4438-8324-9bbfb3ccabfe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70c9b9a2-a77d-4438-8324-9bbfb3ccabfe_0">
											<gml:posList>35.669175415830665 139.74471801063348 55.682 35.66917311018656 139.74472055378317 55.682 35.66917311018656 139.74472055378317 58.422 35.669175415830665 139.74471801063348 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7341f64-86fe-4092-8dd2-18512c3ff16d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7341f64-86fe-4092-8dd2-18512c3ff16d_0">
											<gml:posList>35.66918313934248 139.74472855111821 55.682 35.669175415830665 139.74471801063348 53.1 35.66918313934248 139.74472855111821 53.1 35.66918313934248 139.74472855111821 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61100511-b1ff-471a-9b59-c120ca01202f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61100511-b1ff-471a-9b59-c120ca01202f_0">
											<gml:posList>35.66918313934248 139.74472855111821 55.682 35.669175415830665 139.74471801063348 55.682 35.669175415830665 139.74471801063348 53.1 35.66918313934248 139.74472855111821 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c8e21a8-343a-4e51-916c-33146cc26dec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c8e21a8-343a-4e51-916c-33146cc26dec_0">
											<gml:posList>35.66919321929923 139.74465861818948 53.1 35.66916603370436 139.74462166593688 56.996 35.66919321929923 139.74465861818948 56.996 35.66919321929923 139.74465861818948 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d742aee0-8eb2-4a03-8dc8-d52c315d85b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d742aee0-8eb2-4a03-8dc8-d52c315d85b7_0">
											<gml:posList>35.66919321929923 139.74465861818948 53.1 35.66916603370436 139.74462166593688 53.1 35.66916603370436 139.74462166593688 56.996 35.66919321929923 139.74465861818948 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2420d39e-b7d7-4f42-ac5e-40a332a5783d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2420d39e-b7d7-4f42-ac5e-40a332a5783d_0">
											<gml:posList>35.66916611902341 139.74468856097926 53.1 35.66919321929923 139.74465861818948 56.996 35.66916611902341 139.74468856097926 56.996 35.66916611902341 139.74468856097926 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44c705ff-8879-4b58-bb8e-c6705a5bfbb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44c705ff-8879-4b58-bb8e-c6705a5bfbb9_0">
											<gml:posList>35.66916611902341 139.74468856097926 53.1 35.66919321929923 139.74465861818948 53.1 35.66919321929923 139.74465861818948 56.996 35.66916611902341 139.74468856097926 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d403e309-71d7-441e-b99f-2e893030f4b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d403e309-71d7-441e-b99f-2e893030f4b1_0">
											<gml:posList>35.66917311018656 139.74472055378317 58.422 35.66918082468444 139.74473109427782 58.422 35.669188750357904 139.7447223811963 58.422 35.66917311018656 139.74472055378317 58.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21de8ea0-e503-406c-8359-3f703fa04fb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21de8ea0-e503-406c-8359-3f703fa04fb7_0">
											<gml:posList>35.66918102684555 139.74471184071143 58.422 35.66917311018656 139.74472055378317 58.422 35.669188750357904 139.7447223811963 58.422 35.66918102684555 139.74471184071143 58.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-730dde4c-0f3f-4bb5-9159-b02adfc249e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-730dde4c-0f3f-4bb5-9159-b02adfc249e8_0">
											<gml:posList>35.66918313934248 139.74472855111821 53.1 35.669188750357904 139.7447223811963 53.1 35.66918313934248 139.74472855111821 55.682 35.66918313934248 139.74472855111821 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83b0d390-a39c-4878-84b3-a539348bcf52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83b0d390-a39c-4878-84b3-a539348bcf52_0">
											<gml:posList>35.66918082468444 139.74473109427782 55.682 35.66918313934248 139.74472855111821 55.682 35.66918082468444 139.74473109427782 58.422 35.66918082468444 139.74473109427782 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94cb1708-6b07-4060-b20d-db371d677771">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94cb1708-6b07-4060-b20d-db371d677771_0">
											<gml:posList>35.66918082468444 139.74473109427782 58.422 35.66918313934248 139.74472855111821 55.682 35.669188750357904 139.7447223811963 58.422 35.66918082468444 139.74473109427782 58.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37455f12-042f-4ec5-a420-ac5f77cd9aa9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37455f12-042f-4ec5-a420-ac5f77cd9aa9_0">
											<gml:posList>35.66918313934248 139.74472855111821 55.682 35.669188750357904 139.7447223811963 53.1 35.669188750357904 139.7447223811963 58.422 35.66918313934248 139.74472855111821 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71266693-1b4e-4909-8ed4-def729e65114">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71266693-1b4e-4909-8ed4-def729e65114_0">
											<gml:posList>35.669188750357904 139.7447223811963 53.1 35.66918102684555 139.74471184071143 58.422 35.669188750357904 139.7447223811963 58.422 35.669188750357904 139.7447223811963 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbb9db69-9242-4bd4-af66-a541b1375099">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbb9db69-9242-4bd4-af66-a541b1375099_0">
											<gml:posList>35.669188750357904 139.7447223811963 53.1 35.66918102684555 139.74471184071143 53.1 35.66918102684555 139.74471184071143 58.422 35.669188750357904 139.7447223811963 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-341556cd-18f9-4119-8cd2-448ec7bd8135">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-341556cd-18f9-4119-8cd2-448ec7bd8135_0">
											<gml:posList>35.66922165766352 139.744781154267 55.682 35.66921841847857 139.74477672835835 53.1 35.66922165766352 139.744781154267 53.1 35.66922165766352 139.744781154267 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0005efb4-1295-4f97-97b7-5e547f2bab1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0005efb4-1295-4f97-97b7-5e547f2bab1b_0">
											<gml:posList>35.66922165766352 139.744781154267 55.682 35.66921841847857 139.74477672835835 55.682 35.66921841847857 139.74477672835835 53.1 35.66922165766352 139.744781154267 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df361a53-b659-4dc9-9772-0c385737b519">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df361a53-b659-4dc9-9772-0c385737b519_0">
											<gml:posList>35.66921841847857 139.74477672835835 55.682 35.66925400296023 139.74473760793822 53.1 35.66921841847857 139.74477672835835 53.1 35.66921841847857 139.74477672835835 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bf80b47-eacf-497b-868c-41005ff79779">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bf80b47-eacf-497b-868c-41005ff79779_0">
											<gml:posList>35.66921841847857 139.74477672835835 55.682 35.66925400296023 139.74473760793822 55.682 35.66925400296023 139.74473760793822 53.1 35.66921841847857 139.74477672835835 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-458b16ac-4ae5-4b82-94e9-3d4063186942">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-458b16ac-4ae5-4b82-94e9-3d4063186942_0">
											<gml:posList>35.6692572421466 139.74474203384727 55.682 35.66925400296023 139.74473760793822 55.682 35.66921841847857 139.74477672835835 55.682 35.6692572421466 139.74474203384727 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a5bcbdb-8a99-47a1-9850-21a06f8bcedf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a5bcbdb-8a99-47a1-9850-21a06f8bcedf_0">
											<gml:posList>35.66922165766352 139.744781154267 55.682 35.6692572421466 139.74474203384727 55.682 35.66921841847857 139.74477672835835 55.682 35.66922165766352 139.744781154267 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cdee4ee-a6cb-409f-807c-dd9438de0d40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cdee4ee-a6cb-409f-807c-dd9438de0d40_0">
											<gml:posList>35.66922165766352 139.744781154267 53.1 35.6692572421466 139.74474203384727 55.682 35.66922165766352 139.744781154267 55.682 35.66922165766352 139.744781154267 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-071e1b5a-ec66-4b32-8a50-599fe683cd17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-071e1b5a-ec66-4b32-8a50-599fe683cd17_0">
											<gml:posList>35.66922165766352 139.744781154267 53.1 35.6692572421466 139.74474203384727 53.1 35.6692572421466 139.74474203384727 55.682 35.66922165766352 139.744781154267 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c03bb164-c765-4dc7-8c47-3735dc64b27c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c03bb164-c765-4dc7-8c47-3735dc64b27c_0">
											<gml:posList>35.6692572421466 139.74474203384727 55.682 35.66925400296023 139.74473760793822 53.1 35.66925400296023 139.74473760793822 55.682 35.6692572421466 139.74474203384727 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4774c3a0-3b29-4dc2-bbfc-5d85a0a6a215">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4774c3a0-3b29-4dc2-bbfc-5d85a0a6a215_0">
											<gml:posList>35.6692572421466 139.74474203384727 55.682 35.6692572421466 139.74474203384727 53.1 35.66925400296023 139.74473760793822 53.1 35.6692572421466 139.74474203384727 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36397d1b-ae2c-4a98-9407-8c2e9bbe5e13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36397d1b-ae2c-4a98-9407-8c2e9bbe5e13_0">
											<gml:posList>35.66929993287519 139.74457297013362 42.495 35.669313072311596 139.74459392111038 45.036 35.66929993287519 139.74457297013362 45.036 35.66929993287519 139.74457297013362 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39e2af92-aaca-4221-8c83-3e18fb1e2f13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39e2af92-aaca-4221-8c83-3e18fb1e2f13_0">
											<gml:posList>35.66929993287519 139.74457297013362 42.495 35.669313072311596 139.74459392111038 42.495 35.669313072311596 139.74459392111038 45.036 35.66929993287519 139.74457297013362 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88f1c0b5-82f4-4cb0-a4bb-2d9ded29340e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88f1c0b5-82f4-4cb0-a4bb-2d9ded29340e_0">
											<gml:posList>35.669313579207 139.74456011944386 43.3 35.66931284959199 139.74456079406457 43.3 35.669313579207 139.74456011944386 45.036 35.669313579207 139.74456011944386 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a01685e-f52b-4914-ae12-717635a67023">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a01685e-f52b-4914-ae12-717635a67023_0">
											<gml:posList>35.669313579207 139.74456011944386 45.036 35.66931284959199 139.74456079406457 43.3 35.66929993287519 139.74457297013362 45.036 35.669313579207 139.74456011944386 45.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7ac4f9f-d1fa-48de-acd1-b62abba93927">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7ac4f9f-d1fa-48de-acd1-b62abba93927_0">
											<gml:posList>35.66929993287519 139.74457297013362 45.036 35.66931284959199 139.74456079406457 43.3 35.66929993287519 139.74457297013362 42.495 35.66929993287519 139.74457297013362 45.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4fce10e-6c9a-409f-aeda-90e5ea95cc0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4fce10e-6c9a-409f-aeda-90e5ea95cc0d_0">
											<gml:posList>35.66931284959199 139.74456079406457 43.3 35.66931284959199 139.74456079406457 42.495 35.66929993287519 139.74457297013362 42.495 35.66931284959199 139.74456079406457 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac1ea7a1-cdf3-48bf-964a-2bd73485a3f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac1ea7a1-cdf3-48bf-964a-2bd73485a3f4_0">
											<gml:posList>35.669313579207 139.74456011944386 45.036 35.66929993287519 139.74457297013362 45.036 35.669313072311596 139.74459392111038 45.036 35.669313579207 139.74456011944386 45.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47f66783-8259-42ec-9f7d-28ab0287eeb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47f66783-8259-42ec-9f7d-28ab0287eeb9_0">
											<gml:posList>35.66932671864561 139.7445810704221 45.036 35.669313579207 139.74456011944386 45.036 35.669313072311596 139.74459392111038 45.036 35.66932671864561 139.7445810704221 45.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80e3dd52-4d37-4835-9345-f4e5f09dcff7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80e3dd52-4d37-4835-9345-f4e5f09dcff7_0">
											<gml:posList>35.66931284959199 139.74456079406457 43.3 35.669326673609554 139.7445811146564 42.495 35.66931284959199 139.74456079406457 42.495 35.66931284959199 139.74456079406457 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e136db1-eb76-405c-863b-fa7f833a8f0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e136db1-eb76-405c-863b-fa7f833a8f0b_0">
											<gml:posList>35.66931284959199 139.74456079406457 43.3 35.669326673609554 139.7445811146564 43.3 35.669326673609554 139.7445811146564 42.495 35.66931284959199 139.74456079406457 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bbe6993-edc1-48ad-afb4-c5a6aed6c68c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bbe6993-edc1-48ad-afb4-c5a6aed6c68c_0">
											<gml:posList>35.66932671864561 139.7445810704221 43.3 35.669313579207 139.74456011944386 45.036 35.66932671864561 139.7445810704221 45.036 35.66932671864561 139.7445810704221 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf5ca42d-f38a-4dd9-b5ee-c224be64bf16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf5ca42d-f38a-4dd9-b5ee-c224be64bf16_0">
											<gml:posList>35.66932671864561 139.7445810704221 43.3 35.669313579207 139.74456011944386 43.3 35.669313579207 139.74456011944386 45.036 35.66932671864561 139.7445810704221 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e7a38b2-56a8-4f2c-808a-f5d376a62445">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e7a38b2-56a8-4f2c-808a-f5d376a62445_0">
											<gml:posList>35.669326673609554 139.7445811146564 42.495 35.66932671864561 139.7445810704221 43.3 35.669313072311596 139.74459392111038 42.495 35.669326673609554 139.7445811146564 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e97e60f3-f7d5-428c-88ae-d9fc3a043c7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e97e60f3-f7d5-428c-88ae-d9fc3a043c7d_0">
											<gml:posList>35.66932671864561 139.7445810704221 43.3 35.66932671864561 139.7445810704221 45.036 35.669313072311596 139.74459392111038 45.036 35.66932671864561 139.7445810704221 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-482afd3f-638f-4c95-b238-c29e02e5ce81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-482afd3f-638f-4c95-b238-c29e02e5ce81_0">
											<gml:posList>35.669313072311596 139.74459392111038 42.495 35.66932671864561 139.7445810704221 43.3 35.669313072311596 139.74459392111038 45.036 35.669313072311596 139.74459392111038 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c82c68aa-12dc-41b4-b67b-bdfc2c3eba22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669313579207 139.74456011944386 43.3 35.669326673609554 139.7445811146564 43.3 35.66931284959199 139.74456079406457 43.3 35.669313579207 139.74456011944386 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b09ee479-dd45-4909-aa51-cc6122ae1ffe">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66902038066489 139.74440153526152 42.495 35.66913067139831 139.74453412063195 42.495 35.669124493089804 139.74454105337077 42.495 35.66902038066489 139.74440153526152 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39311ffa-f40d-4d24-ad86-53df14652665">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66902038066489 139.74440153526152 42.495 35.66902655896546 139.74439460252097 42.495 35.66913067139831 139.74453412063195 42.495 35.66902038066489 139.74440153526152 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e1b0f58-706c-4d3c-8435-e0d81a7b39de">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66901514802199 139.7444074065293 42.495 35.66911925142647 139.7445469246471 42.495 35.66911257776952 139.74455441023667 42.495 35.66901514802199 139.7444074065293 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c50527e-4632-441a-a757-3a5a3ae1035b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690084653517 139.74441488108465 42.495 35.66901514802199 139.7444074065293 42.495 35.66911257776952 139.74455441023667 42.495 35.6690084653517 139.74441488108465 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1cd01b9-881c-466e-8f76-7ce06f12e9f7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66904276169332 139.7445602425442 42.495 35.669027514032464 139.74454064159912 42.495 35.669033764182046 139.7445333442687 42.495 35.66904276169332 139.7445602425442 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3ed4014-2a35-462a-a011-54e475e611b7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669049011835924 139.74455293416779 42.495 35.66904276169332 139.7445602425442 42.495 35.669033764182046 139.7445333442687 42.495 35.669049011835924 139.74455293416779 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cba45bfe-0a84-47a9-9601-6fcaf578b943">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903960425159 139.7445688951168 42.495 35.66901552491636 139.74455171199375 42.495 35.669021135637806 139.74454515546017 42.495 35.66903960425159 139.7445688951168 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-377caa08-12a8-4a39-953a-ce9367156452">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903960425159 139.7445688951168 42.495 35.66903399352887 139.74457545165023 42.495 35.66901552491636 139.74455171199375 42.495 35.66903960425159 139.7445688951168 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c3562f4-6b3f-4f85-9d7a-a224ab06aa3c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66931284959199 139.74456079406457 42.495 35.669313072311596 139.74459392111038 42.495 35.66929993287519 139.74457297013362 42.495 35.66931284959199 139.74456079406457 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-316228a3-0c94-4025-9823-0ba59559ba23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66931284959199 139.74456079406457 42.495 35.669326673609554 139.7445811146564 42.495 35.669313072311596 139.74459392111038 42.495 35.66931284959199 139.74456079406457 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc6eeecf-6090-48f3-9e62-314856517d42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66905285022339 139.74459986469887 42.495 35.66907723179301 139.74457461951536 42.495 35.66909058640304 139.74459400165247 42.495 35.66905285022339 139.74459986469887 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc755d8c-49fe-4666-ac73-d1beaae987f8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690662048294 139.7446192468343 42.495 35.66905285022339 139.74459986469887 42.495 35.66909058640304 139.74459400165247 42.495 35.6690662048294 139.7446192468343 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73283024-6a47-4d86-a2fa-e71447c88c9a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66916603370436 139.74462166593688 53.1 35.66919321929923 139.74465861818948 53.1 35.66916611902341 139.74468856097926 53.1 35.66916603370436 139.74462166593688 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ca0d0b6-0ee1-40b6-a843-819e22eddf77">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913893342948 139.74465159768286 53.1 35.66916603370436 139.74462166593688 53.1 35.66916611902341 139.74468856097926 53.1 35.66913893342948 139.74465159768286 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-882e15e5-72aa-49c3-bc39-6e3d81f6664e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66918313934248 139.74472855111821 53.1 35.66918102684555 139.74471184071143 53.1 35.669188750357904 139.7447223811963 53.1 35.66918313934248 139.74472855111821 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9feb834-b149-46a1-a651-41ec7c684c12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66918313934248 139.74472855111821 53.1 35.669175415830665 139.74471801063348 53.1 35.66918102684555 139.74471184071143 53.1 35.66918313934248 139.74472855111821 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6d937e7-2c6c-40b2-9012-4213d46f2431">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66917311018656 139.74472055378317 55.682 35.66918313934248 139.74472855111821 55.682 35.66918082468444 139.74473109427782 55.682 35.66917311018656 139.74472055378317 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b2126f7-c559-481f-914f-ef835bb4f0b3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66917311018656 139.74472055378317 55.682 35.669175415830665 139.74471801063348 55.682 35.66918313934248 139.74472855111821 55.682 35.66917311018656 139.74472055378317 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3385b247-daf3-4819-bf38-d7c0929ad300">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6692572421466 139.74474203384727 53.1 35.66922165766352 139.744781154267 53.1 35.66921841847857 139.74477672835835 53.1 35.6692572421466 139.74474203384727 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f918ff2d-cd81-4710-b140-93e26e035df8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925400296023 139.74473760793822 53.1 35.6692572421466 139.74474203384727 53.1 35.66921841847857 139.74477672835835 53.1 35.66925400296023 139.74473760793822 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-28e6dcc5-a2f8-4c83-bdd6-6d50aec81bb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28e6dcc5-a2f8-4c83-bdd6-6d50aec81bb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28e6dcc5-a2f8-4c83-bdd6-6d50aec81bb9">
											<gml:posList>35.6688334972167 139.74438700711227 6.5 35.66879686655801 139.7443397706883 6.5 35.66897329342897 139.7441341180453 6.5 35.66901461580248 139.74418742460185 6.5 35.66904595641238 139.74415071678501 6.5 35.6695547019465 139.74489819593597 6.5 35.66949787375494 139.7449642040608 6.5 35.66949490181966 139.74496774210039 6.5 35.66936251295928 139.74512187091256 6.5 35.66881188287481 139.74441221606892 6.5 35.6688334972167 139.74438700711227 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-12b7405b-da5d-46ef-8c5a-d4dac2a9bfb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12b7405b-da5d-46ef-8c5a-d4dac2a9bfb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12b7405b-da5d-46ef-8c5a-d4dac2a9bfb6">
											<gml:posList>35.66884869079611 139.74440657490257 48.02 35.668848777784504 139.74440231103125 48.02 35.668800336916014 139.74433986625095 48.02 35.66879686655801 139.7443397706883 48.02 35.66884869079611 139.74440657490257 48.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ff43e0f1-0c91-40d2-99f0-70941d19b058">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff43e0f1-0c91-40d2-99f0-70941d19b058">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff43e0f1-0c91-40d2-99f0-70941d19b058">
											<gml:posList>35.66882513336204 139.744412621124 43.3 35.66883995719634 139.74439532866612 43.3 35.6688334972167 139.74438700711227 43.3 35.66881188287481 139.74441221606892 43.3 35.66882513336204 139.744412621124 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a5cf250-c904-48ef-bf08-68fbdc21e5a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a5cf250-c904-48ef-bf08-68fbdc21e5a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a5cf250-c904-48ef-bf08-68fbdc21e5a7">
											<gml:posList>35.66879686655801 139.7443397706883 48.02 35.668800336916014 139.74433986625095 48.02 35.66897319742819 139.74413837088753 48.02 35.66897329342897 139.7441341180453 48.02 35.66879686655801 139.7443397706883 48.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50a1dd7f-fc0b-4929-92aa-cfcef36f1d5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50a1dd7f-fc0b-4929-92aa-cfcef36f1d5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50a1dd7f-fc0b-4929-92aa-cfcef36f1d5f">
											<gml:posList>35.668848777784504 139.74440231103125 48.308 35.669021656329136 139.74420068310744 48.308 35.66901283262217 139.74418950324582 48.308 35.66897319742819 139.74413837088753 48.308 35.668800336916014 139.74433986625095 48.308 35.668848777784504 139.74440231103125 48.308</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e7647d5d-c824-4ca1-abeb-1bfd4fa3d2a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7647d5d-c824-4ca1-abeb-1bfd4fa3d2a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7647d5d-c824-4ca1-abeb-1bfd4fa3d2a5">
											<gml:posList>35.66902515372009 139.7442007675882 48.02 35.669021656329136 139.74420068310744 48.02 35.668848777784504 139.74440231103125 48.02 35.66884869079611 139.74440657490257 48.02 35.66902515372009 139.7442007675882 48.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-972d6261-5b66-4d37-8b1d-99173f360145">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-972d6261-5b66-4d37-8b1d-99173f360145">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-972d6261-5b66-4d37-8b1d-99173f360145">
											<gml:posList>35.66901461580248 139.74418742460185 48.02 35.66897329342897 139.7441341180453 48.02 35.66897319742819 139.74413837088753 48.02 35.66901283262217 139.74418950324582 48.02 35.66901461580248 139.74418742460185 48.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6db6e57a-6cd0-4a7d-955c-a1cffa8e4c1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6db6e57a-6cd0-4a7d-955c-a1cffa8e4c1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6db6e57a-6cd0-4a7d-955c-a1cffa8e4c1b">
											<gml:posList>35.66901461580248 139.74418742460185 48.02 35.66901283262217 139.74418950324582 48.02 35.669021656329136 139.74420068310744 48.02 35.66902515372009 139.7442007675882 48.02 35.66901461580248 139.74418742460185 48.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c470ee39-b7ba-45df-b09a-c969686ac41d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c470ee39-b7ba-45df-b09a-c969686ac41d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c470ee39-b7ba-45df-b09a-c969686ac41d">
											<gml:posList>35.669045184660405 139.74416751872482 43.3 35.66904595641238 139.74415071678501 43.3 35.66901461580248 139.74418742460185 43.3 35.669021220039866 139.74419577913622 43.3 35.669045184660405 139.74416751872482 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-271e4583-49dd-4f0f-95b5-ad9b3f8e8996">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-271e4583-49dd-4f0f-95b5-ad9b3f8e8996">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-271e4583-49dd-4f0f-95b5-ad9b3f8e8996">
											<gml:posList>35.669045184660405 139.74416751872482 42.495 35.669021220039866 139.74419577913622 42.495 35.66902515372009 139.7442007675882 42.495 35.66884869079611 139.74440657490257 42.495 35.66883995719634 139.74439532866612 42.495 35.66882513336204 139.744412621124 42.495 35.66911286673559 139.74465298518152 42.495 35.66919476226561 139.74456294624096 42.495 35.66926130550796 139.74465382620357 42.495 35.66930411310522 139.74460675556148 42.495 35.669045184660405 139.74416751872482 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb627aaf-87d7-499b-9def-907e6dc7b5ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb627aaf-87d7-499b-9def-907e6dc7b5ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb627aaf-87d7-499b-9def-907e6dc7b5ec">
											<gml:posList>35.66936251295928 139.74512187091256 43.3 35.669362843568344 139.7451056106606 43.3 35.66882513336204 139.744412621124 43.3 35.66881188287481 139.74441221606892 43.3 35.66936251295928 139.74512187091256 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c35ec6a2-0253-436f-9596-f29f79f6ffd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c35ec6a2-0253-436f-9596-f29f79f6ffd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c35ec6a2-0253-436f-9596-f29f79f6ffd1">
											<gml:posList>35.669362843568344 139.7451056106606 42.495 35.66922080649497 139.7448003975135 42.495 35.66911286673559 139.74465298518152 42.495 35.66882513336204 139.744412621124 42.495 35.669362843568344 139.7451056106606 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-afae1cef-eeee-4ea3-a493-aaabdf2115b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afae1cef-eeee-4ea3-a493-aaabdf2115b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afae1cef-eeee-4ea3-a493-aaabdf2115b5">
											<gml:posList>35.66911286673559 139.74465298518152 55.682 35.66912857844845 139.74465403927488 55.682 35.66919391114006 139.7445822005293 55.682 35.66919476226561 139.74456294624096 55.682 35.66911286673559 139.74465298518152 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c102ad34-a940-4496-860a-4bb2b5942a35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c102ad34-a940-4496-860a-4bb2b5942a35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c102ad34-a940-4496-860a-4bb2b5942a35">
											<gml:posList>35.66922080649497 139.7448003975135 55.682 35.66922165766352 139.744781154267 55.682 35.66912857844845 139.74465403927488 55.682 35.66911286673559 139.74465298518152 55.682 35.66922080649497 139.7448003975135 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f7a3cef9-c736-4423-b6a7-10273314b9a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7a3cef9-c736-4423-b6a7-10273314b9a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7a3cef9-c736-4423-b6a7-10273314b9a0">
											<gml:posList>35.669286990429995 139.7447093155413 53.1 35.66919391114006 139.7445822005293 53.1 35.66912857844845 139.74465403927488 53.1 35.66922165766352 139.744781154267 53.1 35.669286990429995 139.7447093155413 53.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e3cba16-ff56-43ae-b64e-2c51317475be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e3cba16-ff56-43ae-b64e-2c51317475be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e3cba16-ff56-43ae-b64e-2c51317475be">
											<gml:posList>35.66919476226561 139.74456294624096 55.682 35.66919391114006 139.7445822005293 55.682 35.669286990429995 139.7447093155413 55.682 35.66930269312007 139.74471035861174 55.682 35.66919476226561 139.74456294624096 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2055c308-a546-45c1-b580-d410e7adce1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2055c308-a546-45c1-b580-d410e7adce1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2055c308-a546-45c1-b580-d410e7adce1e">
											<gml:posList>35.66930269312007 139.74471035861174 55.682 35.669286990429995 139.7447093155413 55.682 35.66922165766352 139.744781154267 55.682 35.66922080649497 139.7448003975135 55.682 35.66930269312007 139.74471035861174 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9de09a5d-4c15-4ef4-a57c-e116cf18a1b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9de09a5d-4c15-4ef4-a57c-e116cf18a1b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9de09a5d-4c15-4ef4-a57c-e116cf18a1b9">
											<gml:posList>35.669303944489634 139.74461034573432 46.501 35.66930411310522 139.74460675556148 46.501 35.66926130550796 139.74465382620357 46.501 35.669262685999 139.74465571356086 46.501 35.669303944489634 139.74461034573432 46.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c2d529f-f980-495e-8325-bee5c6b7e096">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c2d529f-f980-495e-8325-bee5c6b7e096">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c2d529f-f980-495e-8325-bee5c6b7e096">
											<gml:posList>35.66954185669062 139.7448972601353 42.495 35.669045184660405 139.74416751872482 42.495 35.66930411310522 139.74460675556148 42.495 35.66933058603403 139.74464291334056 42.495 35.66954185669062 139.7448972601353 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-032c8c45-168d-4311-bdf6-d972dab59781">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-032c8c45-168d-4311-bdf6-d972dab59781">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-032c8c45-168d-4311-bdf6-d972dab59781">
											<gml:posList>35.669262685999 139.74465571356086 46.254 35.66928639794045 139.74468810766655 46.254 35.669327656435 139.74464272879712 46.254 35.669303944489634 139.74461034573432 46.254 35.669262685999 139.74465571356086 46.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-734a8738-fee6-4e0f-a587-b7f99537508a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-734a8738-fee6-4e0f-a587-b7f99537508a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-734a8738-fee6-4e0f-a587-b7f99537508a">
											<gml:posList>35.66904595641238 139.74415071678501 43.3 35.669045184660405 139.74416751872482 43.3 35.66954185669062 139.7448972601353 43.3 35.6695547019465 139.74489819593597 43.3 35.66904595641238 139.74415071678501 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c592d0e-ab83-4acf-bc41-82d29bce42c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c592d0e-ab83-4acf-bc41-82d29bce42c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c592d0e-ab83-4acf-bc41-82d29bce42c5">
											<gml:posList>35.669327656435 139.74464272879712 46.501 35.66928639794045 139.74468810766655 46.501 35.66928777842282 139.7446899839789 46.501 35.66933058603403 139.74464291334056 46.501 35.669327656435 139.74464272879712 46.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c22852e7-52ec-4de4-9ad0-7b19a2680e2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c22852e7-52ec-4de4-9ad0-7b19a2680e2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c22852e7-52ec-4de4-9ad0-7b19a2680e2b">
											<gml:posList>35.66930411310522 139.74460675556148 46.501 35.669303944489634 139.74461034573432 46.501 35.669327656435 139.74464272879712 46.501 35.66933058603403 139.74464291334056 46.501 35.66930411310522 139.74460675556148 46.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5de54855-76cb-46d5-b45d-906e4f209daf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5de54855-76cb-46d5-b45d-906e4f209daf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5de54855-76cb-46d5-b45d-906e4f209daf">
											<gml:posList>35.66930269312007 139.74471035861174 42.495 35.66922080649497 139.7448003975135 42.495 35.669362843568344 139.7451056106606 42.495 35.66954185669062 139.7448972601353 42.495 35.66933058603403 139.74464291334056 42.495 35.66928777842282 139.7446899839789 42.495 35.66930269312007 139.74471035861174 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b3dfe12-b1f0-40a3-88f1-2d0252d4351e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b3dfe12-b1f0-40a3-88f1-2d0252d4351e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b3dfe12-b1f0-40a3-88f1-2d0252d4351e">
											<gml:posList>35.66949787375494 139.7449642040608 43.3 35.6695547019465 139.74489819593597 43.3 35.66954185669062 139.7448972601353 43.3 35.669362843568344 139.7451056106606 43.3 35.66936251295928 139.74512187091256 43.3 35.66949490181966 139.74496774210039 43.3 35.66949787375494 139.7449642040608 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6bbf935c-8831-4698-b46a-f6e0df29f878">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bbf935c-8831-4698-b46a-f6e0df29f878">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bbf935c-8831-4698-b46a-f6e0df29f878">
											<gml:posList>35.669021220039866 139.74419577913622 43.3 35.669021220039866 139.74419577913622 42.495 35.669045184660405 139.74416751872482 42.495 35.669045184660405 139.74416751872482 43.3 35.669021220039866 139.74419577913622 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2136db78-9ab9-47e4-b396-adb504a7a55b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2136db78-9ab9-47e4-b396-adb504a7a55b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2136db78-9ab9-47e4-b396-adb504a7a55b">
											<gml:posList>35.669362843568344 139.7451056106606 43.3 35.669362843568344 139.7451056106606 42.495 35.66882513336204 139.744412621124 42.495 35.66882513336204 139.744412621124 43.3 35.669362843568344 139.7451056106606 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35f7e778-733b-4fae-83f9-acd68dd9dee4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35f7e778-733b-4fae-83f9-acd68dd9dee4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35f7e778-733b-4fae-83f9-acd68dd9dee4">
											<gml:posList>35.66922165766352 139.744781154267 55.682 35.66922165766352 139.744781154267 53.1 35.66912857844845 139.74465403927488 53.1 35.66912857844845 139.74465403927488 55.682 35.66922165766352 139.744781154267 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac80a47e-06b8-40bf-829f-6fe86dd9895d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac80a47e-06b8-40bf-829f-6fe86dd9895d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac80a47e-06b8-40bf-829f-6fe86dd9895d">
											<gml:posList>35.66919391114006 139.7445822005293 55.682 35.66919391114006 139.7445822005293 53.1 35.669286990429995 139.7447093155413 53.1 35.669286990429995 139.7447093155413 55.682 35.66919391114006 139.7445822005293 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-557d7cb9-48c7-47fa-be34-2a4d2955a9f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-557d7cb9-48c7-47fa-be34-2a4d2955a9f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-557d7cb9-48c7-47fa-be34-2a4d2955a9f8">
											<gml:posList>35.669262685999 139.74465571356086 46.501 35.669262685999 139.74465571356086 46.254 35.669303944489634 139.74461034573432 46.254 35.669303944489634 139.74461034573432 46.501 35.669262685999 139.74465571356086 46.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e28fc69-338e-4e6e-a2f2-40378ccd0ec2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e28fc69-338e-4e6e-a2f2-40378ccd0ec2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e28fc69-338e-4e6e-a2f2-40378ccd0ec2">
											<gml:posList>35.669045184660405 139.74416751872482 43.3 35.669045184660405 139.74416751872482 42.495 35.66954185669062 139.7448972601353 42.495 35.66954185669062 139.7448972601353 43.3 35.669045184660405 139.74416751872482 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-198caf12-59e1-4e81-85c4-59a3338f9f53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-198caf12-59e1-4e81-85c4-59a3338f9f53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-198caf12-59e1-4e81-85c4-59a3338f9f53">
											<gml:posList>35.669327656435 139.74464272879712 46.501 35.669327656435 139.74464272879712 46.254 35.66928639794045 139.74468810766655 46.254 35.66928639794045 139.74468810766655 46.501 35.669327656435 139.74464272879712 46.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01485f35-3541-4917-afa3-f28b8930c1c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01485f35-3541-4917-afa3-f28b8930c1c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01485f35-3541-4917-afa3-f28b8930c1c9">
											<gml:posList>35.66897329342897 139.7441341180453 48.02 35.66901461580248 139.74418742460185 48.02 35.66901461580248 139.74418742460185 43.3 35.66901461580248 139.74418742460185 6.5 35.66897329342897 139.7441341180453 6.5 35.66897329342897 139.7441341180453 48.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79c94d6d-7984-4417-9180-8fa0cde31e44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79c94d6d-7984-4417-9180-8fa0cde31e44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79c94d6d-7984-4417-9180-8fa0cde31e44">
											<gml:posList>35.66897319742819 139.74413837088753 48.02 35.66897319742819 139.74413837088753 48.308 35.66901283262217 139.74418950324582 48.308 35.66901283262217 139.74418950324582 48.02 35.66897319742819 139.74413837088753 48.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4291a8fe-1a08-4fc0-b6bd-09fa0a7292cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4291a8fe-1a08-4fc0-b6bd-09fa0a7292cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4291a8fe-1a08-4fc0-b6bd-09fa0a7292cb">
											<gml:posList>35.66904595641238 139.74415071678501 6.5 35.66901461580248 139.74418742460185 6.5 35.66901461580248 139.74418742460185 43.3 35.66904595641238 139.74415071678501 43.3 35.66904595641238 139.74415071678501 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfa321c9-756b-4838-bb69-754c719c92ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfa321c9-756b-4838-bb69-754c719c92ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfa321c9-756b-4838-bb69-754c719c92ed">
											<gml:posList>35.669021220039866 139.74419577913622 43.3 35.66901461580248 139.74418742460185 43.3 35.66901461580248 139.74418742460185 48.02 35.66902515372009 139.7442007675882 48.02 35.66902515372009 139.7442007675882 42.495 35.669021220039866 139.74419577913622 42.495 35.669021220039866 139.74419577913622 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3890472c-05e2-43d4-a0d7-b1bc5fe97861">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3890472c-05e2-43d4-a0d7-b1bc5fe97861">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3890472c-05e2-43d4-a0d7-b1bc5fe97861">
											<gml:posList>35.66901283262217 139.74418950324582 48.02 35.66901283262217 139.74418950324582 48.308 35.669021656329136 139.74420068310744 48.308 35.669021656329136 139.74420068310744 48.02 35.66901283262217 139.74418950324582 48.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be596c6c-9ee9-4712-b022-9e53e09ea8a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be596c6c-9ee9-4712-b022-9e53e09ea8a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be596c6c-9ee9-4712-b022-9e53e09ea8a9">
											<gml:posList>35.66897329342897 139.7441341180453 48.02 35.66897329342897 139.7441341180453 6.5 35.66879686655801 139.7443397706883 6.5 35.66879686655801 139.7443397706883 48.02 35.66897329342897 139.7441341180453 48.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20d8d9f5-589f-45b8-bb5c-d2b9e2f5a369">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20d8d9f5-589f-45b8-bb5c-d2b9e2f5a369">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20d8d9f5-589f-45b8-bb5c-d2b9e2f5a369">
											<gml:posList>35.668800336916014 139.74433986625095 48.02 35.668800336916014 139.74433986625095 48.308 35.66897319742819 139.74413837088753 48.308 35.66897319742819 139.74413837088753 48.02 35.668800336916014 139.74433986625095 48.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb39c4ce-9c79-4f53-b81f-cd73b30ce14a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb39c4ce-9c79-4f53-b81f-cd73b30ce14a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb39c4ce-9c79-4f53-b81f-cd73b30ce14a">
											<gml:posList>35.669021656329136 139.74420068310744 48.02 35.669021656329136 139.74420068310744 48.308 35.668848777784504 139.74440231103125 48.308 35.668848777784504 139.74440231103125 48.02 35.669021656329136 139.74420068310744 48.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36ea000b-cf16-4b56-95eb-4f7fa1b91279">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36ea000b-cf16-4b56-95eb-4f7fa1b91279">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36ea000b-cf16-4b56-95eb-4f7fa1b91279">
											<gml:posList>35.66884869079611 139.74440657490257 42.495 35.66902515372009 139.7442007675882 42.495 35.66902515372009 139.7442007675882 48.02 35.66884869079611 139.74440657490257 48.02 35.66884869079611 139.74440657490257 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca438e6f-2156-45b3-a692-3457352b3b59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca438e6f-2156-45b3-a692-3457352b3b59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca438e6f-2156-45b3-a692-3457352b3b59">
											<gml:posList>35.668848777784504 139.74440231103125 48.02 35.668848777784504 139.74440231103125 48.308 35.668800336916014 139.74433986625095 48.308 35.668800336916014 139.74433986625095 48.02 35.668848777784504 139.74440231103125 48.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-364b02c0-a754-4730-bdb2-8359ca747dfb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-364b02c0-a754-4730-bdb2-8359ca747dfb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-364b02c0-a754-4730-bdb2-8359ca747dfb">
											<gml:posList>35.66883995719634 139.74439532866612 43.3 35.66883995719634 139.74439532866612 42.495 35.66884869079611 139.74440657490257 42.495 35.66884869079611 139.74440657490257 48.02 35.66879686655801 139.7443397706883 48.02 35.66879686655801 139.7443397706883 6.5 35.6688334972167 139.74438700711227 6.5 35.6688334972167 139.74438700711227 43.3 35.66883995719634 139.74439532866612 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32bd75a0-417b-4226-ab8f-14805185da3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32bd75a0-417b-4226-ab8f-14805185da3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32bd75a0-417b-4226-ab8f-14805185da3a">
											<gml:posList>35.6688334972167 139.74438700711227 6.5 35.66881188287481 139.74441221606892 6.5 35.66881188287481 139.74441221606892 43.3 35.6688334972167 139.74438700711227 43.3 35.6688334972167 139.74438700711227 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3b0ddd8-14eb-4c68-a26f-801e5a431f37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3b0ddd8-14eb-4c68-a26f-801e5a431f37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3b0ddd8-14eb-4c68-a26f-801e5a431f37">
											<gml:posList>35.66882513336204 139.744412621124 43.3 35.66882513336204 139.744412621124 42.495 35.66883995719634 139.74439532866612 42.495 35.66883995719634 139.74439532866612 43.3 35.66882513336204 139.744412621124 43.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9977307a-63a9-4de1-8309-412ffd17f200">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9977307a-63a9-4de1-8309-412ffd17f200">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9977307a-63a9-4de1-8309-412ffd17f200">
											<gml:posList>35.6695547019465 139.74489819593597 6.5 35.66904595641238 139.74415071678501 6.5 35.66904595641238 139.74415071678501 43.3 35.6695547019465 139.74489819593597 43.3 35.6695547019465 139.74489819593597 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca1c18b0-bf70-4958-a137-a952f803fba9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca1c18b0-bf70-4958-a137-a952f803fba9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca1c18b0-bf70-4958-a137-a952f803fba9">
											<gml:posList>35.66911286673559 139.74465298518152 55.682 35.66919476226561 139.74456294624096 55.682 35.66919476226561 139.74456294624096 42.495 35.66911286673559 139.74465298518152 42.495 35.66911286673559 139.74465298518152 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30b4f656-c26f-4e6e-a4bb-0273a01c0dbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30b4f656-c26f-4e6e-a4bb-0273a01c0dbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30b4f656-c26f-4e6e-a4bb-0273a01c0dbc">
											<gml:posList>35.66912857844845 139.74465403927488 55.682 35.66912857844845 139.74465403927488 53.1 35.66919391114006 139.7445822005293 53.1 35.66919391114006 139.7445822005293 55.682 35.66912857844845 139.74465403927488 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-188dc5d5-c985-4eb7-a482-3cd7ea22423e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-188dc5d5-c985-4eb7-a482-3cd7ea22423e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-188dc5d5-c985-4eb7-a482-3cd7ea22423e">
											<gml:posList>35.66930411310522 139.74460675556148 46.501 35.66933058603403 139.74464291334056 46.501 35.66933058603403 139.74464291334056 42.495 35.66930411310522 139.74460675556148 42.495 35.66930411310522 139.74460675556148 46.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4b69de3-7f01-4d0b-b60c-304ed365eb88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4b69de3-7f01-4d0b-b60c-304ed365eb88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4b69de3-7f01-4d0b-b60c-304ed365eb88">
											<gml:posList>35.669303944489634 139.74461034573432 46.501 35.669303944489634 139.74461034573432 46.254 35.669327656435 139.74464272879712 46.254 35.669327656435 139.74464272879712 46.501 35.669303944489634 139.74461034573432 46.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ed2a240-1ec7-4314-bca6-cceb327bba3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ed2a240-1ec7-4314-bca6-cceb327bba3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ed2a240-1ec7-4314-bca6-cceb327bba3c">
											<gml:posList>35.66926130550796 139.74465382620357 46.501 35.66930411310522 139.74460675556148 46.501 35.66930411310522 139.74460675556148 42.495 35.66926130550796 139.74465382620357 42.495 35.66926130550796 139.74465382620357 46.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eca8359f-58d4-4c56-ae27-7667b512c70c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eca8359f-58d4-4c56-ae27-7667b512c70c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eca8359f-58d4-4c56-ae27-7667b512c70c">
											<gml:posList>35.66928639794045 139.74468810766655 46.501 35.66928639794045 139.74468810766655 46.254 35.669262685999 139.74465571356086 46.254 35.669262685999 139.74465571356086 46.501 35.66926130550796 139.74465382620357 46.501 35.66926130550796 139.74465382620357 42.495 35.66919476226561 139.74456294624096 42.495 35.66919476226561 139.74456294624096 55.682 35.66930269312007 139.74471035861174 55.682 35.66930269312007 139.74471035861174 42.495 35.66928777842282 139.7446899839789 42.495 35.66928777842282 139.7446899839789 46.501 35.66928639794045 139.74468810766655 46.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ef8519b-d91b-4152-a2aa-14a7fb73d21d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ef8519b-d91b-4152-a2aa-14a7fb73d21d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ef8519b-d91b-4152-a2aa-14a7fb73d21d">
											<gml:posList>35.66928777842282 139.7446899839789 42.495 35.66933058603403 139.74464291334056 42.495 35.66933058603403 139.74464291334056 46.501 35.66928777842282 139.7446899839789 46.501 35.66928777842282 139.7446899839789 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e23badda-7301-40f1-9f6d-d2524be6dfd7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e23badda-7301-40f1-9f6d-d2524be6dfd7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e23badda-7301-40f1-9f6d-d2524be6dfd7">
											<gml:posList>35.66911286673559 139.74465298518152 42.495 35.66922080649497 139.7448003975135 42.495 35.66922080649497 139.7448003975135 55.682 35.66911286673559 139.74465298518152 55.682 35.66911286673559 139.74465298518152 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fccc5f03-a398-4949-8e15-4fd940abc5f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fccc5f03-a398-4949-8e15-4fd940abc5f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fccc5f03-a398-4949-8e15-4fd940abc5f3">
											<gml:posList>35.669286990429995 139.7447093155413 55.682 35.669286990429995 139.7447093155413 53.1 35.66922165766352 139.744781154267 53.1 35.66922165766352 139.744781154267 55.682 35.669286990429995 139.7447093155413 55.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a54eaa7e-c080-4074-8139-51218a5c0f7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a54eaa7e-c080-4074-8139-51218a5c0f7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a54eaa7e-c080-4074-8139-51218a5c0f7d">
											<gml:posList>35.66922080649497 139.7448003975135 42.495 35.66930269312007 139.74471035861174 42.495 35.66930269312007 139.74471035861174 55.682 35.66922080649497 139.7448003975135 55.682 35.66922080649497 139.7448003975135 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-172887fe-abc9-4fa7-bd47-d76ee7491481">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-172887fe-abc9-4fa7-bd47-d76ee7491481">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-172887fe-abc9-4fa7-bd47-d76ee7491481">
											<gml:posList>35.66881188287481 139.74441221606892 6.5 35.66936251295928 139.74512187091256 6.5 35.66936251295928 139.74512187091256 43.3 35.66881188287481 139.74441221606892 43.3 35.66881188287481 139.74441221606892 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-89e06648-11e9-458d-a860-debeaef9f4ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89e06648-11e9-458d-a860-debeaef9f4ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89e06648-11e9-458d-a860-debeaef9f4ca">
											<gml:posList>35.66949787375494 139.7449642040608 6.5 35.6695547019465 139.74489819593597 6.5 35.6695547019465 139.74489819593597 43.3 35.66949787375494 139.7449642040608 43.3 35.66949787375494 139.7449642040608 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a68f98b-1034-4fb5-a871-07e0f193c369">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a68f98b-1034-4fb5-a871-07e0f193c369">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a68f98b-1034-4fb5-a871-07e0f193c369">
											<gml:posList>35.66949490181966 139.74496774210039 6.5 35.66949787375494 139.7449642040608 6.5 35.66949787375494 139.7449642040608 43.3 35.66949490181966 139.74496774210039 43.3 35.66949490181966 139.74496774210039 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1e836db-add3-4ecc-8c36-b7ed17f34c69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1e836db-add3-4ecc-8c36-b7ed17f34c69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1e836db-add3-4ecc-8c36-b7ed17f34c69">
											<gml:posList>35.66954185669062 139.7448972601353 42.495 35.669362843568344 139.7451056106606 42.495 35.669362843568344 139.7451056106606 43.3 35.66954185669062 139.7448972601353 43.3 35.66954185669062 139.7448972601353 42.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-691de7d9-c5aa-41b5-b1c4-eee6c18570bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-691de7d9-c5aa-41b5-b1c4-eee6c18570bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-691de7d9-c5aa-41b5-b1c4-eee6c18570bc">
											<gml:posList>35.66936251295928 139.74512187091256 6.5 35.66949490181966 139.74496774210039 6.5 35.66949490181966 139.74496774210039 43.3 35.66936251295928 139.74512187091256 43.3 35.66936251295928 139.74512187091256 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8322</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">3018.76565</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>