<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ae3a0cf9-a70d-4181-9205-15f761ef42ff">
			<core:creationDate>2023-08-22</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018003</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">28.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.666724202596654 139.74764958908324 0 35.66664650330019 139.74761415009328 0 35.666619906460966 139.74770155807673 0 35.666640133315646 139.747713007483 0 35.66669539532814 139.7477442742318 0 35.666724202596654 139.74764958908324 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666724202596654 139.74764958908324 5.522 35.66669539532814 139.7477442742318 5.522 35.666640133315646 139.747713007483 5.522 35.666619906460966 139.74770155807673 5.522 35.66664650330019 139.74761415009328 5.522 35.666724202596654 139.74764958908324 5.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666724202596654 139.74764958908324 5.522 35.66664650330019 139.74761415009328 5.522 35.66664650330019 139.74761415009328 28.859 35.666724202596654 139.74764958908324 28.859 35.666724202596654 139.74764958908324 5.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66664650330019 139.74761415009328 5.522 35.666619906460966 139.74770155807673 5.522 35.666619906460966 139.74770155807673 28.859 35.66664650330019 139.74761415009328 28.859 35.66664650330019 139.74761415009328 5.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666619906460966 139.74770155807673 5.522 35.666640133315646 139.747713007483 5.522 35.666640133315646 139.747713007483 28.859 35.666619906460966 139.74770155807673 28.859 35.666619906460966 139.74770155807673 5.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666640133315646 139.747713007483 5.522 35.66669539532814 139.7477442742318 5.522 35.66669539532814 139.7477442742318 28.859 35.666640133315646 139.747713007483 28.859 35.666640133315646 139.747713007483 5.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66669539532814 139.7477442742318 5.522 35.666724202596654 139.74764958908324 5.522 35.666724202596654 139.74764958908324 28.859 35.66669539532814 139.7477442742318 28.859 35.66669539532814 139.7477442742318 5.522</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666724202596654 139.74764958908324 28.859 35.66664650330019 139.74761415009328 28.859 35.666619906460966 139.74770155807673 28.859 35.666640133315646 139.747713007483 28.859 35.66669539532814 139.7477442742318 28.859 35.666724202596654 139.74764958908324 28.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly_TMmnt0179_p1044_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0179_p1044_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0179_p1044_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0179_p1044_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0179_p1044_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0179_p1042_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0179_p1042_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0179_p1042_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0179_p1042_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0179_p1042_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0179_p1042_5"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0179_p1043_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0179_p1043_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0179_p1043_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0179_p1043_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0179_b_0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_34146d7a-b0c7-497a-b9f5-a98f4aff7cf1">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_88a40338-eb40-4ef3-bee8-b7d0eb92043c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_10f3e0f5-4ecd-4ab9-959b-b0acafb77e54">
											<gml:posList>35.666697206200446 139.74764695211738 28.571503196463908 35.666697206200446 139.74764695211738 29.014008079276408 35.66669759831473 139.74764563536343 28.571503196463908 35.666697206200446 139.74764695211738 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_13ae8690-b5ac-433f-92f3-98347cade784">
									<gml:exterior>
										<gml:LinearRing gml:id="line_88be7e9a-d451-4fbd-a39d-1e6d49683eb7">
											<gml:posList>35.66669759831473 139.74764563536343 28.571503196463908 35.666697206200446 139.74764695211738 29.014008079276408 35.66669759831473 139.74764563536343 29.014008079276408 35.66669759831473 139.74764563536343 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b7efa6fa-33af-4e65-a2fc-6733866afbc9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_17c77a89-9525-44f5-abf9-9656c6881ea7">
											<gml:posList>35.66669762957617 139.74764714144644 28.571503196463908 35.66669762957617 139.74764714144644 29.014008079276408 35.666697206200446 139.74764695211738 29.014008079276408 35.66669762957617 139.74764714144644 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ece25bba-e48f-40ef-b6a1-e49b8ae73592">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2dd752ac-a67b-49b7-b006-041eeea350d5">
											<gml:posList>35.66669762957617 139.74764714144644 28.571503196463908 35.666697206200446 139.74764695211738 29.014008079276408 35.666697206200446 139.74764695211738 28.571503196463908 35.66669762957617 139.74764714144644 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3cfa06a3-b9a8-4f95-859b-a0f0a59e998d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dee8c305-b9c0-44cb-b7dd-ce4861bf6051">
											<gml:posList>35.66669817618987 139.74764530591497 28.571503196463908 35.66669817618987 139.74764530591497 29.014008079276408 35.66669762957617 139.74764714144644 28.571503196463908 35.66669817618987 139.74764530591497 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_98a67de8-9a5d-4d7e-868e-414ad6c82602">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1c2254fe-7acb-4aa2-aa17-d04e4afbb5bb">
											<gml:posList>35.66669762957617 139.74764714144644 28.571503196463908 35.66669817618987 139.74764530591497 29.014008079276408 35.66669762957617 139.74764714144644 29.014008079276408 35.66669762957617 139.74764714144644 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1ba36a3a-6bf5-4bc2-9e9e-0bdec3235ae9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7dde58d4-2642-48f6-8c0d-6d9233e1f2be">
											<gml:posList>35.66669759831473 139.74764563536343 29.014008079276408 35.666647949194605 139.74762343276282 29.014008079276408 35.66669759831473 139.74764563536343 28.571503196463908 35.66669759831473 139.74764563536343 29.014008079276408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b326381b-9b44-4268-a081-63841e04ddd8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3646b7fe-c80f-47e2-a7d7-0d770ba13e57">
											<gml:posList>35.66669759831473 139.74764563536343 28.571503196463908 35.666647949194605 139.74762343276282 29.014008079276408 35.666647949194605 139.74762343276282 28.571503196463908 35.66669759831473 139.74764563536343 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e4437502-62a5-4687-9f67-b0a7a3112cc0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1e45cd16-9aa4-4433-82ab-b8a690da7693">
											<gml:posList>35.66664768028381 139.74762272465685 28.571503196463908 35.66664768028381 139.74762272465685 29.014008079276408 35.66669817618987 139.74764530591497 28.571503196463908 35.66664768028381 139.74762272465685 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bb7442cd-f4b0-4a6d-bba8-77a53e80939c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0a535e45-32b9-4801-9d01-bfb4f05d6869">
											<gml:posList>35.66669817618987 139.74764530591497 28.571503196463908 35.66664768028381 139.74762272465685 29.014008079276408 35.66669817618987 139.74764530591497 29.014008079276408 35.66669817618987 139.74764530591497 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7f531d73-fe1a-4bd2-9501-cdad9ab29221">
									<gml:exterior>
										<gml:LinearRing gml:id="line_61206386-b60f-4b49-a8fe-9efba2ba4d74">
											<gml:posList>35.666623057929115 139.74770701217867 28.571503196463908 35.666622905631954 139.74770753364993 29.014008079276408 35.666623057929115 139.74770701217867 29.014008079276408 35.666623057929115 139.74770701217867 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fbfd5edf-60c4-4389-acad-8cdc285029a3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_edc67f3d-10f3-4833-9678-e1c5de6052a5">
											<gml:posList>35.666622905631954 139.74770753364993 29.014008079276408 35.666623057929115 139.74770701217867 28.571503196463908 35.666622905631954 139.74770753364993 28.571503196463908 35.666622905631954 139.74770753364993 29.014008079276408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_435e38df-e959-49f7-8981-cee221d2066b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a911fed4-a2ad-4d71-ab66-3dd2fc89c158">
											<gml:posList>35.666623057929115 139.74770701217867 28.571503196463908 35.666623057929115 139.74770701217867 29.014008079276408 35.66664768028381 139.74762272465685 28.571503196463908 35.666623057929115 139.74770701217867 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_25ca533e-0424-4b05-931e-75c0f405e049">
									<gml:exterior>
										<gml:LinearRing gml:id="line_30100ac4-eac1-4433-a54e-f4da5c5975fe">
											<gml:posList>35.66664768028381 139.74762272465685 28.571503196463908 35.666623057929115 139.74770701217867 29.014008079276408 35.66664768028381 139.74762272465685 29.014008079276408 35.66664768028381 139.74762272465685 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9f81c3be-7989-4e94-8141-bcc21b436f8d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0cd3cd2d-53bb-4a3b-9cca-4a7577d654f8">
											<gml:posList>35.66667226728167 139.7477344775981 28.571503196463908 35.66667226728167 139.7477344775981 29.014008079276408 35.666622905631954 139.74770753364993 28.571503196463908 35.66667226728167 139.7477344775981 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1b2e88c8-648c-4ae7-86be-0da7e8ddcd9c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bba29c60-8840-4b25-a509-093a1df478f5">
											<gml:posList>35.666622905631954 139.74770753364993 28.571503196463908 35.66667226728167 139.7477344775981 29.014008079276408 35.666622905631954 139.74770753364993 29.014008079276408 35.666622905631954 139.74770753364993 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f88653c0-f66c-41bf-9931-a2a41cc5127f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b1d7f79b-cf6b-4a87-8ddd-982ce71fc641">
											<gml:posList>35.666647949194605 139.74762343276282 28.571503196463908 35.666647949194605 139.74762343276282 29.014008079276408 35.66662347077419 139.74770723741915 28.571503196463908 35.666647949194605 139.74762343276282 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_da36c368-4f81-4cfd-ac14-03c729ba60fe">
									<gml:exterior>
										<gml:LinearRing gml:id="line_966485d6-300d-4941-bc5f-c7ddc8deec60">
											<gml:posList>35.66662347077419 139.74770723741915 28.571503196463908 35.666647949194605 139.74762343276282 29.014008079276408 35.66662347077419 139.74770723741915 29.014008079276408 35.66662347077419 139.74770723741915 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c47159c9-615a-41b7-a0b9-e931bc3749b5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2c898bb2-91b0-4b98-a75a-4f238b4f108c">
											<gml:posList>35.666674081548216 139.7477294862308 29.014008079276408 35.66667226728167 139.7477344775981 29.014008079276408 35.666674081548216 139.7477294862308 28.571503196463908 35.666674081548216 139.7477294862308 29.014008079276408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fbd0b878-48a1-4612-8894-331b9b44c567">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7929ddcb-4746-4da5-a811-f63ac13eea1a">
											<gml:posList>35.666674081548216 139.7477294862308 28.571503196463908 35.66667226728167 139.7477344775981 29.014008079276408 35.66667226728167 139.7477344775981 28.571503196463908 35.666674081548216 139.7477294862308 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5a2cffc6-0e7b-499d-a886-d749b6a6a5e6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2f6ed12b-859a-4c89-8da4-15f68152e346">
											<gml:posList>35.66669759831473 139.74764563536343 29.014008079276408 35.66669762957617 139.74764714144644 29.014008079276408 35.66669817618987 139.74764530591497 29.014008079276408 35.66669759831473 139.74764563536343 29.014008079276408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_73c9f1ca-051d-43a6-a3ae-d944a25126e7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8dd7f874-5862-42d3-96bb-deed3af95a95">
											<gml:posList>35.66669762957617 139.74764714144644 29.014008079276408 35.66669759831473 139.74764563536343 29.014008079276408 35.666697206200446 139.74764695211738 29.014008079276408 35.66669762957617 139.74764714144644 29.014008079276408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d96fd021-f9c1-4c5a-8888-177b22f30f90">
									<gml:exterior>
										<gml:LinearRing gml:id="line_85472619-1e34-4683-a472-22fb5252ef66">
											<gml:posList>35.66669759831473 139.74764563536343 29.014008079276408 35.66669817618987 139.74764530591497 29.014008079276408 35.666647949194605 139.74762343276282 29.014008079276408 35.66669759831473 139.74764563536343 29.014008079276408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ee014596-fa69-4d6a-b963-375c42841845">
									<gml:exterior>
										<gml:LinearRing gml:id="line_42cd71a6-e747-4420-ab66-7002a1b1d7f3">
											<gml:posList>35.66667203896481 139.7477337483801 29.014008079276408 35.666674081548216 139.7477294862308 29.014008079276408 35.66667365714073 139.74772929639684 29.014008079276408 35.66667203896481 139.7477337483801 29.014008079276408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6d890bb3-d170-452f-a152-6f9daab9b395">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9f2d276e-e749-4b63-8a07-073e9681f882">
											<gml:posList>35.666674081548216 139.7477294862308 29.014008079276408 35.66667203896481 139.7477337483801 29.014008079276408 35.66667226728167 139.7477344775981 29.014008079276408 35.666674081548216 139.7477294862308 29.014008079276408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d851df9a-1abf-4a8a-813f-6a63f9a291eb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_be1af48e-c8d0-4646-bc1d-59ab5e017381">
											<gml:posList>35.666622905631954 139.74770753364993 29.014008079276408 35.66667203896481 139.7477337483801 29.014008079276408 35.66662347077419 139.74770723741915 29.014008079276408 35.666622905631954 139.74770753364993 29.014008079276408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fb27c5f3-3bac-4d2f-9d36-aa7f6ab2898a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d471bfa9-9ac7-4c12-85ed-371ceb005d29">
											<gml:posList>35.66667203896481 139.7477337483801 29.014008079276408 35.666622905631954 139.74770753364993 29.014008079276408 35.66667226728167 139.7477344775981 29.014008079276408 35.66667203896481 139.7477337483801 29.014008079276408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e498d0b2-0fd6-4718-80fd-b0adb5dac583">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3a96abf6-0be6-4434-82f6-5705a9c2147a">
											<gml:posList>35.666622905631954 139.74770753364993 29.014008079276408 35.66662347077419 139.74770723741915 29.014008079276408 35.666623057929115 139.74770701217867 29.014008079276408 35.666622905631954 139.74770753364993 29.014008079276408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_782f79d7-cc76-4cf5-bfbd-60abcef4834a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b2350ca5-c5d4-413f-a5d7-c4386962b46f">
											<gml:posList>35.666623057929115 139.74770701217867 29.014008079276408 35.66662347077419 139.74770723741915 29.014008079276408 35.666647949194605 139.74762343276282 29.014008079276408 35.666623057929115 139.74770701217867 29.014008079276408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_90827c66-d414-4c09-a8b8-bc1f64e37286">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f495c236-22a0-4a5d-9862-0347567de7ca">
											<gml:posList>35.666623057929115 139.74770701217867 29.014008079276408 35.666647949194605 139.74762343276282 29.014008079276408 35.66664768028381 139.74762272465685 29.014008079276408 35.666623057929115 139.74770701217867 29.014008079276408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a5ffb799-8213-4bb6-9ace-1604fd5d236d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_843748dd-3497-4f72-823a-3f113c156140">
											<gml:posList>35.66664768028381 139.74762272465685 29.014008079276408 35.666647949194605 139.74762343276282 29.014008079276408 35.66669817618987 139.74764530591497 29.014008079276408 35.66664768028381 139.74762272465685 29.014008079276408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bd9b591c-4421-4222-a016-b766dc9ee48f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_693d6a81-7404-4bf1-8210-7ed1b5af70cf">
											<gml:posList>35.66667203896481 139.7477337483801 28.571503196463908 35.666674081548216 139.7477294862308 28.571503196463908 35.66667226728167 139.7477344775981 28.571503196463908 35.66667203896481 139.7477337483801 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9527229a-4e77-4f33-9d01-ee9a6b82cba6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_795658fd-9a77-4bef-a397-207576c3ed4d">
											<gml:posList>35.666674081548216 139.7477294862308 28.571503196463908 35.66667203896481 139.7477337483801 28.571503196463908 35.66667365714073 139.74772929639684 28.571503196463908 35.666674081548216 139.7477294862308 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_983ad52a-0a71-4c3e-9c40-349dfd43c782">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8b12b32a-e15b-4d85-a865-ddc9943a9179">
											<gml:posList>35.66669759831473 139.74764563536343 28.571503196463908 35.66669817618987 139.74764530591497 28.571503196463908 35.66669762957617 139.74764714144644 28.571503196463908 35.66669759831473 139.74764563536343 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_44b7aa56-f8fa-4719-9693-ffc68f71875d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d9e23e21-5889-412c-930b-276a8451d536">
											<gml:posList>35.66669817618987 139.74764530591497 28.571503196463908 35.66669759831473 139.74764563536343 28.571503196463908 35.666647949194605 139.74762343276282 28.571503196463908 35.66669817618987 139.74764530591497 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3b3cd169-bb18-4bec-9785-87e155f3024e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7cd78581-ec21-41bd-a9c9-49d1ce176be0">
											<gml:posList>35.66669817618987 139.74764530591497 28.571503196463908 35.666647949194605 139.74762343276282 28.571503196463908 35.66664768028381 139.74762272465685 28.571503196463908 35.66669817618987 139.74764530591497 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_22e5639d-c2dd-4de9-9bcf-3995e5883a18">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a42b54a9-2ec1-45a3-946c-2616533c51e2">
											<gml:posList>35.66669759831473 139.74764563536343 28.571503196463908 35.66669762957617 139.74764714144644 28.571503196463908 35.666697206200446 139.74764695211738 28.571503196463908 35.66669759831473 139.74764563536343 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_59b0bade-3dd5-4780-a99e-d24d7dbc5d76">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0c1f6bba-25d7-4a7e-bd70-6a026b1dc8ec">
											<gml:posList>35.666623057929115 139.74770701217867 28.571503196463908 35.666647949194605 139.74762343276282 28.571503196463908 35.66662347077419 139.74770723741915 28.571503196463908 35.666623057929115 139.74770701217867 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f1d4ec34-41d8-4543-9c20-a5e7276ea86e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_14095d8c-0f27-4e92-a485-4330d37d9517">
											<gml:posList>35.666647949194605 139.74762343276282 28.571503196463908 35.666623057929115 139.74770701217867 28.571503196463908 35.66664768028381 139.74762272465685 28.571503196463908 35.666647949194605 139.74762343276282 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dd337f3f-ed3e-4c80-aa53-618324c87a13">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6d520c96-afd2-474c-80e8-893821b9b865">
											<gml:posList>35.666623057929115 139.74770701217867 28.571503196463908 35.66662347077419 139.74770723741915 28.571503196463908 35.666622905631954 139.74770753364993 28.571503196463908 35.666623057929115 139.74770701217867 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_15f34e2b-d049-4f4e-866e-40e47406dcb0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bfbbb84b-8d7c-4bbe-9122-5914c9d0deef">
											<gml:posList>35.666622905631954 139.74770753364993 28.571503196463908 35.66662347077419 139.74770723741915 28.571503196463908 35.66667203896481 139.7477337483801 28.571503196463908 35.666622905631954 139.74770753364993 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_94f13cc3-65d9-409f-ada0-864717d31b64">
									<gml:exterior>
										<gml:LinearRing gml:id="line_712424ad-37c8-4080-9649-6a0424ffe989">
											<gml:posList>35.666622905631954 139.74770753364993 28.571503196463908 35.66667203896481 139.7477337483801 28.571503196463908 35.66667226728167 139.7477344775981 28.571503196463908 35.666622905631954 139.74770753364993 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_820f5807-c8ee-434a-9691-d35c3be5505f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c3c97aae-e88c-47e1-b032-c40b4893e18c">
											<gml:posList>35.66667365714073 139.74772929639684 28.571503196463908 35.66667365714073 139.74772929639684 29.014008079276408 35.666674081548216 139.7477294862308 29.014008079276408 35.66667365714073 139.74772929639684 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_38e093f6-9706-4751-bbfe-2b6d167474b9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_959e85c1-d65a-45bd-a61c-6dc5218a3a85">
											<gml:posList>35.66667365714073 139.74772929639684 28.571503196463908 35.666674081548216 139.7477294862308 29.014008079276408 35.666674081548216 139.7477294862308 28.571503196463908 35.66667365714073 139.74772929639684 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0c1a03f1-8b4e-4b32-b05b-dd44c6d38393">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7874d459-bee7-4cac-a31c-3d51cea5cbe5">
											<gml:posList>35.66667203896481 139.7477337483801 28.571503196463908 35.66667203896481 139.7477337483801 29.014008079276408 35.66667365714073 139.74772929639684 28.571503196463908 35.66667203896481 139.7477337483801 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_40ee40df-c8cd-4496-b0b1-c39eeee14aa0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0b7bd5af-01ea-4d3e-91b4-79fb7c382a91">
											<gml:posList>35.66667365714073 139.74772929639684 28.571503196463908 35.66667203896481 139.7477337483801 29.014008079276408 35.66667365714073 139.74772929639684 29.014008079276408 35.66667365714073 139.74772929639684 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4fc468b7-ce5a-47ca-b31b-cae17576cda4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7f270442-de3e-4304-b527-f1e075f8982d">
											<gml:posList>35.66662347077419 139.74770723741915 29.014008079276408 35.66667203896481 139.7477337483801 29.014008079276408 35.66662347077419 139.74770723741915 28.571503196463908 35.66662347077419 139.74770723741915 29.014008079276408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c969bf6b-12f6-4fa9-9244-534b9615b7c0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_36e5af4d-7c78-49b6-b623-a6fd6b1a07b3">
											<gml:posList>35.66662347077419 139.74770723741915 28.571503196463908 35.66667203896481 139.7477337483801 29.014008079276408 35.66667203896481 139.7477337483801 28.571503196463908 35.66662347077419 139.74770723741915 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_50915251-a6ae-4bde-bc00-767e016cdebc">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cd0fe0df-954f-4c79-b7db-e2bed1e5af3f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_46a57f0c-9383-4200-b6e7-eb60d4fc96bf">
											<gml:posList>35.6666473498965 139.7476131329622 15.024490867362346 35.66664646996413 139.74761608781733 15.024490867362346 35.66664646996413 139.74761608781733 16.465836082206096 35.6666473498965 139.7476131329622 15.024490867362346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_23afe9e4-8251-4c18-b841-cc6d5e9d8150">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9b71df1f-9682-4302-97eb-669382bc53ea">
											<gml:posList>35.66670088692768 139.74763707398606 15.024490867362346 35.6666473498965 139.7476131329622 15.024490867362346 35.66670000699473 139.7476400288429 16.465836082206096 35.66670088692768 139.74763707398606 15.024490867362346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8412bd43-8825-4337-817c-48b59965e798">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ad7b9419-2d14-481a-8dd0-fa857ab3b09b">
											<gml:posList>35.66670000699473 139.7476400288429 16.465836082206096 35.6666473498965 139.7476131329622 15.024490867362346 35.66664646996413 139.74761608781733 16.465836082206096 35.66670000699473 139.7476400288429 16.465836082206096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9dd295b9-1b90-4d3b-8c35-61bc890e9440">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9c8c4415-ebf7-41df-9a83-37ca0903bc04">
											<gml:posList>35.66670000699473 139.7476400288429 15.024490867362346 35.66664646996413 139.74761608781733 15.024490867362346 35.66670088692768 139.74763707398606 15.024490867362346 35.66670000699473 139.7476400288429 15.024490867362346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_db9feaec-4704-4d45-a8e7-88420175305e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5e7d2cff-0278-4690-9ece-fb92d729a4a1">
											<gml:posList>35.66670088692768 139.74763707398606 15.024490867362346 35.66664646996413 139.74761608781733 15.024490867362346 35.6666473498965 139.7476131329622 15.024490867362346 35.66670088692768 139.74763707398606 15.024490867362346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8505ed72-80c6-4f07-bee6-b7a6af24880d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ab1be2f0-3e75-46b9-a957-1ed4b802e7f6">
											<gml:posList>35.66670000699473 139.7476400288429 16.465836082206096 35.66664646996413 139.74761608781733 16.465836082206096 35.66670000699473 139.7476400288429 15.024490867362346 35.66670000699473 139.7476400288429 16.465836082206096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dde99096-dc00-406a-a922-536d850ea716">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9464bbbe-597c-4617-9ade-2f02d15b6e82">
											<gml:posList>35.66670000699473 139.7476400288429 15.024490867362346 35.66664646996413 139.74761608781733 16.465836082206096 35.66664646996413 139.74761608781733 15.024490867362346 35.66670000699473 139.7476400288429 15.024490867362346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_410cfb13-821c-44a3-8e6a-393787520d91">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a91878ba-034b-4ddc-9292-a6471a3e184c">
											<gml:posList>35.66670000699473 139.7476400288429 16.465836082206096 35.66670000699473 139.7476400288429 15.024490867362346 35.66670088692768 139.74763707398606 15.024490867362346 35.66670000699473 139.7476400288429 16.465836082206096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gnd_TMmnt0179_b_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0179_b_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0179_b_0">
											<gml:posList>35.66672420289091 139.74764958876338 5.39512365 35.66669543419836 139.74774428387258 5.3945546 35.66661998422161 139.74770157677486 5.391092 35.66664654217216 139.74761415852856 5.39161777 35.66672420289091 139.74764958876338 5.39512365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gml_62862a67-af21-4eb2-a167-f323b6dc2ac6">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_09447b51-b8e8-4463-87a0-87e6d920d251">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e32db5a7-0fe5-40df-844d-883637085ec8">
											<gml:posList>35.66661808709987 139.7477060817267 6.071251426444377 35.666706854087415 139.74762070814202 6.071251426444377 35.666720410832845 139.74766081524973 6.071251426444377 35.66661808709987 139.7477060817267 6.071251426444377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_02160e3b-1ac9-4470-955f-0b7af5e3ef56">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a555d00b-1916-4817-be03-b6d0c4e7a570">
											<gml:posList>35.666706854087415 139.74762070814202 6.071251426444377 35.66661808709987 139.7477060817267 6.071251426444377 35.66665039799914 139.74759546166717 6.071251426444377 35.666706854087415 139.74762070814202 6.071251426444377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b0e4561d-0f20-4fc8-a990-f69e83c5040b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_41ccb27f-0634-4aa6-be03-54d28aa70f75">
											<gml:posList>35.66661808709987 139.7477060817267 6.071251426444377 35.666720410832845 139.74766081524973 6.071251426444377 35.66669001956352 139.74774534596776 6.071251426444377 35.66661808709987 139.7477060817267 6.071251426444377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_1b94bbb9-9abb-4321-afe6-1ec91b51b676">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2e005b0d-28d5-48d9-8da1-170196675195">
									<gml:exterior>
										<gml:LinearRing gml:id="line_639b53e3-0f78-4d32-a190-9526e4b3259e">
											<gml:posList>35.66669044960785 139.74774292031765 27.61948445867094 35.66669572221696 139.74772825499952 27.61948445867094 35.666690819797786 139.74774312015376 27.61948445867094 35.66669044960785 139.74774292031765 27.61948445867094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_27f61e13-a080-4452-a1a5-5dc92c9eebf4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1c46a147-011e-4d53-98cd-caaac1901ba9">
											<gml:posList>35.666690819797786 139.74774312015376 27.61948445867094 35.66669572221696 139.74772825499952 27.61948445867094 35.666696092407044 139.74772845500408 27.61948445867094 35.666690819797786 139.74774312015376 27.61948445867094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_4a981f85-2b80-4a62-ae65-00ed81e85da4">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_582d4bf5-ee9d-4c30-98ee-f22046a6c693">
									<gml:exterior>
										<gml:LinearRing gml:id="line_43ae7652-7e5c-45ac-bf52-6a1d5a7d5179">
											<gml:posList>35.66671636512583 139.74764884614584 12.13176015447172 35.6667052548605 139.7476230814457 12.13176015447172 35.666706854087415 139.74762070814202 12.13176015447172 35.66671636512583 139.74764884614584 12.13176015447172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e784e605-02a1-4d35-8cd4-f4d55c39e1d8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_52b1cc9a-fcf0-4a0d-b2cd-d59374d99b4f">
											<gml:posList>35.6667052548605 139.7476230814457 12.13176015447172 35.66671636512583 139.74764884614584 12.13176015447172 35.66671431537042 139.74764988674087 12.13176015447172 35.6667052548605 139.7476230814457 12.13176015447172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_99e5a163-c61b-42ff-8cbd-ca292882e630">
									<gml:exterior>
										<gml:LinearRing gml:id="line_16b20585-2afd-4d4f-af33-5affad897979">
											<gml:posList>35.666706854087415 139.74762070814202 12.13176015447172 35.6667052548605 139.7476230814457 12.13176015447172 35.666652572593925 139.74759643403618 12.13176015447172 35.666706854087415 139.74762070814202 12.13176015447172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_25a94d8e-7e81-4135-be02-49642ff838ce">
									<gml:exterior>
										<gml:LinearRing gml:id="line_461e03de-8852-40a7-841e-a4bf61b270de">
											<gml:posList>35.666652572593925 139.74759643403618 12.13176015447172 35.6667052548605 139.7476230814457 12.13176015447172 35.666651760958615 139.74759915959788 12.13176015447172 35.666652572593925 139.74759643403618 12.13176015447172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_d7879375-ab86-45ff-b140-70ce129ebfab">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4f67ef12-bcaf-45c7-a3c4-1ea172dd0957">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8d7be4e2-02a5-48c6-9740-1634330f559a">
											<gml:posList>35.66669572221696 139.74772825499952 27.143883262381877 35.66669044960785 139.74774292031765 27.143883262381877 35.66669471387756 139.74772771066495 27.143883262381877 35.66669572221696 139.74772825499952 27.143883262381877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9414ff17-e010-4e29-bd59-875be0b61a05">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d6b83a00-1577-4d60-b4fd-6a48ea508092">
											<gml:posList>35.66669471387756 139.74772771066495 27.143883262381877 35.66669044960785 139.74774292031765 27.143883262381877 35.666689441268524 139.74774237598297 27.143883262381877 35.66669471387756 139.74772771066495 27.143883262381877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_1cf53e24-94b1-4cb5-838e-efdefcffaebd">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3f9d382f-4c19-4ff8-9945-f1ad9f4f4ece">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4d5b6655-dc60-4a7b-839d-422973f82d04">
											<gml:posList>35.66666928904278 139.74760961085764 8.479500327811564 35.666652572593925 139.74759643403618 8.479500327811564 35.6666852861736 139.74761676466275 8.479500327811564 35.66666928904278 139.74760961085764 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cb25259a-2711-48ee-8af6-d10d9017950f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_019ab6cf-4e11-4543-98fd-e59f0e09993d">
											<gml:posList>35.666652572593925 139.74759643403618 8.479500327811564 35.66666928904278 139.74760961085764 8.479500327811564 35.66665107428787 139.74760146551807 8.479500327811564 35.666652572593925 139.74759643403618 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_66875a1a-1b51-4a76-bbef-c2c9b7ca7770">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2071081f-8396-4e35-a2fa-226e585cdba2">
											<gml:posList>35.6666852861736 139.74761676466275 8.479500327811564 35.666652572593925 139.74759643403618 8.479500327811564 35.666705109610035 139.74761992795868 8.479500327811564 35.6666852861736 139.74761676466275 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d35fdd0b-ea9e-4d7f-92a1-38a47a2a2f6c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cb65e488-2768-4c67-bdf6-b38b87e2383b">
											<gml:posList>35.6666852861736 139.74761676466275 8.479500327811564 35.666705109610035 139.74761992795868 8.479500327811564 35.66670361133738 139.7476249594434 8.479500327811564 35.6666852861736 139.74761676466275 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e54215a4-4286-4760-ae09-a81cb2d5053a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_57f44465-d625-4190-8680-5c5be5905c07">
											<gml:posList>35.666683058042565 139.74762424672483 8.479500327811564 35.66666928904278 139.74760961085764 8.479500327811564 35.6666852861736 139.74761676466275 8.479500327811564 35.666683058042565 139.74762424672483 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_55cdc1f6-b648-4eb5-acb4-ca365a2af717">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cef4cee2-9ad9-4a3c-8cc3-808463b8f152">
											<gml:posList>35.66666928904278 139.74760961085764 8.479500327811564 35.666683058042565 139.74762424672483 8.479500327811564 35.66666706094667 139.7476170930869 8.479500327811564 35.66666928904278 139.74760961085764 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_373e75f8-851d-42ba-a540-14149974efc7">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_f6d87125-92d9-4f87-b314-dc9e852e3638">
											<gml:exterior>
												<gml:LinearRing gml:id="line_0a667c28-6ac3-438a-9f56-35d4ed471d36">
													<gml:posList>35.66666706094667 139.7476170930869 6.329262290702189 35.66666706094667 139.7476170930869 8.479500327811564 35.666683058042565 139.74762424672483 6.329262290702189 35.66666706094667 139.7476170930869 6.329262290702189</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_05d9f771-76f2-47fb-b6ec-d291eaf2fd87">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e7939800-5c0c-4f6e-9537-a4c22156e6bd">
													<gml:posList>35.666683058042565 139.74762424672483 6.329262290702189 35.66666706094667 139.7476170930869 8.479500327811564 35.666683058042565 139.74762424672483 8.479500327811564 35.666683058042565 139.74762424672483 6.329262290702189</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_b70e7269-5e2e-42f7-9b66-3ec44384106a">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_9ba75005-4b48-46ea-a685-163fdc327123">
											<gml:exterior>
												<gml:LinearRing gml:id="line_17faee5f-ef64-4fb2-a0ba-dc082e7c2895">
													<gml:posList>35.66666928904278 139.74760961085764 8.479500327811564 35.66666706094667 139.7476170930869 8.479500327811564 35.66666928904278 139.74760961085764 6.329262290702189 35.66666928904278 139.74760961085764 8.479500327811564</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_47f391b8-5895-4706-a87c-6e66911a365c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_c71ae261-be7b-4070-9220-83b4478990ea">
													<gml:posList>35.66666928904278 139.74760961085764 6.329262290702189 35.66666706094667 139.7476170930869 8.479500327811564 35.66666706094667 139.7476170930869 6.329262290702189 35.66666928904278 139.74760961085764 6.329262290702189</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_20aaad0f-4825-47fe-b2bf-286d0ce964dd">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_10e907ad-1477-455b-afa3-674d93bbfd32">
											<gml:exterior>
												<gml:LinearRing gml:id="line_2235c65e-cffa-4864-9b1c-e69f8162f061">
													<gml:posList>35.6666852861736 139.74761676466275 8.479500327811564 35.6666852861736 139.74761676466275 6.329262290702189 35.666683058042565 139.74762424672483 8.479500327811564 35.6666852861736 139.74761676466275 8.479500327811564</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_a5d55171-924c-4bc1-a972-6cbfc04b304e">
											<gml:exterior>
												<gml:LinearRing gml:id="line_f15e9c1e-c67b-43f9-8e82-e99ba9a5b797">
													<gml:posList>35.666683058042565 139.74762424672483 8.479500327811564 35.6666852861736 139.74761676466275 6.329262290702189 35.666683058042565 139.74762424672483 6.329262290702189 35.666683058042565 139.74762424672483 8.479500327811564</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_4134c887-2ce2-4fe9-94ce-b38e33bb8864">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c09555ee-4642-4111-8501-646b135ac36f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dc7d032b-4cc8-4791-9e7d-75962513df63">
											<gml:posList>35.66669074176127 139.74774333715422 8.420250449881877 35.666686201521316 139.747734023496 8.420250449881877 35.66669662610225 139.74772697056582 8.420250449881877 35.66669074176127 139.74774333715422 8.420250449881877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_08b3068e-68dd-42d7-ac19-f67ef900e827">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d3fb6a60-53ec-4886-a117-a16ab1f2e2ea">
											<gml:posList>35.666686201521316 139.747734023496 8.420250449881877 35.66669074176127 139.74774333715422 8.420250449881877 35.66668413533931 139.74773977038203 8.420250449881877 35.666686201521316 139.747734023496 8.420250449881877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e70df01a-b2f9-4d6c-8d8d-d593b3eda8cc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0937e922-e759-4fd6-9d84-61a769b0148f">
											<gml:posList>35.66669662610225 139.74772697056582 8.420250449881877 35.666686201521316 139.747734023496 8.420250449881877 35.66669001964531 139.74772340362622 8.420250449881877 35.66669662610225 139.74772697056582 8.420250449881877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_fd03aae2-cb1b-4299-8026-36b5a79fc8be">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8eb78dfc-92a1-4a62-8829-7d0ac82ea220">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d8fc38f0-edd4-4a78-8109-e924dcf11db4">
											<gml:posList>35.66670775896889 139.74762338518366 8.479500327811564 35.66671636512583 139.74764884614584 8.479500327811564 35.66670495364263 139.7476248091836 8.479500327811564 35.66670775896889 139.74762338518366 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2fdc827c-9840-4fa3-b7cc-51afb95f4433">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4ec84649-ba7b-4ee9-822f-d6d13522af2e">
											<gml:posList>35.66670495364263 139.7476248091836 8.479500327811564 35.66671636512583 139.74764884614584 8.479500327811564 35.66671355981645 139.74765027014502 8.479500327811564 35.66670495364263 139.7476248091836 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_414f83cc-427c-4c4c-98b6-531c8c5cdae5">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_541c4f8e-ef18-4619-acb5-db6ce1c3ae7c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8b9307bf-cab5-4e9f-9498-669c4d2ec7a9">
											<gml:posList>35.666720410832845 139.74766081524973 34.72238210271391 35.666696773400346 139.74764675858478 34.72238210271391 35.666671789768614 139.74772846139706 34.72238210271391 35.666720410832845 139.74766081524973 34.72238210271391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_15573569-34d9-475f-ac27-9a2201542917">
									<gml:exterior>
										<gml:LinearRing gml:id="line_38655641-4a72-4137-8efd-66bd95a6c42d">
											<gml:posList>35.666696773400346 139.74764675858478 34.72238210271391 35.666720410832845 139.74766081524973 34.72238210271391 35.66671902256926 139.74765670811493 34.72238210271391 35.666696773400346 139.74764675858478 34.72238210271391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_58175808-231f-495e-b8e8-9d41ba0e5d94">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bdef4dc9-c62a-43e7-9c7e-41b95814c91a">
											<gml:posList>35.666720410832845 139.74766081524973 34.72238210271391 35.666671789768614 139.74772846139706 34.72238210271391 35.666692724279116 139.74773782311746 34.72238210271391 35.666720410832845 139.74766081524973 34.72238210271391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0179_p1044_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0179_p1044_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0179_p1044_0">
											<gml:posList>35.66665551981085 139.7476623417708 30.02709478 35.66667070458894 139.74766926934868 30.02777993 35.66667846969814 139.747643709672 30.02793432 35.66666328491869 139.74763678209828 30.02724917 35.66665551981085 139.7476623417708 30.02709478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_e67ee351-3878-4c19-929c-eec0399da84e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_842a11b0-d81b-46a4-96c1-f9211bfbdb1b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1991802f-3647-4083-a53e-88b002e1ce80">
											<gml:posList>35.66665631830354 139.74766283597904 30.31375936101469 35.66667055196773 139.74766920103403 30.31375936101469 35.66666260029714 139.74764174061275 30.31375936101469 35.66665631830354 139.74766283597904 30.31375936101469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_13cc06ff-a1c4-4b36-ab37-a06a95c1d105">
									<gml:exterior>
										<gml:LinearRing gml:id="line_be027910-92a1-406e-8d56-5c34e22fa1cd">
											<gml:posList>35.66666260029714 139.74764174061275 30.31375936101469 35.66667055196773 139.74766920103403 30.31375936101469 35.66667683396241 139.74764810566452 30.31375936101469 35.66666260029714 139.74764174061275 30.31375936101469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0179_p1042_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0179_p1042_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0179_p1042_0">
											<gml:posList>35.666678475524805 139.74764371107 28.32293445 35.66668246903244 139.74763056600932 28.32301422 35.66664646392674 139.747614139833 28.32139048 35.66661990607198 139.7477015577654 28.32086471 35.66664013370857 139.7477130072455 28.3217917 35.666655525631384 139.7476623431738 28.32209491 35.666663290741305 139.74763678349453 28.3222493 35.666678475524805 139.74764371107 28.32293445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0179_p1042_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0179_p1042_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0179_p1042_1">
											<gml:posList>35.66667503846401 139.7477259133297 28.32334676 35.66669920672592 139.74764636100608 28.32382486 35.66672194738167 139.74765673571733 28.32485282 35.66672412436544 139.74764956994056 28.32489634 35.66668246903244 139.74763056600932 28.32301422 35.666678475524805 139.74764371107 28.32293445 35.666670710413534 139.74766927075356 28.32278005 35.666655525631384 139.7476623431738 28.32209491 35.66664013370857 139.7477130072455 28.3217917 35.66669535577659 139.7477442647096 28.3243273 35.66669777911302 139.7477362880604 28.32437472 35.66667503846401 139.7477259133297 28.32334676</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_ad86bed9-6bbf-4950-8102-212d6fb88bef">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d4ea32b2-257c-40a3-913a-aedf25b6d21a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_35a4b1b9-9c81-4d0f-9d77-e9883b589123">
											<gml:posList>35.66665039799914 139.74759546166717 13.22275594304594 35.66664646996413 139.74761608781733 13.22275594304594 35.666706854087415 139.74762070814202 13.22275594304594 35.66665039799914 139.74759546166717 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2608c10f-79ef-4bb1-8196-4dd6e2021a89">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a27a4f12-9b8c-45b7-a912-80849a2d22e7">
											<gml:posList>35.66664646996413 139.74761608781733 13.22275594304594 35.66665039799914 139.74759546166717 13.22275594304594 35.666644615592695 139.74761525853708 13.22275594304594 35.66664646996413 139.74761608781733 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_24b62a27-a9cf-44bf-b6a7-22e739e93f83">
									<gml:exterior>
										<gml:LinearRing gml:id="line_05cd1f14-a32c-49f0-bd7d-aa9fe8e78396">
											<gml:posList>35.666706854087415 139.74762070814202 13.22275594304594 35.66664646996413 139.74761608781733 13.22275594304594 35.66669944514227 139.74763977763737 13.22275594304594 35.666706854087415 139.74762070814202 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5e9f4b26-837f-4bdf-b932-b1dce040fb68">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aac5d887-ffb6-43c2-a336-1ee7a2065dd5">
											<gml:posList>35.666706854087415 139.74762070814202 13.22275594304594 35.66669944514227 139.74763977763737 13.22275594304594 35.666715766983046 139.74764707655842 13.22275594304594 35.666706854087415 139.74762070814202 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_3ee1b475-dd48-4553-85eb-61420c9fc23e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_01b059b4-7e1a-4d1a-9270-d28316e1dc2b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8d97aa94-e6dd-474d-bc8c-2cff3e9e2c51">
											<gml:posList>35.66665631830354 139.74766283597904 28.571503196463908 35.66661808709987 139.7477060817267 28.571503196463908 35.666671789768614 139.74772846139706 28.571503196463908 35.66665631830354 139.74766283597904 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e378b096-4b15-4ae0-aced-a5ae0509102c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4499518e-6d07-4b5a-aac1-1c15fd1524e9">
											<gml:posList>35.66661808709987 139.7477060817267 28.571503196463908 35.66665631830354 139.74766283597904 28.571503196463908 35.666644615592695 139.74761525853708 28.571503196463908 35.66661808709987 139.7477060817267 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_599bda34-4bde-4aba-be36-5a7dabc233f2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_48bc1525-34fb-4899-9615-89cf04012162">
											<gml:posList>35.666671789768614 139.74772846139706 28.571503196463908 35.66661808709987 139.7477060817267 28.571503196463908 35.66669001956352 139.74774534596776 28.571503196463908 35.666671789768614 139.74772846139706 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0779fbf4-ad6b-4040-b7b8-57e498c1e458">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b1e48776-c64c-42b4-afaa-aee16fa7b9c3">
											<gml:posList>35.66665631830354 139.74766283597904 28.571503196463908 35.666671789768614 139.74772846139706 28.571503196463908 35.66667055196773 139.74766920103403 28.571503196463908 35.66665631830354 139.74766283597904 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c50225ce-9f34-4304-ae1e-9aad69c6495e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b69398d5-96b0-4b25-a144-18d4d6d63ba7">
											<gml:posList>35.66667055196773 139.74766920103403 28.571503196463908 35.666671789768614 139.74772846139706 28.571503196463908 35.666696773400346 139.74764675858478 28.571503196463908 35.66667055196773 139.74766920103403 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_665b6501-fb8f-444e-a081-6e92e096b9fe">
									<gml:exterior>
										<gml:LinearRing gml:id="line_edded40e-ee84-4d2b-a5a3-14be7a9bcd94">
											<gml:posList>35.666671789768614 139.74772846139706 28.571503196463908 35.66669001956352 139.74774534596776 28.571503196463908 35.666692724279116 139.74773782311746 28.571503196463908 35.666671789768614 139.74772846139706 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eec9ca83-40d1-4f7a-a15b-09cd8259286f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6b7bf737-1b46-4bea-8f84-5d18b46d8011">
											<gml:posList>35.666644615592695 139.74761525853708 28.571503196463908 35.66666260029714 139.74764174061275 28.571503196463908 35.66667683396241 139.74764810566452 28.571503196463908 35.666644615592695 139.74761525853708 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fedea1fe-2d54-4e66-93f2-806a09ab4f7f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cf1cce75-dfe0-401e-9c69-290880e0810b">
											<gml:posList>35.66666260029714 139.74764174061275 28.571503196463908 35.666644615592695 139.74761525853708 28.571503196463908 35.66665631830354 139.74766283597904 28.571503196463908 35.66666260029714 139.74764174061275 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_56f21506-a2a5-4925-964f-ee6f7c1298cf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c7fc33a1-91ae-4e8a-9264-1e9602fb44c7">
											<gml:posList>35.666696773400346 139.74764675858478 28.571503196463908 35.666644615592695 139.74761525853708 28.571503196463908 35.66667683396241 139.74764810566452 28.571503196463908 35.666696773400346 139.74764675858478 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_747df37c-0335-4bf9-940a-ddd9837212ff">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b8ce4427-0948-42f8-8738-b5a2b005bd21">
											<gml:posList>35.666644615592695 139.74761525853708 28.571503196463908 35.666696773400346 139.74764675858478 28.571503196463908 35.666715766983046 139.74764707655842 28.571503196463908 35.666644615592695 139.74761525853708 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bd4d8cb2-901b-4983-aeca-7975c8ef6a11">
									<gml:exterior>
										<gml:LinearRing gml:id="line_21510c27-6b77-490f-8b90-66d3ea4369d3">
											<gml:posList>35.666696773400346 139.74764675858478 28.571503196463908 35.66667683396241 139.74764810566452 28.571503196463908 35.66667055196773 139.74766920103403 28.571503196463908 35.666696773400346 139.74764675858478 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_05e120df-056f-4c2a-8b22-940334b172d6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9f735b24-9487-40fc-90b7-e92b92dfe361">
											<gml:posList>35.666715766983046 139.74764707655842 28.571503196463908 35.666696773400346 139.74764675858478 28.571503196463908 35.66671902256926 139.74765670811493 28.571503196463908 35.666715766983046 139.74764707655842 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0179_p1043_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0179_p1043_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0179_p1043_0">
											<gml:posList>35.666675018219074 139.74772590839518 34.24834632 35.66669775884681 139.7477362831162 34.24937428 35.66672192709298 139.74765673084693 34.24985238 35.66669918645841 139.7476463561453 34.24882441 35.666675018219074 139.74772590839518 34.24834632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_d9767a50-aa89-42b9-98cc-951df38325b5">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d65b7f01-3181-443c-9a4e-f4510748ce8a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_453c9d77-f651-43ef-9ca0-83b7ff755248">
											<gml:posList>35.666715766983046 139.74764707655842 28.571503196463908 35.66669944514227 139.74763977763737 27.049149070487346 35.666644615592695 139.74761525853708 28.571503196463908 35.666715766983046 139.74764707655842 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d13618f2-4a68-444f-8c26-c8b8b5a603d5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_93753110-0d09-421a-a831-bee71b82c339">
											<gml:posList>35.66669944514227 139.74763977763737 27.049149070487346 35.666715766983046 139.74764707655842 28.571503196463908 35.66669944514227 139.74763977763737 25.426666770682658 35.66669944514227 139.74763977763737 27.049149070487346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b74ba1ec-ad12-4b1e-b627-9e247b5aa1db">
									<gml:exterior>
										<gml:LinearRing gml:id="line_73c0047e-854a-4465-9d0e-53399634d087">
											<gml:posList>35.666644615592695 139.74761525853708 28.571503196463908 35.66669944514227 139.74763977763737 27.049149070487346 35.66664646996413 139.74761608781733 27.049149070487346 35.666644615592695 139.74761525853708 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_84abdb7a-c604-4e47-9093-633b78051dc9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5d107731-9a11-41c8-864b-0ecf9c64e554">
											<gml:posList>35.666644615592695 139.74761525853708 28.571503196463908 35.66664646996413 139.74761608781733 27.049149070487346 35.66664646996413 139.74761608781733 25.426666770682658 35.666644615592695 139.74761525853708 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8105634b-7d22-44b1-9646-1dfaaf314cc5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_af0fe2f2-8c9b-4355-a105-3d142e799d34">
											<gml:posList>35.666644615592695 139.74761525853708 28.571503196463908 35.66664646996413 139.74761608781733 25.426666770682658 35.66664646996413 139.74761608781733 24.034744773612346 35.666644615592695 139.74761525853708 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_af822873-e4da-4458-a483-7986c1d95686">
									<gml:exterior>
										<gml:LinearRing gml:id="line_72cd1530-493b-40b0-9aa6-aa4532185ecc">
											<gml:posList>35.666644615592695 139.74761525853708 28.571503196463908 35.66664646996413 139.74761608781733 24.034744773612346 35.66664646996413 139.74761608781733 22.412262473807658 35.666644615592695 139.74761525853708 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_82373033-f854-443e-85a1-d34c6eec9420">
									<gml:exterior>
										<gml:LinearRing gml:id="line_601287aa-f7f6-472a-b654-36aaaad7ad33">
											<gml:posList>35.666644615592695 139.74761525853708 28.571503196463908 35.66664646996413 139.74761608781733 22.412262473807658 35.66664646996413 139.74761608781733 21.032074485526408 35.666644615592695 139.74761525853708 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1a08e143-8494-41a5-bd50-253dc7a8be49">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b32461c7-e219-445c-b95c-11f3a30e63e6">
											<gml:posList>35.666644615592695 139.74761525853708 28.571503196463908 35.66664646996413 139.74761608781733 21.032074485526408 35.666644615592695 139.74761525853708 13.22275594304594 35.666644615592695 139.74761525853708 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b1506d46-3233-4f8f-9389-181f99a95711">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4f8f62f8-54c7-4df6-b055-ae6328e173bf">
											<gml:posList>35.666644615592695 139.74761525853708 13.22275594304594 35.66664646996413 139.74761608781733 19.40959218572172 35.66664646996413 139.74761608781733 18.088318382010783 35.666644615592695 139.74761525853708 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bb93ef7f-e260-4376-87f4-b783aa5628e8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_91f60fd2-baed-43f5-a920-46daa408ee14">
											<gml:posList>35.66664646996413 139.74761608781733 19.40959218572172 35.666644615592695 139.74761525853708 13.22275594304594 35.66664646996413 139.74761608781733 21.032074485526408 35.66664646996413 139.74761608781733 19.40959218572172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a17b84ee-8b7c-4b0a-8ffb-c6dd1624560d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_05d2a509-c8ef-42e5-9053-89fe281315c5">
											<gml:posList>35.666644615592695 139.74761525853708 13.22275594304594 35.66664646996413 139.74761608781733 18.088318382010783 35.66664646996413 139.74761608781733 16.465836082206096 35.666644615592695 139.74761525853708 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9f45f8b7-8deb-44d6-a595-be71ff21f670">
									<gml:exterior>
										<gml:LinearRing gml:id="line_181877cc-c033-4319-8003-1c8cbc0579a5">
											<gml:posList>35.666644615592695 139.74761525853708 13.22275594304594 35.66664646996413 139.74761608781733 16.465836082206096 35.66664646996413 139.74761608781733 15.024490867362346 35.666644615592695 139.74761525853708 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bcb804f7-3e2b-410f-ac15-e4c44bbe1864">
									<gml:exterior>
										<gml:LinearRing gml:id="line_857c5c27-df3c-4c83-a565-bb4ef7aa71f2">
											<gml:posList>35.666644615592695 139.74761525853708 13.22275594304594 35.66664646996413 139.74761608781733 15.024490867362346 35.66664646996413 139.74761608781733 13.22275594304594 35.666644615592695 139.74761525853708 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1b156d6f-0018-4d81-867f-221a12aeedf1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_90cc86da-1c2c-4b6a-97cf-29f005590df2">
											<gml:posList>35.66664646996413 139.74761608781733 25.426666770682658 35.66669944514227 139.74763977763737 24.034744773612346 35.66664646996413 139.74761608781733 24.034744773612346 35.66664646996413 139.74761608781733 25.426666770682658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eab26731-6a33-4ec8-a7c4-accaa094a38e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cdbe847d-7615-4d24-9da6-a38ae0281392">
											<gml:posList>35.66669944514227 139.74763977763737 24.034744773612346 35.66664646996413 139.74761608781733 25.426666770682658 35.66669944514227 139.74763977763737 25.426666770682658 35.66669944514227 139.74763977763737 24.034744773612346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2693fb7a-71d6-4bdb-a26e-6b93566d7700">
									<gml:exterior>
										<gml:LinearRing gml:id="line_62db2f61-94b4-4d05-9de5-066316fc61fe">
											<gml:posList>35.66669944514227 139.74763977763737 22.412262473807658 35.66669944514227 139.74763977763737 21.032074485526408 35.66664646996413 139.74761608781733 22.412262473807658 35.66669944514227 139.74763977763737 22.412262473807658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f813eeb2-b876-446d-ae2d-325f3c3b28aa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7ed31a80-dbda-4356-9680-299216368479">
											<gml:posList>35.66669944514227 139.74763977763737 21.032074485526408 35.66669944514227 139.74763977763737 22.412262473807658 35.666715766983046 139.74764707655842 28.571503196463908 35.66669944514227 139.74763977763737 21.032074485526408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ffefe966-3758-495b-b292-1fa0c20491e2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5ad5d356-fb4d-4047-a639-238ddc7d561a">
											<gml:posList>35.66664646996413 139.74761608781733 22.412262473807658 35.66669944514227 139.74763977763737 21.032074485526408 35.66664646996413 139.74761608781733 21.032074485526408 35.66664646996413 139.74761608781733 22.412262473807658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d36d2cff-f4d0-425b-893d-26a9d2cbed8b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_620402bb-84d0-4ecd-a2b0-ec461d5edd6c">
											<gml:posList>35.66669944514227 139.74763977763737 24.034744773612346 35.666715766983046 139.74764707655842 28.571503196463908 35.66669944514227 139.74763977763737 22.412262473807658 35.66669944514227 139.74763977763737 24.034744773612346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ba7ac957-d349-49c3-89d2-959aac2d5445">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8801e49c-5dc6-4f9c-b090-ed964f6af746">
											<gml:posList>35.666715766983046 139.74764707655842 28.571503196463908 35.66669944514227 139.74763977763737 24.034744773612346 35.66669944514227 139.74763977763737 25.426666770682658 35.666715766983046 139.74764707655842 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6c6a4af8-7c6b-48fd-8993-d8db62f31d23">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9cf763a2-f517-4dd8-a9b3-cc58d9bec21d">
											<gml:posList>35.66669944514227 139.74763977763737 15.024490867362346 35.666715766983046 139.74764707655842 13.22275594304594 35.66669944514227 139.74763977763737 13.22275594304594 35.66669944514227 139.74763977763737 15.024490867362346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9a3e5591-9eef-4ae8-a12e-afc0f629381b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6c47da90-e826-49b5-be60-8fa703b24753">
											<gml:posList>35.666715766983046 139.74764707655842 13.22275594304594 35.66669944514227 139.74763977763737 15.024490867362346 35.66669944514227 139.74763977763737 16.465836082206096 35.666715766983046 139.74764707655842 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_14c11e8a-4435-470b-95eb-49a4bd523286">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d5c2faef-aefc-495d-895c-f9649411cfb5">
											<gml:posList>35.66669944514227 139.74763977763737 19.40959218572172 35.666715766983046 139.74764707655842 13.22275594304594 35.66669944514227 139.74763977763737 18.088318382010783 35.66669944514227 139.74763977763737 19.40959218572172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_83710c6c-428a-4f27-8676-cf0993279988">
									<gml:exterior>
										<gml:LinearRing gml:id="line_61f940e9-94fd-4530-ba8a-047afbbc3b0e">
											<gml:posList>35.666715766983046 139.74764707655842 13.22275594304594 35.66669944514227 139.74763977763737 19.40959218572172 35.66669944514227 139.74763977763737 21.032074485526408 35.666715766983046 139.74764707655842 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cd3e6d18-3fc3-4e42-8e2d-707348c7347f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_13e0133b-2ce5-4e13-a3c2-77061f658956">
											<gml:posList>35.66669944514227 139.74763977763737 21.032074485526408 35.666715766983046 139.74764707655842 28.571503196463908 35.666715766983046 139.74764707655842 13.22275594304594 35.66669944514227 139.74763977763737 21.032074485526408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2a279b8c-3231-4933-b1d8-357c4e19a3c9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_207d6a90-e32d-4a6b-b726-e28a441e7b1c">
											<gml:posList>35.66669944514227 139.74763977763737 16.465836082206096 35.66669944514227 139.74763977763737 15.024490867362346 35.66664646996413 139.74761608781733 15.024490867362346 35.66669944514227 139.74763977763737 16.465836082206096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4cbce12c-bbad-40a3-9916-a9f4e7e7794b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_83ab8a5b-b176-403f-8a74-e2ad08629517">
											<gml:posList>35.66669944514227 139.74763977763737 16.465836082206096 35.66664646996413 139.74761608781733 15.024490867362346 35.66664646996413 139.74761608781733 16.465836082206096 35.66669944514227 139.74763977763737 16.465836082206096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9802f4ae-6ef9-4bc3-a363-3a8e7cc5f29f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_11c27871-d7a8-4847-8538-648433db2e16">
											<gml:posList>35.66669944514227 139.74763977763737 19.40959218572172 35.66669944514227 139.74763977763737 18.088318382010783 35.66664646996413 139.74761608781733 19.40959218572172 35.66669944514227 139.74763977763737 19.40959218572172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9d28b03c-7a93-4cc2-86ba-63f65874536b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5b4d90f2-f8f6-43fe-bdfb-4ca61f981e35">
											<gml:posList>35.66664646996413 139.74761608781733 19.40959218572172 35.66669944514227 139.74763977763737 18.088318382010783 35.66664646996413 139.74761608781733 18.088318382010783 35.66664646996413 139.74761608781733 19.40959218572172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_42c53384-911e-47f1-b124-8ae1c2eb3112">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4f9771cc-3036-465b-b715-19c43b87812f">
											<gml:posList>35.666715766983046 139.74764707655842 13.22275594304594 35.66669944514227 139.74763977763737 16.465836082206096 35.66669944514227 139.74763977763737 18.088318382010783 35.666715766983046 139.74764707655842 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_06ace17e-1a96-4269-9c19-a2540ba28051">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_7e01aaa8-15c7-4e28-a58a-60f3f413e442">
											<gml:exterior>
												<gml:LinearRing gml:id="line_b5fe6e78-e2e4-4587-85e2-e133c4b45021">
													<gml:posList>35.66664646996413 139.74761608781733 15.024490867362346 35.66669944514227 139.74763977763737 15.024490867362346 35.66669944514227 139.74763977763737 13.22275594304594 35.66664646996413 139.74761608781733 15.024490867362346</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_39219e4e-6135-4d0c-b17e-9b47f82fa119">
											<gml:exterior>
												<gml:LinearRing gml:id="line_70a7b6bb-ebcf-4500-954e-15deef5f3f26">
													<gml:posList>35.66664646996413 139.74761608781733 15.024490867362346 35.66669944514227 139.74763977763737 13.22275594304594 35.66664646996413 139.74761608781733 13.22275594304594 35.66664646996413 139.74761608781733 15.024490867362346</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_52e8cd61-a92a-4797-9630-c1d6aa959f18">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_b04cb261-e919-45d0-b146-91962ee0ccb5">
											<gml:exterior>
												<gml:LinearRing gml:id="line_049b04a8-1687-4d0d-8f78-da153b2f9cd2">
													<gml:posList>35.66664646996413 139.74761608781733 18.088318382010783 35.66669944514227 139.74763977763737 18.088318382010783 35.66664646996413 139.74761608781733 16.465836082206096 35.66664646996413 139.74761608781733 18.088318382010783</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_34ba306c-ee26-4147-bf3a-54b912725100">
											<gml:exterior>
												<gml:LinearRing gml:id="line_06a648e2-421c-4ab8-aac6-ea7c8470ba08">
													<gml:posList>35.66664646996413 139.74761608781733 16.465836082206096 35.66669944514227 139.74763977763737 18.088318382010783 35.66669944514227 139.74763977763737 16.465836082206096 35.66664646996413 139.74761608781733 16.465836082206096</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_82d5c1ca-33b2-4379-a74a-772fa3aec1b3">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_68049947-55ad-4eb0-b199-9b802f6adfe3">
											<gml:exterior>
												<gml:LinearRing gml:id="line_657a0cc8-c588-4fcb-a67b-bdea47bc5289">
													<gml:posList>35.66664646996413 139.74761608781733 21.032074485526408 35.66669944514227 139.74763977763737 21.032074485526408 35.66664646996413 139.74761608781733 19.40959218572172 35.66664646996413 139.74761608781733 21.032074485526408</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_c025359a-9c47-4270-a1c4-150b749eee45">
											<gml:exterior>
												<gml:LinearRing gml:id="line_8f7005a2-3f4d-41e8-8452-2758efc16a1f">
													<gml:posList>35.66664646996413 139.74761608781733 19.40959218572172 35.66669944514227 139.74763977763737 21.032074485526408 35.66669944514227 139.74763977763737 19.40959218572172 35.66664646996413 139.74761608781733 19.40959218572172</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_961e178b-7532-4663-8c11-5c97da5dbbc0">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_1f63cfe1-9011-435b-bc8f-335e32251fd9">
											<gml:exterior>
												<gml:LinearRing gml:id="line_144fdd30-af05-439b-9529-122b7528e7b2">
													<gml:posList>35.66664646996413 139.74761608781733 24.034744773612346 35.66669944514227 139.74763977763737 24.034744773612346 35.66664646996413 139.74761608781733 22.412262473807658 35.66664646996413 139.74761608781733 24.034744773612346</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e3f37177-c82f-4dae-b850-0865b69a4ba9">
											<gml:exterior>
												<gml:LinearRing gml:id="line_3f3b4f0a-2be8-40f0-b3b8-012dde85ad06">
													<gml:posList>35.66664646996413 139.74761608781733 22.412262473807658 35.66669944514227 139.74763977763737 24.034744773612346 35.66669944514227 139.74763977763737 22.412262473807658 35.66664646996413 139.74761608781733 22.412262473807658</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_a4698d1a-3d76-485d-bf3d-09cd7b281ee2">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_18197c87-6d4a-49f2-828a-9025e616b0ae">
											<gml:exterior>
												<gml:LinearRing gml:id="line_db82e436-ce15-4955-b41d-3e645d3261d2">
													<gml:posList>35.66664646996413 139.74761608781733 27.049149070487346 35.66669944514227 139.74763977763737 27.049149070487346 35.66664646996413 139.74761608781733 25.426666770682658 35.66664646996413 139.74761608781733 27.049149070487346</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_d37cf1d9-d899-48e3-bdf6-863bb4af37a0">
											<gml:exterior>
												<gml:LinearRing gml:id="line_efab1fbf-ac3d-44aa-b650-69099350fa9d">
													<gml:posList>35.66664646996413 139.74761608781733 25.426666770682658 35.66669944514227 139.74763977763737 27.049149070487346 35.66669944514227 139.74763977763737 25.426666770682658 35.66664646996413 139.74761608781733 25.426666770682658</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0179_p1044_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0179_p1044_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0179_p1044_4">
											<gml:posList>35.66666328491869 139.74763678209828 30.02724917 35.666663290741305 139.74763678349453 28.3222493 35.666655525631384 139.7476623431738 28.32209491 35.66665551981085 139.7476623417708 30.02709478 35.66666328491869 139.74763678209828 30.02724917</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0179_p1042_5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0179_p1042_5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0179_p1042_5">
											<gml:posList>35.66661990607198 139.7477015577654 28.32086471 35.66664646392674 139.747614139833 28.32139048 35.66664654217216 139.74761415852856 5.39161777 35.66661998422161 139.74770157677486 5.391092 35.66661990607198 139.7477015577654 28.32086471</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_48169f60-6b69-4248-8f6b-53b17551240c">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7810ea3e-63a8-416c-be80-6db76443f87c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cc4bd043-15f6-4bac-96b8-14b3317bde46">
											<gml:posList>35.66671636512583 139.74764884614584 8.479500327811564 35.66671636512583 139.74764884614584 6.329262290702189 35.66671355981645 139.74765027014502 8.479500327811564 35.66671636512583 139.74764884614584 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a20b7363-f8d9-4ce1-9627-73cd3379a216">
									<gml:exterior>
										<gml:LinearRing gml:id="line_34c69c3e-c91f-4d56-b13b-c422fb5ff891">
											<gml:posList>35.66671355981645 139.74765027014502 8.479500327811564 35.66671636512583 139.74764884614584 6.329262290702189 35.66671355981645 139.74765027014502 6.329262290702189 35.66671355981645 139.74765027014502 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_1af0a037-9737-4422-95bf-ea67b21122aa">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3330f10a-852f-45e1-a1f5-6fd242681451">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1b95d35b-f32a-44b7-9116-7b8b38df9a37">
											<gml:posList>35.66665039799914 139.74759546166717 6.071251426444377 35.666652572593925 139.74759643403618 6.329262290702189 35.666706854087415 139.74762070814202 6.071251426444377 35.66665039799914 139.74759546166717 6.071251426444377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_793ead2f-93fb-4a2d-97a4-570ef9309af4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d1c1f81f-160a-49bb-bd1b-c79d7f124d53">
											<gml:posList>35.666652572593925 139.74759643403618 6.329262290702189 35.66665039799914 139.74759546166717 6.071251426444377 35.666652572593925 139.74759643403618 8.479500327811564 35.666652572593925 139.74759643403618 6.329262290702189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d927300b-7de1-4cd1-a5ec-ad48ee95a647">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0a47b400-b570-4e82-91c8-f356017c90d4">
											<gml:posList>35.666706854087415 139.74762070814202 6.071251426444377 35.666652572593925 139.74759643403618 6.329262290702189 35.666705109610035 139.74761992795868 6.329262290702189 35.666706854087415 139.74762070814202 6.071251426444377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3f87f76b-e910-44b3-a103-e86224f01650">
									<gml:exterior>
										<gml:LinearRing gml:id="line_02dd91e5-1511-4f56-a5af-2b4e973ac311">
											<gml:posList>35.666706854087415 139.74762070814202 6.071251426444377 35.666705109610035 139.74761992795868 6.329262290702189 35.666706854087415 139.74762070814202 8.479500327811564 35.666706854087415 139.74762070814202 6.071251426444377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b17ce35d-6849-4702-a2b4-33ecb087b724">
									<gml:exterior>
										<gml:LinearRing gml:id="line_10f772c3-2176-4e45-ab25-1644365fcd7c">
											<gml:posList>35.666706854087415 139.74762070814202 8.479500327811564 35.666705109610035 139.74761992795868 6.329262290702189 35.666705109610035 139.74761992795868 8.479500327811564 35.666706854087415 139.74762070814202 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c985bc53-abf0-4193-aaf6-8fab334f6698">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c28bb852-d7d3-4330-a772-a1b810feb486">
											<gml:posList>35.666706854087415 139.74762070814202 8.479500327811564 35.666705109610035 139.74761992795868 8.479500327811564 35.666706854087415 139.74762070814202 9.74887898992094 35.666706854087415 139.74762070814202 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b502abfd-09c7-4864-89a2-929aee1b9cb3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_64e63077-f519-4d78-8fe2-ecb367c7a335">
											<gml:posList>35.666652572593925 139.74759643403618 9.74887898992094 35.66665039799914 139.74759546166717 6.071251426444377 35.66665039799914 139.74759546166717 13.22275594304594 35.666652572593925 139.74759643403618 9.74887898992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_111d1397-d50e-49af-9bd4-d2d6a28b9486">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7d5c1778-8db8-48f2-9d67-7861e465e87f">
											<gml:posList>35.66665039799914 139.74759546166717 6.071251426444377 35.666652572593925 139.74759643403618 9.74887898992094 35.666652572593925 139.74759643403618 8.479500327811564 35.66665039799914 139.74759546166717 6.071251426444377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0eb06b38-5731-4903-b546-909cef21fe4e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_97e73332-e902-4324-8371-fb339c6d9d5e">
											<gml:posList>35.666652572593925 139.74759643403618 9.74887898992094 35.66665039799914 139.74759546166717 13.22275594304594 35.666652572593925 139.74759643403618 12.13176015447172 35.666652572593925 139.74759643403618 9.74887898992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d2fa5f68-caec-4133-910d-7ee09945d89e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d49ea3c5-6066-40a7-ade1-0b847c859429">
											<gml:posList>35.666652572593925 139.74759643403618 12.13176015447172 35.66665039799914 139.74759546166717 13.22275594304594 35.666706854087415 139.74762070814202 13.22275594304594 35.666652572593925 139.74759643403618 12.13176015447172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3b731670-dca0-408a-914d-10090e6c7d74">
									<gml:exterior>
										<gml:LinearRing gml:id="line_532a20f4-3b33-4386-9990-34d1b8b5a5e6">
											<gml:posList>35.666652572593925 139.74759643403618 12.13176015447172 35.666706854087415 139.74762070814202 13.22275594304594 35.666706854087415 139.74762070814202 12.13176015447172 35.666652572593925 139.74759643403618 12.13176015447172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_efd96b1d-62d1-4a27-a5d2-137bd17814fd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d5725620-6aa7-424e-9f57-b1f60349303c">
											<gml:posList>35.666705109610035 139.74761992795868 8.479500327811564 35.666652572593925 139.74759643403618 9.74887898992094 35.666706854087415 139.74762070814202 9.74887898992094 35.666705109610035 139.74761992795868 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0e3bc53c-1b47-4521-a4c2-a0ef1f4d65d7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d4e1a76d-d2e4-49b5-804a-efd929eaaaf0">
											<gml:posList>35.666652572593925 139.74759643403618 9.74887898992094 35.666705109610035 139.74761992795868 8.479500327811564 35.666652572593925 139.74759643403618 8.479500327811564 35.666652572593925 139.74759643403618 9.74887898992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_be8a416e-edcd-47c5-913c-60a39f11d855">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f8d3a16d-4429-4b7a-a191-ea705223d445">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7cd68fb4-a7bf-4010-ac76-477cf49c1a4d">
											<gml:posList>35.66671902256926 139.74765670811493 28.571503196463908 35.666696773400346 139.74764675858478 28.571503196463908 35.66671902256926 139.74765670811493 34.72238210271391 35.66671902256926 139.74765670811493 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1da31e5e-83ae-4d4b-af6c-a5d335954a63">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4e27b44d-b9fb-4cab-b992-62275cce7c3a">
											<gml:posList>35.66671902256926 139.74765670811493 34.72238210271391 35.666696773400346 139.74764675858478 28.571503196463908 35.666696773400346 139.74764675858478 34.72238210271391 35.66671902256926 139.74765670811493 34.72238210271391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_15af528c-e8f6-4b39-8bfa-0bbba6292c61">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d5c296e2-1a2e-4751-8121-1b7e8066102d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_af71ace1-370e-44dd-b65f-7383b86c93d0">
											<gml:posList>35.66667683396241 139.74764810566452 28.571503196463908 35.66666260029714 139.74764174061275 28.571503196463908 35.66667683396241 139.74764810566452 30.31375936101469 35.66667683396241 139.74764810566452 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2ad19cfe-3406-4d74-9c3b-7dc4e6bc56e5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fda3e8d9-c4c6-4e98-875d-cb9d7b75167c">
											<gml:posList>35.66667683396241 139.74764810566452 30.31375936101469 35.66666260029714 139.74764174061275 28.571503196463908 35.66666260029714 139.74764174061275 30.31375936101469 35.66667683396241 139.74764810566452 30.31375936101469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_85080af4-0ccd-4799-b391-c5ac5a2374b5">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7ea01c81-736c-4849-b276-9960912241dc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_83c42cc2-741c-4953-864a-17ed9ff5b975">
											<gml:posList>35.66669572221696 139.74772825499952 27.143883262381877 35.66669471387756 139.74772771066495 24.746124778495158 35.666696092407044 139.74772845500408 24.746124778495158 35.66669572221696 139.74772825499952 27.143883262381877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fb35415b-8791-4c68-a87d-5ad9338915c0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6609a880-e9ac-408f-a842-857838c28495">
											<gml:posList>35.66669471387756 139.74772771066495 24.746124778495158 35.66669572221696 139.74772825499952 27.143883262381877 35.66669471387756 139.74772771066495 27.143883262381877 35.66669471387756 139.74772771066495 24.746124778495158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_da352722-72f8-4185-915d-9de8e19cc884">
									<gml:exterior>
										<gml:LinearRing gml:id="line_95b84d58-b8de-4108-b32e-c7fd0a5a3b97">
											<gml:posList>35.66669572221696 139.74772825499952 27.143883262381877 35.666696092407044 139.74772845500408 24.746124778495158 35.666696092407044 139.74772845500408 27.61948445867094 35.66669572221696 139.74772825499952 27.143883262381877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_91b0486e-8a5b-48bd-85ab-c8b8a636e470">
									<gml:exterior>
										<gml:LinearRing gml:id="line_22cd4e56-1461-475e-8583-abb9d1d6fdfe">
											<gml:posList>35.66669572221696 139.74772825499952 27.143883262381877 35.666696092407044 139.74772845500408 27.61948445867094 35.66669572221696 139.74772825499952 27.61948445867094 35.66669572221696 139.74772825499952 27.143883262381877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_a3d003d8-7076-42d8-ac62-c827da192522">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_738436d8-8634-4608-820c-68739d70bd00">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0d4623ab-1d88-424f-b9c0-d48fb006e6b4">
											<gml:posList>35.66667055196773 139.74766920103403 28.571503196463908 35.66667683396241 139.74764810566452 28.571503196463908 35.66667055196773 139.74766920103403 30.31375936101469 35.66667055196773 139.74766920103403 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c44124bf-93d7-4567-b89e-e7ea619613d1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ba3c6734-0279-4399-ab80-193725b42f21">
											<gml:posList>35.66667055196773 139.74766920103403 30.31375936101469 35.66667683396241 139.74764810566452 28.571503196463908 35.66667683396241 139.74764810566452 30.31375936101469 35.66667055196773 139.74766920103403 30.31375936101469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_bf984037-5c72-4afe-8359-4a73707a258a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_42b660c6-8f37-4c21-acf8-5dfcab824510">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ccf71289-5bb2-4c46-872f-96291f77a457">
											<gml:posList>35.666652572593925 139.74759643403618 9.74887898992094 35.666652572593925 139.74759643403618 12.13176015447172 35.666651760958615 139.74759915959788 9.74887898992094 35.666652572593925 139.74759643403618 9.74887898992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_043da7ac-b032-4481-ad62-8b569e91b041">
									<gml:exterior>
										<gml:LinearRing gml:id="line_02f38d73-c450-47e8-a3bc-04fd0711d176">
											<gml:posList>35.666651760958615 139.74759915959788 9.74887898992094 35.666652572593925 139.74759643403618 12.13176015447172 35.666651760958615 139.74759915959788 12.13176015447172 35.666651760958615 139.74759915959788 9.74887898992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_55399e30-7ddd-43a1-8ca2-6e896c60e21d">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_327a1d5f-4c93-4dab-b030-a39a4c21a7f9">
											<gml:exterior>
												<gml:LinearRing gml:id="line_0cdc3635-411f-439d-a10d-6e5b0de3b294">
													<gml:posList>35.6667052548605 139.7476230814457 12.13176015447172 35.6667052548605 139.7476230814457 9.74887898992094 35.666651760958615 139.74759915959788 12.13176015447172 35.6667052548605 139.7476230814457 12.13176015447172</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_41e1db45-a469-4a9c-b82d-8d180ff80a8b">
											<gml:exterior>
												<gml:LinearRing gml:id="line_572a5431-5ae8-4eb1-88aa-5891fdbfea97">
													<gml:posList>35.666651760958615 139.74759915959788 12.13176015447172 35.6667052548605 139.7476230814457 9.74887898992094 35.666651760958615 139.74759915959788 9.74887898992094 35.666651760958615 139.74759915959788 12.13176015447172</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_2894ba95-bde2-46b9-999a-9cfb5b49613c">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_129ce1ee-d579-4390-89d6-fcb4b67535d7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_02869f1d-64cb-419c-b2e0-2b5e716f6a03">
											<gml:posList>35.66670775896889 139.74762338518366 6.329262290702189 35.66670775896889 139.74762338518366 8.479500327811564 35.66670495364263 139.7476248091836 6.329262290702189 35.66670775896889 139.74762338518366 6.329262290702189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a98fcedc-07d9-4969-9a4e-704b50c273f7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a70da022-ced0-4725-a859-d416006e7d72">
											<gml:posList>35.66670495364263 139.7476248091836 6.329262290702189 35.66670775896889 139.74762338518366 8.479500327811564 35.66670495364263 139.7476248091836 8.479500327811564 35.66670495364263 139.7476248091836 6.329262290702189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_058583eb-168f-4e86-a507-523a7a1bac75">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e3730fed-7ce0-470f-94b0-9afd054f4032">
											<gml:exterior>
												<gml:LinearRing gml:id="line_3603e362-f13c-4639-bf37-3a035e3558c1">
													<gml:posList>35.66670495364263 139.7476248091836 6.329262290702189 35.66670495364263 139.7476248091836 8.479500327811564 35.66671355981645 139.74765027014502 6.329262290702189 35.66670495364263 139.7476248091836 6.329262290702189</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_5897f856-d81e-4c51-9d19-dd6fe579d9b2">
											<gml:exterior>
												<gml:LinearRing gml:id="line_a742b5d1-ab99-4d5f-a410-70bb63d98f81">
													<gml:posList>35.66671355981645 139.74765027014502 6.329262290702189 35.66670495364263 139.7476248091836 8.479500327811564 35.66671355981645 139.74765027014502 8.479500327811564 35.66671355981645 139.74765027014502 6.329262290702189</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0179_p1042_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0179_p1042_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0179_p1042_3">
											<gml:posList>35.66669535577659 139.7477442647096 28.3243273 35.66669543419836 139.74774428387258 5.3945546 35.66672420289091 139.74764958876338 5.39512365 35.66672412436544 139.74764956994056 28.32489634 35.66672194738167 139.74765673571733 28.32485282 35.66672192709298 139.74765673084693 34.24985238 35.66669775884681 139.7477362831162 34.24937428 35.66669777911302 139.7477362880604 28.32437472 35.66669535577659 139.7477442647096 28.3243273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0179_p1042_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0179_p1042_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0179_p1042_4">
											<gml:posList>35.66669535577659 139.7477442647096 28.3243273 35.66664013370857 139.7477130072455 28.3217917 35.66661990607198 139.7477015577654 28.32086471 35.66661998422161 139.74770157677486 5.391092 35.66669543419836 139.74774428387258 5.3945546 35.66669535577659 139.7477442647096 28.3243273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_37f25700-ca27-4071-a579-05f769ee6a67">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5c4446b0-f943-452b-b392-df6e66618115">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7b1c6c32-c085-4d22-bc0e-5013169069b4">
											<gml:posList>35.66669662610225 139.74772697056582 6.254005943045939 35.66669662610225 139.74772697056582 8.420250449881877 35.66669001964531 139.74772340362622 6.254005943045939 35.66669662610225 139.74772697056582 6.254005943045939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6cbad9de-cd25-4730-92c7-261c08ea9a56">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7036d712-0d56-429a-92d0-674a4b2a787d">
											<gml:posList>35.66669001964531 139.74772340362622 6.254005943045939 35.66669662610225 139.74772697056582 8.420250449881877 35.66669001964531 139.74772340362622 8.420250449881877 35.66669001964531 139.74772340362622 6.254005943045939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0179_p1043_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0179_p1043_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0179_p1043_3">
											<gml:posList>35.66669918645841 139.7476463561453 34.24882441 35.66669920672592 139.74764636100608 28.32382486 35.66667503846401 139.7477259133297 28.32334676 35.666675018219074 139.74772590839518 34.24834632 35.66669918645841 139.7476463561453 34.24882441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_2be111eb-12a3-4af4-b71c-5e658f75dd2a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_26a30841-a2b3-410f-9fce-cde9e69c27d8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f2d81f5a-4525-47c9-8a3f-b1973a414923">
											<gml:posList>35.66665712576508 139.7477273909493 25.787262473807658 35.66665220822331 139.74772470673102 26.79172566960844 35.66665220822331 139.74772470673102 25.787262473807658 35.66665712576508 139.7477273909493 25.787262473807658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_62a8d3ef-b038-42bb-8116-19a8b619dcb5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fcc73711-dd82-4ffd-9e7d-1575502313a0">
											<gml:posList>35.66665220822331 139.74772470673102 26.79172566960844 35.66665712576508 139.7477273909493 25.787262473807658 35.66665712576508 139.7477273909493 26.79172566960844 35.66665220822331 139.74772470673102 26.79172566960844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6d0ebde4-bf0f-4312-8fc7-f73ca403709f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0d1f9241-8af3-4caf-8957-8937cebe8538">
											<gml:posList>35.666642492122385 139.74771940322665 25.787262473807658 35.66663721918005 139.74771652505677 26.79172566960844 35.66663721918005 139.74771652505677 25.787262473807658 35.666642492122385 139.74771940322665 25.787262473807658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b1aa3a85-53e4-41ba-8b20-c9bd4795ffc6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_39b20cf8-99fd-4bbe-b125-31a637bddd4f">
											<gml:posList>35.66663721918005 139.74771652505677 26.79172566960844 35.666642492122385 139.74771940322665 25.787262473807658 35.666642492122385 139.74771940322665 26.79172566960844 35.66663721918005 139.74771652505677 26.79172566960844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0e164c6b-8443-45e2-b28c-bc3753663d78">
									<gml:exterior>
										<gml:LinearRing gml:id="line_96573645-dce6-4959-9478-b588af2649a0">
											<gml:posList>35.66667632003482 139.74773786810064 26.631844077811564 35.66666684186563 139.7477326944556 26.79172566960844 35.66667632003482 139.74773786810064 26.049828086600627 35.66667632003482 139.74773786810064 26.631844077811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d68f6d26-c256-4699-9863-e5e99186b704">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d8d6efb4-b639-426f-919e-267b564228f9">
											<gml:posList>35.66666684186563 139.7477326944556 26.79172566960844 35.66667632003482 139.74773786810064 26.631844077811564 35.66669001956352 139.74774534596776 28.571503196463908 35.66666684186563 139.7477326944556 26.79172566960844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c8023299-dee7-4a13-bdf1-f301068824e5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a8deace6-28b6-40ea-86bd-92c8ac250973">
											<gml:posList>35.66667632003482 139.74773786810064 26.049828086600627 35.66666684186563 139.7477326944556 26.79172566960844 35.66666684186563 139.7477326944556 25.787262473807658 35.66667632003482 139.74773786810064 26.049828086600627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2e334596-e765-4273-8ca0-918372cb64fc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d5b1422d-6fc1-452f-b510-55709cd66ee2">
											<gml:posList>35.66667632003482 139.74773786810064 26.049828086600627 35.66666684186563 139.7477326944556 25.787262473807658 35.6666763232683 139.74773786995115 25.450768028006877 35.66667632003482 139.74773786810064 26.049828086600627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a4d60c0b-8a40-4f6f-912f-40201c9ac1b5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_17ffa15b-8377-41ae-ac35-b895ad857be2">
											<gml:posList>35.66668169823461 139.74774080380328 26.631844077811564 35.666681094102174 139.74774047410037 26.631844077811564 35.666681094102174 139.74774047410037 26.049828086600627 35.66668169823461 139.74774080380328 26.631844077811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_81dfe100-4c3a-46d9-98a6-a431aa0453bd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2ce2da81-7bda-48f0-bf8d-f14c67ca05cf">
											<gml:posList>35.666681094102174 139.74774047410037 26.631844077811564 35.66668169823461 139.74774080380328 26.631844077811564 35.66669001956352 139.74774534596776 28.571503196463908 35.666681094102174 139.74774047410037 26.631844077811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4da15c5b-ac0e-4c59-a5e0-c8a6d279f09d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_569c6f53-493b-43c0-91b8-b58fefc84516">
											<gml:posList>35.66668169823461 139.74774080380328 26.631844077811564 35.666681094102174 139.74774047410037 26.049828086600627 35.66668169823461 139.74774080380328 25.950813804374064 35.66668169823461 139.74774080380328 26.631844077811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2f3c9155-1b43-40ae-bac4-d7f7b9a77df0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cfd84385-3079-485b-a807-0954658844c8">
											<gml:posList>35.66668169823461 139.74774080380328 25.950813804374064 35.666681094102174 139.74774047410037 26.049828086600627 35.6666763232683 139.74773786995115 25.450768028006877 35.66668169823461 139.74774080380328 25.950813804374064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_90ec69b7-c2dd-4f7a-914f-1ca4d0116478">
									<gml:exterior>
										<gml:LinearRing gml:id="line_961e1349-54e0-4cac-9c58-23123a82f3ad">
											<gml:posList>35.66665685123441 139.74772724106904 23.075989280448283 35.66666219885467 139.747730160117 23.768089805350627 35.66665685123441 139.74772724106904 23.768089805350627 35.66665685123441 139.74772724106904 23.075989280448283</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9d05cc92-c347-4642-8774-f02822e13f98">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9b6995c4-91f5-433f-8cc9-639610624eeb">
											<gml:posList>35.66666219885467 139.747730160117 23.768089805350627 35.66665685123441 139.74772724106904 23.075989280448283 35.66666219885467 139.747730160117 23.075989280448283 35.66666219885467 139.747730160117 23.768089805350627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5b02906c-3daf-4879-a420-f1377fcfcad8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9bc6c26f-e078-4128-b999-f476e438793b">
											<gml:posList>35.66665220822331 139.74772470673102 26.79172566960844 35.66669001956352 139.74774534596776 28.571503196463908 35.66661808709987 139.7477060817267 28.571503196463908 35.66665220822331 139.74772470673102 26.79172566960844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cbed897a-ea65-40bf-8002-322e3d8ef9c8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2fddff1b-91fb-4d60-95f3-59946500cd79">
											<gml:posList>35.66669001956352 139.74774534596776 28.571503196463908 35.66665220822331 139.74772470673102 26.79172566960844 35.66665712576508 139.7477273909493 26.79172566960844 35.66669001956352 139.74774534596776 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d74e6dd6-1eeb-4190-b44a-b6a5034ea505">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fa40f010-3fbb-49ea-b596-1b2fd371bb9d">
											<gml:posList>35.66665220822331 139.74772470673102 26.79172566960844 35.66661808709987 139.7477060817267 28.571503196463908 35.666642492122385 139.74771940322665 26.79172566960844 35.66665220822331 139.74772470673102 26.79172566960844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_91ef233a-9967-4ed1-b18f-90fdb54da9f1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_66034ae4-17cf-4c27-afc1-d228e252e5e9">
											<gml:posList>35.666642492122385 139.74771940322665 26.79172566960844 35.66661808709987 139.7477060817267 28.571503196463908 35.66663721918005 139.74771652505677 26.79172566960844 35.666642492122385 139.74771940322665 26.79172566960844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8e2476cf-e6da-4ee7-891d-4444539fa357">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9aa4b294-6880-4353-b8ec-ea8b4338c338">
											<gml:posList>35.666627231437445 139.74771107318801 26.79172566960844 35.66661808709987 139.7477060817267 28.571503196463908 35.666627231437445 139.74771107318801 25.787262473807658 35.666627231437445 139.74771107318801 26.79172566960844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_669bacf6-c27c-4ae0-a6e2-00ed0bdd902a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_76ae2891-87b7-425d-9e0f-1b6180c009ca">
											<gml:posList>35.66661808709987 139.7477060817267 28.571503196463908 35.666627231437445 139.74771107318801 26.79172566960844 35.66663721918005 139.74771652505677 26.79172566960844 35.66661808709987 139.7477060817267 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b39924fb-3f9e-4a7f-97ba-b46849f94cc5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d4bc91cb-9c3c-456c-82b5-1cfaadc81a4c">
											<gml:posList>35.666627231437445 139.74771107318801 25.787262473807658 35.66661808709987 139.7477060817267 28.571503196463908 35.666627231437445 139.74771107318801 23.768089805350627 35.666627231437445 139.74771107318801 25.787262473807658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f951ad79-d28e-4e31-a35f-b4a6bb4f8325">
									<gml:exterior>
										<gml:LinearRing gml:id="line_690bde74-6980-478d-8c46-42492c40bd69">
											<gml:posList>35.666627231437445 139.74771107318801 23.768089805350627 35.66661808709987 139.7477060817267 28.571503196463908 35.666627231437445 139.74771107318801 22.71823934148344 35.666627231437445 139.74771107318801 23.768089805350627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6c2130ff-7296-4725-a4de-187e41d70dde">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a81963a0-7ca7-4dc2-9659-cacab1021264">
											<gml:posList>35.666627231437445 139.74771107318801 25.787262473807658 35.666627231437445 139.74771107318801 23.768089805350627 35.66663721918005 139.74771652505677 25.787262473807658 35.666627231437445 139.74771107318801 25.787262473807658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f586c831-99d9-4b0b-adbb-7c18903fbe92">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fa9cbe23-9b9b-488c-9c5c-b1d983e8a991">
											<gml:posList>35.666642492122385 139.74771940322665 25.787262473807658 35.66664207614701 139.74771917613543 23.768089805350627 35.66665220822331 139.74772470673102 23.768089805350627 35.666642492122385 139.74771940322665 25.787262473807658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_43d0b860-3bd0-4e7c-834e-7127cdf13197">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f91d49ce-c196-46e0-a606-f4fbcd7bc85d">
											<gml:posList>35.66664207614701 139.74771917613543 23.768089805350627 35.666642492122385 139.74771940322665 25.787262473807658 35.66663721918005 139.74771652505677 25.787262473807658 35.66664207614701 139.74771917613543 23.768089805350627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ef637dd9-c73a-4078-a19c-9f02e05c5dc0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5c8a6d74-1839-4409-94f5-193937638338">
											<gml:posList>35.66663721918005 139.74771652505677 25.787262473807658 35.666627231437445 139.74771107318801 23.768089805350627 35.66664207614701 139.74771917613543 23.768089805350627 35.66663721918005 139.74771652505677 25.787262473807658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dd34e0e8-01ce-473f-8ebb-f3851f6f5c91">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5025ab3c-04cc-402d-956e-74f7b6fa0da2">
											<gml:posList>35.66666684186563 139.7477326944556 25.787262473807658 35.66666219885467 139.747730160117 23.768089805350627 35.66666684186563 139.7477326944556 23.768089805350627 35.66666684186563 139.7477326944556 25.787262473807658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e48975e4-e5d9-4f02-864f-e33d2656b2c4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4d051247-cc30-4267-bb85-df7c0cbed5f5">
											<gml:posList>35.66666219885467 139.747730160117 23.768089805350627 35.66666684186563 139.7477326944556 25.787262473807658 35.66665712576508 139.7477273909493 25.787262473807658 35.66666219885467 139.747730160117 23.768089805350627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eaf1241b-1696-4ecb-8f31-22ab084ddc96">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3711efde-b1df-43b7-8074-e5b145f85cc0">
											<gml:posList>35.66666684186563 139.7477326944556 25.787262473807658 35.66666684186563 139.7477326944556 23.768089805350627 35.6666763232683 139.74773786995115 24.819046531424846 35.66666684186563 139.7477326944556 25.787262473807658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c186fa9d-d090-4a78-b044-17b6e2819357">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1fd2542f-33fb-4e98-a822-22c4cdf69b00">
											<gml:posList>35.66666684186563 139.7477326944556 25.787262473807658 35.6666763232683 139.74773786995115 24.819046531424846 35.6666763232683 139.74773786995115 25.450768028006877 35.66666684186563 139.7477326944556 25.787262473807658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8880c3af-6f77-46f9-9aa7-38efb0682ee6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a34a3ae9-c7d0-4e7d-b98f-8c3ec71838b4">
											<gml:posList>35.66666219885467 139.747730160117 23.768089805350627 35.66665712576508 139.7477273909493 25.787262473807658 35.66665685123441 139.74772724106904 23.768089805350627 35.66666219885467 139.747730160117 23.768089805350627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fe059a13-f375-48ef-a156-632b017daf12">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8cc6d424-219b-46fa-80cc-5205c2f4078b">
											<gml:posList>35.666627231437445 139.74771107318801 22.71823934148344 35.66661808709987 139.7477060817267 28.571503196463908 35.66661808709987 139.7477060817267 6.071251426444377 35.666627231437445 139.74771107318801 22.71823934148344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c3cda210-9c43-40b2-a541-cbcaced24ab0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_310f3408-afe9-4878-856a-4250852ce643">
											<gml:posList>35.666627231437445 139.74771107318801 22.71823934148344 35.66661808709987 139.7477060817267 6.071251426444377 35.666646949005866 139.74772183596176 20.070198569999064 35.666627231437445 139.74771107318801 22.71823934148344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_52c4da3c-c2bd-4643-ae9a-e11141a1d8e8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_20404399-b98c-422d-97c5-6553fead8311">
											<gml:posList>35.666627231437445 139.74771107318801 22.71823934148344 35.666646949005866 139.74772183596176 20.762299094901408 35.66664207614701 139.74771917613543 22.71823934148344 35.666627231437445 139.74771107318801 22.71823934148344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_497cf871-d957-4015-a592-cf08e2adfed5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_82199a03-7105-4c02-ac93-afbed0eefcc8">
											<gml:posList>35.666646949005866 139.74772183596176 20.762299094901408 35.666627231437445 139.74771107318801 22.71823934148344 35.666646949005866 139.74772183596176 20.070198569999064 35.666646949005866 139.74772183596176 20.762299094901408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dd4e3c01-f6d6-49f7-8d1d-87e8019a8180">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ca53a404-5ad0-464b-8550-29678243c754">
											<gml:posList>35.666646949005866 139.74772183596176 20.070198569999064 35.66661808709987 139.7477060817267 6.071251426444377 35.66665685123441 139.74772724106904 19.757103477225627 35.666646949005866 139.74772183596176 20.070198569999064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e23e2539-03d4-473b-a20f-a612d9fb0167">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aa2d9218-c2d2-4fc8-ad52-76fe701ed330">
											<gml:posList>35.66665685123441 139.74772724106904 19.757103477225627 35.66661808709987 139.7477060817267 6.071251426444377 35.66669001956352 139.74774534596776 6.071251426444377 35.66665685123441 139.74772724106904 19.757103477225627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_449ffa68-6531-416a-b638-a22e69444180">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d1336b5b-f2ab-4be2-a7c7-179f098a38d7">
											<gml:posList>35.66665220822331 139.74772470673102 23.075989280448283 35.66664207614701 139.74771917613543 23.768089805350627 35.66664207614701 139.74771917613543 22.71823934148344 35.66665220822331 139.74772470673102 23.075989280448283</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b2dc213e-45cc-425e-b328-683df8b7911e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e2ceafb0-2357-4eaf-88e8-a32a89dc23cb">
											<gml:posList>35.66664207614701 139.74771917613543 23.768089805350627 35.66665220822331 139.74772470673102 23.075989280448283 35.66665220822331 139.74772470673102 23.768089805350627 35.66664207614701 139.74771917613543 23.768089805350627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_832cd7aa-e9eb-49ff-9257-89551ff9de85">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dc825c5a-582b-4400-9515-95c2830ec293">
											<gml:posList>35.66665685123441 139.74772724106904 20.761566673026408 35.666651592017026 139.74772437029947 20.762299094901408 35.666651592017026 139.74772437029947 20.070198569999064 35.66665685123441 139.74772724106904 20.761566673026408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e5e01d71-c44f-43e5-9f3f-30b65afc8f34">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a9bc6eb0-a33a-4513-978f-1cb4ab870c6a">
											<gml:posList>35.666651592017026 139.74772437029947 20.762299094901408 35.66665685123441 139.74772724106904 20.761566673026408 35.66665220822331 139.74772470673102 23.075989280448283 35.666651592017026 139.74772437029947 20.762299094901408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_455a02d0-3c5b-4ae5-9ceb-749692e59ecf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d8a29863-460d-4f9e-a4db-b1d402070ca7">
											<gml:posList>35.66665685123441 139.74772724106904 20.761566673026408 35.666651592017026 139.74772437029947 20.070198569999064 35.66665685123441 139.74772724106904 19.757103477225627 35.66665685123441 139.74772724106904 20.761566673026408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_206c1a6a-f292-4e9b-bfb1-2b7e355e129f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5ba63b06-6428-4c78-b285-d7c5eafd8a35">
											<gml:posList>35.66665685123441 139.74772724106904 19.757103477225627 35.666651592017026 139.74772437029947 20.070198569999064 35.666646949005866 139.74772183596176 20.070198569999064 35.66665685123441 139.74772724106904 19.757103477225627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_458709b7-aab3-4f83-8b50-1ea55d416840">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cf935498-d9d8-42b3-86b5-9cb7ca1b4292">
											<gml:posList>35.66669001956352 139.74774534596776 28.571503196463908 35.666686490085596 139.7477434193914 26.631844077811564 35.666686490085596 139.7477434193914 25.950813804374064 35.66669001956352 139.74774534596776 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_15f17e45-c41e-43f7-9238-1b878fc9e0db">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7d67d83c-bb96-419b-8da3-8831412ce266">
											<gml:posList>35.666686490085596 139.7477434193914 26.631844077811564 35.66669001956352 139.74774534596776 28.571503196463908 35.66668169823461 139.74774080380328 26.631844077811564 35.666686490085596 139.7477434193914 26.631844077811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_17598c27-f38b-429a-9fa7-fd442dd8a615">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2806e2e4-e4b4-488f-b6a1-96a8a15ef4cc">
											<gml:posList>35.66666684186563 139.7477326944556 26.79172566960844 35.66669001956352 139.74774534596776 28.571503196463908 35.66665712576508 139.7477273909493 26.79172566960844 35.66666684186563 139.7477326944556 26.79172566960844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_aaf385fc-a237-44e8-addc-a6dc20518715">
									<gml:exterior>
										<gml:LinearRing gml:id="line_588db255-f3bf-4585-aba6-cf03484654a7">
											<gml:posList>35.66669001956352 139.74774534596776 28.571503196463908 35.666686490085596 139.7477434193914 25.950813804374064 35.66669001956352 139.74774534596776 6.071251426444377 35.66669001956352 139.74774534596776 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_314831ed-d3da-4fe5-b692-7876edd2fec2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2c1b0fdf-5023-4e97-9755-be25ba41f7bd">
											<gml:posList>35.66669001956352 139.74774534596776 6.071251426444377 35.666686490085596 139.7477434193914 25.950813804374064 35.66668169823461 139.74774080380328 24.819046531424846 35.66669001956352 139.74774534596776 6.071251426444377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6274c256-8184-4d04-9503-b9b34437be36">
									<gml:exterior>
										<gml:LinearRing gml:id="line_26969e8c-5f96-433d-8c61-8934b2dc0a0b">
											<gml:posList>35.66668169823461 139.74774080380328 25.450768028006877 35.666686490085596 139.7477434193914 25.950813804374064 35.66668169823461 139.74774080380328 25.950813804374064 35.66668169823461 139.74774080380328 25.450768028006877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6c281f60-6f2e-45a3-bcd2-66623c465a36">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4d3a88df-4c7a-4b2c-94f4-dbea61bf378e">
											<gml:posList>35.666686490085596 139.7477434193914 25.950813804374064 35.66668169823461 139.74774080380328 25.450768028006877 35.66668169823461 139.74774080380328 24.819046531424846 35.666686490085596 139.7477434193914 25.950813804374064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_755d9e40-5bba-4d6d-bf79-f7649f5d74cd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9525533c-75a1-4850-a538-fe8cf598c646">
											<gml:posList>35.66668169823461 139.74774080380328 25.450768028006877 35.66668169823461 139.74774080380328 25.950813804374064 35.6666763232683 139.74773786995115 25.450768028006877 35.66668169823461 139.74774080380328 25.450768028006877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_20657826-f40e-4ca4-9212-a64b90250538">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2721fef9-09dd-4b7f-849d-b8021f853130">
											<gml:posList>35.66667632003482 139.74773786810064 26.049828086600627 35.6666763232683 139.74773786995115 25.450768028006877 35.666681094102174 139.74774047410037 26.049828086600627 35.66667632003482 139.74773786810064 26.049828086600627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fe1a9964-107a-4dd8-add3-57b515c0f1b4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_da04c941-ef6e-4bba-9bd1-9ff9e157b661">
											<gml:posList>35.66665685123441 139.74772724106904 23.768089805350627 35.66665712576508 139.7477273909493 25.787262473807658 35.66665220822331 139.74772470673102 25.787262473807658 35.66665685123441 139.74772724106904 23.768089805350627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0ef76715-0908-4c37-ae11-43b1e50ba7f0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d4b9a91d-9410-4dd6-bb93-8cb8d5404781">
											<gml:posList>35.66665685123441 139.74772724106904 23.768089805350627 35.66665220822331 139.74772470673102 25.787262473807658 35.66665220822331 139.74772470673102 23.768089805350627 35.66665685123441 139.74772724106904 23.768089805350627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e8e6d257-515c-4735-aee5-41b4436bfeb4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e696d177-250d-45f0-a68f-963b5215913f">
											<gml:posList>35.66665220822331 139.74772470673102 23.768089805350627 35.66665220822331 139.74772470673102 25.787262473807658 35.666642492122385 139.74771940322665 25.787262473807658 35.66665220822331 139.74772470673102 23.768089805350627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_573d7436-54e0-47af-babb-e64637ebaec5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_160b673f-c7e2-4bb4-bb51-e031a1fef08c">
											<gml:posList>35.66669001956352 139.74774534596776 6.071251426444377 35.66668169823461 139.74774080380328 24.819046531424846 35.66666656733498 139.7477325445753 19.757103477225627 35.66669001956352 139.74774534596776 6.071251426444377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c05ca4de-c4f4-4a4d-828a-63bedfe96f92">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3c8c9289-c138-40c9-a307-b29c3275d26a">
											<gml:posList>35.66666656733498 139.7477325445753 19.757103477225627 35.66668169823461 139.74774080380328 24.819046531424846 35.66666656733498 139.7477325445753 20.761566673026408 35.66666656733498 139.7477325445753 19.757103477225627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5ea531b6-701b-4d5f-ae84-ea7d1ac2953a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b31e5254-2628-42dc-b218-c963d9d4541a">
											<gml:posList>35.66666684186563 139.7477326944556 23.075989280448283 35.6666763232683 139.74773786995115 24.819046531424846 35.66666684186563 139.7477326944556 23.768089805350627 35.66666684186563 139.7477326944556 23.075989280448283</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_baad241c-147f-4381-933d-f38456c511ac">
									<gml:exterior>
										<gml:LinearRing gml:id="line_150e3060-e682-4f99-8a93-0394d0ed9b3a">
											<gml:posList>35.6666763232683 139.74773786995115 24.819046531424846 35.66666684186563 139.7477326944556 23.075989280448283 35.66668169823461 139.74774080380328 24.819046531424846 35.6666763232683 139.74773786995115 24.819046531424846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_337c1da8-c7ad-4467-bc4c-fe5fcefd760b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_14b20aa8-1169-4f93-a9b6-2d692e9148e5">
											<gml:posList>35.66668169823461 139.74774080380328 24.819046531424846 35.66666684186563 139.7477326944556 23.075989280448283 35.66666656733498 139.7477325445753 20.761566673026408 35.66668169823461 139.74774080380328 24.819046531424846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c5454afb-138f-42ad-a751-156021486f6f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3ca3c245-d5db-4920-a7c0-2a2108d95446">
											<gml:posList>35.66666656733498 139.7477325445753 20.761566673026408 35.66666684186563 139.7477326944556 23.075989280448283 35.66666219885467 139.747730160117 23.075989280448283 35.66666656733498 139.7477325445753 20.761566673026408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_86f5ca14-5981-48b5-bb37-58adbc656fda">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a5b0a862-1ae5-4e38-ac99-0beb67a2aaa1">
											<gml:posList>35.66666656733498 139.7477325445753 20.761566673026408 35.66666219885467 139.747730160117 23.075989280448283 35.66665685123441 139.74772724106904 20.761566673026408 35.66666656733498 139.7477325445753 20.761566673026408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3424d707-6ca8-47f1-b0dd-1432be4c839c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a90e4dd5-6b93-444d-9a67-e2976567bad8">
											<gml:posList>35.66665685123441 139.74772724106904 20.761566673026408 35.66666219885467 139.747730160117 23.075989280448283 35.66665685123441 139.74772724106904 23.075989280448283 35.66665685123441 139.74772724106904 20.761566673026408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_32ed26bb-1307-49bf-b0bc-4b73a35b8da9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_186672f8-a369-4071-92f5-ba0753656d38">
											<gml:posList>35.66665685123441 139.74772724106904 20.761566673026408 35.66665685123441 139.74772724106904 23.075989280448283 35.66665220822331 139.74772470673102 23.075989280448283 35.66665685123441 139.74772724106904 20.761566673026408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7325598f-c380-4093-b5d0-f17148bac8bb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d961d962-ce7c-4313-9d07-c03bce05eea8">
											<gml:posList>35.666651592017026 139.74772437029947 20.762299094901408 35.66665220822331 139.74772470673102 23.075989280448283 35.66664207614701 139.74771917613543 22.71823934148344 35.666651592017026 139.74772437029947 20.762299094901408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9d41e044-72a9-4d68-87cb-980145733255">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6cee1025-ab2e-4d1b-85d9-a83c0c3f6615">
											<gml:posList>35.66669001956352 139.74774534596776 6.071251426444377 35.66666656733498 139.7477325445753 19.757103477225627 35.66665685123441 139.74772724106904 19.757103477225627 35.66669001956352 139.74774534596776 6.071251426444377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4eaf073e-4e48-407c-b1c7-fcc0aa7a1a85">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d3536cbc-8c29-4d5d-b76f-3b3d2a98e671">
											<gml:posList>35.666651592017026 139.74772437029947 20.762299094901408 35.66664207614701 139.74771917613543 22.71823934148344 35.666646949005866 139.74772183596176 20.762299094901408 35.666651592017026 139.74772437029947 20.762299094901408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_96412625-4a8c-4eef-89f9-122f33efbcf7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_01212519-e7d7-423c-ac58-0dfa264a61ff">
											<gml:posList>35.666681094102174 139.74774047410037 26.631844077811564 35.66669001956352 139.74774534596776 28.571503196463908 35.66667632003482 139.74773786810064 26.631844077811564 35.666681094102174 139.74774047410037 26.631844077811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_142b3554-108c-4662-8a5b-b03eea22a633">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_c785d746-741a-4118-a927-f405249da24c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_0708635f-8f86-432e-9706-a5b6acbcbfd6">
													<gml:posList>35.66663721918005 139.74771652505677 26.79172566960844 35.666627231437445 139.74771107318801 26.79172566960844 35.66663721918005 139.74771652505677 25.787262473807658 35.66663721918005 139.74771652505677 26.79172566960844</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_2eb8f9a8-a1e5-42a3-98cf-361749c5c9f1">
											<gml:exterior>
												<gml:LinearRing gml:id="line_f5d26a8b-bd83-4270-90c5-a59b449c84fe">
													<gml:posList>35.66663721918005 139.74771652505677 25.787262473807658 35.666627231437445 139.74771107318801 26.79172566960844 35.666627231437445 139.74771107318801 25.787262473807658 35.66663721918005 139.74771652505677 25.787262473807658</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_794d7005-e331-40d1-855c-e70e671a6e70">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_94aa78d4-b99d-4cc6-b4b6-d419dd6a63a0">
											<gml:exterior>
												<gml:LinearRing gml:id="line_85924e4a-f7c7-4fd0-b49d-b63796ba36b9">
													<gml:posList>35.66668169823461 139.74774080380328 25.450768028006877 35.6666763232683 139.74773786995115 25.450768028006877 35.66668169823461 139.74774080380328 24.819046531424846 35.66668169823461 139.74774080380328 25.450768028006877</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_199b80f4-34c0-4205-afd5-789c547465b4">
											<gml:exterior>
												<gml:LinearRing gml:id="line_a755ed65-698b-482a-9e41-c7c47fd7d1f9">
													<gml:posList>35.66668169823461 139.74774080380328 24.819046531424846 35.6666763232683 139.74773786995115 25.450768028006877 35.6666763232683 139.74773786995115 24.819046531424846 35.66668169823461 139.74774080380328 24.819046531424846</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_b2e1a7fd-bf9a-4667-8cfb-dc4ea2168692">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e2641caf-b962-4d82-895b-529b865f63f2">
											<gml:exterior>
												<gml:LinearRing gml:id="line_7d921930-cbab-4e09-9ba7-71370629d571">
													<gml:posList>35.66666684186563 139.7477326944556 26.79172566960844 35.66665712576508 139.7477273909493 26.79172566960844 35.66666684186563 139.7477326944556 25.787262473807658 35.66666684186563 139.7477326944556 26.79172566960844</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_79722d56-a129-4169-8304-efa85ad60080">
											<gml:exterior>
												<gml:LinearRing gml:id="line_b3cc980c-8368-41a3-9711-fba68fc48a68">
													<gml:posList>35.66666684186563 139.7477326944556 25.787262473807658 35.66665712576508 139.7477273909493 26.79172566960844 35.66665712576508 139.7477273909493 25.787262473807658 35.66666684186563 139.7477326944556 25.787262473807658</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_526274ce-f329-485c-b47f-06e41a7e5acf">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e031dbea-4f8e-4f56-9f11-5b61dc09099a">
											<gml:exterior>
												<gml:LinearRing gml:id="line_795083e2-dfd9-424b-bd34-66396b6d19fd">
													<gml:posList>35.66666656733498 139.7477325445753 20.761566673026408 35.66665685123441 139.74772724106904 20.761566673026408 35.66666656733498 139.7477325445753 19.757103477225627 35.66666656733498 139.7477325445753 20.761566673026408</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_824bfb30-937f-4cc6-8579-73ec2d7adf62">
											<gml:exterior>
												<gml:LinearRing gml:id="line_0cab9c9d-2f77-4d7c-b422-db00a3190615">
													<gml:posList>35.66666656733498 139.7477325445753 19.757103477225627 35.66665685123441 139.74772724106904 20.761566673026408 35.66665685123441 139.74772724106904 19.757103477225627 35.66666656733498 139.7477325445753 19.757103477225627</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_0a89acbe-6a0b-40d7-ac6e-0f742df055ab">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_6725d1d6-f6a4-4e09-9859-1e02341ece18">
											<gml:exterior>
												<gml:LinearRing gml:id="line_80084107-416a-40fc-9b40-18fa1c654123">
													<gml:posList>35.666651592017026 139.74772437029947 20.070198569999064 35.666651592017026 139.74772437029947 20.762299094901408 35.666646949005866 139.74772183596176 20.070198569999064 35.666651592017026 139.74772437029947 20.070198569999064</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0fb0b499-5218-467a-a226-3b8d33196222">
											<gml:exterior>
												<gml:LinearRing gml:id="line_857eb08d-f1ba-49ab-9414-321d38f1ca32">
													<gml:posList>35.666646949005866 139.74772183596176 20.070198569999064 35.666651592017026 139.74772437029947 20.762299094901408 35.666646949005866 139.74772183596176 20.762299094901408 35.666646949005866 139.74772183596176 20.070198569999064</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_a8d99b99-eb88-4fcf-9324-23fad49e3e76">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_ccdbb371-668c-4b90-a066-c727b15f104b">
											<gml:exterior>
												<gml:LinearRing gml:id="line_92590724-368c-4ce8-91d0-99318eaddcee">
													<gml:posList>35.666681094102174 139.74774047410037 26.631844077811564 35.66667632003482 139.74773786810064 26.631844077811564 35.666681094102174 139.74774047410037 26.049828086600627 35.666681094102174 139.74774047410037 26.631844077811564</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0ebaee7a-22fd-4693-85d4-d5892e39e4e5">
											<gml:exterior>
												<gml:LinearRing gml:id="line_3ad48048-c4a0-4f5a-b298-2cc4092e60fc">
													<gml:posList>35.666681094102174 139.74774047410037 26.049828086600627 35.66667632003482 139.74773786810064 26.631844077811564 35.66667632003482 139.74773786810064 26.049828086600627 35.666681094102174 139.74774047410037 26.049828086600627</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_3b99b22d-a63e-4f2c-be4b-ae5206e85d35">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_37fdc2d2-dd90-482e-a08b-a1a5b33c046c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_989830dc-4723-4558-a4e8-4580a6b0b083">
													<gml:posList>35.66666684186563 139.7477326944556 23.075989280448283 35.66666684186563 139.7477326944556 23.768089805350627 35.66666219885467 139.747730160117 23.075989280448283 35.66666684186563 139.7477326944556 23.075989280448283</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_50ea43b4-d2bc-4590-a63f-47d4a866d3e1">
											<gml:exterior>
												<gml:LinearRing gml:id="line_728df5ac-214b-4a82-aa20-9469b7f833ac">
													<gml:posList>35.66666219885467 139.747730160117 23.075989280448283 35.66666684186563 139.7477326944556 23.768089805350627 35.66666219885467 139.747730160117 23.768089805350627 35.66666219885467 139.747730160117 23.075989280448283</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_1beab50c-aa09-4102-bf2d-d2c8c4de513b">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_367b4b89-bf90-4c46-8f25-87a3c325948f">
											<gml:exterior>
												<gml:LinearRing gml:id="line_aa4f7735-da71-406b-aabd-9abb4a8d0b1a">
													<gml:posList>35.666686490085596 139.7477434193914 26.631844077811564 35.66668169823461 139.74774080380328 26.631844077811564 35.666686490085596 139.7477434193914 25.950813804374064 35.666686490085596 139.7477434193914 26.631844077811564</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_7b853669-ea20-4085-9c84-2af9549650a7">
											<gml:exterior>
												<gml:LinearRing gml:id="line_38cc81cf-0c2f-429f-b98e-110d1687c3a8">
													<gml:posList>35.666686490085596 139.7477434193914 25.950813804374064 35.66668169823461 139.74774080380328 26.631844077811564 35.66668169823461 139.74774080380328 25.950813804374064 35.666686490085596 139.7477434193914 25.950813804374064</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_fe527352-77c2-41ab-bf4f-7721d38e6898">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_86e58bd1-97d3-4749-be21-8887e1b9a7c3">
											<gml:exterior>
												<gml:LinearRing gml:id="line_db1fed21-6472-428a-9a34-76f59490eb67">
													<gml:posList>35.66665685123441 139.74772724106904 23.075989280448283 35.66665685123441 139.74772724106904 23.768089805350627 35.66665220822331 139.74772470673102 23.075989280448283 35.66665685123441 139.74772724106904 23.075989280448283</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_3ea03806-83e2-4dbf-b4f8-10f99fc090d9">
											<gml:exterior>
												<gml:LinearRing gml:id="line_847d91b1-5f82-4773-83ac-4772bee7b9c0">
													<gml:posList>35.66665220822331 139.74772470673102 23.075989280448283 35.66665685123441 139.74772724106904 23.768089805350627 35.66665220822331 139.74772470673102 23.768089805350627 35.66665220822331 139.74772470673102 23.075989280448283</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_083f978a-ce63-42e6-b164-5d589a300dc1">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_6a4bb6d8-c261-4ec0-b752-985bde10f719">
											<gml:exterior>
												<gml:LinearRing gml:id="line_d6cff0f3-d53c-43bc-a156-f55ddad20026">
													<gml:posList>35.66664207614701 139.74771917613543 22.71823934148344 35.66664207614701 139.74771917613543 23.768089805350627 35.666627231437445 139.74771107318801 22.71823934148344 35.66664207614701 139.74771917613543 22.71823934148344</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_9dd47551-271c-40a7-82cb-a35f1f5fb4a2">
											<gml:exterior>
												<gml:LinearRing gml:id="line_fe4554cc-c925-495f-9f5a-9bbfeb09a771">
													<gml:posList>35.666627231437445 139.74771107318801 22.71823934148344 35.66664207614701 139.74771917613543 23.768089805350627 35.666627231437445 139.74771107318801 23.768089805350627 35.666627231437445 139.74771107318801 22.71823934148344</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_4868fc66-957d-461d-bd9d-b86c9c5dfbbd">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e6970c4b-93f4-4cbf-86a4-936674feff07">
											<gml:exterior>
												<gml:LinearRing gml:id="line_81024a0b-db50-4b48-a653-3682652aa8d7">
													<gml:posList>35.66665220822331 139.74772470673102 26.79172566960844 35.666642492122385 139.74771940322665 26.79172566960844 35.66665220822331 139.74772470673102 25.787262473807658 35.66665220822331 139.74772470673102 26.79172566960844</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_5efa2b79-7ca6-498a-904b-cfd103c609f7">
											<gml:exterior>
												<gml:LinearRing gml:id="line_5f80b044-3498-4301-b18c-3309b08b85c2">
													<gml:posList>35.66665220822331 139.74772470673102 25.787262473807658 35.666642492122385 139.74771940322665 26.79172566960844 35.666642492122385 139.74771940322665 25.787262473807658 35.66665220822331 139.74772470673102 25.787262473807658</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_8f9c286d-2708-45d4-ab55-3e08490e8174">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_80154593-1dcc-4db0-bf68-d1811319f61a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f7fed314-cd9d-46bc-8478-c068d13c7692">
											<gml:posList>35.666644615592695 139.74761525853708 13.22275594304594 35.66661808709987 139.7477060817267 28.571503196463908 35.666644615592695 139.74761525853708 28.571503196463908 35.666644615592695 139.74761525853708 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8097e61a-0b22-401c-98f7-d66804f0fcfe">
									<gml:exterior>
										<gml:LinearRing gml:id="line_87b37897-5798-4bb8-8c1e-488f7c26a42d">
											<gml:posList>35.66661808709987 139.7477060817267 28.571503196463908 35.666644615592695 139.74761525853708 13.22275594304594 35.66661808709987 139.7477060817267 6.071251426444377 35.66661808709987 139.7477060817267 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2758a480-a753-422a-b96e-db23557333c6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1508e703-8901-4261-8ba5-c4dbce40686d">
											<gml:posList>35.666644615592695 139.74761525853708 13.22275594304594 35.66665039799914 139.74759546166717 6.071251426444377 35.66661808709987 139.7477060817267 6.071251426444377 35.666644615592695 139.74761525853708 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8083a549-61b2-4bd2-9383-d70cadc27fb4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8dbe0dd5-9236-4af8-a235-86bb85efe4f9">
											<gml:posList>35.66665039799914 139.74759546166717 6.071251426444377 35.666644615592695 139.74761525853708 13.22275594304594 35.66665039799914 139.74759546166717 13.22275594304594 35.66665039799914 139.74759546166717 6.071251426444377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_51a9ae79-3e27-4dfe-acb8-922fcffac15b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_78cd16fe-7600-421e-80c1-2ca24c07b0b8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1138e39a-f72c-4b4f-82f2-1f4ae3428205">
											<gml:posList>35.66665631830354 139.74766283597904 28.571503196463908 35.66667055196773 139.74766920103403 28.571503196463908 35.66665631830354 139.74766283597904 30.31375936101469 35.66665631830354 139.74766283597904 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d30576d2-7f7d-4f8e-acae-b6f782af6e77">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e972a776-8daa-49cd-a86a-5916fa7d89e4">
											<gml:posList>35.66665631830354 139.74766283597904 30.31375936101469 35.66667055196773 139.74766920103403 28.571503196463908 35.66667055196773 139.74766920103403 30.31375936101469 35.66665631830354 139.74766283597904 30.31375936101469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0179_p1044_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0179_p1044_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0179_p1044_2">
											<gml:posList>35.66667070458894 139.74766926934868 30.02777993 35.666670710413534 139.74766927075356 28.32278005 35.666678475524805 139.74764371107 28.32293445 35.66667846969814 139.747643709672 30.02793432 35.66667070458894 139.74766926934868 30.02777993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_ef9d9703-f52a-431d-aa11-0db132222af6">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_73909607-8d3b-47e6-bebf-81075478721a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_82ef2133-8330-4062-8a16-1211b4f0b297">
											<gml:posList>35.66669471387756 139.74772771066495 24.746124778495158 35.66669471387756 139.74772771066495 27.143883262381877 35.666689441268524 139.74774237598297 24.746124778495158 35.66669471387756 139.74772771066495 24.746124778495158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2b176f57-3709-4b43-837d-82ad89ac4a24">
									<gml:exterior>
										<gml:LinearRing gml:id="line_deac3107-1b76-461b-b51d-3962047c2e2a">
											<gml:posList>35.666689441268524 139.74774237598297 24.746124778495158 35.66669471387756 139.74772771066495 27.143883262381877 35.666689441268524 139.74774237598297 27.143883262381877 35.666689441268524 139.74774237598297 24.746124778495158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_867ca42c-0531-44e7-b0fb-2d9c7e825e08">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6802b05a-f632-4f49-93c1-9fc58cf12a33">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2f116ef3-b3e1-4002-9d14-189747c4f605">
											<gml:posList>35.66666260029714 139.74764174061275 28.571503196463908 35.66665631830354 139.74766283597904 28.571503196463908 35.66665631830354 139.74766283597904 30.31375936101469 35.66666260029714 139.74764174061275 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0214eb8b-6685-44e7-8945-6fed24c99cce">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5630108d-565d-434f-856e-1ee5b1cf5d82">
											<gml:posList>35.66666260029714 139.74764174061275 28.571503196463908 35.66665631830354 139.74766283597904 30.31375936101469 35.66666260029714 139.74764174061275 30.31375936101469 35.66666260029714 139.74764174061275 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_88e27fb0-444d-4c06-8ff9-b31539fdec51">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3c3d8b28-411e-4ccd-9ed4-dc6f1e6a5a9b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2d646ec4-4165-4eea-98c0-479220dbf002">
											<gml:posList>35.666705109610035 139.74761992795868 8.479500327811564 35.666705109610035 139.74761992795868 6.329262290702189 35.66670361133738 139.7476249594434 8.479500327811564 35.666705109610035 139.74761992795868 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_70396008-cc39-404a-921e-052cb363ba28">
									<gml:exterior>
										<gml:LinearRing gml:id="line_28dd7a3a-ee30-43c7-b0dd-7ec01e38bfbb">
											<gml:posList>35.66670361133738 139.7476249594434 8.479500327811564 35.666705109610035 139.74761992795868 6.329262290702189 35.66670361133738 139.7476249594434 6.329262290702189 35.66670361133738 139.7476249594434 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_06ee47bd-f23a-480a-9827-4d55fce822c3">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0622995a-4a5c-477b-b6e4-c379e98c5b02">
											<gml:exterior>
												<gml:LinearRing gml:id="line_6cfc2217-e542-4e6c-874c-3669dc36cd93">
													<gml:posList>35.6666852861736 139.74761676466275 6.329262290702189 35.6666852861736 139.74761676466275 8.479500327811564 35.66670361133738 139.7476249594434 6.329262290702189 35.6666852861736 139.74761676466275 6.329262290702189</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_d880bb6b-187f-4382-8b84-a71834776feb">
											<gml:exterior>
												<gml:LinearRing gml:id="line_a94c8bbc-ed5f-4186-8922-a51387182ec3">
													<gml:posList>35.66670361133738 139.7476249594434 6.329262290702189 35.6666852861736 139.74761676466275 8.479500327811564 35.66670361133738 139.7476249594434 8.479500327811564 35.66670361133738 139.7476249594434 6.329262290702189</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_c280f030-14da-4dd8-8494-370bc0ab406c">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cb5e3b82-f217-4b5c-ae99-814c25b3c79d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8cd8da6b-df57-46c2-9cd1-a65710ab57fe">
											<gml:posList>35.666671789768614 139.74772846139706 28.571503196463908 35.666692724279116 139.74773782311746 28.571503196463908 35.666671789768614 139.74772846139706 34.72238210271391 35.666671789768614 139.74772846139706 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2608f4e3-534a-4805-9ebb-d9f5f352b282">
									<gml:exterior>
										<gml:LinearRing gml:id="line_056bf43a-b56b-473f-a981-14add78c407d">
											<gml:posList>35.666671789768614 139.74772846139706 34.72238210271391 35.666692724279116 139.74773782311746 28.571503196463908 35.666692724279116 139.74773782311746 34.72238210271391 35.666671789768614 139.74772846139706 34.72238210271391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0179_p1043_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0179_p1043_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0179_p1043_1">
											<gml:posList>35.66672192709298 139.74765673084693 34.24985238 35.66672194738167 139.74765673571733 28.32485282 35.66669920672592 139.74764636100608 28.32382486 35.66669918645841 139.7476463561453 34.24882441 35.66672192709298 139.74765673084693 34.24985238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0179_p1042_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0179_p1042_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0179_p1042_2">
											<gml:posList>35.66664646392674 139.747614139833 28.32139048 35.66668246903244 139.74763056600932 28.32301422 35.66672412436544 139.74764956994056 28.32489634 35.66672420289091 139.74764958876338 5.39512365 35.66664654217216 139.74761415852856 5.39161777 35.66664646392674 139.747614139833 28.32139048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_a7566dc8-753e-4350-a624-5bd1094fabbf">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0e3055ea-8699-4cb9-8653-a572336ed20b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1d5630cb-9c71-40c7-a59b-86f329090c35">
											<gml:posList>35.66671636512583 139.74764884614584 12.13176015447172 35.66671636512583 139.74764884614584 9.74887898992094 35.66671431537042 139.74764988674087 12.13176015447172 35.66671636512583 139.74764884614584 12.13176015447172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4948ec3f-c02a-4953-921d-b06a24434920">
									<gml:exterior>
										<gml:LinearRing gml:id="line_027acd58-335a-40eb-ba4d-ffcd93a700a6">
											<gml:posList>35.66671431537042 139.74764988674087 12.13176015447172 35.66671636512583 139.74764884614584 9.74887898992094 35.66671431537042 139.74764988674087 9.74887898992094 35.66671431537042 139.74764988674087 12.13176015447172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_ac430d74-fdc8-47d6-8daa-cbdae5dfaef2">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_70a09f16-77dc-45ae-8f4f-474052016d2f">
											<gml:exterior>
												<gml:LinearRing gml:id="line_4a4b0a2b-8273-40b2-a185-6aaf24e637d9">
													<gml:posList>35.6667052548605 139.7476230814457 9.74887898992094 35.6667052548605 139.7476230814457 12.13176015447172 35.66671431537042 139.74764988674087 12.13176015447172 35.6667052548605 139.7476230814457 9.74887898992094</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_be78a7bc-a0b0-47c3-8b9a-00b71f6894f3">
											<gml:exterior>
												<gml:LinearRing gml:id="line_75a267c5-2e4b-4adf-bfab-f89638b3dc57">
													<gml:posList>35.6667052548605 139.7476230814457 9.74887898992094 35.66671431537042 139.74764988674087 12.13176015447172 35.66671431537042 139.74764988674087 9.74887898992094 35.6667052548605 139.7476230814457 9.74887898992094</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_bb56f8c6-4d10-4e72-a01f-5631b604241a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_091084d9-7259-4141-9b7c-59a3fcc05ab6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d5487256-e6d4-43e1-9b7a-9f95e764aad5">
											<gml:posList>35.66668413533931 139.74773977038203 6.254005943045939 35.666686201521316 139.747734023496 6.254005943045939 35.66668413533931 139.74773977038203 8.420250449881877 35.66668413533931 139.74773977038203 6.254005943045939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6d65e826-71b0-4b4c-ae8c-e49a0a5e20df">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c4897d41-d6e2-4728-ae30-d2c5154216c0">
											<gml:posList>35.66668413533931 139.74773977038203 8.420250449881877 35.666686201521316 139.747734023496 6.254005943045939 35.666686201521316 139.747734023496 8.420250449881877 35.66668413533931 139.74773977038203 8.420250449881877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_5a936e9c-1445-4651-8415-f94dacb68a83">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_dae80797-5585-4293-aaa3-a5abb202c27f">
											<gml:exterior>
												<gml:LinearRing gml:id="line_0946b3dd-f302-4802-ac1c-f659aadd06c4">
													<gml:posList>35.666686201521316 139.747734023496 8.420250449881877 35.666686201521316 139.747734023496 6.254005943045939 35.66669001964531 139.74772340362622 8.420250449881877 35.666686201521316 139.747734023496 8.420250449881877</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_305c1cc2-0113-4843-9f5a-8aa09f1d63e3">
											<gml:exterior>
												<gml:LinearRing gml:id="line_db3729db-09c9-4783-ab81-1c01188c6afd">
													<gml:posList>35.66669001964531 139.74772340362622 8.420250449881877 35.666686201521316 139.747734023496 6.254005943045939 35.66669001964531 139.74772340362622 6.254005943045939 35.66669001964531 139.74772340362622 8.420250449881877</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_be1f3299-2e32-4384-b0f3-a637e9d3e704">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d68b8c37-b16b-4019-b701-fa9cc2119ade">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9ecbb8ca-24e6-41a7-a7a9-5fb133cecd3b">
											<gml:posList>35.666652572593925 139.74759643403618 6.329262290702189 35.666652572593925 139.74759643403618 8.479500327811564 35.66665107428787 139.74760146551807 8.479500327811564 35.666652572593925 139.74759643403618 6.329262290702189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c814bbb8-f17b-4e21-82a0-ea57a126dd71">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5b0b6490-9925-41ea-965e-02c6cf799054">
											<gml:posList>35.666652572593925 139.74759643403618 6.329262290702189 35.66665107428787 139.74760146551807 8.479500327811564 35.66665107428787 139.74760146551807 6.329262290702189 35.666652572593925 139.74759643403618 6.329262290702189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_5592ec4f-b9fb-4503-b712-6e4a530d0c49">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_f35399c5-e190-466f-8e4d-0ffe0f2aa1e2">
											<gml:exterior>
												<gml:LinearRing gml:id="line_4e260f37-b08f-427e-98f0-2cd6da8abb56">
													<gml:posList>35.66665107428787 139.74760146551807 8.479500327811564 35.66666928904278 139.74760961085764 8.479500327811564 35.66665107428787 139.74760146551807 6.329262290702189 35.66665107428787 139.74760146551807 8.479500327811564</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_8e24f0cf-74cf-4bbb-929c-b29b9ed3e1a2">
											<gml:exterior>
												<gml:LinearRing gml:id="line_1378d4ad-3114-4109-9d9e-d5b8ec6950fc">
													<gml:posList>35.66665107428787 139.74760146551807 6.329262290702189 35.66666928904278 139.74760961085764 8.479500327811564 35.66666928904278 139.74760961085764 6.329262290702189 35.66665107428787 139.74760146551807 6.329262290702189</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_79339a3e-2f6c-44aa-8b1f-61a88a2d23e6">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_797da4f8-73c0-429d-9415-d02c6c26373f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_275a5f45-2cfd-4fd8-86d6-8dcd23b8a7cc">
											<gml:posList>35.66669572221696 139.74772825499952 27.61948445867094 35.66669044960785 139.74774292031765 27.61948445867094 35.66669572221696 139.74772825499952 27.143883262381877 35.66669572221696 139.74772825499952 27.61948445867094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dd4afcd9-04b4-4e6a-b1e4-e24a6c907030">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2c15c47c-935c-42e5-8bdf-f34a6976629a">
											<gml:posList>35.66669572221696 139.74772825499952 27.143883262381877 35.66669044960785 139.74774292031765 27.61948445867094 35.66669044960785 139.74774292031765 27.143883262381877 35.66669572221696 139.74772825499952 27.143883262381877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_0ceb9dbf-05ef-4217-bc8b-658fe6bce9b4">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_78fd8bbd-f0c5-4afa-8dec-621f26ae844d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_58c6c801-5595-4fa8-af85-9a4daf853999">
											<gml:posList>35.666720410832845 139.74766081524973 34.72238210271391 35.666692724279116 139.74773782311746 28.571503196463908 35.666711044702815 139.74768686644555 27.004204307303752 35.666720410832845 139.74766081524973 34.72238210271391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d4246462-5f86-45cd-b863-e95d3c5deb8d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_25a3ee7a-b540-425b-8368-66e7a0809a21">
											<gml:posList>35.666692724279116 139.74773782311746 28.571503196463908 35.666720410832845 139.74766081524973 34.72238210271391 35.666692724279116 139.74773782311746 34.72238210271391 35.666692724279116 139.74773782311746 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1f0bbff3-6c85-4664-8b06-47e51db74b67">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6274d725-e52b-4594-a88f-762b39f797eb">
											<gml:posList>35.666720410832845 139.74766081524973 34.72238210271391 35.66671446337536 139.74767735770752 27.004204307303752 35.66671446337536 139.74767735770752 25.43382314275297 35.666720410832845 139.74766081524973 34.72238210271391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9e8555d6-7c26-49fd-a818-ab9e79672d2e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7cbf1fe7-5e23-4552-bc9f-34242454c535">
											<gml:posList>35.66671446337536 139.74767735770752 27.004204307303752 35.666720410832845 139.74766081524973 34.72238210271391 35.666711044702815 139.74768686644555 27.004204307303752 35.66671446337536 139.74767735770752 27.004204307303752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ac038502-816d-4697-a720-25e6d84ea74a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d10a1c9a-5d7e-4b0b-ac34-efbe1458849b">
											<gml:posList>35.666720410832845 139.74766081524973 34.72238210271391 35.66671446337536 139.74767735770752 25.43382314275297 35.66671446337536 139.74767735770752 24.008568320975627 35.666720410832845 139.74766081524973 34.72238210271391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bb39e49c-4550-4cf0-94e0-f5d0ce310cee">
									<gml:exterior>
										<gml:LinearRing gml:id="line_142adcec-30c5-4b8e-8504-a8e0a9ddead6">
											<gml:posList>35.666720410832845 139.74766081524973 34.72238210271391 35.66671446337536 139.74767735770752 24.008568320975627 35.666720410832845 139.74766081524973 13.22275594304594 35.666720410832845 139.74766081524973 34.72238210271391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8e51963b-9c08-4b94-8094-c68d11d68d17">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c76de0fc-0852-4c5a-8ca0-808e04f18559">
											<gml:posList>35.66671446337536 139.74767735770752 24.008568320975627 35.66671446337536 139.74767735770752 25.43382314275297 35.666711044702815 139.74768686644555 24.008568320975627 35.66671446337536 139.74767735770752 24.008568320975627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c62564fd-b803-46c3-8663-839775886ecb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_070b07d6-2097-4c0b-a0f1-4cd04ef7dde6">
											<gml:posList>35.666711044702815 139.74768686644555 24.008568320975627 35.66671446337536 139.74767735770752 25.43382314275297 35.666711044702815 139.74768686644555 25.43382314275297 35.666711044702815 139.74768686644555 24.008568320975627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fc483326-0afd-4500-90c8-0145824af001">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2c31aa19-71d2-4c68-aa1e-effeb433c962">
											<gml:posList>35.666711044702815 139.74768686644555 24.008568320975627 35.666699854765724 139.7477179902535 25.678253684745158 35.666699854765724 139.7477179902535 23.705933128104533 35.666711044702815 139.74768686644555 24.008568320975627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b8daa650-cda4-487c-8486-6d4a76bc7fa4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d07f0c55-4aac-4c37-83da-fc9738517baa">
											<gml:posList>35.666699854765724 139.7477179902535 25.678253684745158 35.666711044702815 139.74768686644555 24.008568320975627 35.666711044702815 139.74768686644555 25.43382314275297 35.666699854765724 139.7477179902535 25.678253684745158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b3de2de6-d8d9-4509-a1b9-92f6e9d0fc62">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5a36f48f-22f4-4b26-9c57-02cad6dc3564">
											<gml:posList>35.666720410832845 139.74766081524973 13.22275594304594 35.66671446337536 139.74767735770752 24.008568320975627 35.66671446337536 139.74767735770752 22.438179527030314 35.666720410832845 139.74766081524973 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ea6bb832-5f88-44d5-a646-192cb174cfb2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_97bd3e80-9051-486a-aa3f-e2ac556331e1">
											<gml:posList>35.666720410832845 139.74766081524973 13.22275594304594 35.66671446337536 139.74767735770752 22.438179527030314 35.66671446337536 139.74767735770752 21.007813010917033 35.666720410832845 139.74766081524973 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2a5970b7-b7a9-4375-9344-4346474daca4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2f273cdd-3709-4525-8652-adadf3066247">
											<gml:posList>35.66671446337536 139.74767735770752 21.007813010917033 35.66671446337536 139.74767735770752 22.438179527030314 35.666711044702815 139.74768686644555 21.007813010917033 35.66671446337536 139.74767735770752 21.007813010917033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8a7b0155-1f6e-4aa8-89f6-cdbc295cf556">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1902a912-4dcc-449d-ab18-279f6781840b">
											<gml:posList>35.666720410832845 139.74766081524973 13.22275594304594 35.66671446337536 139.74767735770752 21.007813010917033 35.66671446337536 139.74767735770752 19.437431846366252 35.666720410832845 139.74766081524973 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3ff14053-e32b-4c3a-8bc3-41255f1a0f45">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d4a937b9-a1b1-428b-a171-7d2bf84c8c00">
											<gml:posList>35.666720410832845 139.74766081524973 13.22275594304594 35.66671446337536 139.74767735770752 19.437431846366252 35.66671446337536 139.74767735770752 17.99051717351469 35.666720410832845 139.74766081524973 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5d9740bd-3d15-4dcf-85e0-80e5025937bb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0e38f573-2812-4ef1-93bf-983feaa9d667">
											<gml:posList>35.66671446337536 139.74767735770752 17.99051717351469 35.66671446337536 139.74767735770752 19.437431846366252 35.666711044702815 139.74768686644555 17.99051717351469 35.66671446337536 139.74767735770752 17.99051717351469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a7c96d6a-8907-4d0f-8697-e50b35bd12d0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7a067ca7-17ea-4cc4-93e9-05f650ffce59">
											<gml:posList>35.666720410832845 139.74766081524973 13.22275594304594 35.66671446337536 139.74767735770752 17.99051717351469 35.66671446337536 139.74767735770752 16.420136008963908 35.666720410832845 139.74766081524973 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_71c1c80f-7d11-4615-b13f-51282f8b5674">
									<gml:exterior>
										<gml:LinearRing gml:id="line_49b3d80a-0ea9-40f2-b664-2355afa69984">
											<gml:posList>35.666720410832845 139.74766081524973 13.22275594304594 35.66671446337536 139.74767735770752 16.420136008963908 35.66671446337536 139.74767735770752 14.993195090995158 35.666720410832845 139.74766081524973 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7ec7accc-5782-4d39-b71f-cc9579ca1faf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_61000c45-45c0-4b3d-9d50-7146ab441a1b">
											<gml:posList>35.66671446337536 139.74767735770752 14.993195090995158 35.66671446337536 139.74767735770752 16.420136008963908 35.666711044702815 139.74768686644555 14.993195090995158 35.66671446337536 139.74767735770752 14.993195090995158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d4c28f3d-d240-4cbb-9ee8-9862c953f1eb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_89e18b65-6002-45fb-9847-911c53ef50bb">
											<gml:posList>35.666720410832845 139.74766081524973 13.22275594304594 35.66671446337536 139.74767735770752 14.993195090995158 35.66671446337536 139.74767735770752 13.422806297049846 35.666720410832845 139.74766081524973 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ac4d7f7a-b8e6-41ac-a896-ff2f7e943d2a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fb6e1ed6-9581-4d01-85c4-65dffb8bafb5">
											<gml:posList>35.666720410832845 139.74766081524973 13.22275594304594 35.66671446337536 139.74767735770752 13.422806297049846 35.66671446337536 139.74767735770752 11.965302024588908 35.666720410832845 139.74766081524973 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_687cb4cc-5cbb-4c6b-98e8-3be322af8e62">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9305499f-94fc-4cb8-b73e-b55e1f203b8a">
											<gml:posList>35.666711044702815 139.74768686644555 27.004204307303752 35.666696092407044 139.74772845500408 27.61948445867094 35.666699854765724 139.7477179902535 26.676384483085002 35.666711044702815 139.74768686644555 27.004204307303752</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_06db1630-ab68-46f6-b1d6-39b9d86f728d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7a396119-bded-4f6f-965c-9900eddf228f">
											<gml:posList>35.666696092407044 139.74772845500408 27.61948445867094 35.666711044702815 139.74768686644555 27.004204307303752 35.666692724279116 139.74773782311746 28.571503196463908 35.666696092407044 139.74772845500408 27.61948445867094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_93b6e288-def4-4ff6-a577-28870817a404">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0b59582a-bfe1-4623-ba42-4a637b00d0fb">
											<gml:posList>35.6666976085241 139.74772423791126 26.676384483085002 35.666696092407044 139.74772845500408 27.61948445867094 35.666696092407044 139.74772845500408 24.746124778495158 35.6666976085241 139.74772423791126 26.676384483085002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_807283ce-536b-45b6-a8dd-e7d209d36e87">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6cf5c038-27a6-477a-a1e0-e75b78545ec0">
											<gml:posList>35.666696092407044 139.74772845500408 27.61948445867094 35.6666976085241 139.74772423791126 26.676384483085002 35.666699854765724 139.7477179902535 26.676384483085002 35.666696092407044 139.74772845500408 27.61948445867094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c246605d-fa94-47aa-ad34-8140a4a03111">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7dd0240c-8f48-4962-b006-21bb7c87e345">
											<gml:posList>35.6666976085241 139.74772423791126 26.676384483085002 35.666696092407044 139.74772845500408 24.746124778495158 35.6666976085241 139.74772423791126 25.678253684745158 35.6666976085241 139.74772423791126 26.676384483085002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5d0f8bd1-1479-4825-b6a6-b4d5dab280cc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a13adae3-5fda-4dbf-905e-deb6f66bddfa">
											<gml:posList>35.6666976085241 139.74772423791126 25.678253684745158 35.666696092407044 139.74772845500408 24.746124778495158 35.666699854765724 139.7477179902535 25.678253684745158 35.6666976085241 139.74772423791126 25.678253684745158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ea95d1b9-fd9a-4d6a-9afa-f6a14cf16a41">
									<gml:exterior>
										<gml:LinearRing gml:id="line_247161c6-254f-41c1-859e-8382138511ff">
											<gml:posList>35.666711044702815 139.74768686644555 25.43382314275297 35.666699854765724 139.7477179902535 26.676384483085002 35.666699854765724 139.7477179902535 25.678253684745158 35.666711044702815 139.74768686644555 25.43382314275297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_56e9c687-4469-407c-b0d1-93fa1b2d8eec">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5311861c-8ed2-4593-8bc5-f5c17b715b47">
											<gml:posList>35.666699854765724 139.7477179902535 26.676384483085002 35.666711044702815 139.74768686644555 25.43382314275297 35.666711044702815 139.74768686644555 27.004204307303752 35.666699854765724 139.7477179902535 26.676384483085002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b11e4576-06ab-497d-91d0-57adbcc9169a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2f13cf85-f021-471a-9dc5-86d7c7a65b16">
											<gml:posList>35.666711044702815 139.74768686644555 22.438179527030314 35.666699854765724 139.7477179902535 23.705933128104533 35.666699854765724 139.7477179902535 22.70780232976469 35.666711044702815 139.74768686644555 22.438179527030314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b920e6d1-7a99-4a66-b623-8d00560e9e43">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4390a9c3-2293-428e-98bd-d3a55db8a172">
											<gml:posList>35.666699854765724 139.7477179902535 23.705933128104533 35.666711044702815 139.74768686644555 22.438179527030314 35.666711044702815 139.74768686644555 24.008568320975627 35.666699854765724 139.7477179902535 23.705933128104533</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_89765a09-fcdd-450d-9249-d08574eb6de7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3268f88a-7404-4154-acf1-017d1c92c75a">
											<gml:posList>35.666711044702815 139.74768686644555 22.438179527030314 35.666699854765724 139.7477179902535 22.70780232976469 35.666711044702815 139.74768686644555 21.007813010917033 35.666711044702815 139.74768686644555 22.438179527030314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_403f6d7e-6691-4047-9e2e-80a760f602fb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a3b84202-cf32-4fdd-8fec-30d81c6540ba">
											<gml:posList>35.666699854765724 139.7477179902535 20.680603538260783 35.666699854765724 139.7477179902535 22.70780232976469 35.6666976085241 139.74772423791126 20.680603538260783 35.666699854765724 139.7477179902535 20.680603538260783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a64b5f40-71b3-4c5c-b10b-e9715c278a98">
									<gml:exterior>
										<gml:LinearRing gml:id="line_20ae04fe-e851-418c-a1ec-9097d1054b37">
											<gml:posList>35.666699854765724 139.7477179902535 22.70780232976469 35.666699854765724 139.7477179902535 20.680603538260783 35.666711044702815 139.74768686644555 21.007813010917033 35.666699854765724 139.7477179902535 22.70780232976469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a91ea497-2b92-4632-9520-da6c5d388828">
									<gml:exterior>
										<gml:LinearRing gml:id="line_98ac0c6d-3b23-404a-9a5f-4cb3c745157b">
											<gml:posList>35.6666976085241 139.74772423791126 20.680603538260783 35.666699854765724 139.7477179902535 22.70780232976469 35.6666976085241 139.74772423791126 22.70780232976469 35.6666976085241 139.74772423791126 20.680603538260783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_748fee8c-7c1f-482c-894a-d88893efc6e3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4a396b5a-7157-47be-8826-d0f932a77883">
											<gml:posList>35.666695897007 139.7477289984326 22.70780232976469 35.6666976085241 139.74772423791126 23.705933128104533 35.666695897007 139.7477289984326 23.705933128104533 35.666695897007 139.7477289984326 22.70780232976469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ce893b5b-adb3-4842-951b-969cb00a2f8a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c197febd-c983-46be-819b-4d0fe8ea702a">
											<gml:posList>35.6666976085241 139.74772423791126 23.705933128104533 35.666695897007 139.7477289984326 22.70780232976469 35.6666976085241 139.74772423791126 22.70780232976469 35.6666976085241 139.74772423791126 23.705933128104533</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c2377bf6-b996-4395-ba1f-ce5222308c76">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6a606177-18fd-4265-ab45-1c47ca102844">
											<gml:posList>35.666711044702815 139.74768686644555 19.437431846366252 35.666699854765724 139.7477179902535 20.680603538260783 35.666699854765724 139.7477179902535 19.68247273992094 35.666711044702815 139.74768686644555 19.437431846366252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9ba16880-787b-43ed-8f4b-a584ab1f63a9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_028cb1e7-11d4-4391-b15c-ba045baffb1c">
											<gml:posList>35.666699854765724 139.7477179902535 20.680603538260783 35.666711044702815 139.74768686644555 19.437431846366252 35.666711044702815 139.74768686644555 21.007813010917033 35.666699854765724 139.7477179902535 20.680603538260783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_137c8018-fa98-411c-9f94-0c3ee541a69d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aec22109-5044-4d5d-a81e-a5515c61bc24">
											<gml:posList>35.666711044702815 139.74768686644555 19.437431846366252 35.666699854765724 139.7477179902535 19.68247273992094 35.666711044702815 139.74768686644555 17.99051717351469 35.666711044702815 139.74768686644555 19.437431846366252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ce207700-7fcc-4672-885a-03526c50e440">
									<gml:exterior>
										<gml:LinearRing gml:id="line_011f89de-e74d-4eb3-ad63-d03a1f402089">
											<gml:posList>35.666699854765724 139.7477179902535 17.68565419744047 35.666699854765724 139.7477179902535 19.68247273992094 35.6666976085241 139.74772423791126 19.68247273992094 35.666699854765724 139.7477179902535 17.68565419744047</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_28e6bdb6-c13b-4366-a57f-0762722cefdd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9b584504-05ea-4b31-a017-bd628a5dd3d9">
											<gml:posList>35.666699854765724 139.7477179902535 19.68247273992094 35.666699854765724 139.7477179902535 17.68565419744047 35.666711044702815 139.74768686644555 17.99051717351469 35.666699854765724 139.7477179902535 19.68247273992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d33932dc-588f-443e-936d-e232d4d59ee7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c3d31ee9-10da-48da-a7d3-88c3f9515ade">
											<gml:posList>35.666699854765724 139.7477179902535 17.68565419744047 35.6666976085241 139.74772423791126 19.68247273992094 35.6666976085241 139.74772423791126 17.68565419744047 35.666699854765724 139.7477179902535 17.68565419744047</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f021a20b-652c-413e-ae45-4a2472cb3d25">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3ac9e902-9e93-4817-91ec-d6dbb07f859c">
											<gml:posList>35.666695897007 139.7477289984326 19.68247273992094 35.6666976085241 139.74772423791126 20.680603538260783 35.666695897007 139.7477289984326 20.680603538260783 35.666695897007 139.7477289984326 19.68247273992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7c8ad227-975b-4f60-9c0d-ebadef250c8f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e84fc3ce-5558-46db-bc10-a3760d3c2937">
											<gml:posList>35.6666976085241 139.74772423791126 20.680603538260783 35.666695897007 139.7477289984326 19.68247273992094 35.6666976085241 139.74772423791126 19.68247273992094 35.6666976085241 139.74772423791126 20.680603538260783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_656fb504-03a7-4794-8354-5c6f707f7286">
									<gml:exterior>
										<gml:LinearRing gml:id="line_04eb6c84-b2ca-4e4d-b1e3-87152cf05781">
											<gml:posList>35.666711044702815 139.74768686644555 16.420136008963908 35.666699854765724 139.7477179902535 17.68565419744047 35.666699854765724 139.7477179902535 16.687523399100627 35.666711044702815 139.74768686644555 16.420136008963908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_88355b02-8c58-4307-b27f-bcecc11b9e21">
									<gml:exterior>
										<gml:LinearRing gml:id="line_042fb441-9a99-47b9-9a5f-900b079dd035">
											<gml:posList>35.666699854765724 139.7477179902535 17.68565419744047 35.666711044702815 139.74768686644555 16.420136008963908 35.666711044702815 139.74768686644555 17.99051717351469 35.666699854765724 139.7477179902535 17.68565419744047</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_89bee86e-8cfa-4f64-a739-ad3cd335bdec">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bd8f7226-6cfd-4fb5-a954-4c2380e1c168">
											<gml:posList>35.666711044702815 139.74768686644555 16.420136008963908 35.666699854765724 139.7477179902535 16.687523399100627 35.666711044702815 139.74768686644555 14.993195090995158 35.666711044702815 139.74768686644555 16.420136008963908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0e5820cc-8820-43dc-95a7-1a2ef82504df">
									<gml:exterior>
										<gml:LinearRing gml:id="line_87a37d63-931f-4a3c-bc99-36eef1387aeb">
											<gml:posList>35.666699854765724 139.7477179902535 14.68870595525297 35.666699854765724 139.7477179902535 16.687523399100627 35.6666976085241 139.74772423791126 16.687523399100627 35.666699854765724 139.7477179902535 14.68870595525297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8c83f8ea-bfe1-4958-ab5e-aef05724d5c0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c651bb3f-6676-4e32-b44f-ee8eeaed333e">
											<gml:posList>35.666699854765724 139.7477179902535 16.687523399100627 35.666699854765724 139.7477179902535 14.68870595525297 35.666711044702815 139.74768686644555 14.993195090995158 35.666699854765724 139.7477179902535 16.687523399100627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e53b3247-b4ac-4fd6-b201-b9e3d54e5f6b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_86914303-19fd-4263-a0b9-d6b4a1433457">
											<gml:posList>35.666699854765724 139.7477179902535 14.68870595525297 35.6666976085241 139.74772423791126 16.687523399100627 35.6666976085241 139.74772423791126 14.68870595525297 35.666699854765724 139.7477179902535 14.68870595525297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5b37535b-800c-438c-9c17-1f6d7f8a4822">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6a420ff4-88e6-4af8-b8f9-131c391036f0">
											<gml:posList>35.6666976085241 139.74772423791126 16.687523399100627 35.666695897007 139.7477289984326 17.68565419744047 35.666695897007 139.7477289984326 16.687523399100627 35.6666976085241 139.74772423791126 16.687523399100627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_15b80749-b9d3-4897-95e0-8b1131db8000">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1149cba0-944e-42a1-a057-3caa937ec7a5">
											<gml:posList>35.666695897007 139.7477289984326 17.68565419744047 35.6666976085241 139.74772423791126 16.687523399100627 35.6666976085241 139.74772423791126 17.68565419744047 35.666695897007 139.7477289984326 17.68565419744047</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_629ed030-9c3e-4681-acd0-9de8bc879adf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8367146b-e09f-4976-ba5a-bf3c88455bc3">
											<gml:posList>35.666711044702815 139.74768686644555 13.422806297049846 35.666699854765724 139.7477179902535 14.68870595525297 35.666699854765724 139.7477179902535 13.690575156913127 35.666711044702815 139.74768686644555 13.422806297049846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7c0433c0-e520-43c4-9f40-573009b2d5e6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_af61f3bc-e32a-4ad8-b583-ed5272de088b">
											<gml:posList>35.666699854765724 139.7477179902535 14.68870595525297 35.666711044702815 139.74768686644555 13.422806297049846 35.666711044702815 139.74768686644555 14.993195090995158 35.666699854765724 139.7477179902535 14.68870595525297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7901da73-0410-4f44-80ba-dcc773d2567a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_df4c9594-86b7-4e85-8df6-50badc73b882">
											<gml:posList>35.666711044702815 139.74768686644555 13.422806297049846 35.666699854765724 139.7477179902535 13.690575156913127 35.666711044702815 139.74768686644555 11.965302024588908 35.666711044702815 139.74768686644555 13.422806297049846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1e945adb-4a4c-4c13-8c97-b6516262ae2f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f75451f5-376d-4edf-b20a-15b09ba87d5e">
											<gml:posList>35.666699854765724 139.7477179902535 11.655334983573283 35.666699854765724 139.7477179902535 13.690575156913127 35.6666976085241 139.74772423791126 13.690575156913127 35.666699854765724 139.7477179902535 11.655334983573283</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_18a7925b-ec3e-4847-9ff6-beec15ae2e5e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e7652272-bfac-41a4-a20e-a1773b712a40">
											<gml:posList>35.666699854765724 139.7477179902535 13.690575156913127 35.666699854765724 139.7477179902535 11.655334983573283 35.666711044702815 139.74768686644555 11.965302024588908 35.666699854765724 139.7477179902535 13.690575156913127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1f76f61f-5b8d-4163-baeb-7d6454c35a8b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ffb5bebc-8f83-41ab-91f0-93eb76d0e3e0">
											<gml:posList>35.666699854765724 139.7477179902535 11.655334983573283 35.6666976085241 139.74772423791126 13.690575156913127 35.6666976085241 139.74772423791126 11.655334983573283 35.666699854765724 139.7477179902535 11.655334983573283</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_acabd311-6a55-4d0f-a925-45e28efe3bb2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ded26ccb-1117-47fb-8dcc-7a418fdb2056">
											<gml:posList>35.6666976085241 139.74772423791126 13.690575156913127 35.666695897007 139.7477289984326 14.68870595525297 35.666695897007 139.7477289984326 13.690575156913127 35.6666976085241 139.74772423791126 13.690575156913127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_62be09ed-aa31-43bd-b024-9ace9f758435">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d548dc81-0beb-400d-a88b-e59d0aefb103">
											<gml:posList>35.666695897007 139.7477289984326 14.68870595525297 35.6666976085241 139.74772423791126 13.690575156913127 35.6666976085241 139.74772423791126 14.68870595525297 35.666695897007 139.7477289984326 14.68870595525297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2ed8bbe6-2cc0-4eb3-ab91-13be136f4e5f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f069058a-98a4-4a71-9e43-cff3583b461a">
											<gml:posList>35.666720410832845 139.74766081524973 12.13176015447172 35.66671446337536 139.74767735770752 11.965302024588908 35.66671446337536 139.74767735770752 10.394913230643596 35.666720410832845 139.74766081524973 12.13176015447172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0b7a8017-add5-4829-965b-c3359728aaba">
									<gml:exterior>
										<gml:LinearRing gml:id="line_602bfd64-7c1e-4b4f-a6fd-886355025969">
											<gml:posList>35.66671446337536 139.74767735770752 11.965302024588908 35.666720410832845 139.74766081524973 12.13176015447172 35.666720410832845 139.74766081524973 13.22275594304594 35.66671446337536 139.74767735770752 11.965302024588908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6810ffd3-eb71-4a96-b283-e8a015fb7621">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0ebe4b66-2644-4983-af1a-1cd564366a24">
											<gml:posList>35.666720410832845 139.74766081524973 12.13176015447172 35.66671446337536 139.74767735770752 10.394913230643596 35.666720410832845 139.74766081524973 9.74887898992094 35.666720410832845 139.74766081524973 12.13176015447172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f791a883-5faa-424b-87a0-b6010f194b92">
									<gml:exterior>
										<gml:LinearRing gml:id="line_65c065ab-0e94-4d65-b085-9ba23fadbf2e">
											<gml:posList>35.666720410832845 139.74766081524973 9.74887898992094 35.66671446337536 139.74767735770752 10.394913230643596 35.66671446337536 139.74767735770752 8.467033897147502 35.666720410832845 139.74766081524973 9.74887898992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3ad40dc4-7788-4ba6-b445-63aeda9fe262">
									<gml:exterior>
										<gml:LinearRing gml:id="line_eb235fdc-59b7-4119-9758-528e1c8a88b0">
											<gml:posList>35.666711044702815 139.74768686644555 10.394913230643596 35.666699854765724 139.7477179902535 11.655334983573283 35.666699854765724 139.7477179902535 10.65720418523344 35.666711044702815 139.74768686644555 10.394913230643596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_088c61e0-eb62-4094-a06d-984e74139d1d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2d19b040-1ff4-4240-accf-821f40e3ec06">
											<gml:posList>35.666699854765724 139.7477179902535 11.655334983573283 35.666711044702815 139.74768686644555 10.394913230643596 35.666711044702815 139.74768686644555 11.965302024588908 35.666699854765724 139.7477179902535 11.655334983573283</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6f6595b6-8799-4160-908c-15fb2e9f94f3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_088d3679-d1d3-4afb-952a-c7499ef6afa8">
											<gml:posList>35.666711044702815 139.74768686644555 10.394913230643596 35.666699854765724 139.7477179902535 10.65720418523344 35.666711044702815 139.74768686644555 8.467033897147502 35.666711044702815 139.74768686644555 10.394913230643596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7501f2f9-e265-44f5-94a5-bb4622979d1c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a3fbd573-da8f-4b9c-8093-5911a0317f18">
											<gml:posList>35.666711044702815 139.74768686644555 8.467033897147502 35.666699854765724 139.7477179902535 10.65720418523344 35.66669662610225 139.74772697056582 8.420250449881877 35.666711044702815 139.74768686644555 8.467033897147502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a584e20b-3715-4e80-8d24-6dba34408eaa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_857cf206-6608-4fde-a1d5-e1e0d2ed94a7">
											<gml:posList>35.66669662610225 139.74772697056582 8.420250449881877 35.6666976085241 139.74772423791126 10.65720418523344 35.666695897007 139.7477289984326 10.65720418523344 35.66669662610225 139.74772697056582 8.420250449881877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6e32d795-898d-4b15-a98c-6bdc2c627d51">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c3b9b4e6-fab7-4219-b35c-2f25283f55e1">
											<gml:posList>35.6666976085241 139.74772423791126 10.65720418523344 35.66669662610225 139.74772697056582 8.420250449881877 35.666699854765724 139.7477179902535 10.65720418523344 35.6666976085241 139.74772423791126 10.65720418523344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dac3559e-88d8-4010-95cc-ba55911342d4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f3d2a6b2-7195-4f7a-9769-64f8ef036701">
											<gml:posList>35.666695897007 139.7477289984326 10.65720418523344 35.6666976085241 139.74772423791126 11.655334983573283 35.666695897007 139.7477289984326 11.655334983573283 35.666695897007 139.7477289984326 10.65720418523344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9fb12fce-76c0-4d45-90d5-db9aeca7b657">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f6af626d-b0e8-4e76-af3a-9226ad5dd5ce">
											<gml:posList>35.6666976085241 139.74772423791126 11.655334983573283 35.666695897007 139.7477289984326 10.65720418523344 35.6666976085241 139.74772423791126 10.65720418523344 35.6666976085241 139.74772423791126 11.655334983573283</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_edf8ebc1-82fb-4727-9e79-2e9e7592dc5d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fded2da8-6067-43fc-9047-75e2a9336fda">
											<gml:posList>35.666720410832845 139.74766081524973 8.479500327811564 35.66671446337536 139.74767735770752 8.467033897147502 35.66671446337536 139.74767735770752 6.896645103202189 35.666720410832845 139.74766081524973 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_823145b0-cbe3-49f0-86fe-645781f6cba7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7275bf02-1576-45cc-b65a-51e76237d7a6">
											<gml:posList>35.66671446337536 139.74767735770752 8.467033897147502 35.666720410832845 139.74766081524973 8.479500327811564 35.666720410832845 139.74766081524973 9.74887898992094 35.66671446337536 139.74767735770752 8.467033897147502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_53963051-914c-45bb-ac18-ad55251d5273">
									<gml:exterior>
										<gml:LinearRing gml:id="line_17322206-c634-4a2f-8d75-970b27925c32">
											<gml:posList>35.666720410832845 139.74766081524973 8.479500327811564 35.66671446337536 139.74767735770752 6.896645103202189 35.666720410832845 139.74766081524973 6.071251426444377 35.666720410832845 139.74766081524973 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_862a9be3-ed0c-43b9-9698-67a3d4c30296">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5e5f831e-9e3e-4d0f-82cf-64c5bb6f080f">
											<gml:posList>35.666720410832845 139.74766081524973 6.071251426444377 35.66671446337536 139.74767735770752 6.896645103202189 35.666711044702815 139.74768686644555 6.896645103202189 35.666720410832845 139.74766081524973 6.071251426444377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c11e5b6a-88ab-4993-92fd-62291edd1a96">
									<gml:exterior>
										<gml:LinearRing gml:id="line_376911ef-96ea-48ae-8ea3-b60a8a55d82c">
											<gml:posList>35.666720410832845 139.74766081524973 6.071251426444377 35.666711044702815 139.74768686644555 6.896645103202189 35.66669662610225 139.74772697056582 6.254005943045939 35.666720410832845 139.74766081524973 6.071251426444377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_54192878-62fd-492d-bed7-128483181a45">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f2d7efa3-fe7e-4dda-93db-df7cba9e6982">
											<gml:posList>35.666690819797786 139.74774312015376 27.61948445867094 35.66669001956352 139.74774534596776 28.571503196463908 35.666690819797786 139.74774312015376 24.746124778495158 35.666690819797786 139.74774312015376 27.61948445867094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_208adc91-37cd-490a-bee6-a2e78293aef6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e3ceeb8d-5539-4cc5-b305-8cb5176f0d4a">
											<gml:posList>35.66669001956352 139.74774534596776 28.571503196463908 35.666690819797786 139.74774312015376 27.61948445867094 35.666692724279116 139.74773782311746 28.571503196463908 35.66669001956352 139.74774534596776 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3ed8f15a-ab19-4cd8-aa88-46ebf9703610">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0427b22c-5771-48ec-8d2f-73a4a9012a9b">
											<gml:posList>35.666692724279116 139.74773782311746 28.571503196463908 35.666690819797786 139.74774312015376 27.61948445867094 35.666696092407044 139.74772845500408 27.61948445867094 35.666692724279116 139.74773782311746 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0d417385-8f60-4396-bc09-e81069ba8aad">
									<gml:exterior>
										<gml:LinearRing gml:id="line_199bee18-8dc0-4396-85b4-11d515eea3f3">
											<gml:posList>35.666690819797786 139.74774312015376 24.746124778495158 35.66669001956352 139.74774534596776 28.571503196463908 35.66669001956352 139.74774534596776 6.071251426444377 35.666690819797786 139.74774312015376 24.746124778495158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a16e35f6-222b-4ac4-b200-c9c2a700987b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c298e022-65f4-4678-af7c-ae36da24e272">
											<gml:posList>35.666690819797786 139.74774312015376 24.746124778495158 35.66669001956352 139.74774534596776 6.071251426444377 35.66669074176127 139.74774333715422 8.420250449881877 35.666690819797786 139.74774312015376 24.746124778495158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d056125a-876d-4917-90d3-2d7e49aebdc6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9baa8e4d-f064-4bab-801a-57233748e278">
											<gml:posList>35.666690819797786 139.74774312015376 24.746124778495158 35.666693650799196 139.7477352460897 23.705933128104533 35.666696092407044 139.74772845500408 24.746124778495158 35.666690819797786 139.74774312015376 24.746124778495158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a7189360-6606-4d0d-ad95-f90af73fd030">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e7dd65cc-8a36-4c83-a377-229ac66083e0">
											<gml:posList>35.666693650799196 139.7477352460897 23.705933128104533 35.666690819797786 139.74774312015376 24.746124778495158 35.666693650799196 139.7477352460897 22.70780232976469 35.666693650799196 139.7477352460897 23.705933128104533</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_948b105f-859b-4394-ab58-7f8a9680d498">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d5c5f761-e7c9-47fe-9153-b19240ac380e">
											<gml:posList>35.666696092407044 139.74772845500408 24.746124778495158 35.666699854765724 139.7477179902535 23.705933128104533 35.666699854765724 139.7477179902535 25.678253684745158 35.666696092407044 139.74772845500408 24.746124778495158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d795b2d1-443f-4a34-ad01-9885b8effe58">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a8340614-67cc-4b57-a74e-201151186928">
											<gml:posList>35.666699854765724 139.7477179902535 23.705933128104533 35.666696092407044 139.74772845500408 24.746124778495158 35.6666976085241 139.74772423791126 23.705933128104533 35.666699854765724 139.7477179902535 23.705933128104533</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_95223c01-b6e2-4c97-be6e-9e7b22524032">
									<gml:exterior>
										<gml:LinearRing gml:id="line_39a07dbd-8a4b-4a39-b3ee-eccfab5baadf">
											<gml:posList>35.666696092407044 139.74772845500408 24.746124778495158 35.666693650799196 139.7477352460897 23.705933128104533 35.666695897007 139.7477289984326 23.705933128104533 35.666696092407044 139.74772845500408 24.746124778495158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5e505939-f6e6-4b35-bdae-14c5d6302e12">
									<gml:exterior>
										<gml:LinearRing gml:id="line_28dd5e5c-79dc-49a6-94a3-dc28a6949469">
											<gml:posList>35.666696092407044 139.74772845500408 24.746124778495158 35.666695897007 139.7477289984326 23.705933128104533 35.6666976085241 139.74772423791126 23.705933128104533 35.666696092407044 139.74772845500408 24.746124778495158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_64f63c62-ea26-4407-a8b0-671fb5a0b399">
									<gml:exterior>
										<gml:LinearRing gml:id="line_85f95452-adcc-4a1e-badb-461ff1336ba7">
											<gml:posList>35.666690819797786 139.74774312015376 24.746124778495158 35.66669074176127 139.74774333715422 8.420250449881877 35.666693650799196 139.7477352460897 16.687523399100627 35.666690819797786 139.74774312015376 24.746124778495158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_007de3d4-b446-45d9-9289-49b4fe831b07">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fa80a452-f489-4db3-829c-6cdd7b1dfef9">
											<gml:posList>35.666693650799196 139.7477352460897 22.70780232976469 35.666690819797786 139.74774312015376 24.746124778495158 35.666693650799196 139.7477352460897 20.680603538260783 35.666693650799196 139.7477352460897 22.70780232976469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ca56d8b0-12b2-4301-a4b1-70401d022fae">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d6acba7d-7a17-417b-bf6e-57f0b5b28a31">
											<gml:posList>35.666693650799196 139.7477352460897 22.70780232976469 35.666693650799196 139.7477352460897 20.680603538260783 35.666695897007 139.7477289984326 22.70780232976469 35.666693650799196 139.7477352460897 22.70780232976469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6401ee3a-994d-4459-b615-b7ccd592594d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_29800616-6457-4bea-9ad2-d090c5ebd96e">
											<gml:posList>35.666695897007 139.7477289984326 20.680603538260783 35.666695897007 139.7477289984326 22.70780232976469 35.666693650799196 139.7477352460897 20.680603538260783 35.666695897007 139.7477289984326 20.680603538260783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d8562dfa-7a98-4ae5-9b8b-23a8d32b091d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_db2f44b8-f059-4ca9-b939-720854873686">
											<gml:posList>35.666695897007 139.7477289984326 22.70780232976469 35.666695897007 139.7477289984326 20.680603538260783 35.6666976085241 139.74772423791126 22.70780232976469 35.666695897007 139.7477289984326 22.70780232976469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_34f15621-c6a7-4299-ade2-3b0e5ee7499c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_79bc6920-9587-4dff-a4a1-105c8b1f8125">
											<gml:posList>35.666711044702815 139.74768686644555 22.438179527030314 35.666711044702815 139.74768686644555 21.007813010917033 35.66671446337536 139.74767735770752 22.438179527030314 35.666711044702815 139.74768686644555 22.438179527030314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0ab2e37d-c96a-45ff-aa24-b04eafd7a00f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_66e6c609-85ac-4d55-adcf-d6b74f89090a">
											<gml:posList>35.6666976085241 139.74772423791126 22.70780232976469 35.666695897007 139.7477289984326 20.680603538260783 35.6666976085241 139.74772423791126 20.680603538260783 35.6666976085241 139.74772423791126 22.70780232976469</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_837c8cae-faf4-48f0-b618-73dcd5cbd180">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e93ab99f-4042-4e26-88f6-d03abe9e1866">
											<gml:posList>35.666693650799196 139.7477352460897 20.680603538260783 35.666690819797786 139.74774312015376 24.746124778495158 35.666693650799196 139.7477352460897 19.68247273992094 35.666693650799196 139.7477352460897 20.680603538260783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a064bef6-e131-4b88-8827-98a5e8b80a09">
									<gml:exterior>
										<gml:LinearRing gml:id="line_65894a46-7244-4898-a871-bf52180439a5">
											<gml:posList>35.666693650799196 139.7477352460897 19.68247273992094 35.666690819797786 139.74774312015376 24.746124778495158 35.666693650799196 139.7477352460897 17.68565419744047 35.666693650799196 139.7477352460897 19.68247273992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_13e3f58a-63b1-4c78-941b-4a7707e12dda">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1283253b-635f-40d5-be89-a804bd1a1578">
											<gml:posList>35.666693650799196 139.7477352460897 17.68565419744047 35.666690819797786 139.74774312015376 24.746124778495158 35.666693650799196 139.7477352460897 16.687523399100627 35.666693650799196 139.7477352460897 17.68565419744047</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4faa31b4-4c42-4b0e-96c9-e8c6cef781de">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5b419c89-e9b1-4f75-9f0c-d7c6d5d820ec">
											<gml:posList>35.666693650799196 139.7477352460897 19.68247273992094 35.666693650799196 139.7477352460897 17.68565419744047 35.666695897007 139.7477289984326 17.68565419744047 35.666693650799196 139.7477352460897 19.68247273992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1fc74afd-6c4d-4c70-8521-d032c3fb9c8d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a1a1c919-efe4-4b91-9480-fcc6b807d347">
											<gml:posList>35.666695897007 139.7477289984326 17.68565419744047 35.666695897007 139.7477289984326 19.68247273992094 35.666693650799196 139.7477352460897 19.68247273992094 35.666695897007 139.7477289984326 17.68565419744047</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_05cfe847-a8fc-4077-966c-3f6ab43d0d58">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2413595e-0b03-4125-95f2-9ccfe49ba843">
											<gml:posList>35.666695897007 139.7477289984326 19.68247273992094 35.666695897007 139.7477289984326 17.68565419744047 35.6666976085241 139.74772423791126 17.68565419744047 35.666695897007 139.7477289984326 19.68247273992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_711c09c2-971d-4008-8ec6-869ba5ccf4eb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_822add59-4af6-4bd3-be1c-9c6724de80fe">
											<gml:posList>35.666711044702815 139.74768686644555 19.437431846366252 35.666711044702815 139.74768686644555 17.99051717351469 35.66671446337536 139.74767735770752 19.437431846366252 35.666711044702815 139.74768686644555 19.437431846366252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f9e7e5af-70af-4129-9c24-00fc2b75373f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0b8a4120-9638-4674-85c3-22292aed61bb">
											<gml:posList>35.666695897007 139.7477289984326 19.68247273992094 35.6666976085241 139.74772423791126 17.68565419744047 35.6666976085241 139.74772423791126 19.68247273992094 35.666695897007 139.7477289984326 19.68247273992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f2068072-d387-44ea-ae3a-3f6049ce3de3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8890f484-135f-4f12-b6df-d8e9548f1e5b">
											<gml:posList>35.666693650799196 139.7477352460897 16.687523399100627 35.66669074176127 139.74774333715422 8.420250449881877 35.666693650799196 139.7477352460897 14.68870595525297 35.666693650799196 139.7477352460897 16.687523399100627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8e6b75e0-f1ca-4109-a8af-3977a90dbf38">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cc77b6d7-7f16-4788-8224-4e2ff7a35b43">
											<gml:posList>35.666693650799196 139.7477352460897 16.687523399100627 35.666693650799196 139.7477352460897 14.68870595525297 35.666695897007 139.7477289984326 14.68870595525297 35.666693650799196 139.7477352460897 16.687523399100627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8f9e8760-2d37-47bf-a7a9-8eb5a5ea9eec">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a05f3ae6-8b2d-4241-a719-828ee1f7bd9d">
											<gml:posList>35.666695897007 139.7477289984326 14.68870595525297 35.666695897007 139.7477289984326 16.687523399100627 35.666693650799196 139.7477352460897 16.687523399100627 35.666695897007 139.7477289984326 14.68870595525297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_be42ea7f-a018-4e43-a7f6-589d50220067">
									<gml:exterior>
										<gml:LinearRing gml:id="line_05bedacd-7a6d-43a6-b32b-b79b1887b20c">
											<gml:posList>35.666695897007 139.7477289984326 16.687523399100627 35.666695897007 139.7477289984326 14.68870595525297 35.6666976085241 139.74772423791126 14.68870595525297 35.666695897007 139.7477289984326 16.687523399100627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_07c6a68b-1c8c-4b9b-a136-dde24876ec1a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_db17c582-0420-46d7-a394-0479259a9888">
											<gml:posList>35.666711044702815 139.74768686644555 16.420136008963908 35.666711044702815 139.74768686644555 14.993195090995158 35.66671446337536 139.74767735770752 16.420136008963908 35.666711044702815 139.74768686644555 16.420136008963908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6734c000-c88b-4ce4-a0d9-a455b5c75d92">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e0524838-5b49-4623-82d4-7b3e9169e978">
											<gml:posList>35.666695897007 139.7477289984326 16.687523399100627 35.6666976085241 139.74772423791126 14.68870595525297 35.6666976085241 139.74772423791126 16.687523399100627 35.666695897007 139.7477289984326 16.687523399100627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_513bccf1-fc24-4f62-87ad-357cd645fd39">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2b649519-b84b-4a82-8748-699316749c80">
											<gml:posList>35.666693650799196 139.7477352460897 14.68870595525297 35.66669074176127 139.74774333715422 8.420250449881877 35.666693650799196 139.7477352460897 13.690575156913127 35.666693650799196 139.7477352460897 14.68870595525297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d7022b49-2348-4e02-8ff6-ea187624266a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b3d56edd-22c5-410b-a5e7-158795a2d6e7">
											<gml:posList>35.666693650799196 139.7477352460897 13.690575156913127 35.66669074176127 139.74774333715422 8.420250449881877 35.666693650799196 139.7477352460897 11.655334983573283 35.666693650799196 139.7477352460897 13.690575156913127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_45b07a29-cbed-4e74-bf70-4747f4720eb8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a6030d13-2fb4-432b-982f-40cf6c458c2c">
											<gml:posList>35.666693650799196 139.7477352460897 13.690575156913127 35.666693650799196 139.7477352460897 11.655334983573283 35.666695897007 139.7477289984326 11.655334983573283 35.666693650799196 139.7477352460897 13.690575156913127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_de2954e2-3c90-4dcb-9da4-4d4a8c00577f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0be528e8-78c7-4e84-8de8-824c8157cfb4">
											<gml:posList>35.666695897007 139.7477289984326 11.655334983573283 35.666695897007 139.7477289984326 13.690575156913127 35.666693650799196 139.7477352460897 13.690575156913127 35.666695897007 139.7477289984326 11.655334983573283</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bc21221b-388f-4510-90c0-9033d975f5cf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4c0379fc-1c13-4a2c-a14c-afbc00c5cac1">
											<gml:posList>35.666695897007 139.7477289984326 13.690575156913127 35.666695897007 139.7477289984326 11.655334983573283 35.6666976085241 139.74772423791126 11.655334983573283 35.666695897007 139.7477289984326 13.690575156913127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6d02b27b-4940-4225-8b3f-bec53742674c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_34402d6a-0305-49ca-97ec-908abee4cda5">
											<gml:posList>35.6666976085241 139.74772423791126 11.655334983573283 35.6666976085241 139.74772423791126 13.690575156913127 35.666695897007 139.7477289984326 13.690575156913127 35.6666976085241 139.74772423791126 11.655334983573283</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a7e362b0-4202-4e85-92ae-e4dee3b69f2b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_00fd2f72-f3c2-42fd-91cb-c3829840043b">
											<gml:posList>35.66671446337536 139.74767735770752 11.965302024588908 35.66671446337536 139.74767735770752 13.422806297049846 35.666711044702815 139.74768686644555 11.965302024588908 35.66671446337536 139.74767735770752 11.965302024588908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_10420ce7-d41c-4ad2-a320-adc69fdc499c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c20d72a0-4b20-432f-916f-7d8126534613">
											<gml:posList>35.666711044702815 139.74768686644555 13.422806297049846 35.666711044702815 139.74768686644555 11.965302024588908 35.66671446337536 139.74767735770752 13.422806297049846 35.666711044702815 139.74768686644555 13.422806297049846</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d47e9032-10d3-483e-a74d-e53d4f0dc3d5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2280201a-4ab0-41b6-a9a3-2453cd84e27b">
											<gml:posList>35.666693650799196 139.7477352460897 11.655334983573283 35.66669074176127 139.74774333715422 8.420250449881877 35.666693650799196 139.7477352460897 10.65720418523344 35.666693650799196 139.7477352460897 11.655334983573283</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_91416e4d-39c2-4be6-b372-e7f8640531ff">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a679feea-50d0-47a3-962b-75b5ce95221d">
											<gml:posList>35.666693650799196 139.7477352460897 10.65720418523344 35.66669074176127 139.74774333715422 8.420250449881877 35.66669662610225 139.74772697056582 8.420250449881877 35.666693650799196 139.7477352460897 10.65720418523344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_543aa20a-de6b-45da-a67f-eb124250b718">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d02a0042-7bed-421f-b5af-fb3b65f7fc1e">
											<gml:posList>35.66669662610225 139.74772697056582 8.420250449881877 35.666695897007 139.7477289984326 10.65720418523344 35.666693650799196 139.7477352460897 10.65720418523344 35.66669662610225 139.74772697056582 8.420250449881877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0721a177-6a5d-4fc9-a778-dacf461171ff">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d3bc01db-0732-479e-8e66-a3ddc9d39338">
											<gml:posList>35.666711044702815 139.74768686644555 8.467033897147502 35.66671446337536 139.74767735770752 10.394913230643596 35.666711044702815 139.74768686644555 10.394913230643596 35.666711044702815 139.74768686644555 8.467033897147502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b05ca248-989f-461e-9986-8926708497f6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_930bc109-ac64-452b-8b1d-5130caa56cbc">
											<gml:posList>35.66671446337536 139.74767735770752 10.394913230643596 35.666711044702815 139.74768686644555 8.467033897147502 35.66671446337536 139.74767735770752 8.467033897147502 35.66671446337536 139.74767735770752 10.394913230643596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d87a181c-6bb6-4d6f-b2c1-2bc308273da9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2ffe2878-dc55-40f2-9da8-26ac4ffc3791">
											<gml:posList>35.66669074176127 139.74774333715422 8.420250449881877 35.66669001956352 139.74774534596776 6.071251426444377 35.66669074176127 139.74774333715422 6.254005943045939 35.66669074176127 139.74774333715422 8.420250449881877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7794f597-2d1e-49e9-970d-f456f90b5e1d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ce243692-7d22-4075-926c-0945ecf0cf1c">
											<gml:posList>35.66669074176127 139.74774333715422 6.254005943045939 35.66669001956352 139.74774534596776 6.071251426444377 35.66669662610225 139.74772697056582 6.254005943045939 35.66669074176127 139.74774333715422 6.254005943045939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a9d8bc2d-98aa-4181-9bb2-b5beb0d7dc81">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a9046339-394a-480a-9ecb-a065ac3b2be9">
											<gml:posList>35.66669662610225 139.74772697056582 6.254005943045939 35.66669001956352 139.74774534596776 6.071251426444377 35.666720410832845 139.74766081524973 6.071251426444377 35.66669662610225 139.74772697056582 6.254005943045939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f4a688af-414e-48e2-9b3f-00fff6af1922">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ce00d46f-f7e4-491c-88f9-5ea6a58b39ed">
											<gml:posList>35.666711044702815 139.74768686644555 8.467033897147502 35.66669662610225 139.74772697056582 8.420250449881877 35.666711044702815 139.74768686644555 6.896645103202189 35.666711044702815 139.74768686644555 8.467033897147502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_24c259e9-0130-47ca-a029-b7ed6e95a612">
									<gml:exterior>
										<gml:LinearRing gml:id="line_73f114bf-73e4-4ae0-bf8f-a2843c879617">
											<gml:posList>35.666711044702815 139.74768686644555 6.896645103202189 35.66669662610225 139.74772697056582 8.420250449881877 35.66669662610225 139.74772697056582 6.254005943045939 35.666711044702815 139.74768686644555 6.896645103202189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_4ba6c4fc-e5e6-4e04-8e61-ffd1fe50fff3">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_d3a3b32e-5857-4e51-86f0-10ddee8e4486">
											<gml:exterior>
												<gml:LinearRing gml:id="line_c965701e-c5c3-4ee3-b2df-4767b32d9299">
													<gml:posList>35.66671446337536 139.74767735770752 14.993195090995158 35.666711044702815 139.74768686644555 14.993195090995158 35.66671446337536 139.74767735770752 13.422806297049846 35.66671446337536 139.74767735770752 14.993195090995158</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_208d28ff-10ab-49a8-88c2-fcc144177aa7">
											<gml:exterior>
												<gml:LinearRing gml:id="line_c0b23424-a09b-4e8f-83bc-0469f69395df">
													<gml:posList>35.66671446337536 139.74767735770752 13.422806297049846 35.666711044702815 139.74768686644555 14.993195090995158 35.666711044702815 139.74768686644555 13.422806297049846 35.66671446337536 139.74767735770752 13.422806297049846</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_572af007-8235-4cd7-841d-c4cc5e96f746">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_eb81b1b2-bb32-4f5a-8e4d-a2e2943dcd65">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e7e6e7e4-0746-4244-98ac-125a7cec8638">
													<gml:posList>35.66671446337536 139.74767735770752 27.004204307303752 35.666711044702815 139.74768686644555 27.004204307303752 35.66671446337536 139.74767735770752 25.43382314275297 35.66671446337536 139.74767735770752 27.004204307303752</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_ccd87c8f-56c0-48e2-847e-88718b42b48c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_7c577585-0250-4df6-8ef7-ddc5bb3bb1f2">
													<gml:posList>35.66671446337536 139.74767735770752 25.43382314275297 35.666711044702815 139.74768686644555 27.004204307303752 35.666711044702815 139.74768686644555 25.43382314275297 35.66671446337536 139.74767735770752 25.43382314275297</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_c6af65f7-3ddd-4f1d-9100-aafeaeb5cacb">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_36f261e1-b7b8-433b-a4aa-5f48c20ff8a0">
											<gml:exterior>
												<gml:LinearRing gml:id="line_cdadc041-8e7a-4161-9910-cd54881d2abc">
													<gml:posList>35.66671446337536 139.74767735770752 21.007813010917033 35.666711044702815 139.74768686644555 21.007813010917033 35.66671446337536 139.74767735770752 19.437431846366252 35.66671446337536 139.74767735770752 21.007813010917033</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_5f10e8b8-ff05-46cc-b949-65e3db9a18b8">
											<gml:exterior>
												<gml:LinearRing gml:id="line_a1867420-d900-4fab-bb9c-68a6d6e6e967">
													<gml:posList>35.66671446337536 139.74767735770752 19.437431846366252 35.666711044702815 139.74768686644555 21.007813010917033 35.666711044702815 139.74768686644555 19.437431846366252 35.66671446337536 139.74767735770752 19.437431846366252</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_9dc3e4ab-9644-4dd4-ab5d-39b6b22de56c">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_c4235ba8-4c31-4771-b65c-dc13cb63d79a">
											<gml:exterior>
												<gml:LinearRing gml:id="line_9bfd39b3-1419-4f17-adb7-8af6069a63a1">
													<gml:posList>35.666695897007 139.7477289984326 13.690575156913127 35.666695897007 139.7477289984326 14.68870595525297 35.666693650799196 139.7477352460897 13.690575156913127 35.666695897007 139.7477289984326 13.690575156913127</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_2ee09e93-85d9-45ff-a22d-a8a1dbfe0b63">
											<gml:exterior>
												<gml:LinearRing gml:id="line_069d1d42-218d-4edb-a690-c84b649f990e">
													<gml:posList>35.666693650799196 139.7477352460897 13.690575156913127 35.666695897007 139.7477289984326 14.68870595525297 35.666693650799196 139.7477352460897 14.68870595525297 35.666693650799196 139.7477352460897 13.690575156913127</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_2314b657-6e27-4eba-8b16-ffe4f15bf3cb">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_7a8e00bc-e458-4893-8b11-aa3d8a2236ce">
											<gml:exterior>
												<gml:LinearRing gml:id="line_f7e81d11-1229-473a-bc16-2a9b9aa1728c">
													<gml:posList>35.666699854765724 139.7477179902535 16.687523399100627 35.666699854765724 139.7477179902535 17.68565419744047 35.6666976085241 139.74772423791126 17.68565419744047 35.666699854765724 139.7477179902535 16.687523399100627</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_f31c265f-ca09-4317-8022-bf3f2da14fb9">
											<gml:exterior>
												<gml:LinearRing gml:id="line_0e7f0033-bdad-41b5-bab5-e44b27acdeee">
													<gml:posList>35.666699854765724 139.7477179902535 16.687523399100627 35.6666976085241 139.74772423791126 17.68565419744047 35.6666976085241 139.74772423791126 16.687523399100627 35.666699854765724 139.7477179902535 16.687523399100627</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_2124f8b0-3bf0-4301-85a2-5b5c70e872cf">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_18dd3d70-e0b0-4d81-b56a-820d9b1b9873">
											<gml:exterior>
												<gml:LinearRing gml:id="line_20c52e4b-2bfd-4107-bdc5-010798835d14">
													<gml:posList>35.66671446337536 139.74767735770752 17.99051717351469 35.666711044702815 139.74768686644555 17.99051717351469 35.66671446337536 139.74767735770752 16.420136008963908 35.66671446337536 139.74767735770752 17.99051717351469</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_6227b9d4-2329-463b-9faf-56f953aa6d26">
											<gml:exterior>
												<gml:LinearRing gml:id="line_265d89c5-df7c-4496-9417-55bd5555ed9a">
													<gml:posList>35.66671446337536 139.74767735770752 16.420136008963908 35.666711044702815 139.74768686644555 17.99051717351469 35.666711044702815 139.74768686644555 16.420136008963908 35.66671446337536 139.74767735770752 16.420136008963908</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_c017a281-c6ce-4fa2-bbb9-8a218aa2ba36">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_47348424-2aaf-49e0-b341-6d10e26c2542">
											<gml:exterior>
												<gml:LinearRing gml:id="line_1e78c673-6154-45ab-a8ba-fbd9bc39bba1">
													<gml:posList>35.666695897007 139.7477289984326 19.68247273992094 35.666695897007 139.7477289984326 20.680603538260783 35.666693650799196 139.7477352460897 19.68247273992094 35.666695897007 139.7477289984326 19.68247273992094</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_1d9b1bb3-e414-46ff-a412-6a37ea575e9b">
											<gml:exterior>
												<gml:LinearRing gml:id="line_7014b2c5-779b-45b5-a4ea-5feb2d8567bd">
													<gml:posList>35.666693650799196 139.7477352460897 19.68247273992094 35.666695897007 139.7477289984326 20.680603538260783 35.666693650799196 139.7477352460897 20.680603538260783 35.666693650799196 139.7477352460897 19.68247273992094</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_7c1fda65-9213-49dd-9cd1-851dfa8fc1a3">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_b2932cc5-64d0-46ec-a34a-8c4692499e32">
											<gml:exterior>
												<gml:LinearRing gml:id="line_ba5fd36e-ef66-48ed-9a06-96b396d0f26b">
													<gml:posList>35.66671446337536 139.74767735770752 11.965302024588908 35.666711044702815 139.74768686644555 11.965302024588908 35.66671446337536 139.74767735770752 10.394913230643596 35.66671446337536 139.74767735770752 11.965302024588908</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_92c13349-f08e-4553-8bf9-b6994e32f10b">
											<gml:exterior>
												<gml:LinearRing gml:id="line_4eef45ed-3c3b-46d7-96c6-9a7f483fc09b">
													<gml:posList>35.66671446337536 139.74767735770752 10.394913230643596 35.666711044702815 139.74768686644555 11.965302024588908 35.666711044702815 139.74768686644555 10.394913230643596 35.66671446337536 139.74767735770752 10.394913230643596</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_1d9cd798-8258-4fad-931c-e8a6dee3b00c">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_9e92c8ef-caef-4694-bf8d-3d17dadd612f">
											<gml:exterior>
												<gml:LinearRing gml:id="line_ecd8040d-1b8b-45d8-98ea-3f853f4dcc97">
													<gml:posList>35.666699854765724 139.7477179902535 25.678253684745158 35.666699854765724 139.7477179902535 26.676384483085002 35.6666976085241 139.74772423791126 25.678253684745158 35.666699854765724 139.7477179902535 25.678253684745158</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_10518501-482e-423c-808c-779b08ebe107">
											<gml:exterior>
												<gml:LinearRing gml:id="line_a417f878-e300-469d-8bb0-34d85e10f141">
													<gml:posList>35.6666976085241 139.74772423791126 25.678253684745158 35.666699854765724 139.7477179902535 26.676384483085002 35.6666976085241 139.74772423791126 26.676384483085002 35.6666976085241 139.74772423791126 25.678253684745158</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_52f5f451-ddf3-43f8-8827-2c01e4d0f436">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_8df15708-0546-431b-a5bf-de4fcf3137e9">
											<gml:exterior>
												<gml:LinearRing gml:id="line_d798e5c5-b45b-4800-bb0b-8e9794406935">
													<gml:posList>35.666699854765724 139.7477179902535 22.70780232976469 35.666699854765724 139.7477179902535 23.705933128104533 35.6666976085241 139.74772423791126 23.705933128104533 35.666699854765724 139.7477179902535 22.70780232976469</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_05c5ecf0-c20d-473f-953f-ecfac3007d70">
											<gml:exterior>
												<gml:LinearRing gml:id="line_0fb390db-4f98-4278-a308-ed2003f552d6">
													<gml:posList>35.666699854765724 139.7477179902535 22.70780232976469 35.6666976085241 139.74772423791126 23.705933128104533 35.6666976085241 139.74772423791126 22.70780232976469 35.666699854765724 139.7477179902535 22.70780232976469</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_67f7b956-c76b-44ce-8548-85c392d6e5e4">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_c7f7205d-32f7-467b-b3a3-55067fee59b3">
											<gml:exterior>
												<gml:LinearRing gml:id="line_2143e3a8-23e5-483c-a0b8-2621720d1072">
													<gml:posList>35.666699854765724 139.7477179902535 19.68247273992094 35.666699854765724 139.7477179902535 20.680603538260783 35.6666976085241 139.74772423791126 19.68247273992094 35.666699854765724 139.7477179902535 19.68247273992094</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_2c54404c-c1c8-4aeb-8780-7503763681d3">
											<gml:exterior>
												<gml:LinearRing gml:id="line_bf6800df-3df8-48df-a3b4-8e6032dd0996">
													<gml:posList>35.6666976085241 139.74772423791126 19.68247273992094 35.666699854765724 139.7477179902535 20.680603538260783 35.6666976085241 139.74772423791126 20.680603538260783 35.6666976085241 139.74772423791126 19.68247273992094</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_cb6cc04e-687b-4512-8aae-e6756e5a1e05">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_ecefa44c-51fb-4e58-97bd-a89390d348de">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e3ceb56a-c787-4ecd-b97e-827a7943bd08">
													<gml:posList>35.66671446337536 139.74767735770752 8.467033897147502 35.666711044702815 139.74768686644555 8.467033897147502 35.66671446337536 139.74767735770752 6.896645103202189 35.66671446337536 139.74767735770752 8.467033897147502</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_609491ad-13d7-4377-b31c-26a7891bd49f">
											<gml:exterior>
												<gml:LinearRing gml:id="line_43f6018e-f90c-43b6-ba3b-059ba3dfb19c">
													<gml:posList>35.66671446337536 139.74767735770752 6.896645103202189 35.666711044702815 139.74768686644555 8.467033897147502 35.666711044702815 139.74768686644555 6.896645103202189 35.66671446337536 139.74767735770752 6.896645103202189</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_ee4099e2-2cb0-4297-8dd6-0c389959efd3">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_63f4e8a2-58e1-4065-8627-b2f017b446d2">
											<gml:exterior>
												<gml:LinearRing gml:id="line_819c7bcf-5583-47c9-8ccd-3f563f1fc972">
													<gml:posList>35.66671446337536 139.74767735770752 24.008568320975627 35.666711044702815 139.74768686644555 24.008568320975627 35.66671446337536 139.74767735770752 22.438179527030314 35.66671446337536 139.74767735770752 24.008568320975627</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_b2f92e7c-bde3-467c-8ed6-8c4d1ea33c55">
											<gml:exterior>
												<gml:LinearRing gml:id="line_51651e67-23e7-43ca-ab2d-0b9b98eaedd5">
													<gml:posList>35.66671446337536 139.74767735770752 22.438179527030314 35.666711044702815 139.74768686644555 24.008568320975627 35.666711044702815 139.74768686644555 22.438179527030314 35.66671446337536 139.74767735770752 22.438179527030314</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_e152dc5e-3b62-40b1-a82b-866f6cc67b4c">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_a37d0e46-a1ef-4e6f-a035-b901e2839d0f">
											<gml:exterior>
												<gml:LinearRing gml:id="line_89f541f9-700a-435c-9e7c-43554f4407fe">
													<gml:posList>35.666699854765724 139.7477179902535 10.65720418523344 35.666699854765724 139.7477179902535 11.655334983573283 35.6666976085241 139.74772423791126 10.65720418523344 35.666699854765724 139.7477179902535 10.65720418523344</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_5a5153c4-ce15-4781-b8d3-6c82cc3dd759">
											<gml:exterior>
												<gml:LinearRing gml:id="line_85a8e00b-be97-4f9d-9d6a-9b4556354498">
													<gml:posList>35.6666976085241 139.74772423791126 10.65720418523344 35.666699854765724 139.7477179902535 11.655334983573283 35.6666976085241 139.74772423791126 11.655334983573283 35.6666976085241 139.74772423791126 10.65720418523344</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_a2d7c122-8662-4976-ae3e-d973e7e033e2">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_2af7e81f-a60c-4e15-919e-103f9095ef3b">
											<gml:exterior>
												<gml:LinearRing gml:id="line_cd3ef9ac-7129-42ca-894a-a69d2d65c2e7">
													<gml:posList>35.666695897007 139.7477289984326 16.687523399100627 35.666695897007 139.7477289984326 17.68565419744047 35.666693650799196 139.7477352460897 16.687523399100627 35.666695897007 139.7477289984326 16.687523399100627</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_c3241aee-59dc-40e2-a40e-cd895f14e8e8">
											<gml:exterior>
												<gml:LinearRing gml:id="line_ccd9c5a9-47e6-4e43-8e84-d2e33c70777a">
													<gml:posList>35.666693650799196 139.7477352460897 16.687523399100627 35.666695897007 139.7477289984326 17.68565419744047 35.666693650799196 139.7477352460897 17.68565419744047 35.666693650799196 139.7477352460897 16.687523399100627</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_69dcaa6e-802e-4702-b8b2-37e83fc25c28">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_41640472-f893-4e6f-ac41-4305cc5b037b">
											<gml:exterior>
												<gml:LinearRing gml:id="line_30f2e78c-ede6-4b91-9363-be5a7c028f4c">
													<gml:posList>35.666695897007 139.7477289984326 22.70780232976469 35.666695897007 139.7477289984326 23.705933128104533 35.666693650799196 139.7477352460897 22.70780232976469 35.666695897007 139.7477289984326 22.70780232976469</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_635c710c-c465-4a7f-ae49-26a0c740babc">
											<gml:exterior>
												<gml:LinearRing gml:id="line_d63d3eea-b2cf-418b-9ce8-bad5aeb15e31">
													<gml:posList>35.666693650799196 139.7477352460897 22.70780232976469 35.666695897007 139.7477289984326 23.705933128104533 35.666693650799196 139.7477352460897 23.705933128104533 35.666693650799196 139.7477352460897 22.70780232976469</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_86e86915-f7d2-4836-83bb-32ef9549fd9d">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_edc2dcba-e8a5-4b4d-87c7-7eca01e0579a">
											<gml:exterior>
												<gml:LinearRing gml:id="line_e83ff5df-100c-455c-b301-883635e24868">
													<gml:posList>35.666695897007 139.7477289984326 10.65720418523344 35.666695897007 139.7477289984326 11.655334983573283 35.666693650799196 139.7477352460897 10.65720418523344 35.666695897007 139.7477289984326 10.65720418523344</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_ccd87625-e1a5-4cee-b87d-4160e3bf29fc">
											<gml:exterior>
												<gml:LinearRing gml:id="line_6f258433-3f05-4736-bf37-6f5780fdeca1">
													<gml:posList>35.666693650799196 139.7477352460897 10.65720418523344 35.666695897007 139.7477289984326 11.655334983573283 35.666693650799196 139.7477352460897 11.655334983573283 35.666693650799196 139.7477352460897 10.65720418523344</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
					<bldg:opening>
						<bldg:Window gml:id="wnd_03b4fc38-c7fc-4611-ae3b-6a87aa1ea84d">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_7ed5db8b-dd8a-46c1-b917-9ceaef64d714">
											<gml:exterior>
												<gml:LinearRing gml:id="line_8fb07f4f-a367-48fe-b128-418094b41dea">
													<gml:posList>35.666699854765724 139.7477179902535 13.690575156913127 35.666699854765724 139.7477179902535 14.68870595525297 35.6666976085241 139.74772423791126 13.690575156913127 35.666699854765724 139.7477179902535 13.690575156913127</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_ba32b11b-c0c5-4097-891a-f8aa786f229e">
											<gml:exterior>
												<gml:LinearRing gml:id="line_60392124-81f9-4b53-8446-a29d827f6326">
													<gml:posList>35.6666976085241 139.74772423791126 13.690575156913127 35.666699854765724 139.7477179902535 14.68870595525297 35.6666976085241 139.74772423791126 14.68870595525297 35.6666976085241 139.74772423791126 13.690575156913127</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0179_p1043_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0179_p1043_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0179_p1043_2">
											<gml:posList>35.666675018219074 139.74772590839518 34.24834632 35.66667503846401 139.7477259133297 28.32334676 35.66669777911302 139.7477362880604 28.32437472 35.66669775884681 139.7477362831162 34.24937428 35.666675018219074 139.74772590839518 34.24834632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_b325e21e-6172-4d80-8dbf-bf6bfb1cbdb5">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fc2da5d4-60c0-4f1a-b1a1-453c197d7443">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ac200ea0-0bd0-4d93-917c-606f139963fa">
											<gml:posList>35.66671902256926 139.74765670811493 28.571503196463908 35.666715766983046 139.74764707655842 13.22275594304594 35.666715766983046 139.74764707655842 28.571503196463908 35.66671902256926 139.74765670811493 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_98db2a5f-a0f0-4d48-9a05-c0e4de805844">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5e25202a-9832-4c91-9082-6434f84c71d4">
											<gml:posList>35.666715766983046 139.74764707655842 13.22275594304594 35.66671902256926 139.74765670811493 28.571503196463908 35.666720410832845 139.74766081524973 13.22275594304594 35.666715766983046 139.74764707655842 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f678aa2c-8a09-4668-83d5-eafa1f2a742f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1c2f2180-a2c1-4e18-9643-cf43508b766d">
											<gml:posList>35.66671902256926 139.74765670811493 28.571503196463908 35.666720410832845 139.74766081524973 34.72238210271391 35.666720410832845 139.74766081524973 13.22275594304594 35.66671902256926 139.74765670811493 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e4233af1-f57e-4bd4-8baa-1686119d60a0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5e9d9169-0b17-40b8-9271-ec54c15cbf0c">
											<gml:posList>35.666720410832845 139.74766081524973 34.72238210271391 35.66671902256926 139.74765670811493 28.571503196463908 35.66671902256926 139.74765670811493 34.72238210271391 35.666720410832845 139.74766081524973 34.72238210271391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1b584339-0976-4e67-b2ac-d9ab2e559eea">
									<gml:exterior>
										<gml:LinearRing gml:id="line_782ec73b-b142-47ab-a784-c695687d4965">
											<gml:posList>35.66671636512583 139.74764884614584 12.13176015447172 35.666720410832845 139.74766081524973 13.22275594304594 35.666720410832845 139.74766081524973 12.13176015447172 35.66671636512583 139.74764884614584 12.13176015447172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_10a5076c-0292-42b0-85f7-5294ea949c6f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cac28d8a-a5f6-494d-9e8d-822d78c7a191">
											<gml:posList>35.666720410832845 139.74766081524973 13.22275594304594 35.66671636512583 139.74764884614584 12.13176015447172 35.666715766983046 139.74764707655842 13.22275594304594 35.666720410832845 139.74766081524973 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b0e9b25c-0f1b-4298-80e2-5e69ed62474e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_974da4a3-cb28-41fb-ad8f-c18aeab82658">
											<gml:posList>35.666715766983046 139.74764707655842 13.22275594304594 35.66671636512583 139.74764884614584 12.13176015447172 35.666706854087415 139.74762070814202 12.13176015447172 35.666715766983046 139.74764707655842 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d6a715c7-3c82-4cb9-b35a-d47f5dd89dff">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a9e0f5e3-f75f-46fe-a1c3-1c85bae59ca5">
											<gml:posList>35.666715766983046 139.74764707655842 13.22275594304594 35.666706854087415 139.74762070814202 12.13176015447172 35.666706854087415 139.74762070814202 13.22275594304594 35.666715766983046 139.74764707655842 13.22275594304594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_36a39ed0-0db3-45ec-ae5c-926ba89a611b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0b30c1b0-4d0d-474a-8900-e8c1364e938a">
											<gml:posList>35.666720410832845 139.74766081524973 12.13176015447172 35.666720410832845 139.74766081524973 9.74887898992094 35.66671636512583 139.74764884614584 12.13176015447172 35.666720410832845 139.74766081524973 12.13176015447172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_248e2bb2-c6d6-4ad9-97f6-f0172539f54e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8a77d040-31ca-418e-8f43-ac0b41a8d0ba">
											<gml:posList>35.66671636512583 139.74764884614584 12.13176015447172 35.666720410832845 139.74766081524973 9.74887898992094 35.66671636512583 139.74764884614584 9.74887898992094 35.66671636512583 139.74764884614584 12.13176015447172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_83a45cbd-99d2-4076-87d3-8ce3cf37f832">
									<gml:exterior>
										<gml:LinearRing gml:id="line_52bf414a-e98c-4313-9b1d-181f0b2edc85">
											<gml:posList>35.66671636512583 139.74764884614584 8.479500327811564 35.666720410832845 139.74766081524973 9.74887898992094 35.666720410832845 139.74766081524973 8.479500327811564 35.66671636512583 139.74764884614584 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5b5132b1-82eb-4d7b-9139-3eba3fa96737">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dc607654-3144-41d6-89ba-71eca6354aff">
											<gml:posList>35.666720410832845 139.74766081524973 9.74887898992094 35.66671636512583 139.74764884614584 8.479500327811564 35.66671636512583 139.74764884614584 9.74887898992094 35.666720410832845 139.74766081524973 9.74887898992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_75e79789-0c8c-48e1-b350-8306401f50ce">
									<gml:exterior>
										<gml:LinearRing gml:id="line_135b5afc-edb4-4cfd-8e53-2517e9542a4e">
											<gml:posList>35.66671636512583 139.74764884614584 9.74887898992094 35.66671636512583 139.74764884614584 8.479500327811564 35.66670775896889 139.74762338518366 8.479500327811564 35.66671636512583 139.74764884614584 9.74887898992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7b345a37-6740-4685-a9f7-28bc2e364bfd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c32b56a2-86e6-4c78-b856-85efc04f9494">
											<gml:posList>35.66670775896889 139.74762338518366 8.479500327811564 35.666706854087415 139.74762070814202 9.74887898992094 35.66671636512583 139.74764884614584 9.74887898992094 35.66670775896889 139.74762338518366 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c82f9690-63ec-414d-af37-fe9b8fc8a084">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2c76dca6-e713-4e1e-a407-2c591fbed1cb">
											<gml:posList>35.666706854087415 139.74762070814202 9.74887898992094 35.66670775896889 139.74762338518366 8.479500327811564 35.666706854087415 139.74762070814202 8.479500327811564 35.666706854087415 139.74762070814202 9.74887898992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_00e7fa0f-f489-4dac-95b3-2429beb7a345">
									<gml:exterior>
										<gml:LinearRing gml:id="line_df8b95b2-eb61-4479-895a-e0514ec9c446">
											<gml:posList>35.66671636512583 139.74764884614584 6.329262290702189 35.666706854087415 139.74762070814202 6.071251426444377 35.66670775896889 139.74762338518366 6.329262290702189 35.66671636512583 139.74764884614584 6.329262290702189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1589e1eb-8ddc-4209-b563-54a3c3b8a387">
									<gml:exterior>
										<gml:LinearRing gml:id="line_98bc3e58-7de5-40e4-8fa0-21753f9e9daf">
											<gml:posList>35.666706854087415 139.74762070814202 6.071251426444377 35.66671636512583 139.74764884614584 6.329262290702189 35.666720410832845 139.74766081524973 6.071251426444377 35.666706854087415 139.74762070814202 6.071251426444377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7268c920-aecb-4983-8803-d07e7542d9f0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3ed47b2d-a68a-4d22-aa8c-268d00b87c4e">
											<gml:posList>35.66670775896889 139.74762338518366 6.329262290702189 35.666706854087415 139.74762070814202 6.071251426444377 35.666706854087415 139.74762070814202 8.479500327811564 35.66670775896889 139.74762338518366 6.329262290702189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_14e7ecb2-9306-4d73-986f-7479a207417d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e36de4b7-12ef-48da-8898-e4cd95136138">
											<gml:posList>35.66671636512583 139.74764884614584 6.329262290702189 35.666720410832845 139.74766081524973 8.479500327811564 35.666720410832845 139.74766081524973 6.071251426444377 35.66671636512583 139.74764884614584 6.329262290702189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7d716956-d959-4738-af09-d9bc98377ed2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1cb373d4-ee8d-425d-9556-f69a39ca4660">
											<gml:posList>35.666720410832845 139.74766081524973 8.479500327811564 35.66671636512583 139.74764884614584 6.329262290702189 35.66671636512583 139.74764884614584 8.479500327811564 35.666720410832845 139.74766081524973 8.479500327811564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4984536c-45f9-4ee6-aa1f-98d123735d5b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_80975ced-06e1-4e32-ae86-cd47d29a0cdb">
											<gml:posList>35.66670775896889 139.74762338518366 6.329262290702189 35.666706854087415 139.74762070814202 8.479500327811564 35.66670775896889 139.74762338518366 8.479500327811564 35.66670775896889 139.74762338518366 6.329262290702189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_d5aee16b-ea1b-4c21-bfc6-a50b04747b4e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1179f4c1-417d-409b-b64b-ba1a6149589b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d850c46e-6b06-453c-8363-ae1d086c0800">
											<gml:posList>35.666696773400346 139.74764675858478 28.571503196463908 35.666671789768614 139.74772846139706 28.571503196463908 35.666696773400346 139.74764675858478 34.72238210271391 35.666696773400346 139.74764675858478 28.571503196463908</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3cbb1e6b-7d24-499d-90c2-19452c5ca532">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5eea1910-fc8b-4cf5-9386-afb4f3bfd423">
											<gml:posList>35.666696773400346 139.74764675858478 34.72238210271391 35.666671789768614 139.74772846139706 28.571503196463908 35.666671789768614 139.74772846139706 34.72238210271391 35.666696773400346 139.74764675858478 34.72238210271391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_f922d54e-dfc0-43c6-8069-ba8c69c3696d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9cf8862a-920c-466a-b99a-7c1fb5d38315">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6a8eb048-9516-4e47-84e4-2dab4b987a22">
											<gml:posList>35.66669044960785 139.74774292031765 27.143883262381877 35.666690819797786 139.74774312015376 24.746124778495158 35.666689441268524 139.74774237598297 24.746124778495158 35.66669044960785 139.74774292031765 27.143883262381877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ec393057-58f6-4646-9b49-757ca54c76c5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b97ef27d-b633-4c2c-a0db-3094a35929b9">
											<gml:posList>35.666690819797786 139.74774312015376 24.746124778495158 35.66669044960785 139.74774292031765 27.143883262381877 35.666690819797786 139.74774312015376 27.61948445867094 35.666690819797786 139.74774312015376 24.746124778495158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9aa39d7a-5399-4e16-8b00-5ff34f6b169b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d70509d5-45c9-4d10-9365-990717c3d3be">
											<gml:posList>35.666690819797786 139.74774312015376 27.61948445867094 35.66669044960785 139.74774292031765 27.143883262381877 35.66669044960785 139.74774292031765 27.61948445867094 35.666690819797786 139.74774312015376 27.61948445867094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_26332251-6ca8-465b-9dde-31a4490f6bbe">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a3b2857d-cf8e-41c6-8b77-3de72696d92a">
											<gml:posList>35.66669044960785 139.74774292031765 27.143883262381877 35.666689441268524 139.74774237598297 24.746124778495158 35.666689441268524 139.74774237598297 27.143883262381877 35.66669044960785 139.74774292031765 27.143883262381877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0179_p1044_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0179_p1044_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0179_p1044_1">
											<gml:posList>35.66667846969814 139.747643709672 30.02793432 35.666678475524805 139.74764371107 28.32293445 35.666663290741305 139.74763678349453 28.3222493 35.66666328491869 139.74763678209828 30.02724917 35.66667846969814 139.747643709672 30.02793432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0179_p1044_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0179_p1044_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0179_p1044_3">
											<gml:posList>35.66665551981085 139.7476623417708 30.02709478 35.666655525631384 139.7476623431738 28.32209491 35.666670710413534 139.74766927075356 28.32278005 35.66667070458894 139.74766926934868 30.02777993 35.66665551981085 139.7476623417708 30.02709478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_23a01be6-447d-42d3-9d91-6b169c89c4c4">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bb7cf87c-26d1-4f85-a522-0f40910337c0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c8ca7fb7-6563-48a2-8e4e-45bed252d713">
											<gml:posList>35.66669074176127 139.74774333715422 8.420250449881877 35.66669074176127 139.74774333715422 6.254005943045939 35.66668413533931 139.74773977038203 8.420250449881877 35.66669074176127 139.74774333715422 8.420250449881877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a72363d1-360a-4a62-8653-b8ba97301b3f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_679bc95b-5c11-4391-a9aa-1db663750fc3">
											<gml:posList>35.66668413533931 139.74773977038203 8.420250449881877 35.66669074176127 139.74774333715422 6.254005943045939 35.66668413533931 139.74773977038203 6.254005943045939 35.66668413533931 139.74773977038203 8.420250449881877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_979dd461-7f2f-4e00-b718-67b3dd18aaee">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fca376ea-dc14-4fa7-84a1-2c654421fb67">
									<gml:exterior>
										<gml:LinearRing gml:id="line_19454cfb-4c0f-4a73-bbe5-6ccd6a449e6e">
											<gml:posList>35.6667052548605 139.7476230814457 9.74887898992094 35.666652572593925 139.74759643403618 9.74887898992094 35.666651760958615 139.74759915959788 9.74887898992094 35.6667052548605 139.7476230814457 9.74887898992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a4269909-bb72-4a4d-8bb2-b2823f6cc2ec">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4c78b820-91ba-469b-ab2c-fe230765ecb1">
											<gml:posList>35.666652572593925 139.74759643403618 9.74887898992094 35.6667052548605 139.7476230814457 9.74887898992094 35.666706854087415 139.74762070814202 9.74887898992094 35.666652572593925 139.74759643403618 9.74887898992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0c534fd1-281c-4721-99c1-65043586d330">
									<gml:exterior>
										<gml:LinearRing gml:id="line_10792d38-5169-415e-9b84-8fa2f42132d0">
											<gml:posList>35.66671636512583 139.74764884614584 9.74887898992094 35.6667052548605 139.7476230814457 9.74887898992094 35.66671431537042 139.74764988674087 9.74887898992094 35.66671636512583 139.74764884614584 9.74887898992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5f1f3730-3519-45e2-ae4e-6c805cefdeae">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8e10e999-d818-471c-a0fb-41b9fcef159e">
											<gml:posList>35.6667052548605 139.7476230814457 9.74887898992094 35.66671636512583 139.74764884614584 9.74887898992094 35.666706854087415 139.74762070814202 9.74887898992094 35.6667052548605 139.7476230814457 9.74887898992094</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_ec0ed8a5-895a-436e-8cea-1b54acac7ff6">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8972b34b-e942-442f-b3ce-08da617d1978">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ca9c3258-4eee-4092-9acb-6f25a668c4fe">
											<gml:posList>35.666652572593925 139.74759643403618 6.329262290702189 35.66666928904278 139.74760961085764 6.329262290702189 35.6666852861736 139.74761676466275 6.329262290702189 35.666652572593925 139.74759643403618 6.329262290702189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_206ab300-b54a-4471-a873-6881d4ba98e4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a14e6883-cfa3-4008-b891-b883e433f086">
											<gml:posList>35.66666928904278 139.74760961085764 6.329262290702189 35.666652572593925 139.74759643403618 6.329262290702189 35.66665107428787 139.74760146551807 6.329262290702189 35.66666928904278 139.74760961085764 6.329262290702189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ac6734ef-6f86-431b-b52f-92f56f475ab2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0aae1b53-0b5b-4d73-9ec9-427e1fcd20f2">
											<gml:posList>35.666705109610035 139.74761992795868 6.329262290702189 35.6666852861736 139.74761676466275 6.329262290702189 35.66670361133738 139.7476249594434 6.329262290702189 35.666705109610035 139.74761992795868 6.329262290702189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6a845445-949f-4f53-9365-10b7c5f7b40f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f54ff696-27a8-4d7b-983c-d261433b90c3">
											<gml:posList>35.6666852861736 139.74761676466275 6.329262290702189 35.666705109610035 139.74761992795868 6.329262290702189 35.666652572593925 139.74759643403618 6.329262290702189 35.6666852861736 139.74761676466275 6.329262290702189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8caceb2a-3b50-417f-9159-73e1fafcebef">
									<gml:exterior>
										<gml:LinearRing gml:id="line_eef8662c-91ec-4e8b-a91a-10cc4d75e672">
											<gml:posList>35.6666852861736 139.74761676466275 6.329262290702189 35.66666706094667 139.7476170930869 6.329262290702189 35.666683058042565 139.74762424672483 6.329262290702189 35.6666852861736 139.74761676466275 6.329262290702189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f16240e4-d84e-4f69-91a4-4d362284cde7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b3871478-64cf-4dbf-aa2b-14262f6e2f79">
											<gml:posList>35.66666706094667 139.7476170930869 6.329262290702189 35.6666852861736 139.74761676466275 6.329262290702189 35.66666928904278 139.74760961085764 6.329262290702189 35.66666706094667 139.7476170930869 6.329262290702189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_80527c5b-c3ce-43df-b8cc-62bc5c4d839f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f313f987-2a38-4d41-9a82-3fe3a478e7d9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_82a0d0ba-b1a5-42f1-98bf-1adc249a0301">
											<gml:posList>35.66671636512583 139.74764884614584 6.329262290702189 35.66670775896889 139.74762338518366 6.329262290702189 35.66671355981645 139.74765027014502 6.329262290702189 35.66671636512583 139.74764884614584 6.329262290702189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a5f4aa8c-5348-442f-b756-ebb3f0766c5e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dddd60c3-4724-42ac-b01f-e19f77c782ae">
											<gml:posList>35.66671355981645 139.74765027014502 6.329262290702189 35.66670775896889 139.74762338518366 6.329262290702189 35.66670495364263 139.7476248091836 6.329262290702189 35.66671355981645 139.74765027014502 6.329262290702189</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_718b792b-fff3-4fc5-b440-e245bff52ce5">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_973d736a-5600-47d2-811f-6fd766526fd8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7f2d468d-55a7-4c8a-90c6-c1dd0c219712">
											<gml:posList>35.666686201521316 139.747734023496 6.254005943045939 35.66669074176127 139.74774333715422 6.254005943045939 35.66669662610225 139.74772697056582 6.254005943045939 35.666686201521316 139.747734023496 6.254005943045939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7d4bee1e-2844-4987-814e-5f5ee8266848">
									<gml:exterior>
										<gml:LinearRing gml:id="line_18fd9f5e-285d-45a8-97b9-77f7dc165abc">
											<gml:posList>35.66669074176127 139.74774333715422 6.254005943045939 35.666686201521316 139.747734023496 6.254005943045939 35.66668413533931 139.74773977038203 6.254005943045939 35.66669074176127 139.74774333715422 6.254005943045939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5b5eb29d-9f11-4e5b-9312-473ebf8a999e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c925c781-cc21-4843-8a25-ffef95b0666d">
											<gml:posList>35.666686201521316 139.747734023496 6.254005943045939 35.66669662610225 139.74772697056582 6.254005943045939 35.66669001964531 139.74772340362622 6.254005943045939 35.666686201521316 139.747734023496 6.254005943045939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_b181764f-0c26-4174-b863-5ee9e343d03f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dcd74238-60c9-4ad5-851b-21c724b43ff3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_27cd13d9-0d9f-4f09-b6b0-3d60c615ab1f">
											<gml:posList>35.666690819797786 139.74774312015376 24.746124778495158 35.666696092407044 139.74772845500408 24.746124778495158 35.666689441268524 139.74774237598297 24.746124778495158 35.666690819797786 139.74774312015376 24.746124778495158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d6478b7d-ad82-4b3a-a3a0-04d59d01ddc5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ebdfac2d-0615-4b07-9ddd-56aba6ec1910">
											<gml:posList>35.666689441268524 139.74774237598297 24.746124778495158 35.666696092407044 139.74772845500408 24.746124778495158 35.66669471387756 139.74772771066495 24.746124778495158 35.666689441268524 139.74774237598297 24.746124778495158</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:lod3Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#Poly_26a30841-a2b3-410f-9fce-cde9e69c27d8"/>
							<gml:surfaceMember xlink:href="#Poly_62a8d3ef-b038-42bb-8116-19a8b619dcb5"/>
							<gml:surfaceMember xlink:href="#Poly_6d0ebde4-bf0f-4312-8fc7-f73ca403709f"/>
							<gml:surfaceMember xlink:href="#Poly_b1aa3a85-53e4-41ba-8b20-c9bd4795ffc6"/>
							<gml:surfaceMember xlink:href="#Poly_0e164c6b-8443-45e2-b28c-bc3753663d78"/>
							<gml:surfaceMember xlink:href="#Poly_d68f6d26-c256-4699-9863-e5e99186b704"/>
							<gml:surfaceMember xlink:href="#Poly_c8023299-dee7-4a13-bdf1-f301068824e5"/>
							<gml:surfaceMember xlink:href="#Poly_2e334596-e765-4273-8ca0-918372cb64fc"/>
							<gml:surfaceMember xlink:href="#Poly_a4d60c0b-8a40-4f6f-912f-40201c9ac1b5"/>
							<gml:surfaceMember xlink:href="#Poly_81dfe100-4c3a-46d9-98a6-a431aa0453bd"/>
							<gml:surfaceMember xlink:href="#Poly_4da15c5b-ac0e-4c59-a5e0-c8a6d279f09d"/>
							<gml:surfaceMember xlink:href="#Poly_2f3c9155-1b43-40ae-bac4-d7f7b9a77df0"/>
							<gml:surfaceMember xlink:href="#Poly_90ec69b7-c2dd-4f7a-914f-1ca4d0116478"/>
							<gml:surfaceMember xlink:href="#Poly_9d05cc92-c347-4642-8774-f02822e13f98"/>
							<gml:surfaceMember xlink:href="#Poly_5b02906c-3daf-4879-a420-f1377fcfcad8"/>
							<gml:surfaceMember xlink:href="#Poly_cbed897a-ea65-40bf-8002-322e3d8ef9c8"/>
							<gml:surfaceMember xlink:href="#Poly_d74e6dd6-1eeb-4190-b44a-b6a5034ea505"/>
							<gml:surfaceMember xlink:href="#Poly_91ef233a-9967-4ed1-b18f-90fdb54da9f1"/>
							<gml:surfaceMember xlink:href="#Poly_8e2476cf-e6da-4ee7-891d-4444539fa357"/>
							<gml:surfaceMember xlink:href="#Poly_669bacf6-c27c-4ae0-a6e2-00ed0bdd902a"/>
							<gml:surfaceMember xlink:href="#Poly_b39924fb-3f9e-4a7f-97ba-b46849f94cc5"/>
							<gml:surfaceMember xlink:href="#Poly_f951ad79-d28e-4e31-a35f-b4a6bb4f8325"/>
							<gml:surfaceMember xlink:href="#Poly_6c2130ff-7296-4725-a4de-187e41d70dde"/>
							<gml:surfaceMember xlink:href="#Poly_f586c831-99d9-4b0b-adbb-7c18903fbe92"/>
							<gml:surfaceMember xlink:href="#Poly_43d0b860-3bd0-4e7c-834e-7127cdf13197"/>
							<gml:surfaceMember xlink:href="#Poly_ef637dd9-c73a-4078-a19c-9f02e05c5dc0"/>
							<gml:surfaceMember xlink:href="#Poly_dd34e0e8-01ce-473f-8ebb-f3851f6f5c91"/>
							<gml:surfaceMember xlink:href="#Poly_e48975e4-e5d9-4f02-864f-e33d2656b2c4"/>
							<gml:surfaceMember xlink:href="#Poly_eaf1241b-1696-4ecb-8f31-22ab084ddc96"/>
							<gml:surfaceMember xlink:href="#Poly_c186fa9d-d090-4a78-b044-17b6e2819357"/>
							<gml:surfaceMember xlink:href="#Poly_8880c3af-6f77-46f9-9aa7-38efb0682ee6"/>
							<gml:surfaceMember xlink:href="#Poly_fe059a13-f375-48ef-a156-632b017daf12"/>
							<gml:surfaceMember xlink:href="#Poly_c3cda210-9c43-40b2-a541-cbcaced24ab0"/>
							<gml:surfaceMember xlink:href="#Poly_52c4da3c-c2bd-4643-ae9a-e11141a1d8e8"/>
							<gml:surfaceMember xlink:href="#Poly_497cf871-d957-4015-a592-cf08e2adfed5"/>
							<gml:surfaceMember xlink:href="#Poly_dd4e3c01-f6d6-49f7-8d1d-87e8019a8180"/>
							<gml:surfaceMember xlink:href="#Poly_e23e2539-03d4-473b-a20f-a612d9fb0167"/>
							<gml:surfaceMember xlink:href="#Poly_449ffa68-6531-416a-b638-a22e69444180"/>
							<gml:surfaceMember xlink:href="#Poly_b2dc213e-45cc-425e-b328-683df8b7911e"/>
							<gml:surfaceMember xlink:href="#Poly_832cd7aa-e9eb-49ff-9257-89551ff9de85"/>
							<gml:surfaceMember xlink:href="#Poly_e5e01d71-c44f-43e5-9f3f-30b65afc8f34"/>
							<gml:surfaceMember xlink:href="#Poly_455a02d0-3c5b-4ae5-9ceb-749692e59ecf"/>
							<gml:surfaceMember xlink:href="#Poly_206c1a6a-f292-4e9b-bfb1-2b7e355e129f"/>
							<gml:surfaceMember xlink:href="#Poly_458709b7-aab3-4f83-8b50-1ea55d416840"/>
							<gml:surfaceMember xlink:href="#Poly_15f17e45-c41e-43f7-9238-1b878fc9e0db"/>
							<gml:surfaceMember xlink:href="#Poly_17598c27-f38b-429a-9fa7-fd442dd8a615"/>
							<gml:surfaceMember xlink:href="#Poly_aaf385fc-a237-44e8-addc-a6dc20518715"/>
							<gml:surfaceMember xlink:href="#Poly_314831ed-d3da-4fe5-b692-7876edd2fec2"/>
							<gml:surfaceMember xlink:href="#Poly_6274c256-8184-4d04-9503-b9b34437be36"/>
							<gml:surfaceMember xlink:href="#Poly_6c281f60-6f2e-45a3-bcd2-66623c465a36"/>
							<gml:surfaceMember xlink:href="#Poly_755d9e40-5bba-4d6d-bf79-f7649f5d74cd"/>
							<gml:surfaceMember xlink:href="#Poly_20657826-f40e-4ca4-9212-a64b90250538"/>
							<gml:surfaceMember xlink:href="#Poly_fe1a9964-107a-4dd8-add3-57b515c0f1b4"/>
							<gml:surfaceMember xlink:href="#Poly_0ef76715-0908-4c37-ae11-43b1e50ba7f0"/>
							<gml:surfaceMember xlink:href="#Poly_e8e6d257-515c-4735-aee5-41b4436bfeb4"/>
							<gml:surfaceMember xlink:href="#Poly_573d7436-54e0-47af-babb-e64637ebaec5"/>
							<gml:surfaceMember xlink:href="#Poly_c05ca4de-c4f4-4a4d-828a-63bedfe96f92"/>
							<gml:surfaceMember xlink:href="#Poly_5ea531b6-701b-4d5f-ae84-ea7d1ac2953a"/>
							<gml:surfaceMember xlink:href="#Poly_baad241c-147f-4381-933d-f38456c511ac"/>
							<gml:surfaceMember xlink:href="#Poly_337c1da8-c7ad-4467-bc4c-fe5fcefd760b"/>
							<gml:surfaceMember xlink:href="#Poly_c5454afb-138f-42ad-a751-156021486f6f"/>
							<gml:surfaceMember xlink:href="#Poly_86f5ca14-5981-48b5-bb37-58adbc656fda"/>
							<gml:surfaceMember xlink:href="#Poly_3424d707-6ca8-47f1-b0dd-1432be4c839c"/>
							<gml:surfaceMember xlink:href="#Poly_32ed26bb-1307-49bf-b0bc-4b73a35b8da9"/>
							<gml:surfaceMember xlink:href="#Poly_7325598f-c380-4093-b5d0-f17148bac8bb"/>
							<gml:surfaceMember xlink:href="#Poly_9d41e044-72a9-4d68-87cb-980145733255"/>
							<gml:surfaceMember xlink:href="#Poly_4eaf073e-4e48-407c-b1c7-fcc0aa7a1a85"/>
							<gml:surfaceMember xlink:href="#Poly_96412625-4a8c-4eef-89f9-122f33efbcf7"/>
							<gml:surfaceMember xlink:href="#Poly_e031dbea-4f8e-4f56-9f11-5b61dc09099a"/>
							<gml:surfaceMember xlink:href="#Poly_824bfb30-937f-4cc6-8579-73ec2d7adf62"/>
							<gml:surfaceMember xlink:href="#Poly_6725d1d6-f6a4-4e09-9859-1e02341ece18"/>
							<gml:surfaceMember xlink:href="#Poly_0fb0b499-5218-467a-a226-3b8d33196222"/>
							<gml:surfaceMember xlink:href="#Poly_6a4bb6d8-c261-4ec0-b752-985bde10f719"/>
							<gml:surfaceMember xlink:href="#Poly_9dd47551-271c-40a7-82cb-a35f1f5fb4a2"/>
							<gml:surfaceMember xlink:href="#Poly_86e58bd1-97d3-4749-be21-8887e1b9a7c3"/>
							<gml:surfaceMember xlink:href="#Poly_3ea03806-83e2-4dbf-b4f8-10f99fc090d9"/>
							<gml:surfaceMember xlink:href="#Poly_37fdc2d2-dd90-482e-a08b-a1a5b33c046c"/>
							<gml:surfaceMember xlink:href="#Poly_50ea43b4-d2bc-4590-a63f-47d4a866d3e1"/>
							<gml:surfaceMember xlink:href="#Poly_94aa78d4-b99d-4cc6-b4b6-d419dd6a63a0"/>
							<gml:surfaceMember xlink:href="#Poly_199b80f4-34c0-4205-afd5-789c547465b4"/>
							<gml:surfaceMember xlink:href="#Poly_ccdbb371-668c-4b90-a066-c727b15f104b"/>
							<gml:surfaceMember xlink:href="#Poly_0ebaee7a-22fd-4693-85d4-d5892e39e4e5"/>
							<gml:surfaceMember xlink:href="#Poly_367b4b89-bf90-4c46-8f25-87a3c325948f"/>
							<gml:surfaceMember xlink:href="#Poly_7b853669-ea20-4085-9c84-2af9549650a7"/>
							<gml:surfaceMember xlink:href="#Poly_e2641caf-b962-4d82-895b-529b865f63f2"/>
							<gml:surfaceMember xlink:href="#Poly_79722d56-a129-4169-8304-efa85ad60080"/>
							<gml:surfaceMember xlink:href="#Poly_c785d746-741a-4118-a927-f405249da24c"/>
							<gml:surfaceMember xlink:href="#Poly_2eb8f9a8-a1e5-42a3-98cf-361749c5c9f1"/>
							<gml:surfaceMember xlink:href="#Poly_091084d9-7259-4141-9b7c-59a3fcc05ab6"/>
							<gml:surfaceMember xlink:href="#Poly_6d65e826-71b0-4b4c-ae8c-e49a0a5e20df"/>
							<gml:surfaceMember xlink:href="#Poly_edc2dcba-e8a5-4b4d-87c7-7eca01e0579a"/>
							<gml:surfaceMember xlink:href="#Poly_ccd87625-e1a5-4cee-b87d-4160e3bf29fc"/>
							<gml:surfaceMember xlink:href="#Poly_a37d0e46-a1ef-4e6f-a035-b901e2839d0f"/>
							<gml:surfaceMember xlink:href="#Poly_5a5153c4-ce15-4781-b8d3-6c82cc3dd759"/>
							<gml:surfaceMember xlink:href="#Poly_7ed5db8b-dd8a-46c1-b917-9ceaef64d714"/>
							<gml:surfaceMember xlink:href="#Poly_ba32b11b-c0c5-4097-891a-f8aa786f229e"/>
							<gml:surfaceMember xlink:href="#Poly_c4235ba8-4c31-4771-b65c-dc13cb63d79a"/>
							<gml:surfaceMember xlink:href="#Poly_2ee09e93-85d9-45ff-a22d-a8a1dbfe0b63"/>
							<gml:surfaceMember xlink:href="#Poly_2af7e81f-a60c-4e15-919e-103f9095ef3b"/>
							<gml:surfaceMember xlink:href="#Poly_c3241aee-59dc-40e2-a40e-cd895f14e8e8"/>
							<gml:surfaceMember xlink:href="#Poly_7a8e00bc-e458-4893-8b11-aa3d8a2236ce"/>
							<gml:surfaceMember xlink:href="#Poly_f31c265f-ca09-4317-8022-bf3f2da14fb9"/>
							<gml:surfaceMember xlink:href="#Poly_c7f7205d-32f7-467b-b3a3-55067fee59b3"/>
							<gml:surfaceMember xlink:href="#Poly_2c54404c-c1c8-4aeb-8780-7503763681d3"/>
							<gml:surfaceMember xlink:href="#Poly_47348424-2aaf-49e0-b341-6d10e26c2542"/>
							<gml:surfaceMember xlink:href="#Poly_1d9b1bb3-e414-46ff-a412-6a37ea575e9b"/>
							<gml:surfaceMember xlink:href="#Poly_41640472-f893-4e6f-ac41-4305cc5b037b"/>
							<gml:surfaceMember xlink:href="#Poly_635c710c-c465-4a7f-ae49-26a0c740babc"/>
							<gml:surfaceMember xlink:href="#Poly_8df15708-0546-431b-a5bf-de4fcf3137e9"/>
							<gml:surfaceMember xlink:href="#Poly_05c5ecf0-c20d-473f-953f-ecfac3007d70"/>
							<gml:surfaceMember xlink:href="#Poly_9e92c8ef-caef-4694-bf8d-3d17dadd612f"/>
							<gml:surfaceMember xlink:href="#Poly_10518501-482e-423c-808c-779b08ebe107"/>
							<gml:surfaceMember xlink:href="#Poly_ecefa44c-51fb-4e58-97bd-a89390d348de"/>
							<gml:surfaceMember xlink:href="#Poly_609491ad-13d7-4377-b31c-26a7891bd49f"/>
							<gml:surfaceMember xlink:href="#Poly_b2932cc5-64d0-46ec-a34a-8c4692499e32"/>
							<gml:surfaceMember xlink:href="#Poly_92c13349-f08e-4553-8bf9-b6994e32f10b"/>
							<gml:surfaceMember xlink:href="#Poly_d3a3b32e-5857-4e51-86f0-10ddee8e4486"/>
							<gml:surfaceMember xlink:href="#Poly_208d28ff-10ab-49a8-88c2-fcc144177aa7"/>
							<gml:surfaceMember xlink:href="#Poly_18dd3d70-e0b0-4d81-b56a-820d9b1b9873"/>
							<gml:surfaceMember xlink:href="#Poly_6227b9d4-2329-463b-9faf-56f953aa6d26"/>
							<gml:surfaceMember xlink:href="#Poly_36f261e1-b7b8-433b-a4aa-5f48c20ff8a0"/>
							<gml:surfaceMember xlink:href="#Poly_5f10e8b8-ff05-46cc-b949-65e3db9a18b8"/>
							<gml:surfaceMember xlink:href="#Poly_63f4e8a2-58e1-4065-8627-b2f017b446d2"/>
							<gml:surfaceMember xlink:href="#Poly_b2f92e7c-bde3-467c-8ed6-8c4d1ea33c55"/>
							<gml:surfaceMember xlink:href="#Poly_eb81b1b2-bb32-4f5a-8e4d-a2e2943dcd65"/>
							<gml:surfaceMember xlink:href="#Poly_ccd87c8f-56c0-48e2-847e-88718b42b48c"/>
							<gml:surfaceMember xlink:href="#Poly_7e01aaa8-15c7-4e28-a58a-60f3f413e442"/>
							<gml:surfaceMember xlink:href="#Poly_39219e4e-6135-4d0c-b17e-9b47f82fa119"/>
							<gml:surfaceMember xlink:href="#Poly_b04cb261-e919-45d0-b146-91962ee0ccb5"/>
							<gml:surfaceMember xlink:href="#Poly_34ba306c-ee26-4147-bf3a-54b912725100"/>
							<gml:surfaceMember xlink:href="#Poly_68049947-55ad-4eb0-b199-9b802f6adfe3"/>
							<gml:surfaceMember xlink:href="#Poly_c025359a-9c47-4270-a1c4-150b749eee45"/>
							<gml:surfaceMember xlink:href="#Poly_1f63cfe1-9011-435b-bc8f-335e32251fd9"/>
							<gml:surfaceMember xlink:href="#Poly_e3f37177-c82f-4dae-b850-0865b69a4ba9"/>
							<gml:surfaceMember xlink:href="#Poly_18197c87-6d4a-49f2-828a-9025e616b0ae"/>
							<gml:surfaceMember xlink:href="#Poly_d37cf1d9-d899-48e3-bdf6-863bb4af37a0"/>
							<gml:surfaceMember xlink:href="#Poly_f35399c5-e190-466f-8e4d-0ffe0f2aa1e2"/>
							<gml:surfaceMember xlink:href="#Poly_8e24f0cf-74cf-4bbb-929c-b29b9ed3e1a2"/>
							<gml:surfaceMember xlink:href="#Poly_01b059b4-7e1a-4d1a-9270-d28316e1dc2b"/>
							<gml:surfaceMember xlink:href="#Poly_e378b096-4b15-4ae0-aced-a5ae0509102c"/>
							<gml:surfaceMember xlink:href="#Poly_599bda34-4bde-4aba-be36-5a7dabc233f2"/>
							<gml:surfaceMember xlink:href="#Poly_0779fbf4-ad6b-4040-b7b8-57e498c1e458"/>
							<gml:surfaceMember xlink:href="#Poly_c50225ce-9f34-4304-ae1e-9aad69c6495e"/>
							<gml:surfaceMember xlink:href="#Poly_665b6501-fb8f-444e-a081-6e92e096b9fe"/>
							<gml:surfaceMember xlink:href="#Poly_eec9ca83-40d1-4f7a-a15b-09cd8259286f"/>
							<gml:surfaceMember xlink:href="#Poly_fedea1fe-2d54-4e66-93f2-806a09ab4f7f"/>
							<gml:surfaceMember xlink:href="#Poly_56f21506-a2a5-4925-964f-ee6f7c1298cf"/>
							<gml:surfaceMember xlink:href="#Poly_747df37c-0335-4bf9-940a-ddd9837212ff"/>
							<gml:surfaceMember xlink:href="#Poly_bd4d8cb2-901b-4983-aeca-7975c8ef6a11"/>
							<gml:surfaceMember xlink:href="#Poly_05e120df-056f-4c2a-8b22-940334b172d6"/>
							<gml:surfaceMember xlink:href="#Poly_3330f10a-852f-45e1-a1f5-6fd242681451"/>
							<gml:surfaceMember xlink:href="#Poly_793ead2f-93fb-4a2d-97a4-570ef9309af4"/>
							<gml:surfaceMember xlink:href="#Poly_d927300b-7de1-4cd1-a5ec-ad48ee95a647"/>
							<gml:surfaceMember xlink:href="#Poly_3f87f76b-e910-44b3-a103-e86224f01650"/>
							<gml:surfaceMember xlink:href="#Poly_b17ce35d-6849-4702-a2b4-33ecb087b724"/>
							<gml:surfaceMember xlink:href="#Poly_c985bc53-abf0-4193-aaf6-8fab334f6698"/>
							<gml:surfaceMember xlink:href="#Poly_b502abfd-09c7-4864-89a2-929aee1b9cb3"/>
							<gml:surfaceMember xlink:href="#Poly_111d1397-d50e-49af-9bd4-d2d6a28b9486"/>
							<gml:surfaceMember xlink:href="#Poly_0eb06b38-5731-4903-b546-909cef21fe4e"/>
							<gml:surfaceMember xlink:href="#Poly_d2fa5f68-caec-4133-910d-7ee09945d89e"/>
							<gml:surfaceMember xlink:href="#Poly_3b731670-dca0-408a-914d-10090e6c7d74"/>
							<gml:surfaceMember xlink:href="#Poly_efd96b1d-62d1-4a27-a5d2-137bd17814fd"/>
							<gml:surfaceMember xlink:href="#Poly_0e3bc53c-1b47-4521-a4c2-a0ef1f4d65d7"/>
							<gml:surfaceMember xlink:href="#Poly_e6970c4b-93f4-4cbf-86a4-936674feff07"/>
							<gml:surfaceMember xlink:href="#Poly_5efa2b79-7ca6-498a-904b-cfd103c609f7"/>
							<gml:surfaceMember xlink:href="#Poly_78fd8bbd-f0c5-4afa-8dec-621f26ae844d"/>
							<gml:surfaceMember xlink:href="#Poly_d4246462-5f86-45cd-b863-e95d3c5deb8d"/>
							<gml:surfaceMember xlink:href="#Poly_1f0bbff3-6c85-4664-8b06-47e51db74b67"/>
							<gml:surfaceMember xlink:href="#Poly_9e8555d6-7c26-49fd-a818-ab9e79672d2e"/>
							<gml:surfaceMember xlink:href="#Poly_ac038502-816d-4697-a720-25e6d84ea74a"/>
							<gml:surfaceMember xlink:href="#Poly_bb39e49c-4550-4cf0-94e0-f5d0ce310cee"/>
							<gml:surfaceMember xlink:href="#Poly_8e51963b-9c08-4b94-8094-c68d11d68d17"/>
							<gml:surfaceMember xlink:href="#Poly_c62564fd-b803-46c3-8663-839775886ecb"/>
							<gml:surfaceMember xlink:href="#Poly_fc483326-0afd-4500-90c8-0145824af001"/>
							<gml:surfaceMember xlink:href="#Poly_b8daa650-cda4-487c-8486-6d4a76bc7fa4"/>
							<gml:surfaceMember xlink:href="#Poly_b3de2de6-d8d9-4509-a1b9-92f6e9d0fc62"/>
							<gml:surfaceMember xlink:href="#Poly_ea6bb832-5f88-44d5-a646-192cb174cfb2"/>
							<gml:surfaceMember xlink:href="#Poly_2a5970b7-b7a9-4375-9344-4346474daca4"/>
							<gml:surfaceMember xlink:href="#Poly_8a7b0155-1f6e-4aa8-89f6-cdbc295cf556"/>
							<gml:surfaceMember xlink:href="#Poly_3ff14053-e32b-4c3a-8bc3-41255f1a0f45"/>
							<gml:surfaceMember xlink:href="#Poly_5d9740bd-3d15-4dcf-85e0-80e5025937bb"/>
							<gml:surfaceMember xlink:href="#Poly_a7c96d6a-8907-4d0f-8697-e50b35bd12d0"/>
							<gml:surfaceMember xlink:href="#Poly_71c1c80f-7d11-4615-b13f-51282f8b5674"/>
							<gml:surfaceMember xlink:href="#Poly_7ec7accc-5782-4d39-b71f-cc9579ca1faf"/>
							<gml:surfaceMember xlink:href="#Poly_d4c28f3d-d240-4cbb-9ee8-9862c953f1eb"/>
							<gml:surfaceMember xlink:href="#Poly_ac4d7f7a-b8e6-41ac-a896-ff2f7e943d2a"/>
							<gml:surfaceMember xlink:href="#Poly_687cb4cc-5cbb-4c6b-98e8-3be322af8e62"/>
							<gml:surfaceMember xlink:href="#Poly_06db1630-ab68-46f6-b1d6-39b9d86f728d"/>
							<gml:surfaceMember xlink:href="#Poly_93b6e288-def4-4ff6-a577-28870817a404"/>
							<gml:surfaceMember xlink:href="#Poly_807283ce-536b-45b6-a8dd-e7d209d36e87"/>
							<gml:surfaceMember xlink:href="#Poly_c246605d-fa94-47aa-ad34-8140a4a03111"/>
							<gml:surfaceMember xlink:href="#Poly_5d0f8bd1-1479-4825-b6a6-b4d5dab280cc"/>
							<gml:surfaceMember xlink:href="#Poly_ea95d1b9-fd9a-4d6a-9afa-f6a14cf16a41"/>
							<gml:surfaceMember xlink:href="#Poly_56e9c687-4469-407c-b0d1-93fa1b2d8eec"/>
							<gml:surfaceMember xlink:href="#Poly_b11e4576-06ab-497d-91d0-57adbcc9169a"/>
							<gml:surfaceMember xlink:href="#Poly_b920e6d1-7a99-4a66-b623-8d00560e9e43"/>
							<gml:surfaceMember xlink:href="#Poly_89765a09-fcdd-450d-9249-d08574eb6de7"/>
							<gml:surfaceMember xlink:href="#Poly_403f6d7e-6691-4047-9e2e-80a760f602fb"/>
							<gml:surfaceMember xlink:href="#Poly_a64b5f40-71b3-4c5c-b10b-e9715c278a98"/>
							<gml:surfaceMember xlink:href="#Poly_a91ea497-2b92-4632-9520-da6c5d388828"/>
							<gml:surfaceMember xlink:href="#Poly_748fee8c-7c1f-482c-894a-d88893efc6e3"/>
							<gml:surfaceMember xlink:href="#Poly_ce893b5b-adb3-4842-951b-969cb00a2f8a"/>
							<gml:surfaceMember xlink:href="#Poly_c2377bf6-b996-4395-ba1f-ce5222308c76"/>
							<gml:surfaceMember xlink:href="#Poly_9ba16880-787b-43ed-8f4b-a584ab1f63a9"/>
							<gml:surfaceMember xlink:href="#Poly_137c8018-fa98-411c-9f94-0c3ee541a69d"/>
							<gml:surfaceMember xlink:href="#Poly_ce207700-7fcc-4672-885a-03526c50e440"/>
							<gml:surfaceMember xlink:href="#Poly_28e6bdb6-c13b-4366-a57f-0762722cefdd"/>
							<gml:surfaceMember xlink:href="#Poly_d33932dc-588f-443e-936d-e232d4d59ee7"/>
							<gml:surfaceMember xlink:href="#Poly_f021a20b-652c-413e-ae45-4a2472cb3d25"/>
							<gml:surfaceMember xlink:href="#Poly_7c8ad227-975b-4f60-9c0d-ebadef250c8f"/>
							<gml:surfaceMember xlink:href="#Poly_656fb504-03a7-4794-8354-5c6f707f7286"/>
							<gml:surfaceMember xlink:href="#Poly_88355b02-8c58-4307-b27f-bcecc11b9e21"/>
							<gml:surfaceMember xlink:href="#Poly_89bee86e-8cfa-4f64-a739-ad3cd335bdec"/>
							<gml:surfaceMember xlink:href="#Poly_0e5820cc-8820-43dc-95a7-1a2ef82504df"/>
							<gml:surfaceMember xlink:href="#Poly_8c83f8ea-bfe1-4958-ab5e-aef05724d5c0"/>
							<gml:surfaceMember xlink:href="#Poly_e53b3247-b4ac-4fd6-b201-b9e3d54e5f6b"/>
							<gml:surfaceMember xlink:href="#Poly_5b37535b-800c-438c-9c17-1f6d7f8a4822"/>
							<gml:surfaceMember xlink:href="#Poly_15b80749-b9d3-4897-95e0-8b1131db8000"/>
							<gml:surfaceMember xlink:href="#Poly_629ed030-9c3e-4681-acd0-9de8bc879adf"/>
							<gml:surfaceMember xlink:href="#Poly_7c0433c0-e520-43c4-9f40-573009b2d5e6"/>
							<gml:surfaceMember xlink:href="#Poly_7901da73-0410-4f44-80ba-dcc773d2567a"/>
							<gml:surfaceMember xlink:href="#Poly_1e945adb-4a4c-4c13-8c97-b6516262ae2f"/>
							<gml:surfaceMember xlink:href="#Poly_18a7925b-ec3e-4847-9ff6-beec15ae2e5e"/>
							<gml:surfaceMember xlink:href="#Poly_1f76f61f-5b8d-4163-baeb-7d6454c35a8b"/>
							<gml:surfaceMember xlink:href="#Poly_acabd311-6a55-4d0f-a925-45e28efe3bb2"/>
							<gml:surfaceMember xlink:href="#Poly_62be09ed-aa31-43bd-b024-9ace9f758435"/>
							<gml:surfaceMember xlink:href="#Poly_2ed8bbe6-2cc0-4eb3-ab91-13be136f4e5f"/>
							<gml:surfaceMember xlink:href="#Poly_0b7a8017-add5-4829-965b-c3359728aaba"/>
							<gml:surfaceMember xlink:href="#Poly_6810ffd3-eb71-4a96-b283-e8a015fb7621"/>
							<gml:surfaceMember xlink:href="#Poly_f791a883-5faa-424b-87a0-b6010f194b92"/>
							<gml:surfaceMember xlink:href="#Poly_3ad40dc4-7788-4ba6-b445-63aeda9fe262"/>
							<gml:surfaceMember xlink:href="#Poly_088c61e0-eb62-4094-a06d-984e74139d1d"/>
							<gml:surfaceMember xlink:href="#Poly_6f6595b6-8799-4160-908c-15fb2e9f94f3"/>
							<gml:surfaceMember xlink:href="#Poly_7501f2f9-e265-44f5-94a5-bb4622979d1c"/>
							<gml:surfaceMember xlink:href="#Poly_a584e20b-3715-4e80-8d24-6dba34408eaa"/>
							<gml:surfaceMember xlink:href="#Poly_6e32d795-898d-4b15-a98c-6bdc2c627d51"/>
							<gml:surfaceMember xlink:href="#Poly_dac3559e-88d8-4010-95cc-ba55911342d4"/>
							<gml:surfaceMember xlink:href="#Poly_9fb12fce-76c0-4d45-90d5-db9aeca7b657"/>
							<gml:surfaceMember xlink:href="#Poly_edf8ebc1-82fb-4727-9e79-2e9e7592dc5d"/>
							<gml:surfaceMember xlink:href="#Poly_823145b0-cbe3-49f0-86fe-645781f6cba7"/>
							<gml:surfaceMember xlink:href="#Poly_53963051-914c-45bb-ac18-ad55251d5273"/>
							<gml:surfaceMember xlink:href="#Poly_862a9be3-ed0c-43b9-9698-67a3d4c30296"/>
							<gml:surfaceMember xlink:href="#Poly_c11e5b6a-88ab-4993-92fd-62291edd1a96"/>
							<gml:surfaceMember xlink:href="#Poly_54192878-62fd-492d-bed7-128483181a45"/>
							<gml:surfaceMember xlink:href="#Poly_208adc91-37cd-490a-bee6-a2e78293aef6"/>
							<gml:surfaceMember xlink:href="#Poly_3ed8f15a-ab19-4cd8-aa88-46ebf9703610"/>
							<gml:surfaceMember xlink:href="#Poly_0d417385-8f60-4396-bc09-e81069ba8aad"/>
							<gml:surfaceMember xlink:href="#Poly_a16e35f6-222b-4ac4-b200-c9c2a700987b"/>
							<gml:surfaceMember xlink:href="#Poly_d056125a-876d-4917-90d3-2d7e49aebdc6"/>
							<gml:surfaceMember xlink:href="#Poly_a7189360-6606-4d0d-ad95-f90af73fd030"/>
							<gml:surfaceMember xlink:href="#Poly_948b105f-859b-4394-ab58-7f8a9680d498"/>
							<gml:surfaceMember xlink:href="#Poly_d795b2d1-443f-4a34-ad01-9885b8effe58"/>
							<gml:surfaceMember xlink:href="#Poly_95223c01-b6e2-4c97-be6e-9e7b22524032"/>
							<gml:surfaceMember xlink:href="#Poly_5e505939-f6e6-4b35-bdae-14c5d6302e12"/>
							<gml:surfaceMember xlink:href="#Poly_64f63c62-ea26-4407-a8b0-671fb5a0b399"/>
							<gml:surfaceMember xlink:href="#Poly_007de3d4-b446-45d9-9289-49b4fe831b07"/>
							<gml:surfaceMember xlink:href="#Poly_ca56d8b0-12b2-4301-a4b1-70401d022fae"/>
							<gml:surfaceMember xlink:href="#Poly_6401ee3a-994d-4459-b615-b7ccd592594d"/>
							<gml:surfaceMember xlink:href="#Poly_d8562dfa-7a98-4ae5-9b8b-23a8d32b091d"/>
							<gml:surfaceMember xlink:href="#Poly_34f15621-c6a7-4299-ade2-3b0e5ee7499c"/>
							<gml:surfaceMember xlink:href="#Poly_0ab2e37d-c96a-45ff-aa24-b04eafd7a00f"/>
							<gml:surfaceMember xlink:href="#Poly_837c8cae-faf4-48f0-b618-73dcd5cbd180"/>
							<gml:surfaceMember xlink:href="#Poly_a064bef6-e131-4b88-8827-98a5e8b80a09"/>
							<gml:surfaceMember xlink:href="#Poly_13e3f58a-63b1-4c78-941b-4a7707e12dda"/>
							<gml:surfaceMember xlink:href="#Poly_4faa31b4-4c42-4b0e-96c9-e8c6cef781de"/>
							<gml:surfaceMember xlink:href="#Poly_1fc74afd-6c4d-4c70-8521-d032c3fb9c8d"/>
							<gml:surfaceMember xlink:href="#Poly_05cfe847-a8fc-4077-966c-3f6ab43d0d58"/>
							<gml:surfaceMember xlink:href="#Poly_711c09c2-971d-4008-8ec6-869ba5ccf4eb"/>
							<gml:surfaceMember xlink:href="#Poly_f9e7e5af-70af-4129-9c24-00fc2b75373f"/>
							<gml:surfaceMember xlink:href="#Poly_f2068072-d387-44ea-ae3a-3f6049ce3de3"/>
							<gml:surfaceMember xlink:href="#Poly_8e6b75e0-f1ca-4109-a8af-3977a90dbf38"/>
							<gml:surfaceMember xlink:href="#Poly_8f9e8760-2d37-47bf-a7a9-8eb5a5ea9eec"/>
							<gml:surfaceMember xlink:href="#Poly_be42ea7f-a018-4e43-a7f6-589d50220067"/>
							<gml:surfaceMember xlink:href="#Poly_07c6a68b-1c8c-4b9b-a136-dde24876ec1a"/>
							<gml:surfaceMember xlink:href="#Poly_6734c000-c88b-4ce4-a0d9-a455b5c75d92"/>
							<gml:surfaceMember xlink:href="#Poly_513bccf1-fc24-4f62-87ad-357cd645fd39"/>
							<gml:surfaceMember xlink:href="#Poly_d7022b49-2348-4e02-8ff6-ea187624266a"/>
							<gml:surfaceMember xlink:href="#Poly_45b07a29-cbed-4e74-bf70-4747f4720eb8"/>
							<gml:surfaceMember xlink:href="#Poly_de2954e2-3c90-4dcb-9da4-4d4a8c00577f"/>
							<gml:surfaceMember xlink:href="#Poly_bc21221b-388f-4510-90c0-9033d975f5cf"/>
							<gml:surfaceMember xlink:href="#Poly_6d02b27b-4940-4225-8b3f-bec53742674c"/>
							<gml:surfaceMember xlink:href="#Poly_a7e362b0-4202-4e85-92ae-e4dee3b69f2b"/>
							<gml:surfaceMember xlink:href="#Poly_10420ce7-d41c-4ad2-a320-adc69fdc499c"/>
							<gml:surfaceMember xlink:href="#Poly_d47e9032-10d3-483e-a74d-e53d4f0dc3d5"/>
							<gml:surfaceMember xlink:href="#Poly_91416e4d-39c2-4be6-b372-e7f8640531ff"/>
							<gml:surfaceMember xlink:href="#Poly_543aa20a-de6b-45da-a67f-eb124250b718"/>
							<gml:surfaceMember xlink:href="#Poly_0721a177-6a5d-4fc9-a778-dacf461171ff"/>
							<gml:surfaceMember xlink:href="#Poly_b05ca248-989f-461e-9986-8926708497f6"/>
							<gml:surfaceMember xlink:href="#Poly_d87a181c-6bb6-4d6f-b2c1-2bc308273da9"/>
							<gml:surfaceMember xlink:href="#Poly_7794f597-2d1e-49e9-970d-f456f90b5e1d"/>
							<gml:surfaceMember xlink:href="#Poly_a9d8bc2d-98aa-4181-9bb2-b5beb0d7dc81"/>
							<gml:surfaceMember xlink:href="#Poly_f4a688af-414e-48e2-9b3f-00fff6af1922"/>
							<gml:surfaceMember xlink:href="#Poly_24c259e9-0130-47ca-a029-b7ed6e95a612"/>
							<gml:surfaceMember xlink:href="#Poly_09447b51-b8e8-4463-87a0-87e6d920d251"/>
							<gml:surfaceMember xlink:href="#Poly_02160e3b-1ac9-4470-955f-0b7af5e3ef56"/>
							<gml:surfaceMember xlink:href="#Poly_b0e4561d-0f20-4fc8-a990-f69e83c5040b"/>
							<gml:surfaceMember xlink:href="#Poly_80154593-1dcc-4db0-bf68-d1811319f61a"/>
							<gml:surfaceMember xlink:href="#Poly_8097e61a-0b22-401c-98f7-d66804f0fcfe"/>
							<gml:surfaceMember xlink:href="#Poly_2758a480-a753-422a-b96e-db23557333c6"/>
							<gml:surfaceMember xlink:href="#Poly_8083a549-61b2-4bd2-9383-d70cadc27fb4"/>
							<gml:surfaceMember xlink:href="#Poly_d65b7f01-3181-443c-9a4e-f4510748ce8a"/>
							<gml:surfaceMember xlink:href="#Poly_d13618f2-4a68-444f-8c26-c8b8b5a603d5"/>
							<gml:surfaceMember xlink:href="#Poly_b74ba1ec-ad12-4b1e-b627-9e247b5aa1db"/>
							<gml:surfaceMember xlink:href="#Poly_84abdb7a-c604-4e47-9093-633b78051dc9"/>
							<gml:surfaceMember xlink:href="#Poly_8105634b-7d22-44b1-9646-1dfaaf314cc5"/>
							<gml:surfaceMember xlink:href="#Poly_af822873-e4da-4458-a483-7986c1d95686"/>
							<gml:surfaceMember xlink:href="#Poly_82373033-f854-443e-85a1-d34c6eec9420"/>
							<gml:surfaceMember xlink:href="#Poly_1a08e143-8494-41a5-bd50-253dc7a8be49"/>
							<gml:surfaceMember xlink:href="#Poly_b1506d46-3233-4f8f-9389-181f99a95711"/>
							<gml:surfaceMember xlink:href="#Poly_bb93ef7f-e260-4376-87f4-b783aa5628e8"/>
							<gml:surfaceMember xlink:href="#Poly_a17b84ee-8b7c-4b0a-8ffb-c6dd1624560d"/>
							<gml:surfaceMember xlink:href="#Poly_9f45f8b7-8deb-44d6-a595-be71ff21f670"/>
							<gml:surfaceMember xlink:href="#Poly_bcb804f7-3e2b-410f-ac15-e4c44bbe1864"/>
							<gml:surfaceMember xlink:href="#Poly_1b156d6f-0018-4d81-867f-221a12aeedf1"/>
							<gml:surfaceMember xlink:href="#Poly_eab26731-6a33-4ec8-a7c4-accaa094a38e"/>
							<gml:surfaceMember xlink:href="#Poly_2693fb7a-71d6-4bdb-a26e-6b93566d7700"/>
							<gml:surfaceMember xlink:href="#Poly_f813eeb2-b876-446d-ae2d-325f3c3b28aa"/>
							<gml:surfaceMember xlink:href="#Poly_ffefe966-3758-495b-b292-1fa0c20491e2"/>
							<gml:surfaceMember xlink:href="#Poly_d36d2cff-f4d0-425b-893d-26a9d2cbed8b"/>
							<gml:surfaceMember xlink:href="#Poly_ba7ac957-d349-49c3-89d2-959aac2d5445"/>
							<gml:surfaceMember xlink:href="#Poly_6c6a4af8-7c6b-48fd-8993-d8db62f31d23"/>
							<gml:surfaceMember xlink:href="#Poly_9a3e5591-9eef-4ae8-a12e-afc0f629381b"/>
							<gml:surfaceMember xlink:href="#Poly_14c11e8a-4435-470b-95eb-49a4bd523286"/>
							<gml:surfaceMember xlink:href="#Poly_83710c6c-428a-4f27-8676-cf0993279988"/>
							<gml:surfaceMember xlink:href="#Poly_cd3e6d18-3fc3-4e42-8e2d-707348c7347f"/>
							<gml:surfaceMember xlink:href="#Poly_2a279b8c-3231-4933-b1d8-357c4e19a3c9"/>
							<gml:surfaceMember xlink:href="#Poly_4cbce12c-bbad-40a3-9916-a9f4e7e7794b"/>
							<gml:surfaceMember xlink:href="#Poly_9802f4ae-6ef9-4bc3-a363-3a8e7cc5f29f"/>
							<gml:surfaceMember xlink:href="#Poly_9d28b03c-7a93-4cc2-86ba-63f65874536b"/>
							<gml:surfaceMember xlink:href="#Poly_42c53384-911e-47f1-b124-8ae1c2eb3112"/>
							<gml:surfaceMember xlink:href="#Poly_d4ea32b2-257c-40a3-913a-aedf25b6d21a"/>
							<gml:surfaceMember xlink:href="#Poly_2608c10f-79ef-4bb1-8196-4dd6e2021a89"/>
							<gml:surfaceMember xlink:href="#Poly_24b62a27-a9cf-44bf-b6a7-22e739e93f83"/>
							<gml:surfaceMember xlink:href="#Poly_5e9f4b26-837f-4bdf-b932-b1dce040fb68"/>
							<gml:surfaceMember xlink:href="#Poly_cb5e3b82-f217-4b5c-ae99-814c25b3c79d"/>
							<gml:surfaceMember xlink:href="#Poly_2608f4e3-534a-4805-9ebb-d9f5f352b282"/>
							<gml:surfaceMember xlink:href="#Poly_1179f4c1-417d-409b-b64b-ba1a6149589b"/>
							<gml:surfaceMember xlink:href="#Poly_3cbb1e6b-7d24-499d-90c2-19452c5ca532"/>
							<gml:surfaceMember xlink:href="#Poly_f8d3a16d-4429-4b7a-a191-ea705223d445"/>
							<gml:surfaceMember xlink:href="#Poly_1da31e5e-83ae-4d4b-af6c-a5d335954a63"/>
							<gml:surfaceMember xlink:href="#Poly_541c4f8e-ef18-4619-acb5-db6ce1c3ae7c"/>
							<gml:surfaceMember xlink:href="#Poly_15573569-34d9-475f-ac27-9a2201542917"/>
							<gml:surfaceMember xlink:href="#Poly_58175808-231f-495e-b8e8-9d41ba0e5d94"/>
							<gml:surfaceMember xlink:href="#Poly_2e005b0d-28d5-48d9-8da1-170196675195"/>
							<gml:surfaceMember xlink:href="#Poly_27f61e13-a080-4452-a1a5-5dc92c9eebf4"/>
							<gml:surfaceMember xlink:href="#Poly_9cf8862a-920c-466a-b99a-7c1fb5d38315"/>
							<gml:surfaceMember xlink:href="#Poly_ec393057-58f6-4646-9b49-757ca54c76c5"/>
							<gml:surfaceMember xlink:href="#Poly_9aa39d7a-5399-4e16-8b00-5ff34f6b169b"/>
							<gml:surfaceMember xlink:href="#Poly_26332251-6ca8-465b-9dde-31a4490f6bbe"/>
							<gml:surfaceMember xlink:href="#Poly_dcd74238-60c9-4ad5-851b-21c724b43ff3"/>
							<gml:surfaceMember xlink:href="#Poly_d6478b7d-ad82-4b3a-a3a0-04d59d01ddc5"/>
							<gml:surfaceMember xlink:href="#Poly_7ea01c81-736c-4849-b276-9960912241dc"/>
							<gml:surfaceMember xlink:href="#Poly_fb35415b-8791-4c68-a87d-5ad9338915c0"/>
							<gml:surfaceMember xlink:href="#Poly_da352722-72f8-4185-915d-9de8e19cc884"/>
							<gml:surfaceMember xlink:href="#Poly_91b0486e-8a5b-48bd-85ab-c8b8a636e470"/>
							<gml:surfaceMember xlink:href="#Poly_73909607-8d3b-47e6-bebf-81075478721a"/>
							<gml:surfaceMember xlink:href="#Poly_2b176f57-3709-4b43-837d-82ad89ac4a24"/>
							<gml:surfaceMember xlink:href="#Poly_4f67ef12-bcaf-45c7-a3c4-1ea172dd0957"/>
							<gml:surfaceMember xlink:href="#Poly_9414ff17-e010-4e29-bd59-875be0b61a05"/>
							<gml:surfaceMember xlink:href="#Poly_797da4f8-73c0-429d-9415-d02c6c26373f"/>
							<gml:surfaceMember xlink:href="#Poly_dd4afcd9-04b4-4e6a-b1e4-e24a6c907030"/>
							<gml:surfaceMember xlink:href="#Poly_bb7cf87c-26d1-4f85-a522-0f40910337c0"/>
							<gml:surfaceMember xlink:href="#Poly_a72363d1-360a-4a62-8653-b8ba97301b3f"/>
							<gml:surfaceMember xlink:href="#Poly_973d736a-5600-47d2-811f-6fd766526fd8"/>
							<gml:surfaceMember xlink:href="#Poly_7d4bee1e-2844-4987-814e-5f5ee8266848"/>
							<gml:surfaceMember xlink:href="#Poly_5b5eb29d-9f11-4e5b-9312-473ebf8a999e"/>
							<gml:surfaceMember xlink:href="#Poly_5c4446b0-f943-452b-b392-df6e66618115"/>
							<gml:surfaceMember xlink:href="#Poly_6cbad9de-cd25-4730-92c7-261c08ea9a56"/>
							<gml:surfaceMember xlink:href="#Poly_c09555ee-4642-4111-8501-646b135ac36f"/>
							<gml:surfaceMember xlink:href="#Poly_08b3068e-68dd-42d7-ac19-f67ef900e827"/>
							<gml:surfaceMember xlink:href="#Poly_e70df01a-b2f9-4d6c-8d8d-d593b3eda8cc"/>
							<gml:surfaceMember xlink:href="#Poly_dae80797-5585-4293-aaa3-a5abb202c27f"/>
							<gml:surfaceMember xlink:href="#Poly_305c1cc2-0113-4843-9f5a-8aa09f1d63e3"/>
							<gml:surfaceMember xlink:href="#Poly_fca376ea-dc14-4fa7-84a1-2c654421fb67"/>
							<gml:surfaceMember xlink:href="#Poly_a4269909-bb72-4a4d-8bb2-b2823f6cc2ec"/>
							<gml:surfaceMember xlink:href="#Poly_0c534fd1-281c-4721-99c1-65043586d330"/>
							<gml:surfaceMember xlink:href="#Poly_5f1f3730-3519-45e2-ae4e-6c805cefdeae"/>
							<gml:surfaceMember xlink:href="#Poly_582d4bf5-ee9d-4c30-98ee-f22046a6c693"/>
							<gml:surfaceMember xlink:href="#Poly_e784e605-02a1-4d35-8cd4-f4d55c39e1d8"/>
							<gml:surfaceMember xlink:href="#Poly_99e5a163-c61b-42ff-8cbd-ca292882e630"/>
							<gml:surfaceMember xlink:href="#Poly_25a94d8e-7e81-4135-be02-49642ff838ce"/>
							<gml:surfaceMember xlink:href="#Poly_327a1d5f-4c93-4dab-b030-a39a4c21a7f9"/>
							<gml:surfaceMember xlink:href="#Poly_41e1db45-a469-4a9c-b82d-8d180ff80a8b"/>
							<gml:surfaceMember xlink:href="#Poly_42b660c6-8f37-4c21-acf8-5dfcab824510"/>
							<gml:surfaceMember xlink:href="#Poly_043da7ac-b032-4481-ad62-8b569e91b041"/>
							<gml:surfaceMember xlink:href="#Poly_0e3055ea-8699-4cb9-8653-a572336ed20b"/>
							<gml:surfaceMember xlink:href="#Poly_4948ec3f-c02a-4953-921d-b06a24434920"/>
							<gml:surfaceMember xlink:href="#Poly_70a09f16-77dc-45ae-8f4f-474052016d2f"/>
							<gml:surfaceMember xlink:href="#Poly_be78a7bc-a0b0-47c3-8b9a-00b71f6894f3"/>
							<gml:surfaceMember xlink:href="#Poly_3c3d8b28-411e-4ccd-9ed4-dc6f1e6a5a9b"/>
							<gml:surfaceMember xlink:href="#Poly_70396008-cc39-404a-921e-052cb363ba28"/>
							<gml:surfaceMember xlink:href="#Poly_8972b34b-e942-442f-b3ce-08da617d1978"/>
							<gml:surfaceMember xlink:href="#Poly_206ab300-b54a-4471-a873-6881d4ba98e4"/>
							<gml:surfaceMember xlink:href="#Poly_ac6734ef-6f86-431b-b52f-92f56f475ab2"/>
							<gml:surfaceMember xlink:href="#Poly_6a845445-949f-4f53-9365-10b7c5f7b40f"/>
							<gml:surfaceMember xlink:href="#Poly_8caceb2a-3b50-417f-9159-73e1fafcebef"/>
							<gml:surfaceMember xlink:href="#Poly_f16240e4-d84e-4f69-91a4-4d362284cde7"/>
							<gml:surfaceMember xlink:href="#Poly_d68b8c37-b16b-4019-b701-fa9cc2119ade"/>
							<gml:surfaceMember xlink:href="#Poly_c814bbb8-f17b-4e21-82a0-ea57a126dd71"/>
							<gml:surfaceMember xlink:href="#Poly_3f9d382f-4c19-4ff8-9945-f1ad9f4f4ece"/>
							<gml:surfaceMember xlink:href="#Poly_cb25259a-2711-48ee-8af6-d10d9017950f"/>
							<gml:surfaceMember xlink:href="#Poly_66875a1a-1b51-4a76-bbef-c2c9b7ca7770"/>
							<gml:surfaceMember xlink:href="#Poly_d35fdd0b-ea9e-4d7f-92a1-38a47a2a2f6c"/>
							<gml:surfaceMember xlink:href="#Poly_e54215a4-4286-4760-ae09-a81cb2d5053a"/>
							<gml:surfaceMember xlink:href="#Poly_55cdc1f6-b648-4eb5-acb4-ca365a2af717"/>
							<gml:surfaceMember xlink:href="#Poly_0622995a-4a5c-477b-b6e4-c379e98c5b02"/>
							<gml:surfaceMember xlink:href="#Poly_d880bb6b-187f-4382-8b84-a71834776feb"/>
							<gml:surfaceMember xlink:href="#Poly_129ce1ee-d579-4390-89d6-fcb4b67535d7"/>
							<gml:surfaceMember xlink:href="#Poly_a98fcedc-07d9-4969-9a4e-704b50c273f7"/>
							<gml:surfaceMember xlink:href="#Poly_f313f987-2a38-4d41-9a82-3fe3a478e7d9"/>
							<gml:surfaceMember xlink:href="#Poly_a5f4aa8c-5348-442f-b756-ebb3f0766c5e"/>
							<gml:surfaceMember xlink:href="#Poly_7810ea3e-63a8-416c-be80-6db76443f87c"/>
							<gml:surfaceMember xlink:href="#Poly_a20b7363-f8d9-4ce1-9627-73cd3379a216"/>
							<gml:surfaceMember xlink:href="#Poly_8eb78dfc-92a1-4a62-8829-7d0ac82ea220"/>
							<gml:surfaceMember xlink:href="#Poly_2fdc827c-9840-4fa3-b7cc-51afb95f4433"/>
							<gml:surfaceMember xlink:href="#Poly_e3730fed-7ce0-470f-94b0-9afd054f4032"/>
							<gml:surfaceMember xlink:href="#Poly_5897f856-d81e-4c51-9d19-dd6fe579d9b2"/>
							<gml:surfaceMember xlink:href="#Poly_f6d87125-92d9-4f87-b314-dc9e852e3638"/>
							<gml:surfaceMember xlink:href="#Poly_05d9f771-76f2-47fb-b6ec-d291eaf2fd87"/>
							<gml:surfaceMember xlink:href="#Poly_10e907ad-1477-455b-afa3-674d93bbfd32"/>
							<gml:surfaceMember xlink:href="#Poly_a5d55171-924c-4bc1-a972-6cbfc04b304e"/>
							<gml:surfaceMember xlink:href="#Poly_9ba75005-4b48-46ea-a685-163fdc327123"/>
							<gml:surfaceMember xlink:href="#Poly_47f391b8-5895-4706-a87c-6e66911a365c"/>
							<gml:surfaceMember xlink:href="#Poly_78cd16fe-7600-421e-80c1-2ca24c07b0b8"/>
							<gml:surfaceMember xlink:href="#Poly_d30576d2-7f7d-4f8e-acae-b6f782af6e77"/>
							<gml:surfaceMember xlink:href="#Poly_6802b05a-f632-4f49-93c1-9fc58cf12a33"/>
							<gml:surfaceMember xlink:href="#Poly_0214eb8b-6685-44e7-8945-6fed24c99cce"/>
							<gml:surfaceMember xlink:href="#Poly_d5c296e2-1a2e-4751-8121-1b7e8066102d"/>
							<gml:surfaceMember xlink:href="#Poly_2ad19cfe-3406-4d74-9c3b-7dc4e6bc56e5"/>
							<gml:surfaceMember xlink:href="#Poly_738436d8-8634-4608-820c-68739d70bd00"/>
							<gml:surfaceMember xlink:href="#Poly_c44124bf-93d7-4567-b89e-e7ea619613d1"/>
							<gml:surfaceMember xlink:href="#Poly_842a11b0-d81b-46a4-96c1-f9211bfbdb1b"/>
							<gml:surfaceMember xlink:href="#Poly_13cc06ff-a1c4-4b36-ab37-a06a95c1d105"/>
							<gml:surfaceMember xlink:href="#Poly_fc2da5d4-60c0-4f1a-b1a1-453c197d7443"/>
							<gml:surfaceMember xlink:href="#Poly_98db2a5f-a0f0-4d48-9a05-c0e4de805844"/>
							<gml:surfaceMember xlink:href="#Poly_f678aa2c-8a09-4668-83d5-eafa1f2a742f"/>
							<gml:surfaceMember xlink:href="#Poly_e4233af1-f57e-4bd4-8baa-1686119d60a0"/>
							<gml:surfaceMember xlink:href="#Poly_1b584339-0976-4e67-b2ac-d9ab2e559eea"/>
							<gml:surfaceMember xlink:href="#Poly_10a5076c-0292-42b0-85f7-5294ea949c6f"/>
							<gml:surfaceMember xlink:href="#Poly_b0e9b25c-0f1b-4298-80e2-5e69ed62474e"/>
							<gml:surfaceMember xlink:href="#Poly_d6a715c7-3c82-4cb9-b35a-d47f5dd89dff"/>
							<gml:surfaceMember xlink:href="#Poly_36a39ed0-0db3-45ec-ae5c-926ba89a611b"/>
							<gml:surfaceMember xlink:href="#Poly_248e2bb2-c6d6-4ad9-97f6-f0172539f54e"/>
							<gml:surfaceMember xlink:href="#Poly_83a45cbd-99d2-4076-87d3-8ce3cf37f832"/>
							<gml:surfaceMember xlink:href="#Poly_5b5132b1-82eb-4d7b-9139-3eba3fa96737"/>
							<gml:surfaceMember xlink:href="#Poly_75e79789-0c8c-48e1-b350-8306401f50ce"/>
							<gml:surfaceMember xlink:href="#Poly_7b345a37-6740-4685-a9f7-28bc2e364bfd"/>
							<gml:surfaceMember xlink:href="#Poly_c82f9690-63ec-414d-af37-fe9b8fc8a084"/>
							<gml:surfaceMember xlink:href="#Poly_00e7fa0f-f489-4dac-95b3-2429beb7a345"/>
							<gml:surfaceMember xlink:href="#Poly_1589e1eb-8ddc-4209-b563-54a3c3b8a387"/>
							<gml:surfaceMember xlink:href="#Poly_7268c920-aecb-4983-8803-d07e7542d9f0"/>
							<gml:surfaceMember xlink:href="#Poly_14e7ecb2-9306-4d73-986f-7479a207417d"/>
							<gml:surfaceMember xlink:href="#Poly_7d716956-d959-4738-af09-d9bc98377ed2"/>
							<gml:surfaceMember xlink:href="#Poly_4984536c-45f9-4ee6-aa1f-98d123735d5b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod3Solid>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">3</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">2</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">2</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
					<uro:lodType>3.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">96.11995</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">9</uro:districtsAndZonesType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.07</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2276700000</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>