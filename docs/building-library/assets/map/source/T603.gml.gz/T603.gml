<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ae5b5430-bfae-44e2-9862-015c35b7b045">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.90</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>赤坂一丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">10.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66966840737031 139.74337336881769 0 35.669691845364625 139.74337643544692 0 35.669706502322605 139.7432085172656 0 35.6695357655122 139.74318617504687 0 35.66951914240142 139.74337662920894 0 35.66961136188137 139.74338867651377 0 35.669609305967164 139.74341176528097 0 35.66966447540549 139.74341899387474 0 35.66966840737031 139.74337336881769 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66966840737031 139.74337336881769 9.61 35.66966447540549 139.74341899387474 9.61 35.669609305967164 139.74341176528097 9.61 35.66961136188137 139.74338867651377 9.61 35.66951914240142 139.74337662920894 9.61 35.6695357655122 139.74318617504687 9.61 35.669706502322605 139.7432085172656 9.61 35.669691845364625 139.74337643544692 9.61 35.66966840737031 139.74337336881769 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66966840737031 139.74337336881769 9.61 35.669691845364625 139.74337643544692 9.61 35.669691845364625 139.74337643544692 16.97 35.66966840737031 139.74337336881769 16.97 35.66966840737031 139.74337336881769 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669691845364625 139.74337643544692 9.61 35.669706502322605 139.7432085172656 9.61 35.669706502322605 139.7432085172656 16.97 35.669691845364625 139.74337643544692 16.97 35.669691845364625 139.74337643544692 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669706502322605 139.7432085172656 9.61 35.6695357655122 139.74318617504687 9.61 35.6695357655122 139.74318617504687 16.97 35.669706502322605 139.7432085172656 16.97 35.669706502322605 139.7432085172656 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6695357655122 139.74318617504687 9.61 35.66951914240142 139.74337662920894 9.61 35.66951914240142 139.74337662920894 16.97 35.6695357655122 139.74318617504687 16.97 35.6695357655122 139.74318617504687 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66951914240142 139.74337662920894 9.61 35.66961136188137 139.74338867651377 9.61 35.66961136188137 139.74338867651377 16.97 35.66951914240142 139.74337662920894 16.97 35.66951914240142 139.74337662920894 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66961136188137 139.74338867651377 9.61 35.669609305967164 139.74341176528097 9.61 35.669609305967164 139.74341176528097 16.97 35.66961136188137 139.74338867651377 16.97 35.66961136188137 139.74338867651377 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669609305967164 139.74341176528097 9.61 35.66966447540549 139.74341899387474 9.61 35.66966447540549 139.74341899387474 16.97 35.669609305967164 139.74341176528097 16.97 35.669609305967164 139.74341176528097 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66966447540549 139.74341899387474 9.61 35.66966840737031 139.74337336881769 9.61 35.66966840737031 139.74337336881769 16.97 35.66966447540549 139.74341899387474 16.97 35.66966447540549 139.74341899387474 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66966840737031 139.74337336881769 16.97 35.669691845364625 139.74337643544692 16.97 35.669706502322605 139.7432085172656 16.97 35.6695357655122 139.74318617504687 16.97 35.66951914240142 139.74337662920894 16.97 35.66961136188137 139.74338867651377 16.97 35.669609305967164 139.74341176528097 16.97 35.66966447540549 139.74341899387474 16.97 35.66966840737031 139.74337336881769 16.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-827ef3f5-a80e-42d9-a9a1-62e4fdc171fd"/>
							<gml:surfaceMember xlink:href="#poly-cedb0de4-18f6-41ad-871e-cf8e5b9a27a6"/>
							<gml:surfaceMember xlink:href="#poly-18dd9bee-caaf-4852-85fc-c77afc668487"/>
							<gml:surfaceMember xlink:href="#poly-8656837f-2152-4a8b-af72-3327d21fdb75"/>
							<gml:surfaceMember xlink:href="#poly-2be4d2f8-3972-4a6e-911c-bac5df63e18e"/>
							<gml:surfaceMember xlink:href="#poly-7280ceb7-dfa1-40e5-baa7-de217b76edae"/>
							<gml:surfaceMember xlink:href="#poly-34ca2f3f-fc42-4183-bbca-332fe4cb57e2"/>
							<gml:surfaceMember xlink:href="#poly-c108cec0-9561-4d86-b7b7-3922cddd04cf"/>
							<gml:surfaceMember xlink:href="#poly-ba6f50e5-cea4-4bb7-91e0-820bebba78ca"/>
							<gml:surfaceMember xlink:href="#poly-27f1ba01-2466-4667-bf04-7e02af25dc34"/>
							<gml:surfaceMember xlink:href="#poly-fc388fa0-4779-4d21-b083-edb58d5d206d"/>
							<gml:surfaceMember xlink:href="#poly-8c97bd90-0c27-467e-82a8-1d0361fb7715"/>
							<gml:surfaceMember xlink:href="#poly-4cac0465-d2b9-4c1f-8b83-4fb5701c74e8"/>
							<gml:surfaceMember xlink:href="#poly-9cba157f-07d3-4ba1-9863-86eeb8f696d3"/>
							<gml:surfaceMember xlink:href="#poly-6504d98c-6a33-4e9f-b7ef-471fd85592a7"/>
							<gml:surfaceMember xlink:href="#poly-11f20cc2-155f-4462-b1f9-f8f55217319a"/>
							<gml:surfaceMember xlink:href="#poly-44edbe7e-c370-4a9b-9ad8-08b48c5c8d18"/>
							<gml:surfaceMember xlink:href="#poly-ddb571a8-0700-4cc4-a033-b581a1350df6"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-827ef3f5-a80e-42d9-a9a1-62e4fdc171fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-827ef3f5-a80e-42d9-a9a1-62e4fdc171fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-827ef3f5-a80e-42d9-a9a1-62e4fdc171fd">
											<gml:posList>35.669668407370295 139.74337336881769 9.61 35.669664475405476 139.74341899387474 9.61 35.66960930596713 139.74341176528097 9.61 35.669611361881344 139.74338867651377 9.61 35.6695191424014 139.7433766292089 9.61 35.66953576551219 139.74318617504687 9.61 35.6697065023226 139.74320851726557 9.61 35.66969184536459 139.7433764354469 9.61 35.669668407370295 139.74337336881769 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cedb0de4-18f6-41ad-871e-cf8e5b9a27a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cedb0de4-18f6-41ad-871e-cf8e5b9a27a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cedb0de4-18f6-41ad-871e-cf8e5b9a27a6">
											<gml:posList>35.66957826041087 139.74319173871322 13.6 35.66953576551219 139.74318617504687 13.6 35.6695191424014 139.7433766292089 13.6 35.66956166432447 139.74338218189862 13.6 35.66957826041087 139.74319173871322 13.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18dd9bee-caaf-4852-85fc-c77afc668487">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18dd9bee-caaf-4852-85fc-c77afc668487">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18dd9bee-caaf-4852-85fc-c77afc668487">
											<gml:posList>35.669612425355304 139.74337641408988 16.5 35.669614543795134 139.74337669891312 16.5 35.669615464278 139.74336608252605 16.5 35.66966204277302 139.74337216088097 16.5 35.66966112228963 139.74338277727412 16.5 35.6696675226694 139.74338362064822 16.5 35.669668407370295 139.74337336881769 16.5 35.66969184536459 139.7433764354469 16.5 35.6697065023226 139.74320851726557 16.5 35.66957826041087 139.74319173871322 16.5 35.66956166432447 139.74338218189862 16.5 35.669611361881344 139.74338867651377 16.5 35.669612425355304 139.74337641408988 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8656837f-2152-4a8b-af72-3327d21fdb75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8656837f-2152-4a8b-af72-3327d21fdb75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8656837f-2152-4a8b-af72-3327d21fdb75">
											<gml:posList>35.66966204277302 139.74337216088097 27.11 35.669615464278 139.74336608252605 27.11 35.669614543795134 139.74337669891312 27.11 35.66966112228963 139.74338277727412 27.11 35.66966204277302 139.74337216088097 27.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2be4d2f8-3972-4a6e-911c-bac5df63e18e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2be4d2f8-3972-4a6e-911c-bac5df63e18e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2be4d2f8-3972-4a6e-911c-bac5df63e18e">
											<gml:posList>35.669664475405476 139.74341899387474 29.39 35.6696675226694 139.74338362064822 29.39 35.669612425355304 139.74337641408988 29.39 35.66960930596713 139.74341176528097 29.39 35.669664475405476 139.74341899387474 29.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7280ceb7-dfa1-40e5-baa7-de217b76edae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7280ceb7-dfa1-40e5-baa7-de217b76edae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7280ceb7-dfa1-40e5-baa7-de217b76edae">
											<gml:posList>35.66953576551219 139.74318617504687 9.61 35.66953576551219 139.74318617504687 13.6 35.66957826041087 139.74319173871322 13.6 35.66957826041087 139.74319173871322 16.5 35.6697065023226 139.74320851726557 16.5 35.6697065023226 139.74320851726557 9.61 35.66953576551219 139.74318617504687 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34ca2f3f-fc42-4183-bbca-332fe4cb57e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34ca2f3f-fc42-4183-bbca-332fe4cb57e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34ca2f3f-fc42-4183-bbca-332fe4cb57e2">
											<gml:posList>35.66953576551219 139.74318617504687 9.61 35.6695191424014 139.7433766292089 9.61 35.6695191424014 139.7433766292089 13.6 35.66953576551219 139.74318617504687 13.6 35.66953576551219 139.74318617504687 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c108cec0-9561-4d86-b7b7-3922cddd04cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c108cec0-9561-4d86-b7b7-3922cddd04cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c108cec0-9561-4d86-b7b7-3922cddd04cf">
											<gml:posList>35.66956166432447 139.74338218189862 13.6 35.66956166432447 139.74338218189862 16.5 35.66957826041087 139.74319173871322 16.5 35.66957826041087 139.74319173871322 13.6 35.66956166432447 139.74338218189862 13.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba6f50e5-cea4-4bb7-91e0-820bebba78ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba6f50e5-cea4-4bb7-91e0-820bebba78ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba6f50e5-cea4-4bb7-91e0-820bebba78ca">
											<gml:posList>35.66969184536459 139.7433764354469 9.61 35.6697065023226 139.74320851726557 9.61 35.6697065023226 139.74320851726557 16.5 35.66969184536459 139.7433764354469 16.5 35.66969184536459 139.7433764354469 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27f1ba01-2466-4667-bf04-7e02af25dc34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27f1ba01-2466-4667-bf04-7e02af25dc34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27f1ba01-2466-4667-bf04-7e02af25dc34">
											<gml:posList>35.669615464278 139.74336608252605 27.11 35.66966204277302 139.74337216088097 27.11 35.66966204277302 139.74337216088097 16.5 35.669615464278 139.74336608252605 16.5 35.669615464278 139.74336608252605 27.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc388fa0-4779-4d21-b083-edb58d5d206d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc388fa0-4779-4d21-b083-edb58d5d206d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc388fa0-4779-4d21-b083-edb58d5d206d">
											<gml:posList>35.669615464278 139.74336608252605 16.5 35.669614543795134 139.74337669891312 16.5 35.669614543795134 139.74337669891312 27.11 35.669615464278 139.74336608252605 27.11 35.669615464278 139.74336608252605 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c97bd90-0c27-467e-82a8-1d0361fb7715">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c97bd90-0c27-467e-82a8-1d0361fb7715">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c97bd90-0c27-467e-82a8-1d0361fb7715">
											<gml:posList>35.669668407370295 139.74337336881769 9.61 35.66969184536459 139.7433764354469 9.61 35.66969184536459 139.7433764354469 16.5 35.669668407370295 139.74337336881769 16.5 35.669668407370295 139.74337336881769 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cac0465-d2b9-4c1f-8b83-4fb5701c74e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cac0465-d2b9-4c1f-8b83-4fb5701c74e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cac0465-d2b9-4c1f-8b83-4fb5701c74e8">
											<gml:posList>35.66966204277302 139.74337216088097 27.11 35.66966112228963 139.74338277727412 27.11 35.66966112228963 139.74338277727412 16.5 35.66966204277302 139.74337216088097 16.5 35.66966204277302 139.74337216088097 27.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cba157f-07d3-4ba1-9863-86eeb8f696d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cba157f-07d3-4ba1-9863-86eeb8f696d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cba157f-07d3-4ba1-9863-86eeb8f696d3">
											<gml:posList>35.6696675226694 139.74338362064822 29.39 35.6696675226694 139.74338362064822 16.5 35.66966112228963 139.74338277727412 16.5 35.66966112228963 139.74338277727412 27.11 35.669614543795134 139.74337669891312 27.11 35.669614543795134 139.74337669891312 16.5 35.669612425355304 139.74337641408988 16.5 35.669612425355304 139.74337641408988 29.39 35.6696675226694 139.74338362064822 29.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6504d98c-6a33-4e9f-b7ef-471fd85592a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6504d98c-6a33-4e9f-b7ef-471fd85592a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6504d98c-6a33-4e9f-b7ef-471fd85592a7">
											<gml:posList>35.669611361881344 139.74338867651377 9.61 35.669611361881344 139.74338867651377 16.5 35.66956166432447 139.74338218189862 16.5 35.66956166432447 139.74338218189862 13.6 35.6695191424014 139.7433766292089 13.6 35.6695191424014 139.7433766292089 9.61 35.669611361881344 139.74338867651377 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11f20cc2-155f-4462-b1f9-f8f55217319a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11f20cc2-155f-4462-b1f9-f8f55217319a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11f20cc2-155f-4462-b1f9-f8f55217319a">
											<gml:posList>35.669611361881344 139.74338867651377 16.5 35.669611361881344 139.74338867651377 9.61 35.66960930596713 139.74341176528097 9.61 35.66960930596713 139.74341176528097 29.39 35.669612425355304 139.74337641408988 29.39 35.669612425355304 139.74337641408988 16.5 35.669611361881344 139.74338867651377 16.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44edbe7e-c370-4a9b-9ad8-08b48c5c8d18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44edbe7e-c370-4a9b-9ad8-08b48c5c8d18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44edbe7e-c370-4a9b-9ad8-08b48c5c8d18">
											<gml:posList>35.669664475405476 139.74341899387474 9.61 35.669668407370295 139.74337336881769 9.61 35.669668407370295 139.74337336881769 16.5 35.6696675226694 139.74338362064822 16.5 35.6696675226694 139.74338362064822 29.39 35.669664475405476 139.74341899387474 29.39 35.669664475405476 139.74341899387474 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ddb571a8-0700-4cc4-a033-b581a1350df6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ddb571a8-0700-4cc4-a033-b581a1350df6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ddb571a8-0700-4cc4-a033-b581a1350df6">
											<gml:posList>35.66960930596713 139.74341176528097 29.39 35.66960930596713 139.74341176528097 9.61 35.669664475405476 139.74341899387474 9.61 35.669664475405476 139.74341899387474 29.39 35.66960930596713 139.74341176528097 29.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5930</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">337.87295</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.49</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>