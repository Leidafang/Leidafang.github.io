<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_affd7ffb-c5e7-4357-a6c5-8f8410cc43c6">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">23.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67256789266659 139.73849062853347 0 35.672538727784755 139.73842648254154 0 35.67240999101394 139.73851456538975 0 35.67248249642227 139.73867366040733 0 35.67260977392886 139.73858665097606 0 35.67259764571878 139.73855771226297 0 35.6726190787562 139.73854422115946 0 35.672588342757415 139.73847657520528 0 35.67256789266659 139.73849062853347 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67256789266659 139.73849062853347 9.51 35.672588342757415 139.73847657520528 9.51 35.6726190787562 139.73854422115946 9.51 35.67259764571878 139.73855771226297 9.51 35.67260977392886 139.73858665097606 9.51 35.67248249642227 139.73867366040733 9.51 35.67240999101394 139.73851456538975 9.51 35.672538727784755 139.73842648254154 9.51 35.67256789266659 139.73849062853347 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67256789266659 139.73849062853347 9.51 35.672538727784755 139.73842648254154 9.51 35.672538727784755 139.73842648254154 32.8 35.67256789266659 139.73849062853347 32.8 35.67256789266659 139.73849062853347 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672538727784755 139.73842648254154 9.51 35.67240999101394 139.73851456538975 9.51 35.67240999101394 139.73851456538975 32.8 35.672538727784755 139.73842648254154 32.8 35.672538727784755 139.73842648254154 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67240999101394 139.73851456538975 9.51 35.67248249642227 139.73867366040733 9.51 35.67248249642227 139.73867366040733 32.8 35.67240999101394 139.73851456538975 32.8 35.67240999101394 139.73851456538975 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67248249642227 139.73867366040733 9.51 35.67260977392886 139.73858665097606 9.51 35.67260977392886 139.73858665097606 32.8 35.67248249642227 139.73867366040733 32.8 35.67248249642227 139.73867366040733 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67260977392886 139.73858665097606 9.51 35.67259764571878 139.73855771226297 9.51 35.67259764571878 139.73855771226297 32.8 35.67260977392886 139.73858665097606 32.8 35.67260977392886 139.73858665097606 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67259764571878 139.73855771226297 9.51 35.6726190787562 139.73854422115946 9.51 35.6726190787562 139.73854422115946 32.8 35.67259764571878 139.73855771226297 32.8 35.67259764571878 139.73855771226297 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6726190787562 139.73854422115946 9.51 35.672588342757415 139.73847657520528 9.51 35.672588342757415 139.73847657520528 32.8 35.6726190787562 139.73854422115946 32.8 35.6726190787562 139.73854422115946 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672588342757415 139.73847657520528 9.51 35.67256789266659 139.73849062853347 9.51 35.67256789266659 139.73849062853347 32.8 35.672588342757415 139.73847657520528 32.8 35.672588342757415 139.73847657520528 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67256789266659 139.73849062853347 32.8 35.672538727784755 139.73842648254154 32.8 35.67240999101394 139.73851456538975 32.8 35.67248249642227 139.73867366040733 32.8 35.67260977392886 139.73858665097606 32.8 35.67259764571878 139.73855771226297 32.8 35.6726190787562 139.73854422115946 32.8 35.672588342757415 139.73847657520528 32.8 35.67256789266659 139.73849062853347 32.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b8de5b54-929d-45ac-a46d-3da839105d9c"/>
							<gml:surfaceMember xlink:href="#poly-eeac4c28-df67-4cb4-8377-9153cdf6656a"/>
							<gml:surfaceMember xlink:href="#poly-3a3537f5-cf7d-4d5c-91ab-7adbfcb5be8c"/>
							<gml:surfaceMember xlink:href="#poly-c41348a7-4783-47d6-b98c-a024b1d5960b"/>
							<gml:surfaceMember xlink:href="#poly-79444fc5-0d52-43d7-8b42-912ba30a3031"/>
							<gml:surfaceMember xlink:href="#poly-b7e28afd-c367-44e2-85f2-2445917a0e9a"/>
							<gml:surfaceMember xlink:href="#poly-cd7f1810-da66-497e-a647-18ee4fd5d64a"/>
							<gml:surfaceMember xlink:href="#poly-8a7b9620-f53d-41af-bb69-fb5763dc6578"/>
							<gml:surfaceMember xlink:href="#poly-1679a38f-8ec6-4c53-aa8f-1da1fa8d4785"/>
							<gml:surfaceMember xlink:href="#poly-2f9ebc66-4e2d-4061-aafe-7d67d1af3a16"/>
							<gml:surfaceMember xlink:href="#poly-1bf783b6-0acd-4deb-a660-b6eb681b0fce"/>
							<gml:surfaceMember xlink:href="#poly-7e030e5b-3c6d-4674-b098-11694c637f91"/>
							<gml:surfaceMember xlink:href="#poly-1833be5d-2b0a-4f16-83af-7bad19a7e83f"/>
							<gml:surfaceMember xlink:href="#poly-35724f87-c1a9-49f1-b76f-2462501dceb0"/>
							<gml:surfaceMember xlink:href="#poly-6baf29a3-987e-4699-9616-8b9c343d8b59"/>
							<gml:surfaceMember xlink:href="#poly-b41ab0cc-7ba0-4bfb-b738-52e79ac8a4e8"/>
							<gml:surfaceMember xlink:href="#poly-ba0718cd-7765-4855-baa1-1b845ddd3922"/>
							<gml:surfaceMember xlink:href="#poly-deb7f5d5-d8b2-4850-8e64-b67d748bc233"/>
							<gml:surfaceMember xlink:href="#poly-7ece86b8-95cb-40cc-b8ad-2924b69b94eb"/>
							<gml:surfaceMember xlink:href="#poly-f547ca37-812b-4162-b584-aba2063f36ac"/>
							<gml:surfaceMember xlink:href="#poly-6ff3e01a-75f0-4087-9b19-4e1d09911449"/>
							<gml:surfaceMember xlink:href="#poly-09da6246-1026-4004-86d1-544a8930278f"/>
							<gml:surfaceMember xlink:href="#poly-f2f7061b-e85f-4698-87fb-4cef32468274"/>
							<gml:surfaceMember xlink:href="#poly-81c4436e-4f14-4036-a04a-e4d228242afc"/>
							<gml:surfaceMember xlink:href="#poly-dc03c0fd-819c-4764-bae8-d90fa944084c"/>
							<gml:surfaceMember xlink:href="#poly-d1d8b1f9-1759-437d-ba21-efc1d34082ba"/>
							<gml:surfaceMember xlink:href="#poly-9f9e7836-dc92-4f7e-8017-56c4b83591d8"/>
							<gml:surfaceMember xlink:href="#poly-1da4c359-9161-4428-b8bd-3f6a438e4f0e"/>
							<gml:surfaceMember xlink:href="#poly-3d4de1a4-b054-44fe-bc71-ef54afd9201e"/>
							<gml:surfaceMember xlink:href="#poly-056a8daa-6a93-4e21-9a2c-a912da5225db"/>
							<gml:surfaceMember xlink:href="#poly-fca5e9ea-6073-429d-b5b7-80ed42aca37d"/>
							<gml:surfaceMember xlink:href="#poly-5bbf87b4-a6ef-4a8d-b52c-554150353a9d"/>
							<gml:surfaceMember xlink:href="#poly-4767ce99-79ac-4977-804a-9a022765ab38"/>
							<gml:surfaceMember xlink:href="#poly-ec5d8af8-96ee-41ea-9c28-c3a04f40cb65"/>
							<gml:surfaceMember xlink:href="#poly-f234854a-9209-4ede-8cd5-437525857aa4"/>
							<gml:surfaceMember xlink:href="#poly-ef099d01-7b76-43e3-a5b7-06fd1da9186b"/>
							<gml:surfaceMember xlink:href="#poly-2b209d0e-5072-4e04-95dd-a00fa424f556"/>
							<gml:surfaceMember xlink:href="#poly-def5d575-67ca-44d8-ad86-acce06032a96"/>
							<gml:surfaceMember xlink:href="#poly-3115823d-5189-44ae-9459-762d7cead986"/>
							<gml:surfaceMember xlink:href="#poly-b1b8c771-b440-44bc-b0b3-8d203fe93ab7"/>
							<gml:surfaceMember xlink:href="#poly-94d88926-c8c4-487b-9842-a066c03e57b2"/>
							<gml:surfaceMember xlink:href="#poly-b91db85a-3453-4b21-8edd-e315642f8383"/>
							<gml:surfaceMember xlink:href="#poly-1b57ce4b-6330-435e-930d-0a768888ac2e"/>
							<gml:surfaceMember xlink:href="#poly-cc2af34e-0c0b-479a-8b2f-6a4ad60c4bff"/>
							<gml:surfaceMember xlink:href="#poly-9b17376b-c95a-442a-8d39-0d21f406645e"/>
							<gml:surfaceMember xlink:href="#poly-dbfb6552-7520-4a19-bc1d-ef7260f8faf0"/>
							<gml:surfaceMember xlink:href="#poly-d5c98190-5b28-46c6-a77a-2ac14663e093"/>
							<gml:surfaceMember xlink:href="#poly-a6b9c87b-e131-4e64-966f-a7fcb630796b"/>
							<gml:surfaceMember xlink:href="#poly-a2c7de45-40d9-4df5-8399-a3e1a0937e5d"/>
							<gml:surfaceMember xlink:href="#poly-28e6516e-8dbb-4997-9d77-f8ef60d99f76"/>
							<gml:surfaceMember xlink:href="#poly-c9b6e8c5-9a3e-4012-9e1f-c63986843d69"/>
							<gml:surfaceMember xlink:href="#poly-ba1680cb-df7a-46d9-abfb-857785681550"/>
							<gml:surfaceMember xlink:href="#poly-1343b08e-926b-4bcc-9fad-1762dd6a455c"/>
							<gml:surfaceMember xlink:href="#poly-4da54677-c36b-477b-9152-57457461f723"/>
							<gml:surfaceMember xlink:href="#poly-f19d728b-4b39-407d-a5ed-c1216b59876d"/>
							<gml:surfaceMember xlink:href="#poly-3689b9de-dfd2-430d-8188-3e61bcc3d1a9"/>
							<gml:surfaceMember xlink:href="#poly-f2fd4152-1a9a-4e43-9133-616dbb119b92"/>
							<gml:surfaceMember xlink:href="#poly-adc7cc37-b484-49bc-9038-b3e91ebf3660"/>
							<gml:surfaceMember xlink:href="#poly-31221882-0c7b-4a17-8d83-0c038ffcc141"/>
							<gml:surfaceMember xlink:href="#poly-a3b06534-5683-439d-bf77-592a99987928"/>
							<gml:surfaceMember xlink:href="#poly-91db2b03-f54d-4b23-8022-686f8da0ba35"/>
							<gml:surfaceMember xlink:href="#poly-b6c9dd27-5684-40a4-8993-08acf6b5f05d"/>
							<gml:surfaceMember xlink:href="#poly-8c3c05bf-5a5a-4ccc-9f4b-a1e8910bc3cd"/>
							<gml:surfaceMember xlink:href="#poly-28bd3dcb-fd45-4700-8ac0-1edc112a8842"/>
							<gml:surfaceMember xlink:href="#poly-5d0c829b-49f9-45e1-a3eb-0025992a7cc2"/>
							<gml:surfaceMember xlink:href="#poly-a6d032ca-b7a6-42dc-9a6d-3594470900ab"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_affd7ffb-c5e7-4357-a6c5-8f8410cc43c6_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d2aae29-ce80-4be7-ba4a-4d008524b046">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67261908776989 139.7385442211488 9.46 35.67263159344663 139.7385717454605 9.46 35.67260978294257 139.7385866509654 9.46 35.67259764571875 139.73855771226297 9.46 35.67261908776989 139.7385442211488 9.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df018954-7a58-4f18-8f45-54290b5ef278">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df018954-7a58-4f18-8f45-54290b5ef278_0">
											<gml:posList>35.67259764571875 139.73855771226297 28.737 35.67259764571875 139.73855771226297 9.46 35.67260978294257 139.7385866509654 9.46 35.67260978294257 139.7385866509654 28.737 35.67259764571875 139.73855771226297 28.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35ed52ed-08a6-46fd-a261-65fb89e25108">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35ed52ed-08a6-46fd-a261-65fb89e25108_0">
											<gml:posList>35.67261908776989 139.7385442211488 28.737 35.67261908776989 139.7385442211488 9.46 35.67259764571875 139.73855771226297 9.46 35.67259764571875 139.73855771226297 28.737 35.67261908776989 139.7385442211488 28.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba5f4d4b-9a03-48ff-9b17-e01ad82d4037">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba5f4d4b-9a03-48ff-9b17-e01ad82d4037_0">
											<gml:posList>35.67261908776989 139.7385442211488 28.737 35.67259764571875 139.73855771226297 28.737 35.67260978294257 139.7385866509654 28.737 35.67263159344663 139.7385717454605 28.737 35.67261908776989 139.7385442211488 28.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80c03e9d-b9a4-4d90-a7b2-dd495010ac5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80c03e9d-b9a4-4d90-a7b2-dd495010ac5a_0">
											<gml:posList>35.67260978294257 139.7385866509654 28.737 35.67260978294257 139.7385866509654 9.46 35.67263159344663 139.7385717454605 9.46 35.67263159344663 139.7385717454605 28.737 35.67260978294257 139.7385866509654 28.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-324f6dfe-c593-4cba-b138-84b05d33ec3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-324f6dfe-c593-4cba-b138-84b05d33ec3d_0">
											<gml:posList>35.67263159344663 139.7385717454605 28.737 35.67263159344663 139.7385717454605 9.46 35.67261908776989 139.7385442211488 9.46 35.67261908776989 139.7385442211488 28.737 35.67263159344663 139.7385717454605 28.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_affd7ffb-c5e7-4357-a6c5-8f8410cc43c6_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4ca1efe-c499-476a-8466-aed74daac81f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672561879557975 139.7385123089974 32.79 35.672571050608745 139.73850605684348 32.79 35.67258023346197 139.7385262390979 32.79 35.67258261720635 139.7385314723497 32.79 35.67258041909393 139.7385330435608 32.79 35.672572527502865 139.73853867559214 32.79 35.672561879557975 139.7385123089974 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a039d7c-2957-4ca7-8125-29122b1bec92">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67244669067472 139.7385206307239 32.79 35.67245282198369 139.7385345863055 32.79 35.67244414626837 139.73854030762715 32.79 35.67243801496006 139.73852635204662 32.79 35.67244669067472 139.7385206307239 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c9816ae-3529-44f6-b0e4-b95c67570784">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67259615946048 139.73854754013402 37.904 35.67258791402023 139.73852733467152 37.904 35.67260013974823 139.73851984168942 37.904 35.67260838518973 139.73854004715426 37.904 35.67259615946048 139.73854754013402 37.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f02248bd-6a0e-49cf-951b-0271325e862f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672571512944245 139.73854374716333 32.79 35.67255897951349 139.73854967189143 32.79 35.67255484990421 139.73853654241523 32.79 35.672567383334325 139.7385306176854 32.79 35.672571512944245 139.73854374716333 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c531341b-8265-40a8-88d1-94ea83e2e88e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6725429459857 139.73855207690372 32.79 35.67253768683537 139.73853535863472 32.79 35.67254805777308 139.7385304527465 32.79 35.67255332593779 139.73854717100667 32.79 35.6725429459857 139.73855207690372 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00b78fd4-72d7-4e71-9136-46ba61ec7025">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67250557710667 139.7385546617895 32.79 35.672515487197735 139.73854829830555 32.79 35.672518313717696 139.73855493394265 32.79 35.672508403626296 139.73856129742603 32.79 35.67250557710667 139.7385546617895 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c63e0527-e4d6-4097-bf78-ebac8254dd5f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672463271595944 139.73856091996214 32.79 35.67245628037548 139.7385652805655 32.79 35.67245113278279 139.73855287033416 32.79 35.6724581240028 139.73854850973007 32.79 35.672463271595944 139.73856091996214 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85d2fb5c-1089-444d-9f7c-c2e8f075a0b1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67254293985387 139.73857864388108 32.79 35.67248499026948 139.73861259213848 32.79 35.672483265173156 139.73860817555706 32.79 35.67249247296179 139.73860278500774 32.79 35.67249037753781 139.73859739676732 32.79 35.672547345074584 139.7385640240785 32.79 35.67254652317423 139.7385619262041 32.79 35.672554325463956 139.73855735475212 32.79 35.67255848015604 139.7385679987238 32.79 35.67255052470223 139.73857265872851 32.79 35.67255126531375 139.7385745468146 32.79 35.6725431927422 139.73857928428254 32.79 35.67254293985387 139.73857864388108 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc2b5457-5a20-4748-a786-1b4298ed2a55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67247507827543 139.73859362588004 32.79 35.67246949249869 139.73859710109664 32.79 35.67246301738915 139.73858151102482 32.79 35.67246860315676 139.73857802476087 32.79 35.67247507827543 139.73859362588004 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84ac1b4f-cc35-48f3-9740-69c1ac350f63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84ac1b4f-cc35-48f3-9740-69c1ac350f63_0">
											<gml:posList>35.67245113278279 139.73855287033416 32.79 35.67245628037548 139.7385652805655 32.79 35.67245628037548 139.7385652805655 35.567 35.67245113278279 139.73855287033416 35.567 35.67245113278279 139.73855287033416 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd695f7c-9868-47b7-827d-ad7d16b280ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd695f7c-9868-47b7-827d-ad7d16b280ff_0">
											<gml:posList>35.67245113278279 139.73855287033416 32.79 35.67245113278279 139.73855287033416 35.567 35.6724581240028 139.73854850973007 35.567 35.6724581240028 139.73854850973007 32.79 35.67245113278279 139.73855287033416 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-726ba3f2-f649-4a23-a22d-a8a813acf2eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-726ba3f2-f649-4a23-a22d-a8a813acf2eb_0">
											<gml:posList>35.672463271595944 139.73856091996214 35.567 35.6724581240028 139.73854850973007 35.567 35.67245113278279 139.73855287033416 35.567 35.67245628037548 139.7385652805655 35.567 35.672463271595944 139.73856091996214 35.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25b6da9f-5c24-411e-ad90-d3af1e138d88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25b6da9f-5c24-411e-ad90-d3af1e138d88_0">
											<gml:posList>35.672463271595944 139.73856091996214 32.79 35.672463271595944 139.73856091996214 35.567 35.67245628037548 139.7385652805655 35.567 35.67245628037548 139.7385652805655 32.79 35.672463271595944 139.73856091996214 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6015e0d8-8e6e-46c2-ba5e-8cce94b2059f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6015e0d8-8e6e-46c2-ba5e-8cce94b2059f_0">
											<gml:posList>35.6724581240028 139.73854850973007 32.79 35.6724581240028 139.73854850973007 35.567 35.672463271595944 139.73856091996214 35.567 35.672463271595944 139.73856091996214 32.79 35.6724581240028 139.73854850973007 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-623c9519-f313-4812-a179-8c10875ff4d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-623c9519-f313-4812-a179-8c10875ff4d5_0">
											<gml:posList>35.67246860315676 139.73857802476087 32.79 35.67246301738915 139.73858151102482 32.79 35.67246301738915 139.73858151102482 35.394 35.67246860315676 139.73857802476087 35.394 35.67246860315676 139.73857802476087 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1e7dc7c-08ce-4ebb-a643-d66ec65e33a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1e7dc7c-08ce-4ebb-a643-d66ec65e33a3_0">
											<gml:posList>35.67246301738915 139.73858151102482 32.79 35.67246949249869 139.73859710109664 32.79 35.67246949249869 139.73859710109664 35.394 35.67246301738915 139.73858151102482 35.394 35.67246301738915 139.73858151102482 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d957f978-40fd-4638-beb0-ddd4e16bfa3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d957f978-40fd-4638-beb0-ddd4e16bfa3e_0">
											<gml:posList>35.67247507827543 139.73859362588004 35.394 35.67246860315676 139.73857802476087 35.394 35.67246301738915 139.73858151102482 35.394 35.67246949249869 139.73859710109664 35.394 35.67247507827543 139.73859362588004 35.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b8a066e-535a-4558-914f-008b634b415d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b8a066e-535a-4558-914f-008b634b415d_0">
											<gml:posList>35.67247507827543 139.73859362588004 32.79 35.67246860315676 139.73857802476087 32.79 35.67246860315676 139.73857802476087 35.394 35.67247507827543 139.73859362588004 35.394 35.67247507827543 139.73859362588004 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c98ad85e-b36d-4788-a982-4ef427a526ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c98ad85e-b36d-4788-a982-4ef427a526ed_0">
											<gml:posList>35.67246949249869 139.73859710109664 32.79 35.67247507827543 139.73859362588004 32.79 35.67247507827543 139.73859362588004 35.394 35.67246949249869 139.73859710109664 35.394 35.67246949249869 139.73859710109664 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82e91c6e-e872-4232-973d-d6bc05d0f78a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82e91c6e-e872-4232-973d-d6bc05d0f78a_0">
											<gml:posList>35.672483265173156 139.73860817555706 32.79 35.67248499026948 139.73861259213848 32.79 35.67248499026948 139.73861259213848 34.743 35.672483265173156 139.73860817555706 34.743 35.672483265173156 139.73860817555706 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-621037f0-b7c4-4ff3-b7d7-1ada0ed2b6fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-621037f0-b7c4-4ff3-b7d7-1ada0ed2b6fe_0">
											<gml:posList>35.67249247296179 139.73860278500774 32.79 35.672483265173156 139.73860817555706 32.79 35.672483265173156 139.73860817555706 34.743 35.67249247296179 139.73860278500774 34.743 35.67249247296179 139.73860278500774 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-236acbe8-ae42-48ae-844f-16ab83d852d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-236acbe8-ae42-48ae-844f-16ab83d852d3_0">
											<gml:posList>35.67249037753781 139.73859739676732 32.79 35.67249247296179 139.73860278500774 32.79 35.67249247296179 139.73860278500774 34.743 35.67249037753781 139.73859739676732 34.743 35.67249037753781 139.73859739676732 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64489b58-d4fa-464d-84ae-87cc60b0cb8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64489b58-d4fa-464d-84ae-87cc60b0cb8e_0">
											<gml:posList>35.67250557710667 139.7385546617895 32.79 35.672508403626296 139.73856129742603 32.79 35.672508403626296 139.73856129742603 34.46 35.67250557710667 139.7385546617895 34.46 35.67250557710667 139.7385546617895 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a32def66-aed6-4c6c-87cc-103c16322f69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a32def66-aed6-4c6c-87cc-103c16322f69_0">
											<gml:posList>35.672515487197735 139.73854829830555 32.79 35.67250557710667 139.7385546617895 32.79 35.67250557710667 139.7385546617895 34.46 35.672515487197735 139.73854829830555 34.46 35.672515487197735 139.73854829830555 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-950d5065-7548-41b4-af24-e7dcb6b259d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-950d5065-7548-41b4-af24-e7dcb6b259d6_0">
											<gml:posList>35.672518313717696 139.73855493394265 34.46 35.672515487197735 139.73854829830555 34.46 35.67250557710667 139.7385546617895 34.46 35.672508403626296 139.73856129742603 34.46 35.672518313717696 139.73855493394265 34.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-017a4d8b-71be-4915-84b9-f1f91cd77212">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-017a4d8b-71be-4915-84b9-f1f91cd77212_0">
											<gml:posList>35.672508403626296 139.73856129742603 32.79 35.672518313717696 139.73855493394265 32.79 35.672518313717696 139.73855493394265 34.46 35.672508403626296 139.73856129742603 34.46 35.672508403626296 139.73856129742603 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b4bc9f7-f660-41b1-90cc-8f71cb709ca7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b4bc9f7-f660-41b1-90cc-8f71cb709ca7_0">
											<gml:posList>35.67248499026948 139.73861259213848 34.743 35.67248499026948 139.73861259213848 32.79 35.67254293985387 139.73857864388108 32.79 35.67254293985387 139.73857864388108 34.287 35.67254293985387 139.73857864388108 34.743 35.67248499026948 139.73861259213848 34.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84749d69-f454-4dfd-bd0b-c313985c759e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84749d69-f454-4dfd-bd0b-c313985c759e_0">
											<gml:posList>35.67248499026948 139.73861259213848 34.743 35.67254293985387 139.73857864388108 34.743 35.67254090766395 139.73857343230807 34.743 35.67254913340765 139.7385686173327 34.743 35.672547345074584 139.7385640240785 34.743 35.67249037753781 139.73859739676732 34.743 35.67249247296179 139.73860278500774 34.743 35.672483265173156 139.73860817555706 34.743 35.67248499026948 139.73861259213848 34.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ede924ad-5b5e-4df0-9d70-da1e1b21e599">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ede924ad-5b5e-4df0-9d70-da1e1b21e599_0">
											<gml:posList>35.672518313717696 139.73855493394265 32.79 35.672515487197735 139.73854829830555 32.79 35.672515487197735 139.73854829830555 34.46 35.672518313717696 139.73855493394265 34.46 35.672518313717696 139.73855493394265 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab60d4f4-0554-44a2-9883-b0488900e523">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab60d4f4-0554-44a2-9883-b0488900e523_0">
											<gml:posList>35.672547345074584 139.7385640240785 34.287 35.672547345074584 139.7385640240785 32.79 35.67249037753781 139.73859739676732 32.79 35.67249037753781 139.73859739676732 34.743 35.672547345074584 139.7385640240785 34.743 35.672547345074584 139.7385640240785 34.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ff5fd01-22e0-4516-bb22-2e3e86257efb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ff5fd01-22e0-4516-bb22-2e3e86257efb_0">
											<gml:posList>35.67253768683537 139.73853535863472 32.79 35.6725429459857 139.73855207690372 32.79 35.6725429459857 139.73855207690372 34.004 35.67253768683537 139.73853535863472 34.004 35.67253768683537 139.73853535863472 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d000a8a-55f3-49e1-8ed2-6695e46109da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d000a8a-55f3-49e1-8ed2-6695e46109da_0">
											<gml:posList>35.67254090766395 139.73857343230807 34.287 35.67254090766395 139.73857343230807 34.743 35.67254293985387 139.73857864388108 34.743 35.67254293985387 139.73857864388108 34.287 35.67254090766395 139.73857343230807 34.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97966e0a-5847-44c7-bdf1-1f200fa31e17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97966e0a-5847-44c7-bdf1-1f200fa31e17_0">
											<gml:posList>35.67254293985387 139.73857864388108 32.79 35.6725431927422 139.73857928428254 32.79 35.6725431927422 139.73857928428254 34.287 35.67254293985387 139.73857864388108 34.287 35.67254293985387 139.73857864388108 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74ee7adf-d318-457c-a4f4-3332dce965e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74ee7adf-d318-457c-a4f4-3332dce965e1_0">
											<gml:posList>35.67254913340765 139.7385686173327 34.743 35.67254090766395 139.73857343230807 34.743 35.67254090766395 139.73857343230807 34.287 35.67254913340765 139.7385686173327 34.287 35.67254913340765 139.7385686173327 34.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f6a5ea5-b74c-4f0e-bc47-96af34df258e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f6a5ea5-b74c-4f0e-bc47-96af34df258e_0">
											<gml:posList>35.672547345074584 139.7385640240785 32.79 35.672547345074584 139.7385640240785 34.287 35.67254652317423 139.7385619262041 34.287 35.67254652317423 139.7385619262041 32.79 35.672547345074584 139.7385640240785 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f99906d3-cb24-4ef7-b5c9-e32218c44e84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f99906d3-cb24-4ef7-b5c9-e32218c44e84_0">
											<gml:posList>35.6725431927422 139.73857928428254 32.79 35.67255126531375 139.7385745468146 32.79 35.67255126531375 139.7385745468146 34.287 35.6725431927422 139.73857928428254 34.287 35.6725431927422 139.73857928428254 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40816a32-8b58-479c-82d9-fa76d1ec2032">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40816a32-8b58-479c-82d9-fa76d1ec2032_0">
											<gml:posList>35.6725429459857 139.73855207690372 32.79 35.67255332593779 139.73854717100667 32.79 35.67255332593779 139.73854717100667 34.004 35.6725429459857 139.73855207690372 34.004 35.6725429459857 139.73855207690372 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3586bcc-76fa-40c1-882d-0841928bf484">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3586bcc-76fa-40c1-882d-0841928bf484_0">
											<gml:posList>35.672547345074584 139.7385640240785 34.287 35.672547345074584 139.7385640240785 34.743 35.67254913340765 139.7385686173327 34.743 35.67254913340765 139.7385686173327 34.287 35.672547345074584 139.7385640240785 34.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1081740-c040-45a7-b1ff-7dec108e060d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1081740-c040-45a7-b1ff-7dec108e060d_0">
											<gml:posList>35.672547345074584 139.7385640240785 34.287 35.67254913340765 139.7385686173327 34.287 35.67254090766395 139.73857343230807 34.287 35.67254293985387 139.73857864388108 34.287 35.6725431927422 139.73857928428254 34.287 35.67255126531375 139.7385745468146 34.287 35.67255052470223 139.73857265872851 34.287 35.67255848015604 139.7385679987238 34.287 35.672554325463956 139.73855735475212 34.287 35.67254652317423 139.7385619262041 34.287 35.672547345074584 139.7385640240785 34.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9c0240a-d2d6-4b21-80d7-0036c52157ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9c0240a-d2d6-4b21-80d7-0036c52157ee_0">
											<gml:posList>35.672554325463956 139.73855735475212 32.79 35.67254652317423 139.7385619262041 32.79 35.67254652317423 139.7385619262041 34.287 35.672554325463956 139.73855735475212 34.287 35.672554325463956 139.73855735475212 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f96a6fd-de30-4339-9b9d-99b2a09e0ab9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f96a6fd-de30-4339-9b9d-99b2a09e0ab9_0">
											<gml:posList>35.67255126531375 139.7385745468146 32.79 35.67255052470223 139.73857265872851 32.79 35.67255052470223 139.73857265872851 34.287 35.67255126531375 139.7385745468146 34.287 35.67255126531375 139.7385745468146 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec1c8edd-4af3-44d6-805f-94427533dcb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec1c8edd-4af3-44d6-805f-94427533dcb9_0">
											<gml:posList>35.67255848015604 139.7385679987238 32.79 35.67255848015604 139.7385679987238 34.287 35.67255052470223 139.73857265872851 34.287 35.67255052470223 139.73857265872851 32.79 35.67255848015604 139.7385679987238 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc9af34e-78b8-4928-8516-4eb2df2713b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc9af34e-78b8-4928-8516-4eb2df2713b3_0">
											<gml:posList>35.672554325463956 139.73855735475212 32.79 35.672554325463956 139.73855735475212 34.287 35.67255848015604 139.7385679987238 34.287 35.67255848015604 139.7385679987238 32.79 35.672554325463956 139.73855735475212 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a44edd56-0666-4e3b-a926-d104c56c8b55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a44edd56-0666-4e3b-a926-d104c56c8b55_0">
											<gml:posList>35.67255897951349 139.73854967189143 32.79 35.672571512944245 139.73854374716333 32.79 35.672571512944245 139.73854374716333 33.364 35.67255897951349 139.73854967189143 33.364 35.67255897951349 139.73854967189143 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5188332d-e0bb-4856-9c3c-9b075bde9d42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5188332d-e0bb-4856-9c3c-9b075bde9d42_0">
											<gml:posList>35.67259615946048 139.73854754013402 37.904 35.67260838518973 139.73854004715426 37.904 35.67260838518973 139.73854004715426 38.279 35.67259615946048 139.73854754013402 38.279 35.67259615946048 139.73854754013402 37.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b35e64d-6e4c-4a38-a81f-1185e6c01a5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b35e64d-6e4c-4a38-a81f-1185e6c01a5d_0">
											<gml:posList>35.67244414626837 139.73854030762715 32.79 35.67244414626837 139.73854030762715 33.712 35.67243801496006 139.73852635204662 33.712 35.67243801496006 139.73852635204662 32.79 35.67244414626837 139.73854030762715 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-487ba799-e8c1-47e8-ab3e-8bc74edb364f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-487ba799-e8c1-47e8-ab3e-8bc74edb364f_0">
											<gml:posList>35.67243801496006 139.73852635204662 32.79 35.67243801496006 139.73852635204662 33.712 35.67244669067472 139.7385206307239 33.712 35.67244669067472 139.7385206307239 32.79 35.67243801496006 139.73852635204662 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce7e1e7f-1319-4bb3-a056-c7dfc20054e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce7e1e7f-1319-4bb3-a056-c7dfc20054e7_0">
											<gml:posList>35.67244414626837 139.73854030762715 33.712 35.67245282198369 139.7385345863055 33.712 35.67244669067472 139.7385206307239 33.712 35.67243801496006 139.73852635204662 33.712 35.67244414626837 139.73854030762715 33.712</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-397e9a71-7891-446b-b900-e8150335b6d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-397e9a71-7891-446b-b900-e8150335b6d8_0">
											<gml:posList>35.67245282198369 139.7385345863055 32.79 35.67245282198369 139.7385345863055 33.712 35.67244414626837 139.73854030762715 33.712 35.67244414626837 139.73854030762715 32.79 35.67245282198369 139.7385345863055 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec2e997f-06e6-4677-b95a-981fca509821">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec2e997f-06e6-4677-b95a-981fca509821_0">
											<gml:posList>35.67244669067472 139.7385206307239 32.79 35.67244669067472 139.7385206307239 33.712 35.67245282198369 139.7385345863055 33.712 35.67245282198369 139.7385345863055 32.79 35.67244669067472 139.7385206307239 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1f42b59-f2bf-4d40-baae-2fe99ab043fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1f42b59-f2bf-4d40-baae-2fe99ab043fb_0">
											<gml:posList>35.67254805777308 139.7385304527465 32.79 35.67253768683537 139.73853535863472 32.79 35.67253768683537 139.73853535863472 34.004 35.67254805777308 139.7385304527465 34.004 35.67254805777308 139.7385304527465 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e0cf3dc-07d5-4ee8-8dc4-a2f0ac773261">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e0cf3dc-07d5-4ee8-8dc4-a2f0ac773261_0">
											<gml:posList>35.67254805777308 139.7385304527465 34.004 35.67253768683537 139.73853535863472 34.004 35.6725429459857 139.73855207690372 34.004 35.67255332593779 139.73854717100667 34.004 35.67254805777308 139.7385304527465 34.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0b5c911-0bf4-423b-a8a1-a9e37ff599a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0b5c911-0bf4-423b-a8a1-a9e37ff599a8_0">
											<gml:posList>35.67254805777308 139.7385304527465 32.79 35.67254805777308 139.7385304527465 34.004 35.67255332593779 139.73854717100667 34.004 35.67255332593779 139.73854717100667 32.79 35.67254805777308 139.7385304527465 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3420591d-d9af-4895-ac5e-a0a45dcafe08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3420591d-d9af-4895-ac5e-a0a45dcafe08_0">
											<gml:posList>35.67255484990421 139.73853654241523 32.79 35.67255897951349 139.73854967189143 32.79 35.67255897951349 139.73854967189143 33.364 35.67255484990421 139.73853654241523 33.364 35.67255484990421 139.73853654241523 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b618dcc-8475-46b3-93d1-35521de4938e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b618dcc-8475-46b3-93d1-35521de4938e_0">
											<gml:posList>35.672567383334325 139.7385306176854 32.79 35.67255484990421 139.73853654241523 32.79 35.67255484990421 139.73853654241523 33.364 35.672567383334325 139.7385306176854 33.364 35.672567383334325 139.7385306176854 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3ce85c2-7504-4bf9-b76a-6c606cd6e999">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3ce85c2-7504-4bf9-b76a-6c606cd6e999_0">
											<gml:posList>35.67255484990421 139.73853654241523 33.364 35.67255897951349 139.73854967189143 33.364 35.672571512944245 139.73854374716333 33.364 35.672567383334325 139.7385306176854 33.364 35.67255484990421 139.73853654241523 33.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4e56eb0-c0f1-4a69-9033-f3f7eb94f829">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4e56eb0-c0f1-4a69-9033-f3f7eb94f829_0">
											<gml:posList>35.672571050608745 139.73850605684348 32.79 35.672561879557975 139.7385123089974 32.79 35.672561879557975 139.7385123089974 36.302 35.672571050608745 139.73850605684348 36.302 35.672571050608745 139.73850605684348 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-750310f7-cc02-47a2-b505-67073d5ed174">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-750310f7-cc02-47a2-b505-67073d5ed174_0">
											<gml:posList>35.672561879557975 139.7385123089974 32.79 35.672572527502865 139.73853867559214 32.79 35.672572527502865 139.73853867559214 36.302 35.672561879557975 139.7385123089974 36.302 35.672561879557975 139.7385123089974 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aec0e3ae-f30b-49fb-b2bc-9fb97c2e5473">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aec0e3ae-f30b-49fb-b2bc-9fb97c2e5473_0">
											<gml:posList>35.672567383334325 139.7385306176854 32.79 35.672567383334325 139.7385306176854 33.364 35.672571512944245 139.73854374716333 33.364 35.672571512944245 139.73854374716333 32.79 35.672567383334325 139.7385306176854 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-290dab51-ec78-4d1f-97f8-801526f19729">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-290dab51-ec78-4d1f-97f8-801526f19729_0">
											<gml:posList>35.67258041909393 139.7385330435608 36.302 35.67258261720635 139.7385314723497 36.302 35.67258023346197 139.7385262390979 36.302 35.672571050608745 139.73850605684348 36.302 35.672561879557975 139.7385123089974 36.302 35.672572527502865 139.73853867559214 36.302 35.67258041909393 139.7385330435608 36.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-faf3b87a-f2f9-4ec5-a116-4065b0a3d497">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-faf3b87a-f2f9-4ec5-a116-4065b0a3d497_0">
											<gml:posList>35.67258023346197 139.7385262390979 36.302 35.67258023346197 139.7385262390979 32.79 35.672571050608745 139.73850605684348 32.79 35.672571050608745 139.73850605684348 36.302 35.67258023346197 139.7385262390979 36.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-676a07d1-8b90-4ebf-b3c3-2fd6765b7146">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-676a07d1-8b90-4ebf-b3c3-2fd6765b7146_0">
											<gml:posList>35.67258041909393 139.7385330435608 36.302 35.672572527502865 139.73853867559214 36.302 35.672572527502865 139.73853867559214 32.79 35.67258041909393 139.7385330435608 32.79 35.67258041909393 139.7385330435608 36.302</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-498303d6-d74a-4a3c-8ebc-8739472e7e6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-498303d6-d74a-4a3c-8ebc-8739472e7e6f_0">
											<gml:posList>35.67258023346197 139.7385262390979 32.79 35.67258023346197 139.7385262390979 36.302 35.67258261720635 139.7385314723497 36.302 35.67258261720635 139.7385314723497 32.79 35.67258023346197 139.7385262390979 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edbd5fad-20f2-4b2e-8d7b-a34109a3cb32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edbd5fad-20f2-4b2e-8d7b-a34109a3cb32_0">
											<gml:posList>35.67258041909393 139.7385330435608 32.79 35.67258261720635 139.7385314723497 32.79 35.67258261720635 139.7385314723497 36.302 35.67258041909393 139.7385330435608 36.302 35.67258041909393 139.7385330435608 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b13b466-40ef-4580-bccc-721ad0fa1efe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b13b466-40ef-4580-bccc-721ad0fa1efe_0">
											<gml:posList>35.67258791402023 139.73852733467152 37.904 35.67259615946048 139.73854754013402 37.904 35.67259615946048 139.73854754013402 38.279 35.67258791402023 139.73852733467152 38.279 35.67258791402023 139.73852733467152 37.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28c26062-d3e8-4a5e-81d9-a6cc577030c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28c26062-d3e8-4a5e-81d9-a6cc577030c1_0">
											<gml:posList>35.67260013974823 139.73851984168942 37.904 35.67258791402023 139.73852733467152 37.904 35.67258791402023 139.73852733467152 38.279 35.67260013974823 139.73851984168942 38.279 35.67260013974823 139.73851984168942 37.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31a168a3-a30d-4703-bf05-0a4356f21fd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31a168a3-a30d-4703-bf05-0a4356f21fd8_0">
											<gml:posList>35.67260013974823 139.73851984168942 38.279 35.67258791402023 139.73852733467152 38.279 35.67259615946048 139.73854754013402 38.279 35.67260838518973 139.73854004715426 38.279 35.67260013974823 139.73851984168942 38.279</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ef5841c-d138-4cd3-b1b1-9a8122e5a04e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ef5841c-d138-4cd3-b1b1-9a8122e5a04e_0">
											<gml:posList>35.67260013974823 139.73851984168942 37.904 35.67260013974823 139.73851984168942 38.279 35.67260838518973 139.73854004715426 38.279 35.67260838518973 139.73854004715426 37.904 35.67260013974823 139.73851984168942 37.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_affd7ffb-c5e7-4357-a6c5-8f8410cc43c6_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76541a8c-3b9c-4d51-bd79-74ec88874ee9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672525487990704 139.73850830899985 32.79 35.67248473007085 139.7385339410155 32.79 35.67247423637587 139.73850886671391 32.79 35.67251500331285 139.73848324572475 32.79 35.672525487990704 139.73850830899985 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cce6dcb8-43da-41d5-b2d8-36bf118a3519">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cce6dcb8-43da-41d5-b2d8-36bf118a3519_0">
											<gml:posList>35.67251500331285 139.73848324572475 35.675 35.672525487990704 139.73850830899985 35.675 35.672525487990704 139.73850830899985 32.79 35.67251500331285 139.73848324572475 32.79 35.67251500331285 139.73848324572475 35.675</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5f4991f-478a-4308-95ca-ed176b9a5bfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5f4991f-478a-4308-95ca-ed176b9a5bfb_0">
											<gml:posList>35.67247423637587 139.73850886671391 35.675 35.67251500331285 139.73848324572475 35.675 35.67251500331285 139.73848324572475 32.79 35.67247423637587 139.73850886671391 32.79 35.67247423637587 139.73850886671391 35.675</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-560a9725-e3a5-4a2d-abdf-33583c03a456">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-560a9725-e3a5-4a2d-abdf-33583c03a456_0">
											<gml:posList>35.672525487990704 139.73850830899985 35.675 35.67251500331285 139.73848324572475 35.675 35.67247423637587 139.73850886671391 35.675 35.67248473007085 139.7385339410155 35.675 35.672525487990704 139.73850830899985 35.675</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6dd0995e-1987-4e6d-b4f9-3ed9d4c7031b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6dd0995e-1987-4e6d-b4f9-3ed9d4c7031b_0">
											<gml:posList>35.672525487990704 139.73850830899985 35.675 35.67248473007085 139.7385339410155 35.675 35.67248473007085 139.7385339410155 32.79 35.672525487990704 139.73850830899985 32.79 35.672525487990704 139.73850830899985 35.675</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd656d8b-702e-48f7-9d79-23a43e024024">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd656d8b-702e-48f7-9d79-23a43e024024_0">
											<gml:posList>35.67248473007085 139.7385339410155 32.79 35.67248473007085 139.7385339410155 35.675 35.67247423637587 139.73850886671391 35.675 35.67247423637587 139.73850886671391 32.79 35.67248473007085 139.7385339410155 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b8de5b54-929d-45ac-a46d-3da839105d9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8de5b54-929d-45ac-a46d-3da839105d9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8de5b54-929d-45ac-a46d-3da839105d9c">
											<gml:posList>35.67259764571875 139.73855771226297 9.51 35.672609773928855 139.73858665097606 9.51 35.672482496422234 139.73867366040733 9.51 35.672409991013915 139.73851456538975 9.51 35.672538727784755 139.73842648254154 9.51 35.67256789266658 139.73849062853347 9.51 35.67258834275741 139.73847657520528 9.51 35.67261907875617 139.73854422115943 9.51 35.67259764571875 139.73855771226297 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eeac4c28-df67-4cb4-8377-9153cdf6656a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eeac4c28-df67-4cb4-8377-9153cdf6656a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eeac4c28-df67-4cb4-8377-9153cdf6656a">
											<gml:posList>35.672434032966365 139.73855188531462 33.518 35.67241834902801 139.7385174717913 33.518 35.672409991013915 139.73851456538975 33.518 35.672431643342435 139.73856208409788 33.518 35.67243698566083 139.7385584987029 33.518 35.672434032966365 139.73855188531462 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a3537f5-cf7d-4d5c-91ab-7adbfcb5be8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a3537f5-cf7d-4d5c-91ab-7adbfcb5be8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a3537f5-cf7d-4d5c-91ab-7adbfcb5be8c">
											<gml:posList>35.672431643342435 139.73856208409788 36.364 35.672436214576095 139.73856370253597 36.364 35.67244845776027 139.73855548048107 36.364 35.67244986847959 139.73854984507568 36.364 35.672431643342435 139.73856208409788 36.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c41348a7-4783-47d6-b98c-a024b1d5960b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c41348a7-4783-47d6-b98c-a024b1d5960b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c41348a7-4783-47d6-b98c-a024b1d5960b">
											<gml:posList>35.67245653717348 139.738616712977 36.364 35.672457821738355 139.73861112190735 36.364 35.672436214576095 139.73856370253597 36.364 35.672431643342435 139.73856208409788 36.364 35.67245653717348 139.738616712977 36.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79444fc5-0d52-43d7-8b42-912ba30a3031">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79444fc5-0d52-43d7-8b42-912ba30a3031">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79444fc5-0d52-43d7-8b42-912ba30a3031">
											<gml:posList>35.672468506264956 139.73860380751606 35.978 35.67244845776027 139.73855548048107 35.978 35.672436214576095 139.73856370253597 35.978 35.672457821738355 139.73861112190735 35.978 35.672468506264956 139.73860380751606 35.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b7e28afd-c367-44e2-85f2-2445917a0e9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7e28afd-c367-44e2-85f2-2445917a0e9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7e28afd-c367-44e2-85f2-2445917a0e9a">
											<gml:posList>35.67244986847959 139.73854984507568 36.364 35.67244845776027 139.73855548048107 36.364 35.672468506264956 139.73860380751606 36.364 35.67247296035445 139.73860547028184 36.364 35.67244986847959 139.73854984507568 36.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd7f1810-da66-497e-a647-18ee4fd5d64a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd7f1810-da66-497e-a647-18ee4fd5d64a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd7f1810-da66-497e-a647-18ee4fd5d64a">
											<gml:posList>35.67247296035445 139.73860547028184 36.364 35.672468506264956 139.73860380751606 36.364 35.672457821738355 139.73861112190735 36.364 35.67245653717348 139.738616712977 36.364 35.67247296035445 139.73860547028184 36.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a7b9620-f53d-41af-bb69-fb5763dc6578">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a7b9620-f53d-41af-bb69-fb5763dc6578">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a7b9620-f53d-41af-bb69-fb5763dc6578">
											<gml:posList>35.67247766261618 139.7386476183539 33.518 35.67246190646513 139.73861303918028 33.518 35.67245653717348 139.738616712977 33.518 35.67247515560604 139.7386575632079 33.518 35.67247766261618 139.7386476183539 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1679a38f-8ec6-4c53-aa8f-1da1fa8d4785">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1679a38f-8ec6-4c53-aa8f-1da1fa8d4785">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1679a38f-8ec6-4c53-aa8f-1da1fa8d4785">
											<gml:posList>35.672409991013915 139.73851456538975 33.518 35.67241834902801 139.7385174717913 33.518 35.672536338206335 139.73843672552803 33.518 35.672538727784755 139.73842648254154 33.518 35.672409991013915 139.73851456538975 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2f9ebc66-4e2d-4061-aafe-7d67d1af3a16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f9ebc66-4e2d-4061-aafe-7d67d1af3a16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f9ebc66-4e2d-4061-aafe-7d67d1af3a16">
											<gml:posList>35.67251491410686 139.73863330221133 33.518 35.67250702426172 139.73862969930838 33.518 35.67247766261618 139.7386476183539 33.518 35.67247515560604 139.7386575632079 33.518 35.67251491410686 139.73863330221133 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1bf783b6-0acd-4deb-a660-b6eb681b0fce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bf783b6-0acd-4deb-a660-b6eb681b0fce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bf783b6-0acd-4deb-a660-b6eb681b0fce">
											<gml:posList>35.672434032966365 139.73855188531462 32.79 35.67243698566083 139.7385584987029 32.79 35.67244986847959 139.73854984507568 32.79 35.67247296035445 139.73860547028184 32.79 35.67246190646513 139.73861303918028 32.79 35.67247766261618 139.7386476183539 32.79 35.67250702426172 139.73862969930838 32.79 35.67250475659645 139.73862306300936 32.79 35.67259445283017 139.73856658642868 32.79 35.672593793594125 139.73856501859584 32.79 35.6725908138937 139.73855844941258 32.79 35.672582732917704 139.7385639601538 32.79 35.672572527502865 139.73853867559214 32.79 35.67258261720635 139.7385314723497 32.79 35.67256692417913 139.73849697040495 32.79 35.672564491780065 139.73849863026632 32.79 35.67256149403987 139.73849205006275 32.79 35.672536338206335 139.73843672552803 32.79 35.67241834902801 139.7385174717913 32.79 35.672434032966365 139.73855188531462 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e030e5b-3c6d-4674-b098-11694c637f91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e030e5b-3c6d-4674-b098-11694c637f91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e030e5b-3c6d-4674-b098-11694c637f91">
											<gml:posList>35.67251261933982 139.7386265886177 33.518 35.67250475659645 139.73862306300936 33.518 35.67250702426172 139.73862969930838 33.518 35.67251491410686 139.73863330221133 33.518 35.67251261933982 139.7386265886177 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1833be5d-2b0a-4f16-83af-7bad19a7e83f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1833be5d-2b0a-4f16-83af-7bad19a7e83f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1833be5d-2b0a-4f16-83af-7bad19a7e83f">
											<gml:posList>35.672609773928855 139.73858665097606 29.33 35.67260273000617 139.73856985747454 29.33 35.67251261933982 139.7386265886177 29.33 35.67251491410686 139.73863330221133 29.33 35.67247515560604 139.7386575632079 29.33 35.672482496422234 139.73867366040733 29.33 35.672609773928855 139.73858665097606 29.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35724f87-c1a9-49f1-b76f-2462501dceb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35724f87-c1a9-49f1-b76f-2462501dceb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35724f87-c1a9-49f1-b76f-2462501dceb0">
											<gml:posList>35.67256789266658 139.73849062853347 33.518 35.672538727784755 139.73842648254154 33.518 35.672536338206335 139.73843672552803 33.518 35.67256149403987 139.73849205006275 33.518 35.67256789266658 139.73849062853347 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6baf29a3-987e-4699-9616-8b9c343d8b59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6baf29a3-987e-4699-9616-8b9c343d8b59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6baf29a3-987e-4699-9616-8b9c343d8b59">
											<gml:posList>35.67251261933982 139.7386265886177 33.518 35.67260273000617 139.73856985747454 33.518 35.67259445283017 139.73856658642868 33.518 35.67250475659645 139.73862306300936 33.518 35.67251261933982 139.7386265886177 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b41ab0cc-7ba0-4bfb-b738-52e79ac8a4e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b41ab0cc-7ba0-4bfb-b738-52e79ac8a4e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b41ab0cc-7ba0-4bfb-b738-52e79ac8a4e8">
											<gml:posList>35.67256692417913 139.73849697040495 33.518 35.672590347283816 139.73848099145908 33.518 35.67258834275741 139.73847657520528 33.518 35.67256789266658 139.73849062853347 33.518 35.67256149403987 139.73849205006275 33.518 35.672564491780065 139.73849863026632 33.518 35.67256692417913 139.73849697040495 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba0718cd-7765-4855-baa1-1b845ddd3922">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba0718cd-7765-4855-baa1-1b845ddd3922">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba0718cd-7765-4855-baa1-1b845ddd3922">
											<gml:posList>35.67258261720635 139.7385314723497 38.474 35.672587503937876 139.73853311250912 38.474 35.6725718470269 139.73849868784512 38.474 35.67256692417913 139.73849697040495 38.474 35.67258261720635 139.7385314723497 38.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-deb7f5d5-d8b2-4850-8e64-b67d748bc233">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-deb7f5d5-d8b2-4850-8e64-b67d748bc233">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-deb7f5d5-d8b2-4850-8e64-b67d748bc233">
											<gml:posList>35.672572527502865 139.73853867559214 38.474 35.672582732917704 139.7385639601538 38.474 35.67258429647933 139.7385578274631 38.474 35.67257726107933 139.7385404153519 38.474 35.672572527502865 139.73853867559214 38.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7ece86b8-95cb-40cc-b8ad-2924b69b94eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ece86b8-95cb-40cc-b8ad-2924b69b94eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ece86b8-95cb-40cc-b8ad-2924b69b94eb">
											<gml:posList>35.67256692417913 139.73849697040495 38.474 35.6725718470269 139.73849868784512 38.474 35.672588945886034 139.73848701349425 38.474 35.672590347283816 139.73848099145908 38.474 35.67256692417913 139.73849697040495 38.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f547ca37-812b-4162-b584-aba2063f36ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f547ca37-812b-4162-b584-aba2063f36ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f547ca37-812b-4162-b584-aba2063f36ac">
											<gml:posList>35.67258261720635 139.7385314723497 38.474 35.672572527502865 139.73853867559214 38.474 35.67257726107933 139.7385404153519 38.474 35.672587503937876 139.73853311250912 38.474 35.67258261720635 139.7385314723497 38.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ff3e01a-75f0-4087-9b19-4e1d09911449">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ff3e01a-75f0-4087-9b19-4e1d09911449">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ff3e01a-75f0-4087-9b19-4e1d09911449">
											<gml:posList>35.672587503937876 139.73853311250912 37.904 35.67257726107933 139.7385404153519 37.904 35.67258429647933 139.7385578274631 37.904 35.67261241320891 139.73853862843103 37.904 35.672588945886034 139.73848701349425 37.904 35.6725718470269 139.73849868784512 37.904 35.672587503937876 139.73853311250912 37.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09da6246-1026-4004-86d1-544a8930278f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09da6246-1026-4004-86d1-544a8930278f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09da6246-1026-4004-86d1-544a8930278f">
											<gml:posList>35.67259764571875 139.73855771226297 33.518 35.672593793594125 139.73856501859584 33.518 35.67259445283017 139.73856658642868 33.518 35.67260273000617 139.73856985747454 33.518 35.67259764571875 139.73855771226297 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f2f7061b-e85f-4698-87fb-4cef32468274">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2f7061b-e85f-4698-87fb-4cef32468274">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2f7061b-e85f-4698-87fb-4cef32468274">
											<gml:posList>35.672617327051036 139.73854035693194 38.474 35.67261241320891 139.73853862843103 38.474 35.67258429647933 139.7385578274631 38.474 35.672582732917704 139.7385639601538 38.474 35.672617327051036 139.73854035693194 38.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-81c4436e-4f14-4036-a04a-e4d228242afc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81c4436e-4f14-4036-a04a-e4d228242afc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81c4436e-4f14-4036-a04a-e4d228242afc">
											<gml:posList>35.672590347283816 139.73848099145908 38.474 35.672588945886034 139.73848701349425 38.474 35.67261241320891 139.73853862843103 38.474 35.672617327051036 139.73854035693194 38.474 35.672590347283816 139.73848099145908 38.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc03c0fd-819c-4764-bae8-d90fa944084c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc03c0fd-819c-4764-bae8-d90fa944084c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc03c0fd-819c-4764-bae8-d90fa944084c">
											<gml:posList>35.67259764571875 139.73855771226297 33.518 35.67261907875617 139.73854422115943 33.518 35.672617327051036 139.73854035693194 33.518 35.6725908138937 139.73855844941258 33.518 35.672593793594125 139.73856501859584 33.518 35.67259764571875 139.73855771226297 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1d8b1f9-1759-437d-ba21-efc1d34082ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1d8b1f9-1759-437d-ba21-efc1d34082ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1d8b1f9-1759-437d-ba21-efc1d34082ba">
											<gml:posList>35.672587503937876 139.73853311250912 38.474 35.672587503937876 139.73853311250912 37.904 35.6725718470269 139.73849868784512 37.904 35.6725718470269 139.73849868784512 38.474 35.672587503937876 139.73853311250912 38.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f9e7836-dc92-4f7e-8017-56c4b83591d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f9e7836-dc92-4f7e-8017-56c4b83591d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f9e7836-dc92-4f7e-8017-56c4b83591d8">
											<gml:posList>35.67257726107933 139.7385404153519 38.474 35.67257726107933 139.7385404153519 37.904 35.672587503937876 139.73853311250912 37.904 35.672587503937876 139.73853311250912 38.474 35.67257726107933 139.7385404153519 38.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1da4c359-9161-4428-b8bd-3f6a438e4f0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1da4c359-9161-4428-b8bd-3f6a438e4f0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1da4c359-9161-4428-b8bd-3f6a438e4f0e">
											<gml:posList>35.67244845776027 139.73855548048107 36.364 35.67244845776027 139.73855548048107 35.978 35.672468506264956 139.73860380751606 35.978 35.672468506264956 139.73860380751606 36.364 35.67244845776027 139.73855548048107 36.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d4de1a4-b054-44fe-bc71-ef54afd9201e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d4de1a4-b054-44fe-bc71-ef54afd9201e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d4de1a4-b054-44fe-bc71-ef54afd9201e">
											<gml:posList>35.672457821738355 139.73861112190735 36.364 35.672457821738355 139.73861112190735 35.978 35.672436214576095 139.73856370253597 35.978 35.672436214576095 139.73856370253597 36.364 35.672457821738355 139.73861112190735 36.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-056a8daa-6a93-4e21-9a2c-a912da5225db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-056a8daa-6a93-4e21-9a2c-a912da5225db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-056a8daa-6a93-4e21-9a2c-a912da5225db">
											<gml:posList>35.672434032966365 139.73855188531462 33.518 35.672434032966365 139.73855188531462 32.79 35.67241834902801 139.7385174717913 32.79 35.67241834902801 139.7385174717913 33.518 35.672434032966365 139.73855188531462 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fca5e9ea-6073-429d-b5b7-80ed42aca37d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fca5e9ea-6073-429d-b5b7-80ed42aca37d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fca5e9ea-6073-429d-b5b7-80ed42aca37d">
											<gml:posList>35.67243698566083 139.7385584987029 33.518 35.67243698566083 139.7385584987029 32.79 35.672434032966365 139.73855188531462 32.79 35.672434032966365 139.73855188531462 33.518 35.67243698566083 139.7385584987029 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5bbf87b4-a6ef-4a8d-b52c-554150353a9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bbf87b4-a6ef-4a8d-b52c-554150353a9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bbf87b4-a6ef-4a8d-b52c-554150353a9d">
											<gml:posList>35.67243698566083 139.7385584987029 33.518 35.672431643342435 139.73856208409788 33.518 35.672431643342435 139.73856208409788 36.364 35.67244986847959 139.73854984507568 36.364 35.67244986847959 139.73854984507568 32.79 35.67243698566083 139.7385584987029 32.79 35.67243698566083 139.7385584987029 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4767ce99-79ac-4977-804a-9a022765ab38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4767ce99-79ac-4977-804a-9a022765ab38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4767ce99-79ac-4977-804a-9a022765ab38">
											<gml:posList>35.672436214576095 139.73856370253597 36.364 35.672436214576095 139.73856370253597 35.978 35.67244845776027 139.73855548048107 35.978 35.67244845776027 139.73855548048107 36.364 35.672436214576095 139.73856370253597 36.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec5d8af8-96ee-41ea-9c28-c3a04f40cb65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec5d8af8-96ee-41ea-9c28-c3a04f40cb65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec5d8af8-96ee-41ea-9c28-c3a04f40cb65">
											<gml:posList>35.672482496422234 139.73867366040733 9.51 35.672482496422234 139.73867366040733 29.33 35.67247515560604 139.7386575632079 29.33 35.67247515560604 139.7386575632079 33.518 35.67245653717348 139.738616712977 33.518 35.67245653717348 139.738616712977 36.364 35.672431643342435 139.73856208409788 36.364 35.672431643342435 139.73856208409788 33.518 35.672409991013915 139.73851456538975 33.518 35.672409991013915 139.73851456538975 9.51 35.672482496422234 139.73867366040733 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f234854a-9209-4ede-8cd5-437525857aa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f234854a-9209-4ede-8cd5-437525857aa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f234854a-9209-4ede-8cd5-437525857aa4">
											<gml:posList>35.67244986847959 139.73854984507568 36.364 35.67247296035445 139.73860547028184 36.364 35.67247296035445 139.73860547028184 32.79 35.67244986847959 139.73854984507568 32.79 35.67244986847959 139.73854984507568 36.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef099d01-7b76-43e3-a5b7-06fd1da9186b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef099d01-7b76-43e3-a5b7-06fd1da9186b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef099d01-7b76-43e3-a5b7-06fd1da9186b">
											<gml:posList>35.672468506264956 139.73860380751606 36.364 35.672468506264956 139.73860380751606 35.978 35.672457821738355 139.73861112190735 35.978 35.672457821738355 139.73861112190735 36.364 35.672468506264956 139.73860380751606 36.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b209d0e-5072-4e04-95dd-a00fa424f556">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b209d0e-5072-4e04-95dd-a00fa424f556">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b209d0e-5072-4e04-95dd-a00fa424f556">
											<gml:posList>35.67245653717348 139.738616712977 36.364 35.67245653717348 139.738616712977 33.518 35.67246190646513 139.73861303918028 33.518 35.67246190646513 139.73861303918028 32.79 35.67247296035445 139.73860547028184 32.79 35.67247296035445 139.73860547028184 36.364 35.67245653717348 139.738616712977 36.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-def5d575-67ca-44d8-ad86-acce06032a96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-def5d575-67ca-44d8-ad86-acce06032a96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-def5d575-67ca-44d8-ad86-acce06032a96">
											<gml:posList>35.67247766261618 139.7386476183539 33.518 35.67247766261618 139.7386476183539 32.79 35.67246190646513 139.73861303918028 32.79 35.67246190646513 139.73861303918028 33.518 35.67247766261618 139.7386476183539 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3115823d-5189-44ae-9459-762d7cead986">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3115823d-5189-44ae-9459-762d7cead986">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3115823d-5189-44ae-9459-762d7cead986">
											<gml:posList>35.672538727784755 139.73842648254154 9.51 35.672409991013915 139.73851456538975 9.51 35.672409991013915 139.73851456538975 33.518 35.672538727784755 139.73842648254154 33.518 35.672538727784755 139.73842648254154 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1b8c771-b440-44bc-b0b3-8d203fe93ab7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1b8c771-b440-44bc-b0b3-8d203fe93ab7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1b8c771-b440-44bc-b0b3-8d203fe93ab7">
											<gml:posList>35.67241834902801 139.7385174717913 33.518 35.67241834902801 139.7385174717913 32.79 35.672536338206335 139.73843672552803 32.79 35.672536338206335 139.73843672552803 33.518 35.67241834902801 139.7385174717913 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94d88926-c8c4-487b-9842-a066c03e57b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94d88926-c8c4-487b-9842-a066c03e57b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94d88926-c8c4-487b-9842-a066c03e57b2">
											<gml:posList>35.67250702426172 139.73862969930838 33.518 35.67250702426172 139.73862969930838 32.79 35.67247766261618 139.7386476183539 32.79 35.67247766261618 139.7386476183539 33.518 35.67250702426172 139.73862969930838 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b91db85a-3453-4b21-8edd-e315642f8383">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b91db85a-3453-4b21-8edd-e315642f8383">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b91db85a-3453-4b21-8edd-e315642f8383">
											<gml:posList>35.67251491410686 139.73863330221133 33.518 35.67247515560604 139.7386575632079 33.518 35.67247515560604 139.7386575632079 29.33 35.67251491410686 139.73863330221133 29.33 35.67251491410686 139.73863330221133 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b57ce4b-6330-435e-930d-0a768888ac2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b57ce4b-6330-435e-930d-0a768888ac2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b57ce4b-6330-435e-930d-0a768888ac2e">
											<gml:posList>35.67250475659645 139.73862306300936 33.518 35.67250475659645 139.73862306300936 32.79 35.67250702426172 139.73862969930838 32.79 35.67250702426172 139.73862969930838 33.518 35.67250475659645 139.73862306300936 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc2af34e-0c0b-479a-8b2f-6a4ad60c4bff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc2af34e-0c0b-479a-8b2f-6a4ad60c4bff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc2af34e-0c0b-479a-8b2f-6a4ad60c4bff">
											<gml:posList>35.67251261933982 139.7386265886177 33.518 35.67251491410686 139.73863330221133 33.518 35.67251491410686 139.73863330221133 29.33 35.67251261933982 139.7386265886177 29.33 35.67251261933982 139.7386265886177 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b17376b-c95a-442a-8d39-0d21f406645e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b17376b-c95a-442a-8d39-0d21f406645e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b17376b-c95a-442a-8d39-0d21f406645e">
											<gml:posList>35.672482496422234 139.73867366040733 9.51 35.672609773928855 139.73858665097606 9.51 35.672609773928855 139.73858665097606 29.33 35.672482496422234 139.73867366040733 29.33 35.672482496422234 139.73867366040733 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbfb6552-7520-4a19-bc1d-ef7260f8faf0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbfb6552-7520-4a19-bc1d-ef7260f8faf0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbfb6552-7520-4a19-bc1d-ef7260f8faf0">
											<gml:posList>35.672536338206335 139.73843672552803 33.518 35.672536338206335 139.73843672552803 32.79 35.67256149403987 139.73849205006275 32.79 35.67256149403987 139.73849205006275 33.518 35.672536338206335 139.73843672552803 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5c98190-5b28-46c6-a77a-2ac14663e093">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5c98190-5b28-46c6-a77a-2ac14663e093">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5c98190-5b28-46c6-a77a-2ac14663e093">
											<gml:posList>35.67259445283017 139.73856658642868 33.518 35.67259445283017 139.73856658642868 32.79 35.67250475659645 139.73862306300936 32.79 35.67250475659645 139.73862306300936 33.518 35.67259445283017 139.73856658642868 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6b9c87b-e131-4e64-966f-a7fcb630796b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6b9c87b-e131-4e64-966f-a7fcb630796b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6b9c87b-e131-4e64-966f-a7fcb630796b">
											<gml:posList>35.67256789266658 139.73849062853347 9.51 35.672538727784755 139.73842648254154 9.51 35.672538727784755 139.73842648254154 33.518 35.67256789266658 139.73849062853347 33.518 35.67256789266658 139.73849062853347 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2c7de45-40d9-4df5-8399-a3e1a0937e5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2c7de45-40d9-4df5-8399-a3e1a0937e5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2c7de45-40d9-4df5-8399-a3e1a0937e5d">
											<gml:posList>35.67260273000617 139.73856985747454 33.518 35.67251261933982 139.7386265886177 33.518 35.67251261933982 139.7386265886177 29.33 35.67260273000617 139.73856985747454 29.33 35.67260273000617 139.73856985747454 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28e6516e-8dbb-4997-9d77-f8ef60d99f76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28e6516e-8dbb-4997-9d77-f8ef60d99f76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28e6516e-8dbb-4997-9d77-f8ef60d99f76">
											<gml:posList>35.67256149403987 139.73849205006275 33.518 35.67256149403987 139.73849205006275 32.79 35.672564491780065 139.73849863026632 32.79 35.672564491780065 139.73849863026632 33.518 35.67256149403987 139.73849205006275 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9b6e8c5-9a3e-4012-9e1f-c63986843d69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9b6e8c5-9a3e-4012-9e1f-c63986843d69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9b6e8c5-9a3e-4012-9e1f-c63986843d69">
											<gml:posList>35.672564491780065 139.73849863026632 33.518 35.672564491780065 139.73849863026632 32.79 35.67256692417913 139.73849697040495 32.79 35.67256692417913 139.73849697040495 33.518 35.672564491780065 139.73849863026632 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba1680cb-df7a-46d9-abfb-857785681550">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba1680cb-df7a-46d9-abfb-857785681550">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba1680cb-df7a-46d9-abfb-857785681550">
											<gml:posList>35.67258261720635 139.7385314723497 32.79 35.67258261720635 139.7385314723497 38.474 35.67256692417913 139.73849697040495 38.474 35.67256692417913 139.73849697040495 33.518 35.67256692417913 139.73849697040495 32.79 35.67258261720635 139.7385314723497 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1343b08e-926b-4bcc-9fad-1762dd6a455c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1343b08e-926b-4bcc-9fad-1762dd6a455c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1343b08e-926b-4bcc-9fad-1762dd6a455c">
											<gml:posList>35.672572527502865 139.73853867559214 38.474 35.67258261720635 139.7385314723497 38.474 35.67258261720635 139.7385314723497 32.79 35.672572527502865 139.73853867559214 32.79 35.672572527502865 139.73853867559214 38.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4da54677-c36b-477b-9152-57457461f723">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4da54677-c36b-477b-9152-57457461f723">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4da54677-c36b-477b-9152-57457461f723">
											<gml:posList>35.672572527502865 139.73853867559214 32.79 35.672582732917704 139.7385639601538 32.79 35.672582732917704 139.7385639601538 38.474 35.672572527502865 139.73853867559214 38.474 35.672572527502865 139.73853867559214 32.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f19d728b-4b39-407d-a5ed-c1216b59876d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f19d728b-4b39-407d-a5ed-c1216b59876d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f19d728b-4b39-407d-a5ed-c1216b59876d">
											<gml:posList>35.67258834275741 139.73847657520528 9.51 35.67256789266658 139.73849062853347 9.51 35.67256789266658 139.73849062853347 33.518 35.67258834275741 139.73847657520528 33.518 35.67258834275741 139.73847657520528 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3689b9de-dfd2-430d-8188-3e61bcc3d1a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3689b9de-dfd2-430d-8188-3e61bcc3d1a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3689b9de-dfd2-430d-8188-3e61bcc3d1a9">
											<gml:posList>35.67256692417913 139.73849697040495 38.474 35.672590347283816 139.73848099145908 38.474 35.672590347283816 139.73848099145908 33.518 35.67256692417913 139.73849697040495 33.518 35.67256692417913 139.73849697040495 38.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2fd4152-1a9a-4e43-9133-616dbb119b92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2fd4152-1a9a-4e43-9133-616dbb119b92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2fd4152-1a9a-4e43-9133-616dbb119b92">
											<gml:posList>35.6725718470269 139.73849868784512 38.474 35.6725718470269 139.73849868784512 37.904 35.672588945886034 139.73848701349425 37.904 35.672588945886034 139.73848701349425 38.474 35.6725718470269 139.73849868784512 38.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-adc7cc37-b484-49bc-9038-b3e91ebf3660">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adc7cc37-b484-49bc-9038-b3e91ebf3660">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adc7cc37-b484-49bc-9038-b3e91ebf3660">
											<gml:posList>35.67258429647933 139.7385578274631 38.474 35.67258429647933 139.7385578274631 37.904 35.67257726107933 139.7385404153519 37.904 35.67257726107933 139.7385404153519 38.474 35.67258429647933 139.7385578274631 38.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31221882-0c7b-4a17-8d83-0c038ffcc141">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31221882-0c7b-4a17-8d83-0c038ffcc141">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31221882-0c7b-4a17-8d83-0c038ffcc141">
											<gml:posList>35.6725908138937 139.73855844941258 33.518 35.6725908138937 139.73855844941258 32.79 35.672593793594125 139.73856501859584 32.79 35.672593793594125 139.73856501859584 33.518 35.6725908138937 139.73855844941258 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3b06534-5683-439d-bf77-592a99987928">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3b06534-5683-439d-bf77-592a99987928">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3b06534-5683-439d-bf77-592a99987928">
											<gml:posList>35.672593793594125 139.73856501859584 33.518 35.672593793594125 139.73856501859584 32.79 35.67259445283017 139.73856658642868 32.79 35.67259445283017 139.73856658642868 33.518 35.672593793594125 139.73856501859584 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91db2b03-f54d-4b23-8022-686f8da0ba35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91db2b03-f54d-4b23-8022-686f8da0ba35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91db2b03-f54d-4b23-8022-686f8da0ba35">
											<gml:posList>35.67261241320891 139.73853862843103 38.474 35.67261241320891 139.73853862843103 37.904 35.67258429647933 139.7385578274631 37.904 35.67258429647933 139.7385578274631 38.474 35.67261241320891 139.73853862843103 38.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6c9dd27-5684-40a4-8993-08acf6b5f05d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6c9dd27-5684-40a4-8993-08acf6b5f05d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6c9dd27-5684-40a4-8993-08acf6b5f05d">
											<gml:posList>35.672617327051036 139.73854035693194 38.474 35.672582732917704 139.7385639601538 38.474 35.672582732917704 139.7385639601538 32.79 35.6725908138937 139.73855844941258 32.79 35.6725908138937 139.73855844941258 33.518 35.672617327051036 139.73854035693194 33.518 35.672617327051036 139.73854035693194 38.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c3c05bf-5a5a-4ccc-9f4b-a1e8910bc3cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c3c05bf-5a5a-4ccc-9f4b-a1e8910bc3cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c3c05bf-5a5a-4ccc-9f4b-a1e8910bc3cd">
											<gml:posList>35.672588945886034 139.73848701349425 38.474 35.672588945886034 139.73848701349425 37.904 35.67261241320891 139.73853862843103 37.904 35.67261241320891 139.73853862843103 38.474 35.672588945886034 139.73848701349425 38.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28bd3dcb-fd45-4700-8ac0-1edc112a8842">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28bd3dcb-fd45-4700-8ac0-1edc112a8842">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28bd3dcb-fd45-4700-8ac0-1edc112a8842">
											<gml:posList>35.67259764571875 139.73855771226297 9.51 35.67259764571875 139.73855771226297 33.518 35.67260273000617 139.73856985747454 33.518 35.67260273000617 139.73856985747454 29.33 35.672609773928855 139.73858665097606 29.33 35.672609773928855 139.73858665097606 9.51 35.67259764571875 139.73855771226297 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d0c829b-49f9-45e1-a3eb-0025992a7cc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d0c829b-49f9-45e1-a3eb-0025992a7cc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d0c829b-49f9-45e1-a3eb-0025992a7cc2">
											<gml:posList>35.672617327051036 139.73854035693194 33.518 35.67261907875617 139.73854422115943 33.518 35.67261907875617 139.73854422115943 9.51 35.67258834275741 139.73847657520528 9.51 35.67258834275741 139.73847657520528 33.518 35.672590347283816 139.73848099145908 33.518 35.672590347283816 139.73848099145908 38.474 35.672617327051036 139.73854035693194 38.474 35.672617327051036 139.73854035693194 33.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6d032ca-b7a6-42dc-9a6d-3594470900ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6d032ca-b7a6-42dc-9a6d-3594470900ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6d032ca-b7a6-42dc-9a6d-3594470900ab">
											<gml:posList>35.67259764571875 139.73855771226297 9.51 35.67261907875617 139.73854422115943 9.51 35.67261907875617 139.73854422115943 33.518 35.67259764571875 139.73855771226297 33.518 35.67259764571875 139.73855771226297 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9245</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">295.3896</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>