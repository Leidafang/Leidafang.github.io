<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b0a322b7-52ea-4e63-8192-7caed6b816d5">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">45.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>15</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66669618769116 139.7380707880242 0 35.66667932039168 139.73804471800224 0 35.66664167490665 139.73808507970287 0 35.66671721018009 139.73819931354174 0 35.666776202783176 139.73813937551995 0 35.66681590589171 139.73807934986584 0 35.66681173370967 139.7380466593498 0 35.666777714538696 139.7379994239091 0 35.66676067334671 139.73799281671265 0 35.6667072218498 139.73802692327553 0 35.66672113642004 139.73804636935816 0 35.66669618769116 139.7380707880242 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66669618769116 139.7380707880242 12.44 35.66672113642004 139.73804636935816 12.44 35.6667072218498 139.73802692327553 12.44 35.66676067334671 139.73799281671265 12.44 35.666777714538696 139.7379994239091 12.44 35.66681173370967 139.7380466593498 12.44 35.66681590589171 139.73807934986584 12.44 35.666776202783176 139.73813937551995 12.44 35.66671721018009 139.73819931354174 12.44 35.66664167490665 139.73808507970287 12.44 35.66667932039168 139.73804471800224 12.44 35.66669618769116 139.7380707880242 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66669618769116 139.7380707880242 12.44 35.66667932039168 139.73804471800224 12.44 35.66667932039168 139.73804471800224 57.82 35.66669618769116 139.7380707880242 57.82 35.66669618769116 139.7380707880242 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66667932039168 139.73804471800224 12.44 35.66664167490665 139.73808507970287 12.44 35.66664167490665 139.73808507970287 57.82 35.66667932039168 139.73804471800224 57.82 35.66667932039168 139.73804471800224 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66664167490665 139.73808507970287 12.44 35.66671721018009 139.73819931354174 12.44 35.66671721018009 139.73819931354174 57.82 35.66664167490665 139.73808507970287 57.82 35.66664167490665 139.73808507970287 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66671721018009 139.73819931354174 12.44 35.666776202783176 139.73813937551995 12.44 35.666776202783176 139.73813937551995 57.82 35.66671721018009 139.73819931354174 57.82 35.66671721018009 139.73819931354174 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666776202783176 139.73813937551995 12.44 35.66681590589171 139.73807934986584 12.44 35.66681590589171 139.73807934986584 57.82 35.666776202783176 139.73813937551995 57.82 35.666776202783176 139.73813937551995 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66681590589171 139.73807934986584 12.44 35.66681173370967 139.7380466593498 12.44 35.66681173370967 139.7380466593498 57.82 35.66681590589171 139.73807934986584 57.82 35.66681590589171 139.73807934986584 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66681173370967 139.7380466593498 12.44 35.666777714538696 139.7379994239091 12.44 35.666777714538696 139.7379994239091 57.82 35.66681173370967 139.7380466593498 57.82 35.66681173370967 139.7380466593498 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666777714538696 139.7379994239091 12.44 35.66676067334671 139.73799281671265 12.44 35.66676067334671 139.73799281671265 57.82 35.666777714538696 139.7379994239091 57.82 35.666777714538696 139.7379994239091 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66676067334671 139.73799281671265 12.44 35.6667072218498 139.73802692327553 12.44 35.6667072218498 139.73802692327553 57.82 35.66676067334671 139.73799281671265 57.82 35.66676067334671 139.73799281671265 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6667072218498 139.73802692327553 12.44 35.66672113642004 139.73804636935816 12.44 35.66672113642004 139.73804636935816 57.82 35.6667072218498 139.73802692327553 57.82 35.6667072218498 139.73802692327553 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66672113642004 139.73804636935816 12.44 35.66669618769116 139.7380707880242 12.44 35.66669618769116 139.7380707880242 57.82 35.66672113642004 139.73804636935816 57.82 35.66672113642004 139.73804636935816 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66669618769116 139.7380707880242 57.82 35.66667932039168 139.73804471800224 57.82 35.66664167490665 139.73808507970287 57.82 35.66671721018009 139.73819931354174 57.82 35.666776202783176 139.73813937551995 57.82 35.66681590589171 139.73807934986584 57.82 35.66681173370967 139.7380466593498 57.82 35.666777714538696 139.7379994239091 57.82 35.66676067334671 139.73799281671265 57.82 35.6667072218498 139.73802692327553 57.82 35.66672113642004 139.73804636935816 57.82 35.66669618769116 139.7380707880242 57.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1ea5218e-58e5-4aee-bdf2-351467b09c8e"/>
							<gml:surfaceMember xlink:href="#poly-ef98f43f-93ab-415d-8e31-ac82953134e0"/>
							<gml:surfaceMember xlink:href="#poly-1523e69d-4cf8-4ef7-8c3c-7a4d23146c72"/>
							<gml:surfaceMember xlink:href="#poly-b8121346-ab7b-483f-a4fe-e9b742ab02ff"/>
							<gml:surfaceMember xlink:href="#poly-fec39713-cf12-4cd5-ba18-8f90b00e5e9d"/>
							<gml:surfaceMember xlink:href="#poly-7188b80b-7f85-4eb6-833d-44ad592dcb1f"/>
							<gml:surfaceMember xlink:href="#poly-abfbd306-eabd-4ff7-b853-30c31e28997a"/>
							<gml:surfaceMember xlink:href="#poly-dcc79f7d-96bf-4518-aec5-c8296487d9cb"/>
							<gml:surfaceMember xlink:href="#poly-21e2e69f-09d5-422f-bfbb-2aeeb1046b90"/>
							<gml:surfaceMember xlink:href="#poly-52b034e2-94cf-4e44-ba9b-776ceae9a500"/>
							<gml:surfaceMember xlink:href="#poly-235e3ece-b287-4b58-9c04-b051ac4ecf30"/>
							<gml:surfaceMember xlink:href="#poly-9d7f4d9e-001f-4374-a1aa-52cc458a18b8"/>
							<gml:surfaceMember xlink:href="#poly-6fb747c6-2923-4010-ab30-f9ae8dbaa0e4"/>
							<gml:surfaceMember xlink:href="#poly-05c44490-c5ec-48b0-8d3c-7f1b07f34bc1"/>
							<gml:surfaceMember xlink:href="#poly-05f15c2e-5228-419a-afd6-ae6fffd9e71c"/>
							<gml:surfaceMember xlink:href="#poly-1bd696bd-1b19-4351-a4ed-de77aff31219"/>
							<gml:surfaceMember xlink:href="#poly-7435f46a-71d3-4998-a14d-e818ed8737a8"/>
							<gml:surfaceMember xlink:href="#poly-635db332-d901-4e91-b57d-ca2dec119eec"/>
							<gml:surfaceMember xlink:href="#poly-aba0e132-b7cd-4a4e-ad62-675c9bc3ec3f"/>
							<gml:surfaceMember xlink:href="#poly-d5c42b7a-0b28-469d-96fe-499184370ec1"/>
							<gml:surfaceMember xlink:href="#poly-7b7f2a1f-baf2-4e22-8991-9679ba26c520"/>
							<gml:surfaceMember xlink:href="#poly-6dc6dbc5-29c2-4b01-b80a-3c8c8956edfc"/>
							<gml:surfaceMember xlink:href="#poly-5284c6f0-e8c2-44a0-a658-e8f20297637f"/>
							<gml:surfaceMember xlink:href="#poly-8133a15f-6eda-46bf-862a-0c64391a4398"/>
							<gml:surfaceMember xlink:href="#poly-aa1967eb-793f-46e3-a5dc-d66923663891"/>
							<gml:surfaceMember xlink:href="#poly-19569c6e-e176-4e1b-9828-114f90addadb"/>
							<gml:surfaceMember xlink:href="#poly-48c57599-38b3-46c9-a23d-461dfee1365b"/>
							<gml:surfaceMember xlink:href="#poly-8cbd4fc1-3072-482e-9012-d5bcb20af0f5"/>
							<gml:surfaceMember xlink:href="#poly-da9923a5-b308-4fc9-a1fe-c3f63726027c"/>
							<gml:surfaceMember xlink:href="#poly-7f08bbfb-d4db-47da-a109-1f8c592cbc79"/>
							<gml:surfaceMember xlink:href="#poly-6b7e4351-db93-4fbb-be2c-6de04d1f7024"/>
							<gml:surfaceMember xlink:href="#poly-b565f1e8-39fc-4f74-953e-d1b18622414b"/>
							<gml:surfaceMember xlink:href="#poly-74248b2f-585f-4274-a909-a15563d3357d"/>
							<gml:surfaceMember xlink:href="#poly-df527dc9-8aca-44d3-9df8-febd594aa86c"/>
							<gml:surfaceMember xlink:href="#poly-11a65de7-e01d-489f-bfa5-76a626158df4"/>
							<gml:surfaceMember xlink:href="#poly-b3821cbf-4276-405a-947f-1c9d13c563d6"/>
							<gml:surfaceMember xlink:href="#poly-65125e77-36d7-4e02-8112-d11a70c2c420"/>
							<gml:surfaceMember xlink:href="#poly-daa4db1f-f0c5-4b7c-9cbf-224efde8447b"/>
							<gml:surfaceMember xlink:href="#poly-e16e04ba-b381-4408-9fb3-ed13de58473f"/>
							<gml:surfaceMember xlink:href="#poly-70c00067-6087-41cb-ab22-b74fd11a8808"/>
							<gml:surfaceMember xlink:href="#poly-98c9f29d-eb3b-4f3c-8003-fcb5c1e2057a"/>
							<gml:surfaceMember xlink:href="#poly-3089f3be-79d6-41b6-a132-28f313adf6f2"/>
							<gml:surfaceMember xlink:href="#poly-74266825-097c-4bed-a119-b942f841abca"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b0a322b7-52ea-4e63-8192-7caed6b816d5_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8694287c-5510-40dc-8ca7-4c72eb585bac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8694287c-5510-40dc-8ca7-4c72eb585bac_0">
											<gml:posList>35.666742831503356 139.73811350178747 12.44 35.66676293427311 139.7381162062193 12.44 35.66675368435388 139.7381024983694 12.44 35.666742831503356 139.73811350178747 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e1aa85e-6d35-42ca-a6f4-05523fc92827">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e1aa85e-6d35-42ca-a6f4-05523fc92827_0">
											<gml:posList>35.666742831503356 139.73811350178747 12.44 35.666752081421365 139.7381272096368 12.44 35.66676293427311 139.7381162062193 12.44 35.666742831503356 139.73811350178747 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36186563-b491-4a48-bd25-f38185b7f308">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36186563-b491-4a48-bd25-f38185b7f308_0">
											<gml:posList>35.66675423584141 139.73804761133457 57.956 35.6667683229099 139.7380686257254 58.751 35.6667683229099 139.7380686257254 57.956 35.66675423584141 139.73804761133457 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7220ff12-ec94-4295-85bf-9d3f72ffca08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7220ff12-ec94-4295-85bf-9d3f72ffca08_0">
											<gml:posList>35.66675423584141 139.73804761133457 57.956 35.66675423584141 139.73804761133457 58.751 35.6667683229099 139.7380686257254 58.751 35.66675423584141 139.73804761133457 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9a923d7-057d-4b86-96e9-d0a493263c33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9a923d7-057d-4b86-96e9-d0a493263c33_0">
											<gml:posList>35.66673253002708 139.73806946354227 57.956 35.66675423584141 139.73804761133457 58.751 35.66675423584141 139.73804761133457 57.956 35.66673253002708 139.73806946354227 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3538dec4-a433-44ad-bc6b-52c44e6673b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3538dec4-a433-44ad-bc6b-52c44e6673b1_0">
											<gml:posList>35.66673253002708 139.73806946354227 57.956 35.66673253002708 139.73806946354227 58.751 35.66675423584141 139.73804761133457 58.751 35.66673253002708 139.73806946354227 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb30acbf-0127-4251-86c8-65ad6a5c57ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb30acbf-0127-4251-86c8-65ad6a5c57ed_0">
											<gml:posList>35.66671482658941 139.73805748888483 57.956 35.66670676541187 139.73806521944417 59.217 35.66671482658941 139.73805748888483 59.217 35.66671482658941 139.73805748888483 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8e4850e-436f-4cc9-9345-bb0cb1061e36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8e4850e-436f-4cc9-9345-bb0cb1061e36_0">
											<gml:posList>35.66671482658941 139.73805748888483 57.956 35.66670676541187 139.73806521944417 57.956 35.66670676541187 139.73806521944417 59.217 35.66671482658941 139.73805748888483 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f5afd38-1266-424f-8a64-b930a9e626b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f5afd38-1266-424f-8a64-b930a9e626b1_0">
											<gml:posList>35.66671482658941 139.73805748888483 57.956 35.66672072889057 139.73806673821474 59.217 35.66672072889057 139.73806673821474 57.956 35.66671482658941 139.73805748888483 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cc2e921-1db3-42fe-902d-e74e813b7d47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cc2e921-1db3-42fe-902d-e74e813b7d47_0">
											<gml:posList>35.66671482658941 139.73805748888483 57.956 35.66671482658941 139.73805748888483 59.217 35.66672072889057 139.73806673821474 59.217 35.66671482658941 139.73805748888483 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24b21ba0-b1df-4ee7-a6a2-9a019f181b80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24b21ba0-b1df-4ee7-a6a2-9a019f181b80_0">
											<gml:posList>35.66672072889057 139.73806673821474 59.217 35.66671482658941 139.73805748888483 59.217 35.66670676541187 139.73806521944417 59.217 35.66672072889057 139.73806673821474 59.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05cd642a-927a-485e-9828-8330ecfd978a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05cd642a-927a-485e-9828-8330ecfd978a_0">
											<gml:posList>35.666712667712446 139.73807446877373 59.217 35.66672072889057 139.73806673821474 59.217 35.66670676541187 139.73806521944417 59.217 35.666712667712446 139.73807446877373 59.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe12094b-3b60-4065-a2bb-e9e5ec3ff47f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe12094b-3b60-4065-a2bb-e9e5ec3ff47f_0">
											<gml:posList>35.66673253002708 139.73806946354227 58.751 35.6667683229099 139.7380686257254 58.751 35.66675423584141 139.73804761133457 58.751 35.66673253002708 139.73806946354227 58.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c11c3110-205b-4a88-ba18-66b5bd855b66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c11c3110-205b-4a88-ba18-66b5bd855b66_0">
											<gml:posList>35.66673253002708 139.73806946354227 58.751 35.66674661709182 139.73809047793122 58.751 35.6667683229099 139.7380686257254 58.751 35.66673253002708 139.73806946354227 58.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb125d79-d594-4c8d-a623-d0c5ced924c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb125d79-d594-4c8d-a623-d0c5ced924c7_0">
											<gml:posList>35.66670676541187 139.73806521944417 57.956 35.666712667712446 139.73807446877373 59.217 35.66670676541187 139.73806521944417 59.217 35.66670676541187 139.73806521944417 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a5763f9-9e3c-47db-bec2-e27ddbecbb50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a5763f9-9e3c-47db-bec2-e27ddbecbb50_0">
											<gml:posList>35.66670676541187 139.73806521944417 57.956 35.666712667712446 139.73807446877373 57.956 35.666712667712446 139.73807446877373 59.217 35.66670676541187 139.73806521944417 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38972165-db76-42d3-8157-c551aba4696e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38972165-db76-42d3-8157-c551aba4696e_0">
											<gml:posList>35.666712667712446 139.73807446877373 57.956 35.66672072889057 139.73806673821474 59.217 35.666712667712446 139.73807446877373 59.217 35.666712667712446 139.73807446877373 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-698c7ba7-8528-4db1-bae0-3131d63f8339">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-698c7ba7-8528-4db1-bae0-3131d63f8339_0">
											<gml:posList>35.666712667712446 139.73807446877373 57.956 35.66672072889057 139.73806673821474 57.956 35.66672072889057 139.73806673821474 59.217 35.666712667712446 139.73807446877373 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f35a3ea-f930-454e-8a98-11fa28896d9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f35a3ea-f930-454e-8a98-11fa28896d9d_0">
											<gml:posList>35.6667683229099 139.7380686257254 57.956 35.66674661709182 139.73809047793122 58.751 35.66674661709182 139.73809047793122 57.956 35.6667683229099 139.7380686257254 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4439873-4d29-45d1-87e2-d50324c51cc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4439873-4d29-45d1-87e2-d50324c51cc7_0">
											<gml:posList>35.6667683229099 139.7380686257254 57.956 35.6667683229099 139.7380686257254 58.751 35.66674661709182 139.73809047793122 58.751 35.6667683229099 139.7380686257254 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46fa90e0-29c6-4d89-b97f-5b75a574ab3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46fa90e0-29c6-4d89-b97f-5b75a574ab3f_0">
											<gml:posList>35.66674661709182 139.73809047793122 57.956 35.66673253002708 139.73806946354227 58.751 35.66673253002708 139.73806946354227 57.956 35.66674661709182 139.73809047793122 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-792642d0-c6b5-4167-8b70-3f019c716db8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-792642d0-c6b5-4167-8b70-3f019c716db8_0">
											<gml:posList>35.66674661709182 139.73809047793122 57.956 35.66674661709182 139.73809047793122 58.751 35.66673253002708 139.73806946354227 58.751 35.66674661709182 139.73809047793122 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfe0ce0c-74c2-4b02-892a-83b1ba8c0a48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfe0ce0c-74c2-4b02-892a-83b1ba8c0a48_0">
											<gml:posList>35.666696833558056 139.73808963130944 57.956 35.66668870032101 139.73809742822388 59.321 35.666696833558056 139.73808963130944 59.321 35.666696833558056 139.73808963130944 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8d1d2ca-8d27-4549-a87f-13203c26c004">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8d1d2ca-8d27-4549-a87f-13203c26c004_0">
											<gml:posList>35.666696833558056 139.73808963130944 57.956 35.66668870032101 139.73809742822388 57.956 35.66668870032101 139.73809742822388 59.321 35.666696833558056 139.73808963130944 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db432879-a1da-43d5-b331-2d90a71acc45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db432879-a1da-43d5-b331-2d90a71acc45_0">
											<gml:posList>35.66670380079569 139.73810054728358 57.956 35.666696833558056 139.73808963130944 59.321 35.66670380079569 139.73810054728358 59.321 35.66670380079569 139.73810054728358 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5b29ebc-000c-40b6-afea-c4d85ab626a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5b29ebc-000c-40b6-afea-c4d85ab626a8_0">
											<gml:posList>35.66670380079569 139.73810054728358 57.956 35.666696833558056 139.73808963130944 57.956 35.666696833558056 139.73808963130944 59.321 35.66670380079569 139.73810054728358 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fc69984-6bc2-49d2-96f8-f483614d4813">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fc69984-6bc2-49d2-96f8-f483614d4813_0">
											<gml:posList>35.66670380079569 139.73810054728358 59.321 35.666696833558056 139.73808963130944 59.321 35.66668870032101 139.73809742822388 59.321 35.66670380079569 139.73810054728358 59.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbf3e9f0-fdc6-4472-bcf2-0631e5d8f75d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbf3e9f0-fdc6-4472-bcf2-0631e5d8f75d_0">
											<gml:posList>35.66669566755795 139.73810834419757 59.321 35.66670380079569 139.73810054728358 59.321 35.66668870032101 139.73809742822388 59.321 35.66669566755795 139.73810834419757 59.321</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42ac6e29-a459-4664-a90d-83ab9100017c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42ac6e29-a459-4664-a90d-83ab9100017c_0">
											<gml:posList>35.66668870032101 139.73809742822388 57.956 35.66669566755795 139.73810834419757 59.321 35.66668870032101 139.73809742822388 59.321 35.66668870032101 139.73809742822388 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b84a7419-aec9-4a45-82a7-54e3d54d1523">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b84a7419-aec9-4a45-82a7-54e3d54d1523_0">
											<gml:posList>35.66668870032101 139.73809742822388 57.956 35.66669566755795 139.73810834419757 57.956 35.66669566755795 139.73810834419757 59.321 35.66668870032101 139.73809742822388 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e40d4ed-9250-4a9d-8523-51745bc3d9da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e40d4ed-9250-4a9d-8523-51745bc3d9da_0">
											<gml:posList>35.66670380079569 139.73810054728358 57.956 35.66669566755795 139.73810834419757 59.321 35.66669566755795 139.73810834419757 57.956 35.66670380079569 139.73810054728358 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a14f667-8c3c-40b6-a36d-482f2ca9f764">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a14f667-8c3c-40b6-a36d-482f2ca9f764_0">
											<gml:posList>35.66670380079569 139.73810054728358 57.956 35.66670380079569 139.73810054728358 59.321 35.66669566755795 139.73810834419757 59.321 35.66670380079569 139.73810054728358 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73adff81-4d21-444b-bcbc-2415d3c91b57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73adff81-4d21-444b-bcbc-2415d3c91b57_0">
											<gml:posList>35.66675368435388 139.7381024983694 57.956 35.666742831503356 139.73811350178747 59.077 35.66675368435388 139.7381024983694 59.077 35.66675368435388 139.7381024983694 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ed4c9f0-76a7-4b31-a41b-f2cfcf0ef1dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ed4c9f0-76a7-4b31-a41b-f2cfcf0ef1dd_0">
											<gml:posList>35.66675368435388 139.7381024983694 57.956 35.666742831503356 139.73811350178747 57.956 35.666742831503356 139.73811350178747 59.077 35.66675368435388 139.7381024983694 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbef8f0f-6dc0-45b9-b403-f58a462d4539">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbef8f0f-6dc0-45b9-b403-f58a462d4539_0">
											<gml:posList>35.66675368435388 139.7381024983694 57.956 35.66676293427311 139.7381162062193 59.077 35.66676293427311 139.7381162062193 57.956 35.66675368435388 139.7381024983694 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1e4a67d-ab18-4c7e-84a2-fb7646f5b5be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1e4a67d-ab18-4c7e-84a2-fb7646f5b5be_0">
											<gml:posList>35.66675368435388 139.7381024983694 57.956 35.66675368435388 139.7381024983694 59.077 35.66676293427311 139.7381162062193 59.077 35.66675368435388 139.7381024983694 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f0dbe94-7bb4-47d6-8e13-3af2da606ca6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f0dbe94-7bb4-47d6-8e13-3af2da606ca6_0">
											<gml:posList>35.666742831503356 139.73811350178747 59.077 35.66676293427311 139.7381162062193 59.077 35.66675368435388 139.7381024983694 59.077 35.666742831503356 139.73811350178747 59.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9914dbf-4fe0-497a-b6c8-cdb7334c17d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9914dbf-4fe0-497a-b6c8-cdb7334c17d8_0">
											<gml:posList>35.666742831503356 139.73811350178747 59.077 35.666752081421365 139.7381272096368 59.077 35.66676293427311 139.7381162062193 59.077 35.666742831503356 139.73811350178747 59.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0bf9e22e-b3ea-46bf-af8c-4dd117cb9f82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0bf9e22e-b3ea-46bf-af8c-4dd117cb9f82_0">
											<gml:posList>35.666742831503356 139.73811350178747 57.956 35.666752081421365 139.7381272096368 59.077 35.666742831503356 139.73811350178747 59.077 35.666742831503356 139.73811350178747 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37a86f44-ead9-49ed-bc3e-c9dd6ddbaea0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37a86f44-ead9-49ed-bc3e-c9dd6ddbaea0_0">
											<gml:posList>35.666742831503356 139.73811350178747 57.956 35.666752081421365 139.7381272096368 57.956 35.666752081421365 139.7381272096368 59.077 35.666742831503356 139.73811350178747 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-835af5eb-2aad-4d96-91d4-b0bc0c321e87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-835af5eb-2aad-4d96-91d4-b0bc0c321e87_0">
											<gml:posList>35.66676293427311 139.7381162062193 57.956 35.666752081421365 139.7381272096368 59.077 35.666752081421365 139.7381272096368 57.956 35.66676293427311 139.7381162062193 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1012ba3-6b23-4271-8952-71ac5658b81e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1012ba3-6b23-4271-8952-71ac5658b81e_0">
											<gml:posList>35.66676293427311 139.7381162062193 57.956 35.66676293427311 139.7381162062193 59.077 35.666752081421365 139.7381272096368 59.077 35.66676293427311 139.7381162062193 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f6a5e9c-91fd-4b0b-bfce-bafa3023b087">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66668870032101 139.73809742822388 57.956 35.666696833558056 139.73808963130944 57.956 35.66670380079569 139.73810054728358 57.956 35.66668870032101 139.73809742822388 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5b9f5ef-cf68-4139-942c-15d06366363b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66669566755795 139.73810834419757 57.956 35.66668870032101 139.73809742822388 57.956 35.66670380079569 139.73810054728358 57.956 35.66669566755795 139.73810834419757 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26e2dc7f-effa-42c2-b0d9-f70205201ffc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66672072889057 139.73806673821474 57.956 35.666712667712446 139.73807446877373 57.956 35.66670676541187 139.73806521944417 57.956 35.66672072889057 139.73806673821474 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15192cf0-b47c-4041-a8d4-47de003052c2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66671482658941 139.73805748888483 57.956 35.66672072889057 139.73806673821474 57.956 35.66670676541187 139.73806521944417 57.956 35.66671482658941 139.73805748888483 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b4d04c5-4b62-4aa4-90ec-0dce6ec9a8dc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66673253002708 139.73806946354227 57.956 35.6667683229099 139.7380686257254 57.956 35.66674661709182 139.73809047793122 57.956 35.66673253002708 139.73806946354227 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c358ef24-3716-465f-9c9f-1ca0d19898b5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66673253002708 139.73806946354227 57.956 35.66675423584141 139.73804761133457 57.956 35.6667683229099 139.7380686257254 57.956 35.66673253002708 139.73806946354227 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-083906b0-898d-4a44-b3d0-87c63961e062">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666742831503356 139.73811350178747 12.43 35.66676293427311 139.7381162062193 12.43 35.666752081421365 139.7381272096368 12.43 35.666742831503356 139.73811350178747 12.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf29d316-f807-40eb-868e-f4c9987c3d9e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666742831503356 139.73811350178747 12.43 35.66675368435388 139.7381024983694 12.43 35.66676293427311 139.7381162062193 12.43 35.666742831503356 139.73811350178747 12.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee594248-04f0-493e-93fd-806294f881c1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666742831503356 139.73811350178747 57.956 35.66676293427311 139.7381162062193 57.956 35.666752081421365 139.7381272096368 57.956 35.666742831503356 139.73811350178747 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9ec0304-ad54-46c4-881e-e0ee25b94055">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666742831503356 139.73811350178747 57.956 35.66675368435388 139.7381024983694 57.956 35.66676293427311 139.7381162062193 57.956 35.666742831503356 139.73811350178747 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b0a322b7-52ea-4e63-8192-7caed6b816d5_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27aacb72-f478-4f37-82b6-e667a1bc9dc5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666696187691144 139.73807078802417 12.45 35.66667932039167 139.73804471800224 12.45 35.666707221849784 139.73802692327553 12.45 35.66672113642001 139.73804636935816 12.45 35.666696187691144 139.73807078802417 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7721949c-7b27-41e1-8914-c8d45eb19ce2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7721949c-7b27-41e1-8914-c8d45eb19ce2_0">
											<gml:posList>35.666707221849784 139.73802692327553 12.45 35.66667932039167 139.73804471800224 12.45 35.66667932039167 139.73804471800224 58.091 35.666707221849784 139.73802692327553 58.091 35.666707221849784 139.73802692327553 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e820dc30-b51b-4fa2-ae25-fb983e32f452">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e820dc30-b51b-4fa2-ae25-fb983e32f452_0">
											<gml:posList>35.66672113642001 139.73804636935816 58.091 35.66672113642001 139.73804636935816 12.45 35.666707221849784 139.73802692327553 12.45 35.666707221849784 139.73802692327553 58.091 35.66672113642001 139.73804636935816 58.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4987f438-2846-4cb4-acc7-d0a453fcf13f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4987f438-2846-4cb4-acc7-d0a453fcf13f_0">
											<gml:posList>35.666707221849784 139.73802692327553 58.091 35.66667932039167 139.73804471800224 58.091 35.666696187691144 139.73807078802417 58.091 35.66672113642001 139.73804636935816 58.091 35.666707221849784 139.73802692327553 58.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfbca061-1a07-4ef0-825b-5d9d4d089ca3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfbca061-1a07-4ef0-825b-5d9d4d089ca3_0">
											<gml:posList>35.666696187691144 139.73807078802417 12.45 35.666696187691144 139.73807078802417 58.091 35.66667932039167 139.73804471800224 58.091 35.66667932039167 139.73804471800224 12.45 35.666696187691144 139.73807078802417 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc56e793-b273-4582-a9c2-dd7c3c75ab3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc56e793-b273-4582-a9c2-dd7c3c75ab3d_0">
											<gml:posList>35.66672113642001 139.73804636935816 58.091 35.666696187691144 139.73807078802417 58.091 35.666696187691144 139.73807078802417 12.45 35.66672113642001 139.73804636935816 12.45 35.66672113642001 139.73804636935816 58.091</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1ea5218e-58e5-4aee-bdf2-351467b09c8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ea5218e-58e5-4aee-bdf2-351467b09c8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ea5218e-58e5-4aee-bdf2-351467b09c8e">
											<gml:posList>35.66672113642001 139.73804636935816 12.44 35.666707221849784 139.73802692327553 12.44 35.666760673346694 139.73799281671262 12.44 35.666777714538696 139.73799942390906 12.44 35.66681173370969 139.73804665934978 12.44 35.66681590589171 139.7380793498658 12.44 35.66677620278318 139.73813937551992 12.44 35.666717210180074 139.73819931354174 12.44 35.66664167490663 139.73808507970287 12.44 35.66667932039167 139.73804471800224 12.44 35.666696187691144 139.73807078802417 12.44 35.66672113642001 139.73804636935816 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef98f43f-93ab-415d-8e31-ac82953134e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef98f43f-93ab-415d-8e31-ac82953134e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef98f43f-93ab-415d-8e31-ac82953134e0">
											<gml:posList>35.666777714538696 139.73799942390906 58.926 35.666760673346694 139.73799281671262 58.926 35.66676095592927 139.7379968038962 58.926 35.666775995461435 139.7380026402698 58.926 35.666777714538696 139.73799942390906 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1523e69d-4cf8-4ef7-8c3c-7a4d23146c72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1523e69d-4cf8-4ef7-8c3c-7a4d23146c72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1523e69d-4cf8-4ef7-8c3c-7a4d23146c72">
											<gml:posList>35.666760673346694 139.73799281671262 58.926 35.666707221849784 139.73802692327553 58.926 35.66671201803582 139.73802803319626 58.926 35.66672765797226 139.73801804029023 58.926 35.66673029766547 139.7380163581976 58.926 35.66676095592927 139.7379968038962 58.926 35.666760673346694 139.73799281671262 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8121346-ab7b-483f-a4fe-e9b742ab02ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8121346-ab7b-483f-a4fe-e9b742ab02ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8121346-ab7b-483f-a4fe-e9b742ab02ff">
											<gml:posList>35.66673029766547 139.7380163581976 58.926 35.66672765797226 139.73801804029023 58.926 35.66673716732354 139.73802925147643 58.926 35.66674162030601 139.7380295002365 58.926 35.66673029766547 139.7380163581976 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fec39713-cf12-4cd5-ba18-8f90b00e5e9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fec39713-cf12-4cd5-ba18-8f90b00e5e9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fec39713-cf12-4cd5-ba18-8f90b00e5e9d">
											<gml:posList>35.666777714538696 139.73799942390906 58.926 35.666775995461435 139.7380026402698 58.926 35.666808895696605 139.73804831958722 58.926 35.66681173370969 139.73804665934978 58.926 35.666777714538696 139.73799942390906 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7188b80b-7f85-4eb6-833d-44ad592dcb1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7188b80b-7f85-4eb6-833d-44ad592dcb1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7188b80b-7f85-4eb6-833d-44ad592dcb1f">
											<gml:posList>35.66672765797226 139.73801804029023 56.386 35.66671201803582 139.73802803319626 56.386 35.666723442063784 139.7380440028267 56.386 35.66673716732354 139.73802925147643 56.386 35.66672765797226 139.73801804029023 56.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-abfbd306-eabd-4ff7-b853-30c31e28997a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abfbd306-eabd-4ff7-b853-30c31e28997a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abfbd306-eabd-4ff7-b853-30c31e28997a">
											<gml:posList>35.666707221849784 139.73802692327553 58.926 35.66672113642001 139.73804636935816 58.926 35.666725481421274 139.7380468502083 58.926 35.666723442063784 139.7380440028267 58.926 35.66671201803582 139.73802803319626 58.926 35.666707221849784 139.73802692327553 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dcc79f7d-96bf-4518-aec5-c8296487d9cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcc79f7d-96bf-4518-aec5-c8296487d9cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcc79f7d-96bf-4518-aec5-c8296487d9cb">
											<gml:posList>35.66673716732354 139.73802925147643 58.926 35.666723442063784 139.7380440028267 58.926 35.666725481421274 139.7380468502083 58.926 35.66674162030601 139.7380295002365 58.926 35.66673716732354 139.73802925147643 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21e2e69f-09d5-422f-bfbb-2aeeb1046b90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21e2e69f-09d5-422f-bfbb-2aeeb1046b90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21e2e69f-09d5-422f-bfbb-2aeeb1046b90">
											<gml:posList>35.666696187691144 139.73807078802417 58.926 35.66667932039167 139.73804471800224 58.926 35.66667893702299 139.7380500535547 58.926 35.66669571407044 139.7380759800901 58.926 35.666696187691144 139.73807078802417 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-52b034e2-94cf-4e44-ba9b-776ceae9a500">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52b034e2-94cf-4e44-ba9b-776ceae9a500">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52b034e2-94cf-4e44-ba9b-776ceae9a500">
											<gml:posList>35.666696187691144 139.73807078802417 58.926 35.66669571407044 139.7380759800901 58.926 35.666725481421274 139.7380468502083 58.926 35.66672113642001 139.73804636935816 58.926 35.666696187691144 139.73807078802417 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-235e3ece-b287-4b58-9c04-b051ac4ecf30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-235e3ece-b287-4b58-9c04-b051ac4ecf30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-235e3ece-b287-4b58-9c04-b051ac4ecf30">
											<gml:posList>35.66681173370969 139.73804665934978 58.926 35.666808895696605 139.73804831958722 58.926 35.66681272321586 139.73807830429854 58.926 35.66681590589171 139.7380793498658 58.926 35.66681173370969 139.73804665934978 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d7f4d9e-001f-4374-a1aa-52cc458a18b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d7f4d9e-001f-4374-a1aa-52cc458a18b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d7f4d9e-001f-4374-a1aa-52cc458a18b8">
											<gml:posList>35.66664167490663 139.73808507970287 58.926 35.66664584861202 139.73808551657513 58.926 35.66667893702299 139.7380500535547 58.926 35.66667932039167 139.73804471800224 58.926 35.66664167490663 139.73808507970287 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6fb747c6-2923-4010-ab30-f9ae8dbaa0e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fb747c6-2923-4010-ab30-f9ae8dbaa0e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fb747c6-2923-4010-ab30-f9ae8dbaa0e4">
											<gml:posList>35.66669571407044 139.7380759800901 57.956 35.66667893702299 139.7380500535547 57.956 35.66664584861202 139.73808551657513 57.956 35.66671764772499 139.73819408838068 57.956 35.666774064460256 139.7381367602127 57.956 35.66681272321586 139.73807830429854 57.956 35.666808895696605 139.73804831958722 57.956 35.666775995461435 139.7380026402698 57.956 35.66676095592927 139.7379968038962 57.956 35.66673029766547 139.7380163581976 57.956 35.66674162030601 139.7380295002365 57.956 35.666725481421274 139.7380468502083 57.956 35.66669571407044 139.7380759800901 57.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05c44490-c5ec-48b0-8d3c-7f1b07f34bc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05c44490-c5ec-48b0-8d3c-7f1b07f34bc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05c44490-c5ec-48b0-8d3c-7f1b07f34bc1">
											<gml:posList>35.66677620278318 139.73813937551992 58.926 35.66681590589171 139.7380793498658 58.926 35.66681272321586 139.73807830429854 58.926 35.666774064460256 139.7381367602127 58.926 35.66677620278318 139.73813937551992 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05f15c2e-5228-419a-afd6-ae6fffd9e71c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05f15c2e-5228-419a-afd6-ae6fffd9e71c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05f15c2e-5228-419a-afd6-ae6fffd9e71c">
											<gml:posList>35.666717210180074 139.73819931354174 58.926 35.66671764772499 139.73819408838068 58.926 35.66664584861202 139.73808551657513 58.926 35.66664167490663 139.73808507970287 58.926 35.666717210180074 139.73819931354174 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1bd696bd-1b19-4351-a4ed-de77aff31219">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bd696bd-1b19-4351-a4ed-de77aff31219">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bd696bd-1b19-4351-a4ed-de77aff31219">
											<gml:posList>35.66677620278318 139.73813937551992 58.926 35.666774064460256 139.7381367602127 58.926 35.66671764772499 139.73819408838068 58.926 35.666717210180074 139.73819931354174 58.926 35.66677620278318 139.73813937551992 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7435f46a-71d3-4998-a14d-e818ed8737a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7435f46a-71d3-4998-a14d-e818ed8737a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7435f46a-71d3-4998-a14d-e818ed8737a8">
											<gml:posList>35.66673716732354 139.73802925147643 58.926 35.66673716732354 139.73802925147643 56.386 35.666723442063784 139.7380440028267 56.386 35.666723442063784 139.7380440028267 58.926 35.66673716732354 139.73802925147643 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-635db332-d901-4e91-b57d-ca2dec119eec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-635db332-d901-4e91-b57d-ca2dec119eec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-635db332-d901-4e91-b57d-ca2dec119eec">
											<gml:posList>35.666777714538696 139.73799942390906 12.44 35.666760673346694 139.73799281671262 12.44 35.666760673346694 139.73799281671262 58.926 35.666777714538696 139.73799942390906 58.926 35.666777714538696 139.73799942390906 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aba0e132-b7cd-4a4e-ad62-675c9bc3ec3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aba0e132-b7cd-4a4e-ad62-675c9bc3ec3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aba0e132-b7cd-4a4e-ad62-675c9bc3ec3f">
											<gml:posList>35.66676095592927 139.7379968038962 58.926 35.66676095592927 139.7379968038962 57.956 35.666775995461435 139.7380026402698 57.956 35.666775995461435 139.7380026402698 58.926 35.66676095592927 139.7379968038962 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5c42b7a-0b28-469d-96fe-499184370ec1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5c42b7a-0b28-469d-96fe-499184370ec1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5c42b7a-0b28-469d-96fe-499184370ec1">
											<gml:posList>35.66673029766547 139.7380163581976 58.926 35.66673029766547 139.7380163581976 57.956 35.66676095592927 139.7379968038962 57.956 35.66676095592927 139.7379968038962 58.926 35.66673029766547 139.7380163581976 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b7f2a1f-baf2-4e22-8991-9679ba26c520">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b7f2a1f-baf2-4e22-8991-9679ba26c520">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b7f2a1f-baf2-4e22-8991-9679ba26c520">
											<gml:posList>35.666760673346694 139.73799281671262 12.44 35.666707221849784 139.73802692327553 12.44 35.666707221849784 139.73802692327553 58.926 35.666760673346694 139.73799281671262 58.926 35.666760673346694 139.73799281671262 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6dc6dbc5-29c2-4b01-b80a-3c8c8956edfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dc6dbc5-29c2-4b01-b80a-3c8c8956edfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dc6dbc5-29c2-4b01-b80a-3c8c8956edfc">
											<gml:posList>35.66674162030601 139.7380295002365 58.926 35.66674162030601 139.7380295002365 57.956 35.66673029766547 139.7380163581976 57.956 35.66673029766547 139.7380163581976 58.926 35.66674162030601 139.7380295002365 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5284c6f0-e8c2-44a0-a658-e8f20297637f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5284c6f0-e8c2-44a0-a658-e8f20297637f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5284c6f0-e8c2-44a0-a658-e8f20297637f">
											<gml:posList>35.66671201803582 139.73802803319626 58.926 35.66671201803582 139.73802803319626 56.386 35.66672765797226 139.73801804029023 56.386 35.66672765797226 139.73801804029023 58.926 35.66671201803582 139.73802803319626 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8133a15f-6eda-46bf-862a-0c64391a4398">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8133a15f-6eda-46bf-862a-0c64391a4398">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8133a15f-6eda-46bf-862a-0c64391a4398">
											<gml:posList>35.66681173370969 139.73804665934978 12.44 35.666777714538696 139.73799942390906 12.44 35.666777714538696 139.73799942390906 58.926 35.66681173370969 139.73804665934978 58.926 35.66681173370969 139.73804665934978 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa1967eb-793f-46e3-a5dc-d66923663891">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa1967eb-793f-46e3-a5dc-d66923663891">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa1967eb-793f-46e3-a5dc-d66923663891">
											<gml:posList>35.66672765797226 139.73801804029023 58.926 35.66672765797226 139.73801804029023 56.386 35.66673716732354 139.73802925147643 56.386 35.66673716732354 139.73802925147643 58.926 35.66672765797226 139.73801804029023 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19569c6e-e176-4e1b-9828-114f90addadb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19569c6e-e176-4e1b-9828-114f90addadb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19569c6e-e176-4e1b-9828-114f90addadb">
											<gml:posList>35.666775995461435 139.7380026402698 58.926 35.666775995461435 139.7380026402698 57.956 35.666808895696605 139.73804831958722 57.956 35.666808895696605 139.73804831958722 58.926 35.666775995461435 139.7380026402698 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48c57599-38b3-46c9-a23d-461dfee1365b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48c57599-38b3-46c9-a23d-461dfee1365b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48c57599-38b3-46c9-a23d-461dfee1365b">
											<gml:posList>35.666723442063784 139.7380440028267 58.926 35.666723442063784 139.7380440028267 56.386 35.66671201803582 139.73802803319626 56.386 35.66671201803582 139.73802803319626 58.926 35.666723442063784 139.7380440028267 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cbd4fc1-3072-482e-9012-d5bcb20af0f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cbd4fc1-3072-482e-9012-d5bcb20af0f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cbd4fc1-3072-482e-9012-d5bcb20af0f5">
											<gml:posList>35.666707221849784 139.73802692327553 12.44 35.66672113642001 139.73804636935816 12.44 35.66672113642001 139.73804636935816 58.926 35.666707221849784 139.73802692327553 58.926 35.666707221849784 139.73802692327553 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da9923a5-b308-4fc9-a1fe-c3f63726027c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da9923a5-b308-4fc9-a1fe-c3f63726027c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da9923a5-b308-4fc9-a1fe-c3f63726027c">
											<gml:posList>35.666725481421274 139.7380468502083 58.926 35.666725481421274 139.7380468502083 57.956 35.66674162030601 139.7380295002365 57.956 35.66674162030601 139.7380295002365 58.926 35.666725481421274 139.7380468502083 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f08bbfb-d4db-47da-a109-1f8c592cbc79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f08bbfb-d4db-47da-a109-1f8c592cbc79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f08bbfb-d4db-47da-a109-1f8c592cbc79">
											<gml:posList>35.666696187691144 139.73807078802417 12.44 35.66667932039167 139.73804471800224 12.44 35.66667932039167 139.73804471800224 58.926 35.666696187691144 139.73807078802417 58.926 35.666696187691144 139.73807078802417 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b7e4351-db93-4fbb-be2c-6de04d1f7024">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b7e4351-db93-4fbb-be2c-6de04d1f7024">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b7e4351-db93-4fbb-be2c-6de04d1f7024">
											<gml:posList>35.66672113642001 139.73804636935816 12.44 35.666696187691144 139.73807078802417 12.44 35.666696187691144 139.73807078802417 58.926 35.66672113642001 139.73804636935816 58.926 35.66672113642001 139.73804636935816 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b565f1e8-39fc-4f74-953e-d1b18622414b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b565f1e8-39fc-4f74-953e-d1b18622414b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b565f1e8-39fc-4f74-953e-d1b18622414b">
											<gml:posList>35.66669571407044 139.7380759800901 58.926 35.66669571407044 139.7380759800901 57.956 35.666725481421274 139.7380468502083 57.956 35.666725481421274 139.7380468502083 58.926 35.66669571407044 139.7380759800901 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74248b2f-585f-4274-a909-a15563d3357d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74248b2f-585f-4274-a909-a15563d3357d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74248b2f-585f-4274-a909-a15563d3357d">
											<gml:posList>35.66667893702299 139.7380500535547 58.926 35.66667893702299 139.7380500535547 57.956 35.66669571407044 139.7380759800901 57.956 35.66669571407044 139.7380759800901 58.926 35.66667893702299 139.7380500535547 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df527dc9-8aca-44d3-9df8-febd594aa86c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df527dc9-8aca-44d3-9df8-febd594aa86c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df527dc9-8aca-44d3-9df8-febd594aa86c">
											<gml:posList>35.66681590589171 139.7380793498658 12.44 35.66681173370969 139.73804665934978 12.44 35.66681173370969 139.73804665934978 58.926 35.66681590589171 139.7380793498658 58.926 35.66681590589171 139.7380793498658 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11a65de7-e01d-489f-bfa5-76a626158df4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11a65de7-e01d-489f-bfa5-76a626158df4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11a65de7-e01d-489f-bfa5-76a626158df4">
											<gml:posList>35.666808895696605 139.73804831958722 58.926 35.666808895696605 139.73804831958722 57.956 35.66681272321586 139.73807830429854 57.956 35.66681272321586 139.73807830429854 58.926 35.666808895696605 139.73804831958722 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3821cbf-4276-405a-947f-1c9d13c563d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3821cbf-4276-405a-947f-1c9d13c563d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3821cbf-4276-405a-947f-1c9d13c563d6">
											<gml:posList>35.66667932039167 139.73804471800224 12.44 35.66664167490663 139.73808507970287 12.44 35.66664167490663 139.73808507970287 58.926 35.66667932039167 139.73804471800224 58.926 35.66667932039167 139.73804471800224 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65125e77-36d7-4e02-8112-d11a70c2c420">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65125e77-36d7-4e02-8112-d11a70c2c420">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65125e77-36d7-4e02-8112-d11a70c2c420">
											<gml:posList>35.66664584861202 139.73808551657513 58.926 35.66664584861202 139.73808551657513 57.956 35.66667893702299 139.7380500535547 57.956 35.66667893702299 139.7380500535547 58.926 35.66664584861202 139.73808551657513 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-daa4db1f-f0c5-4b7c-9cbf-224efde8447b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-daa4db1f-f0c5-4b7c-9cbf-224efde8447b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-daa4db1f-f0c5-4b7c-9cbf-224efde8447b">
											<gml:posList>35.66681272321586 139.73807830429854 58.926 35.66681272321586 139.73807830429854 57.956 35.666774064460256 139.7381367602127 57.956 35.666774064460256 139.7381367602127 58.926 35.66681272321586 139.73807830429854 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e16e04ba-b381-4408-9fb3-ed13de58473f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e16e04ba-b381-4408-9fb3-ed13de58473f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e16e04ba-b381-4408-9fb3-ed13de58473f">
											<gml:posList>35.66677620278318 139.73813937551992 12.44 35.66681590589171 139.7380793498658 12.44 35.66681590589171 139.7380793498658 58.926 35.66677620278318 139.73813937551992 58.926 35.66677620278318 139.73813937551992 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70c00067-6087-41cb-ab22-b74fd11a8808">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70c00067-6087-41cb-ab22-b74fd11a8808">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70c00067-6087-41cb-ab22-b74fd11a8808">
											<gml:posList>35.66671764772499 139.73819408838068 58.926 35.66671764772499 139.73819408838068 57.956 35.66664584861202 139.73808551657513 57.956 35.66664584861202 139.73808551657513 58.926 35.66671764772499 139.73819408838068 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98c9f29d-eb3b-4f3c-8003-fcb5c1e2057a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98c9f29d-eb3b-4f3c-8003-fcb5c1e2057a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98c9f29d-eb3b-4f3c-8003-fcb5c1e2057a">
											<gml:posList>35.66664167490663 139.73808507970287 12.44 35.666717210180074 139.73819931354174 12.44 35.666717210180074 139.73819931354174 58.926 35.66664167490663 139.73808507970287 58.926 35.66664167490663 139.73808507970287 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3089f3be-79d6-41b6-a132-28f313adf6f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3089f3be-79d6-41b6-a132-28f313adf6f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3089f3be-79d6-41b6-a132-28f313adf6f2">
											<gml:posList>35.666774064460256 139.7381367602127 58.926 35.666774064460256 139.7381367602127 57.956 35.66671764772499 139.73819408838068 57.956 35.66671764772499 139.73819408838068 58.926 35.666774064460256 139.7381367602127 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74266825-097c-4bed-a119-b942f841abca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74266825-097c-4bed-a119-b942f841abca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74266825-097c-4bed-a119-b942f841abca">
											<gml:posList>35.666717210180074 139.73819931354174 12.44 35.66677620278318 139.73813937551992 12.44 35.66677620278318 139.73813937551992 58.926 35.666717210180074 139.73819931354174 58.926 35.666717210180074 139.73819931354174 12.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-500</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">202.10665</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>