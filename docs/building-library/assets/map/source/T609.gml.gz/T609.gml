<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b0c63c28-83a7-43ea-b440-7750015c1342">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">25.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67321220462436 139.7381615598764 0 35.673292037956536 139.73812578438998 0 35.67326827027487 139.7380479336834 0 35.673267094907374 139.73804340595103 0 35.67318636066461 139.738079734911 0 35.67321220462436 139.7381615598764 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67321220462436 139.7381615598764 8.67 35.67318636066461 139.738079734911 8.67 35.673267094907374 139.73804340595103 8.67 35.67326827027487 139.7380479336834 8.67 35.673292037956536 139.73812578438998 8.67 35.67321220462436 139.7381615598764 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67321220462436 139.7381615598764 8.67 35.673292037956536 139.73812578438998 8.67 35.673292037956536 139.73812578438998 33.92 35.67321220462436 139.7381615598764 33.92 35.67321220462436 139.7381615598764 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673292037956536 139.73812578438998 8.67 35.67326827027487 139.7380479336834 8.67 35.67326827027487 139.7380479336834 33.92 35.673292037956536 139.73812578438998 33.92 35.673292037956536 139.73812578438998 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67326827027487 139.7380479336834 8.67 35.673267094907374 139.73804340595103 8.67 35.673267094907374 139.73804340595103 33.92 35.67326827027487 139.7380479336834 33.92 35.67326827027487 139.7380479336834 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673267094907374 139.73804340595103 8.67 35.67318636066461 139.738079734911 8.67 35.67318636066461 139.738079734911 33.92 35.673267094907374 139.73804340595103 33.92 35.673267094907374 139.73804340595103 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67318636066461 139.738079734911 8.67 35.67321220462436 139.7381615598764 8.67 35.67321220462436 139.7381615598764 33.92 35.67318636066461 139.738079734911 33.92 35.67318636066461 139.738079734911 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67321220462436 139.7381615598764 33.92 35.673292037956536 139.73812578438998 33.92 35.67326827027487 139.7380479336834 33.92 35.673267094907374 139.73804340595103 33.92 35.67318636066461 139.738079734911 33.92 35.67321220462436 139.7381615598764 33.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-10ac9673-d4ec-4906-a86f-08927d7ac012"/>
							<gml:surfaceMember xlink:href="#poly-f3b4f6a4-6c27-4091-9584-42ddbbf894ea"/>
							<gml:surfaceMember xlink:href="#poly-449cc752-d661-4d7d-8edb-dfb59e334f33"/>
							<gml:surfaceMember xlink:href="#poly-f402aabb-2a6f-4862-808e-4fa3d4b30edf"/>
							<gml:surfaceMember xlink:href="#poly-fc6fbe0e-953a-4873-8f4c-d52d952898eb"/>
							<gml:surfaceMember xlink:href="#poly-6a5cb1b7-d7c0-42bc-a70a-feb2855fdcc7"/>
							<gml:surfaceMember xlink:href="#poly-c8e9a72f-c059-42f9-9fb4-1b258e9a9bfe"/>
							<gml:surfaceMember xlink:href="#poly-fa87680c-57e9-4d7e-847d-ab92b2ba3f6a"/>
							<gml:surfaceMember xlink:href="#poly-81b902d2-a7fe-4c1b-b218-dff7019d7758"/>
							<gml:surfaceMember xlink:href="#poly-430182fe-9083-4f4c-8b06-203ac9c207ad"/>
							<gml:surfaceMember xlink:href="#poly-ee3c7383-0b21-4ab7-bbfb-ef9f471dc481"/>
							<gml:surfaceMember xlink:href="#poly-2220ed10-88a1-41ba-8f35-9e0a366073f0"/>
							<gml:surfaceMember xlink:href="#poly-ee041d03-6552-4530-a554-8509a8be03ac"/>
							<gml:surfaceMember xlink:href="#poly-015f2855-5e4f-499c-98ba-745505681f23"/>
							<gml:surfaceMember xlink:href="#poly-cd7c67b6-a2bb-40a4-bd07-2d43c39b5219"/>
							<gml:surfaceMember xlink:href="#poly-258db833-bb3a-43ee-9c68-4df599229d86"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b0c63c28-83a7-43ea-b440-7750015c1342_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27a1b92d-7347-41b5-aa6e-4ce1e59b6574">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27a1b92d-7347-41b5-aa6e-4ce1e59b6574_0">
											<gml:posList>35.673233728722074 139.73811509419775 34.574 35.673238726261744 139.7381314704486 36.636 35.673233728722074 139.73811509419775 36.636 35.673233728722074 139.73811509419775 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9e1bf2e-6f8e-444b-88c6-d4f90bed0b9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9e1bf2e-6f8e-444b-88c6-d4f90bed0b9f_0">
											<gml:posList>35.673233728722074 139.73811509419775 34.574 35.673238726261744 139.7381314704486 34.574 35.673238726261744 139.7381314704486 36.636 35.673233728722074 139.73811509419775 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee6ab2a1-ecbf-4ee2-b4cc-470212395e1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee6ab2a1-ecbf-4ee2-b4cc-470212395e1c_0">
											<gml:posList>35.673246613673584 139.73810917998077 34.574 35.673233728722074 139.73811509419775 36.636 35.673246613673584 139.73810917998077 36.636 35.673246613673584 139.73810917998077 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4faf3c87-8ac0-4153-a0c7-84b88e5fe825">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4faf3c87-8ac0-4153-a0c7-84b88e5fe825_0">
											<gml:posList>35.673246613673584 139.73810917998077 34.574 35.673233728722074 139.73811509419775 34.574 35.673233728722074 139.73811509419775 36.636 35.673246613673584 139.73810917998077 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3eaf85b7-5935-469a-b25d-1585a87269b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3eaf85b7-5935-469a-b25d-1585a87269b3_0">
											<gml:posList>35.673233728722074 139.73811509419775 36.636 35.67325161122279 139.73812556728046 36.636 35.673246613673584 139.73810917998077 36.636 35.673233728722074 139.73811509419775 36.636</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d501af42-08cb-4ed2-8f70-5d7c77512369">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d501af42-08cb-4ed2-8f70-5d7c77512369_0">
											<gml:posList>35.673233728722074 139.73811509419775 36.636 35.673238726261744 139.7381314704486 36.636 35.67325161122279 139.73812556728046 36.636 35.673233728722074 139.73811509419775 36.636</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45aa8b24-b5d1-4e67-a694-378013a3da8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45aa8b24-b5d1-4e67-a694-378013a3da8e_0">
											<gml:posList>35.673238726261744 139.7381314704486 34.574 35.67325161122279 139.73812556728046 36.636 35.673238726261744 139.7381314704486 36.636 35.673238726261744 139.7381314704486 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a89b44e-d39f-476c-a78d-db172c20444f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a89b44e-d39f-476c-a78d-db172c20444f_0">
											<gml:posList>35.673238726261744 139.7381314704486 34.574 35.67325161122279 139.73812556728046 34.574 35.67325161122279 139.73812556728046 36.636 35.673238726261744 139.7381314704486 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c815864-c9c9-42ff-a409-02a388344f12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c815864-c9c9-42ff-a409-02a388344f12_0">
											<gml:posList>35.673242865901805 139.73805465815002 35.619 35.673242865901805 139.73805465815002 35.506 35.673244366086124 139.73805959422134 35.506 35.673242865901805 139.73805465815002 35.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-413d7230-ed09-4436-8471-31b186490d87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-413d7230-ed09-4436-8471-31b186490d87_0">
											<gml:posList>35.673242865901805 139.73805465815002 35.619 35.673244366086124 139.73805959422134 35.506 35.67325515663103 139.73809518476784 39.687 35.673242865901805 139.73805465815002 35.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f81659c-9592-4e82-9256-5c2f54e2d960">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f81659c-9592-4e82-9256-5c2f54e2d960_0">
											<gml:posList>35.673244366086124 139.73805959422134 35.506 35.67325515663103 139.73809518476784 34.574 35.67325515663103 139.73809518476784 39.687 35.673244366086124 139.73805959422134 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b843b3ee-2e34-403b-b6bb-455ad6d35b1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b843b3ee-2e34-403b-b6bb-455ad6d35b1f_0">
											<gml:posList>35.673244366086124 139.73805959422134 35.506 35.673244366086124 139.73805959422134 34.574 35.67325515663103 139.73809518476784 34.574 35.673244366086124 139.73805959422134 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf9aea98-e19f-4a43-ad92-05076f451e16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf9aea98-e19f-4a43-ad92-05076f451e16_0">
											<gml:posList>35.67325161122279 139.73812556728046 34.574 35.673246613673584 139.73810917998077 36.636 35.67325161122279 139.73812556728046 36.636 35.67325161122279 139.73812556728046 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1460ec28-ec4a-4ba7-a475-8bd221568d4b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1460ec28-ec4a-4ba7-a475-8bd221568d4b_0">
											<gml:posList>35.67325161122279 139.73812556728046 34.574 35.673246613673584 139.73810917998077 34.574 35.673246613673584 139.73810917998077 36.636 35.67325161122279 139.73812556728046 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eee6dd3f-2ca8-4d6a-8eee-25d963488c09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eee6dd3f-2ca8-4d6a-8eee-25d963488c09_0">
											<gml:posList>35.673244366086124 139.73805959422134 35.506 35.67326420724734 139.7380506670367 34.574 35.673244366086124 139.73805959422134 34.574 35.673244366086124 139.73805959422134 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed795e4b-68b5-474b-81e4-c195ba613cee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed795e4b-68b5-474b-81e4-c195ba613cee_0">
											<gml:posList>35.673244366086124 139.73805959422134 35.506 35.67326421626105 139.738050667026 35.506 35.67326420724734 139.7380506670367 34.574 35.673244366086124 139.73805959422134 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2febdf0-1356-4a0e-ba91-8c6e29cef5bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2febdf0-1356-4a0e-ba91-8c6e29cef5bb_0">
											<gml:posList>35.673242865901805 139.73805465815002 35.506 35.673266915070116 139.73804395849763 35.619 35.673266915070116 139.73804395849763 35.506 35.673242865901805 139.73805465815002 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c2e8bab-eb83-4f06-83c1-c7b4d35a6f5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c2e8bab-eb83-4f06-83c1-c7b4d35a6f5f_0">
											<gml:posList>35.673242865901805 139.73805465815002 35.506 35.673242865901805 139.73805465815002 35.619 35.673266915070116 139.73804395849763 35.619 35.673242865901805 139.73805465815002 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18202441-7068-40da-8f0b-66f7221c5fe4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18202441-7068-40da-8f0b-66f7221c5fe4_0">
											<gml:posList>35.673242865901805 139.73805465815002 35.619 35.67325515663103 139.73809518476784 39.687 35.67327892619416 139.73808425347835 39.687 35.673242865901805 139.73805465815002 35.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2668bcf-4fe3-4a6e-9d52-a0fdd4b71888">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2668bcf-4fe3-4a6e-9d52-a0fdd4b71888_0">
											<gml:posList>35.673266915070116 139.73804395849763 35.619 35.673242865901805 139.73805465815002 35.619 35.67327892619416 139.73808425347835 39.687 35.673266915070116 139.73804395849763 35.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bf72658-d7d9-4b61-9aa9-0240f30734a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7bf72658-d7d9-4b61-9aa9-0240f30734a7_0">
											<gml:posList>35.6732693620275 139.73811768097983 41.287 35.67326442774799 139.73810151453495 39.687 35.6732693620275 139.73811768097983 39.687 35.6732693620275 139.73811768097983 41.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75b4f407-3b85-4635-8a4f-47c262122db0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75b4f407-3b85-4635-8a4f-47c262122db0_0">
											<gml:posList>35.6732693620275 139.73811768097983 41.287 35.67326442774799 139.73810151453495 41.287 35.67326442774799 139.73810151453495 39.687 35.6732693620275 139.73811768097983 41.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-110a5f56-798a-43c7-970e-b9db54c9e946">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-110a5f56-798a-43c7-970e-b9db54c9e946_0">
											<gml:posList>35.67326442774799 139.73810151453495 41.287 35.67327490690986 139.7380967078373 39.687 35.67326442774799 139.73810151453495 39.687 35.67326442774799 139.73810151453495 41.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46f2d9f4-c6d3-49e0-9a45-784a5d3bee0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46f2d9f4-c6d3-49e0-9a45-784a5d3bee0b_0">
											<gml:posList>35.67326442774799 139.73810151453495 41.287 35.67327490690986 139.7380967078373 41.287 35.67327490690986 139.7380967078373 39.687 35.67326442774799 139.73810151453495 41.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd1ccc91-927d-4eee-8ca9-aa5c2056a565">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd1ccc91-927d-4eee-8ca9-aa5c2056a565_0">
											<gml:posList>35.67327984119001 139.73811287428398 41.287 35.67326442774799 139.73810151453495 41.287 35.6732693620275 139.73811768097983 41.287 35.67327984119001 139.73811287428398 41.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32fb9c39-5e3d-431e-b40d-7cb0eccb98cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32fb9c39-5e3d-431e-b40d-7cb0eccb98cf_0">
											<gml:posList>35.67327984119001 139.73811287428398 41.287 35.67327490690986 139.7380967078373 41.287 35.67326442774799 139.73810151453495 41.287 35.67327984119001 139.73811287428398 41.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-431eee88-f433-44df-b6d4-94e4a184668f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-431eee88-f433-44df-b6d4-94e4a184668f_0">
											<gml:posList>35.673266915070116 139.73804395849763 35.619 35.67327892619416 139.73808425347835 39.687 35.67327892619416 139.73808425347835 35.506 35.673266915070116 139.73804395849763 35.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e13209e-250a-4bff-bce5-58ada5e8dd29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e13209e-250a-4bff-bce5-58ada5e8dd29_0">
											<gml:posList>35.673266915070116 139.73804395849763 35.506 35.673266915070116 139.73804395849763 35.619 35.67327892619416 139.73808425347835 35.506 35.673266915070116 139.73804395849763 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-246d5f7e-6953-4dff-9dbe-6b0eee788423">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-246d5f7e-6953-4dff-9dbe-6b0eee788423_0">
											<gml:posList>35.67327984119001 139.73811287428398 41.287 35.6732693620275 139.73811768097983 39.687 35.67327984119001 139.73811287428398 39.687 35.67327984119001 139.73811287428398 41.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16d1733b-8c0f-47de-8c03-8750d98096f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16d1733b-8c0f-47de-8c03-8750d98096f6_0">
											<gml:posList>35.67327984119001 139.73811287428398 41.287 35.6732693620275 139.73811768097983 41.287 35.6732693620275 139.73811768097983 39.687 35.67327984119001 139.73811287428398 41.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31e73e9a-02bf-491f-ac75-b318f4513d10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31e73e9a-02bf-491f-ac75-b318f4513d10_0">
											<gml:posList>35.67327984119001 139.73811287428398 41.287 35.67327490690986 139.7380967078373 39.687 35.67327490690986 139.7380967078373 41.287 35.67327984119001 139.73811287428398 41.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c51851f-fb6b-4914-bca6-16c487be0379">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c51851f-fb6b-4914-bca6-16c487be0379_0">
											<gml:posList>35.67327984119001 139.73811287428398 41.287 35.67327984119001 139.73811287428398 39.687 35.67327490690986 139.7380967078373 39.687 35.67327984119001 139.73811287428398 41.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88df2ed3-702e-4026-8615-8f39715b5cbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88df2ed3-702e-4026-8615-8f39715b5cbb_0">
											<gml:posList>35.67327892619416 139.73808425347835 35.506 35.67327892619416 139.73808425347835 39.687 35.673275024678716 139.738086058719 35.506 35.67327892619416 139.73808425347835 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6284365d-2b5c-4351-9fa9-5895a55a5368">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6284365d-2b5c-4351-9fa9-5895a55a5368_0">
											<gml:posList>35.67327892619416 139.73808425347835 39.687 35.67325515663103 139.73809518476784 39.687 35.673275024678716 139.738086058719 35.506 35.67327892619416 139.73808425347835 39.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a35e66e-9670-4a3d-9137-a3b6d73e811d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a35e66e-9670-4a3d-9137-a3b6d73e811d_0">
											<gml:posList>35.673275024678716 139.738086058719 35.506 35.67325515663103 139.73809518476784 34.574 35.673275015665 139.7380860587297 34.574 35.673275024678716 139.738086058719 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d054c32-7b93-440e-92c2-04d42024de63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d054c32-7b93-440e-92c2-04d42024de63_0">
											<gml:posList>35.673275024678716 139.738086058719 35.506 35.67325515663103 139.73809518476784 39.687 35.67325515663103 139.73809518476784 34.574 35.673275024678716 139.738086058719 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a75da99-443d-4255-b95b-2eac329809cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a75da99-443d-4255-b95b-2eac329809cc_0">
											<gml:posList>35.67327505179852 139.7380861581067 34.574 35.67326421626105 139.738050667026 35.506 35.67327505179852 139.7380861581067 35.506 35.67327505179852 139.7380861581067 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13c41ec3-eb47-4b59-a87a-c0871ad1ee87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13c41ec3-eb47-4b59-a87a-c0871ad1ee87_0">
											<gml:posList>35.67327505179852 139.7380861581067 34.574 35.67326420724734 139.7380506670367 34.574 35.67326421626105 139.738050667026 35.506 35.67327505179852 139.7380861581067 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e8e3c6b-22a6-4413-b12b-fb985cf36a74">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67325161122279 139.73812556728046 34.574 35.673233728722074 139.73811509419775 34.574 35.673246613673584 139.73810917998077 34.574 35.67325161122279 139.73812556728046 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed093e29-3c32-4aa3-a594-b66b2a5f181e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67325161122279 139.73812556728046 34.574 35.673238726261744 139.7381314704486 34.574 35.673233728722074 139.73811509419775 34.574 35.67325161122279 139.73812556728046 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e8f5d49-d3e5-48a1-93be-d35bf070dc3f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67325515663103 139.73809518476784 34.574 35.673244366086124 139.73805959422134 34.574 35.67326420724734 139.7380506670367 34.574 35.67325515663103 139.73809518476784 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c426e39-e256-4ea1-9f79-cc163b8cf314">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673275015665 139.7380860587297 34.574 35.67325515663103 139.73809518476784 34.574 35.67326420724734 139.7380506670367 34.574 35.673275015665 139.7380860587297 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7069f787-cdaf-467d-9719-624f8d9957e3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673244366086124 139.73805959422134 35.506 35.673242865901805 139.73805465815002 35.506 35.67326421626105 139.738050667026 35.506 35.673244366086124 139.73805959422134 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35bba2f4-82eb-4d12-bf81-1b157b8114c8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673275024678716 139.738086058719 35.506 35.67326421626105 139.738050667026 35.506 35.67327892619416 139.73808425347835 35.506 35.673275024678716 139.738086058719 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14b4f336-1e98-4cb9-be29-d46a07b337ab">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67327892619416 139.73808425347835 35.506 35.67326421626105 139.738050667026 35.506 35.673266915070116 139.73804395849763 35.506 35.67327892619416 139.73808425347835 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c04d9a3-6dd3-4e9b-a214-b3485042d529">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67326421626105 139.738050667026 35.506 35.673242865901805 139.73805465815002 35.506 35.673266915070116 139.73804395849763 35.506 35.67326421626105 139.738050667026 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af49432a-a79f-4026-a6c3-bc250972a01c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67326442774799 139.73810151453495 39.687 35.67327984119001 139.73811287428398 39.687 35.6732693620275 139.73811768097983 39.687 35.67326442774799 139.73810151453495 39.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68e834c4-41fe-4977-9b4c-0a85b7e38b19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67326442774799 139.73810151453495 39.687 35.67327490690986 139.7380967078373 39.687 35.67327984119001 139.73811287428398 39.687 35.67326442774799 139.73810151453495 39.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b0c63c28-83a7-43ea-b440-7750015c1342_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-068ad792-0de7-42f8-b3d8-18346b3b8606">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67325515663103 139.73809518476784 34.574 35.673275015665 139.7380860587297 34.574 35.6732857336905 139.73812114123317 34.574 35.67326586564018 139.73813026727456 34.574 35.67325515663103 139.73809518476784 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d275347-a8b5-4d9f-a276-51735baea111">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67328982443338 139.73811925844262 35.506 35.6732857336905 139.73812114123317 35.506 35.673275015665 139.7380860587297 35.506 35.67327911542105 139.7380841759269 35.506 35.67328982443338 139.73811925844262 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61e0e962-c5da-4c3e-91d3-700ef97a9466">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61e0e962-c5da-4c3e-91d3-700ef97a9466_0">
											<gml:posList>35.67325515663103 139.73809518476784 39.687 35.67325515663103 139.73809518476784 34.574 35.67326586564018 139.73813026727456 34.574 35.67326586564018 139.73813026727456 39.687 35.67325515663103 139.73809518476784 39.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-271bf559-c211-40c8-8a4d-908124a18325">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-271bf559-c211-40c8-8a4d-908124a18325_0">
											<gml:posList>35.673275015665 139.7380860587297 34.574 35.67325515663103 139.73809518476784 34.574 35.67325515663103 139.73809518476784 39.687 35.67327911542105 139.7380841759269 39.687 35.67327911542105 139.7380841759269 35.506 35.673275015665 139.7380860587297 35.506 35.673275015665 139.7380860587297 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbca25f8-aeb1-4172-b421-ff5568305063">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbca25f8-aeb1-4172-b421-ff5568305063_0">
											<gml:posList>35.67325515663103 139.73809518476784 39.687 35.67326586564018 139.73813026727456 39.687 35.67328982443338 139.73811925844262 39.687 35.67327911542105 139.7380841759269 39.687 35.67325515663103 139.73809518476784 39.687</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef3266fc-dd5d-4d74-b700-d14e343cf18c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef3266fc-dd5d-4d74-b700-d14e343cf18c_0">
											<gml:posList>35.67326586564018 139.73813026727456 34.574 35.6732857336905 139.73812114123317 34.574 35.6732857336905 139.73812114123317 35.506 35.67328982443338 139.73811925844262 35.506 35.67328982443338 139.73811925844262 39.687 35.67326586564018 139.73813026727456 39.687 35.67326586564018 139.73813026727456 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb5d3f15-eb5c-4a9c-8c2b-c8c06285b35e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb5d3f15-eb5c-4a9c-8c2b-c8c06285b35e_0">
											<gml:posList>35.673275015665 139.7380860587297 35.506 35.6732857336905 139.73812114123317 35.506 35.6732857336905 139.73812114123317 34.574 35.673275015665 139.7380860587297 34.574 35.673275015665 139.7380860587297 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c180abb0-fb48-4621-aedb-e22ea75be799">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c180abb0-fb48-4621-aedb-e22ea75be799_0">
											<gml:posList>35.67328982443338 139.73811925844262 35.506 35.67327911542105 139.7380841759269 35.506 35.67327911542105 139.7380841759269 39.687 35.67328982443338 139.73811925844262 39.687 35.67328982443338 139.73811925844262 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-10ac9673-d4ec-4906-a86f-08927d7ac012">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10ac9673-d4ec-4906-a86f-08927d7ac012">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10ac9673-d4ec-4906-a86f-08927d7ac012">
											<gml:posList>35.67321220462436 139.7381615598764 8.67 35.67318636066458 139.738079734911 8.67 35.67326709490737 139.73804340595103 8.67 35.67326827027486 139.7380479336834 8.67 35.67329203795654 139.73812578438998 8.67 35.67321220462436 139.7381615598764 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f3b4f6a4-6c27-4091-9584-42ddbbf894ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3b4f6a4-6c27-4091-9584-42ddbbf894ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3b4f6a4-6c27-4091-9584-42ddbbf894ea">
											<gml:posList>35.67321220462436 139.7381615598764 35.506 35.67321484899932 139.73815439850813 35.506 35.673192303317514 139.73808303079755 35.506 35.67318636066458 139.738079734911 35.506 35.67321220462436 139.7381615598764 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-449cc752-d661-4d7d-8edb-dfb59e334f33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-449cc752-d661-4d7d-8edb-dfb59e334f33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-449cc752-d661-4d7d-8edb-dfb59e334f33">
											<gml:posList>35.67318636066458 139.738079734911 35.506 35.673192303317514 139.73808303079755 35.506 35.67326420724734 139.7380506670367 35.506 35.67326709490737 139.73804340595103 35.506 35.67318636066458 139.738079734911 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f402aabb-2a6f-4862-808e-4fa3d4b30edf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f402aabb-2a6f-4862-808e-4fa3d4b30edf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f402aabb-2a6f-4862-808e-4fa3d4b30edf">
											<gml:posList>35.67321484899932 139.73815439850813 34.574 35.67328614035599 139.73812246634935 34.574 35.67326420724734 139.7380506670367 34.574 35.673192303317514 139.73808303079755 34.574 35.67321484899932 139.73815439850813 34.574</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fc6fbe0e-953a-4873-8f4c-d52d952898eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc6fbe0e-953a-4873-8f4c-d52d952898eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc6fbe0e-953a-4873-8f4c-d52d952898eb">
											<gml:posList>35.67329203795654 139.73812578438998 35.506 35.67328614035599 139.73812246634935 35.506 35.67321484899932 139.73815439850813 35.506 35.67321220462436 139.7381615598764 35.506 35.67329203795654 139.73812578438998 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a5cb1b7-d7c0-42bc-a70a-feb2855fdcc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a5cb1b7-d7c0-42bc-a70a-feb2855fdcc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a5cb1b7-d7c0-42bc-a70a-feb2855fdcc7">
											<gml:posList>35.67326827027486 139.7380479336834 35.506 35.67326709490737 139.73804340595103 35.506 35.67326420724734 139.7380506670367 35.506 35.67326827027486 139.7380479336834 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8e9a72f-c059-42f9-9fb4-1b258e9a9bfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8e9a72f-c059-42f9-9fb4-1b258e9a9bfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8e9a72f-c059-42f9-9fb4-1b258e9a9bfe">
											<gml:posList>35.67326827027486 139.7380479336834 35.506 35.67326420724734 139.7380506670367 35.506 35.67328614035599 139.73812246634935 35.506 35.67329203795654 139.73812578438998 35.506 35.67326827027486 139.7380479336834 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa87680c-57e9-4d7e-847d-ab92b2ba3f6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa87680c-57e9-4d7e-847d-ab92b2ba3f6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa87680c-57e9-4d7e-847d-ab92b2ba3f6a">
											<gml:posList>35.67326827027486 139.7380479336834 8.67 35.67326709490737 139.73804340595103 8.67 35.67326709490737 139.73804340595103 35.506 35.67326827027486 139.7380479336834 35.506 35.67326827027486 139.7380479336834 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81b902d2-a7fe-4c1b-b218-dff7019d7758">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81b902d2-a7fe-4c1b-b218-dff7019d7758">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81b902d2-a7fe-4c1b-b218-dff7019d7758">
											<gml:posList>35.67326709490737 139.73804340595103 8.67 35.67318636066458 139.738079734911 8.67 35.67318636066458 139.738079734911 35.506 35.67326709490737 139.73804340595103 35.506 35.67326709490737 139.73804340595103 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-430182fe-9083-4f4c-8b06-203ac9c207ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-430182fe-9083-4f4c-8b06-203ac9c207ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-430182fe-9083-4f4c-8b06-203ac9c207ad">
											<gml:posList>35.673192303317514 139.73808303079755 35.506 35.673192303317514 139.73808303079755 34.574 35.67326420724734 139.7380506670367 34.574 35.67326420724734 139.7380506670367 35.506 35.673192303317514 139.73808303079755 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee3c7383-0b21-4ab7-bbfb-ef9f471dc481">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee3c7383-0b21-4ab7-bbfb-ef9f471dc481">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee3c7383-0b21-4ab7-bbfb-ef9f471dc481">
											<gml:posList>35.67326420724734 139.7380506670367 35.506 35.67326420724734 139.7380506670367 34.574 35.67328614035599 139.73812246634935 34.574 35.67328614035599 139.73812246634935 35.506 35.67326420724734 139.7380506670367 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2220ed10-88a1-41ba-8f35-9e0a366073f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2220ed10-88a1-41ba-8f35-9e0a366073f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2220ed10-88a1-41ba-8f35-9e0a366073f0">
											<gml:posList>35.67326827027486 139.7380479336834 35.506 35.67329203795654 139.73812578438998 35.506 35.67329203795654 139.73812578438998 8.67 35.67326827027486 139.7380479336834 8.67 35.67326827027486 139.7380479336834 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee041d03-6552-4530-a554-8509a8be03ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee041d03-6552-4530-a554-8509a8be03ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee041d03-6552-4530-a554-8509a8be03ac">
											<gml:posList>35.67321484899932 139.73815439850813 35.506 35.67321484899932 139.73815439850813 34.574 35.673192303317514 139.73808303079755 34.574 35.673192303317514 139.73808303079755 35.506 35.67321484899932 139.73815439850813 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-015f2855-5e4f-499c-98ba-745505681f23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-015f2855-5e4f-499c-98ba-745505681f23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-015f2855-5e4f-499c-98ba-745505681f23">
											<gml:posList>35.67318636066458 139.738079734911 8.67 35.67321220462436 139.7381615598764 8.67 35.67321220462436 139.7381615598764 35.506 35.67318636066458 139.738079734911 35.506 35.67318636066458 139.738079734911 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd7c67b6-a2bb-40a4-bd07-2d43c39b5219">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd7c67b6-a2bb-40a4-bd07-2d43c39b5219">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd7c67b6-a2bb-40a4-bd07-2d43c39b5219">
											<gml:posList>35.67328614035599 139.73812246634935 35.506 35.67328614035599 139.73812246634935 34.574 35.67321484899932 139.73815439850813 34.574 35.67321484899932 139.73815439850813 35.506 35.67328614035599 139.73812246634935 35.506</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-258db833-bb3a-43ee-9c68-4df599229d86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-258db833-bb3a-43ee-9c68-4df599229d86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-258db833-bb3a-43ee-9c68-4df599229d86">
											<gml:posList>35.67321220462436 139.7381615598764 8.67 35.67329203795654 139.73812578438998 8.67 35.67329203795654 139.73812578438998 35.506 35.67321220462436 139.7381615598764 35.506 35.67321220462436 139.7381615598764 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9204</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">75.3115</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.16</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>