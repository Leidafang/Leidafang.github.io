<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b131efb3-5947-43bb-a7f4-053364fd6782">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">45.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>13</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67098136892151 139.74352289915606 0 35.67092597132671 139.74381447399017 0 35.67110295183191 139.7438696186456 0 35.671183396241034 139.74344181341868 0 35.67098136892151 139.74352289915606 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67098136892151 139.74352289915606 7.01 35.671183396241034 139.74344181341868 7.01 35.67110295183191 139.7438696186456 7.01 35.67092597132671 139.74381447399017 7.01 35.67098136892151 139.74352289915606 7.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67098136892151 139.74352289915606 7.01 35.67092597132671 139.74381447399017 7.01 35.67092597132671 139.74381447399017 50.47 35.67098136892151 139.74352289915606 50.47 35.67098136892151 139.74352289915606 7.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67092597132671 139.74381447399017 7.01 35.67110295183191 139.7438696186456 7.01 35.67110295183191 139.7438696186456 50.47 35.67092597132671 139.74381447399017 50.47 35.67092597132671 139.74381447399017 7.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67110295183191 139.7438696186456 7.01 35.671183396241034 139.74344181341868 7.01 35.671183396241034 139.74344181341868 50.47 35.67110295183191 139.7438696186456 50.47 35.67110295183191 139.7438696186456 7.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671183396241034 139.74344181341868 7.01 35.67098136892151 139.74352289915606 7.01 35.67098136892151 139.74352289915606 50.47 35.671183396241034 139.74344181341868 50.47 35.671183396241034 139.74344181341868 7.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67098136892151 139.74352289915606 50.47 35.67092597132671 139.74381447399017 50.47 35.67110295183191 139.7438696186456 50.47 35.671183396241034 139.74344181341868 50.47 35.67098136892151 139.74352289915606 50.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f3643bed-9b79-4f94-a3d4-aa20a12e696d"/>
							<gml:surfaceMember xlink:href="#poly-1ab5c6c1-15a1-46e3-8ece-33472c3d9b9b"/>
							<gml:surfaceMember xlink:href="#poly-51d8d286-bee0-4464-b58e-e9a73e1c7f7b"/>
							<gml:surfaceMember xlink:href="#poly-455d6310-924f-4467-b166-4ba2504bdca8"/>
							<gml:surfaceMember xlink:href="#poly-c442fd0d-91f7-43a0-9c71-7160affba190"/>
							<gml:surfaceMember xlink:href="#poly-ae2e07ca-1afb-474a-8f29-ccfc4a1a46f0"/>
							<gml:surfaceMember xlink:href="#poly-0da5b4b8-e33a-4923-8110-48ae42134a52"/>
							<gml:surfaceMember xlink:href="#poly-07b3fe33-c9d8-4407-aec8-b24ca4990419"/>
							<gml:surfaceMember xlink:href="#poly-17cd6f87-b8e0-494c-b0ea-e1b80a5e7fa8"/>
							<gml:surfaceMember xlink:href="#poly-9730b3a0-a5f0-460b-9eec-26433aaa3b08"/>
							<gml:surfaceMember xlink:href="#poly-3e27f296-c988-4df8-9e31-8ae8ba154110"/>
							<gml:surfaceMember xlink:href="#poly-7978a0c3-9247-4564-b3dc-c7e53effee1b"/>
							<gml:surfaceMember xlink:href="#poly-ccfdfa2c-2ae0-4a7e-bab1-e9575759a8be"/>
							<gml:surfaceMember xlink:href="#poly-4b7bc5ef-de24-4557-9a92-57864044e85f"/>
							<gml:surfaceMember xlink:href="#poly-d68339f0-af56-492a-a8f3-a7a6a3b34e5c"/>
							<gml:surfaceMember xlink:href="#poly-3e9fa15a-c890-46e7-b083-35fc7429827d"/>
							<gml:surfaceMember xlink:href="#poly-dff4b50b-c776-4a58-9944-3f112197985f"/>
							<gml:surfaceMember xlink:href="#poly-85cfb452-eb1c-468b-a158-ca42105a3780"/>
							<gml:surfaceMember xlink:href="#poly-69025ade-6a7a-470a-aa4c-674e6639c52e"/>
							<gml:surfaceMember xlink:href="#poly-538eaf5f-7da2-4faf-adec-ef46e5740b9c"/>
							<gml:surfaceMember xlink:href="#poly-2ed6ce90-acb0-4428-ac90-837ac0cb0122"/>
							<gml:surfaceMember xlink:href="#poly-aaafbcaa-b933-40f9-b5e7-a1ddaa93284a"/>
							<gml:surfaceMember xlink:href="#poly-808bb9da-6aef-46bb-9707-06cfed421cff"/>
							<gml:surfaceMember xlink:href="#poly-e8ef58e1-d200-452f-8bfb-54f54a559a26"/>
							<gml:surfaceMember xlink:href="#poly-7eeb92d5-bcbc-4a90-b5eb-40b3c7e3d8dd"/>
							<gml:surfaceMember xlink:href="#poly-5359bd38-161a-4fff-9cf5-8973bd1df397"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b131efb3-5947-43bb-a7f4-053364fd6782_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a84b5d3-b46e-4418-b942-4601e373d5af">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671125718644554 139.743564327014 48.956 35.671135819780424 139.74351161350222 48.956 35.67115078578126 139.74351591586463 48.956 35.67114068464355 139.74356862938572 48.956 35.671125718644554 139.743564327014 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10a8668b-8bfc-45a7-82af-6911997db6fa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67111132328352 139.74350331199025 48.956 35.671077722713 139.74367613673525 48.956 35.67105855536062 139.74367054662193 48.956 35.67106358377017 139.74364465939126 48.956 35.67105412631007 139.74364189733637 48.956 35.67107700557176 139.74352420596009 48.956 35.67108647204822 139.74352696799176 48.956 35.671092155923276 139.74349772191593 48.956 35.67111132328352 139.74350331199025 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f4f6fb3-8f09-4bdd-9802-aed5ed09b9f8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671116102773105 139.74350627810637 48.956 35.67113041965433 139.74351040445214 48.956 35.67109761103949 139.74368156034967 48.956 35.67108330318595 139.74367744501126 48.956 35.671116102773105 139.74350627810637 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-caed31fb-6446-418a-ba8e-3c3078417ced">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67110118655117 139.74368971961093 48.956 35.671111306197346 139.74363758052104 48.956 35.67112644353678 139.74364199317762 48.956 35.671116323888725 139.7436941322768 48.956 35.67110118655117 139.74368971961093 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffb40b4c-ff0e-4211-ba54-fbddc94953c1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67098679777163 139.7436594037857 48.956 35.670980865584674 139.74369417326056 48.956 35.670972427128525 139.74369201761215 48.956 35.670978350301155 139.74365724815084 48.956 35.67098679777163 139.7436594037857 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85b22e07-f7a0-4fe5-83c6-0eb7844e62d8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67099264877326 139.74369718678486 48.956 35.670985625742986 139.74369539408264 48.956 35.670991477127615 139.7436610555036 48.956 35.670998500158376 139.74366284820292 48.956 35.67099264877326 139.74369718678486 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-919e8ba9-9a2c-46ac-a00e-f755f28c5f7c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671004756521526 139.74370028831794 48.956 35.67099804902918 139.74369857258685 48.956 35.671003882485955 139.74366436657888 48.956 35.67101058997879 139.7436660823073 48.956 35.671004756521526 139.74370028831794 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18957f70-e7e9-4af7-a718-af14b7ec4d66">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671011436972684 139.7437020040796 48.956 35.67101734222763 139.74366737822467 48.956 35.671025618412465 139.74366950091414 48.956 35.671019704143205 139.74370412678255 48.956 35.671011436972684 139.7437020040796 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-577602fd-9db6-4aee-95ba-ff933af33cee">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671019704143205 139.74370412678255 48.956 35.671025618412465 139.74366950091414 48.956 35.671025618412465 139.74366950091414 51.94 35.671019704143205 139.74370412678255 51.94 35.671019704143205 139.74370412678255 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd5d3da1-4908-4001-90fd-a3fc752b2c4c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67102988279981 139.74367070019719 48.956 35.67102399549738 139.74370522662005 48.956 35.67102399549738 139.74370522662005 51.94 35.67102988279981 139.74367070019719 51.94 35.67102988279981 139.74367070019719 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-991997c5-1e67-4d74-84f9-10974aa68af8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671036968942886 139.74367251492032 48.956 35.67103108163995 139.74370704134614 48.956 35.67102399549738 139.74370522662005 48.956 35.67102988279981 139.74367070019719 48.956 35.671036968942886 139.74367251492032 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20b5530b-e267-4c6e-8fe6-efb02dda9f97">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67105813086932 139.74368151612535 48.956 35.67105150765303 139.7437203625059 48.956 35.67104216764433 139.7437179648408 48.956 35.67104879086808 139.74367912951092 48.956 35.67105813086932 139.74368151612535 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23fa1c5f-d84f-482c-a403-aff122b15050">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67106502756558 139.74370733478943 48.956 35.67107081112065 139.7436908471626 48.956 35.671078744808234 139.7436930033779 48.956 35.67107113252005 139.7437351316403 48.956 35.671060521215125 139.74373224935408 48.956 35.67106502756558 139.74370733478943 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-756d81dc-eb7c-423f-90e9-4dc0cc28b9f9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670983705440115 139.74370699488964 48.956 35.67097893866981 139.74373322423483 48.956 35.67095350577964 139.74372629346382 48.956 35.67095826353476 139.74370006413662 48.956 35.670983705440115 139.74370699488964 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3328975-d010-4204-9dc0-3dc9079c983b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671118751143744 139.74370968284003 48.956 35.67111389501665 139.74373696173336 48.956 35.67109897433056 139.74373297962543 48.956 35.67110383044854 139.7437056896906 48.956 35.671118751143744 139.74370968284003 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e149ff6-1ee9-4a2d-96ac-7571a3fc69f4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67100788763457 139.7437411231596 48.956 35.67098286043647 139.7437342913473 48.956 35.67098761820149 139.74370807305732 48.956 35.671012645392835 139.7437148938155 48.956 35.67100788763457 139.7437411231596 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10a587b9-9caa-4a47-9566-f20cdc5df6df">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671026727696656 139.74371873325038 48.956 35.67102196993759 139.74374496259884 48.956 35.671011250435264 139.7437420362486 48.956 35.671016017207435 139.7437158068934 48.956 35.671026727696656 139.74371873325038 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccf3ef95-05b6-4922-ae77-b03aacc850f0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67095166475615 139.743735419797 48.956 35.67097648458939 139.74374218556065 48.956 35.670964293897825 139.7438093498853 48.956 35.67093946504635 139.7438025730656 48.956 35.67095166475615 139.743735419797 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16c93a50-189b-4f13-884c-d426a074048d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670981569372735 139.74374358276427 48.956 35.67100586630264 139.74375020551471 48.956 35.67099366658478 139.7438173588265 48.956 35.6709693786722 139.7438107360466 48.956 35.670981569372735 139.74374358276427 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bc2d087-669b-4a71-95cc-7e30535f1154">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67099366658478 139.7438173588265 48.956 35.67100586630264 139.74375020551471 48.956 35.67100586630264 139.74375020551471 59.2 35.67099366658478 139.7438173588265 59.2 35.67099366658478 139.7438173588265 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fe40570-af30-4c54-beed-17c273633e5e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670997390007706 139.74381837093304 48.956 35.670997390007706 139.74381837093304 59.2 35.671009580712415 139.74375121762833 59.2 35.671009580712415 139.74375121762833 48.956 35.670997390007706 139.74381837093304 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e782750d-43ba-495d-a3db-189ea2a2bcec">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670997390007706 139.74381837093304 48.956 35.671009580712415 139.74375121762833 48.956 35.67102920758029 139.7437565642245 48.956 35.67101700786716 139.74382372860123 48.956 35.670997390007706 139.74381837093304 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d69ee21-2e03-4061-9622-66939bfc9d1f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671050968170675 139.74380698860276 48.956 35.67107498570431 139.7438136558755 48.956 35.67106975170792 139.74384191829503 48.956 35.67104573416761 139.7438352399679 48.956 35.671050968170675 139.74380698860276 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93a340c1-93be-4309-a1b0-9cbf93576bd7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93a340c1-93be-4309-a1b0-9cbf93576bd7_0">
											<gml:posList>35.671077722713 139.74367613673525 48.956 35.67111132328352 139.74350331199025 48.956 35.67111132328352 139.74350331199025 59.2 35.671077722713 139.74367613673525 59.2 35.671077722713 139.74367613673525 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-316155a7-6e7d-4e9c-a137-251ab8bf9357">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-316155a7-6e7d-4e9c-a137-251ab8bf9357_0">
											<gml:posList>35.67108330318595 139.74367744501126 48.956 35.67108330318595 139.74367744501126 59.2 35.671116102773105 139.74350627810637 59.2 35.671116102773105 139.74350627810637 48.956 35.67108330318595 139.74367744501126 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6bfa90f-7da1-465f-b11c-4be48220baef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6bfa90f-7da1-465f-b11c-4be48220baef_0">
											<gml:posList>35.67098761820149 139.74370807305732 48.956 35.67098286043647 139.7437342913473 48.956 35.67098286043647 139.7437342913473 59.2 35.67098761820149 139.74370807305732 59.2 35.67098761820149 139.74370807305732 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c60e5a61-d3c1-42f1-98de-4c88ca5130bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c60e5a61-d3c1-42f1-98de-4c88ca5130bd_0">
											<gml:posList>35.67100788763457 139.7437411231596 48.956 35.671012645392835 139.7437148938155 48.956 35.671012645392835 139.7437148938155 59.2 35.67100788763457 139.7437411231596 59.2 35.67100788763457 139.7437411231596 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a43937ef-9622-4f2a-9686-21d8fd0ed48f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a43937ef-9622-4f2a-9686-21d8fd0ed48f_0">
											<gml:posList>35.671092155923276 139.74349772191593 48.956 35.671092155923276 139.74349772191593 59.2 35.67111132328352 139.74350331199025 59.2 35.67111132328352 139.74350331199025 48.956 35.671092155923276 139.74349772191593 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb0e270d-2ab4-4ee4-8618-f23e6824dd70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb0e270d-2ab4-4ee4-8618-f23e6824dd70_0">
											<gml:posList>35.671116102773105 139.74350627810637 48.956 35.671116102773105 139.74350627810637 59.2 35.67113041965433 139.74351040445214 59.2 35.67113041965433 139.74351040445214 48.956 35.671116102773105 139.74350627810637 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42dd5718-854a-4529-a596-64f490741a59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42dd5718-854a-4529-a596-64f490741a59_0">
											<gml:posList>35.671135819780424 139.74351161350222 48.956 35.671135819780424 139.74351161350222 59.2 35.67115078578126 139.74351591586463 59.2 35.67115078578126 139.74351591586463 48.956 35.671135819780424 139.74351161350222 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-624510bf-254e-46d1-8186-c4bd13ca94cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-624510bf-254e-46d1-8186-c4bd13ca94cb_0">
											<gml:posList>35.67108647204822 139.74352696799176 48.956 35.67107700557176 139.74352420596009 48.956 35.67107700557176 139.74352420596009 52.997 35.67108647204822 139.74352696799176 52.997 35.67108647204822 139.74352696799176 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a6e5151-cdab-423b-909d-2800c710d227">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a6e5151-cdab-423b-909d-2800c710d227_0">
											<gml:posList>35.671135819780424 139.74351161350222 48.956 35.671125718644554 139.743564327014 48.956 35.671125718644554 139.743564327014 59.2 35.671135819780424 139.74351161350222 59.2 35.671135819780424 139.74351161350222 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8477328b-c66f-4015-803f-851204c67838">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8477328b-c66f-4015-803f-851204c67838_0">
											<gml:posList>35.67115078578126 139.74351591586463 59.2 35.671135819780424 139.74351161350222 59.2 35.671125718644554 139.743564327014 59.2 35.67114068464355 139.74356862938572 59.2 35.67115078578126 139.74351591586463 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8544f9ab-c8f6-4931-8a49-b5fb1b21cc00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8544f9ab-c8f6-4931-8a49-b5fb1b21cc00_0">
											<gml:posList>35.67114068464355 139.74356862938572 48.956 35.67115078578126 139.74351591586463 48.956 35.67115078578126 139.74351591586463 59.2 35.67114068464355 139.74356862938572 59.2 35.67114068464355 139.74356862938572 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cab99125-d200-4540-95b1-187ae0b988b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cab99125-d200-4540-95b1-187ae0b988b7_0">
											<gml:posList>35.67114068464355 139.74356862938572 48.956 35.67114068464355 139.74356862938572 59.2 35.671125718644554 139.743564327014 59.2 35.671125718644554 139.743564327014 48.956 35.67114068464355 139.74356862938572 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b34dac28-ff99-4766-8955-43bee4527992">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b34dac28-ff99-4766-8955-43bee4527992_0">
											<gml:posList>35.67105412631007 139.74364189733637 48.956 35.67105412631007 139.74364189733637 52.997 35.67107700557176 139.74352420596009 52.997 35.67107700557176 139.74352420596009 48.956 35.67105412631007 139.74364189733637 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-711639b3-5551-4d3c-aab6-3aaa0d3490a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-711639b3-5551-4d3c-aab6-3aaa0d3490a5_0">
											<gml:posList>35.67105855536062 139.74367054662193 48.956 35.67105855536062 139.74367054662193 59.2 35.671092155923276 139.74349772191593 59.2 35.671092155923276 139.74349772191593 48.956 35.67108647204822 139.74352696799176 48.956 35.67108647204822 139.74352696799176 52.997 35.67106358377017 139.74364465939126 52.997 35.67106358377017 139.74364465939126 48.956 35.67105855536062 139.74367054662193 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fca701b-c94e-4198-9fb1-c202f345628b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fca701b-c94e-4198-9fb1-c202f345628b_0">
											<gml:posList>35.67107700557176 139.74352420596009 52.997 35.67105412631007 139.74364189733637 52.997 35.67106358377017 139.74364465939126 52.997 35.67108647204822 139.74352696799176 52.997 35.67107700557176 139.74352420596009 52.997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe9d6be2-a887-4ad1-8aee-ed93fa946e1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe9d6be2-a887-4ad1-8aee-ed93fa946e1b_0">
											<gml:posList>35.671077722713 139.74367613673525 59.2 35.67111132328352 139.74350331199025 59.2 35.671092155923276 139.74349772191593 59.2 35.67105855536062 139.74367054662193 59.2 35.671077722713 139.74367613673525 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d27b902-b00f-428f-88ec-94bec4b99548">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d27b902-b00f-428f-88ec-94bec4b99548_0">
											<gml:posList>35.67109761103949 139.74368156034967 59.2 35.67113041965433 139.74351040445214 59.2 35.671116102773105 139.74350627810637 59.2 35.67108330318595 139.74367744501126 59.2 35.67109761103949 139.74368156034967 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc29ee30-6d3e-4452-bb7f-9bbf4ae4e282">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc29ee30-6d3e-4452-bb7f-9bbf4ae4e282_0">
											<gml:posList>35.67109761103949 139.74368156034967 48.956 35.67113041965433 139.74351040445214 48.956 35.67113041965433 139.74351040445214 59.2 35.67109761103949 139.74368156034967 59.2 35.67109761103949 139.74368156034967 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d891b0c-a74a-409b-b0fc-ee95cb5d2755">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d891b0c-a74a-409b-b0fc-ee95cb5d2755_0">
											<gml:posList>35.671111306197346 139.74363758052104 59.2 35.67112644353678 139.74364199317762 59.2 35.67112644353678 139.74364199317762 48.956 35.671111306197346 139.74363758052104 48.956 35.671111306197346 139.74363758052104 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2e6f030-276e-40aa-a5f5-510d37fa3780">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2e6f030-276e-40aa-a5f5-510d37fa3780_0">
											<gml:posList>35.67105412631007 139.74364189733637 48.956 35.67106358377017 139.74364465939126 48.956 35.67106358377017 139.74364465939126 52.997 35.67105412631007 139.74364189733637 52.997 35.67105412631007 139.74364189733637 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df6680e7-7c6b-45be-b134-357915ec16da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df6680e7-7c6b-45be-b134-357915ec16da_0">
											<gml:posList>35.67098679777163 139.7436594037857 48.956 35.670978350301155 139.74365724815084 48.956 35.670978350301155 139.74365724815084 51.94 35.67098679777163 139.7436594037857 51.94 35.67098679777163 139.7436594037857 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-141e63f8-9bb0-4572-921e-f2550ba1467f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-141e63f8-9bb0-4572-921e-f2550ba1467f_0">
											<gml:posList>35.670998500158376 139.74366284820292 48.956 35.670991477127615 139.7436610555036 48.956 35.670991477127615 139.7436610555036 51.94 35.670998500158376 139.74366284820292 51.94 35.670998500158376 139.74366284820292 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0645647-fc53-4a59-833a-f082f941657a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0645647-fc53-4a59-833a-f082f941657a_0">
											<gml:posList>35.671111306197346 139.74363758052104 48.956 35.67110118655117 139.74368971961093 48.956 35.67110118655117 139.74368971961093 59.2 35.671111306197346 139.74363758052104 59.2 35.671111306197346 139.74363758052104 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-922453f4-9ed0-4c7f-9803-54f192be0047">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-922453f4-9ed0-4c7f-9803-54f192be0047_0">
											<gml:posList>35.67101058997879 139.7436660823073 48.956 35.671003882485955 139.74366436657888 48.956 35.671003882485955 139.74366436657888 51.94 35.67101058997879 139.7436660823073 51.94 35.67101058997879 139.7436660823073 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37e5b4fe-9039-42ca-94a6-0cdd1848ffcf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37e5b4fe-9039-42ca-94a6-0cdd1848ffcf_0">
											<gml:posList>35.67112644353678 139.74364199317762 59.2 35.671111306197346 139.74363758052104 59.2 35.67110118655117 139.74368971961093 59.2 35.671116323888725 139.7436941322768 59.2 35.67112644353678 139.74364199317762 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2036162-153f-41dd-91f4-098995a887e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2036162-153f-41dd-91f4-098995a887e8_0">
											<gml:posList>35.671116323888725 139.7436941322768 48.956 35.67112644353678 139.74364199317762 48.956 35.67112644353678 139.74364199317762 59.2 35.671116323888725 139.7436941322768 59.2 35.671116323888725 139.7436941322768 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-487fe416-3bb9-48b0-b8e9-1f30189b66bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-487fe416-3bb9-48b0-b8e9-1f30189b66bd_0">
											<gml:posList>35.671025618412465 139.74366950091414 48.956 35.67101734222763 139.74366737822467 48.956 35.67101734222763 139.74366737822467 51.94 35.671025618412465 139.74366950091414 51.94 35.671025618412465 139.74366950091414 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18921fea-d613-4238-a2b1-9400990fda22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18921fea-d613-4238-a2b1-9400990fda22_0">
											<gml:posList>35.671036968942886 139.74367251492032 48.956 35.67102988279981 139.74367070019719 48.956 35.67102988279981 139.74367070019719 51.94 35.671036968942886 139.74367251492032 51.94 35.671036968942886 139.74367251492032 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e743548c-d393-480a-8472-19d5864eabe7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e743548c-d393-480a-8472-19d5864eabe7_0">
											<gml:posList>35.671077722713 139.74367613673525 48.956 35.671077722713 139.74367613673525 59.2 35.67105855536062 139.74367054662193 59.2 35.67105855536062 139.74367054662193 48.956 35.671077722713 139.74367613673525 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08af1c39-54f8-4bdc-9f92-0cbc9f3eeadf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08af1c39-54f8-4bdc-9f92-0cbc9f3eeadf_0">
											<gml:posList>35.670978350301155 139.74365724815084 48.956 35.670972427128525 139.74369201761215 48.956 35.670972427128525 139.74369201761215 51.94 35.670978350301155 139.74365724815084 51.94 35.670978350301155 139.74365724815084 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbb77a28-40ac-4328-aa89-2dbde1b16e50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbb77a28-40ac-4328-aa89-2dbde1b16e50_0">
											<gml:posList>35.670972427128525 139.74369201761215 51.94 35.670980865584674 139.74369417326056 51.94 35.67098679777163 139.7436594037857 51.94 35.670978350301155 139.74365724815084 51.94 35.670972427128525 139.74369201761215 51.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f748e2a1-01db-4d4c-89cd-c4df6a05634a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f748e2a1-01db-4d4c-89cd-c4df6a05634a_0">
											<gml:posList>35.670980865584674 139.74369417326056 48.956 35.67098679777163 139.7436594037857 48.956 35.67098679777163 139.7436594037857 51.94 35.670980865584674 139.74369417326056 51.94 35.670980865584674 139.74369417326056 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b966c63f-5824-4d13-ac76-637fa022e08a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b966c63f-5824-4d13-ac76-637fa022e08a_0">
											<gml:posList>35.670991477127615 139.7436610555036 48.956 35.670985625742986 139.74369539408264 48.956 35.670985625742986 139.74369539408264 51.94 35.670991477127615 139.7436610555036 51.94 35.670991477127615 139.7436610555036 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-567fc2f7-3dc1-4d79-ab56-7bb441eccd25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-567fc2f7-3dc1-4d79-ab56-7bb441eccd25_0">
											<gml:posList>35.670991477127615 139.7436610555036 51.94 35.670985625742986 139.74369539408264 51.94 35.67099264877326 139.74369718678486 51.94 35.670998500158376 139.74366284820292 51.94 35.670991477127615 139.7436610555036 51.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28859384-dbd0-4edb-ae8c-d9f0a209e803">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28859384-dbd0-4edb-ae8c-d9f0a209e803_0">
											<gml:posList>35.67109761103949 139.74368156034967 48.956 35.67109761103949 139.74368156034967 59.2 35.67108330318595 139.74367744501126 59.2 35.67108330318595 139.74367744501126 48.956 35.67109761103949 139.74368156034967 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2e44e76-948b-4e2e-ae2e-7709423c815c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2e44e76-948b-4e2e-ae2e-7709423c815c_0">
											<gml:posList>35.67099264877326 139.74369718678486 48.956 35.670998500158376 139.74366284820292 48.956 35.670998500158376 139.74366284820292 51.94 35.67099264877326 139.74369718678486 51.94 35.67099264877326 139.74369718678486 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-daeb8e68-ede7-48b2-86fe-53ac3bc23788">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-daeb8e68-ede7-48b2-86fe-53ac3bc23788_0">
											<gml:posList>35.67105813086932 139.74368151612535 48.956 35.67104879086808 139.74367912951092 48.956 35.67104879086808 139.74367912951092 51.94 35.67105813086932 139.74368151612535 51.94 35.67105813086932 139.74368151612535 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3fa7c27-a68e-4ab2-b92a-9bd395c99eb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3fa7c27-a68e-4ab2-b92a-9bd395c99eb2_0">
											<gml:posList>35.671003882485955 139.74366436657888 48.956 35.67099804902918 139.74369857258685 48.956 35.67099804902918 139.74369857258685 51.94 35.671003882485955 139.74366436657888 51.94 35.671003882485955 139.74366436657888 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1bea8b7-0ab4-45e5-81c4-4a8e20c4b526">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1bea8b7-0ab4-45e5-81c4-4a8e20c4b526_0">
											<gml:posList>35.671003882485955 139.74366436657888 51.94 35.67099804902918 139.74369857258685 51.94 35.671004756521526 139.74370028831794 51.94 35.67101058997879 139.7436660823073 51.94 35.671003882485955 139.74366436657888 51.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1ec38b9-818d-45f8-a93b-7fd7a2a7e940">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1ec38b9-818d-45f8-a93b-7fd7a2a7e940_0">
											<gml:posList>35.671004756521526 139.74370028831794 48.956 35.67101058997879 139.7436660823073 48.956 35.67101058997879 139.7436660823073 51.94 35.671004756521526 139.74370028831794 51.94 35.671004756521526 139.74370028831794 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29629df0-a86a-4c74-b12f-26a515955aa9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29629df0-a86a-4c74-b12f-26a515955aa9_0">
											<gml:posList>35.671011436972684 139.7437020040796 48.956 35.671011436972684 139.7437020040796 51.94 35.67101734222763 139.74366737822467 51.94 35.67101734222763 139.74366737822467 48.956 35.671011436972684 139.7437020040796 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58b6c7d3-3f58-4d6a-8b5c-866d3d11fed5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58b6c7d3-3f58-4d6a-8b5c-866d3d11fed5_0">
											<gml:posList>35.671025618412465 139.74366950091414 51.94 35.67101734222763 139.74366737822467 51.94 35.671011436972684 139.7437020040796 51.94 35.671019704143205 139.74370412678255 51.94 35.671025618412465 139.74366950091414 51.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6428d35d-1f6f-494f-96b6-29d9a16dcf24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6428d35d-1f6f-494f-96b6-29d9a16dcf24_0">
											<gml:posList>35.67102399549738 139.74370522662005 51.94 35.67103108163995 139.74370704134614 51.94 35.671036968942886 139.74367251492032 51.94 35.67102988279981 139.74367070019719 51.94 35.67102399549738 139.74370522662005 51.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38ae6f65-320a-4138-a562-68ffa29f37bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38ae6f65-320a-4138-a562-68ffa29f37bb_0">
											<gml:posList>35.67103108163995 139.74370704134614 48.956 35.671036968942886 139.74367251492032 48.956 35.671036968942886 139.74367251492032 51.94 35.67103108163995 139.74370704134614 51.94 35.67103108163995 139.74370704134614 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bbfebb3-8b71-4c87-95af-845f20b1d23d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7bbfebb3-8b71-4c87-95af-845f20b1d23d_0">
											<gml:posList>35.671078744808234 139.7436930033779 48.956 35.67107081112065 139.7436908471626 48.956 35.67107081112065 139.7436908471626 51.826 35.671078744808234 139.7436930033779 51.826 35.671078744808234 139.7436930033779 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed12118c-8d21-4197-940f-4c69873ce5b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed12118c-8d21-4197-940f-4c69873ce5b8_0">
											<gml:posList>35.67110118655117 139.74368971961093 48.956 35.671116323888725 139.7436941322768 48.956 35.671116323888725 139.7436941322768 59.2 35.67110118655117 139.74368971961093 59.2 35.67110118655117 139.74368971961093 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d973064-7f23-486e-8c76-a93b23ffa5f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d973064-7f23-486e-8c76-a93b23ffa5f0_0">
											<gml:posList>35.670972427128525 139.74369201761215 48.956 35.670980865584674 139.74369417326056 48.956 35.670980865584674 139.74369417326056 51.94 35.670972427128525 139.74369201761215 51.94 35.670972427128525 139.74369201761215 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c26dc32a-3fa9-40a8-b905-946c6e7edbe1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c26dc32a-3fa9-40a8-b905-946c6e7edbe1_0">
											<gml:posList>35.670985625742986 139.74369539408264 48.956 35.67099264877326 139.74369718678486 48.956 35.67099264877326 139.74369718678486 51.94 35.670985625742986 139.74369539408264 51.94 35.670985625742986 139.74369539408264 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40df8906-a201-48c8-bfe5-e8ec6046b458">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40df8906-a201-48c8-bfe5-e8ec6046b458_0">
											<gml:posList>35.67104879086808 139.74367912951092 48.956 35.67104216764433 139.7437179648408 48.956 35.67104216764433 139.7437179648408 51.94 35.67104879086808 139.74367912951092 51.94 35.67104879086808 139.74367912951092 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-985e1f15-ace9-47e9-a4f7-48de0b0636cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-985e1f15-ace9-47e9-a4f7-48de0b0636cc_0">
											<gml:posList>35.67107081112065 139.7436908471626 48.956 35.67106502756558 139.74370733478943 48.956 35.67106502756558 139.74370733478943 51.826 35.67107081112065 139.7436908471626 51.826 35.67107081112065 139.7436908471626 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8eb1603d-f725-408d-a26f-2d5b787df1ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8eb1603d-f725-408d-a26f-2d5b787df1ce_0">
											<gml:posList>35.67099804902918 139.74369857258685 48.956 35.671004756521526 139.74370028831794 48.956 35.671004756521526 139.74370028831794 51.94 35.67099804902918 139.74369857258685 51.94 35.67099804902918 139.74369857258685 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-159dbe8a-75c9-455a-bf06-c5aa3d4ab943">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-159dbe8a-75c9-455a-bf06-c5aa3d4ab943_0">
											<gml:posList>35.67104216764433 139.7437179648408 51.94 35.67105150765303 139.7437203625059 51.94 35.67105813086932 139.74368151612535 51.94 35.67104879086808 139.74367912951092 51.94 35.67104216764433 139.7437179648408 51.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97db8775-125e-4cc9-ba65-07e09fb9ba15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97db8775-125e-4cc9-ba65-07e09fb9ba15_0">
											<gml:posList>35.67105150765303 139.7437203625059 48.956 35.67105813086932 139.74368151612535 48.956 35.67105813086932 139.74368151612535 51.94 35.67105150765303 139.7437203625059 51.94 35.67105150765303 139.7437203625059 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60922e3a-fea5-495c-a745-ccb666755f62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60922e3a-fea5-495c-a745-ccb666755f62_0">
											<gml:posList>35.671011436972684 139.7437020040796 48.956 35.671019704143205 139.74370412678255 48.956 35.671019704143205 139.74370412678255 51.94 35.671011436972684 139.7437020040796 51.94 35.671011436972684 139.7437020040796 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa01b28f-4069-4266-9eaa-86be0e2cc001">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa01b28f-4069-4266-9eaa-86be0e2cc001_0">
											<gml:posList>35.670983705440115 139.74370699488964 48.956 35.67095826353476 139.74370006413662 48.956 35.67095826353476 139.74370006413662 59.2 35.670983705440115 139.74370699488964 59.2 35.670983705440115 139.74370699488964 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4b7c67b-b6a6-4eea-a409-fd3880f0b148">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4b7c67b-b6a6-4eea-a409-fd3880f0b148_0">
											<gml:posList>35.67102399549738 139.74370522662005 48.956 35.67103108163995 139.74370704134614 48.956 35.67103108163995 139.74370704134614 51.94 35.67102399549738 139.74370522662005 51.94 35.67102399549738 139.74370522662005 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b1cc609-e679-4c1c-99db-8cd5c9f319ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b1cc609-e679-4c1c-99db-8cd5c9f319ab_0">
											<gml:posList>35.671118751143744 139.74370968284003 48.956 35.67110383044854 139.7437056896906 48.956 35.67110383044854 139.7437056896906 51.826 35.671118751143744 139.74370968284003 51.826 35.671118751143744 139.74370968284003 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32a05e12-e42a-44c6-8af2-0a50c3a2b1c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32a05e12-e42a-44c6-8af2-0a50c3a2b1c1_0">
											<gml:posList>35.671012645392835 139.7437148938155 48.956 35.67098761820149 139.74370807305732 48.956 35.67098761820149 139.74370807305732 59.2 35.671012645392835 139.7437148938155 59.2 35.671012645392835 139.7437148938155 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b3a30be-5212-493d-aee9-02fc4f0de5b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b3a30be-5212-493d-aee9-02fc4f0de5b0_0">
											<gml:posList>35.67107113252005 139.7437351316403 51.826 35.671078744808234 139.7436930033779 51.826 35.67107081112065 139.7436908471626 51.826 35.67106502756558 139.74370733478943 51.826 35.671060521215125 139.74373224935408 51.826 35.67107113252005 139.7437351316403 51.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f3ba795-53b7-4c62-afed-2b3f4e7756ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f3ba795-53b7-4c62-afed-2b3f4e7756ff_0">
											<gml:posList>35.67095826353476 139.74370006413662 48.956 35.67095350577964 139.74372629346382 48.956 35.67095350577964 139.74372629346382 59.2 35.67095826353476 139.74370006413662 59.2 35.67095826353476 139.74370006413662 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0319deb9-e0c0-47db-a0c2-bd71059d0b0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0319deb9-e0c0-47db-a0c2-bd71059d0b0d_0">
											<gml:posList>35.67107113252005 139.7437351316403 48.956 35.671078744808234 139.7436930033779 48.956 35.671078744808234 139.7436930033779 51.826 35.67107113252005 139.7437351316403 51.826 35.67107113252005 139.7437351316403 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-921c5e4a-3b04-499c-8398-76d07f2bd543">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-921c5e4a-3b04-499c-8398-76d07f2bd543_0">
											<gml:posList>35.67095350577964 139.74372629346382 59.2 35.67097893866981 139.74373322423483 59.2 35.670983705440115 139.74370699488964 59.2 35.67095826353476 139.74370006413662 59.2 35.67095350577964 139.74372629346382 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d858679-e91a-4a68-9368-2a5b2c19bc3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d858679-e91a-4a68-9368-2a5b2c19bc3f_0">
											<gml:posList>35.671026727696656 139.74371873325038 48.956 35.671016017207435 139.7437158068934 48.956 35.671016017207435 139.7437158068934 59.2 35.671026727696656 139.74371873325038 59.2 35.671026727696656 139.74371873325038 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b013d394-fe6a-4485-8025-42375018db34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b013d394-fe6a-4485-8025-42375018db34_0">
											<gml:posList>35.67104216764433 139.7437179648408 48.956 35.67105150765303 139.7437203625059 48.956 35.67105150765303 139.7437203625059 51.94 35.67104216764433 139.7437179648408 51.94 35.67104216764433 139.7437179648408 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-475f202c-6402-4f6d-a864-e020516c2aa8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-475f202c-6402-4f6d-a864-e020516c2aa8_0">
											<gml:posList>35.67110383044854 139.7437056896906 48.956 35.67109897433056 139.74373297962543 48.956 35.67109897433056 139.74373297962543 51.826 35.67110383044854 139.7437056896906 51.826 35.67110383044854 139.7437056896906 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d88a5bf0-26ec-49b2-890c-199b923e9b92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d88a5bf0-26ec-49b2-890c-199b923e9b92_0">
											<gml:posList>35.67106502756558 139.74370733478943 48.956 35.671060521215125 139.74373224935408 48.956 35.671060521215125 139.74373224935408 51.826 35.67106502756558 139.74370733478943 51.826 35.67106502756558 139.74370733478943 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c1d3ea1-c6ad-4111-b0e4-1cb36bd38425">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c1d3ea1-c6ad-4111-b0e4-1cb36bd38425_0">
											<gml:posList>35.67097893866981 139.74373322423483 48.956 35.670983705440115 139.74370699488964 48.956 35.670983705440115 139.74370699488964 59.2 35.67097893866981 139.74373322423483 59.2 35.67097893866981 139.74373322423483 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-443f7d8c-801e-4a68-9ea1-0da0ccdde3f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-443f7d8c-801e-4a68-9ea1-0da0ccdde3f7_0">
											<gml:posList>35.671118751143744 139.74370968284003 51.826 35.67110383044854 139.7437056896906 51.826 35.67109897433056 139.74373297962543 51.826 35.67111389501665 139.74373696173336 51.826 35.671118751143744 139.74370968284003 51.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9614ecbd-026e-49d2-ba52-c6d7fbc9f5ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9614ecbd-026e-49d2-ba52-c6d7fbc9f5ea_0">
											<gml:posList>35.67111389501665 139.74373696173336 48.956 35.671118751143744 139.74370968284003 48.956 35.671118751143744 139.74370968284003 51.826 35.67111389501665 139.74373696173336 51.826 35.67111389501665 139.74373696173336 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53596718-6d30-4d78-86cf-19729433fb63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53596718-6d30-4d78-86cf-19729433fb63_0">
											<gml:posList>35.67100788763457 139.7437411231596 59.2 35.671012645392835 139.7437148938155 59.2 35.67098761820149 139.74370807305732 59.2 35.67098286043647 139.7437342913473 59.2 35.67100788763457 139.7437411231596 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5ccdde1-9b1b-40a6-8866-9b943eefca14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5ccdde1-9b1b-40a6-8866-9b943eefca14_0">
											<gml:posList>35.671016017207435 139.7437158068934 48.956 35.671011250435264 139.7437420362486 48.956 35.671011250435264 139.7437420362486 59.2 35.671016017207435 139.7437158068934 59.2 35.671016017207435 139.7437158068934 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00893112-0a02-4a89-8c3e-848d4f428773">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00893112-0a02-4a89-8c3e-848d4f428773_0">
											<gml:posList>35.67095350577964 139.74372629346382 48.956 35.67097893866981 139.74373322423483 48.956 35.67097893866981 139.74373322423483 59.2 35.67095350577964 139.74372629346382 59.2 35.67095350577964 139.74372629346382 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4326fbf-66e0-432f-8863-835c8ead9421">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4326fbf-66e0-432f-8863-835c8ead9421_0">
											<gml:posList>35.671011250435264 139.7437420362486 59.2 35.67102196993759 139.74374496259884 59.2 35.671026727696656 139.74371873325038 59.2 35.671016017207435 139.7437158068934 59.2 35.671011250435264 139.7437420362486 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e10bec86-211b-4a57-b0db-2e5d1af23cb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e10bec86-211b-4a57-b0db-2e5d1af23cb9_0">
											<gml:posList>35.67102196993759 139.74374496259884 48.956 35.671026727696656 139.74371873325038 48.956 35.671026727696656 139.74371873325038 59.2 35.67102196993759 139.74374496259884 59.2 35.67102196993759 139.74374496259884 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f981fe8-765f-46d3-a1e3-f72890062060">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f981fe8-765f-46d3-a1e3-f72890062060_0">
											<gml:posList>35.671060521215125 139.74373224935408 48.956 35.67107113252005 139.7437351316403 48.956 35.67107113252005 139.7437351316403 51.826 35.671060521215125 139.74373224935408 51.826 35.671060521215125 139.74373224935408 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-531b1530-fd28-435a-a6dd-8480c053e0b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-531b1530-fd28-435a-a6dd-8480c053e0b0_0">
											<gml:posList>35.67109897433056 139.74373297962543 48.956 35.67111389501665 139.74373696173336 48.956 35.67111389501665 139.74373696173336 51.826 35.67109897433056 139.74373297962543 51.826 35.67109897433056 139.74373297962543 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55a5aef3-fec4-4ba9-988c-746e9b48df99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55a5aef3-fec4-4ba9-988c-746e9b48df99_0">
											<gml:posList>35.67100788763457 139.7437411231596 48.956 35.67100788763457 139.7437411231596 59.2 35.67098286043647 139.7437342913473 59.2 35.67098286043647 139.7437342913473 48.956 35.67100788763457 139.7437411231596 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9536d0e-7fcf-46d7-b534-1e5fa8372047">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9536d0e-7fcf-46d7-b534-1e5fa8372047_0">
											<gml:posList>35.67097648458939 139.74374218556065 48.956 35.67095166475615 139.743735419797 48.956 35.67095166475615 139.743735419797 59.2 35.67097648458939 139.74374218556065 59.2 35.67097648458939 139.74374218556065 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c162d6a4-e955-42ad-b821-66db63299b50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c162d6a4-e955-42ad-b821-66db63299b50_0">
											<gml:posList>35.671011250435264 139.7437420362486 48.956 35.67102196993759 139.74374496259884 48.956 35.67102196993759 139.74374496259884 59.2 35.671011250435264 139.7437420362486 59.2 35.671011250435264 139.7437420362486 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c70e7080-d8a4-47cc-9ac1-bb107c13fef8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c70e7080-d8a4-47cc-9ac1-bb107c13fef8_0">
											<gml:posList>35.67100586630264 139.74375020551471 48.956 35.670981569372735 139.74374358276427 48.956 35.670981569372735 139.74374358276427 59.2 35.67100586630264 139.74375020551471 59.2 35.67100586630264 139.74375020551471 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9df16fd3-9589-462f-b582-7029dc1951d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9df16fd3-9589-462f-b582-7029dc1951d9_0">
											<gml:posList>35.67102920758029 139.7437565642245 48.956 35.671009580712415 139.74375121762833 48.956 35.671009580712415 139.74375121762833 59.2 35.67102920758029 139.7437565642245 59.2 35.67102920758029 139.7437565642245 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9831fb2-2016-452d-97b3-0b9793765ccc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9831fb2-2016-452d-97b3-0b9793765ccc_0">
											<gml:posList>35.67093946504635 139.7438025730656 48.956 35.67093946504635 139.7438025730656 59.2 35.67095166475615 139.743735419797 59.2 35.67095166475615 139.743735419797 48.956 35.67093946504635 139.7438025730656 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b02f1e0-36bc-4c6a-9554-7389f88deedb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b02f1e0-36bc-4c6a-9554-7389f88deedb_0">
											<gml:posList>35.67095166475615 139.743735419797 59.2 35.67093946504635 139.7438025730656 59.2 35.670964293897825 139.7438093498853 59.2 35.67097648458939 139.74374218556065 59.2 35.67095166475615 139.743735419797 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3074dc73-9842-49c3-938f-e3eca6e1b3ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3074dc73-9842-49c3-938f-e3eca6e1b3ac_0">
											<gml:posList>35.67097648458939 139.74374218556065 48.956 35.67097648458939 139.74374218556065 59.2 35.670964293897825 139.7438093498853 59.2 35.670964293897825 139.7438093498853 48.956 35.67097648458939 139.74374218556065 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b65a7ee-8765-42fd-bd60-6cb3f1d2a3cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b65a7ee-8765-42fd-bd60-6cb3f1d2a3cd_0">
											<gml:posList>35.6709693786722 139.7438107360466 48.956 35.6709693786722 139.7438107360466 59.2 35.670981569372735 139.74374358276427 59.2 35.670981569372735 139.74374358276427 48.956 35.6709693786722 139.7438107360466 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53b69e7b-876c-4013-bc14-ea0f08fe1702">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53b69e7b-876c-4013-bc14-ea0f08fe1702_0">
											<gml:posList>35.670981569372735 139.74374358276427 59.2 35.6709693786722 139.7438107360466 59.2 35.67099366658478 139.7438173588265 59.2 35.67100586630264 139.74375020551471 59.2 35.670981569372735 139.74374358276427 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65df1662-08d6-4e49-a891-830f4087448a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65df1662-08d6-4e49-a891-830f4087448a_0">
											<gml:posList>35.670997390007706 139.74381837093304 59.2 35.67101700786716 139.74382372860123 59.2 35.67102920758029 139.7437565642245 59.2 35.671009580712415 139.74375121762833 59.2 35.670997390007706 139.74381837093304 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3d25fcd-0e6e-4d85-8b17-97d8f679e906">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3d25fcd-0e6e-4d85-8b17-97d8f679e906_0">
											<gml:posList>35.67101700786716 139.74382372860123 48.956 35.67102920758029 139.7437565642245 48.956 35.67102920758029 139.7437565642245 59.2 35.67101700786716 139.74382372860123 59.2 35.67101700786716 139.74382372860123 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-126b8c56-5779-4a59-8212-c7e1a0dbc996">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-126b8c56-5779-4a59-8212-c7e1a0dbc996_0">
											<gml:posList>35.670964293897825 139.7438093498853 59.2 35.67093946504635 139.7438025730656 59.2 35.67093946504635 139.7438025730656 48.956 35.670964293897825 139.7438093498853 48.956 35.670964293897825 139.7438093498853 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a07df6c-3e88-4954-9a9e-ad783ad7c3f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a07df6c-3e88-4954-9a9e-ad783ad7c3f7_0">
											<gml:posList>35.67107498570431 139.7438136558755 48.956 35.671050968170675 139.74380698860276 48.956 35.671050968170675 139.74380698860276 51.94 35.67107498570431 139.7438136558755 51.94 35.67107498570431 139.7438136558755 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bd18469-a41b-4a65-a9a0-37c383af9f12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bd18469-a41b-4a65-a9a0-37c383af9f12_0">
											<gml:posList>35.6709693786722 139.7438107360466 48.956 35.67099366658478 139.7438173588265 48.956 35.67099366658478 139.7438173588265 59.2 35.6709693786722 139.7438107360466 59.2 35.6709693786722 139.7438107360466 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f58b94c-142e-4124-bbb0-32c5da736dd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f58b94c-142e-4124-bbb0-32c5da736dd4_0">
											<gml:posList>35.67101700786716 139.74382372860123 48.956 35.67101700786716 139.74382372860123 59.2 35.670997390007706 139.74381837093304 59.2 35.670997390007706 139.74381837093304 48.956 35.67101700786716 139.74382372860123 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e9426bc-f69a-47aa-a8c8-60f9151277ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e9426bc-f69a-47aa-a8c8-60f9151277ca_0">
											<gml:posList>35.67104573416761 139.7438352399679 48.956 35.67104573416761 139.7438352399679 51.94 35.671050968170675 139.74380698860276 51.94 35.671050968170675 139.74380698860276 48.956 35.67104573416761 139.7438352399679 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cde5a9f-5463-4b82-a185-9b8946776572">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cde5a9f-5463-4b82-a185-9b8946776572_0">
											<gml:posList>35.67106975170792 139.74384191829503 51.94 35.67107498570431 139.7438136558755 51.94 35.671050968170675 139.74380698860276 51.94 35.67104573416761 139.7438352399679 51.94 35.67106975170792 139.74384191829503 51.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03b0b90f-e7e8-47d6-bef2-58b4749f551f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03b0b90f-e7e8-47d6-bef2-58b4749f551f_0">
											<gml:posList>35.67106975170792 139.74384191829503 48.956 35.67107498570431 139.7438136558755 48.956 35.67107498570431 139.7438136558755 51.94 35.67106975170792 139.74384191829503 51.94 35.67106975170792 139.74384191829503 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fee29a5-93b5-44c0-a807-122af90e552f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1fee29a5-93b5-44c0-a807-122af90e552f_0">
											<gml:posList>35.67104573416761 139.7438352399679 48.956 35.67106975170792 139.74384191829503 48.956 35.67106975170792 139.74384191829503 51.94 35.67104573416761 139.7438352399679 51.94 35.67104573416761 139.7438352399679 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f3643bed-9b79-4f94-a3d4-aa20a12e696d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3643bed-9b79-4f94-a3d4-aa20a12e696d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3643bed-9b79-4f94-a3d4-aa20a12e696d">
											<gml:posList>35.670981368921524 139.74352289915606 7.01 35.67118339624103 139.7434418134187 7.01 35.67110295183189 139.74386961864556 7.01 35.67092597132669 139.74381447399017 7.01 35.670981368921524 139.74352289915606 7.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ab5c6c1-15a1-46e3-8ece-33472c3d9b9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ab5c6c1-15a1-46e3-8ece-33472c3d9b9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ab5c6c1-15a1-46e3-8ece-33472c3d9b9b">
											<gml:posList>35.670981368921524 139.74352289915606 59.2 35.6709856810895 139.74352773262402 59.2 35.67117641758243 139.74345116647166 59.2 35.67118339624103 139.7434418134187 59.2 35.670981368921524 139.74352289915606 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-51d8d286-bee0-4464-b58e-e9a73e1c7f7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51d8d286-bee0-4464-b58e-e9a73e1c7f7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51d8d286-bee0-4464-b58e-e9a73e1c7f7b">
											<gml:posList>35.671124912598366 139.74375284513664 59.2 35.67118339624103 139.7434418134187 59.2 35.67117641758243 139.74345116647166 59.2 35.6711210942218 139.74374535996958 59.2 35.671124912598366 139.74375284513664 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-455d6310-924f-4467-b166-4ba2504bdca8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-455d6310-924f-4467-b166-4ba2504bdca8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-455d6310-924f-4467-b166-4ba2504bdca8">
											<gml:posList>35.671090567322175 139.74373674478232 48.956 35.6711210942218 139.74374535996958 48.956 35.67117641758243 139.74345116647166 48.956 35.6709856810895 139.74352773262402 48.956 35.67093206122792 139.7438099271466 48.956 35.67109916039703 139.7438619898423 48.956 35.671108587572334 139.74381188407887 48.956 35.671078628927894 139.74380378741176 48.956 35.671090567322175 139.74373674478232 48.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c442fd0d-91f7-43a0-9c71-7160affba190">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c442fd0d-91f7-43a0-9c71-7160affba190">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c442fd0d-91f7-43a0-9c71-7160affba190">
											<gml:posList>35.670981368921524 139.74352289915606 59.2 35.67092597132669 139.74381447399017 59.2 35.67093206122792 139.7438099271466 59.2 35.6709856810895 139.74352773262402 59.2 35.670981368921524 139.74352289915606 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ae2e07ca-1afb-474a-8f29-ccfc4a1a46f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae2e07ca-1afb-474a-8f29-ccfc4a1a46f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae2e07ca-1afb-474a-8f29-ccfc4a1a46f0">
											<gml:posList>35.67109443978984 139.74374424093202 59.2 35.671124912598366 139.74375284513664 59.2 35.6711210942218 139.74374535996958 59.2 35.671090567322175 139.74373674478232 59.2 35.67109443978984 139.74374424093202 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0da5b4b8-e33a-4923-8110-48ae42134a52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0da5b4b8-e33a-4923-8110-48ae42134a52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0da5b4b8-e33a-4923-8110-48ae42134a52">
											<gml:posList>35.67109443978984 139.74374424093202 59.2 35.671090567322175 139.74373674478232 59.2 35.671078628927894 139.74380378741176 59.2 35.67108468263404 139.74379905281106 59.2 35.67109443978984 139.74374424093202 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-07b3fe33-c9d8-4407-aec8-b24ca4990419">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07b3fe33-c9d8-4407-aec8-b24ca4990419">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07b3fe33-c9d8-4407-aec8-b24ca4990419">
											<gml:posList>35.671124912598366 139.74375284513664 49.23 35.67109443978984 139.74374424093202 49.23 35.67108468263404 139.74379905281106 49.23 35.67111469536931 139.74380716046295 49.23 35.671124912598366 139.74375284513664 49.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17cd6f87-b8e0-494c-b0ea-e1b80a5e7fa8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17cd6f87-b8e0-494c-b0ea-e1b80a5e7fa8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17cd6f87-b8e0-494c-b0ea-e1b80a5e7fa8">
											<gml:posList>35.67108468263404 139.74379905281106 59.2 35.671078628927894 139.74380378741176 59.2 35.671108587572334 139.74381188407887 59.2 35.67111469536931 139.74380716046295 59.2 35.67108468263404 139.74379905281106 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9730b3a0-a5f0-460b-9eec-26433aaa3b08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9730b3a0-a5f0-460b-9eec-26433aaa3b08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9730b3a0-a5f0-460b-9eec-26433aaa3b08">
											<gml:posList>35.67111469536931 139.74380716046295 59.2 35.671108587572334 139.74381188407887 59.2 35.67109916039703 139.7438619898423 59.2 35.67110295183189 139.74386961864556 59.2 35.67111469536931 139.74380716046295 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e27f296-c988-4df8-9e31-8ae8ba154110">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e27f296-c988-4df8-9e31-8ae8ba154110">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e27f296-c988-4df8-9e31-8ae8ba154110">
											<gml:posList>35.67110295183189 139.74386961864556 59.2 35.67109916039703 139.7438619898423 59.2 35.67093206122792 139.7438099271466 59.2 35.67092597132669 139.74381447399017 59.2 35.67110295183189 139.74386961864556 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7978a0c3-9247-4564-b3dc-c7e53effee1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7978a0c3-9247-4564-b3dc-c7e53effee1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7978a0c3-9247-4564-b3dc-c7e53effee1b">
											<gml:posList>35.671078628927894 139.74380378741176 59.2 35.671078628927894 139.74380378741176 48.956 35.671108587572334 139.74381188407887 48.956 35.671108587572334 139.74381188407887 59.2 35.671078628927894 139.74380378741176 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccfdfa2c-2ae0-4a7e-bab1-e9575759a8be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccfdfa2c-2ae0-4a7e-bab1-e9575759a8be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccfdfa2c-2ae0-4a7e-bab1-e9575759a8be">
											<gml:posList>35.67118339624103 139.7434418134187 7.01 35.670981368921524 139.74352289915606 7.01 35.670981368921524 139.74352289915606 59.2 35.67118339624103 139.7434418134187 59.2 35.67118339624103 139.7434418134187 7.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b7bc5ef-de24-4557-9a92-57864044e85f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b7bc5ef-de24-4557-9a92-57864044e85f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b7bc5ef-de24-4557-9a92-57864044e85f">
											<gml:posList>35.6709856810895 139.74352773262402 59.2 35.6709856810895 139.74352773262402 48.956 35.67117641758243 139.74345116647166 48.956 35.67117641758243 139.74345116647166 59.2 35.6709856810895 139.74352773262402 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d68339f0-af56-492a-a8f3-a7a6a3b34e5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d68339f0-af56-492a-a8f3-a7a6a3b34e5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d68339f0-af56-492a-a8f3-a7a6a3b34e5c">
											<gml:posList>35.67117641758243 139.74345116647166 59.2 35.67117641758243 139.74345116647166 48.956 35.6711210942218 139.74374535996958 48.956 35.6711210942218 139.74374535996958 59.2 35.67117641758243 139.74345116647166 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e9fa15a-c890-46e7-b083-35fc7429827d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e9fa15a-c890-46e7-b083-35fc7429827d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e9fa15a-c890-46e7-b083-35fc7429827d">
											<gml:posList>35.67118339624103 139.7434418134187 59.2 35.671124912598366 139.74375284513664 59.2 35.671124912598366 139.74375284513664 49.23 35.67111469536931 139.74380716046295 49.23 35.67111469536931 139.74380716046295 59.2 35.67110295183189 139.74386961864556 59.2 35.67110295183189 139.74386961864556 7.01 35.67118339624103 139.7434418134187 7.01 35.67118339624103 139.7434418134187 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dff4b50b-c776-4a58-9944-3f112197985f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dff4b50b-c776-4a58-9944-3f112197985f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dff4b50b-c776-4a58-9944-3f112197985f">
											<gml:posList>35.670981368921524 139.74352289915606 7.01 35.67092597132669 139.74381447399017 7.01 35.67092597132669 139.74381447399017 59.2 35.670981368921524 139.74352289915606 59.2 35.670981368921524 139.74352289915606 7.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85cfb452-eb1c-468b-a158-ca42105a3780">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85cfb452-eb1c-468b-a158-ca42105a3780">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85cfb452-eb1c-468b-a158-ca42105a3780">
											<gml:posList>35.67093206122792 139.7438099271466 59.2 35.67093206122792 139.7438099271466 48.956 35.6709856810895 139.74352773262402 48.956 35.6709856810895 139.74352773262402 59.2 35.67093206122792 139.7438099271466 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69025ade-6a7a-470a-aa4c-674e6639c52e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69025ade-6a7a-470a-aa4c-674e6639c52e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69025ade-6a7a-470a-aa4c-674e6639c52e">
											<gml:posList>35.6711210942218 139.74374535996958 59.2 35.6711210942218 139.74374535996958 48.956 35.671090567322175 139.74373674478232 48.956 35.671090567322175 139.74373674478232 59.2 35.6711210942218 139.74374535996958 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-538eaf5f-7da2-4faf-adec-ef46e5740b9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-538eaf5f-7da2-4faf-adec-ef46e5740b9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-538eaf5f-7da2-4faf-adec-ef46e5740b9c">
											<gml:posList>35.671124912598366 139.74375284513664 59.2 35.67109443978984 139.74374424093202 59.2 35.67109443978984 139.74374424093202 49.23 35.671124912598366 139.74375284513664 49.23 35.671124912598366 139.74375284513664 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ed6ce90-acb0-4428-ac90-837ac0cb0122">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ed6ce90-acb0-4428-ac90-837ac0cb0122">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ed6ce90-acb0-4428-ac90-837ac0cb0122">
											<gml:posList>35.671090567322175 139.74373674478232 59.2 35.671090567322175 139.74373674478232 48.956 35.671078628927894 139.74380378741176 48.956 35.671078628927894 139.74380378741176 59.2 35.671090567322175 139.74373674478232 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aaafbcaa-b933-40f9-b5e7-a1ddaa93284a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aaafbcaa-b933-40f9-b5e7-a1ddaa93284a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aaafbcaa-b933-40f9-b5e7-a1ddaa93284a">
											<gml:posList>35.67109443978984 139.74374424093202 59.2 35.67108468263404 139.74379905281106 59.2 35.67108468263404 139.74379905281106 49.23 35.67109443978984 139.74374424093202 49.23 35.67109443978984 139.74374424093202 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-808bb9da-6aef-46bb-9707-06cfed421cff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-808bb9da-6aef-46bb-9707-06cfed421cff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-808bb9da-6aef-46bb-9707-06cfed421cff">
											<gml:posList>35.67108468263404 139.74379905281106 59.2 35.67111469536931 139.74380716046295 59.2 35.67111469536931 139.74380716046295 49.23 35.67108468263404 139.74379905281106 49.23 35.67108468263404 139.74379905281106 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8ef58e1-d200-452f-8bfb-54f54a559a26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8ef58e1-d200-452f-8bfb-54f54a559a26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8ef58e1-d200-452f-8bfb-54f54a559a26">
											<gml:posList>35.67109916039703 139.7438619898423 59.2 35.67109916039703 139.7438619898423 48.956 35.67093206122792 139.7438099271466 48.956 35.67093206122792 139.7438099271466 59.2 35.67109916039703 139.7438619898423 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7eeb92d5-bcbc-4a90-b5eb-40b3c7e3d8dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7eeb92d5-bcbc-4a90-b5eb-40b3c7e3d8dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7eeb92d5-bcbc-4a90-b5eb-40b3c7e3d8dd">
											<gml:posList>35.671108587572334 139.74381188407887 59.2 35.671108587572334 139.74381188407887 48.956 35.67109916039703 139.7438619898423 48.956 35.67109916039703 139.7438619898423 59.2 35.671108587572334 139.74381188407887 59.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5359bd38-161a-4fff-9cf5-8973bd1df397">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5359bd38-161a-4fff-9cf5-8973bd1df397">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5359bd38-161a-4fff-9cf5-8973bd1df397">
											<gml:posList>35.67092597132669 139.74381447399017 7.01 35.67110295183189 139.74386961864556 7.01 35.67110295183189 139.74386961864556 59.2 35.67092597132669 139.74381447399017 59.2 35.67092597132669 139.74381447399017 7.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10027</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">692.67948</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.59</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>