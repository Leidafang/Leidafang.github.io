<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b1663599-0ffb-4bba-b888-270c5d5e4945">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>8</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101008003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">38.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>3</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671287647409414 139.7436330199174 0 35.6712225361364 139.74395343766344 0 35.671505801743926 139.74390506996934 0 35.671466623998896 139.743826794626 0 35.67141264956171 139.7437295360811 0 35.6713439755191 139.7436226837519 0 35.671326314796026 139.74363098830577 0 35.67130648674693 139.74363388255082 0 35.671287647409414 139.7436330199174 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671287647409414 139.7436330199174 6.74 35.67130648674693 139.74363388255082 6.74 35.671326314796026 139.74363098830577 6.74 35.6713439755191 139.7436226837519 6.74 35.67141264956171 139.7437295360811 6.74 35.671466623998896 139.743826794626 6.74 35.671505801743926 139.74390506996934 6.74 35.6712225361364 139.74395343766344 6.74 35.671287647409414 139.7436330199174 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671287647409414 139.7436330199174 6.74 35.6712225361364 139.74395343766344 6.74 35.6712225361364 139.74395343766344 44.85 35.671287647409414 139.7436330199174 44.85 35.671287647409414 139.7436330199174 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6712225361364 139.74395343766344 6.74 35.671505801743926 139.74390506996934 6.74 35.671505801743926 139.74390506996934 44.85 35.6712225361364 139.74395343766344 44.85 35.6712225361364 139.74395343766344 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671505801743926 139.74390506996934 6.74 35.671466623998896 139.743826794626 6.74 35.671466623998896 139.743826794626 44.85 35.671505801743926 139.74390506996934 44.85 35.671505801743926 139.74390506996934 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671466623998896 139.743826794626 6.74 35.67141264956171 139.7437295360811 6.74 35.67141264956171 139.7437295360811 44.85 35.671466623998896 139.743826794626 44.85 35.671466623998896 139.743826794626 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67141264956171 139.7437295360811 6.74 35.6713439755191 139.7436226837519 6.74 35.6713439755191 139.7436226837519 44.85 35.67141264956171 139.7437295360811 44.85 35.67141264956171 139.7437295360811 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6713439755191 139.7436226837519 6.74 35.671326314796026 139.74363098830577 6.74 35.671326314796026 139.74363098830577 44.85 35.6713439755191 139.7436226837519 44.85 35.6713439755191 139.7436226837519 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671326314796026 139.74363098830577 6.74 35.67130648674693 139.74363388255082 6.74 35.67130648674693 139.74363388255082 44.85 35.671326314796026 139.74363098830577 44.85 35.671326314796026 139.74363098830577 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67130648674693 139.74363388255082 6.74 35.671287647409414 139.7436330199174 6.74 35.671287647409414 139.7436330199174 44.85 35.67130648674693 139.74363388255082 44.85 35.67130648674693 139.74363388255082 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671287647409414 139.7436330199174 44.85 35.6712225361364 139.74395343766344 44.85 35.671505801743926 139.74390506996934 44.85 35.671466623998896 139.743826794626 44.85 35.67141264956171 139.7437295360811 44.85 35.6713439755191 139.7436226837519 44.85 35.671326314796026 139.74363098830577 44.85 35.67130648674693 139.74363388255082 44.85 35.671287647409414 139.7436330199174 44.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c8ffb959-7008-45ca-914e-95673e567d99"/>
							<gml:surfaceMember xlink:href="#poly-b1cf85e3-1c01-4574-ad30-d19915b409c9"/>
							<gml:surfaceMember xlink:href="#poly-3a70c234-4681-423a-a845-2a86946c94d8"/>
							<gml:surfaceMember xlink:href="#poly-fcdf3974-3fb1-45aa-aac5-dc256e7e0b2d"/>
							<gml:surfaceMember xlink:href="#poly-17ce6408-e2c9-4aab-91bc-4ffb765277b1"/>
							<gml:surfaceMember xlink:href="#poly-045cfede-911d-4ac4-a619-62e009df7b52"/>
							<gml:surfaceMember xlink:href="#poly-5ba0bbe8-b11c-4c48-90a1-81ed7e90c836"/>
							<gml:surfaceMember xlink:href="#poly-8d5c7243-3290-4196-9cb1-1835afc0454a"/>
							<gml:surfaceMember xlink:href="#poly-b081b9b8-8653-40b7-948e-03fe5e098cd9"/>
							<gml:surfaceMember xlink:href="#poly-d10c77a2-1250-42d0-b000-fd84cff9d0cb"/>
							<gml:surfaceMember xlink:href="#poly-96800bd0-fb48-409f-98fd-9eefb8895228"/>
							<gml:surfaceMember xlink:href="#poly-555f6175-4cac-44c2-9295-145a73650e55"/>
							<gml:surfaceMember xlink:href="#poly-aaed62a0-2d91-4a84-93c8-1f5784b358ae"/>
							<gml:surfaceMember xlink:href="#poly-7cc9c21c-770f-4a14-9ce4-652a67230fdd"/>
							<gml:surfaceMember xlink:href="#poly-8b320f7b-925e-46fd-9594-d69dca20c9ba"/>
							<gml:surfaceMember xlink:href="#poly-39e03f0b-e79f-4946-8416-9030316625e3"/>
							<gml:surfaceMember xlink:href="#poly-1979946f-5dc6-43a5-9eb9-9b6e863cbc5c"/>
							<gml:surfaceMember xlink:href="#poly-2e6c7c9c-030c-47eb-b8fe-44a5d51d8b96"/>
							<gml:surfaceMember xlink:href="#poly-4694a7ae-2fdf-4bb1-9c81-0c22d04eaba0"/>
							<gml:surfaceMember xlink:href="#poly-282d3986-03ac-46d1-95df-772935e6b021"/>
							<gml:surfaceMember xlink:href="#poly-73f98225-54d8-43c8-8e87-e3eb298750eb"/>
							<gml:surfaceMember xlink:href="#poly-1170a030-c44c-46da-bb65-42ade49c75b9"/>
							<gml:surfaceMember xlink:href="#poly-746a0ea5-21c9-46bb-9882-6620aca69c3a"/>
							<gml:surfaceMember xlink:href="#poly-d7adb551-8ef0-45bf-96d8-1253fb14c1e5"/>
							<gml:surfaceMember xlink:href="#poly-2a14dbb7-e863-4e3a-82c9-b9de5206f71c"/>
							<gml:surfaceMember xlink:href="#poly-a5eea2c5-281c-49e5-aea9-30be20e94632"/>
							<gml:surfaceMember xlink:href="#poly-1e774596-edf0-4967-88cb-b34d5646a557"/>
							<gml:surfaceMember xlink:href="#poly-a61d9159-c5ff-43d7-a576-1893f062ea18"/>
							<gml:surfaceMember xlink:href="#poly-c0b05933-836d-468f-ad96-21a67dd10b18"/>
							<gml:surfaceMember xlink:href="#poly-9e756986-081b-448c-87d1-ce5f6fdc019d"/>
							<gml:surfaceMember xlink:href="#poly-6fd1197b-60d9-439b-84aa-7d43b2ddc097"/>
							<gml:surfaceMember xlink:href="#poly-2a4a0307-8bd8-44b1-ae0e-f4a88be677b6"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b1663599-0ffb-4bba-b888-270c5d5e4945_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2c11ebe-c422-40ac-9367-65167e1ba882">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67130418391446 139.7436643731555 44.37 35.671295946515855 139.743665917816 44.37 35.67129625188013 139.74366443725876 44.37 35.67134552205887 139.74365385494178 44.37 35.67134655983805 139.74365546655432 44.37 35.67130418391446 139.7436643731555 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5859ea65-a560-4e0e-b82e-1f0f28b030b2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671313622104115 139.7436654672385 44.37 35.6713203723208 139.74366403470478 44.37 35.67138216566086 139.7437665976757 44.37 35.67137628354568 139.74377177396067 44.37 35.671313622104115 139.7436654672385 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8f8d4c5-b5ab-4b8a-b909-0348ff83eb3e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671362902005754 139.74376482967998 44.37 35.67135654236055 139.74377027161074 44.37 35.671298751741176 139.74366854371857 44.37 35.67130187909147 139.74366798790172 44.37 35.67130629504208 139.74366694460264 44.37 35.671362902005754 139.74376482967998 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-353a5d88-0ec7-454d-a2fd-2a4a017c38b6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67137496113272 139.7437025918546 44.37 35.671392686493746 139.743732684523 44.37 35.67138844381714 139.74373643399366 44.37 35.671370727470766 139.7437063413159 44.37 35.67137496113272 139.7437025918546 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58542b42-d5e9-416b-bfb4-5124121b863d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67135337406736 139.74367947379264 44.37 35.67140093792417 139.74376211395852 44.37 35.67139432609213 139.74376782128743 44.37 35.67134676223919 139.74368518112493 44.37 35.67135337406736 139.74367947379264 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0691c4d1-7272-4cc7-9bb3-7fca4c9a521e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67128669395918 139.74372045311873 44.37 35.671301198105155 139.74374609766338 44.37 35.671297866316316 139.74376263782648 44.37 35.67127931195923 139.74375712431706 44.37 35.67128669395918 139.74372045311873 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca6e9e93-7068-4356-961f-f9f99ece218a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67128373628391 139.74376733727934 44.37 35.67131401031967 139.7437753120908 44.37 35.671311326578376 139.74379059224333 44.37 35.67129517983114 139.7437863463718 44.37 35.67129235248488 139.74380245515962 44.37 35.671278225206045 139.74379873725786 44.37 35.67128373628391 139.74376733727934 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d44d1c76-f6c3-4aa9-82a8-472e1e87b229">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67134834290962 139.7436532552813 47.3 35.67138874249468 139.7437138548209 47.3 35.67143298389763 139.7437892633589 47.3 35.671486828725975 139.7438941220449 47.3 35.671391619728915 139.74391033390597 47.3 35.67125452018809 139.74393365107937 47.3 35.67125430252192 139.7439318507621 47.3 35.67139137502123 139.74390853361584 47.3 35.671484403066586 139.74389282127427 47.3 35.67143175879541 139.7437902920428 47.3 35.67138759861525 139.74371501597136 47.3 35.67134779452875 139.74365521110624 47.3 35.67134655983805 139.74365546655432 47.3 35.67134552205887 139.74365385494178 47.3 35.67134834290962 139.7436532552813 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20da1997-fb31-461a-9007-4e94497c0df4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671295946515855 139.743665917816 47.3 35.67129564009866 139.743665984437 47.3 35.67129431561618 139.7436667039334 47.3 35.671241401916966 139.7439292140165 47.3 35.67123996840705 139.74392877375988 47.3 35.671293106592884 139.74366511460602 47.3 35.67129625188013 139.74366443725876 47.3 35.671295946515855 139.743665917816 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2a80bf6-dae9-4974-9042-0422df6067c1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671442363977775 139.7438334385071 44.37 35.67143203193819 139.74384246390713 44.37 35.671406400178114 139.74379838423752 44.37 35.671416723200714 139.74378935884474 44.37 35.671442363977775 139.7438334385071 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-322d0196-9794-4423-9f20-9a4834b731eb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671314763706164 139.74379448777972 44.37 35.671296740930785 139.743885684778 44.37 35.67129383774089 139.74388464965674 44.37 35.67131186952923 139.7437934526515 44.37 35.671314763706164 139.74379448777972 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d51c536-0422-4cc5-9f99-0f1ae0ac7050">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67142857613371 139.74387408257343 44.37 35.67140820945949 139.74389207779382 44.37 35.67135710015347 139.74380521073303 44.37 35.67137746681485 139.74378721550212 44.37 35.67142857613371 139.74387408257343 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c94366bf-c92f-4b83-a87b-e5b1568f6a2a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67130485446023 139.7439115353185 44.37 35.67127646365317 139.74390268569158 44.37 35.67129459647043 139.7438139961269 44.37 35.67130712810644 139.74381742860757 44.37 35.67129383774089 139.74388464965674 44.37 35.671296740930785 139.743885684778 44.37 35.67131167935165 139.74388928028074 44.37 35.67132587419164 139.74388687842455 44.37 35.67132814366231 139.74390847158585 44.37 35.67130485446023 139.7439115353185 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e93852a-5e9d-49a9-875a-da04b0533a6d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67146370845395 139.74386977945855 44.37 35.67144672865056 139.74388468896197 44.37 35.671431124088684 139.7438580072117 44.37 35.67144810388061 139.74384308665918 44.37 35.67146370845395 139.74386977945855 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfa51c9e-d0be-4373-b822-771ec6c19c90">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671311144021814 139.7438845419775 44.37 35.67137177470219 139.74387824416587 44.37 35.67137231003227 139.74388298247266 44.37 35.67131167935165 139.74388928028074 44.37 35.671311144021814 139.7438845419775 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43636037-24d5-430b-b36d-e4ee3d22a9eb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67126933804035 139.74390840461945 44.37 35.671297221486405 139.74391376415542 44.37 35.67129843686349 139.7439239144289 44.37 35.671271768794554 139.74392870515953 44.37 35.67126933804035 139.74390840461945 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc2ff383-c332-47c2-8acd-82df535d9254">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc2ff383-c332-47c2-8acd-82df535d9254_0">
											<gml:posList>35.6713203723208 139.74366403470478 46.614 35.6713203723208 139.74366403470478 44.37 35.671313622104115 139.7436654672385 44.37 35.671313622104115 139.7436654672385 46.614 35.6713203723208 139.74366403470478 46.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0abfb4da-1eb7-4219-93c5-7a56e29e65d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0abfb4da-1eb7-4219-93c5-7a56e29e65d0_0">
											<gml:posList>35.67130629504208 139.74366694460264 46.614 35.67130629504208 139.74366694460264 44.37 35.67130187909147 139.74366798790172 44.37 35.67130187909147 139.74366798790172 46.614 35.67130629504208 139.74366694460264 46.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0e93fae-de58-493a-b474-4674ca7a1371">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0e93fae-de58-493a-b474-4674ca7a1371_0">
											<gml:posList>35.67130187909147 139.74366798790172 46.614 35.67130187909147 139.74366798790172 44.37 35.671298751741176 139.74366854371857 44.37 35.671298751741176 139.74366854371857 46.614 35.67130187909147 139.74366798790172 46.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01edef67-f8e8-46df-9c9b-d5be34ec8f29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01edef67-f8e8-46df-9c9b-d5be34ec8f29_0">
											<gml:posList>35.671362902005754 139.74376482967998 46.614 35.671362902005754 139.74376482967998 44.37 35.67130629504208 139.74366694460264 44.37 35.67130629504208 139.74366694460264 46.614 35.671362902005754 139.74376482967998 46.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbdb7f90-b343-4ca0-bb9c-4f8782da4840">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbdb7f90-b343-4ca0-bb9c-4f8782da4840_0">
											<gml:posList>35.671442363977775 139.7438334385071 47.475 35.671442363977775 139.7438334385071 44.37 35.671416723200714 139.74378935884474 44.37 35.671416723200714 139.74378935884474 47.475 35.671442363977775 139.7438334385071 47.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1af4d958-c706-445b-ba3f-496ff4d957af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1af4d958-c706-445b-ba3f-496ff4d957af_0">
											<gml:posList>35.671406400178114 139.74379838423752 47.475 35.671406400178114 139.74379838423752 44.37 35.67143203193819 139.74384246390713 44.37 35.67143203193819 139.74384246390713 47.475 35.671406400178114 139.74379838423752 47.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36c096fc-50fa-4797-8289-8bc55e3e2c82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36c096fc-50fa-4797-8289-8bc55e3e2c82_0">
											<gml:posList>35.67129383774089 139.74388464965674 45.2 35.67129383774089 139.74388464965674 44.37 35.67130712810644 139.74381742860757 44.37 35.67130712810644 139.74381742860757 45.2 35.67129383774089 139.74388464965674 45.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19cb8a94-f67b-4a13-bfdd-799d9374a71a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19cb8a94-f67b-4a13-bfdd-799d9374a71a_0">
											<gml:posList>35.67146370845395 139.74386977945855 47.475 35.67146370845395 139.74386977945855 44.37 35.67144810388061 139.74384308665918 44.37 35.67144810388061 139.74384308665918 47.475 35.67146370845395 139.74386977945855 47.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb7f626b-efb2-4a3c-8dea-1f32992e8b13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb7f626b-efb2-4a3c-8dea-1f32992e8b13_0">
											<gml:posList>35.67140820945949 139.74389207779382 47.475 35.67140820945949 139.74389207779382 44.37 35.67142857613371 139.74387408257343 44.37 35.67142857613371 139.74387408257343 47.475 35.67140820945949 139.74389207779382 47.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1df02720-b783-404a-8415-7368cf6b85f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1df02720-b783-404a-8415-7368cf6b85f4_0">
											<gml:posList>35.67129383774089 139.74388464965674 45.407 35.67129383774089 139.74388464965674 44.37 35.671296740930785 139.743885684778 44.37 35.671296740930785 139.743885684778 45.407 35.67129383774089 139.74388464965674 45.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec8f03e5-5d28-4702-aad8-223ea92b5506">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec8f03e5-5d28-4702-aad8-223ea92b5506_0">
											<gml:posList>35.671296740930785 139.743885684778 45.2 35.671296740930785 139.743885684778 44.37 35.67129383774089 139.74388464965674 44.37 35.67129383774089 139.74388464965674 45.2 35.671296740930785 139.743885684778 45.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-477a73da-3afe-4032-a1b0-a06f98648fc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-477a73da-3afe-4032-a1b0-a06f98648fc7_0">
											<gml:posList>35.67132587419164 139.74388687842455 45.2 35.67132587419164 139.74388687842455 44.37 35.67131167935165 139.74388928028074 44.37 35.67131167935165 139.74388928028074 45.2 35.67132587419164 139.74388687842455 45.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ade10418-5452-4460-857b-1e9ebde76dd9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ade10418-5452-4460-857b-1e9ebde76dd9_0">
											<gml:posList>35.67134655983805 139.74365546655432 44.37 35.67134552205887 139.74365385494178 44.37 35.67134552205887 139.74365385494178 47.3 35.67134655983805 139.74365546655432 47.3 35.67134655983805 139.74365546655432 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8a0e646-655f-4ba7-bd7b-9da736796ed2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8a0e646-655f-4ba7-bd7b-9da736796ed2_0">
											<gml:posList>35.67134552205887 139.74365385494178 47.3 35.67134552205887 139.74365385494178 44.37 35.67129625188013 139.74366443725876 44.37 35.67129625188013 139.74366443725876 47.3 35.671293106592884 139.74366511460602 47.3 35.671293106592884 139.74366511460602 49.282 35.67134834290962 139.7436532552813 49.282 35.67134834290962 139.7436532552813 47.3 35.67134552205887 139.74365385494178 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b74b2cf3-7625-413a-ae84-4e5c9d911cf7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b74b2cf3-7625-413a-ae84-4e5c9d911cf7_0">
											<gml:posList>35.67134655983805 139.74365546655432 47.3 35.67134779452875 139.74365521110624 47.3 35.67134779452875 139.74365521110624 49.282 35.67130418391446 139.7436643731555 49.282 35.67130418391446 139.7436643731555 44.37 35.67134655983805 139.74365546655432 44.37 35.67134655983805 139.74365546655432 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10cb171b-809a-48e3-95e3-9508992497bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10cb171b-809a-48e3-95e3-9508992497bd_0">
											<gml:posList>35.67129625188013 139.74366443725876 47.3 35.67129625188013 139.74366443725876 44.37 35.671295946515855 139.743665917816 44.37 35.671295946515855 139.743665917816 47.3 35.67129625188013 139.74366443725876 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a1743b9-010c-487d-ae2c-c0899b9cc073">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a1743b9-010c-487d-ae2c-c0899b9cc073_0">
											<gml:posList>35.67130418391446 139.7436643731555 44.37 35.67130418391446 139.7436643731555 49.282 35.67129564009866 139.743665984437 49.282 35.67129564009866 139.743665984437 47.3 35.671295946515855 139.743665917816 47.3 35.671295946515855 139.743665917816 44.37 35.67130418391446 139.7436643731555 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10c3dd54-f367-43e7-b335-21e3577f204d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10c3dd54-f367-43e7-b335-21e3577f204d_0">
											<gml:posList>35.67129564009866 139.743665984437 47.3 35.67129564009866 139.743665984437 49.282 35.67129431561618 139.7436667039334 49.282 35.67129431561618 139.7436667039334 47.3 35.67129564009866 139.743665984437 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c90c5383-e87f-4185-890b-dc4483c9f0a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c90c5383-e87f-4185-890b-dc4483c9f0a0_0">
											<gml:posList>35.67135337406736 139.74367947379264 46.614 35.67135337406736 139.74367947379264 44.37 35.67134676223919 139.74368518112493 44.37 35.67134676223919 139.74368518112493 46.614 35.67135337406736 139.74367947379264 46.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9d75e87-c4a8-4682-a82e-50f72db2d504">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9d75e87-c4a8-4682-a82e-50f72db2d504_0">
											<gml:posList>35.67138874249468 139.7437138548209 49.282 35.67138874249468 139.7437138548209 47.3 35.67134834290962 139.7436532552813 47.3 35.67134834290962 139.7436532552813 49.282 35.67138874249468 139.7437138548209 49.282</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74457155-8cd8-4671-b0e3-8c854cc815b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74457155-8cd8-4671-b0e3-8c854cc815b6_0">
											<gml:posList>35.67138759861525 139.74371501597136 47.3 35.67138759861525 139.74371501597136 49.282 35.67134779452875 139.74365521110624 49.282 35.67134779452875 139.74365521110624 47.3 35.67138759861525 139.74371501597136 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fbeeb83-c868-4c79-beb5-32576939ca80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fbeeb83-c868-4c79-beb5-32576939ca80_0">
											<gml:posList>35.67137496113272 139.7437025918546 47.179 35.67137496113272 139.7437025918546 44.37 35.671370727470766 139.7437063413159 44.37 35.671370727470766 139.7437063413159 47.179 35.67137496113272 139.7437025918546 47.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27bc2b3f-44a8-4ce1-9322-143eb81694f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27bc2b3f-44a8-4ce1-9322-143eb81694f6_0">
											<gml:posList>35.67138216566086 139.7437665976757 46.614 35.67138216566086 139.7437665976757 44.37 35.6713203723208 139.74366403470478 44.37 35.6713203723208 139.74366403470478 46.614 35.67138216566086 139.7437665976757 46.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30927cd9-5519-43e7-af0e-24ad1c62b089">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30927cd9-5519-43e7-af0e-24ad1c62b089_0">
											<gml:posList>35.671392686493746 139.743732684523 47.179 35.671392686493746 139.743732684523 44.37 35.67137496113272 139.7437025918546 44.37 35.67137496113272 139.7437025918546 47.179 35.671392686493746 139.743732684523 47.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-361fe5bd-fd84-4978-a733-9402741def45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-361fe5bd-fd84-4978-a733-9402741def45_0">
											<gml:posList>35.671313622104115 139.7436654672385 46.614 35.67137628354568 139.74377177396067 46.614 35.67138216566086 139.7437665976757 46.614 35.6713203723208 139.74366403470478 46.614 35.671313622104115 139.7436654672385 46.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38f50350-e1fb-4cf3-8160-742c410a17ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38f50350-e1fb-4cf3-8160-742c410a17ba_0">
											<gml:posList>35.671362902005754 139.74376482967998 46.614 35.67130629504208 139.74366694460264 46.614 35.67130187909147 139.74366798790172 46.614 35.671298751741176 139.74366854371857 46.614 35.67135654236055 139.74377027161074 46.614 35.671362902005754 139.74376482967998 46.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34131936-46e8-43fe-bb52-04418e281dd5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34131936-46e8-43fe-bb52-04418e281dd5_0">
											<gml:posList>35.671313622104115 139.7436654672385 46.614 35.671313622104115 139.7436654672385 44.37 35.67137628354568 139.74377177396067 44.37 35.67137628354568 139.74377177396067 46.614 35.671313622104115 139.7436654672385 46.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f43705ff-9d4f-4df6-8527-0311efd21092">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f43705ff-9d4f-4df6-8527-0311efd21092_0">
											<gml:posList>35.671298751741176 139.74366854371857 46.614 35.671298751741176 139.74366854371857 44.37 35.67135654236055 139.74377027161074 44.37 35.67135654236055 139.74377027161074 46.614 35.671298751741176 139.74366854371857 46.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-752b6051-2efb-4b5c-98f5-912cc750332f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-752b6051-2efb-4b5c-98f5-912cc750332f_0">
											<gml:posList>35.671370727470766 139.7437063413159 47.179 35.67138844381714 139.74373643399366 47.179 35.671392686493746 139.743732684523 47.179 35.67137496113272 139.7437025918546 47.179 35.671370727470766 139.7437063413159 47.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46feba2c-36ff-437a-b5da-6bf14ee169de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46feba2c-36ff-437a-b5da-6bf14ee169de_0">
											<gml:posList>35.67140093792417 139.74376211395852 46.614 35.67140093792417 139.74376211395852 44.37 35.67135337406736 139.74367947379264 44.37 35.67135337406736 139.74367947379264 46.614 35.67140093792417 139.74376211395852 46.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f9f1161-651f-46a1-a28c-37b2f975a85e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f9f1161-651f-46a1-a28c-37b2f975a85e_0">
											<gml:posList>35.671370727470766 139.7437063413159 47.179 35.671370727470766 139.7437063413159 44.37 35.67138844381714 139.74373643399366 44.37 35.67138844381714 139.74373643399366 47.179 35.671370727470766 139.7437063413159 47.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a578f9a2-363f-4300-a394-457fa712abfe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a578f9a2-363f-4300-a394-457fa712abfe_0">
											<gml:posList>35.67134676223919 139.74368518112493 46.614 35.67139432609213 139.74376782128743 46.614 35.67140093792417 139.74376211395852 46.614 35.67135337406736 139.74367947379264 46.614 35.67134676223919 139.74368518112493 46.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d4c54fc-e17e-4654-b497-fef4a5a9f459">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d4c54fc-e17e-4654-b497-fef4a5a9f459_0">
											<gml:posList>35.67134676223919 139.74368518112493 46.614 35.67134676223919 139.74368518112493 44.37 35.67139432609213 139.74376782128743 44.37 35.67139432609213 139.74376782128743 46.614 35.67134676223919 139.74368518112493 46.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c436cba2-0818-46f1-8954-0cc519dde6a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c436cba2-0818-46f1-8954-0cc519dde6a3_0">
											<gml:posList>35.671301198105155 139.74374609766338 44.746 35.671301198105155 139.74374609766338 44.37 35.67128669395918 139.74372045311873 44.37 35.67128669395918 139.74372045311873 44.746 35.671301198105155 139.74374609766338 44.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e81b3d4e-abd3-40c7-8c9c-f2e143722a4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e81b3d4e-abd3-40c7-8c9c-f2e143722a4d_0">
											<gml:posList>35.67138844381714 139.74373643399366 47.179 35.67138844381714 139.74373643399366 44.37 35.671392686493746 139.743732684523 44.37 35.671392686493746 139.743732684523 47.179 35.67138844381714 139.74373643399366 47.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-882a3085-5175-4258-926a-d3af5a802668">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-882a3085-5175-4258-926a-d3af5a802668_0">
											<gml:posList>35.67128669395918 139.74372045311873 44.746 35.67128669395918 139.74372045311873 44.37 35.67127931195923 139.74375712431706 44.37 35.67127931195923 139.74375712431706 44.746 35.67128669395918 139.74372045311873 44.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc24ed24-bf1e-4921-a9c5-114261d79b0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc24ed24-bf1e-4921-a9c5-114261d79b0a_0">
											<gml:posList>35.67127931195923 139.74375712431706 44.746 35.671297866316316 139.74376263782648 44.746 35.671301198105155 139.74374609766338 44.746 35.67128669395918 139.74372045311873 44.746 35.67127931195923 139.74375712431706 44.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-151766ad-bd6f-415a-9938-1931d3a134ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-151766ad-bd6f-415a-9938-1931d3a134ce_0">
											<gml:posList>35.67138874249468 139.7437138548209 49.282 35.67143298389763 139.7437892633589 49.282 35.67143298389763 139.7437892633589 47.3 35.67138874249468 139.7437138548209 47.3 35.67138874249468 139.7437138548209 49.282</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21e95770-2a9a-4778-8f31-435f27a427ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21e95770-2a9a-4778-8f31-435f27a427ec_0">
											<gml:posList>35.67143175879541 139.7437902920428 49.282 35.67138759861525 139.74371501597136 49.282 35.67138759861525 139.74371501597136 47.3 35.67143175879541 139.7437902920428 47.3 35.67143175879541 139.7437902920428 49.282</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccc835ec-54bb-4868-a403-9192a46ce236">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccc835ec-54bb-4868-a403-9192a46ce236_0">
											<gml:posList>35.671297866316316 139.74376263782648 44.746 35.671297866316316 139.74376263782648 44.37 35.671301198105155 139.74374609766338 44.37 35.671301198105155 139.74374609766338 44.746 35.671297866316316 139.74376263782648 44.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-242173b8-dac3-4706-8cb9-216872ce0342">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-242173b8-dac3-4706-8cb9-216872ce0342_0">
											<gml:posList>35.67127931195923 139.74375712431706 44.746 35.67127931195923 139.74375712431706 44.37 35.671297866316316 139.74376263782648 44.37 35.671297866316316 139.74376263782648 44.746 35.67127931195923 139.74375712431706 44.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80c323af-2aab-4816-bfc2-aade1db089f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80c323af-2aab-4816-bfc2-aade1db089f9_0">
											<gml:posList>35.67139432609213 139.74376782128743 46.614 35.67139432609213 139.74376782128743 44.37 35.67140093792417 139.74376211395852 44.37 35.67140093792417 139.74376211395852 46.614 35.67139432609213 139.74376782128743 46.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bc9c754-573f-4aeb-ab53-b2ddbff6869d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5bc9c754-573f-4aeb-ab53-b2ddbff6869d_0">
											<gml:posList>35.67135654236055 139.74377027161074 46.614 35.67135654236055 139.74377027161074 44.37 35.671362902005754 139.74376482967998 44.37 35.671362902005754 139.74376482967998 46.614 35.67135654236055 139.74377027161074 46.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4221f57e-95f0-483e-b069-0290a9d86e38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4221f57e-95f0-483e-b069-0290a9d86e38_0">
											<gml:posList>35.67137628354568 139.74377177396067 46.614 35.67137628354568 139.74377177396067 44.37 35.67138216566086 139.7437665976757 44.37 35.67138216566086 139.7437665976757 46.614 35.67137628354568 139.74377177396067 46.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12ee1d69-d15d-4f39-ad92-8e2b81fbe337">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12ee1d69-d15d-4f39-ad92-8e2b81fbe337_0">
											<gml:posList>35.67131401031967 139.7437753120908 46.166 35.67131401031967 139.7437753120908 44.37 35.67128373628391 139.74376733727934 44.37 35.67128373628391 139.74376733727934 46.166 35.67131401031967 139.7437753120908 46.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04aeaefd-4d74-49b1-b854-7089e1e23e8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04aeaefd-4d74-49b1-b854-7089e1e23e8b_0">
											<gml:posList>35.671311326578376 139.74379059224333 46.166 35.671311326578376 139.74379059224333 44.37 35.67131401031967 139.7437753120908 44.37 35.67131401031967 139.7437753120908 46.166 35.671311326578376 139.74379059224333 46.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d941bae6-fa2d-4b7e-9a9a-d8a9fbc6ec9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d941bae6-fa2d-4b7e-9a9a-d8a9fbc6ec9e_0">
											<gml:posList>35.67128373628391 139.74376733727934 46.166 35.67128373628391 139.74376733727934 44.37 35.671278225206045 139.74379873725786 44.37 35.671278225206045 139.74379873725786 46.166 35.67128373628391 139.74376733727934 46.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-728569f1-886a-4308-a180-4a88ffb859c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-728569f1-886a-4308-a180-4a88ffb859c7_0">
											<gml:posList>35.67128373628391 139.74376733727934 46.166 35.671278225206045 139.74379873725786 46.166 35.67129235248488 139.74380245515962 46.166 35.67129517983114 139.7437863463718 46.166 35.671311326578376 139.74379059224333 46.166 35.67131401031967 139.7437753120908 46.166 35.67128373628391 139.74376733727934 46.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-045571af-4603-4a2d-a260-4f6761a1eff1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-045571af-4603-4a2d-a260-4f6761a1eff1_0">
											<gml:posList>35.67129517983114 139.7437863463718 46.166 35.67129517983114 139.7437863463718 44.37 35.671311326578376 139.74379059224333 44.37 35.671311326578376 139.74379059224333 46.166 35.67129517983114 139.7437863463718 46.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5af9bbf-8998-48f3-8633-4554af04ccba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5af9bbf-8998-48f3-8633-4554af04ccba_0">
											<gml:posList>35.67125452018809 139.74393365107937 49.282 35.671391619728915 139.74391033390597 49.282 35.671486828725975 139.7438941220449 49.282 35.67143298389763 139.7437892633589 49.282 35.67138874249468 139.7437138548209 49.282 35.67134834290962 139.7436532552813 49.282 35.671293106592884 139.74366511460602 49.282 35.67123996840705 139.74392877375988 49.282 35.671241401916966 139.7439292140165 49.282 35.67129431561618 139.7436667039334 49.282 35.67129564009866 139.743665984437 49.282 35.67130418391446 139.7436643731555 49.282 35.67134779452875 139.74365521110624 49.282 35.67138759861525 139.74371501597136 49.282 35.67143175879541 139.7437902920428 49.282 35.671484403066586 139.74389282127427 49.282 35.67139137502123 139.74390853361584 49.282 35.67125430252192 139.7439318507621 49.282 35.67125452018809 139.74393365107937 49.282</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-908a5856-4ed0-41b2-9d10-0618815bf83a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-908a5856-4ed0-41b2-9d10-0618815bf83a_0">
											<gml:posList>35.671314763706164 139.74379448777972 45.407 35.671314763706164 139.74379448777972 44.37 35.67131186952923 139.7437934526515 44.37 35.67131186952923 139.7437934526515 45.407 35.671314763706164 139.74379448777972 45.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ff919e1-6f5f-435f-877d-790b09501230">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ff919e1-6f5f-435f-877d-790b09501230_0">
											<gml:posList>35.671416723200714 139.74378935884474 47.475 35.671416723200714 139.74378935884474 44.37 35.671406400178114 139.74379838423752 44.37 35.671406400178114 139.74379838423752 47.475 35.671416723200714 139.74378935884474 47.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-979434a2-c1f7-4ce3-b545-1325eb14c854">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-979434a2-c1f7-4ce3-b545-1325eb14c854_0">
											<gml:posList>35.67129235248488 139.74380245515962 46.166 35.67129235248488 139.74380245515962 44.37 35.67129517983114 139.7437863463718 44.37 35.67129517983114 139.7437863463718 46.166 35.67129235248488 139.74380245515962 46.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f18002b9-2853-4fac-b92a-4cd70bdc7a5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f18002b9-2853-4fac-b92a-4cd70bdc7a5b_0">
											<gml:posList>35.67137746681485 139.74378721550212 47.475 35.67137746681485 139.74378721550212 44.37 35.67135710015347 139.74380521073303 44.37 35.67135710015347 139.74380521073303 47.475 35.67137746681485 139.74378721550212 47.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-faeeebfc-c6af-400f-84e5-638fe7f19bc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-faeeebfc-c6af-400f-84e5-638fe7f19bc9_0">
											<gml:posList>35.671293106592884 139.74366511460602 49.282 35.671293106592884 139.74366511460602 47.3 35.67123996840705 139.74392877375988 47.3 35.67123996840705 139.74392877375988 49.282 35.671293106592884 139.74366511460602 49.282</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b32add7-1295-4aa1-8eae-76b732774565">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b32add7-1295-4aa1-8eae-76b732774565_0">
											<gml:posList>35.67129431561618 139.7436667039334 47.3 35.67129431561618 139.7436667039334 49.282 35.671241401916966 139.7439292140165 49.282 35.671241401916966 139.7439292140165 47.3 35.67129431561618 139.7436667039334 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-797c2afc-2975-4fc7-824a-f43dd6807d47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-797c2afc-2975-4fc7-824a-f43dd6807d47_0">
											<gml:posList>35.671278225206045 139.74379873725786 46.166 35.671278225206045 139.74379873725786 44.37 35.67129235248488 139.74380245515962 44.37 35.67129235248488 139.74380245515962 46.166 35.671278225206045 139.74379873725786 46.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-366a60c9-9ff2-464a-9560-2b6e955252c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-366a60c9-9ff2-464a-9560-2b6e955252c2_0">
											<gml:posList>35.67130712810644 139.74381742860757 45.2 35.67130712810644 139.74381742860757 44.37 35.67129459647043 139.7438139961269 44.37 35.67129459647043 139.7438139961269 45.2 35.67130712810644 139.74381742860757 45.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58cc2c6b-9f14-4801-be50-00ed15c0396a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58cc2c6b-9f14-4801-be50-00ed15c0396a_0">
											<gml:posList>35.671416723200714 139.74378935884474 47.475 35.671406400178114 139.74379838423752 47.475 35.67143203193819 139.74384246390713 47.475 35.671442363977775 139.7438334385071 47.475 35.671416723200714 139.74378935884474 47.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6794e4ce-a9fb-49bc-b402-069adfc4ac46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6794e4ce-a9fb-49bc-b402-069adfc4ac46_0">
											<gml:posList>35.67142857613371 139.74387408257343 47.475 35.67142857613371 139.74387408257343 44.37 35.67137746681485 139.74378721550212 44.37 35.67137746681485 139.74378721550212 47.475 35.67142857613371 139.74387408257343 47.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7806d826-d0f3-4d09-9ebd-e8f254fbf890">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7806d826-d0f3-4d09-9ebd-e8f254fbf890_0">
											<gml:posList>35.67143203193819 139.74384246390713 47.475 35.67143203193819 139.74384246390713 44.37 35.671442363977775 139.7438334385071 44.37 35.671442363977775 139.7438334385071 47.475 35.67143203193819 139.74384246390713 47.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20878e5b-5947-4a8a-913c-fa516bf575dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20878e5b-5947-4a8a-913c-fa516bf575dd_0">
											<gml:posList>35.67129383774089 139.74388464965674 44.37 35.67129383774089 139.74388464965674 45.407 35.67131186952923 139.7437934526515 45.407 35.67131186952923 139.7437934526515 44.37 35.67129383774089 139.74388464965674 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb68d8d6-3df6-431b-9237-10995b91f17b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb68d8d6-3df6-431b-9237-10995b91f17b_0">
											<gml:posList>35.671314763706164 139.74379448777972 45.407 35.67131186952923 139.7437934526515 45.407 35.67129383774089 139.74388464965674 45.407 35.671296740930785 139.743885684778 45.407 35.671314763706164 139.74379448777972 45.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c715815d-4f96-4308-956c-f0447c47789c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c715815d-4f96-4308-956c-f0447c47789c_0">
											<gml:posList>35.67137746681485 139.74378721550212 47.475 35.67135710015347 139.74380521073303 47.475 35.67140820945949 139.74389207779382 47.475 35.67142857613371 139.74387408257343 47.475 35.67137746681485 139.74378721550212 47.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-520aac15-54ff-457e-850a-25da84d8e9df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-520aac15-54ff-457e-850a-25da84d8e9df_0">
											<gml:posList>35.671296740930785 139.743885684778 45.407 35.671296740930785 139.743885684778 44.37 35.671314763706164 139.74379448777972 44.37 35.671314763706164 139.74379448777972 45.407 35.671296740930785 139.743885684778 45.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f88d1d0-e5e3-4680-b0da-d8f7fe373dd2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f88d1d0-e5e3-4680-b0da-d8f7fe373dd2_0">
											<gml:posList>35.671484403066586 139.74389282127427 47.3 35.671484403066586 139.74389282127427 49.282 35.67143175879541 139.7437902920428 49.282 35.67143175879541 139.7437902920428 47.3 35.671484403066586 139.74389282127427 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed780ae9-45fb-4480-bf7a-20d58eb5e40d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed780ae9-45fb-4480-bf7a-20d58eb5e40d_0">
											<gml:posList>35.67143298389763 139.7437892633589 47.3 35.67143298389763 139.7437892633589 49.282 35.671486828725975 139.7438941220449 49.282 35.671486828725975 139.7438941220449 47.3 35.67143298389763 139.7437892633589 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ac523b9-a77b-4232-a0a4-b832622de02e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ac523b9-a77b-4232-a0a4-b832622de02e_0">
											<gml:posList>35.67135710015347 139.74380521073303 47.475 35.67135710015347 139.74380521073303 44.37 35.67140820945949 139.74389207779382 44.37 35.67140820945949 139.74389207779382 47.475 35.67135710015347 139.74380521073303 47.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9853bf9c-6eb1-416f-8c35-5d15c16c3967">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9853bf9c-6eb1-416f-8c35-5d15c16c3967_0">
											<gml:posList>35.67144810388061 139.74384308665918 47.475 35.67144810388061 139.74384308665918 44.37 35.671431124088684 139.7438580072117 44.37 35.671431124088684 139.7438580072117 47.475 35.67144810388061 139.74384308665918 47.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-776bb678-b29f-4f8a-bb69-29b0e93cfe66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-776bb678-b29f-4f8a-bb69-29b0e93cfe66_0">
											<gml:posList>35.67129459647043 139.7438139961269 45.2 35.67129459647043 139.7438139961269 44.37 35.67127646365317 139.74390268569158 44.37 35.67127646365317 139.74390268569158 45.2 35.67129459647043 139.7438139961269 45.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3be0bc2-de59-402f-bfcd-2aae441acbf5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3be0bc2-de59-402f-bfcd-2aae441acbf5_0">
											<gml:posList>35.67130485446023 139.7439115353185 45.2 35.67132814366231 139.74390847158585 45.2 35.67132587419164 139.74388687842455 45.2 35.67131167935165 139.74388928028074 45.2 35.671296740930785 139.743885684778 45.2 35.67129383774089 139.74388464965674 45.2 35.67130712810644 139.74381742860757 45.2 35.67129459647043 139.7438139961269 45.2 35.67127646365317 139.74390268569158 45.2 35.67130485446023 139.7439115353185 45.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73de4575-046c-42b8-880b-c06a12cd302e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73de4575-046c-42b8-880b-c06a12cd302e_0">
											<gml:posList>35.67144810388061 139.74384308665918 47.475 35.671431124088684 139.7438580072117 47.475 35.67144672865056 139.74388468896197 47.475 35.67146370845395 139.74386977945855 47.475 35.67144810388061 139.74384308665918 47.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77794329-f6ba-45fa-9b6d-59bfc994942f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77794329-f6ba-45fa-9b6d-59bfc994942f_0">
											<gml:posList>35.671431124088684 139.7438580072117 47.475 35.671431124088684 139.7438580072117 44.37 35.67144672865056 139.74388468896197 44.37 35.67144672865056 139.74388468896197 47.475 35.671431124088684 139.7438580072117 47.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82909990-d0ac-4a81-83df-e4fb10973aed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82909990-d0ac-4a81-83df-e4fb10973aed_0">
											<gml:posList>35.67144672865056 139.74388468896197 47.475 35.67144672865056 139.74388468896197 44.37 35.67146370845395 139.74386977945855 44.37 35.67146370845395 139.74386977945855 47.475 35.67144672865056 139.74388468896197 47.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3c2adef-4f46-483b-972e-74d5f3c2dcee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3c2adef-4f46-483b-972e-74d5f3c2dcee_0">
											<gml:posList>35.67137231003227 139.74388298247266 45.407 35.67137231003227 139.74388298247266 44.37 35.67137177470219 139.74387824416587 44.37 35.67137177470219 139.74387824416587 45.407 35.67137231003227 139.74388298247266 45.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46452df9-1c06-4a43-a856-dc67dfd66076">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46452df9-1c06-4a43-a856-dc67dfd66076_0">
											<gml:posList>35.67137177470219 139.74387824416587 45.407 35.67137177470219 139.74387824416587 44.37 35.671311144021814 139.7438845419775 44.37 35.671311144021814 139.7438845419775 45.407 35.67137177470219 139.74387824416587 45.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-209b8a0e-49f9-4d4c-8407-b6c923441ff5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-209b8a0e-49f9-4d4c-8407-b6c923441ff5_0">
											<gml:posList>35.671311144021814 139.7438845419775 45.407 35.67131167935165 139.74388928028074 45.407 35.67137231003227 139.74388298247266 45.407 35.67137177470219 139.74387824416587 45.407 35.671311144021814 139.7438845419775 45.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2714fde3-2841-4df6-b578-47011712bcd7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2714fde3-2841-4df6-b578-47011712bcd7_0">
											<gml:posList>35.67131167935165 139.74388928028074 45.407 35.67131167935165 139.74388928028074 44.37 35.67137231003227 139.74388298247266 44.37 35.67137231003227 139.74388298247266 45.407 35.67131167935165 139.74388928028074 45.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc45adc8-94d2-460c-afb3-cb74a72ba091">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc45adc8-94d2-460c-afb3-cb74a72ba091_0">
											<gml:posList>35.671311144021814 139.7438845419775 45.407 35.671311144021814 139.7438845419775 44.37 35.67131167935165 139.74388928028074 44.37 35.67131167935165 139.74388928028074 45.407 35.671311144021814 139.7438845419775 45.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6fb9789-2f6a-49d7-bcc7-a49a38e37570">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6fb9789-2f6a-49d7-bcc7-a49a38e37570_0">
											<gml:posList>35.67131167935165 139.74388928028074 45.2 35.67131167935165 139.74388928028074 44.37 35.671296740930785 139.743885684778 44.37 35.671296740930785 139.743885684778 45.2 35.67131167935165 139.74388928028074 45.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73ac723c-f4e7-4e15-af41-471e67efa581">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73ac723c-f4e7-4e15-af41-471e67efa581_0">
											<gml:posList>35.67132814366231 139.74390847158585 45.2 35.67132814366231 139.74390847158585 44.37 35.67132587419164 139.74388687842455 44.37 35.67132587419164 139.74388687842455 45.2 35.67132814366231 139.74390847158585 45.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c02571d4-2d37-4dda-9aa9-9ba985b9770d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c02571d4-2d37-4dda-9aa9-9ba985b9770d_0">
											<gml:posList>35.67139137502123 139.74390853361584 49.282 35.671484403066586 139.74389282127427 49.282 35.671484403066586 139.74389282127427 47.3 35.67139137502123 139.74390853361584 47.3 35.67139137502123 139.74390853361584 49.282</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0cff500-db65-40e1-8c57-5bbf1a1483a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0cff500-db65-40e1-8c57-5bbf1a1483a9_0">
											<gml:posList>35.671486828725975 139.7438941220449 47.3 35.671486828725975 139.7438941220449 49.282 35.671391619728915 139.74391033390597 49.282 35.671391619728915 139.74391033390597 47.3 35.671486828725975 139.7438941220449 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93fb5227-f78e-4197-a0ef-562890ed2798">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93fb5227-f78e-4197-a0ef-562890ed2798_0">
											<gml:posList>35.67127646365317 139.74390268569158 45.2 35.67127646365317 139.74390268569158 44.37 35.67130485446023 139.7439115353185 44.37 35.67130485446023 139.7439115353185 45.2 35.67127646365317 139.74390268569158 45.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78a50d0d-89c8-46f6-b513-c675e96dc8b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78a50d0d-89c8-46f6-b513-c675e96dc8b4_0">
											<gml:posList>35.67130485446023 139.7439115353185 45.2 35.67130485446023 139.7439115353185 44.37 35.67132814366231 139.74390847158585 44.37 35.67132814366231 139.74390847158585 45.2 35.67130485446023 139.7439115353185 45.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05058d0b-ede7-4802-bdc3-1992d1f9a0b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05058d0b-ede7-4802-bdc3-1992d1f9a0b4_0">
											<gml:posList>35.671297221486405 139.74391376415542 45.044 35.671297221486405 139.74391376415542 44.37 35.67126933804035 139.74390840461945 44.37 35.67126933804035 139.74390840461945 45.044 35.671297221486405 139.74391376415542 45.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8f7c68b-25c6-480b-9332-a72bd5d23581">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8f7c68b-25c6-480b-9332-a72bd5d23581_0">
											<gml:posList>35.67126933804035 139.74390840461945 45.044 35.67126933804035 139.74390840461945 44.37 35.671271768794554 139.74392870515953 44.37 35.671271768794554 139.74392870515953 45.044 35.67126933804035 139.74390840461945 45.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-198838eb-d9a3-47e6-9ba4-7ceb3e91c78b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-198838eb-d9a3-47e6-9ba4-7ceb3e91c78b_0">
											<gml:posList>35.671271768794554 139.74392870515953 45.044 35.67129843686349 139.7439239144289 45.044 35.671297221486405 139.74391376415542 45.044 35.67126933804035 139.74390840461945 45.044 35.671271768794554 139.74392870515953 45.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7447dfb5-f9ee-4b19-bab3-f08eee81fc0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7447dfb5-f9ee-4b19-bab3-f08eee81fc0e_0">
											<gml:posList>35.67129843686349 139.7439239144289 45.044 35.67129843686349 139.7439239144289 44.37 35.671297221486405 139.74391376415542 44.37 35.671297221486405 139.74391376415542 45.044 35.67129843686349 139.7439239144289 45.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecea5916-81d9-4b49-8d3b-302ab98ad8e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ecea5916-81d9-4b49-8d3b-302ab98ad8e6_0">
											<gml:posList>35.67139137502123 139.74390853361584 49.282 35.67139137502123 139.74390853361584 47.3 35.67125430252192 139.7439318507621 47.3 35.67125430252192 139.7439318507621 49.282 35.67139137502123 139.74390853361584 49.282</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5164a0b9-14e0-4ab7-a4aa-7f5f08db381c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5164a0b9-14e0-4ab7-a4aa-7f5f08db381c_0">
											<gml:posList>35.671391619728915 139.74391033390597 49.282 35.67125452018809 139.74393365107937 49.282 35.67125452018809 139.74393365107937 47.3 35.671391619728915 139.74391033390597 47.3 35.671391619728915 139.74391033390597 49.282</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-781a6807-f203-4d75-8c56-488980ddd127">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-781a6807-f203-4d75-8c56-488980ddd127_0">
											<gml:posList>35.671271768794554 139.74392870515953 45.044 35.671271768794554 139.74392870515953 44.37 35.67129843686349 139.7439239144289 44.37 35.67129843686349 139.7439239144289 45.044 35.671271768794554 139.74392870515953 45.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c66ca90-6e70-4689-bead-9ed7a292901b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c66ca90-6e70-4689-bead-9ed7a292901b_0">
											<gml:posList>35.671241401916966 139.7439292140165 47.3 35.671241401916966 139.7439292140165 49.282 35.67123996840705 139.74392877375988 49.282 35.67123996840705 139.74392877375988 47.3 35.671241401916966 139.7439292140165 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f945d043-4c06-46f4-bfc1-8b7847c99a51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f945d043-4c06-46f4-bfc1-8b7847c99a51_0">
											<gml:posList>35.67125452018809 139.74393365107937 47.3 35.67125452018809 139.74393365107937 49.282 35.67125430252192 139.7439318507621 49.282 35.67125430252192 139.7439318507621 47.3 35.67125452018809 139.74393365107937 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c8ffb959-7008-45ca-914e-95673e567d99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8ffb959-7008-45ca-914e-95673e567d99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8ffb959-7008-45ca-914e-95673e567d99">
											<gml:posList>35.67132631479599 139.74363098830574 6.74 35.67134397551909 139.7436226837519 6.74 35.67141264956168 139.7437295360811 6.74 35.67146662399888 139.743826794626 6.74 35.671505801743926 139.74390506996934 6.74 35.6712225361364 139.74395343766344 6.74 35.67128764740939 139.7436330199174 6.74 35.67130648674693 139.7436338825508 6.74 35.67132631479599 139.74363098830574 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b1cf85e3-1c01-4574-ad30-d19915b409c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1cf85e3-1c01-4574-ad30-d19915b409c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1cf85e3-1c01-4574-ad30-d19915b409c9">
											<gml:posList>35.67132631479599 139.74363098830574 47.3 35.6713298431237 139.7436484045161 47.3 35.67133919610078 139.74364400863612 47.3 35.67134397551909 139.7436226837519 47.3 35.67132631479599 139.74363098830574 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a70c234-4681-423a-a845-2a86946c94d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a70c234-4681-423a-a845-2a86946c94d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a70c234-4681-423a-a845-2a86946c94d8">
											<gml:posList>35.67132631479599 139.74363098830574 47.3 35.67130648674693 139.7436338825508 47.3 35.67130708592718 139.7436517217962 47.3 35.6713298431237 139.7436484045161 47.3 35.67132631479599 139.74363098830574 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fcdf3974-3fb1-45aa-aac5-dc256e7e0b2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcdf3974-3fb1-45aa-aac5-dc256e7e0b2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcdf3974-3fb1-45aa-aac5-dc256e7e0b2d">
											<gml:posList>35.67130648674693 139.7436338825508 47.3 35.67128764740939 139.7436330199174 47.3 35.6712989102015 139.74365135536422 47.3 35.67130708592718 139.7436517217962 47.3 35.67130648674693 139.7436338825508 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17ce6408-e2c9-4aab-91bc-4ffb765277b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17ce6408-e2c9-4aab-91bc-4ffb765277b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17ce6408-e2c9-4aab-91bc-4ffb765277b1">
											<gml:posList>35.67141264956168 139.7437295360811 47.3 35.67134397551909 139.7436226837519 47.3 35.67133919610078 139.74364400863612 47.3 35.671400894438506 139.74374001015994 47.3 35.67141264956168 139.7437295360811 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-045cfede-911d-4ac4-a619-62e009df7b52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-045cfede-911d-4ac4-a619-62e009df7b52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-045cfede-911d-4ac4-a619-62e009df7b52">
											<gml:posList>35.67141264956168 139.7437295360811 47.3 35.671400894438506 139.74374001015994 47.3 35.67145443563397 139.74383649593267 47.3 35.67146662399888 139.743826794626 47.3 35.67141264956168 139.7437295360811 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5ba0bbe8-b11c-4c48-90a1-81ed7e90c836">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ba0bbe8-b11c-4c48-90a1-81ed7e90c836">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ba0bbe8-b11c-4c48-90a1-81ed7e90c836">
											<gml:posList>35.67145443563397 139.74383649593267 44.37 35.671400894438506 139.74374001015994 44.37 35.67133919610078 139.74364400863612 44.37 35.6713298431237 139.7436484045161 44.37 35.67130708592718 139.7436517217962 44.37 35.6712989102015 139.74365135536422 44.37 35.671316689751265 139.7437905972999 44.37 35.671326108992304 139.74379045422336 44.37 35.67137656905857 139.7438769684809 44.37 35.6712974347248 139.74388533051965 44.37 35.671241845771 139.74393215185822 44.37 35.67148180589211 139.7438911782563 44.37 35.67145443563397 139.74383649593267 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d5c7243-3290-4196-9cb1-1835afc0454a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d5c7243-3290-4196-9cb1-1835afc0454a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d5c7243-3290-4196-9cb1-1835afc0454a">
											<gml:posList>35.671316689751265 139.7437905972999 44.37 35.6712989102015 139.74365135536422 44.37 35.671241845771 139.74393215185822 44.37 35.6712974347248 139.74388533051965 44.37 35.671316689751265 139.7437905972999 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b081b9b8-8653-40b7-948e-03fe5e098cd9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b081b9b8-8653-40b7-948e-03fe5e098cd9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b081b9b8-8653-40b7-948e-03fe5e098cd9">
											<gml:posList>35.67128764740939 139.7436330199174 47.3 35.6712225361364 139.74395343766344 47.3 35.671241845771 139.74393215185822 47.3 35.6712989102015 139.74365135536422 47.3 35.67128764740939 139.7436330199174 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d10c77a2-1250-42d0-b000-fd84cff9d0cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d10c77a2-1250-42d0-b000-fd84cff9d0cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d10c77a2-1250-42d0-b000-fd84cff9d0cb">
											<gml:posList>35.6712974347248 139.74388533051965 40.819 35.67137656905857 139.7438769684809 40.819 35.671326108992304 139.74379045422336 40.819 35.671316689751265 139.7437905972999 40.819 35.6712974347248 139.74388533051965 40.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-96800bd0-fb48-409f-98fd-9eefb8895228">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96800bd0-fb48-409f-98fd-9eefb8895228">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96800bd0-fb48-409f-98fd-9eefb8895228">
											<gml:posList>35.67146662399888 139.743826794626 47.3 35.67145443563397 139.74383649593267 47.3 35.67148180589211 139.7438911782563 47.3 35.671505801743926 139.74390506996934 47.3 35.67146662399888 139.743826794626 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-555f6175-4cac-44c2-9295-145a73650e55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-555f6175-4cac-44c2-9295-145a73650e55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-555f6175-4cac-44c2-9295-145a73650e55">
											<gml:posList>35.671505801743926 139.74390506996934 47.3 35.67148180589211 139.7438911782563 47.3 35.671241845771 139.74393215185822 47.3 35.6712225361364 139.74395343766344 47.3 35.671505801743926 139.74390506996934 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aaed62a0-2d91-4a84-93c8-1f5784b358ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aaed62a0-2d91-4a84-93c8-1f5784b358ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aaed62a0-2d91-4a84-93c8-1f5784b358ae">
											<gml:posList>35.67134397551909 139.7436226837519 6.74 35.67132631479599 139.74363098830574 6.74 35.67132631479599 139.74363098830574 47.3 35.67134397551909 139.7436226837519 47.3 35.67134397551909 139.7436226837519 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7cc9c21c-770f-4a14-9ce4-652a67230fdd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cc9c21c-770f-4a14-9ce4-652a67230fdd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cc9c21c-770f-4a14-9ce4-652a67230fdd">
											<gml:posList>35.67132631479599 139.74363098830574 6.74 35.67130648674693 139.7436338825508 6.74 35.67130648674693 139.7436338825508 47.3 35.67132631479599 139.74363098830574 47.3 35.67132631479599 139.74363098830574 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b320f7b-925e-46fd-9594-d69dca20c9ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b320f7b-925e-46fd-9594-d69dca20c9ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b320f7b-925e-46fd-9594-d69dca20c9ba">
											<gml:posList>35.67130648674693 139.7436338825508 6.74 35.67128764740939 139.7436330199174 6.74 35.67128764740939 139.7436330199174 47.3 35.67130648674693 139.7436338825508 47.3 35.67130648674693 139.7436338825508 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39e03f0b-e79f-4946-8416-9030316625e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39e03f0b-e79f-4946-8416-9030316625e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39e03f0b-e79f-4946-8416-9030316625e3">
											<gml:posList>35.67133919610078 139.74364400863612 47.3 35.6713298431237 139.7436484045161 47.3 35.6713298431237 139.7436484045161 44.37 35.67133919610078 139.74364400863612 44.37 35.67133919610078 139.74364400863612 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1979946f-5dc6-43a5-9eb9-9b6e863cbc5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1979946f-5dc6-43a5-9eb9-9b6e863cbc5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1979946f-5dc6-43a5-9eb9-9b6e863cbc5c">
											<gml:posList>35.6713298431237 139.7436484045161 47.3 35.67130708592718 139.7436517217962 47.3 35.67130708592718 139.7436517217962 44.37 35.6713298431237 139.7436484045161 44.37 35.6713298431237 139.7436484045161 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e6c7c9c-030c-47eb-b8fe-44a5d51d8b96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e6c7c9c-030c-47eb-b8fe-44a5d51d8b96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e6c7c9c-030c-47eb-b8fe-44a5d51d8b96">
											<gml:posList>35.67130708592718 139.7436517217962 47.3 35.6712989102015 139.74365135536422 47.3 35.6712989102015 139.74365135536422 44.37 35.67130708592718 139.7436517217962 44.37 35.67130708592718 139.7436517217962 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4694a7ae-2fdf-4bb1-9c81-0c22d04eaba0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4694a7ae-2fdf-4bb1-9c81-0c22d04eaba0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4694a7ae-2fdf-4bb1-9c81-0c22d04eaba0">
											<gml:posList>35.67141264956168 139.7437295360811 6.74 35.67134397551909 139.7436226837519 6.74 35.67134397551909 139.7436226837519 47.3 35.67141264956168 139.7437295360811 47.3 35.67141264956168 139.7437295360811 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-282d3986-03ac-46d1-95df-772935e6b021">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-282d3986-03ac-46d1-95df-772935e6b021">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-282d3986-03ac-46d1-95df-772935e6b021">
											<gml:posList>35.671400894438506 139.74374001015994 47.3 35.67133919610078 139.74364400863612 47.3 35.67133919610078 139.74364400863612 44.37 35.671400894438506 139.74374001015994 44.37 35.671400894438506 139.74374001015994 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73f98225-54d8-43c8-8e87-e3eb298750eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73f98225-54d8-43c8-8e87-e3eb298750eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73f98225-54d8-43c8-8e87-e3eb298750eb">
											<gml:posList>35.67146662399888 139.743826794626 6.74 35.67141264956168 139.7437295360811 6.74 35.67141264956168 139.7437295360811 47.3 35.67146662399888 139.743826794626 47.3 35.67146662399888 139.743826794626 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1170a030-c44c-46da-bb65-42ade49c75b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1170a030-c44c-46da-bb65-42ade49c75b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1170a030-c44c-46da-bb65-42ade49c75b9">
											<gml:posList>35.67145443563397 139.74383649593267 47.3 35.671400894438506 139.74374001015994 47.3 35.671400894438506 139.74374001015994 44.37 35.67145443563397 139.74383649593267 44.37 35.67145443563397 139.74383649593267 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-746a0ea5-21c9-46bb-9882-6620aca69c3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-746a0ea5-21c9-46bb-9882-6620aca69c3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-746a0ea5-21c9-46bb-9882-6620aca69c3a">
											<gml:posList>35.671316689751265 139.7437905972999 44.37 35.671316689751265 139.7437905972999 40.819 35.671326108992304 139.74379045422336 40.819 35.671326108992304 139.74379045422336 44.37 35.671316689751265 139.7437905972999 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7adb551-8ef0-45bf-96d8-1253fb14c1e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7adb551-8ef0-45bf-96d8-1253fb14c1e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7adb551-8ef0-45bf-96d8-1253fb14c1e5">
											<gml:posList>35.671241845771 139.74393215185822 47.3 35.671241845771 139.74393215185822 44.37 35.6712989102015 139.74365135536422 44.37 35.6712989102015 139.74365135536422 47.3 35.671241845771 139.74393215185822 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a14dbb7-e863-4e3a-82c9-b9de5206f71c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a14dbb7-e863-4e3a-82c9-b9de5206f71c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a14dbb7-e863-4e3a-82c9-b9de5206f71c">
											<gml:posList>35.67128764740939 139.7436330199174 6.74 35.6712225361364 139.74395343766344 6.74 35.6712225361364 139.74395343766344 47.3 35.67128764740939 139.7436330199174 47.3 35.67128764740939 139.7436330199174 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5eea2c5-281c-49e5-aea9-30be20e94632">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5eea2c5-281c-49e5-aea9-30be20e94632">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5eea2c5-281c-49e5-aea9-30be20e94632">
											<gml:posList>35.671326108992304 139.74379045422336 44.37 35.671326108992304 139.74379045422336 40.819 35.67137656905857 139.7438769684809 40.819 35.67137656905857 139.7438769684809 44.37 35.671326108992304 139.74379045422336 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e774596-edf0-4967-88cb-b34d5646a557">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e774596-edf0-4967-88cb-b34d5646a557">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e774596-edf0-4967-88cb-b34d5646a557">
											<gml:posList>35.6712974347248 139.74388533051965 44.37 35.6712974347248 139.74388533051965 40.819 35.671316689751265 139.7437905972999 40.819 35.671316689751265 139.7437905972999 44.37 35.6712974347248 139.74388533051965 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a61d9159-c5ff-43d7-a576-1893f062ea18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a61d9159-c5ff-43d7-a576-1893f062ea18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a61d9159-c5ff-43d7-a576-1893f062ea18">
											<gml:posList>35.67148180589211 139.7438911782563 47.3 35.67145443563397 139.74383649593267 47.3 35.67145443563397 139.74383649593267 44.37 35.67148180589211 139.7438911782563 44.37 35.67148180589211 139.7438911782563 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0b05933-836d-468f-ad96-21a67dd10b18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0b05933-836d-468f-ad96-21a67dd10b18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0b05933-836d-468f-ad96-21a67dd10b18">
											<gml:posList>35.671505801743926 139.74390506996934 6.74 35.67146662399888 139.743826794626 6.74 35.67146662399888 139.743826794626 47.3 35.671505801743926 139.74390506996934 47.3 35.671505801743926 139.74390506996934 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e756986-081b-448c-87d1-ce5f6fdc019d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e756986-081b-448c-87d1-ce5f6fdc019d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e756986-081b-448c-87d1-ce5f6fdc019d">
											<gml:posList>35.67137656905857 139.7438769684809 44.37 35.67137656905857 139.7438769684809 40.819 35.6712974347248 139.74388533051965 40.819 35.6712974347248 139.74388533051965 44.37 35.67137656905857 139.7438769684809 44.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6fd1197b-60d9-439b-84aa-7d43b2ddc097">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fd1197b-60d9-439b-84aa-7d43b2ddc097">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fd1197b-60d9-439b-84aa-7d43b2ddc097">
											<gml:posList>35.67148180589211 139.7438911782563 47.3 35.67148180589211 139.7438911782563 44.37 35.671241845771 139.74393215185822 44.37 35.671241845771 139.74393215185822 47.3 35.67148180589211 139.7438911782563 47.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a4a0307-8bd8-44b1-ae0e-f4a88be677b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a4a0307-8bd8-44b1-ae0e-f4a88be677b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a4a0307-8bd8-44b1-ae0e-f4a88be677b6">
											<gml:posList>35.6712225361364 139.74395343766344 6.74 35.671505801743926 139.74390506996934 6.74 35.671505801743926 139.74390506996934 47.3 35.6712225361364 139.74395343766344 47.3 35.6712225361364 139.74395343766344 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区霞が関三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-3399</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">539.08125</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.52</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>