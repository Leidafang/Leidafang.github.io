<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b209b847-c9b4-48d4-97d8-41ad271322b6">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">36.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670899225166636 139.74490910691813 0 35.67096954127134 139.7445416280643 0 35.670795629564466 139.74449167038466 0 35.67073689673801 139.74479849146616 0 35.670774638077056 139.74487323333753 0 35.670899225166636 139.74490910691813 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670899225166636 139.74490910691813 7.08 35.670774638077056 139.74487323333753 7.08 35.67073689673801 139.74479849146616 7.08 35.670795629564466 139.74449167038466 7.08 35.67096954127134 139.7445416280643 7.08 35.670899225166636 139.74490910691813 7.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670899225166636 139.74490910691813 7.08 35.67096954127134 139.7445416280643 7.08 35.67096954127134 139.7445416280643 38.34 35.670899225166636 139.74490910691813 38.34 35.670899225166636 139.74490910691813 7.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67096954127134 139.7445416280643 7.08 35.670795629564466 139.74449167038466 7.08 35.670795629564466 139.74449167038466 38.34 35.67096954127134 139.7445416280643 38.34 35.67096954127134 139.7445416280643 7.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670795629564466 139.74449167038466 7.08 35.67073689673801 139.74479849146616 7.08 35.67073689673801 139.74479849146616 38.34 35.670795629564466 139.74449167038466 38.34 35.670795629564466 139.74449167038466 7.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67073689673801 139.74479849146616 7.08 35.670774638077056 139.74487323333753 7.08 35.670774638077056 139.74487323333753 38.34 35.67073689673801 139.74479849146616 38.34 35.67073689673801 139.74479849146616 7.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670774638077056 139.74487323333753 7.08 35.670899225166636 139.74490910691813 7.08 35.670899225166636 139.74490910691813 38.34 35.670774638077056 139.74487323333753 38.34 35.670774638077056 139.74487323333753 7.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670899225166636 139.74490910691813 38.34 35.67096954127134 139.7445416280643 38.34 35.670795629564466 139.74449167038466 38.34 35.67073689673801 139.74479849146616 38.34 35.670774638077056 139.74487323333753 38.34 35.670899225166636 139.74490910691813 38.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d4b53692-fa8e-40ea-8251-9972e9d5ef3c"/>
							<gml:surfaceMember xlink:href="#poly-c77a6b31-ebc7-41f2-9670-9555097a01da"/>
							<gml:surfaceMember xlink:href="#poly-6ca789a5-db15-4fc6-ad2d-5aea2246a674"/>
							<gml:surfaceMember xlink:href="#poly-58a6e614-f3b7-465e-930c-4c9c5aab98a4"/>
							<gml:surfaceMember xlink:href="#poly-1bbdfb7d-1fb5-413e-885f-1dd1033e726d"/>
							<gml:surfaceMember xlink:href="#poly-5b02aade-6210-4932-8a06-0ca5efd037d3"/>
							<gml:surfaceMember xlink:href="#poly-f9b56874-b5f9-4b24-962b-5a34677785a6"/>
							<gml:surfaceMember xlink:href="#poly-2b3fc5d4-5547-4394-9648-68ed05eda282"/>
							<gml:surfaceMember xlink:href="#poly-88f0b844-b390-4d3c-9485-1bcee06c1d80"/>
							<gml:surfaceMember xlink:href="#poly-85a0e929-47bb-4856-842b-338404407745"/>
							<gml:surfaceMember xlink:href="#poly-1a7cb537-3b73-4cb0-a71d-3d0079cf6bf6"/>
							<gml:surfaceMember xlink:href="#poly-86674fcb-c53d-47ab-b715-21f55b8c7ed4"/>
							<gml:surfaceMember xlink:href="#poly-9b929efd-965d-4034-9177-7df4a9640652"/>
							<gml:surfaceMember xlink:href="#poly-58838c73-e56b-44d2-9f3c-06207aa62fcd"/>
							<gml:surfaceMember xlink:href="#poly-5c95207f-54a7-4d5d-87cc-47222dfa1e8f"/>
							<gml:surfaceMember xlink:href="#poly-66ee8f8e-7470-4719-9e29-4271c5c1cf6f"/>
							<gml:surfaceMember xlink:href="#poly-71c393af-135e-402e-818c-369900c5f6a3"/>
							<gml:surfaceMember xlink:href="#poly-89bd3d89-3e21-4f58-acab-ca00303086e2"/>
							<gml:surfaceMember xlink:href="#poly-696074a5-210a-4e41-8db4-8ebff9a422f9"/>
							<gml:surfaceMember xlink:href="#poly-7f784343-b283-431a-9b10-789a0ab8a812"/>
							<gml:surfaceMember xlink:href="#poly-ed74f602-e704-45e1-9fe8-0ff68f2c1ee0"/>
							<gml:surfaceMember xlink:href="#poly-4b9cb08c-17f3-4d40-a3f2-29be08ce948e"/>
							<gml:surfaceMember xlink:href="#poly-0adf8a17-746e-4adc-a9ce-957e62ecd570"/>
							<gml:surfaceMember xlink:href="#poly-85825a1e-ac8c-49f0-b662-93527cf67299"/>
							<gml:surfaceMember xlink:href="#poly-6a6f29e3-d116-4dda-8ca2-8529e3ce2b5f"/>
							<gml:surfaceMember xlink:href="#poly-da05c032-1c71-4bcf-b52c-f6719d513dcd"/>
							<gml:surfaceMember xlink:href="#poly-92ea8268-0ee0-4ab8-bbae-d417f50377b1"/>
							<gml:surfaceMember xlink:href="#poly-570ea278-c286-4ba7-b09c-3fec2223f2be"/>
							<gml:surfaceMember xlink:href="#poly-ff287c32-0d0f-4ade-bc60-fe950ceb03a0"/>
							<gml:surfaceMember xlink:href="#poly-c48c20a4-b724-4ea9-a8da-f3626d147d11"/>
							<gml:surfaceMember xlink:href="#poly-6c999309-6e46-4232-b24e-04f28ddf0445"/>
							<gml:surfaceMember xlink:href="#poly-429a2969-55d8-4d2b-a1da-ec9ec0a1bd22"/>
							<gml:surfaceMember xlink:href="#poly-366f02e8-026d-45b1-86a0-1f50b0ab6a28"/>
							<gml:surfaceMember xlink:href="#poly-b185e0ef-cb07-4294-965f-7627717e7edd"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b209b847-c9b4-48d4-97d8-41ad271322b6_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ce39062-7728-4089-9094-5d4ea3d6ab7d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670882521432965 139.7447234255021 38.135 35.67088806551479 139.74472429203487 38.135 35.67089107713874 139.74472570263677 38.135 35.67089261134934 139.7447282526435 38.135 35.6708941463483 139.7447318741436 38.135 35.67089388006554 139.74473748597387 38.135 35.670892623305114 139.74474450178244 38.135 35.670890984099685 139.74474625996015 38.135 35.67088572206023 139.7447489500323 38.135 35.670880223445394 139.7447486247177 38.135 35.67087705789764 139.7447462753473 38.135 35.670875080925974 139.74474224562192 38.135 35.67087396848321 139.74473714344765 38.135 35.67087571043988 139.74472802830203 38.135 35.67087889821708 139.74472383822058 38.135 35.670882521432965 139.7447234255021 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e42f8d4-7f01-4fb0-99aa-d1b9c5b24c42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e42f8d4-7f01-4fb0-99aa-d1b9c5b24c42_0">
											<gml:posList>35.67087889821708 139.74472383822058 38.135 35.67087889821708 139.74472383822058 44.068 35.670882521432965 139.7447234255021 44.068 35.670882521432965 139.7447234255021 38.135 35.67087889821708 139.74472383822058 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77e7fc27-a4ee-4c2b-8b3b-80c1c8118029">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77e7fc27-a4ee-4c2b-8b3b-80c1c8118029_0">
											<gml:posList>35.670882521432965 139.7447234255021 38.135 35.670882521432965 139.7447234255021 44.068 35.67088806551479 139.74472429203487 44.068 35.67088806551479 139.74472429203487 38.135 35.670882521432965 139.7447234255021 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0961890-cce0-4ef2-80d3-136ccc08265a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0961890-cce0-4ef2-80d3-136ccc08265a_0">
											<gml:posList>35.67088806551479 139.74472429203487 38.135 35.67088806551479 139.74472429203487 44.068 35.67089107713874 139.74472570263677 44.068 35.67089107713874 139.74472570263677 38.135 35.67088806551479 139.74472429203487 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc0c260f-5c27-4f50-80dd-8cda3b63264f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc0c260f-5c27-4f50-80dd-8cda3b63264f_0">
											<gml:posList>35.67087571043988 139.74472802830203 44.068 35.67087889821708 139.74472383822058 44.068 35.67087889821708 139.74472383822058 38.135 35.67087571043988 139.74472802830203 38.135 35.67087571043988 139.74472802830203 44.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70ce0cc0-0d46-41fa-a431-a363b22f1f49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70ce0cc0-0d46-41fa-a431-a363b22f1f49_0">
											<gml:posList>35.67089107713874 139.74472570263677 38.135 35.67089107713874 139.74472570263677 44.068 35.67089261134934 139.7447282526435 44.068 35.67089261134934 139.7447282526435 38.135 35.67089107713874 139.74472570263677 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d0ca340-211c-498f-96b8-712941ada88d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d0ca340-211c-498f-96b8-712941ada88d_0">
											<gml:posList>35.67089261134934 139.7447282526435 44.068 35.6708941463483 139.7447318741436 44.068 35.6708941463483 139.7447318741436 38.135 35.67089261134934 139.7447282526435 38.135 35.67089261134934 139.7447282526435 44.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7408a94d-30c9-4778-a4db-e824377276de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7408a94d-30c9-4778-a4db-e824377276de_0">
											<gml:posList>35.67087396848321 139.74473714344765 38.135 35.67087396848321 139.74473714344765 44.068 35.67087571043988 139.74472802830203 44.068 35.67087571043988 139.74472802830203 38.135 35.67087396848321 139.74473714344765 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-450fdd91-dd98-4960-b5ed-07c73bae6a58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-450fdd91-dd98-4960-b5ed-07c73bae6a58_0">
											<gml:posList>35.6708941463483 139.7447318741436 38.135 35.6708941463483 139.7447318741436 44.068 35.67089388006554 139.74473748597387 44.068 35.67089388006554 139.74473748597387 38.135 35.6708941463483 139.7447318741436 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6947b637-799f-4882-85ee-fb7fde1f9fce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6947b637-799f-4882-85ee-fb7fde1f9fce_0">
											<gml:posList>35.67087571043988 139.74472802830203 44.068 35.67087396848321 139.74473714344765 44.068 35.670875080925974 139.74474224562192 44.068 35.67087705789764 139.7447462753473 44.068 35.670880223445394 139.7447486247177 44.068 35.67088572206023 139.7447489500323 44.068 35.670890984099685 139.74474625996015 44.068 35.670892623305114 139.74474450178244 44.068 35.67089388006554 139.74473748597387 44.068 35.6708941463483 139.7447318741436 44.068 35.67089261134934 139.7447282526435 44.068 35.67089107713874 139.74472570263677 44.068 35.67088806551479 139.74472429203487 44.068 35.670882521432965 139.7447234255021 44.068 35.67087889821708 139.74472383822058 44.068 35.67087571043988 139.74472802830203 44.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-058a1cfb-ea98-46f6-8b39-5049f6d8c1f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-058a1cfb-ea98-46f6-8b39-5049f6d8c1f2_0">
											<gml:posList>35.670875080925974 139.74474224562192 44.068 35.67087396848321 139.74473714344765 44.068 35.67087396848321 139.74473714344765 38.135 35.670875080925974 139.74474224562192 38.135 35.670875080925974 139.74474224562192 44.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1d7b132-8e9c-484e-ada5-f752becabb6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1d7b132-8e9c-484e-ada5-f752becabb6b_0">
											<gml:posList>35.67089388006554 139.74473748597387 44.068 35.670892623305114 139.74474450178244 44.068 35.670892623305114 139.74474450178244 38.135 35.67089388006554 139.74473748597387 38.135 35.67089388006554 139.74473748597387 44.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1d74147-5fc4-44a1-b0a1-67010cc587c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1d74147-5fc4-44a1-b0a1-67010cc587c5_0">
											<gml:posList>35.67087705789764 139.7447462753473 38.135 35.67087705789764 139.7447462753473 44.068 35.670875080925974 139.74474224562192 44.068 35.670875080925974 139.74474224562192 38.135 35.67087705789764 139.7447462753473 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db30373a-d098-4ba1-8e8a-ae633eb6ddd3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db30373a-d098-4ba1-8e8a-ae633eb6ddd3_0">
											<gml:posList>35.670892623305114 139.74474450178244 44.068 35.670890984099685 139.74474625996015 44.068 35.670890984099685 139.74474625996015 38.135 35.670892623305114 139.74474450178244 38.135 35.670892623305114 139.74474450178244 44.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3dd3cce-9722-4445-9b22-a27d5fcfa91f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3dd3cce-9722-4445-9b22-a27d5fcfa91f_0">
											<gml:posList>35.670880223445394 139.7447486247177 38.135 35.670880223445394 139.7447486247177 44.068 35.67087705789764 139.7447462753473 44.068 35.67087705789764 139.7447462753473 38.135 35.670880223445394 139.7447486247177 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a98d9a4-f178-49c3-aa3c-5552719211f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a98d9a4-f178-49c3-aa3c-5552719211f0_0">
											<gml:posList>35.670890984099685 139.74474625996015 38.135 35.670890984099685 139.74474625996015 44.068 35.67088572206023 139.7447489500323 44.068 35.67088572206023 139.7447489500323 38.135 35.670890984099685 139.74474625996015 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-510e59fc-650c-4491-b43e-1cd1476dcc96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-510e59fc-650c-4491-b43e-1cd1476dcc96_0">
											<gml:posList>35.67088572206023 139.7447489500323 44.068 35.670880223445394 139.7447486247177 44.068 35.670880223445394 139.7447486247177 38.135 35.67088572206023 139.7447489500323 38.135 35.67088572206023 139.7447489500323 44.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b209b847-c9b4-48d4-97d8-41ad271322b6_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35e16916-3f2a-4eb7-9feb-2d63bb8bfd8e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67086509389585 139.7445344642063 38.135 35.6708633249371 139.74454361252378 38.135 35.67084914329625 139.74453948585733 38.135 35.67085090324912 139.7445303485977 38.135 35.67086509389585 139.7445344642063 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3176a4a-2fb8-4758-bf3d-e3e1c611f8db">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67087338808504 139.74453657591502 38.135 35.67090461783644 139.74454496967877 38.135 35.670902939185176 139.74455434987348 38.135 35.67087170943441 139.7445459561063 38.135 35.67087338808504 139.74453657591502 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b63e718-4f7a-4c7f-864b-4568dbecce67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67085316654712 139.74455595147222 38.135 35.67085482694302 139.74454626200648 38.135 35.67088561465493 139.7445541591767 38.135 35.670885004360485 139.7445577388632 38.135 35.67090309833914 139.74456238038053 38.135 35.67090240726297 139.74456642410314 38.135 35.67088456571757 139.74456184858343 38.135 35.67088421569708 139.7445639035882 38.135 35.67085316654712 139.74455595147222 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c819de0-a85d-402e-a9c0-841a8beda512">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670841996135174 139.74456492240935 38.135 35.670860306728045 139.7445699503074 38.135 35.67085614116538 139.7445927545348 38.135 35.67083782155972 139.74458772664175 38.135 35.670841996135174 139.74456492240935 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cece19ba-088b-4ec9-9172-c051342a4266">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6708854871699 139.74457685952493 38.135 35.67088132160594 139.74459966375912 38.135 35.670862776608736 139.74459456983442 38.135 35.6708669511936 139.74457177664158 38.135 35.6708854871699 139.74457685952493 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdfd5a56-2af7-41df-adef-f607b2415107">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67092165719095 139.74461073173072 38.135 35.67090444650207 139.74460601189958 38.135 35.670908612067194 139.7445832076591 38.135 35.67092582276509 139.74458793853194 38.135 35.67092165719095 139.74461073173072 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c923d891-5dd1-4b3b-91f4-c6f614abddda">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67085985999277 139.74464871110595 46.496 35.67085545987943 139.74467127256935 46.496 35.670836554002726 139.74466572612957 46.496 35.670840954115036 139.7446431646712 46.496 35.67085985999277 139.74464871110595 46.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48e06cdc-0362-4526-b7cf-a600de38987d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670845066062284 139.74468217573866 46.496 35.670842634581646 139.74469744444633 46.496 35.670831428547956 139.74469477257847 46.496 35.670833851006414 139.74467949283653 46.496 35.670845066062284 139.74468217573866 46.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a46bc2c-6dbf-4d93-b168-3055cffd433a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67088191207523 139.744752787318 38.135 35.67090415304969 139.74475836323592 38.135 35.67090119156957 139.7447761069163 38.135 35.67087894157407 139.74477051995726 38.135 35.67088191207523 139.744752787318 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12839d32-e0c8-41c9-8887-3b19d22f4b2b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670803917569174 139.74479132572196 38.135 35.67080547052612 139.74478259741537 38.135 35.67083604210474 139.74479078211465 38.135 35.67083448013349 139.74479951043435 38.135 35.670803917569174 139.74479132572196 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e65f672d-62b7-49d9-9100-f33b3d8a0d7f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670797639756756 139.74481005616278 38.135 35.670822729723156 139.7448165236974 38.135 35.67082122191357 139.7448253624186 38.135 35.670796122933915 139.74481889489127 38.135 35.670797639756756 139.74481005616278 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c16d27da-60cd-494b-9340-f373016640fa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67083437831169 139.74482039914253 38.135 35.67085178670161 139.74482431241566 38.135 35.670850315685165 139.74483415631482 38.135 35.670832907295555 139.74483024303962 38.135 35.67083437831169 139.74482039914253 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d1932c4-384e-48e4-9be9-cb13dca052b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d1932c4-384e-48e4-9be9-cb13dca052b2_0">
											<gml:posList>35.67083604210474 139.74479078211465 38.135 35.67080547052612 139.74478259741537 38.135 35.67080547052612 139.74478259741537 40.897 35.67083604210474 139.74479078211465 40.897 35.67083604210474 139.74479078211465 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f63ad65-4b79-4ef4-beea-2c0070adb304">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f63ad65-4b79-4ef4-beea-2c0070adb304_0">
											<gml:posList>35.670803917569174 139.74479132572196 38.135 35.670803917569174 139.74479132572196 40.897 35.67080547052612 139.74478259741537 40.897 35.67080547052612 139.74478259741537 38.135 35.670803917569174 139.74479132572196 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e084b2ae-8a82-4bb4-afdb-30c864f74859">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e084b2ae-8a82-4bb4-afdb-30c864f74859_0">
											<gml:posList>35.670803917569174 139.74479132572196 40.897 35.67083448013349 139.74479951043435 40.897 35.67083604210474 139.74479078211465 40.897 35.67080547052612 139.74478259741537 40.897 35.670803917569174 139.74479132572196 40.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa9802b1-a94e-48cd-afc7-4dd2edcde616">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa9802b1-a94e-48cd-afc7-4dd2edcde616_0">
											<gml:posList>35.67083604210474 139.74479078211465 38.135 35.67083604210474 139.74479078211465 40.897 35.67083448013349 139.74479951043435 40.897 35.67083448013349 139.74479951043435 38.135 35.67083604210474 139.74479078211465 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-126c85a5-731c-4da0-a08f-109be86e2a33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-126c85a5-731c-4da0-a08f-109be86e2a33_0">
											<gml:posList>35.670803917569174 139.74479132572196 38.135 35.67083448013349 139.74479951043435 38.135 35.67083448013349 139.74479951043435 40.897 35.670803917569174 139.74479132572196 40.897 35.670803917569174 139.74479132572196 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e79688d3-224a-4e4c-b9bf-6ad25b8acecf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e79688d3-224a-4e4c-b9bf-6ad25b8acecf_0">
											<gml:posList>35.670822729723156 139.7448165236974 38.135 35.670797639756756 139.74481005616278 38.135 35.670797639756756 139.74481005616278 40.826 35.670822729723156 139.7448165236974 40.826 35.670822729723156 139.7448165236974 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2c24e40-b61b-49ff-8b06-3105bf64410f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2c24e40-b61b-49ff-8b06-3105bf64410f_0">
											<gml:posList>35.670797639756756 139.74481005616278 38.135 35.670796122933915 139.74481889489127 38.135 35.670796122933915 139.74481889489127 40.826 35.670797639756756 139.74481005616278 40.826 35.670797639756756 139.74481005616278 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b93be8af-8765-4976-8a8c-1897aa2b9119">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b93be8af-8765-4976-8a8c-1897aa2b9119_0">
											<gml:posList>35.67082122191357 139.7448253624186 40.826 35.670822729723156 139.7448165236974 40.826 35.670797639756756 139.74481005616278 40.826 35.670796122933915 139.74481889489127 40.826 35.67082122191357 139.7448253624186 40.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb6c1216-f380-495b-b66b-9e322384c217">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb6c1216-f380-495b-b66b-9e322384c217_0">
											<gml:posList>35.670822729723156 139.7448165236974 38.135 35.670822729723156 139.7448165236974 40.826 35.67082122191357 139.7448253624186 40.826 35.67082122191357 139.7448253624186 38.135 35.670822729723156 139.7448165236974 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1df7f212-13db-49f1-ba53-6c958fffcdeb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1df7f212-13db-49f1-ba53-6c958fffcdeb_0">
											<gml:posList>35.670796122933915 139.74481889489127 38.135 35.67082122191357 139.7448253624186 38.135 35.67082122191357 139.7448253624186 40.826 35.670796122933915 139.74481889489127 40.826 35.670796122933915 139.74481889489127 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6c8b94e-529c-498a-b14d-c99525d4b111">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6c8b94e-529c-498a-b14d-c99525d4b111_0">
											<gml:posList>35.67083437831169 139.74482039914253 38.135 35.67083437831169 139.74482039914253 40.826 35.67085178670161 139.74482431241566 40.826 35.67085178670161 139.74482431241566 38.135 35.67083437831169 139.74482039914253 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23d422c8-10b6-480b-9521-d1d8a75956d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23d422c8-10b6-480b-9521-d1d8a75956d9_0">
											<gml:posList>35.67083437831169 139.74482039914253 38.135 35.670832907295555 139.74483024303962 38.135 35.670832907295555 139.74483024303962 40.826 35.67083437831169 139.74482039914253 40.826 35.67083437831169 139.74482039914253 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a4c4cee-56b8-4138-a4da-757068903a24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a4c4cee-56b8-4138-a4da-757068903a24_0">
											<gml:posList>35.670850315685165 139.74483415631482 40.826 35.67085178670161 139.74482431241566 40.826 35.67083437831169 139.74482039914253 40.826 35.670832907295555 139.74483024303962 40.826 35.670850315685165 139.74483415631482 40.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e1fb79d-89ee-4754-a120-8f677e6dde9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e1fb79d-89ee-4754-a120-8f677e6dde9a_0">
											<gml:posList>35.67085178670161 139.74482431241566 38.135 35.67085178670161 139.74482431241566 40.826 35.670850315685165 139.74483415631482 40.826 35.670850315685165 139.74483415631482 38.135 35.67085178670161 139.74482431241566 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1392420-c88e-4521-ada3-761dc8e99e47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1392420-c88e-4521-ada3-761dc8e99e47_0">
											<gml:posList>35.670832907295555 139.74483024303962 38.135 35.670850315685165 139.74483415631482 38.135 35.670850315685165 139.74483415631482 40.826 35.670832907295555 139.74483024303962 40.826 35.670832907295555 139.74483024303962 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7389f7b9-7d17-4ec5-b74f-a16cd325542a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7389f7b9-7d17-4ec5-b74f-a16cd325542a_0">
											<gml:posList>35.67085090324912 139.7445303485977 38.135 35.67085090324912 139.7445303485977 41.037 35.67086509389585 139.7445344642063 41.037 35.67086509389585 139.7445344642063 38.135 35.67085090324912 139.7445303485977 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-106afdaa-57cc-4a5c-960d-40288f2b6ec4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-106afdaa-57cc-4a5c-960d-40288f2b6ec4_0">
											<gml:posList>35.67085090324912 139.7445303485977 38.135 35.67084914329625 139.74453948585733 38.135 35.67084914329625 139.74453948585733 41.037 35.67085090324912 139.7445303485977 41.037 35.67085090324912 139.7445303485977 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35c40e92-23aa-4bb1-a093-1019a7158427">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35c40e92-23aa-4bb1-a093-1019a7158427_0">
											<gml:posList>35.67084914329625 139.74453948585733 41.037 35.6708633249371 139.74454361252378 41.037 35.67086509389585 139.7445344642063 41.037 35.67085090324912 139.7445303485977 41.037 35.67084914329625 139.74453948585733 41.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad38dddf-3f75-4192-adf9-c8c8a9a2bc7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad38dddf-3f75-4192-adf9-c8c8a9a2bc7b_0">
											<gml:posList>35.6708633249371 139.74454361252378 38.135 35.67086509389585 139.7445344642063 38.135 35.67086509389585 139.7445344642063 41.037 35.6708633249371 139.74454361252378 41.037 35.6708633249371 139.74454361252378 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88d4b749-49d1-46c0-83b6-046387c54b72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88d4b749-49d1-46c0-83b6-046387c54b72_0">
											<gml:posList>35.67090461783644 139.74454496967877 38.135 35.67087338808504 139.74453657591502 38.135 35.67087338808504 139.74453657591502 41.037 35.67090461783644 139.74454496967877 41.037 35.67090461783644 139.74454496967877 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b2ba1be-ab07-4f1f-93a8-f02cd409551d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b2ba1be-ab07-4f1f-93a8-f02cd409551d_0">
											<gml:posList>35.67087338808504 139.74453657591502 38.135 35.67087170943441 139.7445459561063 38.135 35.67087170943441 139.7445459561063 41.037 35.67087338808504 139.74453657591502 41.037 35.67087338808504 139.74453657591502 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c60ba41b-eec6-4567-bc5a-1df835caf762">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c60ba41b-eec6-4567-bc5a-1df835caf762_0">
											<gml:posList>35.67084914329625 139.74453948585733 38.135 35.6708633249371 139.74454361252378 38.135 35.6708633249371 139.74454361252378 41.037 35.67084914329625 139.74453948585733 41.037 35.67084914329625 139.74453948585733 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0031f0ce-dfb8-4c44-acbe-12ace8e92744">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0031f0ce-dfb8-4c44-acbe-12ace8e92744_0">
											<gml:posList>35.670902939185176 139.74455434987348 41.037 35.67090461783644 139.74454496967877 41.037 35.67087338808504 139.74453657591502 41.037 35.67087170943441 139.7445459561063 41.037 35.670902939185176 139.74455434987348 41.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcfed5d6-bbce-42cc-9ba4-0c9915561b65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcfed5d6-bbce-42cc-9ba4-0c9915561b65_0">
											<gml:posList>35.670902939185176 139.74455434987348 38.135 35.67090461783644 139.74454496967877 38.135 35.67090461783644 139.74454496967877 41.037 35.670902939185176 139.74455434987348 41.037 35.670902939185176 139.74455434987348 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3dfa11d-6549-48f5-a438-880a2c691b72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3dfa11d-6549-48f5-a438-880a2c691b72_0">
											<gml:posList>35.67087170943441 139.7445459561063 38.135 35.670902939185176 139.74455434987348 38.135 35.670902939185176 139.74455434987348 41.037 35.67087170943441 139.7445459561063 41.037 35.67087170943441 139.7445459561063 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d543fd07-4fd5-4376-8c36-48f05fd98e39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d543fd07-4fd5-4376-8c36-48f05fd98e39_0">
											<gml:posList>35.67088561465493 139.7445541591767 38.135 35.67085482694302 139.74454626200648 38.135 35.67085482694302 139.74454626200648 41.037 35.67088561465493 139.7445541591767 41.037 35.67088561465493 139.7445541591767 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b0900be-ddfa-4898-bb3d-ac68227abced">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b0900be-ddfa-4898-bb3d-ac68227abced_0">
											<gml:posList>35.67085482694302 139.74454626200648 38.135 35.67085316654712 139.74455595147222 38.135 35.67085316654712 139.74455595147222 41.037 35.67085482694302 139.74454626200648 41.037 35.67085482694302 139.74454626200648 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75c3bc0c-5f82-41dd-8587-ebfae56259b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75c3bc0c-5f82-41dd-8587-ebfae56259b9_0">
											<gml:posList>35.670885004360485 139.7445577388632 38.135 35.67088561465493 139.7445541591767 38.135 35.67088561465493 139.7445541591767 41.037 35.670885004360485 139.7445577388632 41.037 35.670885004360485 139.7445577388632 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-332b4c9c-4690-47ec-8a8f-5ef37a9ebcef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-332b4c9c-4690-47ec-8a8f-5ef37a9ebcef_0">
											<gml:posList>35.67088456571757 139.74456184858343 41.037 35.67090240726297 139.74456642410314 41.037 35.67090309833914 139.74456238038053 41.037 35.670885004360485 139.7445577388632 41.037 35.67088561465493 139.7445541591767 41.037 35.67085482694302 139.74454626200648 41.037 35.67085316654712 139.74455595147222 41.037 35.67088421569708 139.7445639035882 41.037 35.67088456571757 139.74456184858343 41.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2ba76c1-6679-4804-9398-d627416f6d31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2ba76c1-6679-4804-9398-d627416f6d31_0">
											<gml:posList>35.67085316654712 139.74455595147222 38.135 35.67088421569708 139.7445639035882 38.135 35.67088421569708 139.7445639035882 41.037 35.67085316654712 139.74455595147222 41.037 35.67085316654712 139.74455595147222 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9479b83-1bb3-49fc-8d55-8167507af35b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9479b83-1bb3-49fc-8d55-8167507af35b_0">
											<gml:posList>35.67090309833914 139.74456238038053 38.135 35.670885004360485 139.7445577388632 38.135 35.670885004360485 139.7445577388632 41.037 35.67090309833914 139.74456238038053 41.037 35.67090309833914 139.74456238038053 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82bb5e80-ea52-4647-93a3-d028fab2e199">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82bb5e80-ea52-4647-93a3-d028fab2e199_0">
											<gml:posList>35.67088421569708 139.7445639035882 38.135 35.67088456571757 139.74456184858343 38.135 35.67088456571757 139.74456184858343 41.037 35.67088421569708 139.7445639035882 41.037 35.67088421569708 139.7445639035882 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59343600-5a91-44fb-b666-a0900c2812ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59343600-5a91-44fb-b666-a0900c2812ae_0">
											<gml:posList>35.67088456571757 139.74456184858343 38.135 35.67090240726297 139.74456642410314 38.135 35.67090240726297 139.74456642410314 41.037 35.67088456571757 139.74456184858343 41.037 35.67088456571757 139.74456184858343 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f95acf4-3172-419b-9b8f-79ef405db522">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f95acf4-3172-419b-9b8f-79ef405db522_0">
											<gml:posList>35.67090240726297 139.74456642410314 38.135 35.67090309833914 139.74456238038053 38.135 35.67090309833914 139.74456238038053 41.037 35.67090240726297 139.74456642410314 41.037 35.67090240726297 139.74456642410314 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf679f24-9425-4f4b-860e-780924631f1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf679f24-9425-4f4b-860e-780924631f1e_0">
											<gml:posList>35.670841996135174 139.74456492240935 38.135 35.670841996135174 139.74456492240935 41.779 35.670860306728045 139.7445699503074 41.779 35.670860306728045 139.7445699503074 38.135 35.670841996135174 139.74456492240935 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eec4a07a-0fd0-443c-a994-07f13aae9fb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eec4a07a-0fd0-443c-a994-07f13aae9fb7_0">
											<gml:posList>35.6708854871699 139.74457685952493 38.135 35.6708669511936 139.74457177664158 38.135 35.6708669511936 139.74457177664158 41.779 35.6708854871699 139.74457685952493 41.779 35.6708854871699 139.74457685952493 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de0529f7-1fbb-44eb-8d75-ee48f8d40bf3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de0529f7-1fbb-44eb-8d75-ee48f8d40bf3_0">
											<gml:posList>35.670841996135174 139.74456492240935 38.135 35.67083782155972 139.74458772664175 38.135 35.67083782155972 139.74458772664175 41.779 35.670841996135174 139.74456492240935 41.779 35.670841996135174 139.74456492240935 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5829b46b-3915-4996-aa0f-0f8d78f5ffe1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5829b46b-3915-4996-aa0f-0f8d78f5ffe1_0">
											<gml:posList>35.67085614116538 139.7445927545348 41.779 35.670860306728045 139.7445699503074 41.779 35.670841996135174 139.74456492240935 41.779 35.67083782155972 139.74458772664175 41.779 35.67085614116538 139.7445927545348 41.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa79be8f-52f8-449c-a37a-a5b203c7310a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa79be8f-52f8-449c-a37a-a5b203c7310a_0">
											<gml:posList>35.67085614116538 139.7445927545348 38.135 35.670860306728045 139.7445699503074 38.135 35.670860306728045 139.7445699503074 41.779 35.67085614116538 139.7445927545348 41.779 35.67085614116538 139.7445927545348 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d2e0c93-6f0f-43a1-b39a-f5ee9110d5bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d2e0c93-6f0f-43a1-b39a-f5ee9110d5bf_0">
											<gml:posList>35.6708669511936 139.74457177664158 38.135 35.670862776608736 139.74459456983442 38.135 35.670862776608736 139.74459456983442 41.779 35.6708669511936 139.74457177664158 41.779 35.6708669511936 139.74457177664158 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b4087dc-6ee9-4b1c-b8e2-69ed4f9f0ad8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b4087dc-6ee9-4b1c-b8e2-69ed4f9f0ad8_0">
											<gml:posList>35.670908612067194 139.7445832076591 38.135 35.670908612067194 139.7445832076591 41.779 35.67092582276509 139.74458793853194 41.779 35.67092582276509 139.74458793853194 38.135 35.670908612067194 139.7445832076591 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ed7ea1d-676c-412a-bcd2-1d26ddf2bdde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ed7ea1d-676c-412a-bcd2-1d26ddf2bdde_0">
											<gml:posList>35.670862776608736 139.74459456983442 41.779 35.67088132160594 139.74459966375912 41.779 35.6708854871699 139.74457685952493 41.779 35.6708669511936 139.74457177664158 41.779 35.670862776608736 139.74459456983442 41.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0651a4aa-5b01-468a-aa08-68f298f9af54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0651a4aa-5b01-468a-aa08-68f298f9af54_0">
											<gml:posList>35.67088132160594 139.74459966375912 38.135 35.6708854871699 139.74457685952493 38.135 35.6708854871699 139.74457685952493 41.779 35.67088132160594 139.74459966375912 41.779 35.67088132160594 139.74459966375912 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d4ea3a0-f192-4b46-9951-7ee4c96c3a15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d4ea3a0-f192-4b46-9951-7ee4c96c3a15_0">
											<gml:posList>35.67083782155972 139.74458772664175 38.135 35.67085614116538 139.7445927545348 38.135 35.67085614116538 139.7445927545348 41.779 35.67083782155972 139.74458772664175 41.779 35.67083782155972 139.74458772664175 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0278ece9-73a7-4b56-bf28-f39765a70638">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0278ece9-73a7-4b56-bf28-f39765a70638_0">
											<gml:posList>35.670908612067194 139.7445832076591 38.135 35.67090444650207 139.74460601189958 38.135 35.67090444650207 139.74460601189958 41.779 35.670908612067194 139.7445832076591 41.779 35.670908612067194 139.7445832076591 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e64442d-bd1a-4ccb-bdcd-922ba4c885eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e64442d-bd1a-4ccb-bdcd-922ba4c885eb_0">
											<gml:posList>35.67092165719095 139.74461073173072 41.779 35.67092582276509 139.74458793853194 41.779 35.670908612067194 139.7445832076591 41.779 35.67090444650207 139.74460601189958 41.779 35.67092165719095 139.74461073173072 41.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c242678a-0a61-4a53-ad92-d7aacbecd94c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c242678a-0a61-4a53-ad92-d7aacbecd94c_0">
											<gml:posList>35.67088132160594 139.74459966375912 38.135 35.67088132160594 139.74459966375912 41.779 35.670862776608736 139.74459456983442 41.779 35.670862776608736 139.74459456983442 38.135 35.67088132160594 139.74459966375912 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81ae174e-b880-4c3c-a1b4-4c3f869d61ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81ae174e-b880-4c3c-a1b4-4c3f869d61ac_0">
											<gml:posList>35.67092165719095 139.74461073173072 38.135 35.67092582276509 139.74458793853194 38.135 35.67092582276509 139.74458793853194 41.779 35.67092165719095 139.74461073173072 41.779 35.67092165719095 139.74461073173072 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6ce9eef-9a2e-4b45-a389-6a8809341b8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6ce9eef-9a2e-4b45-a389-6a8809341b8d_0">
											<gml:posList>35.67092165719095 139.74461073173072 38.135 35.67092165719095 139.74461073173072 41.779 35.67090444650207 139.74460601189958 41.779 35.67090444650207 139.74460601189958 38.135 35.67092165719095 139.74461073173072 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3df94e5d-ba89-4d9f-8490-df415458f097">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3df94e5d-ba89-4d9f-8490-df415458f097_0">
											<gml:posList>35.67085985999277 139.74464871110595 46.496 35.670840954115036 139.7446431646712 46.496 35.670840954115036 139.7446431646712 48.535 35.67085985999277 139.74464871110595 48.535 35.67085985999277 139.74464871110595 46.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51b3c1a7-40fc-4106-bbf9-2f35e73ab15e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51b3c1a7-40fc-4106-bbf9-2f35e73ab15e_0">
											<gml:posList>35.670840954115036 139.7446431646712 46.496 35.670836554002726 139.74466572612957 46.496 35.670836554002726 139.74466572612957 48.535 35.670840954115036 139.7446431646712 48.535 35.670840954115036 139.7446431646712 46.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b7fd602-e238-4b9a-832f-ca81880ec6fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b7fd602-e238-4b9a-832f-ca81880ec6fe_0">
											<gml:posList>35.670836554002726 139.74466572612957 48.535 35.67085545987943 139.74467127256935 48.535 35.67085985999277 139.74464871110595 48.535 35.670840954115036 139.7446431646712 48.535 35.670836554002726 139.74466572612957 48.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d63df42-5dae-4a62-8c58-d2f88a28fb01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d63df42-5dae-4a62-8c58-d2f88a28fb01_0">
											<gml:posList>35.67085545987943 139.74467127256935 46.496 35.67085985999277 139.74464871110595 46.496 35.67085985999277 139.74464871110595 48.535 35.67085545987943 139.74467127256935 48.535 35.67085545987943 139.74467127256935 46.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b435e05-ca0d-488e-8ed3-b42f0ea9fa90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b435e05-ca0d-488e-8ed3-b42f0ea9fa90_0">
											<gml:posList>35.670836554002726 139.74466572612957 46.496 35.67085545987943 139.74467127256935 46.496 35.67085545987943 139.74467127256935 48.535 35.670836554002726 139.74466572612957 48.535 35.670836554002726 139.74466572612957 46.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9e5c451-4c45-4c97-98ae-2f15e46777f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9e5c451-4c45-4c97-98ae-2f15e46777f8_0">
											<gml:posList>35.670845066062284 139.74468217573866 46.496 35.670833851006414 139.74467949283653 46.496 35.670833851006414 139.74467949283653 48.31 35.670845066062284 139.74468217573866 48.31 35.670845066062284 139.74468217573866 46.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42397012-0949-40fb-8f69-a9e202d88865">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42397012-0949-40fb-8f69-a9e202d88865_0">
											<gml:posList>35.670831428547956 139.74469477257847 46.496 35.670831428547956 139.74469477257847 48.31 35.670833851006414 139.74467949283653 48.31 35.670833851006414 139.74467949283653 46.496 35.670831428547956 139.74469477257847 46.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-625d91f9-f788-465d-b2b3-28b9c44523b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-625d91f9-f788-465d-b2b3-28b9c44523b9_0">
											<gml:posList>35.670831428547956 139.74469477257847 48.31 35.670842634581646 139.74469744444633 48.31 35.670845066062284 139.74468217573866 48.31 35.670833851006414 139.74467949283653 48.31 35.670831428547956 139.74469477257847 48.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6be73711-8106-4d58-bba0-b22539eb349b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6be73711-8106-4d58-bba0-b22539eb349b_0">
											<gml:posList>35.670842634581646 139.74469744444633 46.496 35.670845066062284 139.74468217573866 46.496 35.670845066062284 139.74468217573866 48.31 35.670842634581646 139.74469744444633 48.31 35.670842634581646 139.74469744444633 46.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25b42ae4-3d2d-4445-8337-068c6a46fb88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25b42ae4-3d2d-4445-8337-068c6a46fb88_0">
											<gml:posList>35.670831428547956 139.74469477257847 46.496 35.670842634581646 139.74469744444633 46.496 35.670842634581646 139.74469744444633 48.31 35.670831428547956 139.74469477257847 48.31 35.670831428547956 139.74469477257847 46.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98d7f524-8199-4741-a0c5-df6428625a87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98d7f524-8199-4741-a0c5-df6428625a87_0">
											<gml:posList>35.67090415304969 139.74475836323592 38.135 35.67088191207523 139.744752787318 38.135 35.67088191207523 139.744752787318 39.797 35.67090415304969 139.74475836323592 39.797 35.67090415304969 139.74475836323592 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73d4dc8e-ff94-426a-9afd-76d1c6b0f925">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73d4dc8e-ff94-426a-9afd-76d1c6b0f925_0">
											<gml:posList>35.67088191207523 139.744752787318 38.135 35.67087894157407 139.74477051995726 38.135 35.67087894157407 139.74477051995726 39.797 35.67088191207523 139.744752787318 39.797 35.67088191207523 139.744752787318 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26d76fc2-5dfd-49e2-ba88-1eb94de06ef0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26d76fc2-5dfd-49e2-ba88-1eb94de06ef0_0">
											<gml:posList>35.67090119156957 139.7447761069163 39.797 35.67090415304969 139.74475836323592 39.797 35.67088191207523 139.744752787318 39.797 35.67087894157407 139.74477051995726 39.797 35.67090119156957 139.7447761069163 39.797</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b23282b-0a5a-46c9-bd46-9de2d6a9bf13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b23282b-0a5a-46c9-bd46-9de2d6a9bf13_0">
											<gml:posList>35.67090119156957 139.7447761069163 38.135 35.67090415304969 139.74475836323592 38.135 35.67090415304969 139.74475836323592 39.797 35.67090119156957 139.7447761069163 39.797 35.67090119156957 139.7447761069163 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-999bf537-2254-48f8-94cb-91aeb22f17d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-999bf537-2254-48f8-94cb-91aeb22f17d5_0">
											<gml:posList>35.67087894157407 139.74477051995726 38.135 35.67090119156957 139.7447761069163 38.135 35.67090119156957 139.7447761069163 39.797 35.67087894157407 139.74477051995726 39.797 35.67087894157407 139.74477051995726 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b209b847-c9b4-48d4-97d8-41ad271322b6_BuildingInstallation_1030">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69e1d76e-8565-4ecf-b210-fa56d529fd0b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67083664774213 139.74475635005777 49.247 35.670839530168344 139.74474142329075 49.247 35.670853693758644 139.74474552791972 49.247 35.670850811331924 139.74476045468924 49.247 35.67083664774213 139.74475635005777 49.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ea79f4a-f6d1-4e22-bdbe-9da9e72aae7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ea79f4a-f6d1-4e22-bdbe-9da9e72aae7b_0">
											<gml:posList>35.670839530168344 139.74474142329075 50.527 35.670839530168344 139.74474142329075 49.247 35.67083664774213 139.74475635005777 49.247 35.67083664774213 139.74475635005777 50.527 35.670839530168344 139.74474142329075 50.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-140cfa46-d0e9-43e5-bcc8-932e3825255d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-140cfa46-d0e9-43e5-bcc8-932e3825255d_0">
											<gml:posList>35.67083664774213 139.74475635005777 50.527 35.67083664774213 139.74475635005777 49.247 35.670850811331924 139.74476045468924 49.247 35.670850811331924 139.74476045468924 50.527 35.67083664774213 139.74475635005777 50.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6c44662-1d1f-41ef-bf8f-71d62ea4c8a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6c44662-1d1f-41ef-bf8f-71d62ea4c8a3_0">
											<gml:posList>35.670850811331924 139.74476045468924 50.527 35.670853693758644 139.74474552791972 50.527 35.670839530168344 139.74474142329075 50.527 35.67083664774213 139.74475635005777 50.527 35.670850811331924 139.74476045468924 50.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-190e0a18-c053-4fca-95dd-6899b3632c53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-190e0a18-c053-4fca-95dd-6899b3632c53_0">
											<gml:posList>35.670853693758644 139.74474552791972 50.527 35.670853693758644 139.74474552791972 49.247 35.670839530168344 139.74474142329075 49.247 35.670839530168344 139.74474142329075 50.527 35.670853693758644 139.74474552791972 50.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-199fa735-613f-49a5-892a-2debc558414e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-199fa735-613f-49a5-892a-2debc558414e_0">
											<gml:posList>35.670850811331924 139.74476045468924 50.527 35.670850811331924 139.74476045468924 49.247 35.670853693758644 139.74474552791972 49.247 35.670853693758644 139.74474552791972 50.527 35.670850811331924 139.74476045468924 50.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d4b53692-fa8e-40ea-8251-9972e9d5ef3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4b53692-fa8e-40ea-8251-9972e9d5ef3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4b53692-fa8e-40ea-8251-9972e9d5ef3c">
											<gml:posList>35.670899225166615 139.74490910691813 7.142 35.67077463807703 139.74487323333753 7.142 35.670736896738 139.74479849146613 7.142 35.67079562956445 139.74449167038466 7.142 35.67096954127133 139.7445416280643 7.142 35.670899225166615 139.74490910691813 7.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c77a6b31-ebc7-41f2-9670-9555097a01da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c77a6b31-ebc7-41f2-9670-9555097a01da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c77a6b31-ebc7-41f2-9670-9555097a01da">
											<gml:posList>35.67079562956445 139.74449167038466 38.762 35.67079948407196 139.74449932121166 38.762 35.67096330726132 139.74454636280183 38.762 35.67096954127133 139.7445416280643 38.762 35.67079562956445 139.74449167038466 38.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ca789a5-db15-4fc6-ad2d-5aea2246a674">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ca789a5-db15-4fc6-ad2d-5aea2246a674">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ca789a5-db15-4fc6-ad2d-5aea2246a674">
											<gml:posList>35.67096330726132 139.74454636280183 38.135 35.67079948407196 139.74449932121166 38.135 35.67077721581168 139.74461568566934 38.135 35.67082644128675 139.7446299472322 38.135 35.670890082786315 139.7446483794249 38.135 35.670940967139565 139.74466312523194 38.135 35.67096330726132 139.74454636280183 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-58a6e614-f3b7-465e-930c-4c9c5aab98a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58a6e614-f3b7-465e-930c-4c9c5aab98a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58a6e614-f3b7-465e-930c-4c9c5aab98a4">
											<gml:posList>35.67082644128675 139.7446299472322 49.247 35.67082845428452 139.7446339327272 49.247 35.670886821632834 139.74465084636367 49.247 35.670890082786315 139.7446483794249 49.247 35.67082644128675 139.7446299472322 49.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1bbdfb7d-1fb5-413e-885f-1dd1033e726d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bbdfb7d-1fb5-413e-885f-1dd1033e726d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bbdfb7d-1fb5-413e-885f-1dd1033e726d">
											<gml:posList>35.670736896738 139.74479849146613 38.762 35.67074243035187 139.74479738072466 38.762 35.67079948407196 139.74449932121166 38.762 35.67079562956445 139.74449167038466 38.762 35.670736896738 139.74479849146613 38.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b02aade-6210-4932-8a06-0ca5efd037d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b02aade-6210-4932-8a06-0ca5efd037d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b02aade-6210-4932-8a06-0ca5efd037d3">
											<gml:posList>35.67081275663464 139.7447009349748 49.247 35.67081599976175 139.74469846806025 49.247 35.67082845428452 139.7446339327272 49.247 35.67082644128675 139.7446299472322 49.247 35.67081275663464 139.7447009349748 49.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9b56874-b5f9-4b24-962b-5a34677785a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9b56874-b5f9-4b24-962b-5a34677785a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9b56874-b5f9-4b24-962b-5a34677785a6">
											<gml:posList>35.67088683064656 139.7446508463537 46.496 35.67082845428452 139.7446339327272 46.496 35.67081599976175 139.74469846806025 46.496 35.67087437612303 139.74471539277747 46.496 35.67088683064656 139.7446508463537 46.496</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2b3fc5d4-5547-4394-9648-68ed05eda282">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b3fc5d4-5547-4394-9648-68ed05eda282">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b3fc5d4-5547-4394-9648-68ed05eda282">
											<gml:posList>35.67077721581168 139.74461568566934 38.135 35.67075489353525 139.744732293141 38.135 35.670803965722854 139.74474649970932 38.135 35.67082644128675 139.7446299472322 38.135 35.67077721581168 139.74461568566934 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-88f0b844-b390-4d3c-9485-1bcee06c1d80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88f0b844-b390-4d3c-9485-1bcee06c1d80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88f0b844-b390-4d3c-9485-1bcee06c1d80">
											<gml:posList>35.670890082786315 139.7446483794249 49.247 35.670886821632834 139.74465084636367 49.247 35.67087437612303 139.74471539277747 49.247 35.67087638910984 139.7447193672307 49.247 35.670890082786315 139.7446483794249 49.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-85a0e929-47bb-4856-842b-338404407745">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85a0e929-47bb-4856-842b-338404407745">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85a0e929-47bb-4856-842b-338404407745">
											<gml:posList>35.67087638910984 139.7447193672307 49.247 35.67087437612303 139.74471539277747 49.247 35.67081599976175 139.74469846806025 49.247 35.67081275663464 139.7447009349748 49.247 35.67087638910984 139.7447193672307 49.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a7cb537-3b73-4cb0-a71d-3d0079cf6bf6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a7cb537-3b73-4cb0-a71d-3d0079cf6bf6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a7cb537-3b73-4cb0-a71d-3d0079cf6bf6">
											<gml:posList>35.670940967139565 139.74466312523194 38.135 35.670890082786315 139.7446483794249 38.135 35.67086759819122 139.7447649319994 38.135 35.67091865382373 139.7447797218725 38.135 35.670940967139565 139.74466312523194 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-86674fcb-c53d-47ab-b715-21f55b8c7ed4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86674fcb-c53d-47ab-b715-21f55b8c7ed4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86674fcb-c53d-47ab-b715-21f55b8c7ed4">
											<gml:posList>35.67096954127133 139.7445416280643 38.762 35.67096330726132 139.74454636280183 38.762 35.67089536167954 139.74490146711813 38.762 35.670899225166615 139.74490910691813 38.762 35.67096954127133 139.7445416280643 38.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b929efd-965d-4034-9177-7df4a9640652">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b929efd-965d-4034-9177-7df4a9640652">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b929efd-965d-4034-9177-7df4a9640652">
											<gml:posList>35.670803965722854 139.74474649970932 49.247 35.67086759819122 139.7447649319994 49.247 35.67087638910984 139.7447193672307 49.247 35.67081275663464 139.7447009349748 49.247 35.670803965722854 139.74474649970932 49.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-58838c73-e56b-44d2-9f3c-06207aa62fcd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58838c73-e56b-44d2-9f3c-06207aa62fcd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58838c73-e56b-44d2-9f3c-06207aa62fcd">
											<gml:posList>35.67077791496593 139.74486764028683 38.135 35.67089536167954 139.74490146711813 38.135 35.67091865382373 139.7447797218725 38.135 35.67086759819122 139.7447649319994 38.135 35.670803965722854 139.74474649970932 38.135 35.67075489353525 139.744732293141 38.135 35.67074243035187 139.74479738072466 38.135 35.67077791496593 139.74486764028683 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c95207f-54a7-4d5d-87cc-47222dfa1e8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c95207f-54a7-4d5d-87cc-47222dfa1e8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c95207f-54a7-4d5d-87cc-47222dfa1e8f">
											<gml:posList>35.67077463807703 139.74487323333753 38.762 35.67077791496593 139.74486764028683 38.762 35.67074243035187 139.74479738072466 38.762 35.670736896738 139.74479849146613 38.762 35.67077463807703 139.74487323333753 38.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66ee8f8e-7470-4719-9e29-4271c5c1cf6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66ee8f8e-7470-4719-9e29-4271c5c1cf6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66ee8f8e-7470-4719-9e29-4271c5c1cf6f">
											<gml:posList>35.67077463807703 139.74487323333753 38.762 35.670899225166615 139.74490910691813 38.762 35.67089536167954 139.74490146711813 38.762 35.67077791496593 139.74486764028683 38.762 35.67077463807703 139.74487323333753 38.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71c393af-135e-402e-818c-369900c5f6a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71c393af-135e-402e-818c-369900c5f6a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71c393af-135e-402e-818c-369900c5f6a3">
											<gml:posList>35.67096954127133 139.7445416280643 7.142 35.67079562956445 139.74449167038466 7.142 35.67079562956445 139.74449167038466 38.762 35.67096954127133 139.7445416280643 38.762 35.67096954127133 139.7445416280643 7.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-89bd3d89-3e21-4f58-acab-ca00303086e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89bd3d89-3e21-4f58-acab-ca00303086e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89bd3d89-3e21-4f58-acab-ca00303086e2">
											<gml:posList>35.67079948407196 139.74449932121166 38.762 35.67079948407196 139.74449932121166 38.135 35.67096330726132 139.74454636280183 38.135 35.67096330726132 139.74454636280183 38.762 35.67079948407196 139.74449932121166 38.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-696074a5-210a-4e41-8db4-8ebff9a422f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-696074a5-210a-4e41-8db4-8ebff9a422f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-696074a5-210a-4e41-8db4-8ebff9a422f9">
											<gml:posList>35.67082644128675 139.7446299472322 49.247 35.670890082786315 139.7446483794249 49.247 35.670890082786315 139.7446483794249 38.135 35.67082644128675 139.7446299472322 38.135 35.67082644128675 139.7446299472322 49.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f784343-b283-431a-9b10-789a0ab8a812">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f784343-b283-431a-9b10-789a0ab8a812">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f784343-b283-431a-9b10-789a0ab8a812">
											<gml:posList>35.67082845428452 139.7446339327272 49.247 35.67082845428452 139.7446339327272 46.496 35.67088683064656 139.7446508463537 46.496 35.670886821632834 139.74465084636367 49.247 35.67082845428452 139.7446339327272 49.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed74f602-e704-45e1-9fe8-0ff68f2c1ee0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed74f602-e704-45e1-9fe8-0ff68f2c1ee0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed74f602-e704-45e1-9fe8-0ff68f2c1ee0">
											<gml:posList>35.67079562956445 139.74449167038466 7.142 35.670736896738 139.74479849146613 7.142 35.670736896738 139.74479849146613 38.762 35.67079562956445 139.74449167038466 38.762 35.67079562956445 139.74449167038466 7.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b9cb08c-17f3-4d40-a3f2-29be08ce948e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b9cb08c-17f3-4d40-a3f2-29be08ce948e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b9cb08c-17f3-4d40-a3f2-29be08ce948e">
											<gml:posList>35.67074243035187 139.74479738072466 38.762 35.67074243035187 139.74479738072466 38.135 35.67075489353525 139.744732293141 38.135 35.67077721581168 139.74461568566934 38.135 35.67079948407196 139.74449932121166 38.135 35.67079948407196 139.74449932121166 38.762 35.67074243035187 139.74479738072466 38.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0adf8a17-746e-4adc-a9ce-957e62ecd570">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0adf8a17-746e-4adc-a9ce-957e62ecd570">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0adf8a17-746e-4adc-a9ce-957e62ecd570">
											<gml:posList>35.67081599976175 139.74469846806025 49.247 35.67081599976175 139.74469846806025 46.496 35.67082845428452 139.7446339327272 46.496 35.67082845428452 139.7446339327272 49.247 35.67081599976175 139.74469846806025 49.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85825a1e-ac8c-49f0-b662-93527cf67299">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85825a1e-ac8c-49f0-b662-93527cf67299">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85825a1e-ac8c-49f0-b662-93527cf67299">
											<gml:posList>35.670886821632834 139.74465084636367 49.247 35.67088683064656 139.7446508463537 46.496 35.67087437612303 139.74471539277747 46.496 35.67087437612303 139.74471539277747 49.247 35.670886821632834 139.74465084636367 49.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a6f29e3-d116-4dda-8ca2-8529e3ce2b5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a6f29e3-d116-4dda-8ca2-8529e3ce2b5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a6f29e3-d116-4dda-8ca2-8529e3ce2b5f">
											<gml:posList>35.670803965722854 139.74474649970932 38.135 35.670803965722854 139.74474649970932 49.247 35.67081275663464 139.7447009349748 49.247 35.67082644128675 139.7446299472322 49.247 35.67082644128675 139.7446299472322 38.135 35.670803965722854 139.74474649970932 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da05c032-1c71-4bcf-b52c-f6719d513dcd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da05c032-1c71-4bcf-b52c-f6719d513dcd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da05c032-1c71-4bcf-b52c-f6719d513dcd">
											<gml:posList>35.670890082786315 139.7446483794249 38.135 35.670890082786315 139.7446483794249 49.247 35.67087638910984 139.7447193672307 49.247 35.67086759819122 139.7447649319994 49.247 35.67086759819122 139.7447649319994 38.135 35.670890082786315 139.7446483794249 38.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92ea8268-0ee0-4ab8-bbae-d417f50377b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92ea8268-0ee0-4ab8-bbae-d417f50377b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92ea8268-0ee0-4ab8-bbae-d417f50377b1">
											<gml:posList>35.67087437612303 139.74471539277747 49.247 35.67087437612303 139.74471539277747 46.496 35.67081599976175 139.74469846806025 46.496 35.67081599976175 139.74469846806025 49.247 35.67087437612303 139.74471539277747 49.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-570ea278-c286-4ba7-b09c-3fec2223f2be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-570ea278-c286-4ba7-b09c-3fec2223f2be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-570ea278-c286-4ba7-b09c-3fec2223f2be">
											<gml:posList>35.67096330726132 139.74454636280183 38.762 35.67096330726132 139.74454636280183 38.135 35.670940967139565 139.74466312523194 38.135 35.67091865382373 139.7447797218725 38.135 35.67089536167954 139.74490146711813 38.135 35.67089536167954 139.74490146711813 38.762 35.67096330726132 139.74454636280183 38.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff287c32-0d0f-4ade-bc60-fe950ceb03a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff287c32-0d0f-4ade-bc60-fe950ceb03a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff287c32-0d0f-4ade-bc60-fe950ceb03a0">
											<gml:posList>35.670899225166615 139.74490910691813 7.142 35.67096954127133 139.7445416280643 7.142 35.67096954127133 139.7445416280643 38.762 35.670899225166615 139.74490910691813 38.762 35.670899225166615 139.74490910691813 7.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c48c20a4-b724-4ea9-a8da-f3626d147d11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c48c20a4-b724-4ea9-a8da-f3626d147d11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c48c20a4-b724-4ea9-a8da-f3626d147d11">
											<gml:posList>35.67086759819122 139.7447649319994 49.247 35.670803965722854 139.74474649970932 49.247 35.670803965722854 139.74474649970932 38.135 35.67086759819122 139.7447649319994 38.135 35.67086759819122 139.7447649319994 49.247</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c999309-6e46-4232-b24e-04f28ddf0445">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c999309-6e46-4232-b24e-04f28ddf0445">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c999309-6e46-4232-b24e-04f28ddf0445">
											<gml:posList>35.67077791496593 139.74486764028683 38.762 35.67077791496593 139.74486764028683 38.135 35.67074243035187 139.74479738072466 38.135 35.67074243035187 139.74479738072466 38.762 35.67077791496593 139.74486764028683 38.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-429a2969-55d8-4d2b-a1da-ec9ec0a1bd22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-429a2969-55d8-4d2b-a1da-ec9ec0a1bd22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-429a2969-55d8-4d2b-a1da-ec9ec0a1bd22">
											<gml:posList>35.670736896738 139.74479849146613 7.142 35.67077463807703 139.74487323333753 7.142 35.67077463807703 139.74487323333753 38.762 35.670736896738 139.74479849146613 38.762 35.670736896738 139.74479849146613 7.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-366f02e8-026d-45b1-86a0-1f50b0ab6a28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-366f02e8-026d-45b1-86a0-1f50b0ab6a28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-366f02e8-026d-45b1-86a0-1f50b0ab6a28">
											<gml:posList>35.67089536167954 139.74490146711813 38.762 35.67089536167954 139.74490146711813 38.135 35.67077791496593 139.74486764028683 38.135 35.67077791496593 139.74486764028683 38.762 35.67089536167954 139.74490146711813 38.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b185e0ef-cb07-4294-965f-7627717e7edd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b185e0ef-cb07-4294-965f-7627717e7edd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b185e0ef-cb07-4294-965f-7627717e7edd">
											<gml:posList>35.67077463807703 139.74487323333753 7.142 35.670899225166615 139.74490910691813 7.142 35.670899225166615 139.74490910691813 38.762 35.67077463807703 139.74487323333753 38.762 35.67077463807703 139.74487323333753 7.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8801</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">661.2622</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.14</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>