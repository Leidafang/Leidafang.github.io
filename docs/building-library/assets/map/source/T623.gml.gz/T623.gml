<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b47c007a-7781-478e-bd76-479a06fc16db">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">113.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>12</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>2</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66977093343013 139.74978434393267 0 35.669717599948996 139.74994149812386 0 35.66998737694291 139.75007898582083 0 35.67016655131763 139.7495453330971 0 35.67010561322194 139.7494083352502 0 35.66991894459931 139.74931320196274 0 35.669858073701974 139.74949257852555 0 35.66984768619814 139.7494872872177 0 35.66975041993746 139.74977389353572 0 35.66977093343013 139.74978434393267 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66977093343013 139.74978434393267 6.06 35.66975041993746 139.74977389353572 6.06 35.66984768619814 139.7494872872177 6.06 35.669858073701974 139.74949257852555 6.06 35.66991894459931 139.74931320196274 6.06 35.67010561322194 139.7494083352502 6.06 35.67016655131763 139.7495453330971 6.06 35.66998737694291 139.75007898582083 6.06 35.669717599948996 139.74994149812386 6.06 35.66977093343013 139.74978434393267 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66977093343013 139.74978434393267 6.06 35.669717599948996 139.74994149812386 6.06 35.669717599948996 139.74994149812386 114.82 35.66977093343013 139.74978434393267 114.82 35.66977093343013 139.74978434393267 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669717599948996 139.74994149812386 6.06 35.66998737694291 139.75007898582083 6.06 35.66998737694291 139.75007898582083 114.82 35.669717599948996 139.74994149812386 114.82 35.669717599948996 139.74994149812386 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66998737694291 139.75007898582083 6.06 35.67016655131763 139.7495453330971 6.06 35.67016655131763 139.7495453330971 114.82 35.66998737694291 139.75007898582083 114.82 35.66998737694291 139.75007898582083 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67016655131763 139.7495453330971 6.06 35.67010561322194 139.7494083352502 6.06 35.67010561322194 139.7494083352502 114.82 35.67016655131763 139.7495453330971 114.82 35.67016655131763 139.7495453330971 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67010561322194 139.7494083352502 6.06 35.66991894459931 139.74931320196274 6.06 35.66991894459931 139.74931320196274 114.82 35.67010561322194 139.7494083352502 114.82 35.67010561322194 139.7494083352502 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66991894459931 139.74931320196274 6.06 35.669858073701974 139.74949257852555 6.06 35.669858073701974 139.74949257852555 114.82 35.66991894459931 139.74931320196274 114.82 35.66991894459931 139.74931320196274 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669858073701974 139.74949257852555 6.06 35.66984768619814 139.7494872872177 6.06 35.66984768619814 139.7494872872177 114.82 35.669858073701974 139.74949257852555 114.82 35.669858073701974 139.74949257852555 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66984768619814 139.7494872872177 6.06 35.66975041993746 139.74977389353572 6.06 35.66975041993746 139.74977389353572 114.82 35.66984768619814 139.7494872872177 114.82 35.66984768619814 139.7494872872177 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66975041993746 139.74977389353572 6.06 35.66977093343013 139.74978434393267 6.06 35.66977093343013 139.74978434393267 114.82 35.66975041993746 139.74977389353572 114.82 35.66975041993746 139.74977389353572 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66977093343013 139.74978434393267 114.82 35.669717599948996 139.74994149812386 114.82 35.66998737694291 139.75007898582083 114.82 35.67016655131763 139.7495453330971 114.82 35.67010561322194 139.7494083352502 114.82 35.66991894459931 139.74931320196274 114.82 35.669858073701974 139.74949257852555 114.82 35.66984768619814 139.7494872872177 114.82 35.66975041993746 139.74977389353572 114.82 35.66977093343013 139.74978434393267 114.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-30918f43-5e16-43ef-8969-61c89782afc2"/>
							<gml:surfaceMember xlink:href="#poly-66f34566-debd-4c98-b390-f13e5d4c104e"/>
							<gml:surfaceMember xlink:href="#poly-2eeaef4a-952b-47c4-9cd4-ec106fb7b8e3"/>
							<gml:surfaceMember xlink:href="#poly-f388dc59-51dc-4a59-8b7e-449387329fdc"/>
							<gml:surfaceMember xlink:href="#poly-05d376ab-1cc5-406b-804a-9e9aec5e7f9c"/>
							<gml:surfaceMember xlink:href="#poly-8466a127-36ee-47c6-a609-47354f0687f1"/>
							<gml:surfaceMember xlink:href="#poly-0ccf0dc5-007e-4188-b0b3-10a2cd8255e4"/>
							<gml:surfaceMember xlink:href="#poly-ceb37a6a-32ce-4159-a877-619becce198c"/>
							<gml:surfaceMember xlink:href="#poly-554a8411-cf47-4fd7-8d38-119bf0473ba5"/>
							<gml:surfaceMember xlink:href="#poly-9ec5fca6-6499-4a85-baec-a51488bee367"/>
							<gml:surfaceMember xlink:href="#poly-1f82d9df-b68e-46b1-8641-8d5b6a65fd25"/>
							<gml:surfaceMember xlink:href="#poly-45c8ada5-29b8-4608-86fe-65691c456660"/>
							<gml:surfaceMember xlink:href="#poly-4464a99b-070a-483c-89bf-2ebb01ae7cda"/>
							<gml:surfaceMember xlink:href="#poly-98440b09-4786-49c5-9e3f-b4193ca3afa5"/>
							<gml:surfaceMember xlink:href="#poly-58c7490a-f7a4-4125-8ab7-a9873557ced6"/>
							<gml:surfaceMember xlink:href="#poly-cd2b5b49-278d-4329-a563-0d5142714635"/>
							<gml:surfaceMember xlink:href="#poly-1282d771-ce3d-4fd4-bdf0-480ade6d7c48"/>
							<gml:surfaceMember xlink:href="#poly-ec19c783-6682-40b3-a1d7-103f113e098b"/>
							<gml:surfaceMember xlink:href="#poly-2bc324a5-813a-4705-bba0-6c3b6e41068b"/>
							<gml:surfaceMember xlink:href="#poly-7df09c63-a72a-425b-8b06-a9a20943627c"/>
							<gml:surfaceMember xlink:href="#poly-79941c62-3952-400e-a434-a9d34e89bca1"/>
							<gml:surfaceMember xlink:href="#poly-912ade90-703f-4265-8f65-6865c658aae5"/>
							<gml:surfaceMember xlink:href="#poly-13f432c4-b498-45d4-ae25-32c87d0d9b09"/>
							<gml:surfaceMember xlink:href="#poly-19180bce-d8be-4878-bf89-edd6f01a9a1c"/>
							<gml:surfaceMember xlink:href="#poly-73cd91fb-d26a-4c70-9efc-817e3b44178a"/>
							<gml:surfaceMember xlink:href="#poly-d1eb4ef2-bfe3-4bf1-b9ca-2554e5dc40bf"/>
							<gml:surfaceMember xlink:href="#poly-b6043213-6d2f-4b08-b27d-bc8463bf0146"/>
							<gml:surfaceMember xlink:href="#poly-4985b5e0-482f-43a2-896a-38670d9df736"/>
							<gml:surfaceMember xlink:href="#poly-fe4b89b7-f806-4fb9-a79e-0b348e5bb4ac"/>
							<gml:surfaceMember xlink:href="#poly-61946077-65f4-45e8-9e9c-495820e6013b"/>
							<gml:surfaceMember xlink:href="#poly-57641559-d0ef-43b9-b894-23a663dc08dc"/>
							<gml:surfaceMember xlink:href="#poly-fcfd531c-3298-47aa-9712-5a190855b6a4"/>
							<gml:surfaceMember xlink:href="#poly-134da714-65dd-4323-981d-64b56b12b335"/>
							<gml:surfaceMember xlink:href="#poly-18c8a6de-2950-433c-8fe8-11c8f71a6a1e"/>
							<gml:surfaceMember xlink:href="#poly-610459d3-c7bd-493b-a00b-469e9c241a1a"/>
							<gml:surfaceMember xlink:href="#poly-556eb80d-6790-4c2d-9922-34ff6cd64466"/>
							<gml:surfaceMember xlink:href="#poly-55e9d98a-bfdf-46ba-bf6b-4ec0d654c19a"/>
							<gml:surfaceMember xlink:href="#poly-61b1de67-ad1a-400b-82dc-6fb6931ab2a4"/>
							<gml:surfaceMember xlink:href="#poly-db0af696-9771-4837-97e2-416e81230a30"/>
							<gml:surfaceMember xlink:href="#poly-abab3748-3860-47c0-b125-2eeeb195ac15"/>
							<gml:surfaceMember xlink:href="#poly-a984a876-4375-4ee8-b881-124656ef9e78"/>
							<gml:surfaceMember xlink:href="#poly-1895cd09-4b48-4f44-a424-fbc9e8d04886"/>
							<gml:surfaceMember xlink:href="#poly-b0056e16-aad5-4562-b25f-6b849fa7c5ce"/>
							<gml:surfaceMember xlink:href="#poly-f4c37736-0984-4934-9d21-3727c21edf54"/>
							<gml:surfaceMember xlink:href="#poly-a4825b5d-a56b-47cf-a94e-dfe628d4db04"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b47c007a-7781-478e-bd76-479a06fc16db_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a33be76-432a-435a-bda2-91a4c6bacb6b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66977273633651 139.74990157512684 123.4 35.66977108625064 139.7499007483806 123.4 35.669779325921766 139.74987634984657 123.4 35.66978100306429 139.74987719865655 123.4 35.66977273633651 139.74990157512684 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63ef93d2-9606-47ac-9a24-13263f93cd90">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66978338529693 139.74990697667317 114.364 35.66977273633651 139.74990157512684 114.364 35.66978100306429 139.74987719865655 114.364 35.66979161596323 139.74988258919157 114.364 35.66978338529693 139.74990697667317 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da7bad64-9cd6-4559-8854-51f69348946b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66980383736593 139.74988083117492 114.364 35.66982926502137 139.7498937176988 114.364 35.66981986496359 139.74992156386264 114.364 35.6697944282897 139.74990866629463 114.364 35.66980383736593 139.74988083117492 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d41a1bf1-54a8-4b61-a724-2b2ecc47e86e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66983825859544 139.74982563069716 114.364 35.669831882800054 139.749847177398 114.364 35.669804066869986 139.7498348235923 114.364 35.66981043364947 139.74981327690733 114.364 35.66983825859544 139.74982563069716 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11ef907c-3d78-4ff3-a0a4-acb1974bd836">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66984260420381 139.7498140608141 114.364 35.66981396776082 139.7498013323029 114.364 35.669820118726065 139.74978053697797 114.364 35.669848755163564 139.74979325443655 114.364 35.66984260420381 139.7498140608141 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0492204b-60bd-4b54-bc4c-834a6c2e2a09">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66983279112496 139.74971430189376 114.364 35.66982511803565 139.74971084139432 114.364 35.669831035388 139.74969113987558 114.364 35.669838708477876 139.7496946003734 114.364 35.66983279112496 139.74971430189376 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-104fe4f1-3f7d-4429-b3c5-bec4e308b992">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66982608783563 139.7497704566379 114.364 35.669832859876166 139.74974841244114 114.364 35.669842967506085 139.74975307444097 114.364 35.66983620447843 139.74977511863074 114.364 35.66982608783563 139.7497704566379 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e14c5ff-1252-439a-b6ad-fcf74fe88513">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66985859196719 139.74971940041746 114.364 35.66985339485709 139.74973787506312 114.364 35.66983924816484 139.7497319027799 114.364 35.66984444527404 139.74971342813708 114.364 35.66985859196719 139.74971940041746 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93051f2f-7f7d-4717-bb69-3d4bb255b254">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66984404893399 139.74977873360484 114.364 35.66985026335938 139.74975846842125 114.364 35.66986050624077 139.7497631965595 114.364 35.66985428280087 139.74978346175473 114.364 35.66984404893399 139.74977873360484 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d430392f-622b-47e6-8d3e-c60353c737c5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669861878623784 139.74972754907742 114.364 35.66987313129672 139.74973264068382 114.364 35.66987039740478 139.7497416903641 114.364 35.66985915374594 139.74973659874718 114.364 35.669861878623784 139.74972754907742 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33b407e9-1f99-4ca0-9c0a-38b02dc78d11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669878843208565 139.7497156346398 114.364 35.669874966668566 139.74972770112288 114.364 35.669865444968245 139.74972309374434 114.364 35.6698693215078 139.7497110272625 114.364 35.669878843208565 139.7497156346398 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b08242ec-32b5-4d77-910b-c6b22d2cbea6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669923324885616 139.7494548648537 114.364 35.66994218678871 139.7493976147595 114.364 35.66998215845349 139.74941740085364 114.364 35.669963305547185 139.7494746399162 114.364 35.669923324885616 139.7494548648537 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24bca817-a748-4403-a9e3-1f9877bb234d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669980608863426 139.7494832047202 114.364 35.669999470779764 139.7494259545917 114.364 35.6700399203286 139.74944597218456 114.364 35.67002106741663 139.74950322232786 114.364 35.669980608863426 139.7494832047202 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0554f70b-0cd8-4865-a9e7-199a71aff7ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0554f70b-0cd8-4865-a9e7-199a71aff7ae_0">
											<gml:posList>35.66987039740478 139.7497416903641 114.364 35.66987313129672 139.74973264068382 114.364 35.66987313129672 139.74973264068382 124.246 35.66987039740478 139.7497416903641 124.246 35.66987039740478 139.7497416903641 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bd2a221-bfc2-475c-a69f-bd79c2e3b636">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bd2a221-bfc2-475c-a69f-bd79c2e3b636_0">
											<gml:posList>35.669865444968245 139.74972309374434 124.524 35.669874966668566 139.74972770112288 124.524 35.669878843208565 139.7497156346398 124.524 35.6698693215078 139.7497110272625 124.524 35.669865444968245 139.74972309374434 124.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4843d66d-80d9-4168-8e30-f026631a542a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4843d66d-80d9-4168-8e30-f026631a542a_0">
											<gml:posList>35.669878843208565 139.7497156346398 114.364 35.6698693215078 139.7497110272625 114.364 35.6698693215078 139.7497110272625 124.524 35.669878843208565 139.7497156346398 124.524 35.669878843208565 139.7497156346398 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e59bb484-0190-4a12-98d5-0a2cb568e481">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e59bb484-0190-4a12-98d5-0a2cb568e481_0">
											<gml:posList>35.669874966668566 139.74972770112288 114.364 35.669878843208565 139.7497156346398 114.364 35.669878843208565 139.7497156346398 124.524 35.669874966668566 139.74972770112288 124.524 35.669874966668566 139.74972770112288 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3c37945-b218-4bc5-b23a-843ccc582127">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3c37945-b218-4bc5-b23a-843ccc582127_0">
											<gml:posList>35.669923324885616 139.7494548648537 114.364 35.669923324885616 139.7494548648537 123.017 35.66994218678871 139.7493976147595 123.017 35.66994218678871 139.7493976147595 114.364 35.669923324885616 139.7494548648537 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-006c00ab-f5e8-4701-a1d6-85b060957eb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-006c00ab-f5e8-4701-a1d6-85b060957eb6_0">
											<gml:posList>35.669923324885616 139.7494548648537 114.364 35.669963305547185 139.7494746399162 114.364 35.669963305547185 139.7494746399162 123.017 35.669923324885616 139.7494548648537 123.017 35.669923324885616 139.7494548648537 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a452dc5d-b859-4694-8848-e5d14444276f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a452dc5d-b859-4694-8848-e5d14444276f_0">
											<gml:posList>35.66998215845349 139.74941740085364 123.017 35.66994218678871 139.7493976147595 123.017 35.669923324885616 139.7494548648537 123.017 35.669963305547185 139.7494746399162 123.017 35.66998215845349 139.74941740085364 123.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0ab679c-d5c7-422d-b208-53f569c7a4b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0ab679c-d5c7-422d-b208-53f569c7a4b5_0">
											<gml:posList>35.66998215845349 139.74941740085364 114.364 35.66994218678871 139.7493976147595 114.364 35.66994218678871 139.7493976147595 123.017 35.66998215845349 139.74941740085364 123.017 35.66998215845349 139.74941740085364 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0385ddc-cad5-49a6-9fac-4cbf11c280cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0385ddc-cad5-49a6-9fac-4cbf11c280cb_0">
											<gml:posList>35.66998215845349 139.74941740085364 114.364 35.66998215845349 139.74941740085364 123.017 35.669963305547185 139.7494746399162 123.017 35.669963305547185 139.7494746399162 114.364 35.66998215845349 139.74941740085364 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-def988d6-a649-4df9-a79f-4438a0ccd969">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-def988d6-a649-4df9-a79f-4438a0ccd969_0">
											<gml:posList>35.669980608863426 139.7494832047202 114.364 35.669980608863426 139.7494832047202 123.017 35.669999470779764 139.7494259545917 123.017 35.669999470779764 139.7494259545917 114.364 35.669980608863426 139.7494832047202 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0daff70c-389b-41d5-acfd-a0257415c289">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0daff70c-389b-41d5-acfd-a0257415c289_0">
											<gml:posList>35.67002106741663 139.74950322232786 114.364 35.67002106741663 139.74950322232786 123.017 35.669980608863426 139.7494832047202 123.017 35.669980608863426 139.7494832047202 114.364 35.67002106741663 139.74950322232786 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-070820f9-6e1c-42a3-9c0c-b5d59d98d5a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-070820f9-6e1c-42a3-9c0c-b5d59d98d5a4_0">
											<gml:posList>35.6700399203286 139.74944597218456 123.017 35.669999470779764 139.7494259545917 123.017 35.669980608863426 139.7494832047202 123.017 35.67002106741663 139.74950322232786 123.017 35.6700399203286 139.74944597218456 123.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b10f2deb-c242-4472-a4bc-03ebd0a042ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b10f2deb-c242-4472-a4bc-03ebd0a042ad_0">
											<gml:posList>35.6700399203286 139.74944597218456 114.364 35.669999470779764 139.7494259545917 114.364 35.669999470779764 139.7494259545917 123.017 35.6700399203286 139.74944597218456 123.017 35.6700399203286 139.74944597218456 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-904c7ed0-d1ee-4467-beb1-020aa774b63c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-904c7ed0-d1ee-4467-beb1-020aa774b63c_0">
											<gml:posList>35.6700399203286 139.74944597218456 114.364 35.6700399203286 139.74944597218456 123.017 35.67002106741663 139.74950322232786 123.017 35.67002106741663 139.74950322232786 114.364 35.6700399203286 139.74944597218456 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8caa00f9-3956-4828-be05-7ef5fdad6bfc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8caa00f9-3956-4828-be05-7ef5fdad6bfc_0">
											<gml:posList>35.669779325921766 139.74987634984657 123.4 35.66977108625064 139.7499007483806 123.4 35.66977108625064 139.7499007483806 126.01 35.669779325921766 139.74987634984657 126.01 35.669779325921766 139.74987634984657 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c575a46-b2dc-4ffb-800d-2eea2134419c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c575a46-b2dc-4ffb-800d-2eea2134419c_0">
											<gml:posList>35.66977273633651 139.74990157512684 114.364 35.66977273633651 139.74990157512684 123.4 35.66978100306429 139.74987719865655 123.4 35.66978100306429 139.74987719865655 114.364 35.66977273633651 139.74990157512684 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f97a9da3-0055-485c-9973-a0c55ed864b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f97a9da3-0055-485c-9973-a0c55ed864b4_0">
											<gml:posList>35.66978338529693 139.74990697667317 114.364 35.66978338529693 139.74990697667317 126.01 35.66977108625064 139.7499007483806 126.01 35.66977108625064 139.7499007483806 123.4 35.66977273633651 139.74990157512684 123.4 35.66977273633651 139.74990157512684 114.364 35.66978338529693 139.74990697667317 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1003dc2-81d3-4c87-8c8c-3563d184d391">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1003dc2-81d3-4c87-8c8c-3563d184d391_0">
											<gml:posList>35.66977108625064 139.7499007483806 126.01 35.66978338529693 139.74990697667317 126.01 35.66979161596323 139.74988258919157 126.01 35.669779325921766 139.74987634984657 126.01 35.66977108625064 139.7499007483806 126.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ed89f4d-8c9e-4b8e-a2de-dda26df0fd85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ed89f4d-8c9e-4b8e-a2de-dda26df0fd85_0">
											<gml:posList>35.669779325921766 139.74987634984657 126.01 35.66979161596323 139.74988258919157 126.01 35.66979161596323 139.74988258919157 114.364 35.66978100306429 139.74987719865655 114.364 35.66978100306429 139.74987719865655 123.4 35.669779325921766 139.74987634984657 123.4 35.669779325921766 139.74987634984657 126.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69d983dd-0eb3-4be8-bd91-8baab0216a68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69d983dd-0eb3-4be8-bd91-8baab0216a68_0">
											<gml:posList>35.66978338529693 139.74990697667317 114.364 35.66979161596323 139.74988258919157 114.364 35.66979161596323 139.74988258919157 126.01 35.66978338529693 139.74990697667317 126.01 35.66978338529693 139.74990697667317 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b63a79de-e120-4247-ada5-f18d7c6a7dfa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b63a79de-e120-4247-ada5-f18d7c6a7dfa_0">
											<gml:posList>35.66980383736593 139.74988083117492 114.364 35.6697944282897 139.74990866629463 114.364 35.6697944282897 139.74990866629463 123.607 35.66980383736593 139.74988083117492 123.607 35.66980383736593 139.74988083117492 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45af3821-fda4-4ea9-a15e-b4a3e28e94f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45af3821-fda4-4ea9-a15e-b4a3e28e94f6_0">
											<gml:posList>35.6697944282897 139.74990866629463 114.364 35.66981986496359 139.74992156386264 114.364 35.66981986496359 139.74992156386264 123.607 35.6697944282897 139.74990866629463 123.607 35.6697944282897 139.74990866629463 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec290ade-498c-4ae5-b9e4-582737b2be47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec290ade-498c-4ae5-b9e4-582737b2be47_0">
											<gml:posList>35.669804066869986 139.7498348235923 114.364 35.669804066869986 139.7498348235923 125.37 35.66981043364947 139.74981327690733 125.37 35.66981043364947 139.74981327690733 114.364 35.669804066869986 139.7498348235923 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a20968ac-ac3f-469e-b9af-1ae403673353">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a20968ac-ac3f-469e-b9af-1ae403673353_0">
											<gml:posList>35.66981986496359 139.74992156386264 123.607 35.66982926502137 139.7498937176988 123.607 35.66980383736593 139.74988083117492 123.607 35.6697944282897 139.74990866629463 123.607 35.66981986496359 139.74992156386264 123.607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6e63e46-2827-4a24-8afd-2fc30dbcc759">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6e63e46-2827-4a24-8afd-2fc30dbcc759_0">
											<gml:posList>35.66982926502137 139.7498937176988 114.364 35.66980383736593 139.74988083117492 114.364 35.66980383736593 139.74988083117492 123.607 35.66982926502137 139.7498937176988 123.607 35.66982926502137 139.7498937176988 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec15bca7-68f4-4b6b-a1d3-308d02f58a2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec15bca7-68f4-4b6b-a1d3-308d02f58a2f_0">
											<gml:posList>35.669820118726065 139.74978053697797 114.364 35.66981396776082 139.7498013323029 114.364 35.66981396776082 139.7498013323029 125.37 35.669820118726065 139.74978053697797 125.37 35.669820118726065 139.74978053697797 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb8434da-a1b5-41c7-be27-7d0f3b8c84fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb8434da-a1b5-41c7-be27-7d0f3b8c84fe_0">
											<gml:posList>35.669804066869986 139.7498348235923 114.364 35.669831882800054 139.749847177398 114.364 35.669831882800054 139.749847177398 125.37 35.669804066869986 139.7498348235923 125.37 35.669804066869986 139.7498348235923 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ee38f17-70a0-4217-898a-3ab7db9a9726">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ee38f17-70a0-4217-898a-3ab7db9a9726_0">
											<gml:posList>35.669804066869986 139.7498348235923 125.37 35.669831882800054 139.749847177398 125.37 35.66983825859544 139.74982563069716 125.37 35.66981043364947 139.74981327690733 125.37 35.669804066869986 139.7498348235923 125.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e3c0539-30af-4c7e-b329-8165be79a185">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e3c0539-30af-4c7e-b329-8165be79a185_0">
											<gml:posList>35.66981043364947 139.74981327690733 114.364 35.66981043364947 139.74981327690733 125.37 35.66983825859544 139.74982563069716 125.37 35.66983825859544 139.74982563069716 114.364 35.66981043364947 139.74981327690733 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6b5ace0-5fcf-47a3-89c8-b9c77af20b15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6b5ace0-5fcf-47a3-89c8-b9c77af20b15_0">
											<gml:posList>35.66981986496359 139.74992156386264 114.364 35.66982926502137 139.7498937176988 114.364 35.66982926502137 139.7498937176988 123.607 35.66981986496359 139.74992156386264 123.607 35.66981986496359 139.74992156386264 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d78ff18-9ad1-4ab6-baa0-e5343580c2bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d78ff18-9ad1-4ab6-baa0-e5343580c2bd_0">
											<gml:posList>35.66982511803565 139.74971084139432 114.364 35.66982511803565 139.74971084139432 124.411 35.669831035388 139.74969113987558 124.411 35.669831035388 139.74969113987558 114.364 35.66982511803565 139.74971084139432 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-220c2e8f-db6a-416c-aeba-3705a9e61d71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-220c2e8f-db6a-416c-aeba-3705a9e61d71_0">
											<gml:posList>35.66981396776082 139.7498013323029 114.364 35.66984260420381 139.7498140608141 114.364 35.66984260420381 139.7498140608141 125.37 35.66981396776082 139.7498013323029 125.37 35.66981396776082 139.7498013323029 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cebd3560-a2bf-4291-b33f-bb30de683306">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cebd3560-a2bf-4291-b33f-bb30de683306_0">
											<gml:posList>35.66983279112496 139.74971430189376 114.364 35.66983279112496 139.74971430189376 124.411 35.66982511803565 139.74971084139432 124.411 35.66982511803565 139.74971084139432 114.364 35.66983279112496 139.74971430189376 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e540eb1b-a7c2-4491-922a-fd949432e36e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e540eb1b-a7c2-4491-922a-fd949432e36e_0">
											<gml:posList>35.66982608783563 139.7497704566379 114.364 35.66982608783563 139.7497704566379 126.05 35.669832859876166 139.74974841244114 126.05 35.669832859876166 139.74974841244114 114.364 35.66982608783563 139.7497704566379 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-451578d3-0a3f-4c0f-84ab-64738b6e5935">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-451578d3-0a3f-4c0f-84ab-64738b6e5935_0">
											<gml:posList>35.66983620447843 139.74977511863074 114.364 35.66983620447843 139.74977511863074 126.05 35.66982608783563 139.7497704566379 126.05 35.66982608783563 139.7497704566379 114.364 35.66983620447843 139.74977511863074 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ec040ac-64b6-4b07-82af-40311be6a333">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ec040ac-64b6-4b07-82af-40311be6a333_0">
											<gml:posList>35.66984260420381 139.7498140608141 125.37 35.669848755163564 139.74979325443655 125.37 35.669820118726065 139.74978053697797 125.37 35.66981396776082 139.7498013323029 125.37 35.66984260420381 139.7498140608141 125.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a43cb478-d136-4eb8-ac56-06f85040b494">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a43cb478-d136-4eb8-ac56-06f85040b494_0">
											<gml:posList>35.66983279112496 139.74971430189376 124.411 35.669838708477876 139.7496946003734 124.411 35.669831035388 139.74969113987558 124.411 35.66982511803565 139.74971084139432 124.411 35.66983279112496 139.74971430189376 124.411</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df2f8ece-e766-4b4e-8c4f-305c9b3ea3e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df2f8ece-e766-4b4e-8c4f-305c9b3ea3e0_0">
											<gml:posList>35.669820118726065 139.74978053697797 114.364 35.669820118726065 139.74978053697797 125.37 35.669848755163564 139.74979325443655 125.37 35.669848755163564 139.74979325443655 114.364 35.669820118726065 139.74978053697797 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74e96385-c8f2-4556-82b1-6c2a3c552d11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74e96385-c8f2-4556-82b1-6c2a3c552d11_0">
											<gml:posList>35.669842967506085 139.74975307444097 126.05 35.669832859876166 139.74974841244114 126.05 35.66982608783563 139.7497704566379 126.05 35.66983620447843 139.74977511863074 126.05 35.669842967506085 139.74975307444097 126.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67feb5cd-9592-4b33-a8da-d47955cd5f64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67feb5cd-9592-4b33-a8da-d47955cd5f64_0">
											<gml:posList>35.669831035388 139.74969113987558 114.364 35.669831035388 139.74969113987558 124.411 35.669838708477876 139.7496946003734 124.411 35.669838708477876 139.7496946003734 114.364 35.669831035388 139.74969113987558 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46ee4ac5-e6de-41b9-8b53-f8a5924dcc29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46ee4ac5-e6de-41b9-8b53-f8a5924dcc29_0">
											<gml:posList>35.669831882800054 139.749847177398 114.364 35.66983825859544 139.74982563069716 114.364 35.66983825859544 139.74982563069716 125.37 35.669831882800054 139.749847177398 125.37 35.669831882800054 139.749847177398 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a40ebb1-ee01-47db-ad30-d3296936e78a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a40ebb1-ee01-47db-ad30-d3296936e78a_0">
											<gml:posList>35.669838708477876 139.7496946003734 114.364 35.669838708477876 139.7496946003734 124.411 35.66983279112496 139.74971430189376 124.411 35.66983279112496 139.74971430189376 114.364 35.669838708477876 139.7496946003734 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5de5739e-8600-4838-8092-f228c25347a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5de5739e-8600-4838-8092-f228c25347a8_0">
											<gml:posList>35.669832859876166 139.74974841244114 114.364 35.669832859876166 139.74974841244114 126.05 35.669842967506085 139.74975307444097 126.05 35.669842967506085 139.74975307444097 114.364 35.669832859876166 139.74974841244114 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cb60c87-b9dc-4c40-869c-116893e3835f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cb60c87-b9dc-4c40-869c-116893e3835f_0">
											<gml:posList>35.66983620447843 139.74977511863074 114.364 35.669842967506085 139.74975307444097 114.364 35.669842967506085 139.74975307444097 126.05 35.66983620447843 139.74977511863074 126.05 35.66983620447843 139.74977511863074 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8aa4d4e4-82bc-4de6-8785-ff070fc1a38f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8aa4d4e4-82bc-4de6-8785-ff070fc1a38f_0">
											<gml:posList>35.66984444527404 139.74971342813708 114.364 35.66983924816484 139.7497319027799 114.364 35.66983924816484 139.7497319027799 125.37 35.66984444527404 139.74971342813708 125.37 35.66984444527404 139.74971342813708 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98b02da5-b054-44c9-8c9d-f79de591fbc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98b02da5-b054-44c9-8c9d-f79de591fbc8_0">
											<gml:posList>35.66984260420381 139.7498140608141 114.364 35.669848755163564 139.74979325443655 114.364 35.669848755163564 139.74979325443655 125.37 35.66984260420381 139.7498140608141 125.37 35.66984260420381 139.7498140608141 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-801a27f8-79b9-45c9-a5a2-18731c04cbc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-801a27f8-79b9-45c9-a5a2-18731c04cbc6_0">
											<gml:posList>35.66985339485709 139.74973787506312 114.364 35.66985339485709 139.74973787506312 125.37 35.66983924816484 139.7497319027799 125.37 35.66983924816484 139.7497319027799 114.364 35.66985339485709 139.74973787506312 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ee295dd-9e53-4763-85f6-e69b45388392">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ee295dd-9e53-4763-85f6-e69b45388392_0">
											<gml:posList>35.66985026335938 139.74975846842125 114.364 35.66984404893399 139.74977873360484 114.364 35.66984404893399 139.74977873360484 126.05 35.66985026335938 139.74975846842125 126.05 35.66985026335938 139.74975846842125 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93323b13-5fdf-4b43-8a1c-b26ed0a790e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93323b13-5fdf-4b43-8a1c-b26ed0a790e5_0">
											<gml:posList>35.66985859196719 139.74971940041746 125.37 35.66984444527404 139.74971342813708 125.37 35.66983924816484 139.7497319027799 125.37 35.66985339485709 139.74973787506312 125.37 35.66985859196719 139.74971940041746 125.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f38b374-217c-4288-944a-4a026d9175a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f38b374-217c-4288-944a-4a026d9175a3_0">
											<gml:posList>35.66984404893399 139.74977873360484 114.364 35.66985428280087 139.74978346175473 114.364 35.66985428280087 139.74978346175473 126.05 35.66984404893399 139.74977873360484 126.05 35.66984404893399 139.74977873360484 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba73c941-9949-4dc1-8c8d-4f7b43506e83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba73c941-9949-4dc1-8c8d-4f7b43506e83_0">
											<gml:posList>35.66985859196719 139.74971940041746 114.364 35.66984444527404 139.74971342813708 114.364 35.66984444527404 139.74971342813708 125.37 35.66985859196719 139.74971940041746 125.37 35.66985859196719 139.74971940041746 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcc0f793-a65c-4e5b-81d2-4bbef8fc86ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dcc0f793-a65c-4e5b-81d2-4bbef8fc86ef_0">
											<gml:posList>35.66986050624077 139.7497631965595 126.05 35.66985026335938 139.74975846842125 126.05 35.66984404893399 139.74977873360484 126.05 35.66985428280087 139.74978346175473 126.05 35.66986050624077 139.7497631965595 126.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9aff9101-48b4-4fcb-84c9-8679dc82249b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9aff9101-48b4-4fcb-84c9-8679dc82249b_0">
											<gml:posList>35.66986050624077 139.7497631965595 114.364 35.66985026335938 139.74975846842125 114.364 35.66985026335938 139.74975846842125 126.05 35.66986050624077 139.7497631965595 126.05 35.66986050624077 139.7497631965595 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da04132f-130f-4091-9d68-49d1db89311d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da04132f-130f-4091-9d68-49d1db89311d_0">
											<gml:posList>35.66985339485709 139.74973787506312 114.364 35.66985859196719 139.74971940041746 114.364 35.66985859196719 139.74971940041746 125.37 35.66985339485709 139.74973787506312 125.37 35.66985339485709 139.74973787506312 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a5e8215-9c70-4682-9081-f056a200624a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a5e8215-9c70-4682-9081-f056a200624a_0">
											<gml:posList>35.66985428280087 139.74978346175473 114.364 35.66986050624077 139.7497631965595 114.364 35.66986050624077 139.7497631965595 126.05 35.66985428280087 139.74978346175473 126.05 35.66985428280087 139.74978346175473 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f23ceecb-f147-4631-9484-5873b2229264">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f23ceecb-f147-4631-9484-5873b2229264_0">
											<gml:posList>35.669861878623784 139.74972754907742 114.364 35.66985915374594 139.74973659874718 114.364 35.66985915374594 139.74973659874718 124.246 35.669861878623784 139.74972754907742 124.246 35.669861878623784 139.74972754907742 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-650eadd5-22a7-4979-9952-25e58d56a051">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-650eadd5-22a7-4979-9952-25e58d56a051_0">
											<gml:posList>35.66985915374594 139.74973659874718 114.364 35.66987039740478 139.7497416903641 114.364 35.66987039740478 139.7497416903641 124.246 35.66985915374594 139.74973659874718 124.246 35.66985915374594 139.74973659874718 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c8703ff-3680-4b28-9145-5bdbe8520de3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c8703ff-3680-4b28-9145-5bdbe8520de3_0">
											<gml:posList>35.66987039740478 139.7497416903641 124.246 35.66987313129672 139.74973264068382 124.246 35.669861878623784 139.74972754907742 124.246 35.66985915374594 139.74973659874718 124.246 35.66987039740478 139.7497416903641 124.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-886d2a95-995b-4f11-a010-d760cc4528a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-886d2a95-995b-4f11-a010-d760cc4528a4_0">
											<gml:posList>35.669865444968245 139.74972309374434 114.364 35.669865444968245 139.74972309374434 124.524 35.6698693215078 139.7497110272625 124.524 35.6698693215078 139.7497110272625 114.364 35.669865444968245 139.74972309374434 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e5035bf-23b6-4f63-b5d3-f05b92bfff4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e5035bf-23b6-4f63-b5d3-f05b92bfff4a_0">
											<gml:posList>35.66987313129672 139.74973264068382 114.364 35.669861878623784 139.74972754907742 114.364 35.669861878623784 139.74972754907742 124.246 35.66987313129672 139.74973264068382 124.246 35.66987313129672 139.74973264068382 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85e46a26-2811-4be3-a08d-855f1b58c3f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85e46a26-2811-4be3-a08d-855f1b58c3f2_0">
											<gml:posList>35.669865444968245 139.74972309374434 114.364 35.669874966668566 139.74972770112288 114.364 35.669874966668566 139.74972770112288 124.524 35.669865444968245 139.74972309374434 124.524 35.669865444968245 139.74972309374434 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b47c007a-7781-478e-bd76-479a06fc16db_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85618edd-5e0a-4c47-a086-9a84b80a56db">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670059577840625 139.74946978935216 114.364 35.67009361673868 139.7494871073617 114.364 35.67009062132887 139.7494959585167 114.364 35.670056582424365 139.74947862945783 114.364 35.670059577840625 139.74946978935216 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d9ddea9-c800-4e98-86b7-adfe9d74ee4d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67006594528655 139.74950106557867 114.364 35.67006940846446 139.74949085525267 114.364 35.670107099210064 139.74951002522076 114.364 35.6701072887905 139.74951044477902 114.364 35.67010391555599 139.7495203788594 114.364 35.67006594528655 139.74950106557867 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5dd1bb0-334c-4927-a571-6a648e04d8fa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66988036167986 139.74986454676352 114.364 35.6699052875959 139.7497908095562 114.364 35.669881500987415 139.7497787277146 114.364 35.6698848831958 139.74976870529377 114.364 35.6699086878404 139.74978079816032 114.364 35.66991551524539 139.74976059859875 114.364 35.669891043353076 139.74974817504702 114.364 35.66989530710188 139.74973555584913 114.364 35.66991952652682 139.7497478581527 114.364 35.669939253127346 139.74968951365418 114.364 35.66994848645099 139.7496942097034 114.364 35.66988500680875 139.74988196177276 114.364 35.66985101307304 139.74986469882433 114.364 35.66985535779681 139.74985184758467 114.364 35.66988036167986 139.74986454676352 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f9780d2-138f-4318-a298-550a2bd0134f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f9780d2-138f-4318-a298-550a2bd0134f_0">
											<gml:posList>35.66985535779681 139.74985184758467 114.364 35.66985101307304 139.74986469882433 114.364 35.66985101307304 139.74986469882433 119.588 35.66985535779681 139.74985184758467 119.588 35.66985535779681 139.74985184758467 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-385de5ab-4fcc-47d4-b14a-e90b329bee82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-385de5ab-4fcc-47d4-b14a-e90b329bee82_0">
											<gml:posList>35.66988036167986 139.74986454676352 114.364 35.66985535779681 139.74985184758467 114.364 35.66985535779681 139.74985184758467 119.588 35.66988036167986 139.74986454676352 119.588 35.66988036167986 139.74986454676352 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bd77014-c747-49b4-9cd4-42cb5689785c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bd77014-c747-49b4-9cd4-42cb5689785c_0">
											<gml:posList>35.66985101307304 139.74986469882433 114.364 35.66988500680875 139.74988196177276 114.364 35.66988500680875 139.74988196177276 119.588 35.66985101307304 139.74986469882433 119.588 35.66985101307304 139.74986469882433 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b52bec56-144e-48c8-abb8-a63057b26a04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b52bec56-144e-48c8-abb8-a63057b26a04_0">
											<gml:posList>35.6698848831958 139.74976870529377 114.364 35.669881500987415 139.7497787277146 114.364 35.669881500987415 139.7497787277146 119.588 35.6698848831958 139.74976870529377 119.588 35.6698848831958 139.74976870529377 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-035992da-31a8-4095-a50d-156d9d2a7632">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-035992da-31a8-4095-a50d-156d9d2a7632_0">
											<gml:posList>35.66988036167986 139.74986454676352 114.364 35.66988036167986 139.74986454676352 119.588 35.6699052875959 139.7497908095562 119.588 35.6699052875959 139.7497908095562 114.364 35.66988036167986 139.74986454676352 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c59c557-6941-4462-8802-782a9cbd7c97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c59c557-6941-4462-8802-782a9cbd7c97_0">
											<gml:posList>35.66989530710188 139.74973555584913 114.364 35.669891043353076 139.74974817504702 114.364 35.669891043353076 139.74974817504702 119.588 35.66989530710188 139.74973555584913 119.588 35.66989530710188 139.74973555584913 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e6f713c-da7b-470b-bfb2-a60fa4fb23af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e6f713c-da7b-470b-bfb2-a60fa4fb23af_0">
											<gml:posList>35.669881500987415 139.7497787277146 114.364 35.6699052875959 139.7497908095562 114.364 35.6699052875959 139.7497908095562 119.588 35.669881500987415 139.7497787277146 119.588 35.669881500987415 139.7497787277146 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74d331ef-f0fa-497e-961b-8d547e14ae46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74d331ef-f0fa-497e-961b-8d547e14ae46_0">
											<gml:posList>35.6699086878404 139.74978079816032 114.364 35.6698848831958 139.74976870529377 114.364 35.6698848831958 139.74976870529377 119.588 35.6699086878404 139.74978079816032 119.588 35.6699086878404 139.74978079816032 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9319685f-8933-4d5f-8aad-fdbc44283596">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9319685f-8933-4d5f-8aad-fdbc44283596_0">
											<gml:posList>35.66985101307304 139.74986469882433 119.588 35.66988500680875 139.74988196177276 119.588 35.66994848645099 139.7496942097034 119.588 35.669939253127346 139.74968951365418 119.588 35.66991952652682 139.7497478581527 119.588 35.66989530710188 139.74973555584913 119.588 35.669891043353076 139.74974817504702 119.588 35.66991551524539 139.74976059859875 119.588 35.6699086878404 139.74978079816032 119.588 35.6698848831958 139.74976870529377 119.588 35.669881500987415 139.7497787277146 119.588 35.6699052875959 139.7497908095562 119.588 35.66988036167986 139.74986454676352 119.588 35.66985535779681 139.74985184758467 119.588 35.66985101307304 139.74986469882433 119.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62b8e481-a047-47d8-9f9f-d32660b4fc70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62b8e481-a047-47d8-9f9f-d32660b4fc70_0">
											<gml:posList>35.669891043353076 139.74974817504702 114.364 35.66991551524539 139.74976059859875 114.364 35.66991551524539 139.74976059859875 119.588 35.669891043353076 139.74974817504702 119.588 35.669891043353076 139.74974817504702 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-992dd002-8dfd-4eaa-b996-07c5874c529c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-992dd002-8dfd-4eaa-b996-07c5874c529c_0">
											<gml:posList>35.66991952652682 139.7497478581527 114.364 35.66989530710188 139.74973555584913 114.364 35.66989530710188 139.74973555584913 119.588 35.66991952652682 139.7497478581527 119.588 35.66991952652682 139.7497478581527 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-823cee16-0b5f-44d5-a8ce-8c7d4da3a589">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-823cee16-0b5f-44d5-a8ce-8c7d4da3a589_0">
											<gml:posList>35.66991551524539 139.74976059859875 114.364 35.6699086878404 139.74978079816032 114.364 35.6699086878404 139.74978079816032 119.588 35.66991551524539 139.74976059859875 119.588 35.66991551524539 139.74976059859875 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1640fdbb-9033-4c25-978c-ae686bf171f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1640fdbb-9033-4c25-978c-ae686bf171f1_0">
											<gml:posList>35.66994848645099 139.7496942097034 114.364 35.66994848645099 139.7496942097034 119.588 35.66988500680875 139.74988196177276 119.588 35.66988500680875 139.74988196177276 114.364 35.66994848645099 139.7496942097034 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f65dc3ee-98db-4f7d-b5f5-6998422d301f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f65dc3ee-98db-4f7d-b5f5-6998422d301f_0">
											<gml:posList>35.669939253127346 139.74968951365418 114.364 35.66991952652682 139.7497478581527 114.364 35.66991952652682 139.7497478581527 119.588 35.669939253127346 139.74968951365418 119.588 35.669939253127346 139.74968951365418 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-504663df-99c3-4d9a-9492-935293775f75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-504663df-99c3-4d9a-9492-935293775f75_0">
											<gml:posList>35.66994848645099 139.7496942097034 114.364 35.669939253127346 139.74968951365418 114.364 35.669939253127346 139.74968951365418 119.588 35.66994848645099 139.7496942097034 119.588 35.66994848645099 139.7496942097034 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67a9a67d-020e-4d86-b357-61898136b432">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67a9a67d-020e-4d86-b357-61898136b432_0">
											<gml:posList>35.670056582424365 139.74947862945783 114.364 35.670056582424365 139.74947862945783 117.48 35.670059577840625 139.74946978935216 117.48 35.670059577840625 139.74946978935216 114.364 35.670056582424365 139.74947862945783 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e9cab24-7bed-4d40-b75d-f35c6c10d256">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e9cab24-7bed-4d40-b75d-f35c6c10d256_0">
											<gml:posList>35.67006940846446 139.74949085525267 114.364 35.67006594528655 139.74950106557867 114.364 35.67006594528655 139.74950106557867 117.48 35.67006940846446 139.74949085525267 117.48 35.67006940846446 139.74949085525267 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f6d4b02-cb8a-4fae-b19a-38900e440b2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f6d4b02-cb8a-4fae-b19a-38900e440b2c_0">
											<gml:posList>35.670056582424365 139.74947862945783 114.364 35.67009062132887 139.7494959585167 114.364 35.67009062132887 139.7494959585167 117.48 35.670056582424365 139.74947862945783 117.48 35.670056582424365 139.74947862945783 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8031746-1b2c-4010-8a78-19b19a828af8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8031746-1b2c-4010-8a78-19b19a828af8_0">
											<gml:posList>35.67009062132887 139.7494959585167 117.48 35.67009361673868 139.7494871073617 117.48 35.670059577840625 139.74946978935216 117.48 35.670056582424365 139.74947862945783 117.48 35.67009062132887 139.7494959585167 117.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0aec018-b54e-40da-8f8f-aa56a5ac1a07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0aec018-b54e-40da-8f8f-aa56a5ac1a07_0">
											<gml:posList>35.670059577840625 139.74946978935216 114.364 35.670059577840625 139.74946978935216 117.48 35.67009361673868 139.7494871073617 117.48 35.67009361673868 139.7494871073617 114.364 35.670059577840625 139.74946978935216 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75dbe65c-66b4-46bd-ba50-bae30185689d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75dbe65c-66b4-46bd-ba50-bae30185689d_0">
											<gml:posList>35.67006594528655 139.74950106557867 114.364 35.67010391555599 139.7495203788594 114.364 35.67010391555599 139.7495203788594 117.48 35.67006594528655 139.74950106557867 117.48 35.67006594528655 139.74950106557867 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ff2105d-b381-4f30-812d-c0094aa4af54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ff2105d-b381-4f30-812d-c0094aa4af54_0">
											<gml:posList>35.6701072887905 139.74951044477902 117.48 35.670107099210064 139.74951002522076 117.48 35.67006940846446 139.74949085525267 117.48 35.67006594528655 139.74950106557867 117.48 35.67010391555599 139.7495203788594 117.48 35.6701072887905 139.74951044477902 117.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d42cb7c0-8146-4c22-b9ca-ad186b796bd9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d42cb7c0-8146-4c22-b9ca-ad186b796bd9_0">
											<gml:posList>35.670107099210064 139.74951002522076 117.48 35.670107099210064 139.74951002522076 114.364 35.67006940846446 139.74949085525267 114.364 35.67006940846446 139.74949085525267 117.48 35.670107099210064 139.74951002522076 117.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7335dbe1-8506-4c9b-ae60-3ce7ae510fcb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7335dbe1-8506-4c9b-ae60-3ce7ae510fcb_0">
											<gml:posList>35.67009361673868 139.7494871073617 114.364 35.67009361673868 139.7494871073617 117.48 35.67009062132887 139.7494959585167 117.48 35.67009062132887 139.7494959585167 114.364 35.67009361673868 139.7494871073617 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-747f0842-1a56-4007-8b08-d6dd739f911c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-747f0842-1a56-4007-8b08-d6dd739f911c_0">
											<gml:posList>35.6701072887905 139.74951044477902 117.48 35.67010391555599 139.7495203788594 117.48 35.67010391555599 139.7495203788594 114.364 35.6701072887905 139.74951044477902 114.364 35.6701072887905 139.74951044477902 117.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96e1f805-e008-497b-bb5e-bc75c33f3fc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96e1f805-e008-497b-bb5e-bc75c33f3fc9_0">
											<gml:posList>35.670107099210064 139.74951002522076 117.48 35.6701072887905 139.74951044477902 117.48 35.6701072887905 139.74951044477902 114.364 35.670107099210064 139.74951002522076 114.364 35.670107099210064 139.74951002522076 117.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-30918f43-5e16-43ef-8969-61c89782afc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30918f43-5e16-43ef-8969-61c89782afc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30918f43-5e16-43ef-8969-61c89782afc2">
											<gml:posList>35.669770933430115 139.74978434393267 6.06 35.66975041993746 139.74977389353572 6.06 35.66984768619812 139.7494872872177 6.06 35.66985807370196 139.74949257852555 6.06 35.66991894459928 139.7493132019627 6.06 35.67010561322194 139.74940833525017 6.06 35.67016655131762 139.7495453330971 6.06 35.66998737694289 139.75007898582083 6.06 35.66971759994896 139.74994149812386 6.06 35.669770933430115 139.74978434393267 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66f34566-debd-4c98-b390-f13e5d4c104e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66f34566-debd-4c98-b390-f13e5d4c104e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66f34566-debd-4c98-b390-f13e5d4c104e">
											<gml:posList>35.669770933430115 139.74978434393267 123.4 35.66971759994896 139.74994149812386 123.4 35.669767797872254 139.7499161170332 123.4 35.669821140325745 139.7497589516712 123.4 35.669770933430115 139.74978434393267 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2eeaef4a-952b-47c4-9cd4-ec106fb7b8e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2eeaef4a-952b-47c4-9cd4-ec106fb7b8e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2eeaef4a-952b-47c4-9cd4-ec106fb7b8e3">
											<gml:posList>35.669770933430115 139.74978434393267 123.4 35.669821140325745 139.7497589516712 123.4 35.669800626831055 139.7497485012742 123.4 35.66975041993746 139.74977389353572 123.4 35.669770933430115 139.74978434393267 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f388dc59-51dc-4a59-8b7e-449387329fdc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f388dc59-51dc-4a59-8b7e-449387329fdc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f388dc59-51dc-4a59-8b7e-449387329fdc">
											<gml:posList>35.66975041993746 139.74977389353572 123.4 35.669800626831055 139.7497485012742 123.4 35.66986839751311 139.74954881492874 123.4 35.66984768619812 139.7494872872177 123.4 35.66975041993746 139.74977389353572 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05d376ab-1cc5-406b-804a-9e9aec5e7f9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05d376ab-1cc5-406b-804a-9e9aec5e7f9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05d376ab-1cc5-406b-804a-9e9aec5e7f9c">
											<gml:posList>35.66998737694289 139.75007898582083 123.4 35.6699665306548 139.75001740279055 123.4 35.669767797872254 139.7499161170332 123.4 35.66971759994896 139.74994149812386 123.4 35.66998737694289 139.75007898582083 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8466a127-36ee-47c6-a609-47354f0687f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8466a127-36ee-47c6-a609-47354f0687f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8466a127-36ee-47c6-a609-47354f0687f1">
											<gml:posList>35.66985807370196 139.74949257852555 123.4 35.66984768619812 139.7494872872177 123.4 35.66986839751311 139.74954881492874 123.4 35.66987879402795 139.7495541062365 123.4 35.66985807370196 139.74949257852555 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ccf0dc5-007e-4188-b0b3-10a2cd8255e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ccf0dc5-007e-4188-b0b3-10a2cd8255e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ccf0dc5-007e-4188-b0b3-10a2cd8255e4">
											<gml:posList>35.66987879402795 139.7495541062365 114.364 35.66986839751311 139.74954881492874 114.364 35.66985723436388 139.74958172214252 114.364 35.66986886634928 139.74958786272 114.364 35.66989928001795 139.74949910792282 114.364 35.669897720082005 139.74949830318172 114.364 35.66987879402795 139.7495541062365 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ceb37a6a-32ce-4159-a877-619becce198c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ceb37a6a-32ce-4159-a877-619becce198c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ceb37a6a-32ce-4159-a877-619becce198c">
											<gml:posList>35.66986886634928 139.74958786272 125.483 35.669872560678456 139.7495859920552 125.483 35.66990081551204 139.74950364630317 125.483 35.66989928001795 139.74949910792282 125.483 35.66986886634928 139.74958786272 125.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-554a8411-cf47-4fd7-8d38-119bf0473ba5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-554a8411-cf47-4fd7-8d38-119bf0473ba5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-554a8411-cf47-4fd7-8d38-119bf0473ba5">
											<gml:posList>35.66992171522085 139.74961574335293 125.483 35.66992018875241 139.74961121600603 125.483 35.669872560678456 139.7495859920552 125.483 35.66986886634928 139.74958786272 125.483 35.66992171522085 139.74961574335293 125.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9ec5fca6-6499-4a85-baec-a51488bee367">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ec5fca6-6499-4a85-baec-a51488bee367">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ec5fca6-6499-4a85-baec-a51488bee367">
											<gml:posList>35.66985807370196 139.74949257852555 123.4 35.66987879402795 139.7495541062365 123.4 35.66993964698927 139.7493747296927 123.4 35.66991894459928 139.7493132019627 123.4 35.66985807370196 139.74949257852555 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f82d9df-b68e-46b1-8641-8d5b6a65fd25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f82d9df-b68e-46b1-8641-8d5b6a65fd25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f82d9df-b68e-46b1-8641-8d5b6a65fd25">
											<gml:posList>35.66994842494508 139.74952796444492 125.037 35.66990081551204 139.74950364630317 125.037 35.669872560678456 139.7495859920552 125.037 35.66992018875241 139.74961121600603 125.037 35.66994842494508 139.74952796444492 125.037</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-45c8ada5-29b8-4608-86fe-65691c456660">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45c8ada5-29b8-4608-86fe-65691c456660">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45c8ada5-29b8-4608-86fe-65691c456660">
											<gml:posList>35.66985723436388 139.74958172214252 114.364 35.669800626831055 139.7497485012742 114.364 35.669821140325745 139.7497589516712 114.364 35.669767797872254 139.7499161170332 114.364 35.6699665306548 139.75001740279055 114.364 35.6700743466269 139.7496962766084 114.364 35.66992171522085 139.74961574335293 114.364 35.66986886634928 139.74958786272 114.364 35.66985723436388 139.74958172214252 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4464a99b-070a-483c-89bf-2ebb01ae7cda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4464a99b-070a-483c-89bf-2ebb01ae7cda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4464a99b-070a-483c-89bf-2ebb01ae7cda">
											<gml:posList>35.66989928001795 139.74949910792282 125.483 35.66990081551204 139.74950364630317 125.483 35.66994842494508 139.74952796444492 125.483 35.66995213730074 139.74952609375663 125.483 35.66989928001795 139.74949910792282 125.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98440b09-4786-49c5-9e3f-b4193ca3afa5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98440b09-4786-49c5-9e3f-b4193ca3afa5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98440b09-4786-49c5-9e3f-b4193ca3afa5">
											<gml:posList>35.66995213730074 139.74952609375663 125.483 35.66994842494508 139.74952796444492 125.483 35.66992018875241 139.74961121600603 125.483 35.66992171522085 139.74961574335293 125.483 35.66995213730074 139.74952609375663 125.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-58c7490a-f7a4-4125-8ab7-a9873557ced6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58c7490a-f7a4-4125-8ab7-a9873557ced6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58c7490a-f7a4-4125-8ab7-a9873557ced6">
											<gml:posList>35.67007836351329 139.74944542383702 114.364 35.66993964698927 139.7493747296927 114.364 35.669897720082005 139.74949830318172 114.364 35.66989928001795 139.74949910792282 114.364 35.66995213730074 139.74952609375663 114.364 35.67010523584349 139.74960427353867 114.364 35.670124071582784 139.7495481832305 114.364 35.67007836351329 139.74944542383702 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd2b5b49-278d-4329-a563-0d5142714635">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd2b5b49-278d-4329-a563-0d5142714635">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd2b5b49-278d-4329-a563-0d5142714635">
											<gml:posList>35.67010561322194 139.74940833525017 123.4 35.66991894459928 139.7493132019627 123.4 35.66993964698927 139.7493747296927 123.4 35.67007836351329 139.74944542383702 123.4 35.67010561322194 139.74940833525017 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1282d771-ce3d-4fd4-bdf0-480ade6d7c48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1282d771-ce3d-4fd4-bdf0-480ade6d7c48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1282d771-ce3d-4fd4-bdf0-480ade6d7c48">
											<gml:posList>35.67010523584349 139.74960427353867 114.364 35.66995213730074 139.74952609375663 114.364 35.66992171522085 139.74961574335293 114.364 35.6700743466269 139.7496962766084 114.364 35.67010523584349 139.74960427353867 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec19c783-6682-40b3-a1d7-103f113e098b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec19c783-6682-40b3-a1d7-103f113e098b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec19c783-6682-40b3-a1d7-103f113e098b">
											<gml:posList>35.67016655131762 139.7495453330971 123.4 35.670124071582784 139.7495481832305 123.4 35.6699665306548 139.75001740279055 123.4 35.66998737694289 139.75007898582083 123.4 35.67016655131762 139.7495453330971 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2bc324a5-813a-4705-bba0-6c3b6e41068b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bc324a5-813a-4705-bba0-6c3b6e41068b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bc324a5-813a-4705-bba0-6c3b6e41068b">
											<gml:posList>35.67010561322194 139.74940833525017 123.4 35.67007836351329 139.74944542383702 123.4 35.670124071582784 139.7495481832305 123.4 35.67016655131762 139.7495453330971 123.4 35.67010561322194 139.74940833525017 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7df09c63-a72a-425b-8b06-a9a20943627c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7df09c63-a72a-425b-8b06-a9a20943627c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7df09c63-a72a-425b-8b06-a9a20943627c">
											<gml:posList>35.67010561322194 139.74940833525017 6.06 35.66991894459928 139.7493132019627 6.06 35.66991894459928 139.7493132019627 123.4 35.67010561322194 139.74940833525017 123.4 35.67010561322194 139.74940833525017 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79941c62-3952-400e-a434-a9d34e89bca1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79941c62-3952-400e-a434-a9d34e89bca1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79941c62-3952-400e-a434-a9d34e89bca1">
											<gml:posList>35.66991894459928 139.7493132019627 6.06 35.66985807370196 139.74949257852555 6.06 35.66985807370196 139.74949257852555 123.4 35.66991894459928 139.7493132019627 123.4 35.66991894459928 139.7493132019627 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-912ade90-703f-4265-8f65-6865c658aae5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-912ade90-703f-4265-8f65-6865c658aae5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-912ade90-703f-4265-8f65-6865c658aae5">
											<gml:posList>35.66993964698927 139.7493747296927 123.4 35.66993964698927 139.7493747296927 114.364 35.67007836351329 139.74944542383702 114.364 35.67007836351329 139.74944542383702 123.4 35.66993964698927 139.7493747296927 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13f432c4-b498-45d4-ae25-32c87d0d9b09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13f432c4-b498-45d4-ae25-32c87d0d9b09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13f432c4-b498-45d4-ae25-32c87d0d9b09">
											<gml:posList>35.66987879402795 139.7495541062365 123.4 35.66987879402795 139.7495541062365 114.364 35.669897720082005 139.74949830318172 114.364 35.66993964698927 139.7493747296927 114.364 35.66993964698927 139.7493747296927 123.4 35.66987879402795 139.7495541062365 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19180bce-d8be-4878-bf89-edd6f01a9a1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19180bce-d8be-4878-bf89-edd6f01a9a1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19180bce-d8be-4878-bf89-edd6f01a9a1c">
											<gml:posList>35.67016655131762 139.7495453330971 6.06 35.67010561322194 139.74940833525017 6.06 35.67010561322194 139.74940833525017 123.4 35.67016655131762 139.7495453330971 123.4 35.67016655131762 139.7495453330971 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73cd91fb-d26a-4c70-9efc-817e3b44178a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73cd91fb-d26a-4c70-9efc-817e3b44178a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73cd91fb-d26a-4c70-9efc-817e3b44178a">
											<gml:posList>35.66985807370196 139.74949257852555 6.06 35.66984768619812 139.7494872872177 6.06 35.66984768619812 139.7494872872177 123.4 35.66985807370196 139.74949257852555 123.4 35.66985807370196 139.74949257852555 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1eb4ef2-bfe3-4bf1-b9ca-2554e5dc40bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1eb4ef2-bfe3-4bf1-b9ca-2554e5dc40bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1eb4ef2-bfe3-4bf1-b9ca-2554e5dc40bf">
											<gml:posList>35.67007836351329 139.74944542383702 123.4 35.67007836351329 139.74944542383702 114.364 35.670124071582784 139.7495481832305 114.364 35.670124071582784 139.7495481832305 123.4 35.67007836351329 139.74944542383702 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6043213-6d2f-4b08-b27d-bc8463bf0146">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6043213-6d2f-4b08-b27d-bc8463bf0146">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6043213-6d2f-4b08-b27d-bc8463bf0146">
											<gml:posList>35.66989928001795 139.74949910792282 114.364 35.66989928001795 139.74949910792282 125.483 35.66995213730074 139.74952609375663 125.483 35.66995213730074 139.74952609375663 114.364 35.66989928001795 139.74949910792282 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4985b5e0-482f-43a2-896a-38670d9df736">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4985b5e0-482f-43a2-896a-38670d9df736">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4985b5e0-482f-43a2-896a-38670d9df736">
											<gml:posList>35.66990081551204 139.74950364630317 125.483 35.66990081551204 139.74950364630317 125.037 35.66994842494508 139.74952796444492 125.037 35.66994842494508 139.74952796444492 125.483 35.66990081551204 139.74950364630317 125.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe4b89b7-f806-4fb9-a79e-0b348e5bb4ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe4b89b7-f806-4fb9-a79e-0b348e5bb4ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe4b89b7-f806-4fb9-a79e-0b348e5bb4ac">
											<gml:posList>35.66986886634928 139.74958786272 114.364 35.66986886634928 139.74958786272 125.483 35.66989928001795 139.74949910792282 125.483 35.66989928001795 139.74949910792282 114.364 35.66986886634928 139.74958786272 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61946077-65f4-45e8-9e9c-495820e6013b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61946077-65f4-45e8-9e9c-495820e6013b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61946077-65f4-45e8-9e9c-495820e6013b">
											<gml:posList>35.669872560678456 139.7495859920552 125.483 35.669872560678456 139.7495859920552 125.037 35.66990081551204 139.74950364630317 125.037 35.66990081551204 139.74950364630317 125.483 35.669872560678456 139.7495859920552 125.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57641559-d0ef-43b9-b894-23a663dc08dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57641559-d0ef-43b9-b894-23a663dc08dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57641559-d0ef-43b9-b894-23a663dc08dc">
											<gml:posList>35.66986839751311 139.74954881492874 123.4 35.66986839751311 139.74954881492874 114.364 35.66987879402795 139.7495541062365 114.364 35.66987879402795 139.7495541062365 123.4 35.66986839751311 139.74954881492874 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcfd531c-3298-47aa-9712-5a190855b6a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcfd531c-3298-47aa-9712-5a190855b6a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcfd531c-3298-47aa-9712-5a190855b6a4">
											<gml:posList>35.66994842494508 139.74952796444492 125.483 35.66994842494508 139.74952796444492 125.037 35.66992018875241 139.74961121600603 125.037 35.66992018875241 139.74961121600603 125.483 35.66994842494508 139.74952796444492 125.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-134da714-65dd-4323-981d-64b56b12b335">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-134da714-65dd-4323-981d-64b56b12b335">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-134da714-65dd-4323-981d-64b56b12b335">
											<gml:posList>35.66995213730074 139.74952609375663 114.364 35.66995213730074 139.74952609375663 125.483 35.66992171522085 139.74961574335293 125.483 35.66992171522085 139.74961574335293 114.364 35.66995213730074 139.74952609375663 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18c8a6de-2950-433c-8fe8-11c8f71a6a1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18c8a6de-2950-433c-8fe8-11c8f71a6a1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18c8a6de-2950-433c-8fe8-11c8f71a6a1e">
											<gml:posList>35.66992018875241 139.74961121600603 125.483 35.66992018875241 139.74961121600603 125.037 35.669872560678456 139.7495859920552 125.037 35.669872560678456 139.7495859920552 125.483 35.66992018875241 139.74961121600603 125.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-610459d3-c7bd-493b-a00b-469e9c241a1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-610459d3-c7bd-493b-a00b-469e9c241a1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-610459d3-c7bd-493b-a00b-469e9c241a1a">
											<gml:posList>35.66992171522085 139.74961574335293 114.364 35.66992171522085 139.74961574335293 125.483 35.66986886634928 139.74958786272 125.483 35.66986886634928 139.74958786272 114.364 35.66992171522085 139.74961574335293 114.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-556eb80d-6790-4c2d-9922-34ff6cd64466">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-556eb80d-6790-4c2d-9922-34ff6cd64466">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-556eb80d-6790-4c2d-9922-34ff6cd64466">
											<gml:posList>35.66984768619812 139.7494872872177 6.06 35.66975041993746 139.74977389353572 6.06 35.66975041993746 139.74977389353572 123.4 35.66984768619812 139.7494872872177 123.4 35.66984768619812 139.7494872872177 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55e9d98a-bfdf-46ba-bf6b-4ec0d654c19a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55e9d98a-bfdf-46ba-bf6b-4ec0d654c19a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55e9d98a-bfdf-46ba-bf6b-4ec0d654c19a">
											<gml:posList>35.669800626831055 139.7497485012742 123.4 35.669800626831055 139.7497485012742 114.364 35.66985723436388 139.74958172214252 114.364 35.66986839751311 139.74954881492874 114.364 35.66986839751311 139.74954881492874 123.4 35.669800626831055 139.7497485012742 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61b1de67-ad1a-400b-82dc-6fb6931ab2a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61b1de67-ad1a-400b-82dc-6fb6931ab2a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61b1de67-ad1a-400b-82dc-6fb6931ab2a4">
											<gml:posList>35.669821140325745 139.7497589516712 123.4 35.669821140325745 139.7497589516712 114.364 35.669800626831055 139.7497485012742 114.364 35.669800626831055 139.7497485012742 123.4 35.669821140325745 139.7497589516712 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db0af696-9771-4837-97e2-416e81230a30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db0af696-9771-4837-97e2-416e81230a30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db0af696-9771-4837-97e2-416e81230a30">
											<gml:posList>35.66975041993746 139.74977389353572 6.06 35.669770933430115 139.74978434393267 6.06 35.669770933430115 139.74978434393267 123.4 35.66975041993746 139.74977389353572 123.4 35.66975041993746 139.74977389353572 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-abab3748-3860-47c0-b125-2eeeb195ac15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abab3748-3860-47c0-b125-2eeeb195ac15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abab3748-3860-47c0-b125-2eeeb195ac15">
											<gml:posList>35.670124071582784 139.7495481832305 123.4 35.670124071582784 139.7495481832305 114.364 35.67010523584349 139.74960427353867 114.364 35.6700743466269 139.7496962766084 114.364 35.6699665306548 139.75001740279055 114.364 35.6699665306548 139.75001740279055 123.4 35.670124071582784 139.7495481832305 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a984a876-4375-4ee8-b881-124656ef9e78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a984a876-4375-4ee8-b881-124656ef9e78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a984a876-4375-4ee8-b881-124656ef9e78">
											<gml:posList>35.66998737694289 139.75007898582083 6.06 35.67016655131762 139.7495453330971 6.06 35.67016655131762 139.7495453330971 123.4 35.66998737694289 139.75007898582083 123.4 35.66998737694289 139.75007898582083 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1895cd09-4b48-4f44-a424-fbc9e8d04886">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1895cd09-4b48-4f44-a424-fbc9e8d04886">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1895cd09-4b48-4f44-a424-fbc9e8d04886">
											<gml:posList>35.669767797872254 139.7499161170332 123.4 35.669767797872254 139.7499161170332 114.364 35.669821140325745 139.7497589516712 114.364 35.669821140325745 139.7497589516712 123.4 35.669767797872254 139.7499161170332 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0056e16-aad5-4562-b25f-6b849fa7c5ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0056e16-aad5-4562-b25f-6b849fa7c5ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0056e16-aad5-4562-b25f-6b849fa7c5ce">
											<gml:posList>35.669770933430115 139.74978434393267 6.06 35.66971759994896 139.74994149812386 6.06 35.66971759994896 139.74994149812386 123.4 35.669770933430115 139.74978434393267 123.4 35.669770933430115 139.74978434393267 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4c37736-0984-4934-9d21-3727c21edf54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4c37736-0984-4934-9d21-3727c21edf54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4c37736-0984-4934-9d21-3727c21edf54">
											<gml:posList>35.6699665306548 139.75001740279055 123.4 35.6699665306548 139.75001740279055 114.364 35.669767797872254 139.7499161170332 114.364 35.669767797872254 139.7499161170332 123.4 35.6699665306548 139.75001740279055 123.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4825b5d-a56b-47cf-a94e-dfe628d4db04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4825b5d-a56b-47cf-a94e-dfe628d4db04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4825b5d-a56b-47cf-a94e-dfe628d4db04">
											<gml:posList>35.66971759994896 139.74994149812386 6.06 35.66998737694289 139.75007898582083 6.06 35.66998737694289 139.75007898582083 123.4 35.66971759994896 139.74994149812386 123.4 35.66971759994896 139.74994149812386 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-852</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">2101.75549</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>8</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>