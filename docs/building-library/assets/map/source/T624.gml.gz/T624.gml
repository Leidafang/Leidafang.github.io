<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b481440e-9bb1-47a8-8da5-1b440d6ab624">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">17.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67109372826418 139.74181526041798 0 35.67108020506651 139.741835556964 0 35.67112484792958 139.741880199598 0 35.671125604218076 139.74187906096006 0 35.67121081259109 139.74196426386473 0 35.671223570498945 139.74194509490997 0 35.67109372826418 139.74181526041798 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67109372826418 139.74181526041798 7.31 35.671223570498945 139.74194509490997 7.31 35.67121081259109 139.74196426386473 7.31 35.671125604218076 139.74187906096006 7.31 35.67112484792958 139.741880199598 7.31 35.67108020506651 139.741835556964 7.31 35.67109372826418 139.74181526041798 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67109372826418 139.74181526041798 7.31 35.67108020506651 139.741835556964 7.31 35.67108020506651 139.741835556964 24.72 35.67109372826418 139.74181526041798 24.72 35.67109372826418 139.74181526041798 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67108020506651 139.741835556964 7.31 35.67112484792958 139.741880199598 7.31 35.67112484792958 139.741880199598 24.72 35.67108020506651 139.741835556964 24.72 35.67108020506651 139.741835556964 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67112484792958 139.741880199598 7.31 35.671125604218076 139.74187906096006 7.31 35.671125604218076 139.74187906096006 24.72 35.67112484792958 139.741880199598 24.72 35.67112484792958 139.741880199598 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671125604218076 139.74187906096006 7.31 35.67121081259109 139.74196426386473 7.31 35.67121081259109 139.74196426386473 24.72 35.671125604218076 139.74187906096006 24.72 35.671125604218076 139.74187906096006 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121081259109 139.74196426386473 7.31 35.671223570498945 139.74194509490997 7.31 35.671223570498945 139.74194509490997 24.72 35.67121081259109 139.74196426386473 24.72 35.67121081259109 139.74196426386473 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671223570498945 139.74194509490997 7.31 35.67109372826418 139.74181526041798 7.31 35.67109372826418 139.74181526041798 24.72 35.671223570498945 139.74194509490997 24.72 35.671223570498945 139.74194509490997 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67109372826418 139.74181526041798 24.72 35.67108020506651 139.741835556964 24.72 35.67112484792958 139.741880199598 24.72 35.671125604218076 139.74187906096006 24.72 35.67121081259109 139.74196426386473 24.72 35.671223570498945 139.74194509490997 24.72 35.67109372826418 139.74181526041798 24.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a61fb3b2-86cb-4e29-b25b-6cc8e4d1343a"/>
							<gml:surfaceMember xlink:href="#poly-6728bbbd-de97-4191-a18a-7baa177e653f"/>
							<gml:surfaceMember xlink:href="#poly-9d35f0e3-d77e-4985-bf14-b9ec7c5c95b4"/>
							<gml:surfaceMember xlink:href="#poly-24d1cbdf-6792-400f-8dde-9d401d043469"/>
							<gml:surfaceMember xlink:href="#poly-17ed1eb0-d087-4446-abb1-e47d6d2a9023"/>
							<gml:surfaceMember xlink:href="#poly-bccc6c93-5b55-4ae3-bbd3-4a891561bf43"/>
							<gml:surfaceMember xlink:href="#poly-f7f68aac-4449-405d-acf6-fbcc227c317d"/>
							<gml:surfaceMember xlink:href="#poly-cc60cd57-b4fb-45c7-bf67-7cfc47de1fd5"/>
							<gml:surfaceMember xlink:href="#poly-96130e80-220f-4728-9429-a169ac5856be"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a61fb3b2-86cb-4e29-b25b-6cc8e4d1343a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a61fb3b2-86cb-4e29-b25b-6cc8e4d1343a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a61fb3b2-86cb-4e29-b25b-6cc8e4d1343a">
											<gml:posList>35.67109372826418 139.74181526041798 7.31 35.67122357049895 139.74194509490994 7.31 35.67121081259108 139.74196426386473 7.31 35.67112560421808 139.74187906096003 7.31 35.671124847929576 139.741880199598 7.31 35.67108020506651 139.741835556964 7.31 35.67109372826418 139.74181526041798 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6728bbbd-de97-4191-a18a-7baa177e653f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6728bbbd-de97-4191-a18a-7baa177e653f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6728bbbd-de97-4191-a18a-7baa177e653f">
											<gml:posList>35.671124847929576 139.741880199598 16.516 35.67113837112629 139.74185989200183 16.516 35.67109372826418 139.74181526041798 16.516 35.67108020506651 139.741835556964 16.516 35.671124847929576 139.741880199598 16.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d35f0e3-d77e-4985-bf14-b9ec7c5c95b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d35f0e3-d77e-4985-bf14-b9ec7c5c95b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d35f0e3-d77e-4985-bf14-b9ec7c5c95b4">
											<gml:posList>35.67121081259108 139.74196426386473 16.003 35.67122357049895 139.74194509490994 16.003 35.67113837112629 139.74185989200183 16.003 35.67112560421808 139.74187906096003 16.003 35.67121081259108 139.74196426386473 16.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24d1cbdf-6792-400f-8dde-9d401d043469">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24d1cbdf-6792-400f-8dde-9d401d043469">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24d1cbdf-6792-400f-8dde-9d401d043469">
											<gml:posList>35.67109372826418 139.74181526041798 16.516 35.67109372826418 139.74181526041798 7.31 35.67108020506651 139.741835556964 7.31 35.67108020506651 139.741835556964 16.516 35.67109372826418 139.74181526041798 16.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17ed1eb0-d087-4446-abb1-e47d6d2a9023">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17ed1eb0-d087-4446-abb1-e47d6d2a9023">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17ed1eb0-d087-4446-abb1-e47d6d2a9023">
											<gml:posList>35.67108020506651 139.741835556964 16.516 35.67108020506651 139.741835556964 7.31 35.671124847929576 139.741880199598 7.31 35.671124847929576 139.741880199598 16.516 35.67108020506651 139.741835556964 16.516</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bccc6c93-5b55-4ae3-bbd3-4a891561bf43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bccc6c93-5b55-4ae3-bbd3-4a891561bf43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bccc6c93-5b55-4ae3-bbd3-4a891561bf43">
											<gml:posList>35.67112560421808 139.74187906096003 16.003 35.67113837112629 139.74185989200183 16.003 35.67113837112629 139.74185989200183 16.516 35.671124847929576 139.741880199598 16.516 35.671124847929576 139.741880199598 7.31 35.67112560421808 139.74187906096003 7.31 35.67112560421808 139.74187906096003 16.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7f68aac-4449-405d-acf6-fbcc227c317d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7f68aac-4449-405d-acf6-fbcc227c317d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7f68aac-4449-405d-acf6-fbcc227c317d">
											<gml:posList>35.67109372826418 139.74181526041798 7.31 35.67109372826418 139.74181526041798 16.516 35.67113837112629 139.74185989200183 16.516 35.67113837112629 139.74185989200183 16.003 35.67122357049895 139.74194509490994 16.003 35.67122357049895 139.74194509490994 7.31 35.67109372826418 139.74181526041798 7.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc60cd57-b4fb-45c7-bf67-7cfc47de1fd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc60cd57-b4fb-45c7-bf67-7cfc47de1fd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc60cd57-b4fb-45c7-bf67-7cfc47de1fd5">
											<gml:posList>35.67112560421808 139.74187906096003 16.003 35.67112560421808 139.74187906096003 7.31 35.67121081259108 139.74196426386473 7.31 35.67121081259108 139.74196426386473 16.003 35.67112560421808 139.74187906096003 16.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96130e80-220f-4728-9429-a169ac5856be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96130e80-220f-4728-9429-a169ac5856be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96130e80-220f-4728-9429-a169ac5856be">
											<gml:posList>35.67121081259108 139.74196426386473 16.003 35.67121081259108 139.74196426386473 7.31 35.67122357049895 139.74194509490994 7.31 35.67122357049895 139.74194509490994 16.003 35.67121081259108 139.74196426386473 16.003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8955</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.32</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>