<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b635bc85-19f0-4c15-83a0-a966cd899814">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門一・二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:measuredHeight uom="m">4.1</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66801889253579 139.74578025079384 0 35.668004486689334 139.7457652440551 0 35.6679431134151 139.74585376684075 0 35.66795752826443 139.7458687735742 0 35.66801889253579 139.74578025079384 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66801889253579 139.74578025079384 6.68 35.66795752826443 139.7458687735742 6.68 35.6679431134151 139.74585376684075 6.68 35.668004486689334 139.7457652440551 6.68 35.66801889253579 139.74578025079384 6.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66801889253579 139.74578025079384 6.68 35.668004486689334 139.7457652440551 6.68 35.668004486689334 139.7457652440551 10.82 35.66801889253579 139.74578025079384 10.82 35.66801889253579 139.74578025079384 6.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668004486689334 139.7457652440551 6.68 35.6679431134151 139.74585376684075 6.68 35.6679431134151 139.74585376684075 10.82 35.668004486689334 139.7457652440551 10.82 35.668004486689334 139.7457652440551 6.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6679431134151 139.74585376684075 6.68 35.66795752826443 139.7458687735742 6.68 35.66795752826443 139.7458687735742 10.82 35.6679431134151 139.74585376684075 10.82 35.6679431134151 139.74585376684075 6.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66795752826443 139.7458687735742 6.68 35.66801889253579 139.74578025079384 6.68 35.66801889253579 139.74578025079384 10.82 35.66795752826443 139.7458687735742 10.82 35.66795752826443 139.7458687735742 6.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66801889253579 139.74578025079384 10.82 35.668004486689334 139.7457652440551 10.82 35.6679431134151 139.74585376684075 10.82 35.66795752826443 139.7458687735742 10.82 35.66801889253579 139.74578025079384 10.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8c32927d-452f-4579-93d2-58b8d7f3a868"/>
							<gml:surfaceMember xlink:href="#poly-030e2a2f-7ebf-4cbb-82b4-7f7ec1038f07"/>
							<gml:surfaceMember xlink:href="#poly-aa554531-d78a-4d19-97db-51fe264a62e0"/>
							<gml:surfaceMember xlink:href="#poly-f5bff9ae-ab59-48f1-b234-20553b23bcea"/>
							<gml:surfaceMember xlink:href="#poly-150ff850-08bb-429b-bf4b-dd214b440197"/>
							<gml:surfaceMember xlink:href="#poly-a4453f63-0c8d-47f4-a832-391fa0cb1f67"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8c32927d-452f-4579-93d2-58b8d7f3a868">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c32927d-452f-4579-93d2-58b8d7f3a868">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c32927d-452f-4579-93d2-58b8d7f3a868">
											<gml:posList>35.66801889253578 139.7457802507938 6.68 35.66795752826441 139.7458687735742 6.68 35.667943113415085 139.74585376684075 6.68 35.6680044866893 139.74576524405506 6.68 35.66801889253578 139.7457802507938 6.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-030e2a2f-7ebf-4cbb-82b4-7f7ec1038f07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-030e2a2f-7ebf-4cbb-82b4-7f7ec1038f07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-030e2a2f-7ebf-4cbb-82b4-7f7ec1038f07">
											<gml:posList>35.66795752826441 139.7458687735742 11.06 35.66801889253578 139.7457802507938 11.06 35.6680044866893 139.74576524405506 11.06 35.667943113415085 139.74585376684075 11.06 35.66795752826441 139.7458687735742 11.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa554531-d78a-4d19-97db-51fe264a62e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa554531-d78a-4d19-97db-51fe264a62e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa554531-d78a-4d19-97db-51fe264a62e0">
											<gml:posList>35.66801889253578 139.7457802507938 6.68 35.6680044866893 139.74576524405506 6.68 35.6680044866893 139.74576524405506 11.06 35.66801889253578 139.7457802507938 11.06 35.66801889253578 139.7457802507938 6.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5bff9ae-ab59-48f1-b234-20553b23bcea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5bff9ae-ab59-48f1-b234-20553b23bcea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5bff9ae-ab59-48f1-b234-20553b23bcea">
											<gml:posList>35.6680044866893 139.74576524405506 6.68 35.667943113415085 139.74585376684075 6.68 35.667943113415085 139.74585376684075 11.06 35.6680044866893 139.74576524405506 11.06 35.6680044866893 139.74576524405506 6.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-150ff850-08bb-429b-bf4b-dd214b440197">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-150ff850-08bb-429b-bf4b-dd214b440197">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-150ff850-08bb-429b-bf4b-dd214b440197">
											<gml:posList>35.66795752826441 139.7458687735742 6.68 35.66801889253578 139.7457802507938 6.68 35.66801889253578 139.7457802507938 11.06 35.66795752826441 139.7458687735742 11.06 35.66795752826441 139.7458687735742 6.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4453f63-0c8d-47f4-a832-391fa0cb1f67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4453f63-0c8d-47f4-a832-391fa0cb1f67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4453f63-0c8d-47f4-a832-391fa0cb1f67">
											<gml:posList>35.667943113415085 139.74585376684075 6.68 35.66795752826441 139.7458687735742 6.68 35.66795752826441 139.7458687735742 11.06 35.667943113415085 139.74585376684075 11.06 35.667943113415085 139.74585376684075 6.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3601</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.1</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>