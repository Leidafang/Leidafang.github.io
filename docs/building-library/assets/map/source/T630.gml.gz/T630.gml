<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b6c01059-f9d5-4273-b0d6-781ef181884d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">5.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66693783729881 139.73793461570003 0 35.66692240570894 139.7379117692884 0 35.66691556070283 139.73791862581857 0 35.66688605114789 139.7378749196515 0 35.666849214681086 139.73791240867246 0 35.66689415580416 139.73797896124108 0 35.66693783729881 139.73793461570003 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66693783729881 139.73793461570003 13.884 35.66689415580416 139.73797896124108 13.884 35.666849214681086 139.73791240867246 13.884 35.66688605114789 139.7378749196515 13.884 35.66691556070283 139.73791862581857 13.884 35.66692240570894 139.7379117692884 13.884 35.66693783729881 139.73793461570003 13.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66693783729881 139.73793461570003 13.884 35.66692240570894 139.7379117692884 13.884 35.66692240570894 139.7379117692884 19.39 35.66693783729881 139.73793461570003 19.39 35.66693783729881 139.73793461570003 13.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66692240570894 139.7379117692884 13.884 35.66691556070283 139.73791862581857 13.884 35.66691556070283 139.73791862581857 19.39 35.66692240570894 139.7379117692884 19.39 35.66692240570894 139.7379117692884 13.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66691556070283 139.73791862581857 13.884 35.66688605114789 139.7378749196515 13.884 35.66688605114789 139.7378749196515 19.39 35.66691556070283 139.73791862581857 19.39 35.66691556070283 139.73791862581857 13.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66688605114789 139.7378749196515 13.884 35.666849214681086 139.73791240867246 13.884 35.666849214681086 139.73791240867246 19.39 35.66688605114789 139.7378749196515 19.39 35.66688605114789 139.7378749196515 13.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666849214681086 139.73791240867246 13.884 35.66689415580416 139.73797896124108 13.884 35.66689415580416 139.73797896124108 19.39 35.666849214681086 139.73791240867246 19.39 35.666849214681086 139.73791240867246 13.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66689415580416 139.73797896124108 13.884 35.66693783729881 139.73793461570003 13.884 35.66693783729881 139.73793461570003 19.39 35.66689415580416 139.73797896124108 19.39 35.66689415580416 139.73797896124108 13.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66693783729881 139.73793461570003 19.39 35.66692240570894 139.7379117692884 19.39 35.66691556070283 139.73791862581857 19.39 35.66688605114789 139.7378749196515 19.39 35.666849214681086 139.73791240867246 19.39 35.66689415580416 139.73797896124108 19.39 35.66693783729881 139.73793461570003 19.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1b0925b1-fdc8-48f3-9622-fbdcef80e44d"/>
							<gml:surfaceMember xlink:href="#poly-2c26a21e-69f0-4dbf-b57a-b42e712a3b70"/>
							<gml:surfaceMember xlink:href="#poly-6cb0e96b-84c1-40b0-82e0-9ae23c211f8d"/>
							<gml:surfaceMember xlink:href="#poly-f56458b5-31dd-4276-a638-8c5931ee09ca"/>
							<gml:surfaceMember xlink:href="#poly-506dc4e9-c908-4774-afd6-28842e222064"/>
							<gml:surfaceMember xlink:href="#poly-44ce4cce-c407-4878-94ce-d39a4f37ec60"/>
							<gml:surfaceMember xlink:href="#poly-869c0f96-2cfe-4492-9f15-54ca13d51a21"/>
							<gml:surfaceMember xlink:href="#poly-0623789e-9cfa-4f06-b602-b378d3ca793d"/>
							<gml:surfaceMember xlink:href="#poly-0fbf0e78-66e1-4d05-ba44-f943361b2a0f"/>
							<gml:surfaceMember xlink:href="#poly-4728ce27-5ea3-4d47-a5fc-4cf0fa5b14c8"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1b0925b1-fdc8-48f3-9622-fbdcef80e44d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b0925b1-fdc8-48f3-9622-fbdcef80e44d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b0925b1-fdc8-48f3-9622-fbdcef80e44d">
											<gml:posList>35.66689415580414 139.73797896124108 13.884 35.666849214681086 139.73791240867246 13.884 35.66688605114787 139.73787491965146 13.884 35.66691556070284 139.73791862581854 13.884 35.66692240570893 139.73791176928836 13.884 35.666937837298775 139.7379346157 13.884 35.66689415580414 139.73797896124108 13.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c26a21e-69f0-4dbf-b57a-b42e712a3b70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c26a21e-69f0-4dbf-b57a-b42e712a3b70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c26a21e-69f0-4dbf-b57a-b42e712a3b70">
											<gml:posList>35.6669125920942 139.7379602388097 23.013 35.66693103739502 139.73794151635903 22.206 35.66691556070284 139.73791862581854 22.206 35.66688605114787 139.73787491965146 22.206 35.66686763291598 139.73789366416628 23.013 35.6669125920942 139.7379602388097 23.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6cb0e96b-84c1-40b0-82e0-9ae23c211f8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cb0e96b-84c1-40b0-82e0-9ae23c211f8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cb0e96b-84c1-40b0-82e0-9ae23c211f8d">
											<gml:posList>35.666937837298775 139.7379346157 22.206 35.66692240570893 139.73791176928836 22.206 35.66691556070284 139.73791862581854 22.206 35.66693103739502 139.73794151635903 22.206 35.666937837298775 139.7379346157 22.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f56458b5-31dd-4276-a638-8c5931ee09ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f56458b5-31dd-4276-a638-8c5931ee09ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f56458b5-31dd-4276-a638-8c5931ee09ca">
											<gml:posList>35.666849214681086 139.73791240867246 22.206 35.66689415580414 139.73797896124108 22.206 35.6669125920942 139.7379602388097 23.013 35.66686763291598 139.73789366416628 23.013 35.666849214681086 139.73791240867246 22.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-506dc4e9-c908-4774-afd6-28842e222064">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-506dc4e9-c908-4774-afd6-28842e222064">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-506dc4e9-c908-4774-afd6-28842e222064">
											<gml:posList>35.66686763291598 139.73789366416628 23.013 35.66688605114787 139.73787491965146 22.206 35.66688605114787 139.73787491965146 13.884 35.666849214681086 139.73791240867246 13.884 35.666849214681086 139.73791240867246 22.206 35.66686763291598 139.73789366416628 23.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44ce4cce-c407-4878-94ce-d39a4f37ec60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44ce4cce-c407-4878-94ce-d39a4f37ec60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44ce4cce-c407-4878-94ce-d39a4f37ec60">
											<gml:posList>35.666849214681086 139.73791240867246 13.884 35.66689415580414 139.73797896124108 13.884 35.66689415580414 139.73797896124108 22.206 35.666849214681086 139.73791240867246 22.206 35.666849214681086 139.73791240867246 13.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-869c0f96-2cfe-4492-9f15-54ca13d51a21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-869c0f96-2cfe-4492-9f15-54ca13d51a21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-869c0f96-2cfe-4492-9f15-54ca13d51a21">
											<gml:posList>35.66691556070284 139.73791862581854 13.884 35.66688605114787 139.73787491965146 13.884 35.66688605114787 139.73787491965146 22.206 35.66691556070284 139.73791862581854 22.206 35.66691556070284 139.73791862581854 13.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0623789e-9cfa-4f06-b602-b378d3ca793d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0623789e-9cfa-4f06-b602-b378d3ca793d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0623789e-9cfa-4f06-b602-b378d3ca793d">
											<gml:posList>35.66692240570893 139.73791176928836 13.884 35.66691556070284 139.73791862581854 13.884 35.66691556070284 139.73791862581854 22.206 35.66692240570893 139.73791176928836 22.206 35.66692240570893 139.73791176928836 13.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fbf0e78-66e1-4d05-ba44-f943361b2a0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fbf0e78-66e1-4d05-ba44-f943361b2a0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fbf0e78-66e1-4d05-ba44-f943361b2a0f">
											<gml:posList>35.666937837298775 139.7379346157 13.884 35.66692240570893 139.73791176928836 13.884 35.66692240570893 139.73791176928836 22.206 35.666937837298775 139.7379346157 22.206 35.666937837298775 139.7379346157 13.884</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4728ce27-5ea3-4d47-a5fc-4cf0fa5b14c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4728ce27-5ea3-4d47-a5fc-4cf0fa5b14c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4728ce27-5ea3-4d47-a5fc-4cf0fa5b14c8">
											<gml:posList>35.66689415580414 139.73797896124108 22.206 35.66689415580414 139.73797896124108 13.884 35.666937837298775 139.7379346157 13.884 35.666937837298775 139.7379346157 22.206 35.66693103739502 139.73794151635903 22.206 35.6669125920942 139.7379602388097 23.013 35.66689415580414 139.73797896124108 22.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6858</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">44.19725</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">5</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>