<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b8762b4e-146f-444d-9a19-9d169bf3508f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">16.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668486535536445 139.7400676332685 0 35.668519369875895 139.7400990761856 0 35.668568975352855 139.74002136505646 0 35.66853623113068 139.7399899220469 0 35.668486535536445 139.7400676332685 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668486535536445 139.7400676332685 11.48 35.66853623113068 139.7399899220469 11.48 35.668568975352855 139.74002136505646 11.48 35.668519369875895 139.7400990761856 11.48 35.668486535536445 139.7400676332685 11.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668486535536445 139.7400676332685 11.48 35.668519369875895 139.7400990761856 11.48 35.668519369875895 139.7400990761856 27.9 35.668486535536445 139.7400676332685 27.9 35.668486535536445 139.7400676332685 11.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668519369875895 139.7400990761856 11.48 35.668568975352855 139.74002136505646 11.48 35.668568975352855 139.74002136505646 27.9 35.668519369875895 139.7400990761856 27.9 35.668519369875895 139.7400990761856 11.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668568975352855 139.74002136505646 11.48 35.66853623113068 139.7399899220469 11.48 35.66853623113068 139.7399899220469 27.9 35.668568975352855 139.74002136505646 27.9 35.668568975352855 139.74002136505646 11.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66853623113068 139.7399899220469 11.48 35.668486535536445 139.7400676332685 11.48 35.668486535536445 139.7400676332685 27.9 35.66853623113068 139.7399899220469 27.9 35.66853623113068 139.7399899220469 11.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668486535536445 139.7400676332685 27.9 35.668519369875895 139.7400990761856 27.9 35.668568975352855 139.74002136505646 27.9 35.66853623113068 139.7399899220469 27.9 35.668486535536445 139.7400676332685 27.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ec1ca1a5-ea17-409e-9d97-560ac2bc68fc"/>
							<gml:surfaceMember xlink:href="#poly-2dfc2699-ffaa-4501-8f11-f95dda361e1f"/>
							<gml:surfaceMember xlink:href="#poly-68eb699c-80dc-40b8-b78c-f0bc9a3d037a"/>
							<gml:surfaceMember xlink:href="#poly-a3688ad4-fe46-478a-af77-5a09a9c0a71e"/>
							<gml:surfaceMember xlink:href="#poly-6b06bc0c-2fcb-4d79-94b2-c278f992de06"/>
							<gml:surfaceMember xlink:href="#poly-4d51b0cc-147e-4e4b-9622-db990eac6503"/>
							<gml:surfaceMember xlink:href="#poly-5e74817a-6494-4cf2-a2d9-5873860a4120"/>
							<gml:surfaceMember xlink:href="#poly-bd477cdf-64f5-472d-a738-4cdf47731f65"/>
							<gml:surfaceMember xlink:href="#poly-5f28fdba-e45c-480f-ab7c-f2f6798877fd"/>
							<gml:surfaceMember xlink:href="#poly-362a9a65-f2f7-4f0d-84d9-925a388f0bc4"/>
							<gml:surfaceMember xlink:href="#poly-f9eb38d9-1b30-4857-b7b0-b8893a2b485e"/>
							<gml:surfaceMember xlink:href="#poly-718c8b0c-07f7-4d34-9e0e-0483513002b9"/>
							<gml:surfaceMember xlink:href="#poly-b48e281f-d503-4894-ac78-e7f67a663fbd"/>
							<gml:surfaceMember xlink:href="#poly-2a3152f4-e03d-4063-8621-a1957358e2f5"/>
							<gml:surfaceMember xlink:href="#poly-6ee4daf0-d67c-4e22-a05c-3bf6b661cbfa"/>
							<gml:surfaceMember xlink:href="#poly-4d148214-3b7d-49c6-aae9-617f3bbc188a"/>
							<gml:surfaceMember xlink:href="#poly-84a95171-6440-455c-bc92-63fd5172dbd4"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ec1ca1a5-ea17-409e-9d97-560ac2bc68fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec1ca1a5-ea17-409e-9d97-560ac2bc68fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec1ca1a5-ea17-409e-9d97-560ac2bc68fc">
											<gml:posList>35.66848653553644 139.7400676332685 11.48 35.66853623113066 139.73998992204687 11.48 35.66856897535286 139.74002136505646 11.48 35.66851936987588 139.7400990761856 11.48 35.66848653553644 139.7400676332685 11.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2dfc2699-ffaa-4501-8f11-f95dda361e1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dfc2699-ffaa-4501-8f11-f95dda361e1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dfc2699-ffaa-4501-8f11-f95dda361e1f">
											<gml:posList>35.66850807930818 139.74003395104313 27.609 35.66848653553644 139.7400676332685 27.609 35.6685029527072 139.74008335472382 28.208 35.66852446944211 139.74004967252725 28.208 35.66850807930818 139.74003395104313 27.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68eb699c-80dc-40b8-b78c-f0bc9a3d037a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68eb699c-80dc-40b8-b78c-f0bc9a3d037a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68eb699c-80dc-40b8-b78c-f0bc9a3d037a">
											<gml:posList>35.66851936987588 139.7400990761856 27.609 35.66854086858767 139.74006539400727 27.609 35.66852446944211 139.74004967252725 28.208 35.6685029527072 139.74008335472382 28.208 35.66851936987588 139.7400990761856 27.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3688ad4-fe46-478a-af77-5a09a9c0a71e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3688ad4-fe46-478a-af77-5a09a9c0a71e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3688ad4-fe46-478a-af77-5a09a9c0a71e">
											<gml:posList>35.66850807930818 139.74003395104313 28.427 35.66850990888903 139.74003368381022 28.427 35.668536458211975 139.73999216412162 28.427 35.66853623113066 139.73998992204687 28.427 35.66850807930818 139.74003395104313 28.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6b06bc0c-2fcb-4d79-94b2-c278f992de06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b06bc0c-2fcb-4d79-94b2-c278f992de06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b06bc0c-2fcb-4d79-94b2-c278f992de06">
											<gml:posList>35.66854086858767 139.74006539400727 28.427 35.66854065053 139.74006316296772 28.427 35.66850990888903 139.74003368381022 28.427 35.66850807930818 139.74003395104313 28.427 35.66854086858767 139.74006539400727 28.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d51b0cc-147e-4e4b-9622-db990eac6503">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d51b0cc-147e-4e4b-9622-db990eac6503">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d51b0cc-147e-4e4b-9622-db990eac6503">
											<gml:posList>35.668567154794346 139.74002164332535 27.965 35.668536458211975 139.73999216412162 27.965 35.66850990888903 139.74003368381022 27.965 35.66854065053 139.74006316296772 27.965 35.668567154794346 139.74002164332535 27.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e74817a-6494-4cf2-a2d9-5873860a4120">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e74817a-6494-4cf2-a2d9-5873860a4120">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e74817a-6494-4cf2-a2d9-5873860a4120">
											<gml:posList>35.66853623113066 139.73998992204687 28.427 35.668536458211975 139.73999216412162 28.427 35.668567154794346 139.74002164332535 28.427 35.66856897535286 139.74002136505646 28.427 35.66853623113066 139.73998992204687 28.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd477cdf-64f5-472d-a738-4cdf47731f65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd477cdf-64f5-472d-a738-4cdf47731f65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd477cdf-64f5-472d-a738-4cdf47731f65">
											<gml:posList>35.66856897535286 139.74002136505646 28.427 35.668567154794346 139.74002164332535 28.427 35.66854065053 139.74006316296772 28.427 35.66854086858767 139.74006539400727 28.427 35.66856897535286 139.74002136505646 28.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f28fdba-e45c-480f-ab7c-f2f6798877fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f28fdba-e45c-480f-ab7c-f2f6798877fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f28fdba-e45c-480f-ab7c-f2f6798877fd">
											<gml:posList>35.66850990888903 139.74003368381022 28.427 35.66850990888903 139.74003368381022 27.965 35.668536458211975 139.73999216412162 27.965 35.668536458211975 139.73999216412162 28.427 35.66850990888903 139.74003368381022 28.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-362a9a65-f2f7-4f0d-84d9-925a388f0bc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-362a9a65-f2f7-4f0d-84d9-925a388f0bc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-362a9a65-f2f7-4f0d-84d9-925a388f0bc4">
											<gml:posList>35.66856897535286 139.74002136505646 11.48 35.66853623113066 139.73998992204687 11.48 35.66853623113066 139.73998992204687 28.427 35.66856897535286 139.74002136505646 28.427 35.66856897535286 139.74002136505646 11.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9eb38d9-1b30-4857-b7b0-b8893a2b485e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9eb38d9-1b30-4857-b7b0-b8893a2b485e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9eb38d9-1b30-4857-b7b0-b8893a2b485e">
											<gml:posList>35.668536458211975 139.73999216412162 28.427 35.668536458211975 139.73999216412162 27.965 35.668567154794346 139.74002164332535 27.965 35.668567154794346 139.74002164332535 28.427 35.668536458211975 139.73999216412162 28.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-718c8b0c-07f7-4d34-9e0e-0483513002b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-718c8b0c-07f7-4d34-9e0e-0483513002b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-718c8b0c-07f7-4d34-9e0e-0483513002b9">
											<gml:posList>35.66850807930818 139.74003395104313 27.609 35.66850807930818 139.74003395104313 28.427 35.66853623113066 139.73998992204687 28.427 35.66853623113066 139.73998992204687 11.48 35.66848653553644 139.7400676332685 11.48 35.66848653553644 139.7400676332685 27.609 35.66850807930818 139.74003395104313 27.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b48e281f-d503-4894-ac78-e7f67a663fbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b48e281f-d503-4894-ac78-e7f67a663fbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b48e281f-d503-4894-ac78-e7f67a663fbd">
											<gml:posList>35.668567154794346 139.74002164332535 28.427 35.668567154794346 139.74002164332535 27.965 35.66854065053 139.74006316296772 27.965 35.66854065053 139.74006316296772 28.427 35.668567154794346 139.74002164332535 28.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a3152f4-e03d-4063-8621-a1957358e2f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a3152f4-e03d-4063-8621-a1957358e2f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a3152f4-e03d-4063-8621-a1957358e2f5">
											<gml:posList>35.66854065053 139.74006316296772 28.427 35.66854065053 139.74006316296772 27.965 35.66850990888903 139.74003368381022 27.965 35.66850990888903 139.74003368381022 28.427 35.66854065053 139.74006316296772 28.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ee4daf0-d67c-4e22-a05c-3bf6b661cbfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ee4daf0-d67c-4e22-a05c-3bf6b661cbfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ee4daf0-d67c-4e22-a05c-3bf6b661cbfa">
											<gml:posList>35.66852446944211 139.74004967252725 28.208 35.66854086858767 139.74006539400727 27.609 35.66854086858767 139.74006539400727 28.427 35.66850807930818 139.74003395104313 28.427 35.66850807930818 139.74003395104313 27.609 35.66852446944211 139.74004967252725 28.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d148214-3b7d-49c6-aae9-617f3bbc188a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d148214-3b7d-49c6-aae9-617f3bbc188a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d148214-3b7d-49c6-aae9-617f3bbc188a">
											<gml:posList>35.66854086858767 139.74006539400727 27.609 35.66851936987588 139.7400990761856 27.609 35.66851936987588 139.7400990761856 11.48 35.66856897535286 139.74002136505646 11.48 35.66856897535286 139.74002136505646 28.427 35.66854086858767 139.74006539400727 28.427 35.66854086858767 139.74006539400727 27.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84a95171-6440-455c-bc92-63fd5172dbd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84a95171-6440-455c-bc92-63fd5172dbd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84a95171-6440-455c-bc92-63fd5172dbd4">
											<gml:posList>35.66848653553644 139.7400676332685 11.48 35.66851936987588 139.7400990761856 11.48 35.66851936987588 139.7400990761856 27.609 35.6685029527072 139.74008335472382 28.208 35.66848653553644 139.7400676332685 27.609 35.66848653553644 139.7400676332685 11.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1865</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">27.59679</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>