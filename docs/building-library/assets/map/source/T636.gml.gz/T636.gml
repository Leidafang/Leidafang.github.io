<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_b884937c-e4fb-4d26-b96d-14a4e864715b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">23.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67055772648894 139.74376882213778 0 35.67057191704638 139.74370009838566 0 35.67046525994505 139.7436669683447 0 35.67045106940617 139.74373569201117 0 35.67055772648894 139.74376882213778 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055772648894 139.74376882213778 7.377 35.67045106940617 139.74373569201117 7.377 35.67046525994505 139.7436669683447 7.377 35.67057191704638 139.74370009838566 7.377 35.67055772648894 139.74376882213778 7.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055772648894 139.74376882213778 7.377 35.67057191704638 139.74370009838566 7.377 35.67057191704638 139.74370009838566 31.17 35.67055772648894 139.74376882213778 31.17 35.67055772648894 139.74376882213778 7.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67057191704638 139.74370009838566 7.377 35.67046525994505 139.7436669683447 7.377 35.67046525994505 139.7436669683447 31.17 35.67057191704638 139.74370009838566 31.17 35.67057191704638 139.74370009838566 7.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67046525994505 139.7436669683447 7.377 35.67045106940617 139.74373569201117 7.377 35.67045106940617 139.74373569201117 31.17 35.67046525994505 139.7436669683447 31.17 35.67046525994505 139.7436669683447 7.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67045106940617 139.74373569201117 7.377 35.67055772648894 139.74376882213778 7.377 35.67055772648894 139.74376882213778 31.17 35.67045106940617 139.74373569201117 31.17 35.67045106940617 139.74373569201117 7.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055772648894 139.74376882213778 31.17 35.67057191704638 139.74370009838566 31.17 35.67046525994505 139.7436669683447 31.17 35.67045106940617 139.74373569201117 31.17 35.67055772648894 139.74376882213778 31.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-843a3665-eee1-4f0e-a733-71c7a5771c61"/>
							<gml:surfaceMember xlink:href="#poly-e4181324-2775-4e31-abf8-c38e78f9a098"/>
							<gml:surfaceMember xlink:href="#poly-6ebc39e6-6302-4f8f-994e-b8b81a5111e0"/>
							<gml:surfaceMember xlink:href="#poly-e6eff54f-caef-4fbb-9485-dc72ea1fb38e"/>
							<gml:surfaceMember xlink:href="#poly-e55a438c-53a1-4be3-ae89-d4f8df54f397"/>
							<gml:surfaceMember xlink:href="#poly-24b52563-2934-4789-a369-cc1df4cdd3f1"/>
							<gml:surfaceMember xlink:href="#poly-029872ed-7be2-4a17-a9b8-25b6f4a7afdc"/>
							<gml:surfaceMember xlink:href="#poly-8022ec3a-257e-4f6a-a106-b0037f647f2b"/>
							<gml:surfaceMember xlink:href="#poly-ceab87b8-2836-4eb3-be14-cc988d8d48c0"/>
							<gml:surfaceMember xlink:href="#poly-0f794a36-870f-4a49-9a16-8dc359700cc0"/>
							<gml:surfaceMember xlink:href="#poly-407148a0-2305-42ee-82c5-74e4a48a0f76"/>
							<gml:surfaceMember xlink:href="#poly-4330407d-26f3-4e8a-8f2e-d1fae2b6c179"/>
							<gml:surfaceMember xlink:href="#poly-7f7cbe21-19e7-4b3f-9a7f-86f947f0e227"/>
							<gml:surfaceMember xlink:href="#poly-56a06f66-bb7b-4461-9244-6286844e084d"/>
							<gml:surfaceMember xlink:href="#poly-126d1179-671e-4cc2-bf4f-88bb732d29ab"/>
							<gml:surfaceMember xlink:href="#poly-da24e289-180e-4cef-8f2b-290bf47b818a"/>
							<gml:surfaceMember xlink:href="#poly-5778feda-c5fa-4a10-82d0-3f643e0df7d7"/>
							<gml:surfaceMember xlink:href="#poly-609c77eb-cdf0-41cf-9d52-a44e9ae6ddba"/>
							<gml:surfaceMember xlink:href="#poly-59a44fd2-aad8-484f-8cb1-6091334afdff"/>
							<gml:surfaceMember xlink:href="#poly-9bd0c705-de3e-4dde-8c07-077622d83181"/>
							<gml:surfaceMember xlink:href="#poly-9bb38a36-e0f6-4188-a51d-463b63c56ae9"/>
							<gml:surfaceMember xlink:href="#poly-9218f8b9-2561-4037-9ce5-a00cae067798"/>
							<gml:surfaceMember xlink:href="#poly-f929a0c9-d29c-4d46-81b9-b3580474ab37"/>
							<gml:surfaceMember xlink:href="#poly-741d46a5-3247-41f8-b7e4-e9916e7007f9"/>
							<gml:surfaceMember xlink:href="#poly-51bbb1d5-7acb-4845-88c9-078b99c52019"/>
							<gml:surfaceMember xlink:href="#poly-6b1f7114-46ab-4d70-8f25-cf098c260303"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b884937c-e4fb-4d26-b96d-14a4e864715b_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13f93ab8-a88a-48bd-9f6f-a154a50e31cc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705193296884 139.74372263635286 29.374 35.670515263282525 139.7437210060485 29.374 35.67051318713376 139.74371698752375 29.374 35.67051199451883 139.743713222076 29.374 35.67051179278027 139.74370860495733 29.374 35.67051248430458 139.74370520193074 29.374 35.670514166976574 139.74370131175976 29.374 35.67051634639818 139.74369875763298 29.374 35.67051941854015 139.7436966885443 29.374 35.67052358269941 139.7436964408707 29.374 35.6705271529479 139.74369753046093 29.374 35.67053032731616 139.74369959256651 29.374 35.670531816299025 139.74370189957457 29.374 35.670532710285656 139.74370408573878 29.374 35.670533008733415 139.74370542200512 29.374 35.6705337539264 139.7437135733274 29.374 35.67052623042595 139.74374178288951 29.374 35.67051537465658 139.74373743174002 29.374 35.6705193296884 139.74372263635286 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7f68cce-629c-4aaf-ac90-1bcf3551a57e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7f68cce-629c-4aaf-ac90-1bcf3551a57e_0">
											<gml:posList>35.67051199451883 139.743713222076 29.374 35.67051199451883 139.743713222076 34.401 35.67051179278027 139.74370860495733 34.401 35.67051179278027 139.74370860495733 29.374 35.67051199451883 139.743713222076 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf7a853f-f811-4d4a-946e-0f94025b3bba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf7a853f-f811-4d4a-946e-0f94025b3bba_0">
											<gml:posList>35.67051179278027 139.74370860495733 29.374 35.67051179278027 139.74370860495733 34.401 35.67051248430458 139.74370520193074 34.401 35.67051248430458 139.74370520193074 29.374 35.67051179278027 139.74370860495733 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5dea6c6-89cd-41ed-b2a3-db2076a4b47a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5dea6c6-89cd-41ed-b2a3-db2076a4b47a_0">
											<gml:posList>35.67051318713376 139.74371698752375 29.374 35.67051318713376 139.74371698752375 34.401 35.67051199451883 139.743713222076 34.401 35.67051199451883 139.743713222076 29.374 35.67051318713376 139.74371698752375 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7cb11b7-fd11-48be-99de-8cfc0e75f16d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7cb11b7-fd11-48be-99de-8cfc0e75f16d_0">
											<gml:posList>35.67051248430458 139.74370520193074 29.374 35.67051248430458 139.74370520193074 34.401 35.670514166976574 139.74370131175976 34.401 35.670514166976574 139.74370131175976 29.374 35.67051248430458 139.74370520193074 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89b16abe-aa63-4b9c-8371-047eea2a3c8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89b16abe-aa63-4b9c-8371-047eea2a3c8e_0">
											<gml:posList>35.670515263282525 139.7437210060485 34.401 35.67051318713376 139.74371698752375 34.401 35.67051318713376 139.74371698752375 29.374 35.670515263282525 139.7437210060485 29.374 35.670515263282525 139.7437210060485 34.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ad68742-2ad0-4851-9848-1baad8dd7845">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ad68742-2ad0-4851-9848-1baad8dd7845_0">
											<gml:posList>35.670514166976574 139.74370131175976 29.374 35.670514166976574 139.74370131175976 34.401 35.67051634639818 139.74369875763298 34.401 35.67051634639818 139.74369875763298 29.374 35.670514166976574 139.74370131175976 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ee202fb-35f1-4fe9-b668-400b27f284fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ee202fb-35f1-4fe9-b668-400b27f284fd_0">
											<gml:posList>35.6705193296884 139.74372263635286 29.374 35.6705193296884 139.74372263635286 34.401 35.670515263282525 139.7437210060485 34.401 35.670515263282525 139.7437210060485 29.374 35.6705193296884 139.74372263635286 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44b15ba2-b89d-4b1a-be65-ce62eb40db4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44b15ba2-b89d-4b1a-be65-ce62eb40db4e_0">
											<gml:posList>35.67051537465658 139.74373743174002 29.374 35.67051537465658 139.74373743174002 34.401 35.6705193296884 139.74372263635286 34.401 35.6705193296884 139.74372263635286 29.374 35.67051537465658 139.74373743174002 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef269163-df48-4148-a8ad-89421f573d0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef269163-df48-4148-a8ad-89421f573d0e_0">
											<gml:posList>35.67051634639818 139.74369875763298 34.401 35.67051941854015 139.7436966885443 34.401 35.67051941854015 139.7436966885443 29.374 35.67051634639818 139.74369875763298 29.374 35.67051634639818 139.74369875763298 34.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16904c19-70c0-4ff7-85e7-b2fbc223418c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16904c19-70c0-4ff7-85e7-b2fbc223418c_0">
											<gml:posList>35.67051537465658 139.74373743174002 34.401 35.67051537465658 139.74373743174002 29.374 35.67052623042595 139.74374178288951 29.374 35.67052623042595 139.74374178288951 34.401 35.67051537465658 139.74373743174002 34.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e96562d-2493-4fdd-8350-e0de56d9748c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e96562d-2493-4fdd-8350-e0de56d9748c_0">
											<gml:posList>35.67051941854015 139.7436966885443 29.374 35.67051941854015 139.7436966885443 34.401 35.67052358269941 139.7436964408707 34.401 35.67052358269941 139.7436964408707 29.374 35.67051941854015 139.7436966885443 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4886767-342a-4f7f-aa9b-9d357427e187">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4886767-342a-4f7f-aa9b-9d357427e187_0">
											<gml:posList>35.67052623042595 139.74374178288951 34.401 35.6705337539264 139.7437135733274 34.401 35.670533008733415 139.74370542200512 34.401 35.670532710285656 139.74370408573878 34.401 35.670531816299025 139.74370189957457 34.401 35.67053032731616 139.74369959256651 34.401 35.6705271529479 139.74369753046093 34.401 35.67052358269941 139.7436964408707 34.401 35.67051941854015 139.7436966885443 34.401 35.67051634639818 139.74369875763298 34.401 35.670514166976574 139.74370131175976 34.401 35.67051248430458 139.74370520193074 34.401 35.67051179278027 139.74370860495733 34.401 35.67051199451883 139.743713222076 34.401 35.67051318713376 139.74371698752375 34.401 35.670515263282525 139.7437210060485 34.401 35.6705193296884 139.74372263635286 34.401 35.67051537465658 139.74373743174002 34.401 35.67052623042595 139.74374178288951 34.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6be32cdc-790d-48c2-8eea-b7686c6a31ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6be32cdc-790d-48c2-8eea-b7686c6a31ce_0">
											<gml:posList>35.67052358269941 139.7436964408707 34.401 35.6705271529479 139.74369753046093 34.401 35.6705271529479 139.74369753046093 29.374 35.67052358269941 139.7436964408707 29.374 35.67052358269941 139.7436964408707 34.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49d45784-16a2-4d67-80d4-4013cf5e1ae3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49d45784-16a2-4d67-80d4-4013cf5e1ae3_0">
											<gml:posList>35.6705271529479 139.74369753046093 34.401 35.67053032731616 139.74369959256651 34.401 35.67053032731616 139.74369959256651 29.374 35.6705271529479 139.74369753046093 29.374 35.6705271529479 139.74369753046093 34.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b704e8df-21f0-41fb-9093-28d3154efe3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b704e8df-21f0-41fb-9093-28d3154efe3e_0">
											<gml:posList>35.6705337539264 139.7437135733274 29.374 35.6705337539264 139.7437135733274 34.401 35.67052623042595 139.74374178288951 34.401 35.67052623042595 139.74374178288951 29.374 35.6705337539264 139.7437135733274 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2e5fbfc-b818-401d-a0ee-b1c1703ff444">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2e5fbfc-b818-401d-a0ee-b1c1703ff444_0">
											<gml:posList>35.67053032731616 139.74369959256651 34.401 35.670531816299025 139.74370189957457 34.401 35.670531816299025 139.74370189957457 29.374 35.67053032731616 139.74369959256651 29.374 35.67053032731616 139.74369959256651 34.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba3de3f8-1c60-4ebe-811c-267328ade72f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba3de3f8-1c60-4ebe-811c-267328ade72f_0">
											<gml:posList>35.670531816299025 139.74370189957457 29.374 35.670531816299025 139.74370189957457 34.401 35.670532710285656 139.74370408573878 34.401 35.670532710285656 139.74370408573878 29.374 35.670531816299025 139.74370189957457 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-078f521b-5892-443b-8a11-3f4d417d2ec8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-078f521b-5892-443b-8a11-3f4d417d2ec8_0">
											<gml:posList>35.670532710285656 139.74370408573878 34.401 35.670533008733415 139.74370542200512 34.401 35.670533008733415 139.74370542200512 29.374 35.670532710285656 139.74370408573878 29.374 35.670532710285656 139.74370408573878 34.401</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eba1c30f-d3cc-4fc3-9044-c50c334ba0ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eba1c30f-d3cc-4fc3-9044-c50c334ba0ad_0">
											<gml:posList>35.6705337539264 139.7437135733274 29.374 35.670533008733415 139.74370542200512 29.374 35.670533008733415 139.74370542200512 34.401 35.6705337539264 139.7437135733274 34.401 35.6705337539264 139.7437135733274 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b884937c-e4fb-4d26-b96d-14a4e864715b_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1097794-12be-426f-8433-34bb3f693a9c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67045544049947 139.74372281822178 29.374 35.67046069673918 139.74370025586205 29.374 35.670471921751975 139.74370417578618 29.374 35.67046666551976 139.74372674919508 29.374 35.67045544049947 139.74372281822178 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56bd6119-7999-4e74-ac64-fbac10e34ab2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67051165988475 139.74373593359738 29.374 35.67052623042595 139.74374178288951 29.374 35.67052243719506 139.74375598159713 29.374 35.67052092243758 139.74375537574414 29.374 35.67050759706464 139.74375123723166 29.374 35.67051165988475 139.74373593359738 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0029ff47-987c-46ec-bab9-285015cc8019">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0029ff47-987c-46ec-bab9-285015cc8019_0">
											<gml:posList>35.670471921751975 139.74370417578618 29.374 35.67046069673918 139.74370025586205 29.374 35.67046069673918 139.74370025586205 32.769 35.670471921751975 139.74370417578618 32.769 35.670471921751975 139.74370417578618 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0bf531fc-3b3c-4ba3-892e-5bc58ef51520">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0bf531fc-3b3c-4ba3-892e-5bc58ef51520_0">
											<gml:posList>35.67046069673918 139.74370025586205 29.374 35.67045544049947 139.74372281822178 29.374 35.67045544049947 139.74372281822178 32.769 35.67046069673918 139.74370025586205 32.769 35.67046069673918 139.74370025586205 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8f7a52b-d661-4a7b-9a2b-c50bd03a8fb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8f7a52b-d661-4a7b-9a2b-c50bd03a8fb6_0">
											<gml:posList>35.670471921751975 139.74370417578618 32.769 35.67046069673918 139.74370025586205 32.769 35.67045544049947 139.74372281822178 32.769 35.67046666551976 139.74372674919508 32.769 35.670471921751975 139.74370417578618 32.769</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ee6df74-8b6b-4b19-a759-edc8ada20441">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ee6df74-8b6b-4b19-a759-edc8ada20441_0">
											<gml:posList>35.67046666551976 139.74372674919508 29.374 35.670471921751975 139.74370417578618 29.374 35.670471921751975 139.74370417578618 32.769 35.67046666551976 139.74372674919508 32.769 35.67046666551976 139.74372674919508 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-451f5662-3f3e-40e6-8d24-86f626d5c94a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-451f5662-3f3e-40e6-8d24-86f626d5c94a_0">
											<gml:posList>35.67045544049947 139.74372281822178 29.374 35.67046666551976 139.74372674919508 29.374 35.67046666551976 139.74372674919508 32.769 35.67045544049947 139.74372281822178 32.769 35.67045544049947 139.74372281822178 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c3bb07a-6d33-4915-9179-c5a60ebff30d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c3bb07a-6d33-4915-9179-c5a60ebff30d_0">
											<gml:posList>35.67051165988475 139.74373593359738 29.374 35.67051165988475 139.74373593359738 31.358 35.67052623042595 139.74374178288951 31.358 35.67052623042595 139.74374178288951 29.374 35.67051165988475 139.74373593359738 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff3f0dd1-fee8-43ad-89e1-3dc483382d31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff3f0dd1-fee8-43ad-89e1-3dc483382d31_0">
											<gml:posList>35.67050759706464 139.74375123723166 31.358 35.67051165988475 139.74373593359738 31.358 35.67051165988475 139.74373593359738 29.374 35.67050759706464 139.74375123723166 29.374 35.67050759706464 139.74375123723166 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fe11ea3-1a29-4a37-b487-3d26d6470285">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fe11ea3-1a29-4a37-b487-3d26d6470285_0">
											<gml:posList>35.67052092243758 139.74375537574414 31.358 35.67052243719506 139.74375598159713 31.358 35.67052623042595 139.74374178288951 31.358 35.67051165988475 139.74373593359738 31.358 35.67050759706464 139.74375123723166 31.358 35.67052092243758 139.74375537574414 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bd5b13e-a4f6-4d15-82d6-0f1eecdb1b65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1bd5b13e-a4f6-4d15-82d6-0f1eecdb1b65_0">
											<gml:posList>35.67052243719506 139.74375598159713 29.374 35.67052623042595 139.74374178288951 29.374 35.67052623042595 139.74374178288951 31.358 35.67052243719506 139.74375598159713 31.358 35.67052243719506 139.74375598159713 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a4edeb6-84f0-407d-a65b-c18968b99276">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a4edeb6-84f0-407d-a65b-c18968b99276_0">
											<gml:posList>35.67050759706464 139.74375123723166 29.374 35.67052092243758 139.74375537574414 29.374 35.67052092243758 139.74375537574414 31.358 35.67050759706464 139.74375123723166 31.358 35.67050759706464 139.74375123723166 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55343c31-6d90-49eb-8d37-b2710971e6d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55343c31-6d90-49eb-8d37-b2710971e6d9_0">
											<gml:posList>35.67052092243758 139.74375537574414 31.358 35.67052092243758 139.74375537574414 29.374 35.67052243719506 139.74375598159713 29.374 35.67052243719506 139.74375598159713 31.358 35.67052092243758 139.74375537574414 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_b884937c-e4fb-4d26-b96d-14a4e864715b_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b40865eb-1e6a-463f-b0e1-b73f575d62dc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6704616104569 139.74369262186732 29.374 35.670476432332045 139.743697056944 29.374 35.67046797256218 139.7437389317722 29.374 35.67045300630458 139.74373427592414 29.374 35.6704616104569 139.74369262186732 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2feab842-fe73-43ca-9571-cbcb42d8eddd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67050457212705 139.74371983604618 29.374 35.6704991084448 139.74374223295467 29.374 35.67047903840624 139.74373487647057 29.374 35.670484493073424 139.74371247957728 29.374 35.67050457212705 139.74371983604618 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38c480dc-c36a-4859-a1be-521afc40de84">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670489130456744 139.74368196458275 29.374 35.67051122926878 139.74369023562724 29.374 35.67050572030968 139.743712345387 29.374 35.67048362149913 139.74370407433696 29.374 35.670489130456744 139.74368196458275 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b46ddc4-b218-4e2d-9dc5-e0554188c4f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b46ddc4-b218-4e2d-9dc5-e0554188c4f0_0">
											<gml:posList>35.67045300630458 139.74373427592414 31.8 35.6704616104569 139.74369262186732 31.8 35.6704616104569 139.74369262186732 29.374 35.67045300630458 139.74373427592414 29.374 35.67045300630458 139.74373427592414 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-135194fd-8e22-4e17-afa4-a0035f5a3996">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-135194fd-8e22-4e17-afa4-a0035f5a3996_0">
											<gml:posList>35.67045300630458 139.74373427592414 29.374 35.67046797256218 139.7437389317722 29.374 35.67046797256218 139.7437389317722 31.8 35.67045300630458 139.74373427592414 31.8 35.67045300630458 139.74373427592414 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8dd69279-0e1d-4d5b-a411-a7f59460098f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8dd69279-0e1d-4d5b-a411-a7f59460098f_0">
											<gml:posList>35.67046797256218 139.7437389317722 31.8 35.670476432332045 139.743697056944 31.8 35.6704616104569 139.74369262186732 31.8 35.67045300630458 139.74373427592414 31.8 35.67046797256218 139.7437389317722 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74f369a2-1702-4eb1-b5fe-01e2891b0d4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74f369a2-1702-4eb1-b5fe-01e2891b0d4f_0">
											<gml:posList>35.6704616104569 139.74369262186732 31.8 35.670476432332045 139.743697056944 31.8 35.670476432332045 139.743697056944 29.374 35.6704616104569 139.74369262186732 29.374 35.6704616104569 139.74369262186732 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63753e6d-a6db-4269-8258-20b666306416">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63753e6d-a6db-4269-8258-20b666306416_0">
											<gml:posList>35.67046797256218 139.7437389317722 29.374 35.670476432332045 139.743697056944 29.374 35.670476432332045 139.743697056944 31.8 35.67046797256218 139.7437389317722 31.8 35.67046797256218 139.7437389317722 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ea2e60d-c280-491c-ab58-262f54b44f80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ea2e60d-c280-491c-ab58-262f54b44f80_0">
											<gml:posList>35.670484493073424 139.74371247957728 29.374 35.67047903840624 139.74373487647057 29.374 35.67047903840624 139.74373487647057 31.233 35.670484493073424 139.74371247957728 31.233 35.670484493073424 139.74371247957728 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06211782-5a62-4a07-a444-ca4f895104fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06211782-5a62-4a07-a444-ca4f895104fd_0">
											<gml:posList>35.670489130456744 139.74368196458275 29.374 35.67048362149913 139.74370407433696 29.374 35.67048362149913 139.74370407433696 31.233 35.670489130456744 139.74368196458275 31.233 35.670489130456744 139.74368196458275 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1bdd03e-a282-47d5-a116-ff7417857004">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1bdd03e-a282-47d5-a116-ff7417857004_0">
											<gml:posList>35.67047903840624 139.74373487647057 29.374 35.6704991084448 139.74374223295467 29.374 35.6704991084448 139.74374223295467 31.233 35.67047903840624 139.74373487647057 31.233 35.67047903840624 139.74373487647057 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0d18db9-0907-4881-afce-9261effecc64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0d18db9-0907-4881-afce-9261effecc64_0">
											<gml:posList>35.67047903840624 139.74373487647057 31.233 35.6704991084448 139.74374223295467 31.233 35.67050457212705 139.74371983604618 31.233 35.670484493073424 139.74371247957728 31.233 35.67047903840624 139.74373487647057 31.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bea09da2-365f-4621-842a-7fca2123aa7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bea09da2-365f-4621-842a-7fca2123aa7c_0">
											<gml:posList>35.67050457212705 139.74371983604618 29.374 35.670484493073424 139.74371247957728 29.374 35.670484493073424 139.74371247957728 31.233 35.67050457212705 139.74371983604618 31.233 35.67050457212705 139.74371983604618 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7a51e55-1e60-4d2c-aed8-0a6f075b7a7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7a51e55-1e60-4d2c-aed8-0a6f075b7a7d_0">
											<gml:posList>35.67050572030968 139.743712345387 29.374 35.67050572030968 139.743712345387 31.233 35.67048362149913 139.74370407433696 31.233 35.67048362149913 139.74370407433696 29.374 35.67050572030968 139.743712345387 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66951f87-2c38-4af6-a357-01f546c737ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66951f87-2c38-4af6-a357-01f546c737ce_0">
											<gml:posList>35.67050572030968 139.743712345387 31.233 35.67051122926878 139.74369023562724 31.233 35.670489130456744 139.74368196458275 31.233 35.67048362149913 139.74370407433696 31.233 35.67050572030968 139.743712345387 31.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e96fba2a-1dfb-4759-9c49-1d16120b7cf0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e96fba2a-1dfb-4759-9c49-1d16120b7cf0_0">
											<gml:posList>35.67051122926878 139.74369023562724 29.374 35.670489130456744 139.74368196458275 29.374 35.670489130456744 139.74368196458275 31.233 35.67051122926878 139.74369023562724 31.233 35.67051122926878 139.74369023562724 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f11b775f-ba0c-44d8-8b2b-48e5727813c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f11b775f-ba0c-44d8-8b2b-48e5727813c3_0">
											<gml:posList>35.67050457212705 139.74371983604618 29.374 35.67050457212705 139.74371983604618 31.233 35.6704991084448 139.74374223295467 31.233 35.6704991084448 139.74374223295467 29.374 35.67050457212705 139.74371983604618 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-643f3baf-ea76-4103-9b52-44652ea26bb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-643f3baf-ea76-4103-9b52-44652ea26bb6_0">
											<gml:posList>35.67050572030968 139.743712345387 29.374 35.67051122926878 139.74369023562724 29.374 35.67051122926878 139.74369023562724 31.233 35.67050572030968 139.743712345387 31.233 35.67050572030968 139.743712345387 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-843a3665-eee1-4f0e-a733-71c7a5771c61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-843a3665-eee1-4f0e-a733-71c7a5771c61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-843a3665-eee1-4f0e-a733-71c7a5771c61">
											<gml:posList>35.670557726488944 139.74376882213778 7.377 35.67045106940614 139.74373569201117 7.377 35.67046525994504 139.74366696834468 7.377 35.67057191704638 139.74370009838566 7.377 35.670557726488944 139.74376882213778 7.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e4181324-2775-4e31-abf8-c38e78f9a098">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4181324-2775-4e31-abf8-c38e78f9a098">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4181324-2775-4e31-abf8-c38e78f9a098">
											<gml:posList>35.67052092243758 139.74375537574414 31.8 35.67052197878532 139.74375771637514 31.8 35.67052243719506 139.74375598159713 31.8 35.67052092243758 139.74375537574414 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ebc39e6-6302-4f8f-994e-b8b81a5111e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ebc39e6-6302-4f8f-994e-b8b81a5111e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ebc39e6-6302-4f8f-994e-b8b81a5111e0">
											<gml:posList>35.670539470727626 139.74369217028965 31.8 35.670540001057084 139.743690181366 31.8 35.670537955969834 139.7436915644377 31.8 35.670539470727626 139.74369217028965 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6eff54f-caef-4fbb-9485-dc72ea1fb38e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6eff54f-caef-4fbb-9485-dc72ea1fb38e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6eff54f-caef-4fbb-9485-dc72ea1fb38e">
											<gml:posList>35.67045106940614 139.74373569201117 31.8 35.67045300630458 139.74373427592414 31.8 35.67046641547835 139.74366935304707 31.8 35.67046525994504 139.74366696834468 31.8 35.67045106940614 139.74373569201117 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e55a438c-53a1-4be3-ae89-d4f8df54f397">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e55a438c-53a1-4be3-ae89-d4f8df54f397">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e55a438c-53a1-4be3-ae89-d4f8df54f397">
											<gml:posList>35.67052197878532 139.74375771637514 31.8 35.67052092243758 139.74375537574414 31.8 35.67045300630458 139.74373427592414 31.8 35.67045106940614 139.74373569201117 31.8 35.67052197878532 139.74375771637514 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-24b52563-2934-4789-a369-cc1df4cdd3f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24b52563-2934-4789-a369-cc1df4cdd3f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24b52563-2934-4789-a369-cc1df4cdd3f1">
											<gml:posList>35.67052092243758 139.74375537574414 29.374 35.67052243719506 139.74375598159713 29.374 35.670539470727626 139.74369217028965 29.374 35.670537955969834 139.7436915644377 29.374 35.67046641547835 139.74366935304707 29.374 35.67045300630458 139.74373427592414 29.374 35.67052092243758 139.74375537574414 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-029872ed-7be2-4a17-a9b8-25b6f4a7afdc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-029872ed-7be2-4a17-a9b8-25b6f4a7afdc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-029872ed-7be2-4a17-a9b8-25b6f4a7afdc">
											<gml:posList>35.67046525994504 139.74366696834468 31.8 35.67046641547835 139.74366935304707 31.8 35.670537955969834 139.7436915644377 31.8 35.670540001057084 139.743690181366 31.8 35.67046525994504 139.74366696834468 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8022ec3a-257e-4f6a-a106-b0037f647f2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8022ec3a-257e-4f6a-a106-b0037f647f2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8022ec3a-257e-4f6a-a106-b0037f647f2b">
											<gml:posList>35.670540001057084 139.743690181366 36.872 35.67052197878532 139.74375771637514 36.872 35.670524663535424 139.74375591283209 36.872 35.670541391456574 139.7436932506778 36.872 35.670540001057084 139.743690181366 36.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ceab87b8-2836-4eb3-be14-cc988d8d48c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ceab87b8-2836-4eb3-be14-cc988d8d48c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ceab87b8-2836-4eb3-be14-cc988d8d48c0">
											<gml:posList>35.670557726488944 139.74376882213778 36.872 35.67055621888833 139.7437657198161 36.872 35.670524663535424 139.74375591283209 36.872 35.67052197878532 139.74375771637514 36.872 35.670557726488944 139.74376882213778 36.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0f794a36-870f-4a49-9a16-8dc359700cc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f794a36-870f-4a49-9a16-8dc359700cc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f794a36-870f-4a49-9a16-8dc359700cc0">
											<gml:posList>35.67055621888833 139.7437657198161 36.229 35.670569385571554 139.74370195699174 36.229 35.670541391456574 139.7436932506778 36.229 35.670524663535424 139.74375591283209 36.229 35.67055621888833 139.7437657198161 36.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-407148a0-2305-42ee-82c5-74e4a48a0f76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-407148a0-2305-42ee-82c5-74e4a48a0f76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-407148a0-2305-42ee-82c5-74e4a48a0f76">
											<gml:posList>35.670540001057084 139.743690181366 36.872 35.670541391456574 139.7436932506778 36.872 35.670569385571554 139.74370195699174 36.872 35.67057191704638 139.74370009838566 36.872 35.670540001057084 139.743690181366 36.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4330407d-26f3-4e8a-8f2e-d1fae2b6c179">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4330407d-26f3-4e8a-8f2e-d1fae2b6c179">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4330407d-26f3-4e8a-8f2e-d1fae2b6c179">
											<gml:posList>35.67057191704638 139.74370009838566 36.872 35.670569385571554 139.74370195699174 36.872 35.67055621888833 139.7437657198161 36.872 35.670557726488944 139.74376882213778 36.872 35.67057191704638 139.74370009838566 36.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f7cbe21-19e7-4b3f-9a7f-86f947f0e227">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f7cbe21-19e7-4b3f-9a7f-86f947f0e227">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f7cbe21-19e7-4b3f-9a7f-86f947f0e227">
											<gml:posList>35.67046641547835 139.74366935304707 31.8 35.67046641547835 139.74366935304707 29.374 35.670537955969834 139.7436915644377 29.374 35.670537955969834 139.7436915644377 31.8 35.67046641547835 139.74366935304707 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56a06f66-bb7b-4461-9244-6286844e084d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56a06f66-bb7b-4461-9244-6286844e084d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56a06f66-bb7b-4461-9244-6286844e084d">
											<gml:posList>35.67057191704638 139.74370009838566 7.377 35.67046525994504 139.74366696834468 7.377 35.67046525994504 139.74366696834468 31.8 35.670540001057084 139.743690181366 31.8 35.670540001057084 139.743690181366 36.872 35.67057191704638 139.74370009838566 36.872 35.67057191704638 139.74370009838566 7.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-126d1179-671e-4cc2-bf4f-88bb732d29ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-126d1179-671e-4cc2-bf4f-88bb732d29ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-126d1179-671e-4cc2-bf4f-88bb732d29ab">
											<gml:posList>35.670537955969834 139.7436915644377 31.8 35.670537955969834 139.7436915644377 29.374 35.670539470727626 139.74369217028965 29.374 35.670539470727626 139.74369217028965 31.8 35.670537955969834 139.7436915644377 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da24e289-180e-4cef-8f2b-290bf47b818a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da24e289-180e-4cef-8f2b-290bf47b818a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da24e289-180e-4cef-8f2b-290bf47b818a">
											<gml:posList>35.670541391456574 139.7436932506778 36.872 35.670541391456574 139.7436932506778 36.229 35.670569385571554 139.74370195699174 36.229 35.670569385571554 139.74370195699174 36.872 35.670541391456574 139.7436932506778 36.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5778feda-c5fa-4a10-82d0-3f643e0df7d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5778feda-c5fa-4a10-82d0-3f643e0df7d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5778feda-c5fa-4a10-82d0-3f643e0df7d7">
											<gml:posList>35.67045106940614 139.74373569201117 31.8 35.67046525994504 139.74366696834468 31.8 35.67046525994504 139.74366696834468 7.377 35.67045106940614 139.74373569201117 7.377 35.67045106940614 139.74373569201117 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-609c77eb-cdf0-41cf-9d52-a44e9ae6ddba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-609c77eb-cdf0-41cf-9d52-a44e9ae6ddba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-609c77eb-cdf0-41cf-9d52-a44e9ae6ddba">
											<gml:posList>35.67045300630458 139.74373427592414 31.8 35.67045300630458 139.74373427592414 29.374 35.67046641547835 139.74366935304707 29.374 35.67046641547835 139.74366935304707 31.8 35.67045300630458 139.74373427592414 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59a44fd2-aad8-484f-8cb1-6091334afdff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59a44fd2-aad8-484f-8cb1-6091334afdff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59a44fd2-aad8-484f-8cb1-6091334afdff">
											<gml:posList>35.67052197878532 139.74375771637514 36.872 35.670540001057084 139.743690181366 36.872 35.670540001057084 139.743690181366 31.8 35.670539470727626 139.74369217028965 31.8 35.670539470727626 139.74369217028965 29.374 35.67052243719506 139.74375598159713 29.374 35.67052243719506 139.74375598159713 31.8 35.67052197878532 139.74375771637514 31.8 35.67052197878532 139.74375771637514 36.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9bd0c705-de3e-4dde-8c07-077622d83181">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bd0c705-de3e-4dde-8c07-077622d83181">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bd0c705-de3e-4dde-8c07-077622d83181">
											<gml:posList>35.670524663535424 139.74375591283209 36.872 35.670524663535424 139.74375591283209 36.229 35.670541391456574 139.7436932506778 36.229 35.670541391456574 139.7436932506778 36.872 35.670524663535424 139.74375591283209 36.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9bb38a36-e0f6-4188-a51d-463b63c56ae9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bb38a36-e0f6-4188-a51d-463b63c56ae9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bb38a36-e0f6-4188-a51d-463b63c56ae9">
											<gml:posList>35.670569385571554 139.74370195699174 36.872 35.670569385571554 139.74370195699174 36.229 35.67055621888833 139.7437657198161 36.229 35.67055621888833 139.7437657198161 36.872 35.670569385571554 139.74370195699174 36.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9218f8b9-2561-4037-9ce5-a00cae067798">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9218f8b9-2561-4037-9ce5-a00cae067798">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9218f8b9-2561-4037-9ce5-a00cae067798">
											<gml:posList>35.670557726488944 139.74376882213778 7.377 35.67057191704638 139.74370009838566 7.377 35.67057191704638 139.74370009838566 36.872 35.670557726488944 139.74376882213778 36.872 35.670557726488944 139.74376882213778 7.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f929a0c9-d29c-4d46-81b9-b3580474ab37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f929a0c9-d29c-4d46-81b9-b3580474ab37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f929a0c9-d29c-4d46-81b9-b3580474ab37">
											<gml:posList>35.67052092243758 139.74375537574414 31.8 35.67052092243758 139.74375537574414 29.374 35.67045300630458 139.74373427592414 29.374 35.67045300630458 139.74373427592414 31.8 35.67052092243758 139.74375537574414 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-741d46a5-3247-41f8-b7e4-e9916e7007f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-741d46a5-3247-41f8-b7e4-e9916e7007f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-741d46a5-3247-41f8-b7e4-e9916e7007f9">
											<gml:posList>35.670557726488944 139.74376882213778 7.377 35.670557726488944 139.74376882213778 36.872 35.67052197878532 139.74375771637514 36.872 35.67052197878532 139.74375771637514 31.8 35.67045106940614 139.74373569201117 31.8 35.67045106940614 139.74373569201117 7.377 35.670557726488944 139.74376882213778 7.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51bbb1d5-7acb-4845-88c9-078b99c52019">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51bbb1d5-7acb-4845-88c9-078b99c52019">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51bbb1d5-7acb-4845-88c9-078b99c52019">
											<gml:posList>35.67052243719506 139.74375598159713 31.8 35.67052243719506 139.74375598159713 29.374 35.67052092243758 139.74375537574414 29.374 35.67052092243758 139.74375537574414 31.8 35.67052243719506 139.74375598159713 31.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b1f7114-46ab-4d70-8f25-cf098c260303">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b1f7114-46ab-4d70-8f25-cf098c260303">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b1f7114-46ab-4d70-8f25-cf098c260303">
											<gml:posList>35.67055621888833 139.7437657198161 36.872 35.67055621888833 139.7437657198161 36.229 35.670524663535424 139.74375591283209 36.229 35.670524663535424 139.74375591283209 36.872 35.67055621888833 139.7437657198161 36.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8479</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">78.3384</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.47</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>