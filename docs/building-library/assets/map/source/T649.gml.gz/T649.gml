<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_bd22d17a-8a2c-4b3e-a254-7e84414793b7">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">16</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670455376526085 139.7407314331517 0 35.67044945497098 139.74065002898828 0 35.67033044125833 139.7404908796027 0 35.67021417385687 139.74050349648255 0 35.67023257581446 139.74075577127837 0 35.670455376526085 139.7407314331517 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670455376526085 139.7407314331517 10.23 35.67023257581446 139.74075577127837 10.23 35.67021417385687 139.74050349648255 10.23 35.67033044125833 139.7404908796027 10.23 35.67044945497098 139.74065002898828 10.23 35.670455376526085 139.7407314331517 10.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670455376526085 139.7407314331517 10.23 35.67044945497098 139.74065002898828 10.23 35.67044945497098 139.74065002898828 26.26 35.670455376526085 139.7407314331517 26.26 35.670455376526085 139.7407314331517 10.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67044945497098 139.74065002898828 10.23 35.67033044125833 139.7404908796027 10.23 35.67033044125833 139.7404908796027 26.26 35.67044945497098 139.74065002898828 26.26 35.67044945497098 139.74065002898828 10.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033044125833 139.7404908796027 10.23 35.67021417385687 139.74050349648255 10.23 35.67021417385687 139.74050349648255 26.26 35.67033044125833 139.7404908796027 26.26 35.67033044125833 139.7404908796027 10.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021417385687 139.74050349648255 10.23 35.67023257581446 139.74075577127837 10.23 35.67023257581446 139.74075577127837 26.26 35.67021417385687 139.74050349648255 26.26 35.67021417385687 139.74050349648255 10.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67023257581446 139.74075577127837 10.23 35.670455376526085 139.7407314331517 10.23 35.670455376526085 139.7407314331517 26.26 35.67023257581446 139.74075577127837 26.26 35.67023257581446 139.74075577127837 10.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670455376526085 139.7407314331517 26.26 35.67044945497098 139.74065002898828 26.26 35.67033044125833 139.7404908796027 26.26 35.67021417385687 139.74050349648255 26.26 35.67023257581446 139.74075577127837 26.26 35.670455376526085 139.7407314331517 26.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d6820081-cd8f-484c-b78b-fff69a6801ca"/>
							<gml:surfaceMember xlink:href="#poly-a0a1d571-3c03-4206-837b-f7fe785f2dd5"/>
							<gml:surfaceMember xlink:href="#poly-68530d62-b340-4319-9e4a-93e0b3138d37"/>
							<gml:surfaceMember xlink:href="#poly-af1a0230-6243-4bf7-bbfd-8ce28b7af0c1"/>
							<gml:surfaceMember xlink:href="#poly-4911f2c1-3504-4416-bca9-b6905c64c556"/>
							<gml:surfaceMember xlink:href="#poly-3fd96949-e26b-4435-8103-9af8ac3d1d42"/>
							<gml:surfaceMember xlink:href="#poly-bbf23b1d-5d2f-4b64-ae16-73ecac219cdb"/>
							<gml:surfaceMember xlink:href="#poly-2fea219c-e380-45a7-b39d-33d4cf1bd4a9"/>
							<gml:surfaceMember xlink:href="#poly-17ca475a-2abe-4253-8930-ddb506c2c22a"/>
							<gml:surfaceMember xlink:href="#poly-75fa8734-9fc0-41ff-9a6b-b00b71928d52"/>
							<gml:surfaceMember xlink:href="#poly-b916f340-3fb9-4cfc-bf3b-f30ed2c3decf"/>
							<gml:surfaceMember xlink:href="#poly-a841335a-fb72-48a5-b8db-8c0b18c04996"/>
							<gml:surfaceMember xlink:href="#poly-d0b473fe-9555-4592-948c-48378d57a7ad"/>
							<gml:surfaceMember xlink:href="#poly-b753e5a5-8e4c-4ae7-9709-f8e261add5fe"/>
							<gml:surfaceMember xlink:href="#poly-5255eb00-dca5-4f6f-b1ea-fa36d2624347"/>
							<gml:surfaceMember xlink:href="#poly-3a42b635-197b-4eeb-be68-ef3a1c2334a4"/>
							<gml:surfaceMember xlink:href="#poly-7bef4bad-be8a-41c9-8226-01efc534d578"/>
							<gml:surfaceMember xlink:href="#poly-9e71e030-8562-4364-8611-2dc7e44073d3"/>
							<gml:surfaceMember xlink:href="#poly-9aa81f86-9bce-4af9-8e11-cf417e63e31c"/>
							<gml:surfaceMember xlink:href="#poly-53d86485-7ad2-4d74-861c-080ac6321a73"/>
							<gml:surfaceMember xlink:href="#poly-d105cd03-1900-4b92-9ffe-c1fcd23fa5b2"/>
							<gml:surfaceMember xlink:href="#poly-0d7c71aa-40d5-4782-aad2-03a98ad7dc76"/>
							<gml:surfaceMember xlink:href="#poly-4b73cd5c-a684-469a-93e5-25d55ae42621"/>
							<gml:surfaceMember xlink:href="#poly-a7512469-f58b-4bdd-851e-19fe6b0181bf"/>
							<gml:surfaceMember xlink:href="#poly-0f497086-bb03-40b3-838b-0c7f08ad4d0c"/>
							<gml:surfaceMember xlink:href="#poly-2a5a8642-cda4-42ff-b3e7-f328bf8e6445"/>
							<gml:surfaceMember xlink:href="#poly-3cd6831d-54e8-46d0-a33c-1cf9863d15ec"/>
							<gml:surfaceMember xlink:href="#poly-e76aec9e-50fa-41c1-b800-d75fb77d7273"/>
							<gml:surfaceMember xlink:href="#poly-49815842-98ab-4922-9282-503acbeb52b2"/>
							<gml:surfaceMember xlink:href="#poly-1719d2a3-4332-4342-8638-4e2336942f40"/>
							<gml:surfaceMember xlink:href="#poly-9407a56e-11ee-40df-a6c4-08e459025b5c"/>
							<gml:surfaceMember xlink:href="#poly-b8ca452c-b9cb-4e01-a57c-bd0bb355179d"/>
							<gml:surfaceMember xlink:href="#poly-b110a828-631d-456b-b5d8-d96f6253b17c"/>
							<gml:surfaceMember xlink:href="#poly-b2b3eb8c-5370-4c81-960a-c79a8119b40e"/>
							<gml:surfaceMember xlink:href="#poly-3a836082-f2bd-45c9-a31f-a2bdc2246120"/>
							<gml:surfaceMember xlink:href="#poly-047fa5f8-6196-47df-b515-065c50e03f96"/>
							<gml:surfaceMember xlink:href="#poly-eb7fcac7-84f1-4ec4-8080-3f4443899d58"/>
							<gml:surfaceMember xlink:href="#poly-d02aa5af-81f1-4408-a741-59c477bc830f"/>
							<gml:surfaceMember xlink:href="#poly-f022afc0-8b90-49a0-954b-a674b0de0264"/>
							<gml:surfaceMember xlink:href="#poly-340d2c3e-18f0-4eef-b319-fee2be6609ad"/>
							<gml:surfaceMember xlink:href="#poly-1920d444-ba1f-4104-85c0-2ea3ee074ed6"/>
							<gml:surfaceMember xlink:href="#poly-d2746612-1fd2-4e99-870b-5fa342b2a525"/>
							<gml:surfaceMember xlink:href="#poly-34a0fb59-0335-422a-a43d-04e9850f0bf4"/>
							<gml:surfaceMember xlink:href="#poly-f29ebb3d-8b32-4a9c-9657-2ac1cab18009"/>
							<gml:surfaceMember xlink:href="#poly-667c8876-fe12-4e5e-ad30-169e032b74b8"/>
							<gml:surfaceMember xlink:href="#poly-d8510c28-8af7-4a8e-be18-3f89d352a307"/>
							<gml:surfaceMember xlink:href="#poly-b01d8daa-7bf2-4a9e-8a31-87aabbf41e92"/>
							<gml:surfaceMember xlink:href="#poly-79c73984-211b-472c-88fe-6e7a6e42a6cb"/>
							<gml:surfaceMember xlink:href="#poly-189d4541-f703-4d79-926c-0c442e573f9f"/>
							<gml:surfaceMember xlink:href="#poly-edec16e5-b15d-4cd8-9983-33d43b616822"/>
							<gml:surfaceMember xlink:href="#poly-266689ed-434f-47d1-ba95-fcb970ca4ff4"/>
							<gml:surfaceMember xlink:href="#poly-176f8b2f-1f76-480e-af3c-d20240d2db76"/>
							<gml:surfaceMember xlink:href="#poly-a1c92ca7-c3ef-4050-8efc-022657792929"/>
							<gml:surfaceMember xlink:href="#poly-2875b71d-aa5d-4f76-b487-4f249191f11d"/>
							<gml:surfaceMember xlink:href="#poly-3d0f9b85-8f86-441c-97f9-738777a72b2d"/>
							<gml:surfaceMember xlink:href="#poly-f91cb83c-442e-4719-b95a-93f18cbf508b"/>
							<gml:surfaceMember xlink:href="#poly-27d24984-af9b-4f29-9dad-e4dc4d1d5513"/>
							<gml:surfaceMember xlink:href="#poly-87b1c090-188c-4b75-bf8f-6facd8a6981f"/>
							<gml:surfaceMember xlink:href="#poly-2b39a01d-cfca-44ff-adb3-9eca692f94ba"/>
							<gml:surfaceMember xlink:href="#poly-aeab1203-6d54-4296-ac70-38868171afb2"/>
							<gml:surfaceMember xlink:href="#poly-54ce455e-cd36-4fc0-b181-c4934eb790a8"/>
							<gml:surfaceMember xlink:href="#poly-cf156fa5-e66d-4e04-9709-5a4820d30b40"/>
							<gml:surfaceMember xlink:href="#poly-e4b39657-bbde-4f86-bdd9-28a9c318c5ba"/>
							<gml:surfaceMember xlink:href="#poly-7d03363f-530e-4e90-a5c9-66c403c58037"/>
							<gml:surfaceMember xlink:href="#poly-4882f912-7ea4-48af-b87a-d33f2bd4fc1c"/>
							<gml:surfaceMember xlink:href="#poly-0f24514a-98ba-40fc-977f-a2f3f5f213b3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bd22d17a-8a2c-4b3e-a254-7e84414793b7_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5475962-e7be-42fc-9192-8a9db9d53ebf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67030029883223 139.7407360418058 25.056 35.670243048437925 139.74074231591135 25.056 35.67023802887178 139.74067341526364 25.056 35.67023987653197 139.74067321429604 25.056 35.67024478672742 139.74074054650544 25.056 35.670298305746144 139.74073467437282 25.056 35.67029506263619 139.74069018383244 25.056 35.670296937337575 139.74068998283383 25.056 35.67030029883223 139.7407360418058 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-405cc81e-37af-4887-a61e-dbf23f8fea6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-405cc81e-37af-4887-a61e-dbf23f8fea6e_0">
											<gml:posList>35.67023802887178 139.74067341526364 25.056 35.67023802887178 139.74067341526364 26.803 35.67023987653197 139.74067321429604 26.803 35.67023987653197 139.74067321429604 25.056 35.67023802887178 139.74067341526364 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b1ee966-d3da-4e18-86f9-c657137849d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b1ee966-d3da-4e18-86f9-c657137849d2_0">
											<gml:posList>35.67029506263619 139.74069018383244 25.056 35.67029506263619 139.74069018383244 26.803 35.670296937337575 139.74068998283383 26.803 35.670296937337575 139.74068998283383 25.056 35.67029506263619 139.74069018383244 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19e2db53-41d7-4e55-8e8e-b0689037006f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19e2db53-41d7-4e55-8e8e-b0689037006f_0">
											<gml:posList>35.67023987653197 139.74067321429604 25.056 35.67023987653197 139.74067321429604 26.803 35.67024478672742 139.74074054650544 26.803 35.67024478672742 139.74074054650544 25.056 35.67023987653197 139.74067321429604 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7977efa-bc6b-4d5a-aaac-f802b850c82b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7977efa-bc6b-4d5a-aaac-f802b850c82b_0">
											<gml:posList>35.67029506263619 139.74069018383244 26.803 35.670298305746144 139.74073467437282 26.803 35.67024478672742 139.74074054650544 26.803 35.67023987653197 139.74067321429604 26.803 35.67023802887178 139.74067341526364 26.803 35.670243048437925 139.74074231591135 26.803 35.67030029883223 139.7407360418058 26.803 35.670296937337575 139.74068998283383 26.803 35.67029506263619 139.74069018383244 26.803</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7687ab9-6323-4ab4-830d-ae5de46c9dfa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7687ab9-6323-4ab4-830d-ae5de46c9dfa_0">
											<gml:posList>35.670243048437925 139.74074231591135 25.056 35.670243048437925 139.74074231591135 26.803 35.67023802887178 139.74067341526364 26.803 35.67023802887178 139.74067341526364 25.056 35.670243048437925 139.74074231591135 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be3ec081-b4ea-40c3-babc-077f65bec7f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be3ec081-b4ea-40c3-babc-077f65bec7f4_0">
											<gml:posList>35.670298305746144 139.74073467437282 25.056 35.670298305746144 139.74073467437282 26.803 35.67029506263619 139.74069018383244 26.803 35.67029506263619 139.74069018383244 25.056 35.670298305746144 139.74073467437282 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2d23a60-f77c-4e41-8dc3-ed568066079c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2d23a60-f77c-4e41-8dc3-ed568066079c_0">
											<gml:posList>35.670296937337575 139.74068998283383 25.056 35.670296937337575 139.74068998283383 26.803 35.67030029883223 139.7407360418058 26.803 35.67030029883223 139.7407360418058 25.056 35.670296937337575 139.74068998283383 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-605d3c01-f846-4076-b6b3-b568f5ddedb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-605d3c01-f846-4076-b6b3-b568f5ddedb3_0">
											<gml:posList>35.67024478672742 139.74074054650544 25.056 35.67024478672742 139.74074054650544 26.803 35.670298305746144 139.74073467437282 26.803 35.670298305746144 139.74073467437282 25.056 35.67024478672742 139.74074054650544 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f63d755d-62c7-4b8e-a7fa-5aa6fff55a2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f63d755d-62c7-4b8e-a7fa-5aa6fff55a2b_0">
											<gml:posList>35.67030029883223 139.7407360418058 25.056 35.67030029883223 139.7407360418058 26.803 35.670243048437925 139.74074231591135 26.803 35.670243048437925 139.74074231591135 25.056 35.67030029883223 139.7407360418058 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bd22d17a-8a2c-4b3e-a254-7e84414793b7_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ed379d3-aae4-4863-a6c3-c70d9dc0dc1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ed379d3-aae4-4863-a6c3-c70d9dc0dc1f_0">
											<gml:posList>35.67025978823092 139.7405332353873 25.056 35.67024838682491 139.74053448576262 25.056 35.67024838682491 139.74053448576262 27.572 35.67025978823092 139.7405332353873 27.572 35.67025978823092 139.7405332353873 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-882d2fe0-e4f6-4495-94a3-cc1cd0116b89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-882d2fe0-e4f6-4495-94a3-cc1cd0116b89_0">
											<gml:posList>35.670259501529046 139.74055888509497 25.056 35.670259501529046 139.74055888509497 27.572 35.67025308429451 139.74055958843363 27.572 35.67025308429451 139.74055958843363 25.056 35.670259501529046 139.74055888509497 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3db24f99-018a-4b36-99a2-dd1a5028d0d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3db24f99-018a-4b36-99a2-dd1a5028d0d1_0">
											<gml:posList>35.670277653652 139.74055689785934 25.056 35.67028360220696 139.74055623924752 25.056 35.67028360220696 139.74055623924752 27.572 35.670277653652 139.74055689785934 27.572 35.670277653652 139.74055689785934 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-849493a4-63c1-4955-9aea-4e9059a86dba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-849493a4-63c1-4955-9aea-4e9059a86dba_0">
											<gml:posList>35.670333551890295 139.74057391068473 25.056 35.670333551890295 139.74057391068473 28.068 35.670238852608904 139.74058428220124 28.068 35.670238852608904 139.74058428220124 25.056 35.670333551890295 139.74057391068473 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a685c315-78eb-4e08-9ff8-f8f8237d911b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a685c315-78eb-4e08-9ff8-f8f8237d911b_0">
											<gml:posList>35.67030138958476 139.7405488066322 25.056 35.67031269184838 139.74054756741904 25.056 35.67031269184838 139.74054756741904 26.584 35.67030138958476 139.7405488066322 26.584 35.67030138958476 139.7405488066322 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ee66256-c7c7-4ceb-8a76-d403eceaab2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ee66256-c7c7-4ceb-8a76-d403eceaab2b_0">
											<gml:posList>35.670324765728346 139.74058850190204 27.798 35.670316428732406 139.74058941733833 27.798 35.670316428732406 139.74058941733833 29.499 35.670324765728346 139.74058850190204 29.499 35.670324765728346 139.74058850190204 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36617b60-4323-4658-9f4b-921996dd6521">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36617b60-4323-4658-9f4b-921996dd6521_0">
											<gml:posList>35.67032251646317 139.7406641602805 25.056 35.67032251646317 139.7406641602805 28.068 35.67033999260952 139.7406622401259 28.068 35.67033999260952 139.7406622401259 25.056 35.67032251646317 139.7406641602805 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66f768d0-4d6b-4a63-adb4-68b6117c0a6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66f768d0-4d6b-4a63-adb4-68b6117c0a6f_0">
											<gml:posList>35.670333551890295 139.74057391068473 28.068 35.670333551890295 139.74057391068473 25.056 35.67033999260952 139.7406622401259 25.056 35.67033999260952 139.7406622401259 28.068 35.670333551890295 139.74057391068473 28.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11c42f0e-949c-4f6a-8ab8-4a7959c77748">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11c42f0e-949c-4f6a-8ab8-4a7959c77748_0">
											<gml:posList>35.67033539073459 139.74055056782413 25.056 35.67033922124333 139.74055014363378 25.056 35.67033922124333 139.74055014363378 26.584 35.67033539073459 139.74055056782413 26.584 35.67033539073459 139.74055056782413 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3168b6e-9398-4835-ab0f-418d823c6707">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3168b6e-9398-4835-ab0f-418d823c6707_0">
											<gml:posList>35.67034077147598 139.74054997614599 25.056 35.670353425687296 139.74054859176653 25.056 35.670353425687296 139.74054859176653 27.131 35.67034077147598 139.74054997614599 27.131 35.67034077147598 139.74054997614599 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a2a728d-6e91-4475-bd74-20b851847209">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a2a728d-6e91-4475-bd74-20b851847209_0">
											<gml:posList>35.67035492859438 139.7405688930458 25.056 35.67035492859438 139.7405688930458 27.131 35.670353425687296 139.74054859176653 27.131 35.670353425687296 139.74054859176653 25.056 35.67035492859438 139.7405688930458 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb5c0c79-bb00-4723-8248-47ad990e3479">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb5c0c79-bb00-4723-8248-47ad990e3479_0">
											<gml:posList>35.670252861167 139.74066781977012 25.509 35.670252861167 139.74066781977012 29.84 35.67033583457984 139.7406587322233 29.84 35.67033583457984 139.7406587322233 25.056 35.670252861167 139.74066781977012 25.056 35.670252861167 139.74066781977012 25.509</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-569c15d3-a80d-41df-b6bc-bf3ec57644d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-569c15d3-a80d-41df-b6bc-bf3ec57644d4_0">
											<gml:posList>35.670362171213156 139.74066851085786 28.272 35.67036141506605 139.7406581061578 28.272 35.67036141506605 139.7406581061578 25.056 35.670362171213156 139.74066851085786 25.056 35.670362171213156 139.74066851085786 28.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4814459-6258-4bdb-a5a0-c6163ba4dfea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4814459-6258-4bdb-a5a0-c6163ba4dfea_0">
											<gml:posList>35.67043052771591 139.74066379242316 28.272 35.67041123975203 139.74066563734982 28.272 35.67041123975203 139.74066563734982 25.056 35.67043052771591 139.74066379242316 25.056 35.67043052771591 139.74066379242316 28.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f551db52-c9ea-4080-b288-ad6eaf7a809d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f551db52-c9ea-4080-b288-ad6eaf7a809d_0">
											<gml:posList>35.67033999260952 139.7406622401259 25.056 35.67033999260952 139.7406622401259 29.84 35.67025315263234 139.7406717518954 29.84 35.67025315263234 139.7406717518954 25.056 35.67033999260952 139.7406622401259 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01e97a96-827e-4690-9c32-b0cc0c1704d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01e97a96-827e-4690-9c32-b0cc0c1704d1_0">
											<gml:posList>35.67040564730975 139.74068395851748 28.272 35.670412398273584 139.74068354200463 28.272 35.67041123975203 139.74066563734982 28.272 35.67043052771591 139.74066379242316 28.272 35.67042974308183 139.74065150988193 28.272 35.67036141506605 139.7406581061578 28.272 35.670362171213156 139.74066851085786 28.272 35.670362271775204 139.7406703444203 28.272 35.67040312799666 139.74066641996365 28.272 35.67040564730975 139.74068395851748 28.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cc4ba6a-6253-4eae-b0f4-518d713b5320">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0cc4ba6a-6253-4eae-b0f4-518d713b5320_0">
											<gml:posList>35.67040312799666 139.74066641996365 28.272 35.670362271775204 139.7406703444203 28.272 35.670362271775204 139.7406703444203 25.056 35.67040312799666 139.74066641996365 25.056 35.67040312799666 139.74066641996365 28.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52c9e594-3575-445c-9c83-bc36802e7245">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52c9e594-3575-445c-9c83-bc36802e7245_0">
											<gml:posList>35.67032314504911 139.74067278667647 25.056 35.67032314504911 139.74067278667647 28.068 35.67032251646317 139.7406641602805 28.068 35.67032251646317 139.7406641602805 25.056 35.67032314504911 139.74067278667647 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cc0084c-9dc9-45d4-8f14-7079667f927b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4cc0084c-9dc9-45d4-8f14-7079667f927b_0">
											<gml:posList>35.670362271775204 139.7406703444203 28.272 35.670362171213156 139.74066851085786 28.272 35.670362171213156 139.74066851085786 25.056 35.670362271775204 139.7406703444203 25.056 35.670362271775204 139.7406703444203 28.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dde2a275-7934-4b12-9700-550c8bbec3b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dde2a275-7934-4b12-9700-550c8bbec3b3_0">
											<gml:posList>35.670362171213156 139.74066851085786 25.056 35.670362171213156 139.74066851085786 28.068 35.67032314504911 139.74067278667647 28.068 35.67032314504911 139.74067278667647 25.056 35.670362171213156 139.74066851085786 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57a87295-7150-4758-b15a-4b54edd87084">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57a87295-7150-4758-b15a-4b54edd87084_0">
											<gml:posList>35.67043078515815 139.74067036465414 25.056 35.67042491753921 139.74067078014733 25.056 35.67042491753921 139.74067078014733 28.011 35.67043078515815 139.74067036465414 28.011 35.67043078515815 139.74067036465414 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4452a927-7171-4fb7-95e0-b2c51663036f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4452a927-7171-4fb7-95e0-b2c51663036f_0">
											<gml:posList>35.67041123975203 139.74066563734982 28.272 35.670412398273584 139.74068354200463 28.272 35.670412398273584 139.74068354200463 25.056 35.67041123975203 139.74066563734982 25.056 35.67041123975203 139.74066563734982 28.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-210f3ea5-7e71-4b7c-b8f7-1327ad0ac3d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-210f3ea5-7e71-4b7c-b8f7-1327ad0ac3d0_0">
											<gml:posList>35.67040564730975 139.74068395851748 28.272 35.67040312799666 139.74066641996365 28.272 35.67040312799666 139.74066641996365 25.056 35.67040564730975 139.74068395851748 25.056 35.67040564730975 139.74068395851748 28.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f2bc4fa-15d4-4c89-b33e-c32d5cd0faaa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f2bc4fa-15d4-4c89-b33e-c32d5cd0faaa_0">
											<gml:posList>35.67043134430274 139.74068245966976 25.056 35.67043078515815 139.74067036465414 25.056 35.67043078515815 139.74067036465414 28.011 35.67043134430274 139.74068245966976 28.011 35.67043134430274 139.74068245966976 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf67d981-d7ed-4b8e-b5ef-17103857a635">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf67d981-d7ed-4b8e-b5ef-17103857a635_0">
											<gml:posList>35.67044239454027 139.74068168470788 25.056 35.67043134430274 139.74068245966976 25.056 35.67043134430274 139.74068245966976 28.011 35.67044239454027 139.74068168470788 28.011 35.67044239454027 139.74068168470788 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd8d4026-acb7-46e6-a344-a4bb013802e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd8d4026-acb7-46e6-a344-a4bb013802e5_0">
											<gml:posList>35.670412398273584 139.74068354200463 28.272 35.67040564730975 139.74068395851748 28.272 35.67040564730975 139.74068395851748 25.056 35.670412398273584 139.74068354200463 25.056 35.670412398273584 139.74068354200463 28.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54774fb2-32f8-4620-93e7-2cfcf283f213">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54774fb2-32f8-4620-93e7-2cfcf283f213_0">
											<gml:posList>35.67040185271947 139.74068420592013 25.056 35.67040185271947 139.74068420592013 27.858 35.67041571516205 139.74068332829273 27.858 35.67041571516205 139.74068332829273 25.056 35.67040185271947 139.74068420592013 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1c972a4-d304-4d3d-82b3-7162e95368fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1c972a4-d304-4d3d-82b3-7162e95368fc_0">
											<gml:posList>35.67044271533257 139.74068858825473 25.056 35.67044239454027 139.74068168470788 25.056 35.67044239454027 139.74068168470788 28.011 35.67044271533257 139.74068858825473 28.011 35.67044271533257 139.74068858825473 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86ff5b60-e366-420a-a099-f19f4a7fa0a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86ff5b60-e366-420a-a099-f19f4a7fa0a1_0">
											<gml:posList>35.6704313496317 139.7406893856727 28.011 35.67044271533257 139.74068858825473 28.011 35.67044239454027 139.74068168470788 28.011 35.67043134430274 139.74068245966976 28.011 35.67043078515815 139.74067036465414 28.011 35.67042491753921 139.74067078014733 28.011 35.67042663143196 139.74070759537065 28.011 35.67043218359623 139.74070721338342 28.011 35.6704313496317 139.7406893856727 28.011</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-589cf270-d3cb-4044-835c-17ecd58e929c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-589cf270-d3cb-4044-835c-17ecd58e929c_0">
											<gml:posList>35.6704313496317 139.7406893856727 25.056 35.67044271533257 139.74068858825473 25.056 35.67044271533257 139.74068858825473 28.011 35.6704313496317 139.7406893856727 28.011 35.6704313496317 139.7406893856727 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c4a915a-9b04-4450-bf00-b23aec3abc88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c4a915a-9b04-4450-bf00-b23aec3abc88_0">
											<gml:posList>35.67042491753921 139.74067078014733 25.056 35.67042663143196 139.74070759537065 25.056 35.67042663143196 139.74070759537065 28.011 35.67042491753921 139.74067078014733 28.011 35.67042491753921 139.74067078014733 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f14390a9-a1ac-4ab0-a5c2-4ab7686e535d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f14390a9-a1ac-4ab0-a5c2-4ab7686e535d_0">
											<gml:posList>35.67041649565699 139.7407019513927 25.056 35.67041571516205 139.74068332829273 25.056 35.67041571516205 139.74068332829273 27.858 35.67041649565699 139.7407019513927 27.858 35.67041649565699 139.7407019513927 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4380ccac-4a88-4496-a10e-1c6101c9f379">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4380ccac-4a88-4496-a10e-1c6101c9f379_0">
											<gml:posList>35.67041571516205 139.74068332829273 27.858 35.67040185271947 139.74068420592013 27.858 35.67040263320576 139.74070281797063 27.858 35.67041649565699 139.7407019513927 27.858 35.67041571516205 139.74068332829273 27.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec244046-2f32-4936-96e1-23897ff36b58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec244046-2f32-4936-96e1-23897ff36b58_0">
											<gml:posList>35.67040185271947 139.74068420592013 25.056 35.67040263320576 139.74070281797063 25.056 35.67040263320576 139.74070281797063 27.858 35.67040185271947 139.74068420592013 27.858 35.67040185271947 139.74068420592013 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be89f47b-2dfd-4e6d-a1de-f84b94a2095d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be89f47b-2dfd-4e6d-a1de-f84b94a2095d_0">
											<gml:posList>35.67043218359623 139.74070721338342 25.056 35.6704313496317 139.7406893856727 25.056 35.6704313496317 139.7406893856727 28.011 35.67043218359623 139.74070721338342 28.011 35.67043218359623 139.74070721338342 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03b63290-26da-4a76-be40-dad62cbbb2ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03b63290-26da-4a76-be40-dad62cbbb2ea_0">
											<gml:posList>35.670316415298736 139.74070077460695 25.056 35.67030670830101 139.74070180207676 25.056 35.67030670830101 139.74070180207676 26.918 35.670316415298736 139.74070077460695 26.918 35.670316415298736 139.74070077460695 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a619f18-273b-427f-932e-ccd397cead12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a619f18-273b-427f-932e-ccd397cead12_0">
											<gml:posList>35.67040263320576 139.74070281797063 25.056 35.67041649565699 139.7407019513927 25.056 35.67041649565699 139.7407019513927 27.858 35.67040263320576 139.74070281797063 27.858 35.67040263320576 139.74070281797063 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbed577b-47dd-4eec-8668-c73de5a67d2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbed577b-47dd-4eec-8668-c73de5a67d2f_0">
											<gml:posList>35.67042663143196 139.74070759537065 25.056 35.67043218359623 139.74070721338342 25.056 35.67043218359623 139.74070721338342 28.011 35.67042663143196 139.74070759537065 28.011 35.67042663143196 139.74070759537065 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdfb5997-f50c-4ecb-9705-c838414eca65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdfb5997-f50c-4ecb-9705-c838414eca65_0">
											<gml:posList>35.670316415298736 139.74070077460695 25.056 35.670316415298736 139.74070077460695 26.918 35.670318602339485 139.74073164635166 26.918 35.670318602339485 139.74073164635166 25.056 35.670316415298736 139.74070077460695 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50cb2bd6-67b5-4f63-8812-1a86a75495e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50cb2bd6-67b5-4f63-8812-1a86a75495e1_0">
											<gml:posList>35.67030670830101 139.74070180207676 26.918 35.670308895349976 139.740732684864 26.918 35.670318602339485 139.74073164635166 26.918 35.670316415298736 139.74070077460695 26.918 35.67030670830101 139.74070180207676 26.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5b246cb-2a1d-4e95-944c-8c1cc7ac7a7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5b246cb-2a1d-4e95-944c-8c1cc7ac7a7a_0">
											<gml:posList>35.67030670830101 139.74070180207676 25.056 35.670308895349976 139.740732684864 25.056 35.670308895349976 139.740732684864 26.918 35.67030670830101 139.74070180207676 26.918 35.67030670830101 139.74070180207676 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d645c8f-e990-4427-b87c-e4d19c1042cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d645c8f-e990-4427-b87c-e4d19c1042cc_0">
											<gml:posList>35.670308895349976 139.740732684864 25.056 35.670318602339485 139.74073164635166 25.056 35.670318602339485 139.74073164635166 26.918 35.670308895349976 139.740732684864 26.918 35.670308895349976 139.740732684864 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5859b9bd-5cdb-48cd-9b59-d4067096c727">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5859b9bd-5cdb-48cd-9b59-d4067096c727_0">
											<gml:posList>35.67025818286301 139.74050864830926 25.056 35.67025383857215 139.740509073096 25.056 35.67025383857215 139.740509073096 27.627 35.67025818286301 139.74050864830926 27.627 35.67025818286301 139.74050864830926 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2597a61-2868-4a67-8ba9-d4b37190f829">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2597a61-2868-4a67-8ba9-d4b37190f829_0">
											<gml:posList>35.67023562195737 139.74050924883326 25.056 35.67023069181708 139.74050972952926 25.056 35.67023069181708 139.74050972952926 27.627 35.67023562195737 139.74050924883326 27.627 35.67023562195737 139.74050924883326 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5570cb81-7f88-4b4d-b8d9-2bea053a5dfa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5570cb81-7f88-4b4d-b8d9-2bea053a5dfa_0">
											<gml:posList>35.67025383857215 139.740509073096 25.056 35.67025439509347 139.74051774375175 25.056 35.67025439509347 139.74051774375175 27.627 35.67025383857215 139.740509073096 27.627 35.67025383857215 139.740509073096 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-324a8a19-c82a-47db-9301-267195aec0b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-324a8a19-c82a-47db-9301-267195aec0b9_0">
											<gml:posList>35.6702362788557 139.74051951002934 25.056 35.67023562195737 139.74050924883326 25.056 35.67023562195737 139.74050924883326 27.627 35.6702362788557 139.74051951002934 27.627 35.6702362788557 139.74051951002934 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cb513a7-b246-4aa4-a614-c61868fef877">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cb513a7-b246-4aa4-a614-c61868fef877_0">
											<gml:posList>35.67025900387304 139.74052132844542 25.056 35.67025818286301 139.74050864830926 25.056 35.67025818286301 139.74050864830926 27.627 35.67025900387304 139.74052132844542 27.627 35.67025900387304 139.74052132844542 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d227ec8e-bcff-4318-9c6a-c1bc31e1f726">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d227ec8e-bcff-4318-9c6a-c1bc31e1f726_0">
											<gml:posList>35.67025439509347 139.74051774375175 25.056 35.6702362788557 139.74051951002934 25.056 35.6702362788557 139.74051951002934 27.627 35.67025439509347 139.74051774375175 27.627 35.67025439509347 139.74051774375175 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e49ba493-d855-47de-94a9-fb6d6065eff3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e49ba493-d855-47de-94a9-fb6d6065eff3_0">
											<gml:posList>35.670272757792446 139.74051998697487 25.056 35.67025900387304 139.74052132844542 25.056 35.67025900387304 139.74052132844542 27.627 35.670272757792446 139.74051998697487 27.627 35.670272757792446 139.74051998697487 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18180da9-4a1a-483c-bc25-a04ae72a5c15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18180da9-4a1a-483c-bc25-a04ae72a5c15_0">
											<gml:posList>35.67024125341157 139.74052987669046 25.056 35.670283461542844 139.74052576281724 25.056 35.670283461542844 139.74052576281724 27.627 35.67024125341157 139.74052987669046 27.627 35.67024125341157 139.74052987669046 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e72f0968-e380-4ba3-baf6-89cc6d1641ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e72f0968-e380-4ba3-baf6-89cc6d1641ee_0">
											<gml:posList>35.670276756198604 139.74051519932218 27.627 35.6702761997878 139.74050667226507 27.627 35.67027192759824 139.74050708592227 27.627 35.670272757792446 139.74051998697487 27.627 35.67025900387304 139.74052132844542 27.627 35.67025818286301 139.74050864830926 27.627 35.67025383857215 139.740509073096 27.627 35.67025439509347 139.74051774375175 27.627 35.6702362788557 139.74051951002934 27.627 35.67023562195737 139.74050924883326 27.627 35.67023069181708 139.74050972952926 27.627 35.67023339199141 139.7405513928176 27.627 35.67024258530788 139.74055049847982 27.627 35.67024125341157 139.74052987669046 27.627 35.670283461542844 139.74052576281724 27.627 35.6702827408593 139.74051460694298 27.627 35.670276756198604 139.74051519932218 27.627</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e03d578-da66-4bd3-84dd-f1dcb14cab5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e03d578-da66-4bd3-84dd-f1dcb14cab5f_0">
											<gml:posList>35.67023069181708 139.74050972952926 25.056 35.67023339199141 139.7405513928176 25.056 35.67023339199141 139.7405513928176 27.627 35.67023069181708 139.74050972952926 27.627 35.67023069181708 139.74050972952926 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdd6acb9-1f33-46b9-94b9-5cd24ce866db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdd6acb9-1f33-46b9-94b9-5cd24ce866db_0">
											<gml:posList>35.67024258530788 139.74055049847982 25.056 35.67024125341157 139.74052987669046 25.056 35.67024125341157 139.74052987669046 27.627 35.67024258530788 139.74055049847982 27.627 35.67024258530788 139.74055049847982 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8722289-e639-415c-b24f-a66b09adec87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8722289-e639-415c-b24f-a66b09adec87_0">
											<gml:posList>35.6702607994969 139.74054717457548 25.056 35.67025978823092 139.7405332353873 25.056 35.67025978823092 139.7405332353873 27.572 35.6702607994969 139.74054717457548 27.572 35.6702607994969 139.74054717457548 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-279e59fc-bf1b-4295-8902-5623dcbf889d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-279e59fc-bf1b-4295-8902-5623dcbf889d_0">
											<gml:posList>35.67024838682491 139.74053448576262 25.056 35.670249352460345 139.74054769594972 25.056 35.670249352460345 139.74054769594972 27.572 35.67024838682491 139.74053448576262 27.572 35.67024838682491 139.74053448576262 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f861ef40-c024-468a-9178-d4af8072472c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f861ef40-c024-468a-9178-d4af8072472c_0">
											<gml:posList>35.670249352460345 139.74054769594972 27.572 35.67025219154473 139.74054738336943 27.572 35.67025308429451 139.74055958843363 27.572 35.670259501529046 139.74055888509497 27.572 35.67025866342332 139.74054740901857 27.572 35.6702607994969 139.74054717457548 27.572 35.67025978823092 139.7405332353873 27.572 35.67024838682491 139.74053448576262 27.572 35.670249352460345 139.74054769594972 27.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e5850b2-000b-41fb-9030-cdf5bd550d30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e5850b2-000b-41fb-9030-cdf5bd550d30_0">
											<gml:posList>35.67025866342332 139.74054740901857 25.056 35.6702607994969 139.74054717457548 25.056 35.6702607994969 139.74054717457548 27.572 35.67025866342332 139.74054740901857 27.572 35.67025866342332 139.74054740901857 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82c01c0f-d382-492c-bbcb-87e73c7df5a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82c01c0f-d382-492c-bbcb-87e73c7df5a8_0">
											<gml:posList>35.670249352460345 139.74054769594972 25.056 35.67025219154473 139.74054738336943 25.056 35.67025219154473 139.74054738336943 27.572 35.670249352460345 139.74054769594972 27.572 35.670249352460345 139.74054769594972 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ce63e76-9b15-4f1f-bba4-2696c73ef990">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ce63e76-9b15-4f1f-bba4-2696c73ef990_0">
											<gml:posList>35.67023339199141 139.7405513928176 25.056 35.67024258530788 139.74055049847982 25.056 35.67024258530788 139.74055049847982 27.627 35.67023339199141 139.7405513928176 27.627 35.67023339199141 139.7405513928176 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abfabb11-43fc-497c-8760-1b29775c3af8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abfabb11-43fc-497c-8760-1b29775c3af8_0">
											<gml:posList>35.670259501529046 139.74055888509497 25.056 35.67025866342332 139.74054740901857 25.056 35.67025866342332 139.74054740901857 27.572 35.670259501529046 139.74055888509497 27.572 35.670259501529046 139.74055888509497 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e213ce0b-1773-44e6-adb6-30202cfc8304">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e213ce0b-1773-44e6-adb6-30202cfc8304_0">
											<gml:posList>35.67025219154473 139.74054738336943 25.056 35.67025308429451 139.74055958843363 25.056 35.67025308429451 139.74055958843363 27.572 35.67025219154473 139.74054738336943 27.572 35.67025219154473 139.74054738336943 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76c629a8-4685-45f9-b3b0-780f7746a46e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76c629a8-4685-45f9-b3b0-780f7746a46e_0">
											<gml:posList>35.670238852608904 139.74058428220124 25.056 35.670238852608904 139.74058428220124 28.068 35.67023717640121 139.74056133005405 28.068 35.67023717640121 139.74056133005405 25.056 35.670238852608904 139.74058428220124 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a02feba-cbf2-4c06-b87a-1b4403fae985">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a02feba-cbf2-4c06-b87a-1b4403fae985_0">
											<gml:posList>35.67023277787014 139.74058495200276 29.84 35.670233087518774 139.74058908293802 29.416 35.670233087518774 139.74058908293802 29.84 35.67023277787014 139.74058495200276 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9fcb388-14d2-41d8-b0e8-527ada0d36b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9fcb388-14d2-41d8-b0e8-527ada0d36b4_0">
											<gml:posList>35.670233087518774 139.74058908293802 29.416 35.67023277787014 139.74058495200276 29.84 35.67023277787014 139.74058495200276 25.056 35.670233087518774 139.74058908293802 25.056 35.670233087518774 139.74058908293802 29.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fee88817-0f14-4053-be6b-6d3303b4e7f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fee88817-0f14-4053-be6b-6d3303b4e7f0_0">
											<gml:posList>35.670252861167 139.74066781977012 25.509 35.67025315263234 139.7406717518954 25.056 35.67025315263234 139.7406717518954 29.84 35.670252861167 139.74066781977012 29.84 35.670252861167 139.74066781977012 25.509</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92b1f817-ff00-480d-83b5-a3e6808fc45b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92b1f817-ff00-480d-83b5-a3e6808fc45b_0">
											<gml:posList>35.67025315263234 139.7406717518954 25.056 35.670252861167 139.74066781977012 25.509 35.670252861167 139.74066781977012 25.056 35.67025315263234 139.7406717518954 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c34d20e-1bd1-4a5a-81d5-bbe2dd7a1684">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c34d20e-1bd1-4a5a-81d5-bbe2dd7a1684_0">
											<gml:posList>35.6702761997878 139.74050667226507 25.056 35.67027192759824 139.74050708592227 25.056 35.67027192759824 139.74050708592227 27.627 35.6702761997878 139.74050667226507 27.627 35.6702761997878 139.74050667226507 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-747d8832-863f-4097-a8f5-949bc0fbc6e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-747d8832-863f-4097-a8f5-949bc0fbc6e4_0">
											<gml:posList>35.670276756198604 139.74051519932218 25.056 35.6702761997878 139.74050667226507 25.056 35.6702761997878 139.74050667226507 27.627 35.670276756198604 139.74051519932218 27.627 35.670276756198604 139.74051519932218 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c887ad28-da12-48e8-b3f6-e9268e4da5d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c887ad28-da12-48e8-b3f6-e9268e4da5d5_0">
											<gml:posList>35.67031142009007 139.74051141451463 25.056 35.67029875686537 139.74051279890963 25.056 35.67029875686537 139.74051279890963 26.584 35.67031142009007 139.74051141451463 26.584 35.67031142009007 139.74051141451463 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fab29f1-10f1-4f3d-9fb3-431000540317">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fab29f1-10f1-4f3d-9fb3-431000540317_0">
											<gml:posList>35.67033044821217 139.74051159131827 25.056 35.67031897469674 139.74051284178128 25.056 35.67031897469674 139.74051284178128 26.584 35.67033044821217 139.74051159131827 26.584 35.67033044821217 139.74051159131827 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afb43fb0-e53e-445c-a761-d13e9f9de59c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afb43fb0-e53e-445c-a761-d13e9f9de59c_0">
											<gml:posList>35.67027192759824 139.74050708592227 25.056 35.670272757792446 139.74051998697487 25.056 35.670272757792446 139.74051998697487 27.627 35.67027192759824 139.74050708592227 27.627 35.67027192759824 139.74050708592227 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-460e8653-1b2e-4d81-9a8a-dd84af0c1974">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-460e8653-1b2e-4d81-9a8a-dd84af0c1974_0">
											<gml:posList>35.6702827408593 139.74051460694298 25.056 35.670276756198604 139.74051519932218 25.056 35.670276756198604 139.74051519932218 27.627 35.6702827408593 139.74051460694298 27.627 35.6702827408593 139.74051460694298 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c925b09-6afb-4863-b46c-cf8faee85438">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c925b09-6afb-4863-b46c-cf8faee85438_0">
											<gml:posList>35.67033146851141 139.74052555260053 25.056 35.67033044821217 139.74051159131827 25.056 35.67033044821217 139.74051159131827 26.584 35.67033146851141 139.74052555260053 26.584 35.67033146851141 139.74052555260053 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7577f1c4-f435-4948-9b11-c186fbf676fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7577f1c4-f435-4948-9b11-c186fbf676fd_0">
											<gml:posList>35.670283461542844 139.74052576281724 25.056 35.6702827408593 139.74051460694298 25.056 35.6702827408593 139.74051460694298 27.627 35.670283461542844 139.74052576281724 27.627 35.670283461542844 139.74052576281724 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-228209eb-9789-4ff3-bade-d4bb928ddfd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-228209eb-9789-4ff3-bade-d4bb928ddfd0_0">
											<gml:posList>35.67031298704443 139.7405329418422 25.056 35.67031142009007 139.74051141451463 25.056 35.67031142009007 139.74051141451463 26.584 35.67031298704443 139.7405329418422 26.584 35.67031298704443 139.7405329418422 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c004b2e-ae39-403a-a6a0-57af0a661365">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c004b2e-ae39-403a-a6a0-57af0a661365_0">
											<gml:posList>35.67031897469674 139.74051284178128 25.056 35.67032037767568 139.7405321269117 25.056 35.67032037767568 139.7405321269117 26.584 35.67031897469674 139.74051284178128 26.584 35.67031897469674 139.74051284178128 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7df05bd8-c7b4-4de3-8fcf-2de792f7a4a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7df05bd8-c7b4-4de3-8fcf-2de792f7a4a6_0">
											<gml:posList>35.67033738101975 139.74052490507393 25.056 35.67033146851141 139.74052555260053 25.056 35.67033146851141 139.74052555260053 26.584 35.67033738101975 139.74052490507393 26.584 35.67033738101975 139.74052490507393 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-adc7a32b-0de8-4af8-8fdf-6e1adb3a852d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-adc7a32b-0de8-4af8-8fdf-6e1adb3a852d_0">
											<gml:posList>35.67030138958476 139.7405488066322 25.056 35.67030138958476 139.7405488066322 26.584 35.67029875686537 139.74051279890963 26.584 35.67029875686537 139.74051279890963 25.056 35.67030138958476 139.7405488066322 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62538a65-de0a-44b7-8cf5-e30347422d57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62538a65-de0a-44b7-8cf5-e30347422d57_0">
											<gml:posList>35.67032037767568 139.7405321269117 26.584 35.67031298704443 139.7405329418422 26.584 35.67031142009007 139.74051141451463 26.584 35.67029875686537 139.74051279890963 26.584 35.67030138958476 139.7405488066322 26.584 35.67031269184838 139.74054756741904 26.584 35.67031194489182 139.74053740573342 26.584 35.67032322912785 139.74053616653939 26.584 35.67032387586957 139.74054494756092 26.584 35.67033488971952 139.7405437418194 26.584 35.67033539073459 139.74055056782413 26.584 35.67033922124333 139.74055014363378 26.584 35.67033738101975 139.74052490507393 26.584 35.67033146851141 139.74052555260053 26.584 35.67033044821217 139.74051159131827 26.584 35.67031897469674 139.74051284178128 26.584 35.67032037767568 139.7405321269117 26.584</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-671358c9-9631-40fc-8913-565540feefc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-671358c9-9631-40fc-8913-565540feefc8_0">
											<gml:posList>35.670286485149894 139.74053096209946 25.056 35.67027087468441 139.7405326702433 25.056 35.67027087468441 139.7405326702433 27.572 35.670286485149894 139.74053096209946 27.572 35.670286485149894 139.74053096209946 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afb2f59f-a8d5-427a-a691-680ab7ef9e6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afb2f59f-a8d5-427a-a691-680ab7ef9e6f_0">
											<gml:posList>35.67032037767568 139.7405321269117 25.056 35.67031298704443 139.7405329418422 25.056 35.67031298704443 139.7405329418422 26.584 35.67032037767568 139.7405321269117 26.584 35.67032037767568 139.7405321269117 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89cf3447-dbd5-4912-a67b-b18177b596de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89cf3447-dbd5-4912-a67b-b18177b596de_0">
											<gml:posList>35.67031194489182 139.74053740573342 25.056 35.67032322912785 139.74053616653939 25.056 35.67032322912785 139.74053616653939 26.584 35.67031194489182 139.74053740573342 26.584 35.67031194489182 139.74053740573342 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c86d0fe-d3f0-4e2b-a98a-723742f3f2d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c86d0fe-d3f0-4e2b-a98a-723742f3f2d8_0">
											<gml:posList>35.67033922124333 139.74055014363378 25.056 35.67033738101975 139.74052490507393 25.056 35.67033738101975 139.74052490507393 26.584 35.67033922124333 139.74055014363378 26.584 35.67033922124333 139.74055014363378 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98d5da33-cf4d-4254-8cd5-1b551bfa4196">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98d5da33-cf4d-4254-8cd5-1b551bfa4196_0">
											<gml:posList>35.670287478175894 139.74054462515724 25.056 35.670286485149894 139.74053096209946 25.056 35.670286485149894 139.74053096209946 27.572 35.670287478175894 139.74054462515724 27.572 35.670287478175894 139.74054462515724 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b123887-4155-44c5-8b73-2db86635010d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b123887-4155-44c5-8b73-2db86635010d_0">
											<gml:posList>35.67027179485138 139.74054536131322 25.056 35.67027179485138 139.74054536131322 27.572 35.67027087468441 139.7405326702433 27.572 35.67027087468441 139.7405326702433 25.056 35.67027179485138 139.74054536131322 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d31ea5e-cfe1-49a5-87fc-048d354a8cf3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d31ea5e-cfe1-49a5-87fc-048d354a8cf3_0">
											<gml:posList>35.67032322912785 139.74053616653939 25.056 35.67032387586957 139.74054494756092 25.056 35.67032387586957 139.74054494756092 26.584 35.67032322912785 139.74053616653939 26.584 35.67032322912785 139.74053616653939 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9530771-2bcb-49eb-baaa-7f8b51f20ec5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9530771-2bcb-49eb-baaa-7f8b51f20ec5_0">
											<gml:posList>35.67034077147598 139.74054997614599 25.056 35.67034077147598 139.74054997614599 27.131 35.670354873380035 139.74053233000242 27.131 35.670354873380035 139.74053233000242 25.056 35.67034077147598 139.74054997614599 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0776465-1116-4a98-86bc-474134747187">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0776465-1116-4a98-86bc-474134747187_0">
											<gml:posList>35.670368009516196 139.7405480888542 25.77 35.670368009516196 139.7405480888542 25.056 35.670354873380035 139.74053233000242 25.056 35.670354873380035 139.74053233000242 27.131 35.67036987709318 139.74055034012957 27.131 35.67036987709318 139.74055034012957 25.77 35.670368009516196 139.7405480888542 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc705440-143b-4877-8440-f5bdfafe2a8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc705440-143b-4877-8440-f5bdfafe2a8f_0">
											<gml:posList>35.67031269184838 139.74054756741904 25.056 35.67031194489182 139.74053740573342 25.056 35.67031194489182 139.74053740573342 26.584 35.67031269184838 139.74054756741904 26.584 35.67031269184838 139.74054756741904 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d893b262-9120-4839-81c8-e03c019afb53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d893b262-9120-4839-81c8-e03c019afb53_0">
											<gml:posList>35.670276770009316 139.74054481428956 27.572 35.670277653652 139.74055689785934 27.572 35.67028360220696 139.74055623924752 27.572 35.67028279143156 139.74054513870846 27.572 35.670287478175894 139.74054462515724 27.572 35.670286485149894 139.74053096209946 27.572 35.67027087468441 139.7405326702433 27.572 35.67027179485138 139.74054536131322 27.572 35.670276770009316 139.74054481428956 27.572</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01d930f7-3f0f-4a0b-b8b3-50258368a71f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01d930f7-3f0f-4a0b-b8b3-50258368a71f_0">
											<gml:posList>35.67033488971952 139.7405437418194 25.056 35.67033488971952 139.7405437418194 26.584 35.67032387586957 139.74054494756092 26.584 35.67032387586957 139.74054494756092 25.056 35.67033488971952 139.7405437418194 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e66b8420-f02d-4d1d-8d76-f7e6e2761925">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e66b8420-f02d-4d1d-8d76-f7e6e2761925_0">
											<gml:posList>35.670287478175894 139.74054462515724 25.056 35.670287478175894 139.74054462515724 27.572 35.67028279143156 139.74054513870846 27.572 35.67028279143156 139.74054513870846 25.056 35.670287478175894 139.74054462515724 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-345f885a-3b44-4a35-a28d-9e85f6377150">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-345f885a-3b44-4a35-a28d-9e85f6377150_0">
											<gml:posList>35.670276770009316 139.74054481428956 25.056 35.670276770009316 139.74054481428956 27.572 35.67027179485138 139.74054536131322 27.572 35.67027179485138 139.74054536131322 25.056 35.670276770009316 139.74054481428956 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a088d12-7e60-4ab7-b874-a19237cb8f3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a088d12-7e60-4ab7-b874-a19237cb8f3b_0">
											<gml:posList>35.67033488971952 139.7405437418194 25.056 35.67033539073459 139.74055056782413 25.056 35.67033539073459 139.74055056782413 26.584 35.67033488971952 139.7405437418194 26.584 35.67033488971952 139.7405437418194 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59ac615e-d268-46ce-8d2d-891e7694dafe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59ac615e-d268-46ce-8d2d-891e7694dafe_0">
											<gml:posList>35.670369778035855 139.74055046175306 25.056 35.670368009516196 139.7405480888542 25.056 35.670368009516196 139.7405480888542 25.77 35.670369778035855 139.74055046175306 25.77 35.670369778035855 139.74055046175306 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53836009-e144-45cd-a3eb-db0e151967db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53836009-e144-45cd-a3eb-db0e151967db_0">
											<gml:posList>35.67028360220696 139.74055623924752 25.056 35.67028279143156 139.74054513870846 25.056 35.67028279143156 139.74054513870846 27.572 35.67028360220696 139.74055623924752 27.572 35.67028360220696 139.74055623924752 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6e2f576-67a2-47d0-8cd5-fcc90e60afdc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6e2f576-67a2-47d0-8cd5-fcc90e60afdc_0">
											<gml:posList>35.670353425687296 139.74054859176653 27.131 35.67035492859438 139.7405688930458 27.131 35.67036987709318 139.74055034012957 27.131 35.670354873380035 139.74053233000242 27.131 35.67034077147598 139.74054997614599 27.131 35.670353425687296 139.74054859176653 27.131</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-620e71bd-2b5b-450e-96f8-16c225f9b87c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-620e71bd-2b5b-450e-96f8-16c225f9b87c_0">
											<gml:posList>35.670277653652 139.74055689785934 25.056 35.670277653652 139.74055689785934 27.572 35.670276770009316 139.74054481428956 27.572 35.670276770009316 139.74054481428956 25.056 35.670277653652 139.74055689785934 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec3578bf-826d-4bbf-a857-23498fd34c02">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec3578bf-826d-4bbf-a857-23498fd34c02_0">
											<gml:posList>35.670353425687296 139.74054859176653 28.068 35.670353425687296 139.74054859176653 25.056 35.67023717640121 139.74056133005405 25.056 35.67023717640121 139.74056133005405 28.068 35.670353425687296 139.74054859176653 28.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e660a8e0-4873-46e4-b8fe-61eb3f6a617d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e660a8e0-4873-46e4-b8fe-61eb3f6a617d_0">
											<gml:posList>35.670369778035855 139.74055046175306 25.77 35.67036987709318 139.74055034012957 25.77 35.67036987709318 139.74055034012957 27.131 35.67035492859438 139.7405688930458 27.131 35.67035492859438 139.7405688930458 25.056 35.670369778035855 139.74055046175306 25.056 35.670369778035855 139.74055046175306 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d36c64d-b4ec-4bb6-b47e-1a98c8878e64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d36c64d-b4ec-4bb6-b47e-1a98c8878e64_0">
											<gml:posList>35.670333551890295 139.74057391068473 25.056 35.67023277787014 139.74058495200276 25.056 35.67023277787014 139.74058495200276 29.84 35.670333551890295 139.74057391068473 29.84 35.670333551890295 139.74057391068473 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45c1a780-5020-4233-8136-b00da02c6ea0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45c1a780-5020-4233-8136-b00da02c6ea0_0">
											<gml:posList>35.670233087518774 139.74058908293802 29.416 35.670233087518774 139.74058908293802 25.056 35.67032998597036 139.7405784769125 25.056 35.67032998597036 139.7405784769125 29.84 35.670233087518774 139.74058908293802 29.84 35.670233087518774 139.74058908293802 29.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7207cc71-e4e0-46a9-95a1-38147cf87b49">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7207cc71-e4e0-46a9-95a1-38147cf87b49_0">
											<gml:posList>35.670401584451156 139.740593317583 25.056 35.670389206256516 139.74057857409636 25.056 35.670389206256516 139.74057857409636 27.146 35.670401584451156 139.740593317583 27.146 35.670401584451156 139.740593317583 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35d4a692-b26f-41ed-8511-713267c3be84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35d4a692-b26f-41ed-8511-713267c3be84_0">
											<gml:posList>35.670374510129136 139.7405971156736 25.056 35.670374510129136 139.7405971156736 27.146 35.670389206256516 139.74057857409636 27.146 35.670389206256516 139.74057857409636 25.056 35.670374510129136 139.7405971156736 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6571a92-3d10-4d89-87b4-038d81df1170">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6571a92-3d10-4d89-87b4-038d81df1170_0">
											<gml:posList>35.670316428732406 139.74058941733833 27.798 35.670316856903476 139.74059529344845 27.798 35.670316856903476 139.74059529344845 29.499 35.670316428732406 139.74058941733833 29.499 35.670316428732406 139.74058941733833 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab012c8d-faed-4cb3-bf41-d6a563855ba1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab012c8d-faed-4cb3-bf41-d6a563855ba1_0">
											<gml:posList>35.670374510129136 139.7405971156736 27.146 35.67038688832153 139.74061185916045 27.146 35.670401584451156 139.740593317583 27.146 35.670389206256516 139.74057857409636 27.146 35.670374510129136 139.7405971156736 27.146</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4892914-86f0-4caa-a87d-7af7727e5d0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4892914-86f0-4caa-a87d-7af7727e5d0d_0">
											<gml:posList>35.670316856903476 139.74059529344845 27.798 35.67031481095854 139.74059551673992 27.798 35.67031481095854 139.74059551673992 29.499 35.670316856903476 139.74059529344845 29.499 35.670316856903476 139.74059529344845 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ad3ae5e-4192-48ae-9019-f6d7c4db68ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ad3ae5e-4192-48ae-9019-f6d7c4db68ec_0">
											<gml:posList>35.670303110916585 139.74059523202408 27.798 35.670280109750436 139.74059766671007 27.798 35.670280109750436 139.74059766671007 31.865 35.670303110916585 139.74059523202408 31.865 35.670303110916585 139.74059523202408 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afecf4c5-6c35-46f3-a776-e2d5e33aabc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afecf4c5-6c35-46f3-a776-e2d5e33aabc6_0">
											<gml:posList>35.67031481095854 139.74059551673992 27.798 35.670315366674004 139.74060314905623 27.798 35.670315366674004 139.74060314905623 29.499 35.67031481095854 139.74059551673992 29.499 35.67031481095854 139.74059551673992 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f18845a9-7c78-4afc-a0b0-bb6a03558889">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f18845a9-7c78-4afc-a0b0-bb6a03558889_0">
											<gml:posList>35.67038688832153 139.74061185916045 25.056 35.670401584451156 139.740593317583 25.056 35.670401584451156 139.740593317583 27.146 35.67038688832153 139.74061185916045 27.146 35.67038688832153 139.74061185916045 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6148631-16fc-4d32-ae3e-658138d909e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6148631-16fc-4d32-ae3e-658138d909e4_0">
											<gml:posList>35.67032691567132 139.74061798186202 27.798 35.670324765728346 139.74058850190204 27.798 35.670324765728346 139.74058850190204 29.499 35.67032691567132 139.74061798186202 29.499 35.67032691567132 139.74061798186202 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f1985ad-636c-4475-9670-1c4d6bab5795">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f1985ad-636c-4475-9670-1c4d6bab5795_0">
											<gml:posList>35.670315366674004 139.74060314905623 27.798 35.67031277994821 139.74060342820422 27.798 35.67031277994821 139.74060342820422 29.499 35.670315366674004 139.74060314905623 29.499 35.670315366674004 139.74060314905623 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cb9b3df-680c-48b6-82c9-e5fe8de3ba60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cb9b3df-680c-48b6-82c9-e5fe8de3ba60_0">
											<gml:posList>35.670315366674004 139.74060314905623 29.499 35.67031277994821 139.74060342820422 29.499 35.67031343587737 139.7406124411858 29.499 35.67031535563872 139.74061222908693 29.499 35.67031586576571 139.74061918763488 29.499 35.67032691567132 139.74061798186202 29.499 35.670324765728346 139.74058850190204 29.499 35.670316428732406 139.74058941733833 29.499 35.670316856903476 139.74059529344845 29.499 35.67031481095854 139.74059551673992 29.499 35.670315366674004 139.74060314905623 29.499</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04096cd9-f326-4c55-96bc-68e2f3dad140">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04096cd9-f326-4c55-96bc-68e2f3dad140_0">
											<gml:posList>35.670374510129136 139.7405971156736 25.056 35.67038688832153 139.74061185916045 25.056 35.67038688832153 139.74061185916045 27.146 35.670374510129136 139.7405971156736 27.146 35.670374510129136 139.7405971156736 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23ebfca9-14ce-4769-afb9-18f91a57b6fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23ebfca9-14ce-4769-afb9-18f91a57b6fd_0">
											<gml:posList>35.670304751352134 139.7406185598047 27.798 35.670303110916585 139.74059523202408 27.798 35.670303110916585 139.74059523202408 31.865 35.670304751352134 139.7406185598047 31.865 35.670304751352134 139.7406185598047 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99335a04-8cbc-4d89-a381-a2f3cef2f5fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99335a04-8cbc-4d89-a381-a2f3cef2f5fb_0">
											<gml:posList>35.67031277994821 139.74060342820422 27.798 35.67031343587737 139.7406124411858 27.798 35.67031343587737 139.7406124411858 29.499 35.67031277994821 139.74060342820422 29.499 35.67031277994821 139.74060342820422 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84e90c87-ab56-43d1-b27b-4972d75a0e57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84e90c87-ab56-43d1-b27b-4972d75a0e57_0">
											<gml:posList>35.6702817501855 139.74062099448403 31.865 35.670304751352134 139.7406185598047 31.865 35.670303110916585 139.74059523202408 31.865 35.670280109750436 139.74059766671007 31.865 35.6702817501855 139.74062099448403 31.865</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e1287ab-0792-4423-b493-9109a6f7d30d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e1287ab-0792-4423-b493-9109a6f7d30d_0">
											<gml:posList>35.670353425687296 139.74054859176653 25.056 35.670353425687296 139.74054859176653 28.068 35.670362171213156 139.74066851085786 28.068 35.670362171213156 139.74066851085786 25.056 35.670353425687296 139.74054859176653 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-586e21f1-61ac-4806-a5b8-e66dbcd204ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-586e21f1-61ac-4806-a5b8-e66dbcd204ec_0">
											<gml:posList>35.6702817501855 139.74062099448403 27.798 35.6702817501855 139.74062099448403 31.865 35.670280109750436 139.74059766671007 31.865 35.670280109750436 139.74059766671007 27.798 35.6702817501855 139.74062099448403 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0b61401-458c-4f9c-82b1-36786a201b20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0b61401-458c-4f9c-82b1-36786a201b20_0">
											<gml:posList>35.670238852608904 139.74058428220124 28.068 35.670333551890295 139.74057391068473 28.068 35.67033999260952 139.7406622401259 28.068 35.67032251646317 139.7406641602805 28.068 35.67032314504911 139.74067278667647 28.068 35.670362171213156 139.74066851085786 28.068 35.670353425687296 139.74054859176653 28.068 35.67023717640121 139.74056133005405 28.068 35.670238852608904 139.74058428220124 28.068</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07165b9c-e69b-41b6-a6c4-40f781c05fe0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07165b9c-e69b-41b6-a6c4-40f781c05fe0_0">
											<gml:posList>35.67031343587737 139.7406124411858 27.798 35.67031535563872 139.74061222908693 27.798 35.67031535563872 139.74061222908693 29.499 35.67031343587737 139.7406124411858 29.499 35.67031343587737 139.7406124411858 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-304f2f64-3a17-4e9f-bda4-375c43afdf70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-304f2f64-3a17-4e9f-bda4-375c43afdf70_0">
											<gml:posList>35.67031535563872 139.74061222908693 27.798 35.67031586576571 139.74061918763488 27.798 35.67031586576571 139.74061918763488 29.499 35.67031535563872 139.74061222908693 29.499 35.67031535563872 139.74061222908693 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-171f7bf5-624a-420b-bdae-4297346e7797">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-171f7bf5-624a-420b-bdae-4297346e7797_0">
											<gml:posList>35.67033999260952 139.7406622401259 25.056 35.670333551890295 139.74057391068473 25.056 35.670333551890295 139.74057391068473 29.84 35.67033999260952 139.7406622401259 29.84 35.67033999260952 139.7406622401259 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fc07f31-3332-4509-8ed2-e04ab050fab5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fc07f31-3332-4509-8ed2-e04ab050fab5_0">
											<gml:posList>35.67031586576571 139.74061918763488 27.798 35.67032691567132 139.74061798186202 27.798 35.67032691567132 139.74061798186202 29.499 35.67031586576571 139.74061918763488 29.499 35.67031586576571 139.74061918763488 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d89c6a1d-b647-446e-8c65-8fee9207ec13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d89c6a1d-b647-446e-8c65-8fee9207ec13_0">
											<gml:posList>35.67032998597036 139.7405784769125 25.056 35.67033583457984 139.7406587322233 25.056 35.67033583457984 139.7406587322233 29.84 35.67032998597036 139.7405784769125 29.84 35.67032998597036 139.7405784769125 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cbdfebf-b300-4741-bd35-3ca98111457d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8cbdfebf-b300-4741-bd35-3ca98111457d_0">
											<gml:posList>35.6702817501855 139.74062099448403 27.798 35.670304751352134 139.7406185598047 27.798 35.670304751352134 139.7406185598047 31.865 35.6702817501855 139.74062099448403 31.865 35.6702817501855 139.74062099448403 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b923f876-3073-4db5-ae2a-57c6a5221e52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b923f876-3073-4db5-ae2a-57c6a5221e52_0">
											<gml:posList>35.67025315263234 139.7406717518954 29.84 35.67033999260952 139.7406622401259 29.84 35.670333551890295 139.74057391068473 29.84 35.67023277787014 139.74058495200276 29.84 35.670233087518774 139.74058908293802 29.84 35.67032998597036 139.7405784769125 29.84 35.67033583457984 139.7406587322233 29.84 35.670252861167 139.74066781977012 29.84 35.67025315263234 139.7406717518954 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eadadda0-e4d9-43ca-a9a0-0d20ba162bb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eadadda0-e4d9-43ca-a9a0-0d20ba162bb3_0">
											<gml:posList>35.670279402009825 139.7406384281748 27.798 35.670279402009825 139.7406384281748 30.859 35.67031526452628 139.74063437692462 30.859 35.67031526452628 139.74063437692462 27.798 35.670279402009825 139.7406384281748 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9618686-aa57-4aa8-8e5d-99cb7d70132b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9618686-aa57-4aa8-8e5d-99cb7d70132b_0">
											<gml:posList>35.670316703404616 139.74065348527475 27.798 35.67031526452628 139.74063437692462 27.798 35.67031526452628 139.74063437692462 30.859 35.670316703404616 139.74065348527475 30.859 35.670316703404616 139.74065348527475 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-996fd591-e8b1-4145-9fcb-68a10f381905">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-996fd591-e8b1-4145-9fcb-68a10f381905_0">
											<gml:posList>35.670316703404616 139.74065348527475 30.859 35.67031526452628 139.74063437692462 30.859 35.670279402009825 139.7406384281748 30.859 35.67028084089602 139.74065754756273 30.859 35.670316703404616 139.74065348527475 30.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c75203b9-c6f4-431a-890e-5fd8973f67aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c75203b9-c6f4-431a-890e-5fd8973f67aa_0">
											<gml:posList>35.670279402009825 139.7406384281748 27.798 35.67028084089602 139.74065754756273 27.798 35.67028084089602 139.74065754756273 30.859 35.670279402009825 139.7406384281748 30.859 35.670279402009825 139.7406384281748 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e124eb7a-b29f-4402-97ce-44df0ee9568f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e124eb7a-b29f-4402-97ce-44df0ee9568f_0">
											<gml:posList>35.67036141506605 139.7406581061578 25.056 35.67036141506605 139.7406581061578 28.272 35.67042974308183 139.74065150988193 28.272 35.67042974308183 139.74065150988193 25.056 35.67036141506605 139.7406581061578 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe00cced-c586-40f2-b97d-a37df8628dfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe00cced-c586-40f2-b97d-a37df8628dfb_0">
											<gml:posList>35.67028084089602 139.74065754756273 27.798 35.670316703404616 139.74065348527475 27.798 35.670316703404616 139.74065348527475 30.859 35.67028084089602 139.74065754756273 30.859 35.67028084089602 139.74065754756273 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6ff06c8-a027-4a8b-869a-9e129fda8aff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6ff06c8-a027-4a8b-869a-9e129fda8aff_0">
											<gml:posList>35.67042974308183 139.74065150988193 28.272 35.67043052771591 139.74066379242316 28.272 35.67043052771591 139.74066379242316 25.056 35.67042974308183 139.74065150988193 25.056 35.67042974308183 139.74065150988193 28.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b04b42c-1aea-4a73-ae4d-6e3d27f57eb1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67025978823092 139.7405332353873 25.056 35.6702607994969 139.74054717457548 25.056 35.67025866342332 139.74054740901857 25.056 35.670259501529046 139.74055888509497 25.056 35.67025308429451 139.74055958843363 25.056 35.67025219154473 139.74054738336943 25.056 35.670249352460345 139.74054769594972 25.056 35.67024838682491 139.74053448576262 25.056 35.67025978823092 139.7405332353873 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d9fb0cd-2d4d-45e7-9e12-13a4a3253483">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670283461542844 139.74052576281724 25.056 35.67024125341157 139.74052987669046 25.056 35.67024258530788 139.74055049847982 25.056 35.67023339199141 139.7405513928176 25.056 35.67023069181708 139.74050972952926 25.056 35.67023562195737 139.74050924883326 25.056 35.6702362788557 139.74051951002934 25.056 35.67025439509347 139.74051774375175 25.056 35.67025383857215 139.740509073096 25.056 35.67025818286301 139.74050864830926 25.056 35.67025900387304 139.74052132844542 25.056 35.670272757792446 139.74051998697487 25.056 35.67027192759824 139.74050708592227 25.056 35.6702761997878 139.74050667226507 25.056 35.670276756198604 139.74051519932218 25.056 35.6702827408593 139.74051460694298 25.056 35.670283461542844 139.74052576281724 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb4e154b-1d74-4a60-acb8-4cb7287c8bf4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67027087468441 139.7405326702433 25.056 35.670286485149894 139.74053096209946 25.056 35.670287478175894 139.74054462515724 25.056 35.67028279143156 139.74054513870846 25.056 35.67028360220696 139.74055623924752 25.056 35.670277653652 139.74055689785934 25.056 35.670276770009316 139.74054481428956 25.056 35.67027179485138 139.74054536131322 25.056 35.67027087468441 139.7405326702433 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dee92a57-eeef-4df5-81d8-756afb42d12e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033583457984 139.7406587322233 25.056 35.67032998597036 139.7405784769125 25.056 35.670233087518774 139.74058908293802 25.056 35.67023277787014 139.74058495200276 25.056 35.670333551890295 139.74057391068473 25.056 35.67033999260952 139.7406622401259 25.056 35.67025315263234 139.7406717518954 25.056 35.670252861167 139.74066781977012 25.056 35.67033583457984 139.7406587322233 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e2acd82-24b2-4ac3-af07-94e4c8e155b2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6702817501855 139.74062099448403 27.798 35.670280109750436 139.74059766671007 27.798 35.670303110916585 139.74059523202408 27.798 35.670304751352134 139.7406185598047 27.798 35.6702817501855 139.74062099448403 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-020a7514-6ca6-434f-91e0-c850d0d6722b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670316703404616 139.74065348527475 27.798 35.67028084089602 139.74065754756273 27.798 35.670279402009825 139.7406384281748 27.798 35.67031526452628 139.74063437692462 27.798 35.670316703404616 139.74065348527475 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62dc28e2-5615-4c9f-bde0-3f8665d08064">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670353425687296 139.74054859176653 25.056 35.670362171213156 139.74066851085786 25.056 35.67032314504911 139.74067278667647 25.056 35.67032251646317 139.7406641602805 25.056 35.67033999260952 139.7406622401259 25.056 35.670333551890295 139.74057391068473 25.056 35.670238852608904 139.74058428220124 25.056 35.67023717640121 139.74056133005405 25.056 35.670353425687296 139.74054859176653 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df491f08-d359-43de-9291-780c65416e3e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67030670830101 139.74070180207676 25.056 35.670316415298736 139.74070077460695 25.056 35.670318602339485 139.74073164635166 25.056 35.670308895349976 139.740732684864 25.056 35.67030670830101 139.74070180207676 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a09a6d79-719d-45f1-8f51-fdc923ad2362">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033044821217 139.74051159131827 25.056 35.67033146851141 139.74052555260053 25.056 35.67033738101975 139.74052490507393 25.056 35.67033922124333 139.74055014363378 25.056 35.67033539073459 139.74055056782413 25.056 35.67033488971952 139.7405437418194 25.056 35.67032387586957 139.74054494756092 25.056 35.67032322912785 139.74053616653939 25.056 35.67031194489182 139.74053740573342 25.056 35.67031269184838 139.74054756741904 25.056 35.67030138958476 139.7405488066322 25.056 35.67029875686537 139.74051279890963 25.056 35.67031142009007 139.74051141451463 25.056 35.67031298704443 139.7405329418422 25.056 35.67032037767568 139.7405321269117 25.056 35.67031897469674 139.74051284178128 25.056 35.67033044821217 139.74051159131827 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54a97fc0-c798-43db-8ce0-63233fcf3f82">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670316856903476 139.74059529344845 27.798 35.670316428732406 139.74058941733833 27.798 35.670324765728346 139.74058850190204 27.798 35.67032691567132 139.74061798186202 27.798 35.67031586576571 139.74061918763488 27.798 35.67031535563872 139.74061222908693 27.798 35.67031343587737 139.7406124411858 27.798 35.67031277994821 139.74060342820422 27.798 35.670315366674004 139.74060314905623 27.798 35.67031481095854 139.74059551673992 27.798 35.670316856903476 139.74059529344845 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a550bda-4473-42b2-a089-3cd4bda22a0b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670354873380035 139.74053233000242 25.056 35.670368009516196 139.7405480888542 25.056 35.670369778035855 139.74055046175306 25.056 35.67035492859438 139.7405688930458 25.056 35.670353425687296 139.74054859176653 25.056 35.67034077147598 139.74054997614599 25.056 35.670354873380035 139.74053233000242 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9f6db55-c896-4567-b6af-3670971b0685">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67036987709318 139.74055034012957 25.77 35.670369778035855 139.74055046175306 25.77 35.670368009516196 139.7405480888542 25.77 35.67036987709318 139.74055034012957 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e8dafaf-8ae9-46d4-b86c-17f42388fc4a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670374510129136 139.7405971156736 25.056 35.670389206256516 139.74057857409636 25.056 35.670401584451156 139.740593317583 25.056 35.67038688832153 139.74061185916045 25.056 35.670374510129136 139.7405971156736 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fca5416-0b6e-4590-9afb-258a55345a92">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67042974308183 139.74065150988193 25.056 35.67043052771591 139.74066379242316 25.056 35.67041123975203 139.74066563734982 25.056 35.670412398273584 139.74068354200463 25.056 35.67040564730975 139.74068395851748 25.056 35.67040312799666 139.74066641996365 25.056 35.670362271775204 139.7406703444203 25.056 35.670362171213156 139.74066851085786 25.056 35.67036141506605 139.7406581061578 25.056 35.67042974308183 139.74065150988193 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34fd37c6-7565-4c7d-9da1-52291b238264">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67040263320576 139.74070281797063 25.056 35.67040185271947 139.74068420592013 25.056 35.67041571516205 139.74068332829273 25.056 35.67041649565699 139.7407019513927 25.056 35.67040263320576 139.74070281797063 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f691bc3-a2cc-44b4-8de0-703bef8cce70">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67042663143196 139.74070759537065 25.056 35.67042491753921 139.74067078014733 25.056 35.67043078515815 139.74067036465414 25.056 35.67043134430274 139.74068245966976 25.056 35.67044239454027 139.74068168470788 25.056 35.67044271533257 139.74068858825473 25.056 35.6704313496317 139.7406893856727 25.056 35.67043218359623 139.74070721338342 25.056 35.67042663143196 139.74070759537065 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bd22d17a-8a2c-4b3e-a254-7e84414793b7_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d347140-a2d4-42c7-942a-be7b226cfc70">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033040692494 139.74070378511504 25.056 35.6703860797874 139.74069734710375 25.056 35.67038796444026 139.74072180134706 25.056 35.670332291576486 139.74072823934156 25.056 35.67033040692494 139.74070378511504 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2861969e-1e30-477e-9cf0-fb1a02617115">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2861969e-1e30-477e-9cf0-fb1a02617115_0">
											<gml:posList>35.67033040692494 139.74070378511504 28.272 35.6703860797874 139.74069734710375 28.272 35.6703860797874 139.74069734710375 25.056 35.67033040692494 139.74070378511504 25.056 35.67033040692494 139.74070378511504 28.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5a83904-ff3f-4bec-be41-f985595427e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5a83904-ff3f-4bec-be41-f985595427e5_0">
											<gml:posList>35.6703860797874 139.74069734710375 25.056 35.6703860797874 139.74069734710375 28.272 35.67038796444026 139.74072180134706 28.272 35.67038796444026 139.74072180134706 25.056 35.6703860797874 139.74069734710375 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38bb5484-91c7-44b4-b832-44c3f0f94370">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38bb5484-91c7-44b4-b832-44c3f0f94370_0">
											<gml:posList>35.67033040692494 139.74070378511504 28.272 35.670332291576486 139.74072823934156 28.272 35.67038796444026 139.74072180134706 28.272 35.6703860797874 139.74069734710375 28.272 35.67033040692494 139.74070378511504 28.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b20728b5-231f-47de-ab1b-66456629eb4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b20728b5-231f-47de-ab1b-66456629eb4f_0">
											<gml:posList>35.670332291576486 139.74072823934156 25.056 35.670332291576486 139.74072823934156 28.272 35.67033040692494 139.74070378511504 28.272 35.67033040692494 139.74070378511504 25.056 35.670332291576486 139.74072823934156 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57966d57-f641-47c4-a101-a914a5f6097a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57966d57-f641-47c4-a101-a914a5f6097a_0">
											<gml:posList>35.67038796444026 139.74072180134706 25.056 35.67038796444026 139.74072180134706 28.272 35.670332291576486 139.74072823934156 28.272 35.670332291576486 139.74072823934156 25.056 35.67038796444026 139.74072180134706 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d6820081-cd8f-484c-b78b-fff69a6801ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6820081-cd8f-484c-b78b-fff69a6801ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6820081-cd8f-484c-b78b-fff69a6801ca">
											<gml:posList>35.670455376526085 139.74073143315167 10.23 35.67023257581445 139.74075577127837 10.23 35.670214173856856 139.74050349648252 10.23 35.670330441258294 139.7404908796027 10.23 35.670449454970964 139.74065002898828 10.23 35.670455376526085 139.74073143315167 10.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a0a1d571-3c03-4206-837b-f7fe785f2dd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0a1d571-3c03-4206-837b-f7fe785f2dd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0a1d571-3c03-4206-837b-f7fe785f2dd5">
											<gml:posList>35.670330441258294 139.7404908796027 25.77 35.670214173856856 139.74050349648252 25.77 35.67021839562584 139.7405078327658 25.77 35.670328867689356 139.7404958522384 25.77 35.670330441258294 139.7404908796027 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68530d62-b340-4319-9e4a-93e0b3138d37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68530d62-b340-4319-9e4a-93e0b3138d37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68530d62-b340-4319-9e4a-93e0b3138d37">
											<gml:posList>35.67022021378686 139.74058632522386 25.77 35.67022408936442 139.7405859009837 25.77 35.67021839562584 139.7405078327658 25.77 35.670214173856856 139.74050349648252 25.77 35.67022021378686 139.74058632522386 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af1a0230-6243-4bf7-bbfd-8ce28b7af0c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af1a0230-6243-4bf7-bbfd-8ce28b7af0c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af1a0230-6243-4bf7-bbfd-8ce28b7af0c1">
											<gml:posList>35.670330441258294 139.7404908796027 25.77 35.670328867689356 139.7404958522384 25.77 35.6704212272135 139.74061912103036 25.77 35.6704260041378 139.7406186626096 25.77 35.670330441258294 139.7404908796027 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4911f2c1-3504-4416-bca9-b6905c64c556">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4911f2c1-3504-4416-bca9-b6905c64c556">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4911f2c1-3504-4416-bca9-b6905c64c556">
											<gml:posList>35.67024991474418 139.74058725188985 27.975 35.67025389294393 139.74059133439764 27.975 35.67032665464528 139.74058335216358 27.975 35.67032998597036 139.7405784769125 27.975 35.67024991474418 139.74058725188985 27.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3fd96949-e26b-4435-8103-9af8ac3d1d42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fd96949-e26b-4435-8103-9af8ac3d1d42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fd96949-e26b-4435-8103-9af8ac3d1d42">
											<gml:posList>35.67022021378686 139.74058632522386 29.84 35.67022205404123 139.74058821200177 29.84 35.67023125627814 139.74058719614942 29.84 35.67023277787014 139.74058495200276 29.84 35.67022021378686 139.74058632522386 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bbf23b1d-5d2f-4b64-ae16-73ecac219cdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbf23b1d-5d2f-4b64-ae16-73ecac219cdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbf23b1d-5d2f-4b64-ae16-73ecac219cdb">
											<gml:posList>35.67023618491578 139.74063158528523 29.84 35.67023277787014 139.74058495200276 29.84 35.67023125627814 139.74058719614942 29.84 35.67023465430918 139.7406338294415 29.84 35.67023618491578 139.74063158528523 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2fea219c-e380-45a7-b39d-33d4cf1bd4a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fea219c-e380-45a7-b39d-33d4cf1bd4a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fea219c-e380-45a7-b39d-33d4cf1bd4a9">
											<gml:posList>35.67032998597036 139.7405784769125 27.975 35.67032665464528 139.74058335216358 27.975 35.670331847368686 139.7406546497184 27.975 35.67033583457984 139.7406587322233 27.975 35.67032998597036 139.7405784769125 27.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17ca475a-2abe-4253-8930-ddb506c2c22a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17ca475a-2abe-4253-8930-ddb506c2c22a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17ca475a-2abe-4253-8930-ddb506c2c22a">
											<gml:posList>35.6704260041378 139.7406186626096 28.918 35.67038777975504 139.74062236312326 28.918 35.670390287602615 139.74062500027975 28.918 35.670425041957365 139.74062163516768 28.918 35.6704260041378 139.7406186626096 28.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-75fa8734-9fc0-41ff-9a6b-b00b71928d52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75fa8734-9fc0-41ff-9a6b-b00b71928d52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75fa8734-9fc0-41ff-9a6b-b00b71928d52">
											<gml:posList>35.670331847368686 139.7406546497184 27.798 35.67032665464528 139.74058335216358 27.798 35.67025389294393 139.74059133439764 27.798 35.670259094676304 139.74066263187788 27.798 35.670331847368686 139.7406546497184 27.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b916f340-3fb9-4cfc-bf3b-f30ed2c3decf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b916f340-3fb9-4cfc-bf3b-f30ed2c3decf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b916f340-3fb9-4cfc-bf3b-f30ed2c3decf">
											<gml:posList>35.670328867689356 139.7404958522384 25.056 35.67021839562584 139.7405078327658 25.056 35.67022408936442 139.7405859009837 25.056 35.67023277787014 139.74058495200276 25.056 35.67023618491578 139.74063158528523 25.056 35.67025010995265 139.74063005585 25.056 35.67024991474418 139.74058725188985 25.056 35.67032998597036 139.7405784769125 25.056 35.67033583457984 139.7406587322233 25.056 35.670255772361486 139.74066750711071 25.056 35.670253152640846 139.74067176294162 25.056 35.670230539097 139.7406742413411 25.056 35.67023610521918 139.740750597563 25.056 35.67045114576006 139.74072710790054 25.056 35.67044557902772 139.74064997823743 25.056 35.67038990535222 139.74065535584643 25.056 35.67038777975504 139.74062236312326 25.056 35.6704212272135 139.74061912103036 25.056 35.670328867689356 139.7404958522384 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a841335a-fb72-48a5-b8db-8c0b18c04996">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a841335a-fb72-48a5-b8db-8c0b18c04996">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a841335a-fb72-48a5-b8db-8c0b18c04996">
											<gml:posList>35.670255772361486 139.74066750711071 27.975 35.670259094676304 139.74066263187788 27.975 35.67025389294393 139.74059133439764 27.975 35.67024991474418 139.74058725188985 27.975 35.670255772361486 139.74066750711071 27.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0b473fe-9555-4592-948c-48378d57a7ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0b473fe-9555-4592-948c-48378d57a7ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0b473fe-9555-4592-948c-48378d57a7ad">
											<gml:posList>35.670255772361486 139.74066750711071 25.056 35.67024991474418 139.74058725188985 25.056 35.67025010995265 139.74063005585 25.056 35.670253152640846 139.74067176294162 25.056 35.670255772361486 139.74066750711071 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b753e5a5-8e4c-4ae7-9709-f8e261add5fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b753e5a5-8e4c-4ae7-9709-f8e261add5fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b753e5a5-8e4c-4ae7-9709-f8e261add5fe">
											<gml:posList>35.6702282031487 139.7406724324576 29.564 35.6702513214185 139.74066989824314 29.564 35.670248579346094 139.7406323000067 29.564 35.67023465430918 139.7406338294415 29.564 35.67023125627814 139.74058719614942 29.564 35.67022205404123 139.74058821200177 29.564 35.6702282031487 139.7406724324576 29.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5255eb00-dca5-4f6f-b1ea-fa36d2624347">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5255eb00-dca5-4f6f-b1ea-fa36d2624347">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5255eb00-dca5-4f6f-b1ea-fa36d2624347">
											<gml:posList>35.670226663519124 139.74067466557705 29.84 35.6702282031487 139.7406724324576 29.84 35.67022205404123 139.74058821200177 29.84 35.67022021378686 139.74058632522386 29.84 35.670226663519124 139.74067466557705 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a42b635-197b-4eeb-be68-ef3a1c2334a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a42b635-197b-4eeb-be68-ef3a1c2334a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a42b635-197b-4eeb-be68-ef3a1c2334a4">
											<gml:posList>35.67023618491578 139.74063158528523 29.84 35.67023465430918 139.7406338294415 29.84 35.670248579346094 139.7406323000067 29.84 35.67025010995265 139.74063005585 29.84 35.67023618491578 139.74063158528523 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7bef4bad-be8a-41c9-8226-01efc534d578">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bef4bad-be8a-41c9-8226-01efc534d578">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bef4bad-be8a-41c9-8226-01efc534d578">
											<gml:posList>35.6704260041378 139.7406186626096 28.918 35.670425041957365 139.74062163516768 28.918 35.67044419781951 139.74064724035955 28.918 35.67044915721203 139.7406496316668 28.918 35.6704260041378 139.7406186626096 28.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e71e030-8562-4364-8611-2dc7e44073d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e71e030-8562-4364-8611-2dc7e44073d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e71e030-8562-4364-8611-2dc7e44073d3">
											<gml:posList>35.670392048254655 139.74065228250882 28.373 35.67044419781951 139.74064724035955 28.373 35.670425041957365 139.74062163516768 28.373 35.670390287602615 139.74062500027975 28.373 35.670392048254655 139.74065228250882 28.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9aa81f86-9bce-4af9-8e11-cf417e63e31c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9aa81f86-9bce-4af9-8e11-cf417e63e31c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9aa81f86-9bce-4af9-8e11-cf417e63e31c">
											<gml:posList>35.67038990535222 139.74065535584643 28.918 35.670392048254655 139.74065228250882 28.918 35.670390287602615 139.74062500027975 28.918 35.67038777975504 139.74062236312326 28.918 35.67038990535222 139.74065535584643 28.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-53d86485-7ad2-4d74-861c-080ac6321a73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53d86485-7ad2-4d74-861c-080ac6321a73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53d86485-7ad2-4d74-861c-080ac6321a73">
											<gml:posList>35.67025010995265 139.74063005585 29.84 35.670248579346094 139.7406323000067 29.84 35.6702513214185 139.74066989824314 29.84 35.670253152640846 139.74067176294162 29.84 35.67025010995265 139.74063005585 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d105cd03-1900-4b92-9ffe-c1fcd23fa5b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d105cd03-1900-4b92-9ffe-c1fcd23fa5b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d105cd03-1900-4b92-9ffe-c1fcd23fa5b2">
											<gml:posList>35.67038990535222 139.74065535584643 28.918 35.67044915721203 139.7406496316668 28.918 35.67044419781951 139.74064724035955 28.918 35.670392048254655 139.74065228250882 28.918 35.67038990535222 139.74065535584643 28.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d7c71aa-40d5-4782-aad2-03a98ad7dc76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d7c71aa-40d5-4782-aad2-03a98ad7dc76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d7c71aa-40d5-4782-aad2-03a98ad7dc76">
											<gml:posList>35.67033583457984 139.7406587322233 27.975 35.670331847368686 139.7406546497184 27.975 35.670259094676304 139.74066263187788 27.975 35.670255772361486 139.74066750711071 27.975 35.67033583457984 139.7406587322233 27.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4b73cd5c-a684-469a-93e5-25d55ae42621">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b73cd5c-a684-469a-93e5-25d55ae42621">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b73cd5c-a684-469a-93e5-25d55ae42621">
											<gml:posList>35.670253152640846 139.74067176294162 29.84 35.6702513214185 139.74066989824314 29.84 35.6702282031487 139.7406724324576 29.84 35.670226663519124 139.74067466557705 29.84 35.670253152640846 139.74067176294162 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7512469-f58b-4bdd-851e-19fe6b0181bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7512469-f58b-4bdd-851e-19fe6b0181bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7512469-f58b-4bdd-851e-19fe6b0181bf">
											<gml:posList>35.670449454970964 139.74065002898828 25.77 35.67044557902772 139.74064997823743 25.77 35.67045114576006 139.74072710790054 25.77 35.670455376526085 139.74073143315167 25.77 35.670449454970964 139.74065002898828 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0f497086-bb03-40b3-838b-0c7f08ad4d0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f497086-bb03-40b3-838b-0c7f08ad4d0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f497086-bb03-40b3-838b-0c7f08ad4d0c">
											<gml:posList>35.670226663519124 139.74067466557705 25.77 35.67023257581445 139.74075577127837 25.77 35.67023610521918 139.740750597563 25.77 35.670230539097 139.7406742413411 25.77 35.670226663519124 139.74067466557705 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2a5a8642-cda4-42ff-b3e7-f328bf8e6445">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a5a8642-cda4-42ff-b3e7-f328bf8e6445">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a5a8642-cda4-42ff-b3e7-f328bf8e6445">
											<gml:posList>35.670455376526085 139.74073143315167 25.77 35.67045114576006 139.74072710790054 25.77 35.67023610521918 139.740750597563 25.77 35.67023257581445 139.74075577127837 25.77 35.670455376526085 139.74073143315167 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cd6831d-54e8-46d0-a33c-1cf9863d15ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cd6831d-54e8-46d0-a33c-1cf9863d15ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cd6831d-54e8-46d0-a33c-1cf9863d15ec">
											<gml:posList>35.67023125627814 139.74058719614942 29.84 35.67023125627814 139.74058719614942 29.564 35.67023465430918 139.7406338294415 29.564 35.67023465430918 139.7406338294415 29.84 35.67023125627814 139.74058719614942 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e76aec9e-50fa-41c1-b800-d75fb77d7273">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e76aec9e-50fa-41c1-b800-d75fb77d7273">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e76aec9e-50fa-41c1-b800-d75fb77d7273">
											<gml:posList>35.670425041957365 139.74062163516768 28.918 35.670425041957365 139.74062163516768 28.373 35.67044419781951 139.74064724035955 28.373 35.67044419781951 139.74064724035955 28.918 35.670425041957365 139.74062163516768 28.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49815842-98ab-4922-9282-503acbeb52b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49815842-98ab-4922-9282-503acbeb52b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49815842-98ab-4922-9282-503acbeb52b2">
											<gml:posList>35.670392048254655 139.74065228250882 28.918 35.670392048254655 139.74065228250882 28.373 35.670390287602615 139.74062500027975 28.373 35.670390287602615 139.74062500027975 28.918 35.670392048254655 139.74065228250882 28.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1719d2a3-4332-4342-8638-4e2336942f40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1719d2a3-4332-4342-8638-4e2336942f40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1719d2a3-4332-4342-8638-4e2336942f40">
											<gml:posList>35.67022408936442 139.7405859009837 25.77 35.67022408936442 139.7405859009837 25.056 35.67021839562584 139.7405078327658 25.056 35.67021839562584 139.7405078327658 25.77 35.67022408936442 139.7405859009837 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9407a56e-11ee-40df-a6c4-08e459025b5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9407a56e-11ee-40df-a6c4-08e459025b5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9407a56e-11ee-40df-a6c4-08e459025b5c">
											<gml:posList>35.670226663519124 139.74067466557705 25.77 35.670226663519124 139.74067466557705 29.84 35.67022021378686 139.74058632522386 29.84 35.67022021378686 139.74058632522386 25.77 35.670214173856856 139.74050349648252 25.77 35.670214173856856 139.74050349648252 10.23 35.67023257581445 139.74075577127837 10.23 35.67023257581445 139.74075577127837 25.77 35.670226663519124 139.74067466557705 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8ca452c-b9cb-4e01-a57c-bd0bb355179d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8ca452c-b9cb-4e01-a57c-bd0bb355179d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8ca452c-b9cb-4e01-a57c-bd0bb355179d">
											<gml:posList>35.6702282031487 139.7406724324576 29.84 35.6702282031487 139.7406724324576 29.564 35.67022205404123 139.74058821200177 29.564 35.67022205404123 139.74058821200177 29.84 35.6702282031487 139.7406724324576 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b110a828-631d-456b-b5d8-d96f6253b17c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b110a828-631d-456b-b5d8-d96f6253b17c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b110a828-631d-456b-b5d8-d96f6253b17c">
											<gml:posList>35.67022408936442 139.7405859009837 25.77 35.67022021378686 139.74058632522386 25.77 35.67022021378686 139.74058632522386 29.84 35.67023277787014 139.74058495200276 29.84 35.67023277787014 139.74058495200276 25.056 35.67022408936442 139.7405859009837 25.056 35.67022408936442 139.7405859009837 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2b3eb8c-5370-4c81-960a-c79a8119b40e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2b3eb8c-5370-4c81-960a-c79a8119b40e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2b3eb8c-5370-4c81-960a-c79a8119b40e">
											<gml:posList>35.67022205404123 139.74058821200177 29.84 35.67022205404123 139.74058821200177 29.564 35.67023125627814 139.74058719614942 29.564 35.67023125627814 139.74058719614942 29.84 35.67022205404123 139.74058821200177 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a836082-f2bd-45c9-a31f-a2bdc2246120">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a836082-f2bd-45c9-a31f-a2bdc2246120">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a836082-f2bd-45c9-a31f-a2bdc2246120">
											<gml:posList>35.67023610521918 139.740750597563 25.77 35.67023610521918 139.740750597563 25.056 35.670230539097 139.7406742413411 25.056 35.670230539097 139.7406742413411 25.77 35.67023610521918 139.740750597563 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-047fa5f8-6196-47df-b515-065c50e03f96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-047fa5f8-6196-47df-b515-065c50e03f96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-047fa5f8-6196-47df-b515-065c50e03f96">
											<gml:posList>35.67023277787014 139.74058495200276 29.84 35.67023618491578 139.74063158528523 29.84 35.67023618491578 139.74063158528523 25.056 35.67023277787014 139.74058495200276 25.056 35.67023277787014 139.74058495200276 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb7fcac7-84f1-4ec4-8080-3f4443899d58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb7fcac7-84f1-4ec4-8080-3f4443899d58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb7fcac7-84f1-4ec4-8080-3f4443899d58">
											<gml:posList>35.6702513214185 139.74066989824314 29.84 35.6702513214185 139.74066989824314 29.564 35.6702282031487 139.7406724324576 29.564 35.6702282031487 139.7406724324576 29.84 35.6702513214185 139.74066989824314 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d02aa5af-81f1-4408-a741-59c477bc830f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d02aa5af-81f1-4408-a741-59c477bc830f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d02aa5af-81f1-4408-a741-59c477bc830f">
											<gml:posList>35.670226663519124 139.74067466557705 29.84 35.670226663519124 139.74067466557705 25.77 35.670230539097 139.7406742413411 25.77 35.670230539097 139.7406742413411 25.056 35.670253152640846 139.74067176294162 25.056 35.670253152640846 139.74067176294162 29.84 35.670226663519124 139.74067466557705 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f022afc0-8b90-49a0-954b-a674b0de0264">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f022afc0-8b90-49a0-954b-a674b0de0264">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f022afc0-8b90-49a0-954b-a674b0de0264">
											<gml:posList>35.67023465430918 139.7406338294415 29.84 35.67023465430918 139.7406338294415 29.564 35.670248579346094 139.7406323000067 29.564 35.670248579346094 139.7406323000067 29.84 35.67023465430918 139.7406338294415 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-340d2c3e-18f0-4eef-b319-fee2be6609ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-340d2c3e-18f0-4eef-b319-fee2be6609ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-340d2c3e-18f0-4eef-b319-fee2be6609ad">
											<gml:posList>35.67023618491578 139.74063158528523 29.84 35.67025010995265 139.74063005585 29.84 35.67025010995265 139.74063005585 25.056 35.67023618491578 139.74063158528523 25.056 35.67023618491578 139.74063158528523 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1920d444-ba1f-4104-85c0-2ea3ee074ed6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1920d444-ba1f-4104-85c0-2ea3ee074ed6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1920d444-ba1f-4104-85c0-2ea3ee074ed6">
											<gml:posList>35.670248579346094 139.7406323000067 29.84 35.670248579346094 139.7406323000067 29.564 35.6702513214185 139.74066989824314 29.564 35.6702513214185 139.74066989824314 29.84 35.670248579346094 139.7406323000067 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2746612-1fd2-4e99-870b-5fa342b2a525">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2746612-1fd2-4e99-870b-5fa342b2a525">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2746612-1fd2-4e99-870b-5fa342b2a525">
											<gml:posList>35.67025010995265 139.74063005585 29.84 35.670253152640846 139.74067176294162 29.84 35.670253152640846 139.74067176294162 25.056 35.67025010995265 139.74063005585 25.056 35.67025010995265 139.74063005585 29.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34a0fb59-0335-422a-a43d-04e9850f0bf4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34a0fb59-0335-422a-a43d-04e9850f0bf4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34a0fb59-0335-422a-a43d-04e9850f0bf4">
											<gml:posList>35.67024991474418 139.74058725188985 25.056 35.670255772361486 139.74066750711071 25.056 35.670255772361486 139.74066750711071 27.975 35.67024991474418 139.74058725188985 27.975 35.67024991474418 139.74058725188985 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f29ebb3d-8b32-4a9c-9657-2ac1cab18009">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f29ebb3d-8b32-4a9c-9657-2ac1cab18009">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f29ebb3d-8b32-4a9c-9657-2ac1cab18009">
											<gml:posList>35.670259094676304 139.74066263187788 27.975 35.670259094676304 139.74066263187788 27.798 35.67025389294393 139.74059133439764 27.798 35.67025389294393 139.74059133439764 27.975 35.670259094676304 139.74066263187788 27.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-667c8876-fe12-4e5e-ad30-169e032b74b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-667c8876-fe12-4e5e-ad30-169e032b74b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-667c8876-fe12-4e5e-ad30-169e032b74b8">
											<gml:posList>35.670330441258294 139.7404908796027 10.23 35.670214173856856 139.74050349648252 10.23 35.670214173856856 139.74050349648252 25.77 35.670330441258294 139.7404908796027 25.77 35.670330441258294 139.7404908796027 10.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8510c28-8af7-4a8e-be18-3f89d352a307">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8510c28-8af7-4a8e-be18-3f89d352a307">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8510c28-8af7-4a8e-be18-3f89d352a307">
											<gml:posList>35.67021839562584 139.7405078327658 25.77 35.67021839562584 139.7405078327658 25.056 35.670328867689356 139.7404958522384 25.056 35.670328867689356 139.7404958522384 25.77 35.67021839562584 139.7405078327658 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b01d8daa-7bf2-4a9e-8a31-87aabbf41e92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b01d8daa-7bf2-4a9e-8a31-87aabbf41e92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b01d8daa-7bf2-4a9e-8a31-87aabbf41e92">
											<gml:posList>35.67024991474418 139.74058725188985 27.975 35.67032998597036 139.7405784769125 27.975 35.67032998597036 139.7405784769125 25.056 35.67024991474418 139.74058725188985 25.056 35.67024991474418 139.74058725188985 27.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79c73984-211b-472c-88fe-6e7a6e42a6cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79c73984-211b-472c-88fe-6e7a6e42a6cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79c73984-211b-472c-88fe-6e7a6e42a6cb">
											<gml:posList>35.67025389294393 139.74059133439764 27.975 35.67025389294393 139.74059133439764 27.798 35.67032665464528 139.74058335216358 27.798 35.67032665464528 139.74058335216358 27.975 35.67025389294393 139.74059133439764 27.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-189d4541-f703-4d79-926c-0c442e573f9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-189d4541-f703-4d79-926c-0c442e573f9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-189d4541-f703-4d79-926c-0c442e573f9f">
											<gml:posList>35.670331847368686 139.7406546497184 27.975 35.670331847368686 139.7406546497184 27.798 35.670259094676304 139.74066263187788 27.798 35.670259094676304 139.74066263187788 27.975 35.670331847368686 139.7406546497184 27.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edec16e5-b15d-4cd8-9983-33d43b616822">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edec16e5-b15d-4cd8-9983-33d43b616822">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edec16e5-b15d-4cd8-9983-33d43b616822">
											<gml:posList>35.670255772361486 139.74066750711071 25.056 35.67033583457984 139.7406587322233 25.056 35.67033583457984 139.7406587322233 27.975 35.670255772361486 139.74066750711071 27.975 35.670255772361486 139.74066750711071 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-266689ed-434f-47d1-ba95-fcb970ca4ff4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-266689ed-434f-47d1-ba95-fcb970ca4ff4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-266689ed-434f-47d1-ba95-fcb970ca4ff4">
											<gml:posList>35.67032665464528 139.74058335216358 27.975 35.67032665464528 139.74058335216358 27.798 35.670331847368686 139.7406546497184 27.798 35.670331847368686 139.7406546497184 27.975 35.67032665464528 139.74058335216358 27.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-176f8b2f-1f76-480e-af3c-d20240d2db76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-176f8b2f-1f76-480e-af3c-d20240d2db76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-176f8b2f-1f76-480e-af3c-d20240d2db76">
											<gml:posList>35.67032998597036 139.7405784769125 27.975 35.67033583457984 139.7406587322233 27.975 35.67033583457984 139.7406587322233 25.056 35.67032998597036 139.7405784769125 25.056 35.67032998597036 139.7405784769125 27.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1c92ca7-c3ef-4050-8efc-022657792929">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1c92ca7-c3ef-4050-8efc-022657792929">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1c92ca7-c3ef-4050-8efc-022657792929">
											<gml:posList>35.670328867689356 139.7404958522384 25.77 35.670328867689356 139.7404958522384 25.056 35.6704212272135 139.74061912103036 25.056 35.6704212272135 139.74061912103036 25.77 35.670328867689356 139.7404958522384 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2875b71d-aa5d-4f76-b487-4f249191f11d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2875b71d-aa5d-4f76-b487-4f249191f11d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2875b71d-aa5d-4f76-b487-4f249191f11d">
											<gml:posList>35.67038777975504 139.74062236312326 28.918 35.67038777975504 139.74062236312326 25.056 35.67038990535222 139.74065535584643 25.056 35.67038990535222 139.74065535584643 25.77 35.67038990535222 139.74065535584643 28.918 35.67038777975504 139.74062236312326 28.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d0f9b85-8f86-441c-97f9-738777a72b2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d0f9b85-8f86-441c-97f9-738777a72b2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d0f9b85-8f86-441c-97f9-738777a72b2d">
											<gml:posList>35.67044915721203 139.7406496316668 28.918 35.670449454970964 139.74065002898828 25.77 35.670449454970964 139.74065002898828 10.23 35.670330441258294 139.7404908796027 10.23 35.670330441258294 139.7404908796027 25.77 35.6704260041378 139.7406186626096 25.77 35.6704260041378 139.7406186626096 28.918 35.67044915721203 139.7406496316668 28.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f91cb83c-442e-4719-b95a-93f18cbf508b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f91cb83c-442e-4719-b95a-93f18cbf508b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f91cb83c-442e-4719-b95a-93f18cbf508b">
											<gml:posList>35.67038777975504 139.74062236312326 25.056 35.67038777975504 139.74062236312326 28.918 35.6704260041378 139.7406186626096 28.918 35.6704260041378 139.7406186626096 25.77 35.6704212272135 139.74061912103036 25.77 35.6704212272135 139.74061912103036 25.056 35.67038777975504 139.74062236312326 25.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27d24984-af9b-4f29-9dad-e4dc4d1d5513">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27d24984-af9b-4f29-9dad-e4dc4d1d5513">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27d24984-af9b-4f29-9dad-e4dc4d1d5513">
											<gml:posList>35.670390287602615 139.74062500027975 28.918 35.670390287602615 139.74062500027975 28.373 35.670425041957365 139.74062163516768 28.373 35.670425041957365 139.74062163516768 28.918 35.670390287602615 139.74062500027975 28.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87b1c090-188c-4b75-bf8f-6facd8a6981f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87b1c090-188c-4b75-bf8f-6facd8a6981f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87b1c090-188c-4b75-bf8f-6facd8a6981f">
											<gml:posList>35.67038990535222 139.74065535584643 25.77 35.67038990535222 139.74065535584643 25.056 35.67044557902772 139.74064997823743 25.056 35.67044557902772 139.74064997823743 25.77 35.67038990535222 139.74065535584643 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b39a01d-cfca-44ff-adb3-9eca692f94ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b39a01d-cfca-44ff-adb3-9eca692f94ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b39a01d-cfca-44ff-adb3-9eca692f94ba">
											<gml:posList>35.67044419781951 139.74064724035955 28.918 35.67044419781951 139.74064724035955 28.373 35.670392048254655 139.74065228250882 28.373 35.670392048254655 139.74065228250882 28.918 35.67044419781951 139.74064724035955 28.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aeab1203-6d54-4296-ac70-38868171afb2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aeab1203-6d54-4296-ac70-38868171afb2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aeab1203-6d54-4296-ac70-38868171afb2">
											<gml:posList>35.67044915721203 139.7406496316668 28.918 35.67038990535222 139.74065535584643 28.918 35.67038990535222 139.74065535584643 25.77 35.67044915721203 139.7406496316668 28.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54ce455e-cd36-4fc0-b181-c4934eb790a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54ce455e-cd36-4fc0-b181-c4934eb790a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54ce455e-cd36-4fc0-b181-c4934eb790a8">
											<gml:posList>35.67044915721203 139.7406496316668 28.918 35.67038990535222 139.74065535584643 25.77 35.67044557902772 139.74064997823743 25.77 35.67044915721203 139.7406496316668 28.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf156fa5-e66d-4e04-9709-5a4820d30b40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf156fa5-e66d-4e04-9709-5a4820d30b40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf156fa5-e66d-4e04-9709-5a4820d30b40">
											<gml:posList>35.67044915721203 139.7406496316668 28.918 35.67044557902772 139.74064997823743 25.77 35.670449454970964 139.74065002898828 25.77 35.67044915721203 139.7406496316668 28.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4b39657-bbde-4f86-bdd9-28a9c318c5ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4b39657-bbde-4f86-bdd9-28a9c318c5ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4b39657-bbde-4f86-bdd9-28a9c318c5ba">
											<gml:posList>35.67044557902772 139.74064997823743 25.77 35.67044557902772 139.74064997823743 25.056 35.67045114576006 139.74072710790054 25.056 35.67045114576006 139.74072710790054 25.77 35.67044557902772 139.74064997823743 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d03363f-530e-4e90-a5c9-66c403c58037">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d03363f-530e-4e90-a5c9-66c403c58037">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d03363f-530e-4e90-a5c9-66c403c58037">
											<gml:posList>35.670455376526085 139.74073143315167 10.23 35.670449454970964 139.74065002898828 10.23 35.670449454970964 139.74065002898828 25.77 35.670455376526085 139.74073143315167 25.77 35.670455376526085 139.74073143315167 10.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4882f912-7ea4-48af-b87a-d33f2bd4fc1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4882f912-7ea4-48af-b87a-d33f2bd4fc1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4882f912-7ea4-48af-b87a-d33f2bd4fc1c">
											<gml:posList>35.67045114576006 139.74072710790054 25.77 35.67045114576006 139.74072710790054 25.056 35.67023610521918 139.740750597563 25.056 35.67023610521918 139.740750597563 25.77 35.67045114576006 139.74072710790054 25.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f24514a-98ba-40fc-977f-a2f3f5f213b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f24514a-98ba-40fc-977f-a2f3f5f213b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f24514a-98ba-40fc-977f-a2f3f5f213b3">
											<gml:posList>35.67023257581445 139.74075577127837 10.23 35.670455376526085 139.74073143315167 10.23 35.670455376526085 139.74073143315167 25.77 35.67023257581445 139.74075577127837 25.77 35.67023257581445 139.74075577127837 10.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1271</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">476.78795</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1131</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>