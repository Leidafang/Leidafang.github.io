<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_bd73d935-300c-4459-a1ae-05e5b40f64b4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">13.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669240811826896 139.7385758634741 0 35.669258222107686 139.73859337306686 0 35.66928491483596 139.73855145468437 0 35.66930353284617 139.73856881925457 0 35.66927597516807 139.73861121364544 0 35.669293583910665 139.73862893289515 0 35.669352014488304 139.73854182047387 0 35.66929731327167 139.7383284742968 0 35.66921421449476 139.7384527309072 0 35.669279435400874 139.7385182676083 0 35.669240811826896 139.7385758634741 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669240811826896 139.7385758634741 17.07 35.669279435400874 139.7385182676083 17.07 35.66921421449476 139.7384527309072 17.07 35.66929731327167 139.7383284742968 17.07 35.669352014488304 139.73854182047387 17.07 35.669293583910665 139.73862893289515 17.07 35.66927597516807 139.73861121364544 17.07 35.66930353284617 139.73856881925457 17.07 35.66928491483596 139.73855145468437 17.07 35.669258222107686 139.73859337306686 17.07 35.669240811826896 139.7385758634741 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669240811826896 139.7385758634741 17.07 35.669258222107686 139.73859337306686 17.07 35.669258222107686 139.73859337306686 30.67 35.669240811826896 139.7385758634741 30.67 35.669240811826896 139.7385758634741 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669258222107686 139.73859337306686 17.07 35.66928491483596 139.73855145468437 17.07 35.66928491483596 139.73855145468437 30.67 35.669258222107686 139.73859337306686 30.67 35.669258222107686 139.73859337306686 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66928491483596 139.73855145468437 17.07 35.66930353284617 139.73856881925457 17.07 35.66930353284617 139.73856881925457 30.67 35.66928491483596 139.73855145468437 30.67 35.66928491483596 139.73855145468437 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66930353284617 139.73856881925457 17.07 35.66927597516807 139.73861121364544 17.07 35.66927597516807 139.73861121364544 30.67 35.66930353284617 139.73856881925457 30.67 35.66930353284617 139.73856881925457 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927597516807 139.73861121364544 17.07 35.669293583910665 139.73862893289515 17.07 35.669293583910665 139.73862893289515 30.67 35.66927597516807 139.73861121364544 30.67 35.66927597516807 139.73861121364544 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669293583910665 139.73862893289515 17.07 35.669352014488304 139.73854182047387 17.07 35.669352014488304 139.73854182047387 30.67 35.669293583910665 139.73862893289515 30.67 35.669293583910665 139.73862893289515 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669352014488304 139.73854182047387 17.07 35.66929731327167 139.7383284742968 17.07 35.66929731327167 139.7383284742968 30.67 35.669352014488304 139.73854182047387 30.67 35.669352014488304 139.73854182047387 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66929731327167 139.7383284742968 17.07 35.66921421449476 139.7384527309072 17.07 35.66921421449476 139.7384527309072 30.67 35.66929731327167 139.7383284742968 30.67 35.66929731327167 139.7383284742968 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66921421449476 139.7384527309072 17.07 35.669279435400874 139.7385182676083 17.07 35.669279435400874 139.7385182676083 30.67 35.66921421449476 139.7384527309072 30.67 35.66921421449476 139.7384527309072 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669279435400874 139.7385182676083 17.07 35.669240811826896 139.7385758634741 17.07 35.669240811826896 139.7385758634741 30.67 35.669279435400874 139.7385182676083 30.67 35.669279435400874 139.7385182676083 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669240811826896 139.7385758634741 30.67 35.669258222107686 139.73859337306686 30.67 35.66928491483596 139.73855145468437 30.67 35.66930353284617 139.73856881925457 30.67 35.66927597516807 139.73861121364544 30.67 35.669293583910665 139.73862893289515 30.67 35.669352014488304 139.73854182047387 30.67 35.66929731327167 139.7383284742968 30.67 35.66921421449476 139.7384527309072 30.67 35.669279435400874 139.7385182676083 30.67 35.669240811826896 139.7385758634741 30.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fede88dc-bfcd-4cf3-b482-fb950cc42326"/>
							<gml:surfaceMember xlink:href="#poly-97ce3d08-9bcd-4811-a331-873901977a81"/>
							<gml:surfaceMember xlink:href="#poly-5040bad9-66c1-461c-8b1a-12abe76e7780"/>
							<gml:surfaceMember xlink:href="#poly-d44ec7fd-a8ee-484c-b27a-384cecd78b5c"/>
							<gml:surfaceMember xlink:href="#poly-529b2f6d-e43a-46e2-9763-c3204e0caf20"/>
							<gml:surfaceMember xlink:href="#poly-c27cb67c-6e57-419b-95b2-4381e26528d3"/>
							<gml:surfaceMember xlink:href="#poly-99097d42-8940-4422-86e4-b3667a9ddf54"/>
							<gml:surfaceMember xlink:href="#poly-dc624864-7ef2-4749-a1fa-7e5adb06703f"/>
							<gml:surfaceMember xlink:href="#poly-cbba3ffc-4e07-4f31-ad49-ddd0f37fa8db"/>
							<gml:surfaceMember xlink:href="#poly-aa8411b3-1564-4c5c-b8d9-20050f5e1103"/>
							<gml:surfaceMember xlink:href="#poly-3ac6e979-4218-4d5f-81fc-d05637591ca8"/>
							<gml:surfaceMember xlink:href="#poly-c48e5787-7c98-48fb-90d8-293f59e64609"/>
							<gml:surfaceMember xlink:href="#poly-7d74ad26-7f16-4dbe-b3fc-7168ef3b79af"/>
							<gml:surfaceMember xlink:href="#poly-5a823b50-47dd-4c58-a52e-998e1bf403d3"/>
							<gml:surfaceMember xlink:href="#poly-418553d0-71f3-43ad-a4c0-85c4aae76d23"/>
							<gml:surfaceMember xlink:href="#poly-6367c19f-0849-4565-95a8-2f35ecbbb63b"/>
							<gml:surfaceMember xlink:href="#poly-3afba555-1a5b-4baf-a8ec-86193eab8e7c"/>
							<gml:surfaceMember xlink:href="#poly-001cf821-ebc3-46b3-bb5a-aec6c9754962"/>
							<gml:surfaceMember xlink:href="#poly-1dc425f9-39b2-4083-a675-d7127d4ddf63"/>
							<gml:surfaceMember xlink:href="#poly-1892da58-5847-4417-859c-f85e255cb772"/>
							<gml:surfaceMember xlink:href="#poly-0df2f355-2522-4808-91a0-880743c3eaf2"/>
							<gml:surfaceMember xlink:href="#poly-d50e7f6d-5e35-406e-ad2e-86e29372dc22"/>
							<gml:surfaceMember xlink:href="#poly-6d890438-7b34-46f9-a70a-788ac64a923c"/>
							<gml:surfaceMember xlink:href="#poly-c66f9002-9e2d-49e6-a9dd-086489fd81c9"/>
							<gml:surfaceMember xlink:href="#poly-4a9133f2-0406-4ce1-8bdc-545a5502ea40"/>
							<gml:surfaceMember xlink:href="#poly-aa6bbe31-76af-4a47-8cbe-b88798312214"/>
							<gml:surfaceMember xlink:href="#poly-2b4ab89d-82bd-42e1-a322-34e00376a3ab"/>
							<gml:surfaceMember xlink:href="#poly-ea90c6bf-fe32-4470-a737-3fae92d6f16e"/>
							<gml:surfaceMember xlink:href="#poly-99e4541e-c725-411c-bfd4-10de8f4050d3"/>
							<gml:surfaceMember xlink:href="#poly-b7e768b9-872c-498e-9c78-9481f58fec4b"/>
							<gml:surfaceMember xlink:href="#poly-0a1cbb65-5f55-4933-914b-231821f5a8f7"/>
							<gml:surfaceMember xlink:href="#poly-4d6b29d0-050a-4b6c-985f-5c6525667832"/>
							<gml:surfaceMember xlink:href="#poly-69e10f05-7ec1-4f8a-85a6-6fc52747508e"/>
							<gml:surfaceMember xlink:href="#poly-2e86e18f-3b82-434a-b124-d3fe3e981798"/>
							<gml:surfaceMember xlink:href="#poly-9dcbcbf0-0f63-42f0-a092-023d402fb79c"/>
							<gml:surfaceMember xlink:href="#poly-9daec16a-1bd2-4916-ae90-3785ad74d962"/>
							<gml:surfaceMember xlink:href="#poly-9ebf49e3-1b6b-4f04-9838-e595aa7d1fb4"/>
							<gml:surfaceMember xlink:href="#poly-6507a5b7-ded8-48e1-9283-fb4e6bf1e1c0"/>
							<gml:surfaceMember xlink:href="#poly-f3ead9c5-790e-4c6a-899a-6e9d0b81029a"/>
							<gml:surfaceMember xlink:href="#poly-270f4acd-00a7-4399-978c-450483bc5a46"/>
							<gml:surfaceMember xlink:href="#poly-af3426e2-2d6a-48eb-b1cb-e56b9470b3b2"/>
							<gml:surfaceMember xlink:href="#poly-26b7b2ef-6f5d-4370-86b8-3c84234f2a91"/>
							<gml:surfaceMember xlink:href="#poly-4354f827-b585-4846-8e47-1e25376696cd"/>
							<gml:surfaceMember xlink:href="#poly-03769603-9cef-4e44-9bd3-1c35566eb4f2"/>
							<gml:surfaceMember xlink:href="#poly-9be98f66-fc0b-4c10-8f48-ea879883a9a2"/>
							<gml:surfaceMember xlink:href="#poly-7bb457ea-1917-406f-bada-f3caef8270c2"/>
							<gml:surfaceMember xlink:href="#poly-77605f7c-04d8-44b7-a906-cc7de467f84f"/>
							<gml:surfaceMember xlink:href="#poly-e59c8c19-0de5-46c2-8563-7ec676cf565b"/>
							<gml:surfaceMember xlink:href="#poly-1afb498f-0def-4b01-a8fa-573b1d37b361"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bd73d935-300c-4459-a1ae-05e5b40f64b4_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd8120ee-30c3-457d-b8e8-a4094acd8874">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927314605898 139.73846389506215 31.355 35.669257885748614 139.7384867012319 31.355 35.66925144484232 139.73848022478796 31.355 35.66926748842289 139.7384562468048 31.355 35.66927392933045 139.73846272324803 31.355 35.66927314605898 139.73846389506215 31.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b20a660a-d7ed-48e3-8dcb-fa636d24726d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927597516807 139.73861121364544 17.07 35.66925822210767 139.73859337306683 17.07 35.66928491483595 139.7385514546844 17.07 35.66930349683472 139.7385688745277 17.07 35.66927597516807 139.73861121364544 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01d1929f-212e-4fce-8a80-49e54111db32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01d1929f-212e-4fce-8a80-49e54111db32_0">
											<gml:posList>35.66925144484232 139.73848022478796 31.355 35.669257885748614 139.7384867012319 31.355 35.669257885748614 139.7384867012319 32.243 35.66925144484232 139.73848022478796 32.243 35.66925144484232 139.73848022478796 31.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f18c50b6-581b-4e8e-b968-4e00046afd6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f18c50b6-581b-4e8e-b968-4e00046afd6e_0">
											<gml:posList>35.66925144484232 139.73848022478796 31.355 35.66925144484232 139.73848022478796 32.243 35.66926748842289 139.7384562468048 32.243 35.66926748842289 139.7384562468048 31.355 35.66925144484232 139.73848022478796 31.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-314181a3-0ca3-407b-a464-7656a1187547">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-314181a3-0ca3-407b-a464-7656a1187547_0">
											<gml:posList>35.66926748842289 139.7384562468048 32.243 35.66925144484232 139.73848022478796 32.243 35.669257885748614 139.7384867012319 32.243 35.66927314605898 139.73846389506215 32.243 35.66927392933045 139.73846272324803 32.243 35.66926748842289 139.7384562468048 32.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98cb0711-159c-4046-ad52-22355a52d228">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98cb0711-159c-4046-ad52-22355a52d228_0">
											<gml:posList>35.66927314605898 139.73846389506215 32.243 35.669257885748614 139.7384867012319 32.243 35.669257885748614 139.7384867012319 31.355 35.66927314605898 139.73846389506215 31.355 35.66927314605898 139.73846389506215 32.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42aaedb0-eea9-4e99-8b31-b12ed871e787">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42aaedb0-eea9-4e99-8b31-b12ed871e787_0">
											<gml:posList>35.66925822210767 139.73859337306683 17.07 35.66927597516807 139.73861121364544 17.07 35.66927597516807 139.73861121364544 32.128 35.66925822210767 139.73859337306683 32.128 35.66925822210767 139.73859337306683 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a043af79-9664-46cc-ade8-10c96277a84d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a043af79-9664-46cc-ade8-10c96277a84d_0">
											<gml:posList>35.66927392933045 139.73846272324803 31.355 35.66926748842289 139.7384562468048 31.355 35.66926748842289 139.7384562468048 32.243 35.66927392933045 139.73846272324803 32.243 35.66927392933045 139.73846272324803 31.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbd30cdc-68c9-4da5-8d43-5183df2d1c5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbd30cdc-68c9-4da5-8d43-5183df2d1c5f_0">
											<gml:posList>35.66928491483595 139.7385514546844 17.07 35.66925822210767 139.73859337306683 17.07 35.66925822210767 139.73859337306683 32.128 35.66928491483595 139.7385514546844 32.128 35.66928491483595 139.7385514546844 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53b321ab-842a-4d2a-9802-78927c805f5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53b321ab-842a-4d2a-9802-78927c805f5b_0">
											<gml:posList>35.66927314605898 139.73846389506215 31.355 35.66927392933045 139.73846272324803 31.355 35.66927392933045 139.73846272324803 32.243 35.66927314605898 139.73846389506215 32.243 35.66927314605898 139.73846389506215 31.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e4ab70f-a3f8-4f28-901d-66f4b6f61e0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e4ab70f-a3f8-4f28-901d-66f4b6f61e0f_0">
											<gml:posList>35.66927597516807 139.73861121364544 32.128 35.66930349683472 139.7385688745277 32.128 35.66928491483595 139.7385514546844 32.128 35.66925822210767 139.73859337306683 32.128 35.66927597516807 139.73861121364544 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-264f3cdc-3812-41c9-8474-e94a50bcb9dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-264f3cdc-3812-41c9-8474-e94a50bcb9dc_0">
											<gml:posList>35.66930349683472 139.7385688745277 17.07 35.66930349683472 139.7385688745277 32.128 35.66927597516807 139.73861121364544 32.128 35.66927597516807 139.73861121364544 17.07 35.66930349683472 139.7385688745277 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1c08edd-cc8b-49a5-8929-21f4b4525a36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1c08edd-cc8b-49a5-8929-21f4b4525a36_0">
											<gml:posList>35.66930349683472 139.7385688745277 32.128 35.66930349683472 139.7385688745277 17.07 35.66928491483595 139.7385514546844 17.07 35.66928491483595 139.7385514546844 32.128 35.66930349683472 139.7385688745277 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bd73d935-300c-4459-a1ae-05e5b40f64b4_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75ccffd1-514c-4cfa-bc95-699de6764067">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927714679866 139.7385308407847 31.355 35.66928683418951 139.73851638102064 31.355 35.66929481765822 139.73852440210166 31.355 35.66928513928884 139.73853887290161 31.355 35.66927714679866 139.7385308407847 31.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff2141b2-c94f-4468-8abb-9fecc5c605a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff2141b2-c94f-4468-8abb-9fecc5c605a7_0">
											<gml:posList>35.66928683418951 139.73851638102064 31.355 35.66928683418951 139.73851638102064 34.145 35.66929481765822 139.73852440210166 34.145 35.66929481765822 139.73852440210166 31.355 35.66928683418951 139.73851638102064 31.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d826f2bd-d0a1-470d-b2b9-e1447e239551">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d826f2bd-d0a1-470d-b2b9-e1447e239551_0">
											<gml:posList>35.66927714679866 139.7385308407847 31.355 35.66927714679866 139.7385308407847 34.145 35.66928683418951 139.73851638102064 34.145 35.66928683418951 139.73851638102064 31.355 35.66927714679866 139.7385308407847 31.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddece1f5-a75d-4028-9941-6d5d24ed3c95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddece1f5-a75d-4028-9941-6d5d24ed3c95_0">
											<gml:posList>35.66927714679866 139.7385308407847 34.145 35.66928513928884 139.73853887290161 34.145 35.66929481765822 139.73852440210166 34.145 35.66928683418951 139.73851638102064 34.145 35.66927714679866 139.7385308407847 34.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd97bb80-9f0e-4c66-a1e5-4e55a15870e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd97bb80-9f0e-4c66-a1e5-4e55a15870e3_0">
											<gml:posList>35.66929481765822 139.73852440210166 31.355 35.66929481765822 139.73852440210166 34.145 35.66928513928884 139.73853887290161 34.145 35.66928513928884 139.73853887290161 31.355 35.66929481765822 139.73852440210166 31.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d570fa0d-ae83-4973-bf49-4a178e69d4bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d570fa0d-ae83-4973-bf49-4a178e69d4bb_0">
											<gml:posList>35.66928513928884 139.73853887290161 31.355 35.66928513928884 139.73853887290161 34.145 35.66927714679866 139.7385308407847 34.145 35.66927714679866 139.7385308407847 31.355 35.66928513928884 139.73853887290161 31.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fede88dc-bfcd-4cf3-b482-fb950cc42326">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fede88dc-bfcd-4cf3-b482-fb950cc42326">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fede88dc-bfcd-4cf3-b482-fb950cc42326">
											<gml:posList>35.66928491483595 139.7385514546844 17.07 35.66925822210767 139.73859337306683 17.07 35.66924081182688 139.73857586347413 17.07 35.66927943540087 139.7385182676083 17.07 35.66921421449476 139.7384527309072 17.07 35.669297313271635 139.73832847429676 17.07 35.66935201448829 139.73854182047387 17.07 35.669293583910644 139.73862893289515 17.07 35.66927597516807 139.73861121364544 17.07 35.66930353284615 139.73856881925457 17.07 35.66928491483595 139.7385514546844 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97ce3d08-9bcd-4811-a331-873901977a81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97ce3d08-9bcd-4811-a331-873901977a81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97ce3d08-9bcd-4811-a331-873901977a81">
											<gml:posList>35.669289433894164 139.73839530154603 32.128 35.669297313271635 139.73832847429676 28.55 35.66921421449476 139.7384527309072 28.55 35.669289433894164 139.73839530154603 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5040bad9-66c1-461c-8b1a-12abe76e7780">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5040bad9-66c1-461c-8b1a-12abe76e7780">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5040bad9-66c1-461c-8b1a-12abe76e7780">
											<gml:posList>35.66935201448829 139.73854182047387 28.55 35.669297313271635 139.73832847429676 28.55 35.669289433894164 139.73839530154603 32.128 35.66935201448829 139.73854182047387 28.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d44ec7fd-a8ee-484c-b27a-384cecd78b5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d44ec7fd-a8ee-484c-b27a-384cecd78b5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d44ec7fd-a8ee-484c-b27a-384cecd78b5c">
											<gml:posList>35.66921421449476 139.7384527309072 28.55 35.66923720870044 139.73847583423458 32.128 35.669289433894164 139.73839530154603 32.128 35.66921421449476 139.7384527309072 28.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-529b2f6d-e43a-46e2-9763-c3204e0caf20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-529b2f6d-e43a-46e2-9763-c3204e0caf20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-529b2f6d-e43a-46e2-9763-c3204e0caf20">
											<gml:posList>35.66923720870044 139.73847583423458 32.128 35.6692383713577 139.73847568925976 32.128 35.6692890930709 139.7383974559408 32.128 35.669289433894164 139.73839530154603 32.128 35.66923720870044 139.73847583423458 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c27cb67c-6e57-419b-95b2-4381e26528d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c27cb67c-6e57-419b-95b2-4381e26528d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c27cb67c-6e57-419b-95b2-4381e26528d3">
											<gml:posList>35.669272281751 139.73846517743314 31.355 35.6692890930709 139.7383974559408 31.355 35.6692383713577 139.73847568925976 31.355 35.669256040101644 139.73848945389508 31.355 35.669272281751 139.73846517743314 31.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-99097d42-8940-4422-86e4-b3667a9ddf54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99097d42-8940-4422-86e4-b3667a9ddf54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99097d42-8940-4422-86e4-b3667a9ddf54">
											<gml:posList>35.66932354547902 139.73853719267066 32.128 35.669289433894164 139.73839530154603 32.128 35.6692890930709 139.7383974559408 32.128 35.66932262589657 139.7385369617895 32.128 35.66932354547902 139.73853719267066 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc624864-7ef2-4749-a1fa-7e5adb06703f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc624864-7ef2-4749-a1fa-7e5adb06703f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc624864-7ef2-4749-a1fa-7e5adb06703f">
											<gml:posList>35.669289433894164 139.73839530154603 32.128 35.66932354547902 139.73853719267066 32.128 35.66935201448829 139.73854182047387 28.55 35.669289433894164 139.73839530154603 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cbba3ffc-4e07-4f31-ad49-ddd0f37fa8db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbba3ffc-4e07-4f31-ad49-ddd0f37fa8db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbba3ffc-4e07-4f31-ad49-ddd0f37fa8db">
											<gml:posList>35.669256040101644 139.73848945389508 36.086 35.669259167568015 139.73848907462812 36.086 35.669272591228655 139.73846899901986 36.086 35.669272281751 139.73846517743314 36.086 35.669256040101644 139.73848945389508 36.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa8411b3-1564-4c5c-b8d9-20050f5e1103">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa8411b3-1564-4c5c-b8d9-20050f5e1103">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa8411b3-1564-4c5c-b8d9-20050f5e1103">
											<gml:posList>35.669272281751 139.73846517743314 36.086 35.669272591228655 139.73846899901986 36.086 35.66929625296858 139.7384927643457 36.086 35.66929938044364 139.73849239612474 36.086 35.669272281751 139.73846517743314 36.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ac6e979-4218-4d5f-81fc-d05637591ca8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ac6e979-4218-4d5f-81fc-d05637591ca8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ac6e979-4218-4d5f-81fc-d05637591ca8">
											<gml:posList>35.66929625296858 139.7384927643457 31.564 35.669272591228655 139.73846899901986 31.564 35.669259167568015 139.73848907462812 31.564 35.669282829304045 139.7385128399559 31.564 35.66929625296858 139.7384927643457 31.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c48e5787-7c98-48fb-90d8-293f59e64609">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c48e5787-7c98-48fb-90d8-293f59e64609">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c48e5787-7c98-48fb-90d8-293f59e64609">
											<gml:posList>35.66928313878889 139.7385166725894 31.355 35.669256040101644 139.73848945389508 31.355 35.6692383713577 139.73847568925976 31.355 35.6692806070719 139.7385181226234 31.355 35.66924199250302 139.73857570743337 31.355 35.669258094759655 139.7385919040854 31.355 35.669284769486055 139.73855001886213 31.355 35.6693033424713 139.7385674387157 31.355 35.66932262589657 139.7385369617895 31.355 35.6692890930709 139.7383974559408 31.355 35.669272281751 139.73846517743314 31.355 35.66929938044364 139.73849239612474 31.355 35.66928313878889 139.7385166725894 31.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d74ad26-7f16-4dbe-b3fc-7168ef3b79af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d74ad26-7f16-4dbe-b3fc-7168ef3b79af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d74ad26-7f16-4dbe-b3fc-7168ef3b79af">
											<gml:posList>35.66927943540087 139.7385182676083 32.128 35.6692806070719 139.7385181226234 32.128 35.6692383713577 139.73847568925976 32.128 35.66923720870044 139.73847583423458 32.128 35.66927943540087 139.7385182676083 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5a823b50-47dd-4c58-a52e-998e1bf403d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a823b50-47dd-4c58-a52e-998e1bf403d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a823b50-47dd-4c58-a52e-998e1bf403d3">
											<gml:posList>35.66928313878889 139.7385166725894 36.086 35.669282829304045 139.7385128399559 36.086 35.669259167568015 139.73848907462812 36.086 35.669256040101644 139.73848945389508 36.086 35.66928313878889 139.7385166725894 36.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-418553d0-71f3-43ad-a4c0-85c4aae76d23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-418553d0-71f3-43ad-a4c0-85c4aae76d23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-418553d0-71f3-43ad-a4c0-85c4aae76d23">
											<gml:posList>35.66929938044364 139.73849239612474 36.086 35.66929625296858 139.7384927643457 36.086 35.669282829304045 139.7385128399559 36.086 35.66928313878889 139.7385166725894 36.086 35.66929938044364 139.73849239612474 36.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6367c19f-0849-4565-95a8-2f35ecbbb63b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6367c19f-0849-4565-95a8-2f35ecbbb63b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6367c19f-0849-4565-95a8-2f35ecbbb63b">
											<gml:posList>35.66927943540087 139.7385182676083 32.128 35.66924081182688 139.73857586347413 32.128 35.66924199250302 139.73857570743337 32.128 35.6692806070719 139.7385181226234 32.128 35.66927943540087 139.7385182676083 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3afba555-1a5b-4baf-a8ec-86193eab8e7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3afba555-1a5b-4baf-a8ec-86193eab8e7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3afba555-1a5b-4baf-a8ec-86193eab8e7c">
											<gml:posList>35.66932354547902 139.73853719267066 32.128 35.66932262589657 139.7385369617895 32.128 35.6693033424713 139.7385674387157 32.128 35.66930349683472 139.7385688745277 32.128 35.66932354547902 139.73853719267066 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-001cf821-ebc3-46b3-bb5a-aec6c9754962">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-001cf821-ebc3-46b3-bb5a-aec6c9754962">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-001cf821-ebc3-46b3-bb5a-aec6c9754962">
											<gml:posList>35.66928491483595 139.7385514546844 32.128 35.66930349683472 139.7385688745277 32.128 35.6693033424713 139.7385674387157 32.128 35.669284769486055 139.73855001886213 32.128 35.66928491483595 139.7385514546844 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1dc425f9-39b2-4083-a675-d7127d4ddf63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1dc425f9-39b2-4083-a675-d7127d4ddf63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1dc425f9-39b2-4083-a675-d7127d4ddf63">
											<gml:posList>35.66928491483595 139.7385514546844 32.128 35.669284769486055 139.73855001886213 32.128 35.669258094759655 139.7385919040854 32.128 35.66925822210767 139.73859337306683 32.128 35.66928491483595 139.7385514546844 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1892da58-5847-4417-859c-f85e255cb772">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1892da58-5847-4417-859c-f85e255cb772">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1892da58-5847-4417-859c-f85e255cb772">
											<gml:posList>35.669293583910644 139.73862893289515 28.55 35.66935201448829 139.73854182047387 28.55 35.66932354547902 139.73853719267066 32.128 35.669293583910644 139.73862893289515 28.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0df2f355-2522-4808-91a0-880743c3eaf2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0df2f355-2522-4808-91a0-880743c3eaf2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0df2f355-2522-4808-91a0-880743c3eaf2">
											<gml:posList>35.669293583910644 139.73862893289515 28.55 35.66932354547902 139.73853719267066 32.128 35.66930349683472 139.7385688745277 32.128 35.669293583910644 139.73862893289515 28.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d50e7f6d-5e35-406e-ad2e-86e29372dc22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d50e7f6d-5e35-406e-ad2e-86e29372dc22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d50e7f6d-5e35-406e-ad2e-86e29372dc22">
											<gml:posList>35.66925822210767 139.73859337306683 32.128 35.669258094759655 139.7385919040854 32.128 35.66924199250302 139.73857570743337 32.128 35.66924081182688 139.73857586347413 32.128 35.66925822210767 139.73859337306683 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d890438-7b34-46f9-a70a-788ac64a923c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d890438-7b34-46f9-a70a-788ac64a923c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d890438-7b34-46f9-a70a-788ac64a923c">
											<gml:posList>35.669293583910644 139.73862893289515 28.55 35.66930349683472 139.7385688745277 32.128 35.66927597516807 139.73861121364544 32.128 35.669293583910644 139.73862893289515 28.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c66f9002-9e2d-49e6-a9dd-086489fd81c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c66f9002-9e2d-49e6-a9dd-086489fd81c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c66f9002-9e2d-49e6-a9dd-086489fd81c9">
											<gml:posList>35.669272591228655 139.73846899901986 36.086 35.669272591228655 139.73846899901986 31.564 35.66929625296858 139.7384927643457 31.564 35.66929625296858 139.7384927643457 36.086 35.669272591228655 139.73846899901986 36.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a9133f2-0406-4ce1-8bdc-545a5502ea40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a9133f2-0406-4ce1-8bdc-545a5502ea40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a9133f2-0406-4ce1-8bdc-545a5502ea40">
											<gml:posList>35.669282829304045 139.7385128399559 36.086 35.669282829304045 139.7385128399559 31.564 35.669259167568015 139.73848907462812 31.564 35.669259167568015 139.73848907462812 36.086 35.669282829304045 139.7385128399559 36.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa6bbe31-76af-4a47-8cbe-b88798312214">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa6bbe31-76af-4a47-8cbe-b88798312214">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa6bbe31-76af-4a47-8cbe-b88798312214">
											<gml:posList>35.669284769486055 139.73855001886213 32.128 35.669284769486055 139.73855001886213 31.355 35.669258094759655 139.7385919040854 31.355 35.669258094759655 139.7385919040854 32.128 35.669284769486055 139.73855001886213 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b4ab89d-82bd-42e1-a322-34e00376a3ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b4ab89d-82bd-42e1-a322-34e00376a3ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b4ab89d-82bd-42e1-a322-34e00376a3ab">
											<gml:posList>35.669297313271635 139.73832847429676 17.07 35.66921421449476 139.7384527309072 17.07 35.66921421449476 139.7384527309072 28.55 35.669297313271635 139.73832847429676 28.55 35.669297313271635 139.73832847429676 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea90c6bf-fe32-4470-a737-3fae92d6f16e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea90c6bf-fe32-4470-a737-3fae92d6f16e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea90c6bf-fe32-4470-a737-3fae92d6f16e">
											<gml:posList>35.66935201448829 139.73854182047387 17.07 35.669297313271635 139.73832847429676 17.07 35.669297313271635 139.73832847429676 28.55 35.66935201448829 139.73854182047387 28.55 35.66935201448829 139.73854182047387 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99e4541e-c725-411c-bfd4-10de8f4050d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99e4541e-c725-411c-bfd4-10de8f4050d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99e4541e-c725-411c-bfd4-10de8f4050d3">
											<gml:posList>35.6692383713577 139.73847568925976 32.128 35.6692383713577 139.73847568925976 31.355 35.6692890930709 139.7383974559408 31.355 35.6692890930709 139.7383974559408 32.128 35.6692383713577 139.73847568925976 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7e768b9-872c-498e-9c78-9481f58fec4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7e768b9-872c-498e-9c78-9481f58fec4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7e768b9-872c-498e-9c78-9481f58fec4b">
											<gml:posList>35.6692890930709 139.7383974559408 32.128 35.6692890930709 139.7383974559408 31.355 35.66932262589657 139.7385369617895 31.355 35.66932262589657 139.7385369617895 32.128 35.6692890930709 139.7383974559408 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a1cbb65-5f55-4933-914b-231821f5a8f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a1cbb65-5f55-4933-914b-231821f5a8f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a1cbb65-5f55-4933-914b-231821f5a8f7">
											<gml:posList>35.669256040101644 139.73848945389508 36.086 35.669272281751 139.73846517743314 36.086 35.669272281751 139.73846517743314 31.355 35.669256040101644 139.73848945389508 31.355 35.669256040101644 139.73848945389508 36.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d6b29d0-050a-4b6c-985f-5c6525667832">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d6b29d0-050a-4b6c-985f-5c6525667832">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d6b29d0-050a-4b6c-985f-5c6525667832">
											<gml:posList>35.669272281751 139.73846517743314 31.355 35.669272281751 139.73846517743314 36.086 35.66929938044364 139.73849239612474 36.086 35.66929938044364 139.73849239612474 31.355 35.669272281751 139.73846517743314 31.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69e10f05-7ec1-4f8a-85a6-6fc52747508e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69e10f05-7ec1-4f8a-85a6-6fc52747508e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69e10f05-7ec1-4f8a-85a6-6fc52747508e">
											<gml:posList>35.669259167568015 139.73848907462812 36.086 35.669259167568015 139.73848907462812 31.564 35.669272591228655 139.73846899901986 31.564 35.669272591228655 139.73846899901986 36.086 35.669259167568015 139.73848907462812 36.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e86e18f-3b82-434a-b124-d3fe3e981798">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e86e18f-3b82-434a-b124-d3fe3e981798">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e86e18f-3b82-434a-b124-d3fe3e981798">
											<gml:posList>35.66927943540087 139.7385182676083 32.128 35.66923720870044 139.73847583423458 32.128 35.66921421449476 139.7384527309072 28.55 35.66921421449476 139.7384527309072 17.07 35.66927943540087 139.7385182676083 17.07 35.66927943540087 139.7385182676083 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9dcbcbf0-0f63-42f0-a092-023d402fb79c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dcbcbf0-0f63-42f0-a092-023d402fb79c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dcbcbf0-0f63-42f0-a092-023d402fb79c">
											<gml:posList>35.6692806070719 139.7385181226234 32.128 35.6692806070719 139.7385181226234 31.355 35.6692383713577 139.73847568925976 31.355 35.6692383713577 139.73847568925976 32.128 35.6692806070719 139.7385181226234 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9daec16a-1bd2-4916-ae90-3785ad74d962">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9daec16a-1bd2-4916-ae90-3785ad74d962">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9daec16a-1bd2-4916-ae90-3785ad74d962">
											<gml:posList>35.66929625296858 139.7384927643457 36.086 35.66929625296858 139.7384927643457 31.564 35.669282829304045 139.7385128399559 31.564 35.669282829304045 139.7385128399559 36.086 35.66929625296858 139.7384927643457 36.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ebf49e3-1b6b-4f04-9838-e595aa7d1fb4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ebf49e3-1b6b-4f04-9838-e595aa7d1fb4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ebf49e3-1b6b-4f04-9838-e595aa7d1fb4">
											<gml:posList>35.66928313878889 139.7385166725894 31.355 35.66928313878889 139.7385166725894 36.086 35.669256040101644 139.73848945389508 36.086 35.669256040101644 139.73848945389508 31.355 35.66928313878889 139.7385166725894 31.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6507a5b7-ded8-48e1-9283-fb4e6bf1e1c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6507a5b7-ded8-48e1-9283-fb4e6bf1e1c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6507a5b7-ded8-48e1-9283-fb4e6bf1e1c0">
											<gml:posList>35.66929938044364 139.73849239612474 31.355 35.66929938044364 139.73849239612474 36.086 35.66928313878889 139.7385166725894 36.086 35.66928313878889 139.7385166725894 31.355 35.66929938044364 139.73849239612474 31.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3ead9c5-790e-4c6a-899a-6e9d0b81029a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3ead9c5-790e-4c6a-899a-6e9d0b81029a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3ead9c5-790e-4c6a-899a-6e9d0b81029a">
											<gml:posList>35.66924199250302 139.73857570743337 32.128 35.66924199250302 139.73857570743337 31.355 35.6692806070719 139.7385181226234 31.355 35.6692806070719 139.7385181226234 32.128 35.66924199250302 139.73857570743337 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-270f4acd-00a7-4399-978c-450483bc5a46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-270f4acd-00a7-4399-978c-450483bc5a46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-270f4acd-00a7-4399-978c-450483bc5a46">
											<gml:posList>35.66927943540087 139.7385182676083 17.07 35.66924081182688 139.73857586347413 17.07 35.66924081182688 139.73857586347413 32.128 35.66927943540087 139.7385182676083 32.128 35.66927943540087 139.7385182676083 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af3426e2-2d6a-48eb-b1cb-e56b9470b3b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af3426e2-2d6a-48eb-b1cb-e56b9470b3b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af3426e2-2d6a-48eb-b1cb-e56b9470b3b2">
											<gml:posList>35.66932262589657 139.7385369617895 32.128 35.66932262589657 139.7385369617895 31.355 35.6693033424713 139.7385674387157 31.355 35.6693033424713 139.7385674387157 32.128 35.66932262589657 139.7385369617895 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26b7b2ef-6f5d-4370-86b8-3c84234f2a91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26b7b2ef-6f5d-4370-86b8-3c84234f2a91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26b7b2ef-6f5d-4370-86b8-3c84234f2a91">
											<gml:posList>35.6693033424713 139.7385674387157 32.128 35.6693033424713 139.7385674387157 31.355 35.669284769486055 139.73855001886213 31.355 35.669284769486055 139.73855001886213 32.128 35.6693033424713 139.7385674387157 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4354f827-b585-4846-8e47-1e25376696cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4354f827-b585-4846-8e47-1e25376696cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4354f827-b585-4846-8e47-1e25376696cd">
											<gml:posList>35.66928491483595 139.7385514546844 17.07 35.66930353284615 139.73856881925457 17.07 35.66930349683472 139.7385688745277 32.128 35.66928491483595 139.7385514546844 32.128 35.66928491483595 139.7385514546844 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03769603-9cef-4e44-9bd3-1c35566eb4f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03769603-9cef-4e44-9bd3-1c35566eb4f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03769603-9cef-4e44-9bd3-1c35566eb4f2">
											<gml:posList>35.66925822210767 139.73859337306683 17.07 35.66928491483595 139.7385514546844 17.07 35.66928491483595 139.7385514546844 32.128 35.66925822210767 139.73859337306683 32.128 35.66925822210767 139.73859337306683 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9be98f66-fc0b-4c10-8f48-ea879883a9a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9be98f66-fc0b-4c10-8f48-ea879883a9a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9be98f66-fc0b-4c10-8f48-ea879883a9a2">
											<gml:posList>35.669258094759655 139.7385919040854 32.128 35.669258094759655 139.7385919040854 31.355 35.66924199250302 139.73857570743337 31.355 35.66924199250302 139.73857570743337 32.128 35.669258094759655 139.7385919040854 32.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7bb457ea-1917-406f-bada-f3caef8270c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bb457ea-1917-406f-bada-f3caef8270c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bb457ea-1917-406f-bada-f3caef8270c2">
											<gml:posList>35.66924081182688 139.73857586347413 17.07 35.66925822210767 139.73859337306683 17.07 35.66925822210767 139.73859337306683 32.128 35.66924081182688 139.73857586347413 32.128 35.66924081182688 139.73857586347413 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77605f7c-04d8-44b7-a906-cc7de467f84f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77605f7c-04d8-44b7-a906-cc7de467f84f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77605f7c-04d8-44b7-a906-cc7de467f84f">
											<gml:posList>35.669293583910644 139.73862893289515 17.07 35.66935201448829 139.73854182047387 17.07 35.66935201448829 139.73854182047387 28.55 35.669293583910644 139.73862893289515 28.55 35.669293583910644 139.73862893289515 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e59c8c19-0de5-46c2-8563-7ec676cf565b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e59c8c19-0de5-46c2-8563-7ec676cf565b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e59c8c19-0de5-46c2-8563-7ec676cf565b">
											<gml:posList>35.66930353284615 139.73856881925457 17.07 35.66927597516807 139.73861121364544 17.07 35.66927597516807 139.73861121364544 32.128 35.66930349683472 139.7385688745277 32.128 35.66930353284615 139.73856881925457 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1afb498f-0def-4b01-a8fa-573b1d37b361">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1afb498f-0def-4b01-a8fa-573b1d37b361">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1afb498f-0def-4b01-a8fa-573b1d37b361">
											<gml:posList>35.66927597516807 139.73861121364544 17.07 35.669293583910644 139.73862893289515 17.07 35.669293583910644 139.73862893289515 28.55 35.66927597516807 139.73861121364544 32.128 35.66927597516807 139.73861121364544 17.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11276</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">203.5532</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>