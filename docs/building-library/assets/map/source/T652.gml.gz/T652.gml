<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_bdeef334-c369-41ba-8a2f-2a694c0ca237">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">13.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66832062725209 139.73849620483887 0 35.66831584623677 139.73849146072442 0 35.66828154456125 139.73854308597717 0 35.6683564173511 139.73861781189075 0 35.66834400213196 139.738636527398 0 35.66841013342837 139.73870218397053 0 35.668492041360565 139.73857627337375 0 35.668356450424945 139.73844229122238 0 35.66832062725209 139.73849620483887 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66832062725209 139.73849620483887 15.26 35.668356450424945 139.73844229122238 15.26 35.668492041360565 139.73857627337375 15.26 35.66841013342837 139.73870218397053 15.26 35.66834400213196 139.738636527398 15.26 35.6683564173511 139.73861781189075 15.26 35.66828154456125 139.73854308597717 15.26 35.66831584623677 139.73849146072442 15.26 35.66832062725209 139.73849620483887 15.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66832062725209 139.73849620483887 15.26 35.66831584623677 139.73849146072442 15.26 35.66831584623677 139.73849146072442 28.95 35.66832062725209 139.73849620483887 28.95 35.66832062725209 139.73849620483887 15.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66831584623677 139.73849146072442 15.26 35.66828154456125 139.73854308597717 15.26 35.66828154456125 139.73854308597717 28.95 35.66831584623677 139.73849146072442 28.95 35.66831584623677 139.73849146072442 15.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66828154456125 139.73854308597717 15.26 35.6683564173511 139.73861781189075 15.26 35.6683564173511 139.73861781189075 28.95 35.66828154456125 139.73854308597717 28.95 35.66828154456125 139.73854308597717 15.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6683564173511 139.73861781189075 15.26 35.66834400213196 139.738636527398 15.26 35.66834400213196 139.738636527398 28.95 35.6683564173511 139.73861781189075 28.95 35.6683564173511 139.73861781189075 15.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66834400213196 139.738636527398 15.26 35.66841013342837 139.73870218397053 15.26 35.66841013342837 139.73870218397053 28.95 35.66834400213196 139.738636527398 28.95 35.66834400213196 139.738636527398 15.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66841013342837 139.73870218397053 15.26 35.668492041360565 139.73857627337375 15.26 35.668492041360565 139.73857627337375 28.95 35.66841013342837 139.73870218397053 28.95 35.66841013342837 139.73870218397053 15.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668492041360565 139.73857627337375 15.26 35.668356450424945 139.73844229122238 15.26 35.668356450424945 139.73844229122238 28.95 35.668492041360565 139.73857627337375 28.95 35.668492041360565 139.73857627337375 15.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668356450424945 139.73844229122238 15.26 35.66832062725209 139.73849620483887 15.26 35.66832062725209 139.73849620483887 28.95 35.668356450424945 139.73844229122238 28.95 35.668356450424945 139.73844229122238 15.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66832062725209 139.73849620483887 28.95 35.66831584623677 139.73849146072442 28.95 35.66828154456125 139.73854308597717 28.95 35.6683564173511 139.73861781189075 28.95 35.66834400213196 139.738636527398 28.95 35.66841013342837 139.73870218397053 28.95 35.668492041360565 139.73857627337375 28.95 35.668356450424945 139.73844229122238 28.95 35.66832062725209 139.73849620483887 28.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b7eeffea-fb9d-4caa-82d5-9a65c7d76cc4"/>
							<gml:surfaceMember xlink:href="#poly-a3ede207-e639-4be3-a4c0-c4b585034b54"/>
							<gml:surfaceMember xlink:href="#poly-e8178273-6701-4878-bc16-5783cd82da41"/>
							<gml:surfaceMember xlink:href="#poly-f67ada76-19a3-4c93-99a7-bc9e279f4112"/>
							<gml:surfaceMember xlink:href="#poly-3d5ecb3d-7a85-40fb-bbde-43c769a61e08"/>
							<gml:surfaceMember xlink:href="#poly-2b279714-005d-49d2-870e-8b790fd638c7"/>
							<gml:surfaceMember xlink:href="#poly-49037f67-cf26-4754-9d1a-da4bdb73b026"/>
							<gml:surfaceMember xlink:href="#poly-7b3571d7-74be-43fb-842e-887279ae7e79"/>
							<gml:surfaceMember xlink:href="#poly-4be1c926-c406-49ea-ad9a-7bc2cbd43fb4"/>
							<gml:surfaceMember xlink:href="#poly-0da7893e-43e6-491b-92d9-7cb70919268b"/>
							<gml:surfaceMember xlink:href="#poly-7311912c-a6eb-47eb-a0de-c48a0fdd2569"/>
							<gml:surfaceMember xlink:href="#poly-9d2aad99-c3ca-4035-aafc-362b6aec5fc6"/>
							<gml:surfaceMember xlink:href="#poly-42c0a616-68be-4391-9cbc-8cb1f958a6ea"/>
							<gml:surfaceMember xlink:href="#poly-a4e7d684-021f-4edd-83e2-309ee46f0d1a"/>
							<gml:surfaceMember xlink:href="#poly-0f338d40-c776-44f6-984e-d92a8e7cee17"/>
							<gml:surfaceMember xlink:href="#poly-5b2bf544-1091-4b4a-8f7c-0f82f44c7458"/>
							<gml:surfaceMember xlink:href="#poly-40a3bac0-2d34-4b78-89c7-1ac3f8f95e5b"/>
							<gml:surfaceMember xlink:href="#poly-a03669f9-2fb7-4685-aa0d-168807a1e578"/>
							<gml:surfaceMember xlink:href="#poly-b2d1a2d7-0bb3-41ea-a0a2-a1df2fa8b12d"/>
							<gml:surfaceMember xlink:href="#poly-b1ccbac3-6cb5-474b-88a0-e5009e2fc0f9"/>
							<gml:surfaceMember xlink:href="#poly-bd56fae5-ce2c-4423-b93a-25d79040d33b"/>
							<gml:surfaceMember xlink:href="#poly-f15109ef-0399-4120-9b75-063742e15653"/>
							<gml:surfaceMember xlink:href="#poly-002bb6f1-5234-4673-a730-d5f9819bee2a"/>
							<gml:surfaceMember xlink:href="#poly-e4fce706-05e5-40b5-9b02-3023c729cbb7"/>
							<gml:surfaceMember xlink:href="#poly-c268a301-ab0d-46a0-9f35-5ffd0a24ed8f"/>
							<gml:surfaceMember xlink:href="#poly-3854166e-8428-459f-a0ea-da91fa0fd061"/>
							<gml:surfaceMember xlink:href="#poly-1b838b48-3daa-4a02-96f8-6ba7edfcc0e6"/>
							<gml:surfaceMember xlink:href="#poly-658a63cc-c7bd-4a3d-861d-c890a64dc008"/>
							<gml:surfaceMember xlink:href="#poly-7c0f2e76-a06a-408c-ba0e-f56bcdcaff97"/>
							<gml:surfaceMember xlink:href="#poly-242dfaee-3ce5-42c4-a606-a598aaa4798c"/>
							<gml:surfaceMember xlink:href="#poly-a6488c64-691f-4acf-9e6e-05f6359fab90"/>
							<gml:surfaceMember xlink:href="#poly-aada9c29-abac-42ef-9c47-81180ffc285c"/>
							<gml:surfaceMember xlink:href="#poly-1e9c6eb8-3893-4095-8ec3-32de64a72fad"/>
							<gml:surfaceMember xlink:href="#poly-0cafe727-7776-455a-a986-8639c96a6821"/>
							<gml:surfaceMember xlink:href="#poly-dbb686a6-dae1-4b23-ad52-6380bbaa2f5a"/>
							<gml:surfaceMember xlink:href="#poly-eaafd52a-b6ed-4dfa-a563-fd5a8fdfae67"/>
							<gml:surfaceMember xlink:href="#poly-11f647d2-5811-44cf-b6ea-6c0e5c52a3b2"/>
							<gml:surfaceMember xlink:href="#poly-f6e7b1bd-312b-4e2b-aea8-7b32cda42504"/>
							<gml:surfaceMember xlink:href="#poly-5cdee73f-4441-4494-8373-4ef673d552e8"/>
							<gml:surfaceMember xlink:href="#poly-9e6dd4bc-d873-4d63-a07f-8df154c8dbe5"/>
							<gml:surfaceMember xlink:href="#poly-081b71fe-8dc1-4d67-85a3-4afa90be2e0b"/>
							<gml:surfaceMember xlink:href="#poly-541779c8-29e4-449b-8baa-59f211271c97"/>
							<gml:surfaceMember xlink:href="#poly-141c92dc-d6e1-48e8-b645-9d07be72158e"/>
							<gml:surfaceMember xlink:href="#poly-3d175fce-2d2e-4af7-9063-06abc5deb240"/>
							<gml:surfaceMember xlink:href="#poly-9ab10389-ca26-4e11-87b6-f199ff1ddbc1"/>
							<gml:surfaceMember xlink:href="#poly-3a052763-ccd9-4973-97e5-5e6fde219d3c"/>
							<gml:surfaceMember xlink:href="#poly-89058522-8ac7-458e-93f7-efea7dc993ea"/>
							<gml:surfaceMember xlink:href="#poly-2d383dd9-104b-478d-93aa-ee11eefcb555"/>
							<gml:surfaceMember xlink:href="#poly-7e17dbc6-8978-4014-95d0-291456e51c0e"/>
							<gml:surfaceMember xlink:href="#poly-800a44b5-61c6-47ee-b119-c01eb51bacb0"/>
							<gml:surfaceMember xlink:href="#poly-2a7a7c92-d1e9-4429-8a99-8d93ff8bf41b"/>
							<gml:surfaceMember xlink:href="#poly-cb492563-15af-4f35-99e2-7cc69bfe19c3"/>
							<gml:surfaceMember xlink:href="#poly-4b603239-9cdf-4b5c-b6f4-0c3cfd6cd977"/>
							<gml:surfaceMember xlink:href="#poly-e38b3e99-6f46-4c4c-be24-dbdb8d86c89e"/>
							<gml:surfaceMember xlink:href="#poly-2e19f6c6-c3fc-4772-aed3-436eb04d6d4e"/>
							<gml:surfaceMember xlink:href="#poly-5727933d-1e18-44d3-bbfb-475da64685b9"/>
							<gml:surfaceMember xlink:href="#poly-e1281ba2-248d-4300-a46e-6ffdd10aeca9"/>
							<gml:surfaceMember xlink:href="#poly-b398d23d-c448-40db-9851-0fc7d6b7fe6b"/>
							<gml:surfaceMember xlink:href="#poly-224791ae-62d9-4179-b9a6-e8b2082764ed"/>
							<gml:surfaceMember xlink:href="#poly-376ec84e-65aa-4278-8432-c69b5f5cd2f4"/>
							<gml:surfaceMember xlink:href="#poly-9afa8145-93f9-4891-94ca-be887b6ce0ff"/>
							<gml:surfaceMember xlink:href="#poly-69e15ceb-1e5e-4214-b0f9-c137f813c75b"/>
							<gml:surfaceMember xlink:href="#poly-ce717241-364b-4ba0-94f2-ee00e8248b6c"/>
							<gml:surfaceMember xlink:href="#poly-57de2318-5042-47e8-bc6c-8f40e6b6ab8a"/>
							<gml:surfaceMember xlink:href="#poly-1a41cf15-e25f-41ef-a90f-f16960639738"/>
							<gml:surfaceMember xlink:href="#poly-2f8a795f-2bc2-46bb-a3fe-fb28ce21f259"/>
							<gml:surfaceMember xlink:href="#poly-d668e008-8c70-43a0-9c73-be45406e982d"/>
							<gml:surfaceMember xlink:href="#poly-0d0df5bd-7127-4d7d-be22-ac55c68ff08e"/>
							<gml:surfaceMember xlink:href="#poly-674c193f-f77b-45d4-b077-5e21b77e13ff"/>
							<gml:surfaceMember xlink:href="#poly-ff98993c-2cb2-40ab-b0ad-610f9bed283e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bdeef334-c369-41ba-8a2f-2a694c0ca237_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97e279eb-f9eb-4ae8-bade-ea8d41569584">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66838466219571 139.7385437483399 34.34 35.66837304346538 139.73853226320708 34.34 35.66838250557586 139.73851788119475 34.34 35.668394133321264 139.73852936631621 34.34 35.66838466219571 139.7385437483399 34.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8bb9507-3ea1-4435-8569-7d78a41445f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8bb9507-3ea1-4435-8569-7d78a41445f8_0">
											<gml:posList>35.66838250557586 139.73851788119475 34.34 35.66838250557586 139.73851788119475 38.915 35.668394133321264 139.73852936631621 38.915 35.668394133321264 139.73852936631621 34.34 35.66838250557586 139.73851788119475 34.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2382e26-d411-4f75-aefe-208007a0fbeb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2382e26-d411-4f75-aefe-208007a0fbeb_0">
											<gml:posList>35.66837304346538 139.73853226320708 38.915 35.66838250557586 139.73851788119475 38.915 35.66838250557586 139.73851788119475 34.34 35.66837304346538 139.73853226320708 34.34 35.66837304346538 139.73853226320708 38.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2cbeadc-afc9-41fb-b4b4-b531ffba47da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2cbeadc-afc9-41fb-b4b4-b531ffba47da_0">
											<gml:posList>35.66838466219571 139.7385437483399 38.915 35.668394133321264 139.73852936631621 38.915 35.66838250557586 139.73851788119475 38.915 35.66837304346538 139.73853226320708 38.915 35.66838466219571 139.7385437483399 38.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4af55344-5315-42c7-baab-929ae6c52116">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4af55344-5315-42c7-baab-929ae6c52116_0">
											<gml:posList>35.668394133321264 139.73852936631621 34.34 35.668394133321264 139.73852936631621 38.915 35.66838466219571 139.7385437483399 38.915 35.66838466219571 139.7385437483399 34.34 35.668394133321264 139.73852936631621 34.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3258a195-cb39-4bcf-a317-01cb99981b98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3258a195-cb39-4bcf-a317-01cb99981b98_0">
											<gml:posList>35.66838466219571 139.7385437483399 38.915 35.66837304346538 139.73853226320708 38.915 35.66837304346538 139.73853226320708 34.34 35.66838466219571 139.7385437483399 34.34 35.66838466219571 139.7385437483399 38.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b7eeffea-fb9d-4caa-82d5-9a65c7d76cc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7eeffea-fb9d-4caa-82d5-9a65c7d76cc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7eeffea-fb9d-4caa-82d5-9a65c7d76cc4">
											<gml:posList>35.66835641735108 139.73861781189072 15.26 35.66828154456124 139.73854308597717 15.26 35.66831584623676 139.73849146072442 15.26 35.668320627252065 139.73849620483887 15.26 35.668356450424945 139.73844229122238 15.26 35.66849204136056 139.73857627337372 15.26 35.668410133428374 139.73870218397053 15.26 35.66834400213197 139.738636527398 15.26 35.66835641735108 139.73861781189072 15.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3ede207-e639-4be3-a4c0-c4b585034b54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3ede207-e639-4be3-a4c0-c4b585034b54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3ede207-e639-4be3-a4c0-c4b585034b54">
											<gml:posList>35.66828154456124 139.73854308597717 27.558 35.66831304105892 139.7385577288432 27.552 35.668293032887206 139.73853777032966 27.545 35.66828154456124 139.73854308597717 27.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e8178273-6701-4878-bc16-5783cd82da41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8178273-6701-4878-bc16-5783cd82da41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8178273-6701-4878-bc16-5783cd82da41">
											<gml:posList>35.66828154456124 139.73854308597717 27.558 35.668293032887206 139.73853777032966 27.545 35.66831584623676 139.73849146072442 27.558 35.66828154456124 139.73854308597717 27.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f67ada76-19a3-4c93-99a7-bc9e279f4112">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f67ada76-19a3-4c93-99a7-bc9e279f4112">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f67ada76-19a3-4c93-99a7-bc9e279f4112">
											<gml:posList>35.668293032887206 139.73853777032966 27.545 35.668320627252065 139.73849620483887 27.558 35.66831584623676 139.73849146072442 27.558 35.668293032887206 139.73853777032966 27.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d5ecb3d-7a85-40fb-bbde-43c769a61e08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d5ecb3d-7a85-40fb-bbde-43c769a61e08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d5ecb3d-7a85-40fb-bbde-43c769a61e08">
											<gml:posList>35.66828154456124 139.73854308597717 27.558 35.668333049218575 139.73857767632074 27.558 35.66831304105892 139.7385577288432 27.552 35.66828154456124 139.73854308597717 27.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2b279714-005d-49d2-870e-8b790fd638c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b279714-005d-49d2-870e-8b790fd638c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b279714-005d-49d2-870e-8b790fd638c7">
											<gml:posList>35.66828154456124 139.73854308597717 27.558 35.668366678562364 139.73861090707715 27.558 35.668333049218575 139.73857767632074 27.558 35.66828154456124 139.73854308597717 27.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-49037f67-cf26-4754-9d1a-da4bdb73b026">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49037f67-cf26-4754-9d1a-da4bdb73b026">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49037f67-cf26-4754-9d1a-da4bdb73b026">
											<gml:posList>35.66828154456124 139.73854308597717 27.558 35.66836069315838 139.7386220043128 27.558 35.668366678562364 139.73861090707715 27.558 35.66828154456124 139.73854308597717 27.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b3571d7-74be-43fb-842e-887279ae7e79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b3571d7-74be-43fb-842e-887279ae7e79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b3571d7-74be-43fb-842e-887279ae7e79">
											<gml:posList>35.66835642336636 139.73844226916245 29.155 35.66829299682361 139.73853775932633 29.143 35.66831300498663 139.7385577067939 29.149 35.668376323162704 139.73846194060056 29.155 35.66835642336636 139.73844226916245 29.155</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4be1c926-c406-49ea-ad9a-7bc2cbd43fb4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4be1c926-c406-49ea-ad9a-7bc2cbd43fb4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4be1c926-c406-49ea-ad9a-7bc2cbd43fb4">
											<gml:posList>35.668366678562364 139.73861090707715 34.567 35.66836640564812 139.7386077261568 34.567 35.66833565391573 139.73857733081738 34.567 35.668333049218575 139.73857767632074 34.567 35.668366678562364 139.73861090707715 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0da7893e-43e6-491b-92d9-7cb70919268b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0da7893e-43e6-491b-92d9-7cb70919268b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0da7893e-43e6-491b-92d9-7cb70919268b">
											<gml:posList>35.66833297705662 139.73857761013016 32.031 35.66839617784366 139.73848155687185 32.031 35.668376278050566 139.73846188542402 32.031 35.668312968888266 139.7385576516067 32.024 35.66833297705662 139.73857761013016 32.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7311912c-a6eb-47eb-a0de-c48a0fdd2569">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7311912c-a6eb-47eb-a0de-c48a0fdd2569">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7311912c-a6eb-47eb-a0de-c48a0fdd2569">
											<gml:posList>35.668333049218575 139.73857767632074 34.567 35.66833565391573 139.73857733081738 34.567 35.6683965409594 139.73848481500818 34.567 35.668396250005664 139.7384816230624 34.567 35.668333049218575 139.73857767632074 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d2aad99-c3ca-4035-aafc-362b6aec5fc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d2aad99-c3ca-4035-aafc-362b6aec5fc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d2aad99-c3ca-4035-aafc-362b6aec5fc6">
											<gml:posList>35.6683965409594 139.73848481500818 34.34 35.66833565391573 139.73857733081738 34.34 35.66836640564812 139.7386077261568 34.34 35.668417704534335 139.73852974714862 34.34 35.66843863267211 139.7385504225931 34.34 35.668440343236625 139.73854782476295 34.34 35.66843613957138 139.73854367643938 34.34 35.668443999153254 139.73853172643018 34.34 35.6683965409594 139.73848481500818 34.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-42c0a616-68be-4391-9cbc-8cb1f958a6ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42c0a616-68be-4391-9cbc-8cb1f958a6ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42c0a616-68be-4391-9cbc-8cb1f958a6ea">
											<gml:posList>35.668417986455665 139.7385329170141 34.567 35.668417704534335 139.73852974714862 34.567 35.66836640564812 139.7386077261568 34.567 35.668366678562364 139.73861090707715 34.567 35.668417986455665 139.7385329170141 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4e7d684-021f-4edd-83e2-309ee46f0d1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4e7d684-021f-4edd-83e2-309ee46f0d1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4e7d684-021f-4edd-83e2-309ee46f0d1a">
											<gml:posList>35.6684365962658 139.7385513086796 32.066 35.668417986455665 139.7385329170141 32.066 35.668366678562364 139.73861090707715 32.066 35.66838464011965 139.7386302494693 32.066 35.6684365962658 139.7385513086796 32.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0f338d40-c776-44f6-984e-d92a8e7cee17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f338d40-c776-44f6-984e-d92a8e7cee17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f338d40-c776-44f6-984e-d92a8e7cee17">
											<gml:posList>35.66838464011965 139.7386302494693 29.333 35.66840259265138 139.73864958083482 29.333 35.66845506160139 139.73856938019057 29.333 35.668438914601595 139.7385536035055 29.333 35.6684365962658 139.7385513086796 29.333 35.66838464011965 139.7386302494693 29.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b2bf544-1091-4b4a-8f7c-0f82f44c7458">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b2bf544-1091-4b4a-8f7c-0f82f44c7458">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b2bf544-1091-4b4a-8f7c-0f82f44c7458">
											<gml:posList>35.668396250005664 139.7384816230624 34.567 35.6683965409594 139.73848481500818 34.567 35.668443999153254 139.73853172643018 34.567 35.668446594827806 139.7385313698895 34.567 35.668396250005664 139.7384816230624 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-40a3bac0-2d34-4b78-89c7-1ac3f8f95e5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40a3bac0-2d34-4b78-89c7-1ac3f8f95e5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40a3bac0-2d34-4b78-89c7-1ac3f8f95e5b">
											<gml:posList>35.668417986455665 139.7385329170141 34.567 35.668438914601595 139.7385536035055 34.567 35.66843863267211 139.7385504225931 34.567 35.668417704534335 139.73852974714862 34.567 35.668417986455665 139.7385329170141 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a03669f9-2fb7-4685-aa0d-168807a1e578">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a03669f9-2fb7-4685-aa0d-168807a1e578">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a03669f9-2fb7-4685-aa0d-168807a1e578">
											<gml:posList>35.66840259265138 139.73864958083482 26.22 35.668418343964 139.7386665399201 26.22 35.66847120859039 139.738585145836 26.22 35.66845506160139 139.73856938019057 26.22 35.66840259265138 139.73864958083482 26.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b2d1a2d7-0bb3-41ea-a0a2-a1df2fa8b12d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2d1a2d7-0bb3-41ea-a0a2-a1df2fa8b12d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2d1a2d7-0bb3-41ea-a0a2-a1df2fa8b12d">
											<gml:posList>35.668438735245964 139.73854331989915 34.567 35.66843613957138 139.73854367643938 34.567 35.668440343236625 139.73854782476295 34.567 35.66844293891991 139.73854747926882 34.567 35.668438735245964 139.73854331989915 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b1ccbac3-6cb5-474b-88a0-e5009e2fc0f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1ccbac3-6cb5-474b-88a0-e5009e2fc0f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1ccbac3-6cb5-474b-88a0-e5009e2fc0f9">
											<gml:posList>35.66844293891991 139.73854747926882 34.567 35.668440343236625 139.73854782476295 34.567 35.66843863267211 139.7385504225931 34.567 35.668438914601595 139.7385536035055 34.567 35.66844293891991 139.73854747926882 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd56fae5-ce2c-4423-b93a-25d79040d33b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd56fae5-ce2c-4423-b93a-25d79040d33b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd56fae5-ce2c-4423-b93a-25d79040d33b">
											<gml:posList>35.668438735245964 139.73854331989915 34.567 35.668446594827806 139.7385313698895 34.567 35.668443999153254 139.73853172643018 34.567 35.66843613957138 139.73854367643938 34.567 35.668438735245964 139.73854331989915 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f15109ef-0399-4120-9b75-063742e15653">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f15109ef-0399-4120-9b75-063742e15653">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f15109ef-0399-4120-9b75-063742e15653">
											<gml:posList>35.66844293891991 139.73854747926882 24.526 35.668438914601595 139.7385536035055 24.526 35.66847120859039 139.738585145836 24.526 35.668480418695566 139.7385941484869 24.526 35.66849204136056 139.73857627337372 24.526 35.668446594827806 139.7385313698895 24.526 35.668438735245964 139.73854331989915 24.526 35.66844293891991 139.73854747926882 24.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-002bb6f1-5234-4673-a730-d5f9819bee2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-002bb6f1-5234-4673-a730-d5f9819bee2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-002bb6f1-5234-4673-a730-d5f9819bee2a">
											<gml:posList>35.668410133428374 139.73870218397053 22.593 35.668427148827604 139.7386760290764 22.593 35.668366678562364 139.73861090707715 22.593 35.66836069315838 139.7386220043128 22.593 35.66835641735108 139.73861781189072 22.593 35.66834400213197 139.738636527398 22.593 35.668410133428374 139.73870218397053 22.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e4fce706-05e5-40b5-9b02-3023c729cbb7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4fce706-05e5-40b5-9b02-3023c729cbb7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4fce706-05e5-40b5-9b02-3023c729cbb7">
											<gml:posList>35.668418343964 139.7386665399201 24.526 35.668427148827604 139.7386760290764 24.526 35.668480418695566 139.7385941484869 24.526 35.66847120859039 139.738585145836 24.526 35.668418343964 139.7386665399201 24.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c268a301-ab0d-46a0-9f35-5ffd0a24ed8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c268a301-ab0d-46a0-9f35-5ffd0a24ed8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c268a301-ab0d-46a0-9f35-5ffd0a24ed8f">
											<gml:posList>35.66843863267211 139.7385504225931 34.567 35.66843863267211 139.7385504225931 34.34 35.668417704534335 139.73852974714862 34.34 35.668417704534335 139.73852974714862 34.567 35.66843863267211 139.7385504225931 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3854166e-8428-459f-a0ea-da91fa0fd061">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3854166e-8428-459f-a0ea-da91fa0fd061">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3854166e-8428-459f-a0ea-da91fa0fd061">
											<gml:posList>35.668417704534335 139.73852974714862 34.567 35.668417704534335 139.73852974714862 34.34 35.66836640564812 139.7386077261568 34.34 35.66836640564812 139.7386077261568 34.567 35.668417704534335 139.73852974714862 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b838b48-3daa-4a02-96f8-6ba7edfcc0e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b838b48-3daa-4a02-96f8-6ba7edfcc0e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b838b48-3daa-4a02-96f8-6ba7edfcc0e6">
											<gml:posList>35.66836640564812 139.7386077261568 34.567 35.66836640564812 139.7386077261568 34.34 35.66833565391573 139.73857733081738 34.34 35.66833565391573 139.73857733081738 34.567 35.66836640564812 139.7386077261568 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-658a63cc-c7bd-4a3d-861d-c890a64dc008">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-658a63cc-c7bd-4a3d-861d-c890a64dc008">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-658a63cc-c7bd-4a3d-861d-c890a64dc008">
											<gml:posList>35.66831584623676 139.73849146072442 15.26 35.66828154456124 139.73854308597717 15.26 35.66828154456124 139.73854308597717 27.558 35.66831584623676 139.73849146072442 27.558 35.66831584623676 139.73849146072442 15.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c0f2e76-a06a-408c-ba0e-f56bcdcaff97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c0f2e76-a06a-408c-ba0e-f56bcdcaff97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c0f2e76-a06a-408c-ba0e-f56bcdcaff97">
											<gml:posList>35.66831304105892 139.7385577288432 27.552 35.66831300498663 139.7385577067939 29.149 35.66829299682361 139.73853775932633 29.143 35.668293032887206 139.73853777032966 27.545 35.66831304105892 139.7385577288432 27.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-242dfaee-3ce5-42c4-a606-a598aaa4798c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-242dfaee-3ce5-42c4-a606-a598aaa4798c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-242dfaee-3ce5-42c4-a606-a598aaa4798c">
											<gml:posList>35.668320627252065 139.73849620483887 15.26 35.66831584623676 139.73849146072442 15.26 35.66831584623676 139.73849146072442 27.558 35.668320627252065 139.73849620483887 27.558 35.668320627252065 139.73849620483887 15.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6488c64-691f-4acf-9e6e-05f6359fab90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6488c64-691f-4acf-9e6e-05f6359fab90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6488c64-691f-4acf-9e6e-05f6359fab90">
											<gml:posList>35.66828154456124 139.73854308597717 27.558 35.66835641735108 139.73861781189072 15.26 35.66835641735108 139.73861781189072 22.593 35.66828154456124 139.73854308597717 27.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aada9c29-abac-42ef-9c47-81180ffc285c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aada9c29-abac-42ef-9c47-81180ffc285c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aada9c29-abac-42ef-9c47-81180ffc285c">
											<gml:posList>35.66828154456124 139.73854308597717 27.558 35.66828154456124 139.73854308597717 15.26 35.66835641735108 139.73861781189072 15.26 35.66828154456124 139.73854308597717 27.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e9c6eb8-3893-4095-8ec3-32de64a72fad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e9c6eb8-3893-4095-8ec3-32de64a72fad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e9c6eb8-3893-4095-8ec3-32de64a72fad">
											<gml:posList>35.66828154456124 139.73854308597717 27.558 35.66836069315838 139.7386220043128 22.593 35.66836069315838 139.7386220043128 27.558 35.66828154456124 139.73854308597717 27.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0cafe727-7776-455a-a986-8639c96a6821">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cafe727-7776-455a-a986-8639c96a6821">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cafe727-7776-455a-a986-8639c96a6821">
											<gml:posList>35.66828154456124 139.73854308597717 27.558 35.66835641735108 139.73861781189072 22.593 35.66836069315838 139.7386220043128 22.593 35.66828154456124 139.73854308597717 27.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbb686a6-dae1-4b23-ad52-6380bbaa2f5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbb686a6-dae1-4b23-ad52-6380bbaa2f5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbb686a6-dae1-4b23-ad52-6380bbaa2f5a">
											<gml:posList>35.66831300498663 139.7385577067939 29.149 35.66831304105892 139.7385577288432 27.552 35.668333049218575 139.73857767632074 27.558 35.66833297705662 139.73857761013016 32.031 35.668312968888266 139.7385576516067 32.024 35.66831300498663 139.7385577067939 29.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eaafd52a-b6ed-4dfa-a563-fd5a8fdfae67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eaafd52a-b6ed-4dfa-a563-fd5a8fdfae67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eaafd52a-b6ed-4dfa-a563-fd5a8fdfae67">
											<gml:posList>35.66835642336636 139.73844226916245 29.155 35.668356450424945 139.73844229122238 15.26 35.668320627252065 139.73849620483887 15.26 35.668320627252065 139.73849620483887 27.558 35.668293032887206 139.73853777032966 27.545 35.66829299682361 139.73853775932633 29.143 35.66835642336636 139.73844226916245 29.155</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11f647d2-5811-44cf-b6ea-6c0e5c52a3b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11f647d2-5811-44cf-b6ea-6c0e5c52a3b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11f647d2-5811-44cf-b6ea-6c0e5c52a3b2">
											<gml:posList>35.668376278050566 139.73846188542402 32.031 35.668376323162704 139.73846194060056 29.155 35.66831300498663 139.7385577067939 29.149 35.668312968888266 139.7385576516067 32.024 35.668376278050566 139.73846188542402 32.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6e7b1bd-312b-4e2b-aea8-7b32cda42504">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6e7b1bd-312b-4e2b-aea8-7b32cda42504">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6e7b1bd-312b-4e2b-aea8-7b32cda42504">
											<gml:posList>35.668366678562364 139.73861090707715 32.066 35.668366678562364 139.73861090707715 34.567 35.668333049218575 139.73857767632074 34.567 35.668366678562364 139.73861090707715 32.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cdee73f-4441-4494-8373-4ef673d552e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cdee73f-4441-4494-8373-4ef673d552e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cdee73f-4441-4494-8373-4ef673d552e8">
											<gml:posList>35.668333049218575 139.73857767632074 34.567 35.668333049218575 139.73857767632074 27.558 35.668366678562364 139.73861090707715 27.558 35.668333049218575 139.73857767632074 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e6dd4bc-d873-4d63-a07f-8df154c8dbe5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e6dd4bc-d873-4d63-a07f-8df154c8dbe5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e6dd4bc-d873-4d63-a07f-8df154c8dbe5">
											<gml:posList>35.66835641735108 139.73861781189072 15.26 35.66834400213197 139.738636527398 15.26 35.66834400213197 139.738636527398 22.593 35.66835641735108 139.73861781189072 22.593 35.66835641735108 139.73861781189072 15.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-081b71fe-8dc1-4d67-85a3-4afa90be2e0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-081b71fe-8dc1-4d67-85a3-4afa90be2e0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-081b71fe-8dc1-4d67-85a3-4afa90be2e0b">
											<gml:posList>35.66838464011965 139.7386302494693 29.333 35.668366678562364 139.73861090707715 32.066 35.668333049218575 139.73857767632074 34.567 35.66838464011965 139.7386302494693 29.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-541779c8-29e4-449b-8baa-59f211271c97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-541779c8-29e4-449b-8baa-59f211271c97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-541779c8-29e4-449b-8baa-59f211271c97">
											<gml:posList>35.668366678562364 139.73861090707715 22.593 35.668366678562364 139.73861090707715 27.558 35.66836069315838 139.7386220043128 27.558 35.66836069315838 139.7386220043128 22.593 35.668366678562364 139.73861090707715 22.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-141c92dc-d6e1-48e8-b645-9d07be72158e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-141c92dc-d6e1-48e8-b645-9d07be72158e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-141c92dc-d6e1-48e8-b645-9d07be72158e">
											<gml:posList>35.668396250005664 139.7384816230624 34.567 35.66839617784366 139.73848155687185 32.031 35.66833297705662 139.73857761013016 32.031 35.668333049218575 139.73857767632074 34.567 35.668396250005664 139.7384816230624 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d175fce-2d2e-4af7-9063-06abc5deb240">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d175fce-2d2e-4af7-9063-06abc5deb240">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d175fce-2d2e-4af7-9063-06abc5deb240">
											<gml:posList>35.66833565391573 139.73857733081738 34.567 35.66833565391573 139.73857733081738 34.34 35.6683965409594 139.73848481500818 34.34 35.6683965409594 139.73848481500818 34.567 35.66833565391573 139.73857733081738 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ab10389-ca26-4e11-87b6-f199ff1ddbc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ab10389-ca26-4e11-87b6-f199ff1ddbc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ab10389-ca26-4e11-87b6-f199ff1ddbc1">
											<gml:posList>35.66840259265138 139.73864958083482 26.22 35.66838464011965 139.7386302494693 29.333 35.668333049218575 139.73857767632074 34.567 35.66840259265138 139.73864958083482 26.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a052763-ccd9-4973-97e5-5e6fde219d3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a052763-ccd9-4973-97e5-5e6fde219d3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a052763-ccd9-4973-97e5-5e6fde219d3c">
											<gml:posList>35.66840259265138 139.73864958083482 26.22 35.668333049218575 139.73857767632074 34.567 35.668366678562364 139.73861090707715 27.558 35.66840259265138 139.73864958083482 26.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-89058522-8ac7-458e-93f7-efea7dc993ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89058522-8ac7-458e-93f7-efea7dc993ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89058522-8ac7-458e-93f7-efea7dc993ea">
											<gml:posList>35.66838464011965 139.7386302494693 29.333 35.66838464011965 139.7386302494693 32.066 35.668366678562364 139.73861090707715 32.066 35.66838464011965 139.7386302494693 29.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d383dd9-104b-478d-93aa-ee11eefcb555">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d383dd9-104b-478d-93aa-ee11eefcb555">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d383dd9-104b-478d-93aa-ee11eefcb555">
											<gml:posList>35.66834400213197 139.738636527398 15.26 35.668410133428374 139.73870218397053 15.26 35.668410133428374 139.73870218397053 22.593 35.66834400213197 139.738636527398 22.593 35.66834400213197 139.738636527398 15.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e17dbc6-8978-4014-95d0-291456e51c0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e17dbc6-8978-4014-95d0-291456e51c0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e17dbc6-8978-4014-95d0-291456e51c0e">
											<gml:posList>35.668366678562364 139.73861090707715 32.066 35.668417986455665 139.7385329170141 32.066 35.668417986455665 139.7385329170141 34.567 35.668366678562364 139.73861090707715 34.567 35.668366678562364 139.73861090707715 32.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-800a44b5-61c6-47ee-b119-c01eb51bacb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-800a44b5-61c6-47ee-b119-c01eb51bacb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-800a44b5-61c6-47ee-b119-c01eb51bacb0">
											<gml:posList>35.66840259265138 139.73864958083482 26.22 35.668366678562364 139.73861090707715 27.558 35.668418343964 139.7386665399201 24.526 35.66840259265138 139.73864958083482 26.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a7a7c92-d1e9-4429-8a99-8d93ff8bf41b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a7a7c92-d1e9-4429-8a99-8d93ff8bf41b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a7a7c92-d1e9-4429-8a99-8d93ff8bf41b">
											<gml:posList>35.66840259265138 139.73864958083482 26.22 35.66840259265138 139.73864958083482 29.333 35.66838464011965 139.7386302494693 29.333 35.66840259265138 139.73864958083482 26.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb492563-15af-4f35-99e2-7cc69bfe19c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb492563-15af-4f35-99e2-7cc69bfe19c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb492563-15af-4f35-99e2-7cc69bfe19c3">
											<gml:posList>35.668366678562364 139.73861090707715 27.558 35.668366678562364 139.73861090707715 22.593 35.668427148827604 139.7386760290764 22.593 35.668366678562364 139.73861090707715 27.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b603239-9cdf-4b5c-b6f4-0c3cfd6cd977">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b603239-9cdf-4b5c-b6f4-0c3cfd6cd977">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b603239-9cdf-4b5c-b6f4-0c3cfd6cd977">
											<gml:posList>35.668366678562364 139.73861090707715 27.558 35.668427148827604 139.7386760290764 22.593 35.668418343964 139.7386665399201 24.526 35.668366678562364 139.73861090707715 27.558</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e38b3e99-6f46-4c4c-be24-dbdb8d86c89e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e38b3e99-6f46-4c4c-be24-dbdb8d86c89e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e38b3e99-6f46-4c4c-be24-dbdb8d86c89e">
											<gml:posList>35.66840259265138 139.73864958083482 26.22 35.668418343964 139.7386665399201 24.526 35.668418343964 139.7386665399201 26.22 35.66840259265138 139.73864958083482 26.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e19f6c6-c3fc-4772-aed3-436eb04d6d4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e19f6c6-c3fc-4772-aed3-436eb04d6d4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e19f6c6-c3fc-4772-aed3-436eb04d6d4e">
											<gml:posList>35.6684365962658 139.7385513086796 29.333 35.6684365962658 139.7385513086796 32.066 35.66838464011965 139.7386302494693 32.066 35.66838464011965 139.7386302494693 29.333 35.6684365962658 139.7385513086796 29.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5727933d-1e18-44d3-bbfb-475da64685b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5727933d-1e18-44d3-bbfb-475da64685b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5727933d-1e18-44d3-bbfb-475da64685b9">
											<gml:posList>35.6683965409594 139.73848481500818 34.567 35.6683965409594 139.73848481500818 34.34 35.668443999153254 139.73853172643018 34.34 35.668443999153254 139.73853172643018 34.567 35.6683965409594 139.73848481500818 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1281ba2-248d-4300-a46e-6ffdd10aeca9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1281ba2-248d-4300-a46e-6ffdd10aeca9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1281ba2-248d-4300-a46e-6ffdd10aeca9">
											<gml:posList>35.668427148827604 139.7386760290764 22.593 35.668427148827604 139.7386760290764 24.526 35.668418343964 139.7386665399201 24.526 35.668427148827604 139.7386760290764 22.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b398d23d-c448-40db-9851-0fc7d6b7fe6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b398d23d-c448-40db-9851-0fc7d6b7fe6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b398d23d-c448-40db-9851-0fc7d6b7fe6b">
											<gml:posList>35.66849204136056 139.73857627337372 15.26 35.668356450424945 139.73844229122238 15.26 35.66835642336636 139.73844226916245 29.155 35.668376323162704 139.73846194060056 29.155 35.668376278050566 139.73846188542402 32.031 35.66839617784366 139.73848155687185 32.031 35.668396250005664 139.7384816230624 34.567 35.668446594827806 139.7385313698895 34.567 35.668446594827806 139.7385313698895 24.526 35.66849204136056 139.73857627337372 24.526 35.66849204136056 139.73857627337372 15.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-224791ae-62d9-4179-b9a6-e8b2082764ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-224791ae-62d9-4179-b9a6-e8b2082764ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-224791ae-62d9-4179-b9a6-e8b2082764ed">
											<gml:posList>35.6684365962658 139.7385513086796 32.066 35.6684365962658 139.7385513086796 29.333 35.668438914601595 139.7385536035055 29.333 35.668438914601595 139.7385536035055 34.567 35.668417986455665 139.7385329170141 34.567 35.668417986455665 139.7385329170141 32.066 35.6684365962658 139.7385513086796 32.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-376ec84e-65aa-4278-8432-c69b5f5cd2f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-376ec84e-65aa-4278-8432-c69b5f5cd2f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-376ec84e-65aa-4278-8432-c69b5f5cd2f4">
											<gml:posList>35.66845506160139 139.73856938019057 26.22 35.66845506160139 139.73856938019057 29.333 35.66840259265138 139.73864958083482 29.333 35.66840259265138 139.73864958083482 26.22 35.66845506160139 139.73856938019057 26.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9afa8145-93f9-4891-94ca-be887b6ce0ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9afa8145-93f9-4891-94ca-be887b6ce0ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9afa8145-93f9-4891-94ca-be887b6ce0ff">
											<gml:posList>35.668440343236625 139.73854782476295 34.567 35.668440343236625 139.73854782476295 34.34 35.66843863267211 139.7385504225931 34.34 35.66843863267211 139.7385504225931 34.567 35.668440343236625 139.73854782476295 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69e15ceb-1e5e-4214-b0f9-c137f813c75b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69e15ceb-1e5e-4214-b0f9-c137f813c75b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69e15ceb-1e5e-4214-b0f9-c137f813c75b">
											<gml:posList>35.668443999153254 139.73853172643018 34.567 35.668443999153254 139.73853172643018 34.34 35.66843613957138 139.73854367643938 34.34 35.66843613957138 139.73854367643938 34.567 35.668443999153254 139.73853172643018 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce717241-364b-4ba0-94f2-ee00e8248b6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce717241-364b-4ba0-94f2-ee00e8248b6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce717241-364b-4ba0-94f2-ee00e8248b6c">
											<gml:posList>35.668438735245964 139.73854331989915 34.567 35.66844293891991 139.73854747926882 34.567 35.66844293891991 139.73854747926882 24.526 35.668438735245964 139.73854331989915 24.526 35.668438735245964 139.73854331989915 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57de2318-5042-47e8-bc6c-8f40e6b6ab8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57de2318-5042-47e8-bc6c-8f40e6b6ab8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57de2318-5042-47e8-bc6c-8f40e6b6ab8a">
											<gml:posList>35.66844293891991 139.73854747926882 24.526 35.66844293891991 139.73854747926882 34.567 35.668438914601595 139.7385536035055 34.567 35.668438914601595 139.7385536035055 29.333 35.668438914601595 139.7385536035055 24.526 35.66844293891991 139.73854747926882 24.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a41cf15-e25f-41ef-a90f-f16960639738">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a41cf15-e25f-41ef-a90f-f16960639738">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a41cf15-e25f-41ef-a90f-f16960639738">
											<gml:posList>35.668446594827806 139.7385313698895 34.567 35.668438735245964 139.73854331989915 34.567 35.668438735245964 139.73854331989915 24.526 35.668446594827806 139.7385313698895 24.526 35.668446594827806 139.7385313698895 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f8a795f-2bc2-46bb-a3fe-fb28ce21f259">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f8a795f-2bc2-46bb-a3fe-fb28ce21f259">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f8a795f-2bc2-46bb-a3fe-fb28ce21f259">
											<gml:posList>35.66847120859039 139.738585145836 24.526 35.66847120859039 139.738585145836 26.22 35.668418343964 139.7386665399201 26.22 35.668418343964 139.7386665399201 24.526 35.66847120859039 139.738585145836 24.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d668e008-8c70-43a0-9c73-be45406e982d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d668e008-8c70-43a0-9c73-be45406e982d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d668e008-8c70-43a0-9c73-be45406e982d">
											<gml:posList>35.668480418695566 139.7385941484869 24.526 35.668427148827604 139.7386760290764 24.526 35.668427148827604 139.7386760290764 22.593 35.668410133428374 139.73870218397053 22.593 35.668410133428374 139.73870218397053 15.26 35.66849204136056 139.73857627337372 15.26 35.66849204136056 139.73857627337372 24.526 35.668480418695566 139.7385941484869 24.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d0df5bd-7127-4d7d-be22-ac55c68ff08e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d0df5bd-7127-4d7d-be22-ac55c68ff08e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d0df5bd-7127-4d7d-be22-ac55c68ff08e">
											<gml:posList>35.668438914601595 139.7385536035055 24.526 35.668438914601595 139.7385536035055 29.333 35.66845506160139 139.73856938019057 29.333 35.66845506160139 139.73856938019057 26.22 35.66847120859039 139.738585145836 26.22 35.66847120859039 139.738585145836 24.526 35.668438914601595 139.7385536035055 24.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-674c193f-f77b-45d4-b077-5e21b77e13ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-674c193f-f77b-45d4-b077-5e21b77e13ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-674c193f-f77b-45d4-b077-5e21b77e13ff">
											<gml:posList>35.66843613957138 139.73854367643938 34.567 35.66843613957138 139.73854367643938 34.34 35.668440343236625 139.73854782476295 34.34 35.668440343236625 139.73854782476295 34.567 35.66843613957138 139.73854367643938 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff98993c-2cb2-40ab-b0ad-610f9bed283e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff98993c-2cb2-40ab-b0ad-610f9bed283e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff98993c-2cb2-40ab-b0ad-610f9bed283e">
											<gml:posList>35.668333049218575 139.73857767632074 34.567 35.66833297705662 139.73857761013016 32.031 35.668333049218575 139.73857767632074 27.558 35.668333049218575 139.73857767632074 34.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7603</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">230.57015</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>