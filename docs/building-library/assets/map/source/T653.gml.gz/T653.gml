<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_bea70090-fc9f-420f-be3f-03cafe3676c1">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.6</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6694006204951 139.74760184975722 0 35.66942586582555 139.74763683899192 0 35.6694295630061 139.7476263522638 0 35.66947436799521 139.74764848501025 0 35.669489544433894 139.74763204318552 0 35.669438313887404 139.74756101609472 0 35.6694006204951 139.74760184975722 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6694006204951 139.74760184975722 6.762 35.669438313887404 139.74756101609472 6.762 35.669489544433894 139.74763204318552 6.762 35.66947436799521 139.74764848501025 6.762 35.6694295630061 139.7476263522638 6.762 35.66942586582555 139.74763683899192 6.762 35.6694006204951 139.74760184975722 6.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6694006204951 139.74760184975722 6.762 35.66942586582555 139.74763683899192 6.762 35.66942586582555 139.74763683899192 10.4 35.6694006204951 139.74760184975722 10.4 35.6694006204951 139.74760184975722 6.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66942586582555 139.74763683899192 6.762 35.6694295630061 139.7476263522638 6.762 35.6694295630061 139.7476263522638 10.4 35.66942586582555 139.74763683899192 10.4 35.66942586582555 139.74763683899192 6.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6694295630061 139.7476263522638 6.762 35.66947436799521 139.74764848501025 6.762 35.66947436799521 139.74764848501025 10.4 35.6694295630061 139.7476263522638 10.4 35.6694295630061 139.7476263522638 6.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66947436799521 139.74764848501025 6.762 35.669489544433894 139.74763204318552 6.762 35.669489544433894 139.74763204318552 10.4 35.66947436799521 139.74764848501025 10.4 35.66947436799521 139.74764848501025 6.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669489544433894 139.74763204318552 6.762 35.669438313887404 139.74756101609472 6.762 35.669438313887404 139.74756101609472 10.4 35.669489544433894 139.74763204318552 10.4 35.669489544433894 139.74763204318552 6.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669438313887404 139.74756101609472 6.762 35.6694006204951 139.74760184975722 6.762 35.6694006204951 139.74760184975722 10.4 35.669438313887404 139.74756101609472 10.4 35.669438313887404 139.74756101609472 6.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6694006204951 139.74760184975722 10.4 35.66942586582555 139.74763683899192 10.4 35.6694295630061 139.7476263522638 10.4 35.66947436799521 139.74764848501025 10.4 35.669489544433894 139.74763204318552 10.4 35.669438313887404 139.74756101609472 10.4 35.6694006204951 139.74760184975722 10.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e060942b-1db4-4d1e-b5c1-f851f3f4628c"/>
							<gml:surfaceMember xlink:href="#poly-704bd768-58a8-4ec3-802c-6ba3c4164f58"/>
							<gml:surfaceMember xlink:href="#poly-02a14fe7-8313-4200-a14d-7e3cb6877f85"/>
							<gml:surfaceMember xlink:href="#poly-7a1b884b-116d-489b-a475-ea952b38a33d"/>
							<gml:surfaceMember xlink:href="#poly-6ac9a8cb-4ae2-419d-b6e7-7d1214419c97"/>
							<gml:surfaceMember xlink:href="#poly-eabcd3a2-bd01-412b-8f3a-84f8b3186379"/>
							<gml:surfaceMember xlink:href="#poly-2cf68651-4517-42b6-a873-417ac33b7d93"/>
							<gml:surfaceMember xlink:href="#poly-3e75feda-59f7-47c7-9ad4-96d1e55fba7c"/>
							<gml:surfaceMember xlink:href="#poly-7ebcd4ec-3c52-4292-bcc3-ee81cdd22e55"/>
							<gml:surfaceMember xlink:href="#poly-a8c48b2c-1099-4a41-b743-347cbb846e93"/>
							<gml:surfaceMember xlink:href="#poly-d0857ab3-b28d-4160-8fc7-3f7ea8d913cd"/>
							<gml:surfaceMember xlink:href="#poly-0d45b316-30bc-44b4-bdc6-8b80811cc596"/>
							<gml:surfaceMember xlink:href="#poly-97bb91a3-a495-4b21-938e-3a975d0c6469"/>
							<gml:surfaceMember xlink:href="#poly-f158b717-4c55-4aac-86a9-5b45f0600c9b"/>
							<gml:surfaceMember xlink:href="#poly-3874f785-8c6d-4a31-a899-7890682da8b3"/>
							<gml:surfaceMember xlink:href="#poly-e53acdf9-b58e-44b5-b45b-e88a52e58767"/>
							<gml:surfaceMember xlink:href="#poly-1cea10a7-0cfc-4483-8ce0-cf3f179c8ca8"/>
							<gml:surfaceMember xlink:href="#poly-5a9dff97-fd4e-4e93-a01e-ba87ca7655d6"/>
							<gml:surfaceMember xlink:href="#poly-337a07b7-39e8-428b-9b9c-a1face066ef6"/>
							<gml:surfaceMember xlink:href="#poly-80eecd1f-aeec-4075-99b2-69d004b202a2"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e060942b-1db4-4d1e-b5c1-f851f3f4628c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e060942b-1db4-4d1e-b5c1-f851f3f4628c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e060942b-1db4-4d1e-b5c1-f851f3f4628c">
											<gml:posList>35.669438313887404 139.74756101609472 6.762 35.6694895444339 139.74763204318552 6.762 35.66947436799521 139.74764848501025 6.762 35.66942956300606 139.7476263522638 6.762 35.66942586582555 139.74763683899192 6.762 35.66940062049508 139.74760184975722 6.762 35.669438313887404 139.74756101609472 6.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-704bd768-58a8-4ec3-802c-6ba3c4164f58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-704bd768-58a8-4ec3-802c-6ba3c4164f58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-704bd768-58a8-4ec3-802c-6ba3c4164f58">
											<gml:posList>35.66940062049508 139.74760184975722 10.5 35.66942586582555 139.74763683899192 10.5 35.66942553949184 139.7476342545466 10.5 35.66940224306012 139.7476019805758 10.5 35.66940062049508 139.74760184975722 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-02a14fe7-8313-4200-a14d-7e3cb6877f85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02a14fe7-8313-4200-a14d-7e3cb6877f85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02a14fe7-8313-4200-a14d-7e3cb6877f85">
											<gml:posList>35.66940062049508 139.74760184975722 10.5 35.66940224306012 139.7476019805758 10.5 35.66943822516642 139.7475630044931 10.5 35.669438313887404 139.74756101609472 10.5 35.66940062049508 139.74760184975722 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a1b884b-116d-489b-a475-ea952b38a33d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a1b884b-116d-489b-a475-ea952b38a33d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a1b884b-116d-489b-a475-ea952b38a33d">
											<gml:posList>35.66942956300606 139.7476263522638 10.5 35.66942896681073 139.74762454133594 10.5 35.66942553949184 139.7476342545466 10.5 35.66942586582555 139.74763683899192 10.5 35.66942956300606 139.7476263522638 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ac9a8cb-4ae2-419d-b6e7-7d1214419c97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ac9a8cb-4ae2-419d-b6e7-7d1214419c97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ac9a8cb-4ae2-419d-b6e7-7d1214419c97">
											<gml:posList>35.66942896681073 139.74762454133594 10.355 35.66947414149659 139.7476468614704 10.355 35.669487930890504 139.74763192340265 10.355 35.66943822516642 139.7475630044931 10.355 35.66940224306012 139.7476019805758 10.355 35.66942553949184 139.7476342545466 10.355 35.66942896681073 139.74762454133594 10.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eabcd3a2-bd01-412b-8f3a-84f8b3186379">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eabcd3a2-bd01-412b-8f3a-84f8b3186379">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eabcd3a2-bd01-412b-8f3a-84f8b3186379">
											<gml:posList>35.66942956300606 139.7476263522638 10.5 35.66947436799521 139.74764848501025 10.5 35.66947414149659 139.7476468614704 10.5 35.66942896681073 139.74762454133594 10.5 35.66942956300606 139.7476263522638 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2cf68651-4517-42b6-a873-417ac33b7d93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cf68651-4517-42b6-a873-417ac33b7d93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cf68651-4517-42b6-a873-417ac33b7d93">
											<gml:posList>35.669438313887404 139.74756101609472 10.5 35.66943822516642 139.7475630044931 10.5 35.669487930890504 139.74763192340265 10.5 35.6694895444339 139.74763204318552 10.5 35.669438313887404 139.74756101609472 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e75feda-59f7-47c7-9ad4-96d1e55fba7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e75feda-59f7-47c7-9ad4-96d1e55fba7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e75feda-59f7-47c7-9ad4-96d1e55fba7c">
											<gml:posList>35.66947436799521 139.74764848501025 10.5 35.6694895444339 139.74763204318552 10.5 35.669487930890504 139.74763192340265 10.5 35.66947414149659 139.7476468614704 10.5 35.66947436799521 139.74764848501025 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ebcd4ec-3c52-4292-bcc3-ee81cdd22e55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ebcd4ec-3c52-4292-bcc3-ee81cdd22e55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ebcd4ec-3c52-4292-bcc3-ee81cdd22e55">
											<gml:posList>35.66942896681073 139.74762454133594 10.5 35.66942896681073 139.74762454133594 10.355 35.66942553949184 139.7476342545466 10.355 35.66942553949184 139.7476342545466 10.5 35.66942896681073 139.74762454133594 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8c48b2c-1099-4a41-b743-347cbb846e93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8c48b2c-1099-4a41-b743-347cbb846e93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8c48b2c-1099-4a41-b743-347cbb846e93">
											<gml:posList>35.66947414149659 139.7476468614704 10.5 35.66947414149659 139.7476468614704 10.355 35.66942896681073 139.74762454133594 10.355 35.66942896681073 139.74762454133594 10.5 35.66947414149659 139.7476468614704 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0857ab3-b28d-4160-8fc7-3f7ea8d913cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0857ab3-b28d-4160-8fc7-3f7ea8d913cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0857ab3-b28d-4160-8fc7-3f7ea8d913cd">
											<gml:posList>35.669438313887404 139.74756101609472 6.762 35.66940062049508 139.74760184975722 6.762 35.66940062049508 139.74760184975722 10.5 35.669438313887404 139.74756101609472 10.5 35.669438313887404 139.74756101609472 6.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d45b316-30bc-44b4-bdc6-8b80811cc596">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d45b316-30bc-44b4-bdc6-8b80811cc596">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d45b316-30bc-44b4-bdc6-8b80811cc596">
											<gml:posList>35.66940224306012 139.7476019805758 10.5 35.66940224306012 139.7476019805758 10.355 35.66943822516642 139.7475630044931 10.355 35.66943822516642 139.7475630044931 10.5 35.66940224306012 139.7476019805758 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97bb91a3-a495-4b21-938e-3a975d0c6469">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97bb91a3-a495-4b21-938e-3a975d0c6469">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97bb91a3-a495-4b21-938e-3a975d0c6469">
											<gml:posList>35.6694895444339 139.74763204318552 6.762 35.669438313887404 139.74756101609472 6.762 35.669438313887404 139.74756101609472 10.5 35.6694895444339 139.74763204318552 10.5 35.6694895444339 139.74763204318552 6.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f158b717-4c55-4aac-86a9-5b45f0600c9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f158b717-4c55-4aac-86a9-5b45f0600c9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f158b717-4c55-4aac-86a9-5b45f0600c9b">
											<gml:posList>35.66943822516642 139.7475630044931 10.5 35.66943822516642 139.7475630044931 10.355 35.669487930890504 139.74763192340265 10.355 35.669487930890504 139.74763192340265 10.5 35.66943822516642 139.7475630044931 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3874f785-8c6d-4a31-a899-7890682da8b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3874f785-8c6d-4a31-a899-7890682da8b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3874f785-8c6d-4a31-a899-7890682da8b3">
											<gml:posList>35.66942553949184 139.7476342545466 10.5 35.66942553949184 139.7476342545466 10.355 35.66940224306012 139.7476019805758 10.355 35.66940224306012 139.7476019805758 10.5 35.66942553949184 139.7476342545466 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e53acdf9-b58e-44b5-b45b-e88a52e58767">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e53acdf9-b58e-44b5-b45b-e88a52e58767">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e53acdf9-b58e-44b5-b45b-e88a52e58767">
											<gml:posList>35.66940062049508 139.74760184975722 6.762 35.66942586582555 139.74763683899192 6.762 35.66942586582555 139.74763683899192 10.5 35.66940062049508 139.74760184975722 10.5 35.66940062049508 139.74760184975722 6.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1cea10a7-0cfc-4483-8ce0-cf3f179c8ca8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cea10a7-0cfc-4483-8ce0-cf3f179c8ca8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cea10a7-0cfc-4483-8ce0-cf3f179c8ca8">
											<gml:posList>35.66942586582555 139.74763683899192 6.762 35.66942956300606 139.7476263522638 6.762 35.66942956300606 139.7476263522638 10.5 35.66942586582555 139.74763683899192 10.5 35.66942586582555 139.74763683899192 6.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a9dff97-fd4e-4e93-a01e-ba87ca7655d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a9dff97-fd4e-4e93-a01e-ba87ca7655d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a9dff97-fd4e-4e93-a01e-ba87ca7655d6">
											<gml:posList>35.66942956300606 139.7476263522638 6.762 35.66947436799521 139.74764848501025 6.762 35.66947436799521 139.74764848501025 10.5 35.66942956300606 139.7476263522638 10.5 35.66942956300606 139.7476263522638 6.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-337a07b7-39e8-428b-9b9c-a1face066ef6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-337a07b7-39e8-428b-9b9c-a1face066ef6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-337a07b7-39e8-428b-9b9c-a1face066ef6">
											<gml:posList>35.669487930890504 139.74763192340265 10.5 35.669487930890504 139.74763192340265 10.355 35.66947414149659 139.7476468614704 10.355 35.66947414149659 139.7476468614704 10.5 35.669487930890504 139.74763192340265 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80eecd1f-aeec-4075-99b2-69d004b202a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80eecd1f-aeec-4075-99b2-69d004b202a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80eecd1f-aeec-4075-99b2-69d004b202a2">
											<gml:posList>35.66947436799521 139.74764848501025 6.762 35.6694895444339 139.74763204318552 6.762 35.6694895444339 139.74763204318552 10.5 35.66947436799521 139.74764848501025 10.5 35.66947436799521 139.74764848501025 6.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11353</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>