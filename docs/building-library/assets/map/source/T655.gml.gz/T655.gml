<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_bf3aa1cd-da36-4eeb-a228-fb5814c3b42e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">26.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67260789809278 139.73778691494365 0 35.672592535842064 139.737737886508 0 35.672520272649386 139.73777177512943 0 35.67253491203642 139.73781859507739 0 35.672517882504316 139.73782667935032 0 35.672581048921124 139.73802919805587 0 35.672694309472675 139.73797615030702 0 35.672631775593466 139.73777572945173 0 35.67260789809278 139.73778691494365 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67260789809278 139.73778691494365 8.9 35.672631775593466 139.73777572945173 8.9 35.672694309472675 139.73797615030702 8.9 35.672581048921124 139.73802919805587 8.9 35.672517882504316 139.73782667935032 8.9 35.67253491203642 139.73781859507739 8.9 35.672520272649386 139.73777177512943 8.9 35.672592535842064 139.737737886508 8.9 35.67260789809278 139.73778691494365 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67260789809278 139.73778691494365 8.9 35.672592535842064 139.737737886508 8.9 35.672592535842064 139.737737886508 35.76 35.67260789809278 139.73778691494365 35.76 35.67260789809278 139.73778691494365 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672592535842064 139.737737886508 8.9 35.672520272649386 139.73777177512943 8.9 35.672520272649386 139.73777177512943 35.76 35.672592535842064 139.737737886508 35.76 35.672592535842064 139.737737886508 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672520272649386 139.73777177512943 8.9 35.67253491203642 139.73781859507739 8.9 35.67253491203642 139.73781859507739 35.76 35.672520272649386 139.73777177512943 35.76 35.672520272649386 139.73777177512943 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67253491203642 139.73781859507739 8.9 35.672517882504316 139.73782667935032 8.9 35.672517882504316 139.73782667935032 35.76 35.67253491203642 139.73781859507739 35.76 35.67253491203642 139.73781859507739 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672517882504316 139.73782667935032 8.9 35.672581048921124 139.73802919805587 8.9 35.672581048921124 139.73802919805587 35.76 35.672517882504316 139.73782667935032 35.76 35.672517882504316 139.73782667935032 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672581048921124 139.73802919805587 8.9 35.672694309472675 139.73797615030702 8.9 35.672694309472675 139.73797615030702 35.76 35.672581048921124 139.73802919805587 35.76 35.672581048921124 139.73802919805587 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672694309472675 139.73797615030702 8.9 35.672631775593466 139.73777572945173 8.9 35.672631775593466 139.73777572945173 35.76 35.672694309472675 139.73797615030702 35.76 35.672694309472675 139.73797615030702 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672631775593466 139.73777572945173 8.9 35.67260789809278 139.73778691494365 8.9 35.67260789809278 139.73778691494365 35.76 35.672631775593466 139.73777572945173 35.76 35.672631775593466 139.73777572945173 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67260789809278 139.73778691494365 35.76 35.672592535842064 139.737737886508 35.76 35.672520272649386 139.73777177512943 35.76 35.67253491203642 139.73781859507739 35.76 35.672517882504316 139.73782667935032 35.76 35.672581048921124 139.73802919805587 35.76 35.672694309472675 139.73797615030702 35.76 35.672631775593466 139.73777572945173 35.76 35.67260789809278 139.73778691494365 35.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5216702d-9d33-4732-a20c-81174282d648"/>
							<gml:surfaceMember xlink:href="#poly-c6229396-f06e-4c36-8bf2-a410e55df859"/>
							<gml:surfaceMember xlink:href="#poly-81105145-c8c5-435f-9058-f8eefcf97d51"/>
							<gml:surfaceMember xlink:href="#poly-f492a4da-8134-467f-87c7-aef1b791c7a3"/>
							<gml:surfaceMember xlink:href="#poly-b00df439-a612-44bc-86ae-40b81ca238c1"/>
							<gml:surfaceMember xlink:href="#poly-867b4393-fc59-4272-aecf-3ecdd6dbbffc"/>
							<gml:surfaceMember xlink:href="#poly-f624db78-20a8-4840-a45f-c849dc144b83"/>
							<gml:surfaceMember xlink:href="#poly-cbe9e4e4-07fe-4f2b-9b22-db201c2db238"/>
							<gml:surfaceMember xlink:href="#poly-d9622c6d-473a-4934-9d4d-1bb92775a2c6"/>
							<gml:surfaceMember xlink:href="#poly-f6e8eade-22a5-4a4b-88fc-b0b6ee0e9e11"/>
							<gml:surfaceMember xlink:href="#poly-97b43005-58ef-4b53-84e8-b01362707139"/>
							<gml:surfaceMember xlink:href="#poly-5d01b0c2-67dd-4bd3-a863-b31077848f75"/>
							<gml:surfaceMember xlink:href="#poly-def7c9d7-0416-4611-a238-2359ab79c7b7"/>
							<gml:surfaceMember xlink:href="#poly-dfd4167f-b430-4871-9c4d-da532d46eacc"/>
							<gml:surfaceMember xlink:href="#poly-b85e40f2-3f8b-455d-b08a-b098ba18df91"/>
							<gml:surfaceMember xlink:href="#poly-420c7164-f940-4dd5-9e00-ec6f0de0efc6"/>
							<gml:surfaceMember xlink:href="#poly-1605a8c2-2c35-4d4b-83ac-f8e6ddd85c56"/>
							<gml:surfaceMember xlink:href="#poly-068ae16c-f05b-4455-8694-b67c0701589f"/>
							<gml:surfaceMember xlink:href="#poly-aeec18f7-b3f8-4f71-839e-8d240d9b5683"/>
							<gml:surfaceMember xlink:href="#poly-01de93a0-a98f-4938-906f-4099089f98ad"/>
							<gml:surfaceMember xlink:href="#poly-b2c56eb9-2e44-41a0-a99d-ad028079d7ee"/>
							<gml:surfaceMember xlink:href="#poly-063f42ed-316e-4477-831c-55ca373a5ff1"/>
							<gml:surfaceMember xlink:href="#poly-f8cef14d-0a7c-435e-a8b2-36facc6c63ee"/>
							<gml:surfaceMember xlink:href="#poly-b6ca5720-72f5-43ab-8201-ef613796d887"/>
							<gml:surfaceMember xlink:href="#poly-770819ba-838c-4ba8-b4d5-efd6923ee00d"/>
							<gml:surfaceMember xlink:href="#poly-09e60d66-32ce-4fff-a473-1374118c5955"/>
							<gml:surfaceMember xlink:href="#poly-b24ff87a-4eb0-4967-9251-b8d448676612"/>
							<gml:surfaceMember xlink:href="#poly-bc7e6089-d2c1-47f1-8f2d-38d59782ff25"/>
							<gml:surfaceMember xlink:href="#poly-dface5b0-5cbf-4429-9b89-9143787c143b"/>
							<gml:surfaceMember xlink:href="#poly-4f639cb0-a779-46fb-bfff-03c64c50bd8c"/>
							<gml:surfaceMember xlink:href="#poly-5e77141a-4834-4bb4-b367-cc2ca45a4128"/>
							<gml:surfaceMember xlink:href="#poly-058f0aa0-ba7a-4f9f-bdf9-ad74fdb82b4e"/>
							<gml:surfaceMember xlink:href="#poly-7be1a19c-c3b2-4cc9-a962-d511befd281d"/>
							<gml:surfaceMember xlink:href="#poly-ff42b2aa-5dd8-4d03-aed9-3eee9f1cbd0e"/>
							<gml:surfaceMember xlink:href="#poly-af7ed548-1e20-48c5-86da-71a5dd15d763"/>
							<gml:surfaceMember xlink:href="#poly-1aca13d4-90c4-49c6-9fe4-f0a142cdb460"/>
							<gml:surfaceMember xlink:href="#poly-73a7d708-85ab-43a7-9c7d-d0e7fd134edb"/>
							<gml:surfaceMember xlink:href="#poly-2e5c8ea9-68ea-4b8c-abe2-70e0be5e6d89"/>
							<gml:surfaceMember xlink:href="#poly-08423413-0206-4b36-ad8f-3dae8db39c73"/>
							<gml:surfaceMember xlink:href="#poly-3948195d-3d03-4498-bf32-7623a76392f2"/>
							<gml:surfaceMember xlink:href="#poly-dfbe30a9-08e1-40d6-b42d-1ad99b4c732b"/>
							<gml:surfaceMember xlink:href="#poly-3fadb647-2a75-414c-963a-e2842f17e1aa"/>
							<gml:surfaceMember xlink:href="#poly-20c2f73f-7c4c-499c-97b3-1b103a139024"/>
							<gml:surfaceMember xlink:href="#poly-eb20c3c2-88fc-4f3d-9b60-18700e17a4ec"/>
							<gml:surfaceMember xlink:href="#poly-f4030b98-0623-4216-ac70-445cbb56915a"/>
							<gml:surfaceMember xlink:href="#poly-09b2520a-5e2f-4c1f-988c-87235e0bdc35"/>
							<gml:surfaceMember xlink:href="#poly-a69da7a4-4a02-47ca-b6c8-81c536d3cf8d"/>
							<gml:surfaceMember xlink:href="#poly-ea006a4a-27a5-42b0-81c8-a75e20dfa92a"/>
							<gml:surfaceMember xlink:href="#poly-e8cf5d53-fd48-4bbd-8646-7e1fc604f5ec"/>
							<gml:surfaceMember xlink:href="#poly-ab43f752-2f93-435b-8282-c9690dc43c73"/>
							<gml:surfaceMember xlink:href="#poly-c7ebdd86-3705-427c-84fd-80bf72f1fbd0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bf3aa1cd-da36-4eeb-a228-fb5814c3b42e_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce062984-ce95-4538-9f1a-397d99866d7a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672580830506135 139.737901378542 36.073 35.67256143116595 139.7379104819062 36.073 35.672546457466254 139.73786260185454 36.073 35.67256585680284 139.7378534984805 36.073 35.672580830506135 139.737901378542 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ca39b03-32d8-4d62-b60f-aa8a845f5ff7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ca39b03-32d8-4d62-b60f-aa8a845f5ff7_0">
											<gml:posList>35.672546457466254 139.73786260185454 36.073 35.672546457466254 139.73786260185454 38.51 35.67256585680284 139.7378534984805 38.51 35.67256585680284 139.7378534984805 36.073 35.672546457466254 139.73786260185454 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74ca1da6-aa40-4f16-a0e3-ef7883292e5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74ca1da6-aa40-4f16-a0e3-ef7883292e5a_0">
											<gml:posList>35.67256585680284 139.7378534984805 36.073 35.67256585680284 139.7378534984805 38.51 35.672580830506135 139.737901378542 38.51 35.672580830506135 139.737901378542 36.073 35.67256585680284 139.7378534984805 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81012700-b8bc-4a52-ba8a-0f94c4895346">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81012700-b8bc-4a52-ba8a-0f94c4895346_0">
											<gml:posList>35.672546457466254 139.73786260185454 38.51 35.67256143116595 139.7379104819062 38.51 35.672580830506135 139.737901378542 38.51 35.67256585680284 139.7378534984805 38.51 35.672546457466254 139.73786260185454 38.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-249a20b5-51c7-42bc-b3ac-08c9ec1cbb3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-249a20b5-51c7-42bc-b3ac-08c9ec1cbb3a_0">
											<gml:posList>35.67256143116595 139.7379104819062 36.073 35.67256143116595 139.7379104819062 38.51 35.672546457466254 139.73786260185454 38.51 35.672546457466254 139.73786260185454 36.073 35.67256143116595 139.7379104819062 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76da9cec-7ca8-456f-92ae-c7568ddc6ff8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76da9cec-7ca8-456f-92ae-c7568ddc6ff8_0">
											<gml:posList>35.672580830506135 139.737901378542 36.073 35.672580830506135 139.737901378542 38.51 35.67256143116595 139.7379104819062 38.51 35.67256143116595 139.7379104819062 36.073 35.672580830506135 139.737901378542 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bf3aa1cd-da36-4eeb-a228-fb5814c3b42e_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb3be281-6955-4f40-a06b-3fd49108004e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67258914555182 139.7378273345754 36.073 35.67255917749683 139.73784196278064 36.073 35.67255458732222 139.73782783969932 36.073 35.67257903209535 139.737815902385 36.073 35.672584555375515 139.73781321148965 36.073 35.67258914555182 139.7378273345754 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5063b440-d3c5-42f7-a998-7814f3831586">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5063b440-d3c5-42f7-a998-7814f3831586_0">
											<gml:posList>35.67255917749683 139.73784196278064 36.073 35.67255917749683 139.73784196278064 36.97 35.67255458732222 139.73782783969932 36.97 35.67255458732222 139.73782783969932 36.073 35.67255917749683 139.73784196278064 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b402e18-e2a5-4128-9154-6a5fe6902f3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b402e18-e2a5-4128-9154-6a5fe6902f3d_0">
											<gml:posList>35.67255458732222 139.73782783969932 36.97 35.67257903209535 139.737815902385 36.97 35.67257903209535 139.737815902385 36.073 35.67255458732222 139.73782783969932 36.073 35.67255458732222 139.73782783969932 36.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c64cefd-db81-4cfc-9063-ae880f0c36d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c64cefd-db81-4cfc-9063-ae880f0c36d1_0">
											<gml:posList>35.67257903209535 139.737815902385 36.97 35.67255458732222 139.73782783969932 36.97 35.67255917749683 139.73784196278064 36.97 35.67258914555182 139.7378273345754 36.97 35.672584555375515 139.73781321148965 36.97 35.67257903209535 139.737815902385 36.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3292ab34-7887-48e6-82de-fff026518c4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3292ab34-7887-48e6-82de-fff026518c4e_0">
											<gml:posList>35.67258914555182 139.7378273345754 36.073 35.67258914555182 139.7378273345754 36.97 35.67255917749683 139.73784196278064 36.97 35.67255917749683 139.73784196278064 36.073 35.67258914555182 139.7378273345754 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-742f9b6c-1e8a-4c85-9db4-089c9f913fbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-742f9b6c-1e8a-4c85-9db4-089c9f913fbe_0">
											<gml:posList>35.672584555375515 139.73781321148965 36.073 35.67257903209535 139.737815902385 36.073 35.67257903209535 139.737815902385 36.97 35.672584555375515 139.73781321148965 36.97 35.672584555375515 139.73781321148965 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b86deb9-5b35-4d76-ae50-bbff77f4abc1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b86deb9-5b35-4d76-ae50-bbff77f4abc1_0">
											<gml:posList>35.672584555375515 139.73781321148965 36.073 35.672584555375515 139.73781321148965 36.97 35.67258914555182 139.7378273345754 36.97 35.67258914555182 139.7378273345754 36.073 35.672584555375515 139.73781321148965 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_bf3aa1cd-da36-4eeb-a228-fb5814c3b42e_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-403c21eb-4fe1-4a0a-a9a1-d7be57519ebf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-403c21eb-4fe1-4a0a-a9a1-d7be57519ebf_0">
											<gml:posList>35.672631587118445 139.73791314899938 36.073 35.67262525284651 139.73791615015855 37.723 35.672631587118445 139.73791314899938 37.723 35.672631587118445 139.73791314899938 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc02d5df-a027-474a-9987-02db70eec2d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc02d5df-a027-474a-9987-02db70eec2d7_0">
											<gml:posList>35.672631587118445 139.73791314899938 36.073 35.67262525284651 139.73791615015855 36.073 35.67262525284651 139.73791615015855 37.723 35.672631587118445 139.73791314899938 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d2ff762-7d88-499a-b25e-f79b6b0f977c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d2ff762-7d88-499a-b25e-f79b6b0f977c_0">
											<gml:posList>35.6726042686236 139.7379385665219 36.073 35.672597934351 139.73794156767806 37.723 35.672597934351 139.73794156767806 36.073 35.6726042686236 139.7379385665219 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87d236ad-d6b3-4318-b4a7-07ae9492c686">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87d236ad-d6b3-4318-b4a7-07ae9492c686_0">
											<gml:posList>35.6726042686236 139.7379385665219 36.073 35.6726042686236 139.7379385665219 37.723 35.672597934351 139.73794156767806 37.723 35.6726042686236 139.7379385665219 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb1d5e7e-5c75-4759-8775-3381f88d80dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb1d5e7e-5c75-4759-8775-3381f88d80dd_0">
											<gml:posList>35.672583094216904 139.7379484783908 36.073 35.67258942848969 139.7379454772357 37.723 35.672583094216904 139.7379484783908 37.723 35.672583094216904 139.7379484783908 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2e2f5e5-f136-4aa5-b85b-700ea132c9ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2e2f5e5-f136-4aa5-b85b-700ea132c9ad_0">
											<gml:posList>35.672583094216904 139.7379484783908 36.073 35.67258942848969 139.7379454772357 36.073 35.67258942848969 139.7379454772357 37.723 35.672583094216904 139.7379484783908 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b9038cb-5666-4ff2-9348-52f9e64beaf0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b9038cb-5666-4ff2-9348-52f9e64beaf0_0">
											<gml:posList>35.6725799043406 139.73793834144183 36.073 35.672583094216904 139.7379484783908 37.723 35.6725799043406 139.73793834144183 37.723 35.6725799043406 139.73793834144183 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fee3b0f-23be-43f3-b85d-d3ea9b81675b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fee3b0f-23be-43f3-b85d-d3ea9b81675b_0">
											<gml:posList>35.6725799043406 139.73793834144183 36.073 35.672583094216904 139.7379484783908 36.073 35.672583094216904 139.7379484783908 37.723 35.6725799043406 139.73793834144183 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52fa8ff2-8101-4fe0-93aa-0968a3e13b0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52fa8ff2-8101-4fe0-93aa-0968a3e13b0d_0">
											<gml:posList>35.672586238621896 139.73793535133265 36.073 35.6725799043406 139.73793834144183 37.723 35.672586238621896 139.73793535133265 37.723 35.672586238621896 139.73793535133265 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cca66881-9b08-483d-950d-b071ca84fcff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cca66881-9b08-483d-950d-b071ca84fcff_0">
											<gml:posList>35.672586238621896 139.73793535133265 36.073 35.6725799043406 139.73793834144183 36.073 35.6725799043406 139.73793834144183 37.723 35.672586238621896 139.73793535133265 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59161a6e-101c-45e1-924b-fd6a9ebd8407">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59161a6e-101c-45e1-924b-fd6a9ebd8407_0">
											<gml:posList>35.67258942848969 139.7379454772357 37.723 35.672586238621896 139.73793535133265 37.723 35.6725799043406 139.73793834144183 37.723 35.67258942848969 139.7379454772357 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb2078d8-1e60-45b1-b244-3d122545dd37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb2078d8-1e60-45b1-b244-3d122545dd37_0">
											<gml:posList>35.672583094216904 139.7379484783908 37.723 35.67258942848969 139.7379454772357 37.723 35.6725799043406 139.73793834144183 37.723 35.672583094216904 139.7379484783908 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da6e1a2b-b162-4c05-abad-064f32540a13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da6e1a2b-b162-4c05-abad-064f32540a13_0">
											<gml:posList>35.672583916539196 139.73795109544778 36.073 35.672586763018145 139.73796012814992 37.723 35.672583916539196 139.73795109544778 37.723 35.672583916539196 139.73795109544778 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50a6c9aa-fe2a-4ceb-9d6f-86d968d1f953">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50a6c9aa-fe2a-4ceb-9d6f-86d968d1f953_0">
											<gml:posList>35.672583916539196 139.73795109544778 36.073 35.672586763018145 139.73796012814992 36.073 35.672586763018145 139.73796012814992 37.723 35.672583916539196 139.73795109544778 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acbf7cf1-9f93-4db7-ac61-4b65a3c2817a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acbf7cf1-9f93-4db7-ac61-4b65a3c2817a_0">
											<gml:posList>35.672590259825775 139.7379480942822 36.073 35.672583916539196 139.73795109544778 37.723 35.672590259825775 139.7379480942822 37.723 35.672590259825775 139.7379480942822 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e471793e-ebe8-4005-8357-656a969e1ccc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e471793e-ebe8-4005-8357-656a969e1ccc_0">
											<gml:posList>35.672590259825775 139.7379480942822 36.073 35.672583916539196 139.73795109544778 36.073 35.672583916539196 139.73795109544778 37.723 35.672590259825775 139.7379480942822 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b68cb363-d756-425a-8270-28248fd9c948">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b68cb363-d756-425a-8270-28248fd9c948_0">
											<gml:posList>35.67258942848969 139.7379454772357 36.073 35.672586238621896 139.73793535133265 37.723 35.67258942848969 139.7379454772357 37.723 35.67258942848969 139.7379454772357 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-742d0106-a4c4-49c7-b719-3571e6bc63b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-742d0106-a4c4-49c7-b719-3571e6bc63b6_0">
											<gml:posList>35.67258942848969 139.7379454772357 36.073 35.672586238621896 139.73793535133265 36.073 35.672586238621896 139.73793535133265 37.723 35.67258942848969 139.7379454772357 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbdba8b5-a9fc-4642-b41e-e4fc2e5fe747">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbdba8b5-a9fc-4642-b41e-e4fc2e5fe747_0">
											<gml:posList>35.672583916539196 139.73795109544778 37.723 35.67259309729122 139.73795712699567 37.723 35.672590259825775 139.7379480942822 37.723 35.672583916539196 139.73795109544778 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a048ad9e-b296-4f53-bd1d-de447a7b4f56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a048ad9e-b296-4f53-bd1d-de447a7b4f56_0">
											<gml:posList>35.672583916539196 139.73795109544778 37.723 35.672586763018145 139.73796012814992 37.723 35.67259309729122 139.73795712699567 37.723 35.672583916539196 139.73795109544778 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4dca0ec8-3d71-4a1f-b4b5-2740946353cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4dca0ec8-3d71-4a1f-b4b5-2740946353cb_0">
											<gml:posList>35.672586763018145 139.73796012814992 36.073 35.67259309729122 139.73795712699567 37.723 35.672586763018145 139.73796012814992 37.723 35.672586763018145 139.73796012814992 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f609cd3b-6774-4809-af06-c13cf853c17d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f609cd3b-6774-4809-af06-c13cf853c17d_0">
											<gml:posList>35.672586763018145 139.73796012814992 36.073 35.67259309729122 139.73795712699567 36.073 35.67259309729122 139.73795712699567 37.723 35.672586763018145 139.73796012814992 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7104f8ae-56d6-4a5e-bdf1-cb879b6e28d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7104f8ae-56d6-4a5e-bdf1-cb879b6e28d3_0">
											<gml:posList>35.67259309729122 139.73795712699567 36.073 35.672590259825775 139.7379480942822 37.723 35.67259309729122 139.73795712699567 37.723 35.67259309729122 139.73795712699567 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-791238ef-395f-408d-a4e6-426b3f12b0ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-791238ef-395f-408d-a4e6-426b3f12b0ed_0">
											<gml:posList>35.67259309729122 139.73795712699567 36.073 35.672590259825775 139.7379480942822 36.073 35.672590259825775 139.7379480942822 37.723 35.67259309729122 139.73795712699567 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49485e70-89d4-48fe-b3e9-bf0c30cd3775">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49485e70-89d4-48fe-b3e9-bf0c30cd3775_0">
											<gml:posList>35.672594744482886 139.73793144177407 36.073 35.672597934351 139.73794156767806 37.723 35.672594744482886 139.73793144177407 37.723 35.672594744482886 139.73793144177407 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21a56d14-eb35-4e30-b253-d31caf791517">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21a56d14-eb35-4e30-b253-d31caf791517_0">
											<gml:posList>35.672594744482886 139.73793144177407 36.073 35.672597934351 139.73794156767806 36.073 35.672597934351 139.73794156767806 37.723 35.672594744482886 139.73793144177407 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d9ca9ec-7db9-424c-8b6e-f65a6983e2af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d9ca9ec-7db9-424c-8b6e-f65a6983e2af_0">
											<gml:posList>35.672601078755235 139.73792844061722 36.073 35.672594744482886 139.73793144177407 37.723 35.672601078755235 139.73792844061722 37.723 35.672601078755235 139.73792844061722 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6686e540-4825-4407-968a-4e3aeeebd5e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6686e540-4825-4407-968a-4e3aeeebd5e6_0">
											<gml:posList>35.672601078755235 139.73792844061722 36.073 35.672594744482886 139.73793144177407 36.073 35.672594744482886 139.73793144177407 37.723 35.672601078755235 139.73792844061722 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2530c00b-13ca-4895-b6c3-7bd75c85dfcc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2530c00b-13ca-4895-b6c3-7bd75c85dfcc_0">
											<gml:posList>35.672594744482886 139.73793144177407 37.723 35.6726042686236 139.7379385665219 37.723 35.672601078755235 139.73792844061722 37.723 35.672594744482886 139.73793144177407 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccde222d-df41-451e-90bd-5db1bb863616">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccde222d-df41-451e-90bd-5db1bb863616_0">
											<gml:posList>35.672594744482886 139.73793144177407 37.723 35.672597934351 139.73794156767806 37.723 35.6726042686236 139.7379385665219 37.723 35.672594744482886 139.73793144177407 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-877b0013-6bcb-492d-be51-5422e2478453">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-877b0013-6bcb-492d-be51-5422e2478453_0">
											<gml:posList>35.67259875667345 139.73794418473545 36.073 35.67260161216662 139.73795321742833 37.723 35.67259875667345 139.73794418473545 37.723 35.67259875667345 139.73794418473545 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b139d551-59d1-41d9-bbba-820bf264c754">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b139d551-59d1-41d9-bbba-820bf264c754_0">
											<gml:posList>35.67259875667345 139.73794418473545 36.073 35.67260161216662 139.73795321742833 36.073 35.67260161216662 139.73795321742833 37.723 35.67259875667345 139.73794418473545 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ca03d78-ca28-4e10-88f5-17e35038b137">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ca03d78-ca28-4e10-88f5-17e35038b137_0">
											<gml:posList>35.67260509995983 139.73794118356878 36.073 35.67259875667345 139.73794418473545 37.723 35.67260509995983 139.73794118356878 37.723 35.67260509995983 139.73794118356878 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff5b00f7-4dc6-43a8-baaa-8f169218b97a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff5b00f7-4dc6-43a8-baaa-8f169218b97a_0">
											<gml:posList>35.67260509995983 139.73794118356878 36.073 35.67259875667345 139.73794418473545 36.073 35.67259875667345 139.73794418473545 37.723 35.67260509995983 139.73794118356878 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16a20d7d-d878-4315-a062-e8c805bb9170">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16a20d7d-d878-4315-a062-e8c805bb9170_0">
											<gml:posList>35.672601078755235 139.73792844061722 36.073 35.6726042686236 139.7379385665219 37.723 35.6726042686236 139.7379385665219 36.073 35.672601078755235 139.73792844061722 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33218d4d-8e8f-48b4-9447-8a06199bdaae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33218d4d-8e8f-48b4-9447-8a06199bdaae_0">
											<gml:posList>35.672601078755235 139.73792844061722 36.073 35.672601078755235 139.73792844061722 37.723 35.6726042686236 139.7379385665219 37.723 35.672601078755235 139.73792844061722 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46880a2d-bd67-491c-8dba-28d89df86242">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46880a2d-bd67-491c-8dba-28d89df86242_0">
											<gml:posList>35.67260161216662 139.73795321742833 37.723 35.67260793743455 139.73795022733023 37.723 35.67260509995983 139.73794118356878 37.723 35.67260161216662 139.73795321742833 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f9eef2c-5d07-435c-a52f-f9f23054d310">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f9eef2c-5d07-435c-a52f-f9f23054d310_0">
											<gml:posList>35.67259875667345 139.73794418473545 37.723 35.67260161216662 139.73795321742833 37.723 35.67260509995983 139.73794118356878 37.723 35.67259875667345 139.73794418473545 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-247bfcbc-ccc9-4d8a-922d-8f917f013fb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-247bfcbc-ccc9-4d8a-922d-8f917f013fb5_0">
											<gml:posList>35.67260161216662 139.73795321742833 36.073 35.67260793743455 139.73795022733023 37.723 35.67260161216662 139.73795321742833 37.723 35.67260161216662 139.73795321742833 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8364e69-6e64-487d-81c7-14d6c24e9baf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8364e69-6e64-487d-81c7-14d6c24e9baf_0">
											<gml:posList>35.67260161216662 139.73795321742833 36.073 35.67260793743455 139.73795022733023 36.073 35.67260793743455 139.73795022733023 37.723 35.67260161216662 139.73795321742833 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8578f8a5-e086-4625-b3cb-6cb08b49005f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8578f8a5-e086-4625-b3cb-6cb08b49005f_0">
											<gml:posList>35.67260793743455 139.73795022733023 36.073 35.67260509995983 139.73794118356878 37.723 35.67260793743455 139.73795022733023 37.723 35.67260793743455 139.73795022733023 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b613321c-52ed-4368-bc9f-09618bc23c29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b613321c-52ed-4368-bc9f-09618bc23c29_0">
											<gml:posList>35.67260793743455 139.73795022733023 36.073 35.67260509995983 139.73794118356878 36.073 35.67260509995983 139.73794118356878 37.723 35.67260793743455 139.73795022733023 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c336c2e5-9094-4dab-8316-7f2b676e7a24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c336c2e5-9094-4dab-8316-7f2b676e7a24_0">
											<gml:posList>35.672610548339875 139.73792359095214 36.073 35.67261373821741 139.73793372790436 37.723 35.672610548339875 139.73792359095214 37.723 35.672610548339875 139.73792359095214 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88d68471-0e52-421b-bfed-54732ff9e3a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88d68471-0e52-421b-bfed-54732ff9e3a0_0">
											<gml:posList>35.672610548339875 139.73792359095214 36.073 35.67261373821741 139.73793372790436 36.073 35.67261373821741 139.73793372790436 37.723 35.672610548339875 139.73792359095214 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35ade5c8-8ebc-4b8b-a3c4-9e402ba6dc0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35ade5c8-8ebc-4b8b-a3c4-9e402ba6dc0c_0">
											<gml:posList>35.67261456955373 139.7379363449515 36.073 35.67261741603378 139.73794537765656 37.723 35.67261456955373 139.7379363449515 37.723 35.67261456955373 139.7379363449515 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f198e87-30e6-4325-96cc-21d86d6ae328">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f198e87-30e6-4325-96cc-21d86d6ae328_0">
											<gml:posList>35.67261456955373 139.7379363449515 36.073 35.67261741603378 139.73794537765656 36.073 35.67261741603378 139.73794537765656 37.723 35.67261456955373 139.7379363449515 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e5369d5-efdd-4db7-9621-d4c304213c89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e5369d5-efdd-4db7-9621-d4c304213c89_0">
											<gml:posList>35.67261373821741 139.73793372790436 36.073 35.672620072489785 139.73793072674698 37.723 35.67261373821741 139.73793372790436 37.723 35.67261373821741 139.73793372790436 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8dd7e778-58da-4e68-b67e-f4828b6c8e19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8dd7e778-58da-4e68-b67e-f4828b6c8e19_0">
											<gml:posList>35.67261373821741 139.73793372790436 36.073 35.672620072489785 139.73793072674698 36.073 35.672620072489785 139.73793072674698 37.723 35.67261373821741 139.73793372790436 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ae9760b-2411-4310-8eb3-62991c213166">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ae9760b-2411-4310-8eb3-62991c213166_0">
											<gml:posList>35.67262090382618 139.7379333437943 36.073 35.67261456955373 139.7379363449515 37.723 35.67262090382618 139.7379333437943 37.723 35.67262090382618 139.7379333437943 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc6c18c8-b57d-43c6-90a2-26cbc4ff13e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc6c18c8-b57d-43c6-90a2-26cbc4ff13e9_0">
											<gml:posList>35.67262090382618 139.7379333437943 36.073 35.67261456955373 139.7379363449515 36.073 35.67261456955373 139.7379363449515 37.723 35.67262090382618 139.7379333437943 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c6ead2a-a3d9-42b7-9dda-1c92f6ff5da7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c6ead2a-a3d9-42b7-9dda-1c92f6ff5da7_0">
											<gml:posList>35.67261741603378 139.73794537765656 37.723 35.67262090382618 139.7379333437943 37.723 35.67261456955373 139.7379363449515 37.723 35.67261741603378 139.73794537765656 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f2182af-9ea0-4ab6-82c7-3b48e13ea6fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f2182af-9ea0-4ab6-82c7-3b48e13ea6fa_0">
											<gml:posList>35.67261741603378 139.73794537765656 37.723 35.6726237503152 139.73794238754655 37.723 35.67262090382618 139.7379333437943 37.723 35.67261741603378 139.73794537765656 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cf230b4-f7ff-47b7-b289-7440c27426e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cf230b4-f7ff-47b7-b289-7440c27426e8_0">
											<gml:posList>35.67261741603378 139.73794537765656 36.073 35.6726237503152 139.73794238754655 37.723 35.67261741603378 139.73794537765656 37.723 35.67261741603378 139.73794537765656 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-708c7a64-1c1c-449d-acd0-e7be4e81ffa2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-708c7a64-1c1c-449d-acd0-e7be4e81ffa2_0">
											<gml:posList>35.67261741603378 139.73794537765656 36.073 35.6726237503152 139.73794238754655 36.073 35.6726237503152 139.73794238754655 37.723 35.67261741603378 139.73794537765656 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d8430a5-d858-49f8-af3f-943612d4ec74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d8430a5-d858-49f8-af3f-943612d4ec74_0">
											<gml:posList>35.6726237503152 139.73794238754655 36.073 35.67262090382618 139.7379333437943 37.723 35.6726237503152 139.73794238754655 37.723 35.6726237503152 139.73794238754655 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e935bcdc-6eb0-4380-a527-a876d83c16d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e935bcdc-6eb0-4380-a527-a876d83c16d8_0">
											<gml:posList>35.6726237503152 139.73794238754655 36.073 35.67262090382618 139.7379333437943 36.073 35.67262090382618 139.7379333437943 37.723 35.6726237503152 139.73794238754655 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3342f798-13d0-410c-9c97-430d687c0c61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3342f798-13d0-410c-9c97-430d687c0c61_0">
											<gml:posList>35.67262926504743 139.73792890417062 36.073 35.67263211152803 139.73793793687707 37.723 35.67262926504743 139.73792890417062 37.723 35.67262926504743 139.73792890417062 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92b21a64-f628-4513-bbc2-958e8a093ac5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92b21a64-f628-4513-bbc2-958e8a093ac5_0">
											<gml:posList>35.67262926504743 139.73792890417062 36.073 35.67263211152803 139.73793793687707 36.073 35.67263211152803 139.73793793687707 37.723 35.67262926504743 139.73792890417062 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04e46dbc-3148-4389-8934-180a350b539d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04e46dbc-3148-4389-8934-180a350b539d_0">
											<gml:posList>35.6726384458005 139.73793493571935 37.723 35.67263559931968 139.7379259030123 37.723 35.67262926504743 139.73792890417062 37.723 35.6726384458005 139.73793493571935 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0218db6b-1af5-4aeb-b722-4f214f9daecd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0218db6b-1af5-4aeb-b722-4f214f9daecd_0">
											<gml:posList>35.67263211152803 139.73793793687707 37.723 35.6726384458005 139.73793493571935 37.723 35.67262926504743 139.73792890417062 37.723 35.67263211152803 139.73793793687707 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ca82473-649f-4f4a-9b88-4efe54cfa706">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ca82473-649f-4f4a-9b88-4efe54cfa706_0">
											<gml:posList>35.67263211152803 139.73793793687707 36.073 35.6726384458005 139.73793493571935 37.723 35.67263211152803 139.73793793687707 37.723 35.67263211152803 139.73793793687707 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42457687-b029-48b5-95d2-ed685c1b9aab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42457687-b029-48b5-95d2-ed685c1b9aab_0">
											<gml:posList>35.67263211152803 139.73793793687707 36.073 35.6726384458005 139.73793493571935 36.073 35.6726384458005 139.73793493571935 37.723 35.67263211152803 139.73793793687707 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73fdac4e-c330-4329-8d4e-bd9b3de2f4d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73fdac4e-c330-4329-8d4e-bd9b3de2f4d7_0">
											<gml:posList>35.6726384458005 139.73793493571935 36.073 35.67263559931968 139.7379259030123 37.723 35.6726384458005 139.73793493571935 37.723 35.6726384458005 139.73793493571935 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8582a7af-f484-4f04-af02-12f9987fcfa4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8582a7af-f484-4f04-af02-12f9987fcfa4_0">
											<gml:posList>35.6726384458005 139.73793493571935 36.073 35.67263559931968 139.7379259030123 36.073 35.67263559931968 139.7379259030123 37.723 35.6726384458005 139.73793493571935 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4e24429-98d9-4647-a25a-3281dc8ab80b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4e24429-98d9-4647-a25a-3281dc8ab80b_0">
											<gml:posList>35.672647212919195 139.73793084910213 36.073 35.67265354719148 139.73792784794327 37.723 35.672647212919195 139.73793084910213 37.723 35.672647212919195 139.73793084910213 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-598349f6-e203-4c9a-9e7c-d3a6e4bdef29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-598349f6-e203-4c9a-9e7c-d3a6e4bdef29_0">
											<gml:posList>35.672647212919195 139.73793084910213 36.073 35.67265354719148 139.73792784794327 36.073 35.67265354719148 139.73792784794327 37.723 35.672647212919195 139.73793084910213 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ede60c20-874f-4042-8ca8-8945e00d9ee6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ede60c20-874f-4042-8ca8-8945e00d9ee6_0">
											<gml:posList>35.67255308318921 139.73784066654562 36.073 35.672533945014884 139.73784947135326 37.349 35.67255308318921 139.73784066654562 37.349 35.67255308318921 139.73784066654562 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18d37643-5490-4615-9904-d5ebdb115614">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18d37643-5490-4615-9904-d5ebdb115614_0">
											<gml:posList>35.67255308318921 139.73784066654562 36.073 35.672533945014884 139.73784947135326 36.073 35.672533945014884 139.73784947135326 37.349 35.67255308318921 139.73784066654562 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6761cf5b-1d00-4b20-b0a3-e8e588cbe128">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6761cf5b-1d00-4b20-b0a3-e8e588cbe128_0">
											<gml:posList>35.672555848544214 139.73784968829042 36.073 35.67255308318921 139.73784066654562 37.349 35.672555848544214 139.73784968829042 37.349 35.672555848544214 139.73784968829042 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aad9f378-0089-42c1-9e1d-bf4e023343ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aad9f378-0089-42c1-9e1d-bf4e023343ee_0">
											<gml:posList>35.672555848544214 139.73784968829042 36.073 35.67255308318921 139.73784066654562 36.073 35.67255308318921 139.73784066654562 37.349 35.672555848544214 139.73784968829042 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ed3363a-6464-40a3-8493-53f6eaba9d8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ed3363a-6464-40a3-8493-53f6eaba9d8d_0">
											<gml:posList>35.67257680402966 139.73785925174815 36.073 35.67261635885502 139.73783978477775 38.13 35.67261635885502 139.73783978477775 36.073 35.67257680402966 139.73785925174815 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a0a017e-fda6-4f38-800b-9283fa8d8c02">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a0a017e-fda6-4f38-800b-9283fa8d8c02_0">
											<gml:posList>35.67257680402966 139.73785925174815 36.073 35.67257680402966 139.73785925174815 38.13 35.67261635885502 139.73783978477775 38.13 35.67257680402966 139.73785925174815 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f4ea761-4a54-4769-99d6-c3d13ba8a197">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f4ea761-4a54-4769-99d6-c3d13ba8a197_0">
											<gml:posList>35.67253671036924 139.73785849309624 37.349 35.672555848544214 139.73784968829042 37.349 35.67255308318921 139.73784066654562 37.349 35.67253671036924 139.73785849309624 37.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6ef67a5-ae20-4888-882e-a004614ef808">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6ef67a5-ae20-4888-882e-a004614ef808_0">
											<gml:posList>35.672533945014884 139.73784947135326 37.349 35.67253671036924 139.73785849309624 37.349 35.67255308318921 139.73784066654562 37.349 35.672533945014884 139.73784947135326 37.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ac65bbf-6480-4da6-9008-ebec3a7c121e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ac65bbf-6480-4da6-9008-ebec3a7c121e_0">
											<gml:posList>35.67261527066553 139.73784290120588 36.073 35.672579355971884 139.7378605853431 38.13 35.672579355971884 139.7378605853431 36.073 35.67261527066553 139.73784290120588 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5e08918-4f7f-448f-a8b7-1c6ec7dcd6b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5e08918-4f7f-448f-a8b7-1c6ec7dcd6b2_0">
											<gml:posList>35.67261527066553 139.73784290120588 36.073 35.67261527066553 139.73784290120588 38.13 35.672579355971884 139.7378605853431 38.13 35.67261527066553 139.73784290120588 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b336f7a6-b967-4f92-a383-d36c2e007b54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b336f7a6-b967-4f92-a383-d36c2e007b54_0">
											<gml:posList>35.672533945014884 139.73784947135326 36.073 35.67253671036924 139.73785849309624 37.349 35.672533945014884 139.73784947135326 37.349 35.672533945014884 139.73784947135326 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ea2247d-97f9-49b0-995a-e3c1fb4e4883">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ea2247d-97f9-49b0-995a-e3c1fb4e4883_0">
											<gml:posList>35.672533945014884 139.73784947135326 36.073 35.67253671036924 139.73785849309624 36.073 35.67253671036924 139.73785849309624 37.349 35.672533945014884 139.73784947135326 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-029af2f3-0e09-49b7-9bfa-7d7f1cd531fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-029af2f3-0e09-49b7-9bfa-7d7f1cd531fc_0">
											<gml:posList>35.672555848544214 139.73784968829042 36.073 35.67253671036924 139.73785849309624 37.349 35.67253671036924 139.73785849309624 36.073 35.672555848544214 139.73784968829042 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49dbee0f-440a-4aba-b308-7218bf10a6ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49dbee0f-440a-4aba-b308-7218bf10a6ce_0">
											<gml:posList>35.672555848544214 139.73784968829042 36.073 35.672555848544214 139.73784968829042 37.349 35.67253671036924 139.73785849309624 37.349 35.672555848544214 139.73784968829042 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0788bae3-4cbd-4a85-baf1-d27efca9c4fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0788bae3-4cbd-4a85-baf1-d27efca9c4fe_0">
											<gml:posList>35.67261635885502 139.73783978477775 36.073 35.6726352251553 139.73789734807443 38.13 35.6726352251553 139.73789734807443 36.073 35.67261635885502 139.73783978477775 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4e065bc-0efe-43d2-8c60-5d83f659eb58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4e065bc-0efe-43d2-8c60-5d83f659eb58_0">
											<gml:posList>35.67261635885502 139.73783978477775 36.073 35.67261635885502 139.73783978477775 38.13 35.6726352251553 139.73789734807443 38.13 35.67261635885502 139.73783978477775 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e610e665-afa0-44c8-ab23-455b910fdd56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e610e665-afa0-44c8-ab23-455b910fdd56_0">
											<gml:posList>35.672632673213506 139.73789601447737 36.073 35.67261527066553 139.73784290120588 38.13 35.67261527066553 139.73784290120588 36.073 35.672632673213506 139.73789601447737 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6dd465a4-f566-451a-9670-72d5ade4096f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6dd465a4-f566-451a-9670-72d5ade4096f_0">
											<gml:posList>35.672632673213506 139.73789601447737 36.073 35.672632673213506 139.73789601447737 38.13 35.67261527066553 139.73784290120588 38.13 35.672632673213506 139.73789601447737 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-198dc1b8-9558-42bc-a63d-51162e14cda0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-198dc1b8-9558-42bc-a63d-51162e14cda0_0">
											<gml:posList>35.6726352251553 139.73789734807443 38.13 35.67261635885502 139.73783978477775 38.13 35.672632673213506 139.73789601447737 38.13 35.6726352251553 139.73789734807443 38.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-562c9932-c8f7-43b1-aa7c-9b2c84df778b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-562c9932-c8f7-43b1-aa7c-9b2c84df778b_0">
											<gml:posList>35.672595670320725 139.737916815021 38.13 35.6726352251553 139.73789734807443 38.13 35.672632673213506 139.73789601447737 38.13 35.672595670320725 139.737916815021 38.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bb613cd-6a5d-4c6e-91df-2072a730f8d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bb613cd-6a5d-4c6e-91df-2072a730f8d2_0">
											<gml:posList>35.67261635885502 139.73783978477775 38.13 35.67257680402966 139.73785925174815 38.13 35.67261527066553 139.73784290120588 38.13 35.67261635885502 139.73783978477775 38.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30024740-1205-4e7e-aa08-6e9394d8e669">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30024740-1205-4e7e-aa08-6e9394d8e669_0">
											<gml:posList>35.67257680402966 139.73785925174815 38.13 35.672595670320725 139.737916815021 38.13 35.672596758503374 139.73791368754812 38.13 35.67257680402966 139.73785925174815 38.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b0c6398-8cbd-4d9a-bba1-5396c32ba162">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b0c6398-8cbd-4d9a-bba1-5396c32ba162_0">
											<gml:posList>35.67261635885502 139.73783978477775 38.13 35.67261527066553 139.73784290120588 38.13 35.672632673213506 139.73789601447737 38.13 35.67261635885502 139.73783978477775 38.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be89f3dd-249f-4a0a-9b64-4636c34378ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be89f3dd-249f-4a0a-9b64-4636c34378ee_0">
											<gml:posList>35.67261527066553 139.73784290120588 38.13 35.67257680402966 139.73785925174815 38.13 35.672579355971884 139.7378605853431 38.13 35.67261527066553 139.73784290120588 38.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f67a5c3-f1ef-4dbe-98bc-c7cd5c99c1f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f67a5c3-f1ef-4dbe-98bc-c7cd5c99c1f8_0">
											<gml:posList>35.672596758503374 139.73791368754812 38.13 35.672595670320725 139.737916815021 38.13 35.672632673213506 139.73789601447737 38.13 35.672596758503374 139.73791368754812 38.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16aceb04-fad4-4916-b547-deb281a131c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16aceb04-fad4-4916-b547-deb281a131c3_0">
											<gml:posList>35.672579355971884 139.7378605853431 38.13 35.67257680402966 139.73785925174815 38.13 35.672596758503374 139.73791368754812 38.13 35.672579355971884 139.7378605853431 38.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d484a585-f584-4aab-881d-c175a44720b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d484a585-f584-4aab-881d-c175a44720b5_0">
											<gml:posList>35.672579355971884 139.7378605853431 36.073 35.672596758503374 139.73791368754812 38.13 35.672596758503374 139.73791368754812 36.073 35.672579355971884 139.7378605853431 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b74b429-ee08-4f66-992e-54cd085f04d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b74b429-ee08-4f66-992e-54cd085f04d4_0">
											<gml:posList>35.672579355971884 139.7378605853431 36.073 35.672579355971884 139.7378605853431 38.13 35.672596758503374 139.73791368754812 38.13 35.672579355971884 139.7378605853431 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ff84fd9-8d3e-44bb-a315-922d469386cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ff84fd9-8d3e-44bb-a315-922d469386cf_0">
											<gml:posList>35.67257680402966 139.73785925174815 36.073 35.672595670320725 139.737916815021 38.13 35.67257680402966 139.73785925174815 38.13 35.67257680402966 139.73785925174815 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d94ef91-8bab-454d-9b8a-b14a007920e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d94ef91-8bab-454d-9b8a-b14a007920e9_0">
											<gml:posList>35.67257680402966 139.73785925174815 36.073 35.672595670320725 139.737916815021 36.073 35.672595670320725 139.737916815021 38.13 35.67257680402966 139.73785925174815 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2d8c207-dbca-4344-af1c-b02f12d9ac27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2d8c207-dbca-4344-af1c-b02f12d9ac27_0">
											<gml:posList>35.672632673213506 139.73789601447737 36.073 35.672596758503374 139.73791368754812 38.13 35.672632673213506 139.73789601447737 38.13 35.672632673213506 139.73789601447737 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87c00a98-edb7-4f3f-bed8-46d855f01813">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87c00a98-edb7-4f3f-bed8-46d855f01813_0">
											<gml:posList>35.672632673213506 139.73789601447737 36.073 35.672596758503374 139.73791368754812 36.073 35.672596758503374 139.73791368754812 38.13 35.672632673213506 139.73789601447737 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4edd840-7fcb-4e9c-8a2e-dcbd5b8f2a72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4edd840-7fcb-4e9c-8a2e-dcbd5b8f2a72_0">
											<gml:posList>35.6726352251553 139.73789734807443 36.073 35.672595670320725 139.737916815021 38.13 35.672595670320725 139.737916815021 36.073 35.6726352251553 139.73789734807443 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd52201f-0862-48d8-89cd-7d1963c94c36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd52201f-0862-48d8-89cd-7d1963c94c36_0">
											<gml:posList>35.6726352251553 139.73789734807443 36.073 35.6726352251553 139.73789734807443 38.13 35.672595670320725 139.737916815021 38.13 35.6726352251553 139.73789734807443 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dba68944-f967-469a-8570-38aa43cbbc70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dba68944-f967-469a-8570-38aa43cbbc70_0">
											<gml:posList>35.672646679494434 139.73790606123055 36.073 35.67264034522269 139.73790906239083 37.723 35.672646679494434 139.73790606123055 37.723 35.672646679494434 139.73790606123055 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5beb1d3f-a1e6-4dca-bd01-737e2cfc7b0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5beb1d3f-a1e6-4dca-bd01-737e2cfc7b0e_0">
											<gml:posList>35.672646679494434 139.73790606123055 36.073 35.67264034522269 139.73790906239083 36.073 35.67264034522269 139.73790906239083 37.723 35.672646679494434 139.73790606123055 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab6cf7a9-201d-4f1a-b145-36b26b190c6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab6cf7a9-201d-4f1a-b145-36b26b190c6a_0">
											<gml:posList>35.672649869373416 139.73791619818664 36.073 35.672646679494434 139.73790606123055 37.723 35.672649869373416 139.73791619818664 37.723 35.672649869373416 139.73791619818664 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26edcf1a-e894-409a-94dd-b54c8278c9a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26edcf1a-e894-409a-94dd-b54c8278c9a9_0">
											<gml:posList>35.672649869373416 139.73791619818664 36.073 35.672646679494434 139.73790606123055 36.073 35.672646679494434 139.73790606123055 37.723 35.672649869373416 139.73791619818664 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b73ddddd-0798-4d18-8424-8713339bc192">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b73ddddd-0798-4d18-8424-8713339bc192_0">
											<gml:posList>35.67264034522269 139.73790906239083 37.723 35.672649869373416 139.73791619818664 37.723 35.672646679494434 139.73790606123055 37.723 35.67264034522269 139.73790906239083 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c1f7f46-3f41-478b-821d-fbd7c675d7b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c1f7f46-3f41-478b-821d-fbd7c675d7b1_0">
											<gml:posList>35.67264034522269 139.73790906239083 37.723 35.672643535092675 139.7379191882997 37.723 35.672649869373416 139.73791619818664 37.723 35.67264034522269 139.73790906239083 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c49855c-3b9e-43b8-b47c-f5d0a3ebc0d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c49855c-3b9e-43b8-b47c-f5d0a3ebc0d2_0">
											<gml:posList>35.67264034522269 139.73790906239083 36.073 35.672643535092675 139.7379191882997 37.723 35.67264034522269 139.73790906239083 37.723 35.67264034522269 139.73790906239083 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6988f60-5c47-4ee1-9b85-79946a9eb1a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6988f60-5c47-4ee1-9b85-79946a9eb1a8_0">
											<gml:posList>35.67264034522269 139.73790906239083 36.073 35.672643535092675 139.7379191882997 36.073 35.672643535092675 139.7379191882997 37.723 35.67264034522269 139.73790906239083 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89623798-a7d8-4dde-aaff-02790a8b77c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89623798-a7d8-4dde-aaff-02790a8b77c7_0">
											<gml:posList>35.672649869373416 139.73791619818664 36.073 35.672643535092675 139.7379191882997 37.723 35.672643535092675 139.7379191882997 36.073 35.672649869373416 139.73791619818664 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7096ead7-fdeb-4ef2-92d4-7034418d1b51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7096ead7-fdeb-4ef2-92d4-7034418d1b51_0">
											<gml:posList>35.672649869373416 139.73791619818664 36.073 35.672649869373416 139.73791619818664 37.723 35.672643535092675 139.7379191882997 37.723 35.672649869373416 139.73791619818664 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcd2146d-f65f-4cc9-b520-e5e574efdc14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcd2146d-f65f-4cc9-b520-e5e574efdc14_0">
											<gml:posList>35.67263477699684 139.73792328595383 36.073 35.672631587118445 139.73791314899938 37.723 35.67263477699684 139.73792328595383 37.723 35.67263477699684 139.73792328595383 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f0ce3f1-f9a3-4446-a4cb-ce5a71358905">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f0ce3f1-f9a3-4446-a4cb-ce5a71358905_0">
											<gml:posList>35.67263477699684 139.73792328595383 36.073 35.672631587118445 139.73791314899938 36.073 35.672631587118445 139.73791314899938 37.723 35.67263477699684 139.73792328595383 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4db39f6-c4b5-46d5-bf89-b3037e63557f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4db39f6-c4b5-46d5-bf89-b3037e63557f_0">
											<gml:posList>35.67262525284651 139.73791615015855 37.723 35.67263477699684 139.73792328595383 37.723 35.672631587118445 139.73791314899938 37.723 35.67262525284651 139.73791615015855 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5d6887d-1a93-48a0-b1f8-5fbb0da9cb55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5d6887d-1a93-48a0-b1f8-5fbb0da9cb55_0">
											<gml:posList>35.67262525284651 139.73791615015855 37.723 35.67262844272466 139.73792628711234 37.723 35.67263477699684 139.73792328595383 37.723 35.67262525284651 139.73791615015855 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7de9e70f-2fdc-42c0-bac1-95ac5a83122d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7de9e70f-2fdc-42c0-bac1-95ac5a83122d_0">
											<gml:posList>35.67265070071013 139.73791881523476 36.073 35.672644366429324 139.73792180534764 37.723 35.67265070071013 139.73791881523476 37.723 35.67265070071013 139.73791881523476 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56c117e4-fd5d-4173-80cf-f2b14d935b6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56c117e4-fd5d-4173-80cf-f2b14d935b6f_0">
											<gml:posList>35.67265070071013 139.73791881523476 36.073 35.672644366429324 139.73792180534764 36.073 35.672644366429324 139.73792180534764 37.723 35.67265070071013 139.73791881523476 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-675574b8-2660-4a2d-b0f0-79e6c381051e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-675574b8-2660-4a2d-b0f0-79e6c381051e_0">
											<gml:posList>35.67262525284651 139.73791615015855 36.073 35.67262844272466 139.73792628711234 37.723 35.67262525284651 139.73791615015855 37.723 35.67262525284651 139.73791615015855 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34310483-df3d-45f3-9bdb-a796554617e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34310483-df3d-45f3-9bdb-a796554617e8_0">
											<gml:posList>35.67262525284651 139.73791615015855 36.073 35.67262844272466 139.73792628711234 36.073 35.67262844272466 139.73792628711234 37.723 35.67262525284651 139.73791615015855 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-676b05e5-50ba-43b9-b7fb-cd347381aed7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-676b05e5-50ba-43b9-b7fb-cd347381aed7_0">
											<gml:posList>35.672610548339875 139.73792359095214 36.073 35.672616882620765 139.73792060084065 37.723 35.672616882620765 139.73792060084065 36.073 35.672610548339875 139.73792359095214 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56ea7bff-ebb3-45ee-bcb0-89f6b8947f76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56ea7bff-ebb3-45ee-bcb0-89f6b8947f76_0">
											<gml:posList>35.672610548339875 139.73792359095214 36.073 35.672610548339875 139.73792359095214 37.723 35.672616882620765 139.73792060084065 37.723 35.672610548339875 139.73792359095214 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bf0c70a-9720-4c2f-a860-1e533ed4c5e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bf0c70a-9720-4c2f-a860-1e533ed4c5e6_0">
											<gml:posList>35.67265070071013 139.73791881523476 36.073 35.67265354719148 139.73792784794327 37.723 35.67265354719148 139.73792784794327 36.073 35.67265070071013 139.73791881523476 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d77b90e-d6ac-4bb6-9d7d-c1aeaf387847">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d77b90e-d6ac-4bb6-9d7d-c1aeaf387847_0">
											<gml:posList>35.67265070071013 139.73791881523476 36.073 35.67265070071013 139.73791881523476 37.723 35.67265354719148 139.73792784794327 37.723 35.67265070071013 139.73791881523476 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-724e813e-9aea-42f1-9540-09c6e438cb79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-724e813e-9aea-42f1-9540-09c6e438cb79_0">
											<gml:posList>35.672647212919195 139.73793084910213 37.723 35.67265070071013 139.73791881523476 37.723 35.672644366429324 139.73792180534764 37.723 35.672647212919195 139.73793084910213 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cac194e6-e1f1-4b81-a601-d7d2a30d36c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cac194e6-e1f1-4b81-a601-d7d2a30d36c3_0">
											<gml:posList>35.672647212919195 139.73793084910213 37.723 35.67265354719148 139.73792784794327 37.723 35.67265070071013 139.73791881523476 37.723 35.672647212919195 139.73793084910213 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b66322fd-18ec-45b2-9952-c7515b025f2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b66322fd-18ec-45b2-9952-c7515b025f2a_0">
											<gml:posList>35.672616882620765 139.73792060084065 36.073 35.672620072489785 139.73793072674698 37.723 35.672620072489785 139.73793072674698 36.073 35.672616882620765 139.73792060084065 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44cf5b5a-4a89-4e00-9743-235487c72fb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44cf5b5a-4a89-4e00-9743-235487c72fb7_0">
											<gml:posList>35.672616882620765 139.73792060084065 36.073 35.672616882620765 139.73792060084065 37.723 35.672620072489785 139.73793072674698 37.723 35.672616882620765 139.73792060084065 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f47487be-061c-49d7-8ab3-da708c79cef0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f47487be-061c-49d7-8ab3-da708c79cef0_0">
											<gml:posList>35.672644366429324 139.73792180534764 36.073 35.672647212919195 139.73793084910213 37.723 35.672644366429324 139.73792180534764 37.723 35.672644366429324 139.73792180534764 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a19752ae-8367-463c-9447-2efb726ea52e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a19752ae-8367-463c-9447-2efb726ea52e_0">
											<gml:posList>35.672644366429324 139.73792180534764 36.073 35.672647212919195 139.73793084910213 36.073 35.672647212919195 139.73793084910213 37.723 35.672644366429324 139.73792180534764 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce90f045-a591-4d09-9f2d-d494f1f4c8c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce90f045-a591-4d09-9f2d-d494f1f4c8c4_0">
											<gml:posList>35.672610548339875 139.73792359095214 37.723 35.672620072489785 139.73793072674698 37.723 35.672616882620765 139.73792060084065 37.723 35.672610548339875 139.73792359095214 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cb8b862-feb0-4618-96fd-4cc170235276">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8cb8b862-feb0-4618-96fd-4cc170235276_0">
											<gml:posList>35.672610548339875 139.73792359095214 37.723 35.67261373821741 139.73793372790436 37.723 35.672620072489785 139.73793072674698 37.723 35.672610548339875 139.73792359095214 37.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1cd120d-68ea-4eaa-bfb7-d58191cf7586">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67253671036924 139.73785849309624 36.073 35.672533945014884 139.73784947135326 36.073 35.67255308318921 139.73784066654562 36.073 35.67253671036924 139.73785849309624 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd123389-71c2-48f4-a9a8-2c6af8dd0f45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672555848544214 139.73784968829042 36.073 35.67253671036924 139.73785849309624 36.073 35.67255308318921 139.73784066654562 36.073 35.672555848544214 139.73784968829042 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5739fe32-9641-4185-8489-55482c9c9b0c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672632673213506 139.73789601447737 36.073 35.6726352251553 139.73789734807443 36.073 35.672595670320725 139.737916815021 36.073 35.672632673213506 139.73789601447737 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-812a3712-7a81-4acb-a4eb-817041e8ccfc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672595670320725 139.737916815021 36.073 35.67257680402966 139.73785925174815 36.073 35.672596758503374 139.73791368754812 36.073 35.672595670320725 139.737916815021 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07d7f329-d73a-4477-ac97-f50f773db04d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672632673213506 139.73789601447737 36.073 35.67261635885502 139.73783978477775 36.073 35.6726352251553 139.73789734807443 36.073 35.672632673213506 139.73789601447737 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9488d82a-9ba5-4556-b9f7-3c51240978b6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67261527066553 139.73784290120588 36.073 35.67257680402966 139.73785925174815 36.073 35.67261635885502 139.73783978477775 36.073 35.67261527066553 139.73784290120588 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d91fb647-e926-4913-98a6-ffbd490b70d9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672632673213506 139.73789601447737 36.073 35.672595670320725 139.737916815021 36.073 35.672596758503374 139.73791368754812 36.073 35.672632673213506 139.73789601447737 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3a53086-0eeb-4244-ac01-33bc9f1a82a1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67257680402966 139.73785925174815 36.073 35.672579355971884 139.7378605853431 36.073 35.672596758503374 139.73791368754812 36.073 35.67257680402966 139.73785925174815 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-582036cd-e2f2-49db-af14-6db35b04ed0a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67261527066553 139.73784290120588 36.073 35.67261635885502 139.73783978477775 36.073 35.672632673213506 139.73789601447737 36.073 35.67261527066553 139.73784290120588 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bb37ff5-6e71-4e42-842c-c8d09791b069">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67261527066553 139.73784290120588 36.073 35.672579355971884 139.7378605853431 36.073 35.67257680402966 139.73785925174815 36.073 35.67261527066553 139.73784290120588 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee6c508d-bd20-47c0-a00e-4ef4c32535cd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67264034522269 139.73790906239083 36.073 35.672649869373416 139.73791619818664 36.073 35.672643535092675 139.7379191882997 36.073 35.67264034522269 139.73790906239083 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2631c44-f940-409c-879b-96807bc29d91">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67264034522269 139.73790906239083 36.073 35.672646679494434 139.73790606123055 36.073 35.672649869373416 139.73791619818664 36.073 35.67264034522269 139.73790906239083 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a5b0312-243f-4314-902e-0d970d246e91">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67263477699684 139.73792328595383 36.073 35.67262525284651 139.73791615015855 36.073 35.672631587118445 139.73791314899938 36.073 35.67263477699684 139.73792328595383 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f345bfa-b3d5-4934-a868-ae294c15833b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67263477699684 139.73792328595383 36.073 35.67262844272466 139.73792628711234 36.073 35.67262525284651 139.73791615015855 36.073 35.67263477699684 139.73792328595383 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42d30910-699b-462e-8165-caa8f7e9e1dc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67262844272466 139.73792628711234 36.073 35.67263477699684 139.73792328595383 37.723 35.67262844272466 139.73792628711234 37.723 35.67262844272466 139.73792628711234 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-206ba485-2566-4cf9-b123-d6a966dc0508">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67262844272466 139.73792628711234 36.073 35.67263477699684 139.73792328595383 36.073 35.67263477699684 139.73792328595383 37.723 35.67262844272466 139.73792628711234 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a07d497-89f7-414e-94d6-5b252c9c05ca">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67265070071013 139.73791881523476 36.073 35.672647212919195 139.73793084910213 36.073 35.672644366429324 139.73792180534764 36.073 35.67265070071013 139.73791881523476 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0844c0e4-6d8c-46ae-89b5-d980a6d0ae8f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67265070071013 139.73791881523476 36.073 35.67265354719148 139.73792784794327 36.073 35.672647212919195 139.73793084910213 36.073 35.67265070071013 139.73791881523476 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-607721bd-f9eb-4f92-80ee-61dce0e04188">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672620072489785 139.73793072674698 36.073 35.672610548339875 139.73792359095214 36.073 35.672616882620765 139.73792060084065 36.073 35.672620072489785 139.73793072674698 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ddfdebc-01f1-4793-a9d6-fa5f52ddffff">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672620072489785 139.73793072674698 36.073 35.67261373821741 139.73793372790436 36.073 35.672610548339875 139.73792359095214 36.073 35.672620072489785 139.73793072674698 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14899979-30c7-4c0e-b41e-2c06260c8ec7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67263559931968 139.7379259030123 36.073 35.67262926504743 139.73792890417062 37.723 35.67263559931968 139.7379259030123 37.723 35.67263559931968 139.7379259030123 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5378bc72-953b-46ee-9a8e-018cbf8def4c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67263559931968 139.7379259030123 36.073 35.67262926504743 139.73792890417062 36.073 35.67262926504743 139.73792890417062 37.723 35.67263559931968 139.7379259030123 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3c38ff2-627e-4b8c-b21a-4f8eae2d7a72">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6726384458005 139.73793493571935 36.073 35.67263211152803 139.73793793687707 36.073 35.67262926504743 139.73792890417062 36.073 35.6726384458005 139.73793493571935 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fefabbf5-9bb4-4b5b-a7e7-183b838af124">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67263559931968 139.7379259030123 36.073 35.6726384458005 139.73793493571935 36.073 35.67262926504743 139.73792890417062 36.073 35.67263559931968 139.7379259030123 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e35d7da1-0b58-409e-b82e-c6a2770b5589">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6726042686236 139.7379385665219 36.073 35.672594744482886 139.73793144177407 36.073 35.672601078755235 139.73792844061722 36.073 35.6726042686236 139.7379385665219 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dc8e096-4a0d-448c-b28d-67879cda2885">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6726042686236 139.7379385665219 36.073 35.672597934351 139.73794156767806 36.073 35.672594744482886 139.73793144177407 36.073 35.6726042686236 139.7379385665219 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cb2e0c9-5e24-443a-a324-7e73ffc2c265">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67262090382618 139.7379333437943 36.073 35.67261741603378 139.73794537765656 36.073 35.67261456955373 139.7379363449515 36.073 35.67262090382618 139.7379333437943 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af2766b8-52c8-416c-ad34-edff1ea60b46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67262090382618 139.7379333437943 36.073 35.6726237503152 139.73794238754655 36.073 35.67261741603378 139.73794537765656 36.073 35.67262090382618 139.7379333437943 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64eace86-b7ac-4408-a92d-f95c21199569">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67258942848969 139.7379454772357 36.073 35.672583094216904 139.7379484783908 36.073 35.6725799043406 139.73793834144183 36.073 35.67258942848969 139.7379454772357 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdd477ca-5c57-4d0e-b72a-5d30d6b809e1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672586238621896 139.73793535133265 36.073 35.67258942848969 139.7379454772357 36.073 35.6725799043406 139.73793834144183 36.073 35.672586238621896 139.73793535133265 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c48cdac-01ef-4a72-b87b-c68dc0879c60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67260161216662 139.73795321742833 36.073 35.67259875667345 139.73794418473545 36.073 35.67260509995983 139.73794118356878 36.073 35.67260161216662 139.73795321742833 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13c69f43-39a0-4701-b2c7-3d344a41624c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67260793743455 139.73795022733023 36.073 35.67260161216662 139.73795321742833 36.073 35.67260509995983 139.73794118356878 36.073 35.67260793743455 139.73795022733023 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-568e572c-4eea-4a37-a4b7-b12eee93686a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672583916539196 139.73795109544778 36.073 35.67259309729122 139.73795712699567 36.073 35.672586763018145 139.73796012814992 36.073 35.672583916539196 139.73795109544778 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44a9afb5-6e62-4ed4-bcd9-c710d3d29cbb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672583916539196 139.73795109544778 36.073 35.672590259825775 139.7379480942822 36.073 35.67259309729122 139.73795712699567 36.073 35.672583916539196 139.73795109544778 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5216702d-9d33-4732-a20c-81174282d648">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5216702d-9d33-4732-a20c-81174282d648">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5216702d-9d33-4732-a20c-81174282d648">
											<gml:posList>35.67253491203639 139.73781859507739 8.9 35.67252027264937 139.73777177512943 8.9 35.67259253584205 139.737737886508 8.9 35.67260789809275 139.73778691494363 8.9 35.672631775593445 139.7377757294517 8.9 35.67269430947267 139.73797615030702 8.9 35.6725810489211 139.73802919805584 8.9 35.672517882504316 139.73782667935032 8.9 35.67253491203639 139.73781859507739 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c6229396-f06e-4c36-8bf2-a410e55df859">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6229396-f06e-4c36-8bf2-a410e55df859">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6229396-f06e-4c36-8bf2-a410e55df859">
											<gml:posList>35.67252027264937 139.73777177512943 36.78 35.6725251421703 139.7377744315448 36.78 35.67259036826275 139.73774384319043 36.78 35.67259253584205 139.737737886508 36.78 35.67252027264937 139.73777177512943 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-81105145-c8c5-435f-9058-f8eefcf97d51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81105145-c8c5-435f-9058-f8eefcf97d51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81105145-c8c5-435f-9058-f8eefcf97d51">
											<gml:posList>35.6725251421703 139.7377744315448 36.073 35.67253729024174 139.73778272407546 36.073 35.67258229638199 139.737760765102 36.073 35.67259036826275 139.73774384319043 36.073 35.6725251421703 139.7377744315448 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f492a4da-8134-467f-87c7-aef1b791c7a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f492a4da-8134-467f-87c7-aef1b791c7a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f492a4da-8134-467f-87c7-aef1b791c7a3">
											<gml:posList>35.67260789809275 139.73778691494363 36.78 35.67259253584205 139.737737886508 36.78 35.67259036826275 139.73774384319043 36.78 35.672605730502276 139.73779286057933 36.78 35.67260789809275 139.73778691494363 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b00df439-a612-44bc-86ae-40b81ca238c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b00df439-a612-44bc-86ae-40b81ca238c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b00df439-a612-44bc-86ae-40b81ca238c1">
											<gml:posList>35.67253729024174 139.73778272407546 40.78 35.6725423400368 139.7377853802772 40.78 35.6725801289769 139.7377669427141 40.78 35.67258229638199 139.737760765102 40.78 35.67253729024174 139.73778272407546 40.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-867b4393-fc59-4272-aecf-3ecdd6dbbffc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-867b4393-fc59-4272-aecf-3ecdd6dbbffc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-867b4393-fc59-4272-aecf-3ecdd6dbbffc">
											<gml:posList>35.67259036826275 139.73774384319043 36.073 35.67258229638199 139.737760765102 36.073 35.67259731386738 139.73780697707258 36.073 35.672605730502276 139.73779286057933 36.073 35.67259036826275 139.73774384319043 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f624db78-20a8-4840-a45f-c849dc144b83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f624db78-20a8-4840-a45f-c849dc144b83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f624db78-20a8-4840-a45f-c849dc144b83">
											<gml:posList>35.67259731386738 139.73780697707258 40.78 35.67258229638199 139.737760765102 40.78 35.6725801289769 139.7377669427141 40.78 35.6725922730778 139.73780430981034 40.78 35.67259731386738 139.73780697707258 40.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cbe9e4e4-07fe-4f2b-9b22-db201c2db238">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbe9e4e4-07fe-4f2b-9b22-db201c2db238">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbe9e4e4-07fe-4f2b-9b22-db201c2db238">
											<gml:posList>35.672631775593445 139.7377757294517 36.78 35.67260789809275 139.73778691494363 36.78 35.672605730502276 139.73779286057933 36.78 35.672617669261804 139.7377872788818 36.78 35.672631775593445 139.7377757294517 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d9622c6d-473a-4934-9d4d-1bb92775a2c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9622c6d-473a-4934-9d4d-1bb92775a2c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9622c6d-473a-4934-9d4d-1bb92775a2c6">
											<gml:posList>35.67255448414079 139.73782275840523 40 35.6725922730778 139.73780430981034 40 35.6725801289769 139.7377669427141 40 35.6725423400368 139.7377853802772 40 35.67255448414079 139.73782275840523 40</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f6e8eade-22a5-4a4b-88fc-b0b6ee0e9e11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6e8eade-22a5-4a4b-88fc-b0b6ee0e9e11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6e8eade-22a5-4a4b-88fc-b0b6ee0e9e11">
											<gml:posList>35.6725251421703 139.7377744315448 36.78 35.67252027264937 139.73777177512943 36.78 35.67253491203639 139.73781859507739 36.78 35.67253977252505 139.7378212294137 36.78 35.6725251421703 139.7377744315448 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97b43005-58ef-4b53-84e8-b01362707139">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97b43005-58ef-4b53-84e8-b01362707139">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97b43005-58ef-4b53-84e8-b01362707139">
											<gml:posList>35.67255230772755 139.7378289470708 36.073 35.67253729024174 139.73778272407546 36.073 35.6725251421703 139.7377744315448 36.073 35.67253977252505 139.7378212294137 36.073 35.67255230772755 139.7378289470708 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d01b0c2-67dd-4bd3-a863-b31077848f75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d01b0c2-67dd-4bd3-a863-b31077848f75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d01b0c2-67dd-4bd3-a863-b31077848f75">
											<gml:posList>35.67255448414079 139.73782275840523 40.78 35.6725423400368 139.7377853802772 40.78 35.67253729024174 139.73778272407546 40.78 35.67255230772755 139.7378289470708 40.78 35.67255448414079 139.73782275840523 40.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-def7c9d7-0416-4611-a238-2359ab79c7b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-def7c9d7-0416-4611-a238-2359ab79c7b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-def7c9d7-0416-4611-a238-2359ab79c7b7">
											<gml:posList>35.6725922730778 139.73780430981034 40.78 35.67255448414079 139.73782275840523 40.78 35.67255230772755 139.7378289470708 40.78 35.67259731386738 139.73780697707258 40.78 35.6725922730778 139.73780430981034 40.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dfd4167f-b430-4871-9c4d-da532d46eacc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfd4167f-b430-4871-9c4d-da532d46eacc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfd4167f-b430-4871-9c4d-da532d46eacc">
											<gml:posList>35.672522742992804 139.73782931368658 36.78 35.67253977252505 139.7378212294137 36.78 35.67253491203639 139.73781859507739 36.78 35.672517882504316 139.73782667935032 36.78 35.672522742992804 139.73782931368658 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b85e40f2-3f8b-455d-b08a-b098ba18df91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b85e40f2-3f8b-455d-b08a-b098ba18df91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b85e40f2-3f8b-455d-b08a-b098ba18df91">
											<gml:posList>35.67267791696053 139.73792362124377 36.78 35.672631775593445 139.7377757294517 36.78 35.672617669261804 139.7377872788818 36.78 35.67266119902459 139.73792681150604 36.78 35.67267791696053 139.73792362124377 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-420c7164-f940-4dd5-9e00-ec6f0de0efc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-420c7164-f940-4dd5-9e00-ec6f0de0efc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-420c7164-f940-4dd5-9e00-ec6f0de0efc6">
											<gml:posList>35.67259731386738 139.73780697707258 36.073 35.67266119902459 139.73792681150604 36.073 35.672617669261804 139.7377872788818 36.073 35.672605730502276 139.73779286057933 36.073 35.67259731386738 139.73780697707258 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1605a8c2-2c35-4d4b-83ac-f8e6ddd85c56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1605a8c2-2c35-4d4b-83ac-f8e6ddd85c56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1605a8c2-2c35-4d4b-83ac-f8e6ddd85c56">
											<gml:posList>35.67255230772755 139.7378289470708 36.073 35.67256744750908 139.73797265583462 36.073 35.67266119902459 139.73792681150604 36.073 35.67259731386738 139.73780697707258 36.073 35.67255230772755 139.7378289470708 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-068ae16c-f05b-4455-8694-b67c0701589f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-068ae16c-f05b-4455-8694-b67c0701589f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-068ae16c-f05b-4455-8694-b67c0701589f">
											<gml:posList>35.67253977252505 139.7378212294137 36.073 35.672522742992804 139.73782931368658 36.073 35.67256744750908 139.73797265583462 36.073 35.67255230772755 139.7378289470708 36.073 35.67253977252505 139.7378212294137 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aeec18f7-b3f8-4f71-839e-8d240d9b5683">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aeec18f7-b3f8-4f71-839e-8d240d9b5683">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aeec18f7-b3f8-4f71-839e-8d240d9b5683">
											<gml:posList>35.67256744750908 139.73797265583462 36.78 35.672522742992804 139.73782931368658 36.78 35.672517882504316 139.73782667935032 36.78 35.67256528898435 139.73797867877744 36.78 35.67256744750908 139.73797265583462 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-01de93a0-a98f-4938-906f-4099089f98ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01de93a0-a98f-4938-906f-4099089f98ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01de93a0-a98f-4938-906f-4099089f98ad">
											<gml:posList>35.67266119902459 139.73792681150604 36.78 35.67256744750908 139.73797265583462 36.78 35.67256528898435 139.73797867877744 36.78 35.67267791696053 139.73792362124377 36.78 35.67266119902459 139.73792681150604 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b2c56eb9-2e44-41a0-a99d-ad028079d7ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2c56eb9-2e44-41a0-a99d-ad028079d7ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2c56eb9-2e44-41a0-a99d-ad028079d7ee">
											<gml:posList>35.67268572465387 139.73794865454167 34.914 35.67267791696053 139.73792362124377 36.78 35.67256528898435 139.73797867877744 36.78 35.67257321415079 139.73800409853555 34.914 35.67268572465387 139.73794865454167 34.914</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-063f42ed-316e-4477-831c-55ca373a5ff1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-063f42ed-316e-4477-831c-55ca373a5ff1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-063f42ed-316e-4477-831c-55ca373a5ff1">
											<gml:posList>35.67268219265003 139.73795039305642 32.177 35.67257662902086 139.73800241539763 32.177 35.6725832075183 139.73802326348562 32.177 35.67268948503363 139.73797350486674 32.177 35.67268219265003 139.73795039305642 32.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f8cef14d-0a7c-435e-a8b2-36facc6c63ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8cef14d-0a7c-435e-a8b2-36facc6c63ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8cef14d-0a7c-435e-a8b2-36facc6c63ee">
											<gml:posList>35.67269430947267 139.73797615030702 32.855 35.67268572465387 139.73794865454167 32.855 35.67268219265003 139.73795039305642 32.855 35.67268948503363 139.73797350486674 32.855 35.6725832075183 139.73802326348562 32.855 35.67257662902086 139.73800241539763 32.855 35.67257321415079 139.73800409853555 32.855 35.6725810489211 139.73802919805584 32.855 35.67269430947267 139.73797615030702 32.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6ca5720-72f5-43ab-8201-ef613796d887">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6ca5720-72f5-43ab-8201-ef613796d887">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6ca5720-72f5-43ab-8201-ef613796d887">
											<gml:posList>35.67253491203639 139.73781859507739 36.78 35.67253491203639 139.73781859507739 8.9 35.672517882504316 139.73782667935032 8.9 35.672517882504316 139.73782667935032 36.78 35.67253491203639 139.73781859507739 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-770819ba-838c-4ba8-b4d5-efd6923ee00d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-770819ba-838c-4ba8-b4d5-efd6923ee00d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-770819ba-838c-4ba8-b4d5-efd6923ee00d">
											<gml:posList>35.67252027264937 139.73777177512943 36.78 35.67252027264937 139.73777177512943 8.9 35.67253491203639 139.73781859507739 8.9 35.67253491203639 139.73781859507739 36.78 35.67252027264937 139.73777177512943 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09e60d66-32ce-4fff-a473-1374118c5955">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09e60d66-32ce-4fff-a473-1374118c5955">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09e60d66-32ce-4fff-a473-1374118c5955">
											<gml:posList>35.672522742992804 139.73782931368658 36.073 35.67253977252505 139.7378212294137 36.073 35.67253977252505 139.7378212294137 36.78 35.672522742992804 139.73782931368658 36.78 35.672522742992804 139.73782931368658 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b24ff87a-4eb0-4967-9251-b8d448676612">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b24ff87a-4eb0-4967-9251-b8d448676612">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b24ff87a-4eb0-4967-9251-b8d448676612">
											<gml:posList>35.67253977252505 139.7378212294137 36.073 35.6725251421703 139.7377744315448 36.073 35.6725251421703 139.7377744315448 36.78 35.67253977252505 139.7378212294137 36.78 35.67253977252505 139.7378212294137 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc7e6089-d2c1-47f1-8f2d-38d59782ff25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc7e6089-d2c1-47f1-8f2d-38d59782ff25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc7e6089-d2c1-47f1-8f2d-38d59782ff25">
											<gml:posList>35.67253729024174 139.73778272407546 36.073 35.67255230772755 139.7378289470708 36.073 35.67255230772755 139.7378289470708 40.78 35.67253729024174 139.73778272407546 40.78 35.67253729024174 139.73778272407546 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dface5b0-5cbf-4429-9b89-9143787c143b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dface5b0-5cbf-4429-9b89-9143787c143b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dface5b0-5cbf-4429-9b89-9143787c143b">
											<gml:posList>35.67255448414079 139.73782275840523 40 35.6725423400368 139.7377853802772 40 35.6725423400368 139.7377853802772 40.78 35.67255448414079 139.73782275840523 40.78 35.67255448414079 139.73782275840523 40</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f639cb0-a779-46fb-bfff-03c64c50bd8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f639cb0-a779-46fb-bfff-03c64c50bd8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f639cb0-a779-46fb-bfff-03c64c50bd8c">
											<gml:posList>35.67259253584205 139.737737886508 36.78 35.67259253584205 139.737737886508 8.9 35.67252027264937 139.73777177512943 8.9 35.67252027264937 139.73777177512943 36.78 35.67259253584205 139.737737886508 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e77141a-4834-4bb4-b367-cc2ca45a4128">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e77141a-4834-4bb4-b367-cc2ca45a4128">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e77141a-4834-4bb4-b367-cc2ca45a4128">
											<gml:posList>35.6725251421703 139.7377744315448 36.073 35.67259036826275 139.73774384319043 36.073 35.67259036826275 139.73774384319043 36.78 35.6725251421703 139.7377744315448 36.78 35.6725251421703 139.7377744315448 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-058f0aa0-ba7a-4f9f-bdf9-ad74fdb82b4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-058f0aa0-ba7a-4f9f-bdf9-ad74fdb82b4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-058f0aa0-ba7a-4f9f-bdf9-ad74fdb82b4e">
											<gml:posList>35.67258229638199 139.737760765102 36.073 35.67253729024174 139.73778272407546 36.073 35.67253729024174 139.73778272407546 40.78 35.67258229638199 139.737760765102 40.78 35.67258229638199 139.737760765102 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7be1a19c-c3b2-4cc9-a962-d511befd281d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7be1a19c-c3b2-4cc9-a962-d511befd281d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7be1a19c-c3b2-4cc9-a962-d511befd281d">
											<gml:posList>35.6725423400368 139.7377853802772 40 35.6725801289769 139.7377669427141 40 35.6725801289769 139.7377669427141 40.78 35.6725423400368 139.7377853802772 40.78 35.6725423400368 139.7377853802772 40</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff42b2aa-5dd8-4d03-aed9-3eee9f1cbd0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff42b2aa-5dd8-4d03-aed9-3eee9f1cbd0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff42b2aa-5dd8-4d03-aed9-3eee9f1cbd0e">
											<gml:posList>35.6725922730778 139.73780430981034 40 35.67255448414079 139.73782275840523 40 35.67255448414079 139.73782275840523 40.78 35.6725922730778 139.73780430981034 40.78 35.6725922730778 139.73780430981034 40</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af7ed548-1e20-48c5-86da-71a5dd15d763">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af7ed548-1e20-48c5-86da-71a5dd15d763">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af7ed548-1e20-48c5-86da-71a5dd15d763">
											<gml:posList>35.67259731386738 139.73780697707258 40.78 35.67255230772755 139.7378289470708 40.78 35.67255230772755 139.7378289470708 36.073 35.67259731386738 139.73780697707258 36.073 35.67259731386738 139.73780697707258 40.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1aca13d4-90c4-49c6-9fe4-f0a142cdb460">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1aca13d4-90c4-49c6-9fe4-f0a142cdb460">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1aca13d4-90c4-49c6-9fe4-f0a142cdb460">
											<gml:posList>35.6725801289769 139.7377669427141 40 35.6725922730778 139.73780430981034 40 35.6725922730778 139.73780430981034 40.78 35.6725801289769 139.7377669427141 40.78 35.6725801289769 139.7377669427141 40</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73a7d708-85ab-43a7-9c7d-d0e7fd134edb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73a7d708-85ab-43a7-9c7d-d0e7fd134edb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73a7d708-85ab-43a7-9c7d-d0e7fd134edb">
											<gml:posList>35.67258229638199 139.737760765102 40.78 35.67259731386738 139.73780697707258 40.78 35.67259731386738 139.73780697707258 36.073 35.67258229638199 139.737760765102 36.073 35.67258229638199 139.737760765102 40.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e5c8ea9-68ea-4b8c-abe2-70e0be5e6d89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e5c8ea9-68ea-4b8c-abe2-70e0be5e6d89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e5c8ea9-68ea-4b8c-abe2-70e0be5e6d89">
											<gml:posList>35.672605730502276 139.73779286057933 36.78 35.67259036826275 139.73774384319043 36.78 35.67259036826275 139.73774384319043 36.073 35.672605730502276 139.73779286057933 36.073 35.672605730502276 139.73779286057933 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08423413-0206-4b36-ad8f-3dae8db39c73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08423413-0206-4b36-ad8f-3dae8db39c73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08423413-0206-4b36-ad8f-3dae8db39c73">
											<gml:posList>35.67260789809275 139.73778691494363 36.78 35.67260789809275 139.73778691494363 8.9 35.67259253584205 139.737737886508 8.9 35.67259253584205 139.737737886508 36.78 35.67260789809275 139.73778691494363 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3948195d-3d03-4498-bf32-7623a76392f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3948195d-3d03-4498-bf32-7623a76392f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3948195d-3d03-4498-bf32-7623a76392f2">
											<gml:posList>35.672617669261804 139.7377872788818 36.78 35.672605730502276 139.73779286057933 36.78 35.672605730502276 139.73779286057933 36.073 35.672617669261804 139.7377872788818 36.073 35.672617669261804 139.7377872788818 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dfbe30a9-08e1-40d6-b42d-1ad99b4c732b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfbe30a9-08e1-40d6-b42d-1ad99b4c732b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfbe30a9-08e1-40d6-b42d-1ad99b4c732b">
											<gml:posList>35.672631775593445 139.7377757294517 8.9 35.67260789809275 139.73778691494363 8.9 35.67260789809275 139.73778691494363 36.78 35.672631775593445 139.7377757294517 36.78 35.672631775593445 139.7377757294517 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fadb647-2a75-414c-963a-e2842f17e1aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fadb647-2a75-414c-963a-e2842f17e1aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fadb647-2a75-414c-963a-e2842f17e1aa">
											<gml:posList>35.672617669261804 139.7377872788818 36.073 35.67266119902459 139.73792681150604 36.073 35.67266119902459 139.73792681150604 36.78 35.672617669261804 139.7377872788818 36.78 35.672617669261804 139.7377872788818 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20c2f73f-7c4c-499c-97b3-1b103a139024">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20c2f73f-7c4c-499c-97b3-1b103a139024">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20c2f73f-7c4c-499c-97b3-1b103a139024">
											<gml:posList>35.67268572465387 139.73794865454167 32.855 35.67269430947267 139.73797615030702 32.855 35.67269430947267 139.73797615030702 8.9 35.672631775593445 139.7377757294517 8.9 35.672631775593445 139.7377757294517 36.78 35.67267791696053 139.73792362124377 36.78 35.67268572465387 139.73794865454167 34.914 35.67268572465387 139.73794865454167 32.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb20c3c2-88fc-4f3d-9b60-18700e17a4ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb20c3c2-88fc-4f3d-9b60-18700e17a4ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb20c3c2-88fc-4f3d-9b60-18700e17a4ec">
											<gml:posList>35.67256744750908 139.73797265583462 36.073 35.672522742992804 139.73782931368658 36.073 35.672522742992804 139.73782931368658 36.78 35.67256744750908 139.73797265583462 36.78 35.67256744750908 139.73797265583462 36.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4030b98-0623-4216-ac70-445cbb56915a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4030b98-0623-4216-ac70-445cbb56915a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4030b98-0623-4216-ac70-445cbb56915a">
											<gml:posList>35.672517882504316 139.73782667935032 8.9 35.6725810489211 139.73802919805584 8.9 35.6725810489211 139.73802919805584 32.855 35.67257321415079 139.73800409853555 32.855 35.67257321415079 139.73800409853555 34.914 35.67256528898435 139.73797867877744 36.78 35.672517882504316 139.73782667935032 36.78 35.672517882504316 139.73782667935032 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09b2520a-5e2f-4c1f-988c-87235e0bdc35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09b2520a-5e2f-4c1f-988c-87235e0bdc35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09b2520a-5e2f-4c1f-988c-87235e0bdc35">
											<gml:posList>35.6725832075183 139.73802326348562 32.177 35.67257662902086 139.73800241539763 32.177 35.67257662902086 139.73800241539763 32.855 35.6725832075183 139.73802326348562 32.855 35.6725832075183 139.73802326348562 32.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a69da7a4-4a02-47ca-b6c8-81c536d3cf8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a69da7a4-4a02-47ca-b6c8-81c536d3cf8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a69da7a4-4a02-47ca-b6c8-81c536d3cf8d">
											<gml:posList>35.67256744750908 139.73797265583462 36.78 35.67266119902459 139.73792681150604 36.78 35.67266119902459 139.73792681150604 36.073 35.67256744750908 139.73797265583462 36.073 35.67256744750908 139.73797265583462 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea006a4a-27a5-42b0-81c8-a75e20dfa92a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea006a4a-27a5-42b0-81c8-a75e20dfa92a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea006a4a-27a5-42b0-81c8-a75e20dfa92a">
											<gml:posList>35.67257662902086 139.73800241539763 32.855 35.67257662902086 139.73800241539763 32.177 35.67268219265003 139.73795039305642 32.177 35.67268219265003 139.73795039305642 32.855 35.67268572465387 139.73794865454167 32.855 35.67268572465387 139.73794865454167 34.914 35.67257321415079 139.73800409853555 34.914 35.67257321415079 139.73800409853555 32.855 35.67257662902086 139.73800241539763 32.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8cf5d53-fd48-4bbd-8646-7e1fc604f5ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8cf5d53-fd48-4bbd-8646-7e1fc604f5ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8cf5d53-fd48-4bbd-8646-7e1fc604f5ec">
											<gml:posList>35.6725832075183 139.73802326348562 32.855 35.67268948503363 139.73797350486674 32.855 35.67268948503363 139.73797350486674 32.177 35.6725832075183 139.73802326348562 32.177 35.6725832075183 139.73802326348562 32.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab43f752-2f93-435b-8282-c9690dc43c73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab43f752-2f93-435b-8282-c9690dc43c73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab43f752-2f93-435b-8282-c9690dc43c73">
											<gml:posList>35.67269430947267 139.73797615030702 8.9 35.67269430947267 139.73797615030702 32.855 35.6725810489211 139.73802919805584 32.855 35.6725810489211 139.73802919805584 8.9 35.67269430947267 139.73797615030702 8.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7ebdd86-3705-427c-84fd-80bf72f1fbd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7ebdd86-3705-427c-84fd-80bf72f1fbd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7ebdd86-3705-427c-84fd-80bf72f1fbd0">
											<gml:posList>35.67268219265003 139.73795039305642 32.177 35.67268948503363 139.73797350486674 32.177 35.67268948503363 139.73797350486674 32.855 35.67268219265003 139.73795039305642 32.855 35.67268219265003 139.73795039305642 32.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10444</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">302.49155</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>