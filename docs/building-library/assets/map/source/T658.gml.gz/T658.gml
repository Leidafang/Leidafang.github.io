<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c0bd6cfd-b69f-4ce9-ae8f-169a88cca8e1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">49.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669377839070364 139.7477740389741 0 35.66936517629881 139.74781424931814 0 35.669333065196525 139.74790994293093 0 35.66945389228739 139.74797067839333 0 35.66954941568664 139.74768558613653 0 35.66942958106498 139.74762639642904 0 35.66940466326328 139.74769700780783 0 35.66937319514634 139.7476826814593 0 35.66934876000798 139.74776028444856 0 35.669377839070364 139.7477740389741 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669377839070364 139.7477740389741 6.407 35.66934876000798 139.74776028444856 6.407 35.66937319514634 139.7476826814593 6.407 35.66940466326328 139.74769700780783 6.407 35.66942958106498 139.74762639642904 6.407 35.66954941568664 139.74768558613653 6.407 35.66945389228739 139.74797067839333 6.407 35.669333065196525 139.74790994293093 6.407 35.66936517629881 139.74781424931814 6.407 35.669377839070364 139.7477740389741 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669377839070364 139.7477740389741 6.407 35.66936517629881 139.74781424931814 6.407 35.66936517629881 139.74781424931814 55.67999999999999 35.669377839070364 139.7477740389741 55.67999999999999 35.669377839070364 139.7477740389741 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66936517629881 139.74781424931814 6.407 35.669333065196525 139.74790994293093 6.407 35.669333065196525 139.74790994293093 55.67999999999999 35.66936517629881 139.74781424931814 55.67999999999999 35.66936517629881 139.74781424931814 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669333065196525 139.74790994293093 6.407 35.66945389228739 139.74797067839333 6.407 35.66945389228739 139.74797067839333 55.67999999999999 35.669333065196525 139.74790994293093 55.67999999999999 35.669333065196525 139.74790994293093 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66945389228739 139.74797067839333 6.407 35.66954941568664 139.74768558613653 6.407 35.66954941568664 139.74768558613653 55.67999999999999 35.66945389228739 139.74797067839333 55.67999999999999 35.66945389228739 139.74797067839333 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66954941568664 139.74768558613653 6.407 35.66942958106498 139.74762639642904 6.407 35.66942958106498 139.74762639642904 55.67999999999999 35.66954941568664 139.74768558613653 55.67999999999999 35.66954941568664 139.74768558613653 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66942958106498 139.74762639642904 6.407 35.66940466326328 139.74769700780783 6.407 35.66940466326328 139.74769700780783 55.67999999999999 35.66942958106498 139.74762639642904 55.67999999999999 35.66942958106498 139.74762639642904 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66940466326328 139.74769700780783 6.407 35.66937319514634 139.7476826814593 6.407 35.66937319514634 139.7476826814593 55.67999999999999 35.66940466326328 139.74769700780783 55.67999999999999 35.66940466326328 139.74769700780783 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66937319514634 139.7476826814593 6.407 35.66934876000798 139.74776028444856 6.407 35.66934876000798 139.74776028444856 55.67999999999999 35.66937319514634 139.7476826814593 55.67999999999999 35.66937319514634 139.7476826814593 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66934876000798 139.74776028444856 6.407 35.669377839070364 139.7477740389741 6.407 35.669377839070364 139.7477740389741 55.67999999999999 35.66934876000798 139.74776028444856 55.67999999999999 35.66934876000798 139.74776028444856 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669377839070364 139.7477740389741 55.67999999999999 35.66936517629881 139.74781424931814 55.67999999999999 35.669333065196525 139.74790994293093 55.67999999999999 35.66945389228739 139.74797067839333 55.67999999999999 35.66954941568664 139.74768558613653 55.67999999999999 35.66942958106498 139.74762639642904 55.67999999999999 35.66940466326328 139.74769700780783 55.67999999999999 35.66937319514634 139.7476826814593 55.67999999999999 35.66934876000798 139.74776028444856 55.67999999999999 35.669377839070364 139.7477740389741 55.67999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-799cfd97-155d-4875-9012-3271c1c55923"/>
							<gml:surfaceMember xlink:href="#poly-410dc557-c54a-4519-81f1-31bd5bd7bddf"/>
							<gml:surfaceMember xlink:href="#poly-a361dc10-7301-4049-9c32-25c251700f81"/>
							<gml:surfaceMember xlink:href="#poly-43255e73-243c-431c-8211-6f3100bb5bf1"/>
							<gml:surfaceMember xlink:href="#poly-4d3a4de6-4261-417e-9fe8-d7c86f11e5ed"/>
							<gml:surfaceMember xlink:href="#poly-7cfcb2df-011b-4d36-9dd5-f18b506c81a3"/>
							<gml:surfaceMember xlink:href="#poly-a845078e-e13c-439f-a44c-f0002038aa6b"/>
							<gml:surfaceMember xlink:href="#poly-fdb71826-48d4-45ac-9bd3-2a33d201840a"/>
							<gml:surfaceMember xlink:href="#poly-4fa16334-a734-4903-b6ae-a21ac10a6fcf"/>
							<gml:surfaceMember xlink:href="#poly-ee1ec3b8-8474-4e3c-a130-ab396eb74abb"/>
							<gml:surfaceMember xlink:href="#poly-1b6e860e-0169-43bb-9805-4bbcaf33c24d"/>
							<gml:surfaceMember xlink:href="#poly-40850bf1-694d-42cd-bb6f-6af6f036e01b"/>
							<gml:surfaceMember xlink:href="#poly-db2702b6-1406-4452-9b95-31da43213167"/>
							<gml:surfaceMember xlink:href="#poly-c107b6eb-6b94-42ca-92a8-78551b1c0812"/>
							<gml:surfaceMember xlink:href="#poly-7b23c5e2-1d51-4da8-90cd-132219c1042d"/>
							<gml:surfaceMember xlink:href="#poly-2f212421-9d03-4b26-90eb-31f3b90e8c21"/>
							<gml:surfaceMember xlink:href="#poly-74e3b167-4073-46e1-a122-8a75bdc9e5fa"/>
							<gml:surfaceMember xlink:href="#poly-f0870028-67c8-4c01-8018-5dec4bc10867"/>
							<gml:surfaceMember xlink:href="#poly-de138c7c-8501-42b7-9b0a-5811646fe1e0"/>
							<gml:surfaceMember xlink:href="#poly-49ae5a42-da3a-43de-a5f7-5b2808432c16"/>
							<gml:surfaceMember xlink:href="#poly-f2cac0a3-e0f1-4b77-8c8e-8d34a73feac7"/>
							<gml:surfaceMember xlink:href="#poly-d6b87d1e-9b12-4c4d-8b66-11f18d70cbf4"/>
							<gml:surfaceMember xlink:href="#poly-fb7e50f9-0185-4c5c-9eac-3b6e15f0b5ba"/>
							<gml:surfaceMember xlink:href="#poly-37be7d6c-fbfe-4de3-8b4d-b43f70fe6041"/>
							<gml:surfaceMember xlink:href="#poly-31f9a7c1-f41c-44b0-956d-615f8420ca41"/>
							<gml:surfaceMember xlink:href="#poly-9ecb02f9-af9b-4e5d-b622-fc21d927ce22"/>
							<gml:surfaceMember xlink:href="#poly-83ba87a1-54a1-4493-898c-d28a1e509897"/>
							<gml:surfaceMember xlink:href="#poly-bfe80768-28fe-44d1-982a-4c2ed6f8aab1"/>
							<gml:surfaceMember xlink:href="#poly-de439511-9201-4009-aab8-c2637ae44f47"/>
							<gml:surfaceMember xlink:href="#poly-e3434396-9d73-4345-bf15-4d8dcb9fbb6a"/>
							<gml:surfaceMember xlink:href="#poly-40c801fa-f6bc-4686-932b-845b6ceb9310"/>
							<gml:surfaceMember xlink:href="#poly-2acb2aab-eaff-4682-920a-18be96ad0bf7"/>
							<gml:surfaceMember xlink:href="#poly-e79d5021-43ec-4104-9c24-68bb0c4ec3a7"/>
							<gml:surfaceMember xlink:href="#poly-4fbd02e7-d2c6-4519-88ee-dafb67581247"/>
							<gml:surfaceMember xlink:href="#poly-a1fd13ae-7014-4d99-879e-156947dbde46"/>
							<gml:surfaceMember xlink:href="#poly-db2c8887-f1a9-46ba-821a-612156b022a0"/>
							<gml:surfaceMember xlink:href="#poly-a45b51ee-3721-4b3f-9b68-1bc8ddd8b82d"/>
							<gml:surfaceMember xlink:href="#poly-25eabdec-a315-4aa7-99e7-bbc431e5fb92"/>
							<gml:surfaceMember xlink:href="#poly-3a5f25f2-314d-4c9d-869e-76b7b24f2bbc"/>
							<gml:surfaceMember xlink:href="#poly-632bff9d-0fee-4057-9936-c0a4ae52ff75"/>
							<gml:surfaceMember xlink:href="#poly-55a33bd6-25be-465d-ad3f-353281abe92e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c0bd6cfd-b69f-4ce9-ae8f-169a88cca8e1_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7370ea1f-14ab-46e6-9a0c-233c6a19c7ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7370ea1f-14ab-46e6-9a0c-233c6a19c7ed_0">
											<gml:posList>35.66935333370034 139.747778218464 53.541 35.669368995149235 139.74778468582568 56.281 35.669368995149235 139.74778468582568 51.329 35.66935333370034 139.747778218464 53.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6dcca1b-b478-4bd4-be3e-db2ab6df8734">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6dcca1b-b478-4bd4-be3e-db2ab6df8734_0">
											<gml:posList>35.669368995149235 139.74778468582568 51.329 35.66935791202485 139.7477646158059 53.541 35.66935333370034 139.747778218464 53.541 35.669368995149235 139.74778468582568 51.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee164918-09e0-4ca5-8ab3-9ae0cef25642">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee164918-09e0-4ca5-8ab3-9ae0cef25642_0">
											<gml:posList>35.669368995149235 139.74778468582568 51.329 35.669372573366864 139.74777166967695 51.329 35.66935791202485 139.7477646158059 53.541 35.669368995149235 139.74778468582568 51.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-068a8129-5596-45dd-a2a1-47c063def2da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-068a8129-5596-45dd-a2a1-47c063def2da_0">
											<gml:posList>35.66939655611539 139.74772969090327 56.913 35.66940679014161 139.7477345292264 57.858 35.66940679014161 139.7477345292264 56.913 35.66939655611539 139.74772969090327 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e05fb08b-9e0a-4209-9628-d99e7ed89075">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e05fb08b-9e0a-4209-9628-d99e7ed89075_0">
											<gml:posList>35.66939655611539 139.74772969090327 56.913 35.66939655611539 139.74772969090327 57.858 35.66940679014161 139.7477345292264 57.858 35.66939655611539 139.74772969090327 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a08de3a3-00f3-4d65-b328-79547e15f546">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a08de3a3-00f3-4d65-b328-79547e15f546_0">
											<gml:posList>35.66938416315827 139.7477690393782 57.858 35.66939655611539 139.74772969090327 56.913 35.66938416315827 139.7477690393782 56.913 35.66938416315827 139.7477690393782 57.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65761698-28ad-4f62-bb61-dc533e2d4e50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65761698-28ad-4f62-bb61-dc533e2d4e50_0">
											<gml:posList>35.66938416315827 139.7477690393782 57.858 35.66939655611539 139.74772969090327 57.858 35.66939655611539 139.74772969090327 56.913 35.66938416315827 139.7477690393782 57.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41eb5eb7-555c-4f8f-bd3e-24196bf822b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41eb5eb7-555c-4f8f-bd3e-24196bf822b2_0">
											<gml:posList>35.66938197776762 139.7477760007676 57.858 35.669392211792015 139.74778083909573 57.858 35.66938416315827 139.7477690393782 57.858 35.66938197776762 139.7477760007676 57.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29b649aa-66ac-4fd8-a2b2-a46860187c18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29b649aa-66ac-4fd8-a2b2-a46860187c18_0">
											<gml:posList>35.66938416315827 139.7477690393782 57.858 35.66940679014161 139.7477345292264 57.858 35.66939655611539 139.74772969090327 57.858 35.66938416315827 139.7477690393782 57.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c54a0661-0b90-4095-a600-fe3d6714d422">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c54a0661-0b90-4095-a600-fe3d6714d422_0">
											<gml:posList>35.66938416315827 139.7477690393782 57.858 35.669392211792015 139.74778083909573 57.858 35.66940679014161 139.7477345292264 57.858 35.66938416315827 139.7477690393782 57.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65f7db57-9b35-43d7-8a87-a6768ed86155">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65f7db57-9b35-43d7-8a87-a6768ed86155_0">
											<gml:posList>35.66940679014161 139.7477345292264 56.913 35.669392211792015 139.74778083909573 57.858 35.669392211792015 139.74778083909573 56.913 35.66940679014161 139.7477345292264 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-155a0720-198d-45fb-a85e-3d04e40e748c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-155a0720-198d-45fb-a85e-3d04e40e748c_0">
											<gml:posList>35.66940679014161 139.7477345292264 56.913 35.66940679014161 139.7477345292264 57.858 35.669392211792015 139.74778083909573 57.858 35.66940679014161 139.7477345292264 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba1be43b-35f4-4657-a658-067a28f44412">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba1be43b-35f4-4657-a658-067a28f44412_0">
											<gml:posList>35.66935496353955 139.74776321609542 6.407 35.66935496353955 139.74776321609542 53.541 35.669372573366864 139.74777166967695 51.329 35.66935496353955 139.74776321609542 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-903f6018-9d2e-49a5-92a9-19056efc7ab6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-903f6018-9d2e-49a5-92a9-19056efc7ab6_0">
											<gml:posList>35.66935496353955 139.74776321609542 6.407 35.669372573366864 139.74777166967695 51.329 35.66937783907034 139.7477740389741 6.407 35.66935496353955 139.74776321609542 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a127f74-9d6c-4ea5-82dc-3b9d251c465c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a127f74-9d6c-4ea5-82dc-3b9d251c465c_0">
											<gml:posList>35.66937783907034 139.7477740389741 6.407 35.669372573366864 139.74777166967695 51.329 35.66937783907034 139.7477740389741 56.281 35.66937783907034 139.7477740389741 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-391b3d56-dbcd-429b-abac-e5b538d7eb37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-391b3d56-dbcd-429b-abac-e5b538d7eb37_0">
											<gml:posList>35.66935496353955 139.74776321609542 53.541 35.66935791202485 139.7477646158059 53.541 35.669372573366864 139.74777166967695 51.329 35.66935496353955 139.74776321609542 53.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3944851d-2245-4402-bee2-22fdf7f42c07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3944851d-2245-4402-bee2-22fdf7f42c07_0">
											<gml:posList>35.66937783907034 139.7477740389741 56.281 35.669372573366864 139.74777166967695 51.329 35.669372573366864 139.74777166967695 56.281 35.66937783907034 139.7477740389741 56.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38e17bd1-83e9-4b2b-97cb-2bc1932bcfdd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38e17bd1-83e9-4b2b-97cb-2bc1932bcfdd_0">
											<gml:posList>35.66938197776762 139.7477760007676 57.858 35.66938416315827 139.7477690393782 56.913 35.66938197776762 139.7477760007676 56.913 35.66938197776762 139.7477760007676 57.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22389abb-6c08-4480-9130-2fdcf38a27b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22389abb-6c08-4480-9130-2fdcf38a27b6_0">
											<gml:posList>35.66938197776762 139.7477760007676 57.858 35.66938416315827 139.7477690393782 57.858 35.66938416315827 139.7477690393782 56.913 35.66938197776762 139.7477760007676 57.858</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27892653-295d-4f63-8334-78df9ae0d515">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27892653-295d-4f63-8334-78df9ae0d515_0">
											<gml:posList>35.66934633882468 139.74779059757958 53.541 35.66935496353955 139.74776321609542 6.407 35.66934633882468 139.74779059757958 6.407 35.66934633882468 139.74779059757958 53.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fef86f9-5496-47d7-a215-e5ed58291ed4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fef86f9-5496-47d7-a215-e5ed58291ed4_0">
											<gml:posList>35.66934633882468 139.74779059757958 53.541 35.66935496353955 139.74776321609542 53.541 35.66935496353955 139.74776321609542 6.407 35.66934633882468 139.74779059757958 53.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6c9a095-b617-4828-a71e-7b3666eaf82c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6c9a095-b617-4828-a71e-7b3666eaf82c_0">
											<gml:posList>35.66934875537429 139.74779182112053 53.541 35.66935333370034 139.747778218464 53.541 35.66934633882468 139.74779059757958 53.541 35.66934875537429 139.74779182112053 53.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6aae95a5-a0a5-4f85-9831-be88fa00d4d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6aae95a5-a0a5-4f85-9831-be88fa00d4d6_0">
											<gml:posList>35.66935333370034 139.747778218464 53.541 35.66935496353955 139.74776321609542 53.541 35.66934633882468 139.74779059757958 53.541 35.66935333370034 139.747778218464 53.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae166a38-43be-43f4-930f-0ef8fa762432">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae166a38-43be-43f4-930f-0ef8fa762432_0">
											<gml:posList>35.66935333370034 139.747778218464 53.541 35.66935791202485 139.7477646158059 53.541 35.66935496353955 139.74776321609542 53.541 35.66935333370034 139.747778218464 53.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc3bb8cb-9ffd-4930-80ab-1e45559befd2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc3bb8cb-9ffd-4930-80ab-1e45559befd2_0">
											<gml:posList>35.669368995149235 139.74778468582568 56.281 35.669372573366864 139.74777166967695 51.329 35.669368995149235 139.74778468582568 51.329 35.669368995149235 139.74778468582568 56.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a332a236-85c3-4422-bb60-96fcde460e13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a332a236-85c3-4422-bb60-96fcde460e13_0">
											<gml:posList>35.669368995149235 139.74778468582568 56.281 35.669372573366864 139.74777166967695 56.281 35.669372573366864 139.74777166967695 51.329 35.669368995149235 139.74778468582568 56.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b118e08-2108-429e-b402-56d33eb2da13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b118e08-2108-429e-b402-56d33eb2da13_0">
											<gml:posList>35.669392211792015 139.74778083909573 56.913 35.66938197776762 139.7477760007676 57.858 35.66938197776762 139.7477760007676 56.913 35.669392211792015 139.74778083909573 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28612cea-bcc4-47ef-a71f-a2aa91206275">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28612cea-bcc4-47ef-a71f-a2aa91206275_0">
											<gml:posList>35.669392211792015 139.74778083909573 56.913 35.669392211792015 139.74778083909573 57.858 35.66938197776762 139.7477760007676 57.858 35.669392211792015 139.74778083909573 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0862ae22-57b7-4433-8d27-6530caf41f77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0862ae22-57b7-4433-8d27-6530caf41f77_0">
											<gml:posList>35.669372573366864 139.74777166967695 56.281 35.669368995149235 139.74778468582568 56.281 35.66937783907034 139.7477740389741 56.281 35.669372573366864 139.74777166967695 56.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4135c44-9f83-4e45-a84e-b1ca04fd7970">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4135c44-9f83-4e45-a84e-b1ca04fd7970_0">
											<gml:posList>35.669368995149235 139.74778468582568 56.281 35.66936480558179 139.7477999339417 56.281 35.66936924192778 139.74780217157172 56.281 35.669368995149235 139.74778468582568 56.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bd727ca-afaf-4ea4-bd46-2bbfef531b5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5bd727ca-afaf-4ea4-bd46-2bbfef531b5b_0">
											<gml:posList>35.669368995149235 139.74778468582568 56.281 35.66936924192778 139.74780217157172 56.281 35.66937783907034 139.7477740389741 56.281 35.669368995149235 139.74778468582568 56.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-240d862c-4283-468a-96e2-5677dd8fdb8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-240d862c-4283-468a-96e2-5677dd8fdb8e_0">
											<gml:posList>35.66936924192778 139.74780217157172 56.281 35.66937783907034 139.7477740389741 6.407 35.66937783907034 139.7477740389741 56.281 35.66936924192778 139.74780217157172 56.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0da9ab3-24c2-4b75-a22c-e5aa865809a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0da9ab3-24c2-4b75-a22c-e5aa865809a2_0">
											<gml:posList>35.66936924192778 139.74780217157172 56.281 35.66936924192778 139.74780217157172 6.407 35.66937783907034 139.7477740389741 6.407 35.66936924192778 139.74780217157172 56.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28a1198c-dbcf-4ae2-a2d8-11748f02c173">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28a1198c-dbcf-4ae2-a2d8-11748f02c173_0">
											<gml:posList>35.66934875537429 139.74779182112053 53.541 35.66936480558179 139.7477999339417 56.281 35.669368995149235 139.74778468582568 56.281 35.66934875537429 139.74779182112053 53.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6c35455-08fc-454c-9a97-afcc3578007d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6c35455-08fc-454c-9a97-afcc3578007d_0">
											<gml:posList>35.66935333370034 139.747778218464 53.541 35.66934875537429 139.74779182112053 53.541 35.669368995149235 139.74778468582568 56.281 35.66935333370034 139.747778218464 53.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1aac768c-1cd9-41ec-b5f1-a2c37776b6c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1aac768c-1cd9-41ec-b5f1-a2c37776b6c7_0">
											<gml:posList>35.66936924192778 139.74780217157172 56.281 35.66936480558179 139.7477999339417 56.281 35.66934875537429 139.74779182112053 53.541 35.66936924192778 139.74780217157172 56.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3549b061-2da4-45bf-9120-eb35fcfa8d96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3549b061-2da4-45bf-9120-eb35fcfa8d96_0">
											<gml:posList>35.66936924192778 139.74780217157172 56.281 35.66934875537429 139.74779182112053 53.541 35.66936924192778 139.74780217157172 6.407 35.66936924192778 139.74780217157172 56.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5f756a1-36b4-4e93-9232-2806fda552cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5f756a1-36b4-4e93-9232-2806fda552cb_0">
											<gml:posList>35.66934875537429 139.74779182112053 53.541 35.66934633882468 139.74779059757958 6.407 35.66936924192778 139.74780217157172 6.407 35.66934875537429 139.74779182112053 53.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f31d05d-d3fd-478d-990d-ffc7774b96e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f31d05d-d3fd-478d-990d-ffc7774b96e2_0">
											<gml:posList>35.66934875537429 139.74779182112053 53.541 35.66934633882468 139.74779059757958 53.541 35.66934633882468 139.74779059757958 6.407 35.66934875537429 139.74779182112053 53.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-738c1801-2c2b-453d-9685-b7bfdc3fe585">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66938197776762 139.7477760007676 56.913 35.66938416315827 139.7477690393782 56.913 35.669392211792015 139.74778083909573 56.913 35.66938197776762 139.7477760007676 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-771f9352-6536-451a-919c-c1c28e02b1a2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669392211792015 139.74778083909573 56.913 35.66938416315827 139.7477690393782 56.913 35.66940679014161 139.7477345292264 56.913 35.669392211792015 139.74778083909573 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1352ad03-27be-4486-b633-84e8670bb74d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66938416315827 139.7477690393782 56.913 35.66939655611539 139.74772969090327 56.913 35.66940679014161 139.7477345292264 56.913 35.66938416315827 139.7477690393782 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-672f8d1d-20c2-43cf-b4d4-1bd1718e26f2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66934633882468 139.74779059757958 6.407 35.66937783907034 139.7477740389741 6.407 35.66936924192778 139.74780217157172 6.407 35.66934633882468 139.74779059757958 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3feaaa0-f426-41fa-a871-10965358b5cc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66934633882468 139.74779059757958 6.407 35.66935496353955 139.74776321609542 6.407 35.66937783907034 139.7477740389741 6.407 35.66934633882468 139.74779059757958 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c0bd6cfd-b69f-4ce9-ae8f-169a88cca8e1_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b710daeb-4b30-437d-99ac-3d6c7122549c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66940344893191 139.7477005549111 57.4 35.66937712884712 139.74768790207293 57.4 35.669370329937955 139.74770965914752 57.4 35.669365776521786 139.7477075762933 57.4 35.669373456905795 139.7476831893013 57.4 35.669404537173214 139.74769715154213 57.4 35.66940344893191 139.7477005549111 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e1ace6f-78f2-4632-ba87-611e8b98dd41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66940827067827 139.74769971025586 57.4 35.66940763265186 139.74770245037658 57.4 35.669405081131146 139.74770155836532 57.4 35.669406043510264 139.74769861906805 57.4 35.66940827067827 139.74769971025586 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a6a3ad0-7fff-492b-b793-8cb5ca1c0d51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66943379360761 139.74773216966472 56.913 35.66942102535791 139.74772541201972 56.913 35.669438935558745 139.74767459174308 56.913 35.669451703811234 139.74768134938148 56.913 35.66943379360761 139.74773216966472 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4da87e33-bb6e-4f62-bbb3-d24018767083">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66937997097226 139.7477045124051 57.4 35.669382975020966 139.7476953188228 57.4 35.669402794126995 139.7477050513835 57.4 35.6694005655329 139.74771463075405 57.4 35.66937997097226 139.7477045124051 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99bb35e6-d9b2-4513-aebd-f6ebd769bf26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66942308541439 139.74770698487822 56.913 35.6694178148223 139.7477230957608 56.913 35.6694005655329 139.74771463075405 56.913 35.669402794126995 139.7477050513835 56.913 35.66940378598247 139.74770553635378 56.913 35.669405081131146 139.74770155836532 56.913 35.66940763265186 139.74770245037658 56.913 35.66940827067827 139.74769971025586 56.913 35.66942308541439 139.74770698487822 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e4611ff-1b4a-405a-9f8e-b08b173ad0f2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669426346568144 139.74778051547457 56.913 35.669460284783966 139.74768120766132 56.913 35.66948203384955 139.7476923741642 56.913 35.66944809562466 139.74779168199967 56.913 35.669426346568144 139.74778051547457 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fe5b186-b148-4b84-bc46-d0b072de3a3e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6694134332263 139.74774715890362 56.913 35.66942586738599 139.7477530994945 56.913 35.66941544377383 139.74778589552574 56.913 35.66940300961573 139.74777995493056 56.913 35.6694134332263 139.74774715890362 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55d08ae0-f496-4e46-86fb-ee0f013b44c9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669378352526884 139.7477862664834 57.4 35.66936982672246 139.74781331648396 57.4 35.66936697738869 139.7478119166657 57.4 35.66937549417125 139.74778485562948 57.4 35.669378352526884 139.7477862664834 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00c6d2eb-b961-4fa3-942d-91d225e42284">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66938984004732 139.7477919319346 56.913 35.669381323255365 139.74781898192882 56.913 35.66936982672246 139.74781331648396 56.913 35.669378352526884 139.7477862664834 56.913 35.66938984004732 139.7477919319346 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd423140-3b2f-49b2-a1b5-b0abfadbad4e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669426366522934 139.74785938481256 56.913 35.66944546133541 139.74780116239083 56.913 35.669452223999336 139.74780449110875 56.913 35.66943312919313 139.7478627245807 56.913 35.669426366522934 139.74785938481256 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2cee79c7-084d-4169-b7dd-984935036250">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669459762706616 139.74780903407407 56.913 35.669466768905664 139.7478125945023 56.913 35.669447295064394 139.74787018771127 56.913 35.66944028886701 139.74786662727888 56.913 35.669459762706616 139.74780903407407 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6d1aa31-afe8-46b3-8022-4a51bfaa4517">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669418477387815 139.74785639972194 56.913 35.66941124558024 139.74785246396425 56.913 35.66942185197957 139.74782318041716 56.913 35.669429083788096 139.74782711617272 56.913 35.669418477387815 139.74785639972194 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a618d5a-77f6-455c-afd6-ba9b7aee3e31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66947066317225 139.7478257573414 56.913 35.66945400435747 139.74787452169002 56.913 35.66945400435747 139.74787452169002 58.453 35.66947066317225 139.7478257573414 58.453 35.66947066317225 139.7478257573414 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e03aeef4-4b80-4f14-8ea4-b9b89876ea11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66945400435747 139.74787452169002 56.913 35.66947066317225 139.7478257573414 56.913 35.669478589131636 139.747829824913 56.913 35.66946192130151 139.7478785892752 56.913 35.66945400435747 139.74787452169002 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed47834b-e4db-4f34-8f22-19944ebb1441">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66940784422902 139.74789879504374 56.913 35.66939033318544 139.74788981111135 56.913 35.669395073565774 139.7478759210814 56.913 35.66941259361626 139.74788489395553 56.913 35.66940784422902 139.74789879504374 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35a62369-7499-4893-8c5b-b01b27e6b4db">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66940656475695 139.74793759040168 56.913 35.66940037908477 139.74793441570563 56.913 35.66942173338417 139.7478719712915 56.913 35.66942791906581 139.74787515702968 56.913 35.66940656475695 139.74793759040168 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c49df88f-6678-4134-a550-fee0ceaf1f61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669389993681435 139.7478940642308 56.913 35.66937884943411 139.7479275679485 56.913 35.669356757907494 139.74791645699156 56.913 35.66936790215962 139.74788296432766 56.913 35.669389993681435 139.7478940642308 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c212a64-e922-4b20-b845-f5b6aa6d5717">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66942791906581 139.74787515702968 56.913 35.66942791906581 139.74787515702968 58.125 35.66940656475695 139.74793759040168 58.125 35.66940656475695 139.74793759040168 56.913 35.66942791906581 139.74787515702968 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c52e0678-72cd-45f9-8e15-66b2215686db">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66943589062528 139.74787997569223 56.913 35.66944318539475 139.74788372360229 56.913 35.6694220469723 139.74794553817082 56.913 35.66941475220471 139.74794179025614 56.913 35.66943589062528 139.74787997569223 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac71c659-96e1-442a-a9f0-c5de0aafdab4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66942897204384 139.7479490986957 56.913 35.66942897204384 139.7479490986957 58.125 35.66944980462847 139.74788816813924 58.125 35.66944980462847 139.74788816813924 56.913 35.66942897204384 139.7479490986957 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2867dabf-3046-4ea6-97b2-92e9476cf379">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66944980462847 139.74788816813924 56.913 35.66945753221327 139.74789213651215 56.913 35.66943669061295 139.74795306708305 56.913 35.66942897204384 139.7479490986957 56.913 35.66944980462847 139.74788816813924 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-582d23db-e3b5-48be-bac6-ef43d0396a7b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66935550767147 139.74792022505002 57.4 35.669356757907494 139.74791645699156 57.4 35.66937884943411 139.7479275679485 57.4 35.66937759918991 139.7479313249617 57.4 35.66935550767147 139.74792022505002 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89fd770e-628e-4c4a-89be-16548dca8ace">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89fd770e-628e-4c4a-89be-16548dca8ace_0">
											<gml:posList>35.669382975020966 139.7476953188228 57.4 35.66937997097226 139.7477045124051 57.4 35.66937997097226 139.7477045124051 57.457 35.669382975020966 139.7476953188228 57.457 35.669382975020966 139.7476953188228 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d382e9e-a28b-4bb7-b3aa-f08bcc8b1d4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d382e9e-a28b-4bb7-b3aa-f08bcc8b1d4a_0">
											<gml:posList>35.6694178148223 139.7477230957608 56.913 35.66942308541439 139.74770698487822 56.913 35.66942308541439 139.74770698487822 57.457 35.6694178148223 139.7477230957608 57.457 35.6694178148223 139.7477230957608 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c215619-0e94-43a7-a252-d89707d84062">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c215619-0e94-43a7-a252-d89707d84062_0">
											<gml:posList>35.66943312919313 139.7478627245807 56.913 35.669452223999336 139.74780449110875 56.913 35.669452223999336 139.74780449110875 58.453 35.66943312919313 139.7478627245807 58.453 35.66943312919313 139.7478627245807 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7a6272e-c08b-46e8-a5f3-824ffc816787">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7a6272e-c08b-46e8-a5f3-824ffc816787_0">
											<gml:posList>35.66944028886701 139.74786662727888 58.453 35.669459762706616 139.74780903407407 58.453 35.669459762706616 139.74780903407407 56.913 35.66944028886701 139.74786662727888 56.913 35.66944028886701 139.74786662727888 58.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-603d0a81-9934-4492-86e5-f2670e48b3d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-603d0a81-9934-4492-86e5-f2670e48b3d4_0">
											<gml:posList>35.66943589062528 139.74787997569223 56.913 35.66941475220471 139.74794179025614 56.913 35.66941475220471 139.74794179025614 58.125 35.66943589062528 139.74787997569223 58.125 35.66943589062528 139.74787997569223 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e681b80d-f7be-4c41-9377-a8897c04b79b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e681b80d-f7be-4c41-9377-a8897c04b79b_0">
											<gml:posList>35.66944318539475 139.74788372360229 56.913 35.66944318539475 139.74788372360229 58.125 35.6694220469723 139.74794553817082 58.125 35.6694220469723 139.74794553817082 56.913 35.66944318539475 139.74788372360229 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23a7ac2b-3a5a-4dde-9fe3-73aec865b191">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23a7ac2b-3a5a-4dde-9fe3-73aec865b191_0">
											<gml:posList>35.669451703811234 139.74768134938148 56.913 35.669438935558745 139.74767459174308 56.913 35.669438935558745 139.74767459174308 59.006 35.669451703811234 139.74768134938148 59.006 35.669451703811234 139.74768134938148 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88268330-40e9-40ef-b5cd-c1966d62dcdb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88268330-40e9-40ef-b5cd-c1966d62dcdb_0">
											<gml:posList>35.66948203384955 139.7476923741642 56.913 35.669460284783966 139.74768120766132 56.913 35.669460284783966 139.74768120766132 58.518 35.66948203384955 139.7476923741642 58.518 35.66948203384955 139.7476923741642 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a9270aa-513c-44ea-aad4-648ce9825d3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a9270aa-513c-44ea-aad4-648ce9825d3e_0">
											<gml:posList>35.669373456905795 139.7476831893013 57.4 35.669373456905795 139.7476831893013 60.678 35.669404537173214 139.74769715154213 60.678 35.669404537173214 139.74769715154213 57.4 35.669373456905795 139.7476831893013 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a9024a7-9066-4815-825b-6981fc243caa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a9024a7-9066-4815-825b-6981fc243caa_0">
											<gml:posList>35.66940344893191 139.7477005549111 57.4 35.66940344893191 139.7477005549111 60.678 35.66937712884712 139.74768790207293 60.678 35.66937712884712 139.74768790207293 57.4 35.66940344893191 139.7477005549111 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea8fa3b4-c59c-4618-8867-5b632f226add">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea8fa3b4-c59c-4618-8867-5b632f226add_0">
											<gml:posList>35.669373456905795 139.7476831893013 57.4 35.669365776521786 139.7477075762933 57.4 35.669365776521786 139.7477075762933 60.678 35.669373456905795 139.7476831893013 60.678 35.669373456905795 139.7476831893013 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a5ef0ee-1e00-46f9-9260-23b6d3b40dba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a5ef0ee-1e00-46f9-9260-23b6d3b40dba_0">
											<gml:posList>35.669373456905795 139.7476831893013 60.678 35.669365776521786 139.7477075762933 60.678 35.669370329937955 139.74770965914752 60.678 35.66937712884712 139.74768790207293 60.678 35.66940344893191 139.7477005549111 60.678 35.669404537173214 139.74769715154213 60.678 35.669373456905795 139.7476831893013 60.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86f14014-9769-4ff3-baeb-892eedf2145e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86f14014-9769-4ff3-baeb-892eedf2145e_0">
											<gml:posList>35.66937712884712 139.74768790207293 57.4 35.66937712884712 139.74768790207293 60.678 35.669370329937955 139.74770965914752 60.678 35.669370329937955 139.74770965914752 57.4 35.66937712884712 139.74768790207293 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90bb277f-c3ef-4e08-9ba8-180abc5fabb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90bb277f-c3ef-4e08-9ba8-180abc5fabb4_0">
											<gml:posList>35.669404537173214 139.74769715154213 57.4 35.669404537173214 139.74769715154213 60.678 35.66940344893191 139.7477005549111 60.678 35.66940344893191 139.7477005549111 57.4 35.669404537173214 139.74769715154213 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c051663-e41e-4f56-a4f2-671372ac743e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c051663-e41e-4f56-a4f2-671372ac743e_0">
											<gml:posList>35.66942102535791 139.74772541201972 56.913 35.66942102535791 139.74772541201972 59.006 35.669438935558745 139.74767459174308 59.006 35.669438935558745 139.74767459174308 56.913 35.66942102535791 139.74772541201972 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d27ffd0-dd59-425a-9cb3-dc71c5c6f457">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d27ffd0-dd59-425a-9cb3-dc71c5c6f457_0">
											<gml:posList>35.669402794126995 139.7477050513835 57.4 35.669382975020966 139.7476953188228 57.4 35.669382975020966 139.7476953188228 57.457 35.66940378598247 139.74770553635378 57.457 35.66940378598247 139.74770553635378 56.913 35.669402794126995 139.7477050513835 56.913 35.669402794126995 139.7477050513835 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c58a4626-3ea8-432c-b5a9-d2905bcb7d7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c58a4626-3ea8-432c-b5a9-d2905bcb7d7d_0">
											<gml:posList>35.66940763265186 139.74770245037658 57.4 35.66940827067827 139.74769971025586 57.4 35.66940827067827 139.74769971025586 56.913 35.66940763265186 139.74770245037658 56.913 35.66940763265186 139.74770245037658 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-701a46ea-9675-4dfd-9652-5fd43254b6ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-701a46ea-9675-4dfd-9652-5fd43254b6ca_0">
											<gml:posList>35.669405081131146 139.74770155836532 56.913 35.669405081131146 139.74770155836532 57.4 35.66940763265186 139.74770245037658 57.4 35.66940763265186 139.74770245037658 56.913 35.669405081131146 139.74770155836532 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d9f27ae-c776-4e77-a81a-2cf180bb334a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d9f27ae-c776-4e77-a81a-2cf180bb334a_0">
											<gml:posList>35.66940378598247 139.74770553635378 56.913 35.66940378598247 139.74770553635378 57.457 35.669406043510264 139.74769861906805 57.457 35.669406043510264 139.74769861906805 57.4 35.669405081131146 139.74770155836532 57.4 35.669405081131146 139.74770155836532 56.913 35.66940378598247 139.74770553635378 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fd14505-a6ff-43c2-be42-daaf8c94b30e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fd14505-a6ff-43c2-be42-daaf8c94b30e_0">
											<gml:posList>35.66940827067827 139.74769971025586 57.4 35.669406043510264 139.74769861906805 57.4 35.669406043510264 139.74769861906805 57.457 35.66942308541439 139.74770698487822 57.457 35.66942308541439 139.74770698487822 56.913 35.66940827067827 139.74769971025586 56.913 35.66940827067827 139.74769971025586 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00f0b9b1-2d15-4460-bd42-5083aada4514">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00f0b9b1-2d15-4460-bd42-5083aada4514_0">
											<gml:posList>35.669438935558745 139.74767459174308 59.006 35.66942102535791 139.74772541201972 59.006 35.66943379360761 139.74773216966472 59.006 35.669451703811234 139.74768134938148 59.006 35.669438935558745 139.74767459174308 59.006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fa40609-87a5-4d11-b98d-f779cd887f64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fa40609-87a5-4d11-b98d-f779cd887f64_0">
											<gml:posList>35.66943379360761 139.74773216966472 56.913 35.669451703811234 139.74768134938148 56.913 35.669451703811234 139.74768134938148 59.006 35.66943379360761 139.74773216966472 59.006 35.66943379360761 139.74773216966472 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40be25e0-d471-4ef9-a397-ba593f59564c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40be25e0-d471-4ef9-a397-ba593f59564c_0">
											<gml:posList>35.669365776521786 139.7477075762933 57.4 35.669370329937955 139.74770965914752 57.4 35.669370329937955 139.74770965914752 60.678 35.669365776521786 139.7477075762933 60.678 35.669365776521786 139.7477075762933 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39c948d7-f2ca-4264-8b29-e603711fd930">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39c948d7-f2ca-4264-8b29-e603711fd930_0">
											<gml:posList>35.66940378598247 139.74770553635378 57.457 35.669382975020966 139.7476953188228 57.457 35.66937997097226 139.7477045124051 57.457 35.6694178148223 139.7477230957608 57.457 35.66942308541439 139.74770698487822 57.457 35.669406043510264 139.74769861906805 57.457 35.66940378598247 139.74770553635378 57.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19bb66b5-24b5-435a-8014-530ac5bab784">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19bb66b5-24b5-435a-8014-530ac5bab784_0">
											<gml:posList>35.669402794126995 139.7477050513835 57.4 35.669402794126995 139.7477050513835 56.913 35.6694005655329 139.74771463075405 56.913 35.6694005655329 139.74771463075405 57.4 35.669402794126995 139.7477050513835 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37d76a79-c67c-4999-9d9b-451c707ea6e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37d76a79-c67c-4999-9d9b-451c707ea6e1_0">
											<gml:posList>35.6694178148223 139.7477230957608 56.913 35.6694178148223 139.7477230957608 57.457 35.66937997097226 139.7477045124051 57.457 35.66937997097226 139.7477045124051 57.4 35.6694005655329 139.74771463075405 57.4 35.6694005655329 139.74771463075405 56.913 35.6694178148223 139.7477230957608 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd992da3-b40a-439c-a1e6-ef0282026ff6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd992da3-b40a-439c-a1e6-ef0282026ff6_0">
											<gml:posList>35.66942102535791 139.74772541201972 56.913 35.66943379360761 139.74773216966472 56.913 35.66943379360761 139.74773216966472 59.006 35.66942102535791 139.74772541201972 59.006 35.66942102535791 139.74772541201972 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5d2a069-5cf8-4a24-a378-a68411a3fb80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5d2a069-5cf8-4a24-a378-a68411a3fb80_0">
											<gml:posList>35.669426346568144 139.74778051547457 56.913 35.669426346568144 139.74778051547457 58.518 35.669460284783966 139.74768120766132 58.518 35.669460284783966 139.74768120766132 56.913 35.669426346568144 139.74778051547457 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c6740f7-2cd9-4fb0-aaee-99208c626c24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c6740f7-2cd9-4fb0-aaee-99208c626c24_0">
											<gml:posList>35.66948203384955 139.7476923741642 58.518 35.669460284783966 139.74768120766132 58.518 35.669426346568144 139.74778051547457 58.518 35.66944809562466 139.74779168199967 58.518 35.66948203384955 139.7476923741642 58.518</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a10911b9-e045-43a1-beba-2c02b4ca0692">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a10911b9-e045-43a1-beba-2c02b4ca0692_0">
											<gml:posList>35.66944809562466 139.74779168199967 56.913 35.66948203384955 139.7476923741642 56.913 35.66948203384955 139.7476923741642 58.518 35.66944809562466 139.74779168199967 58.518 35.66944809562466 139.74779168199967 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce68dfae-b3bf-4268-9223-d185adcbbe17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce68dfae-b3bf-4268-9223-d185adcbbe17_0">
											<gml:posList>35.6694134332263 139.74774715890362 56.913 35.6694134332263 139.74774715890362 57.633 35.66942586738599 139.7477530994945 57.633 35.66942586738599 139.7477530994945 56.913 35.6694134332263 139.74774715890362 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f9d0325-d7b0-42f7-8845-346857dd1517">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f9d0325-d7b0-42f7-8845-346857dd1517_0">
											<gml:posList>35.6694134332263 139.74774715890362 56.913 35.66940300961573 139.74777995493056 56.913 35.66940300961573 139.74777995493056 57.633 35.6694134332263 139.74774715890362 57.633 35.6694134332263 139.74774715890362 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17486001-cfc7-42c3-83e2-f78521effb80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17486001-cfc7-42c3-83e2-f78521effb80_0">
											<gml:posList>35.66941544377383 139.74778589552574 57.633 35.66942586738599 139.7477530994945 57.633 35.6694134332263 139.74774715890362 57.633 35.66940300961573 139.74777995493056 57.633 35.66941544377383 139.74778589552574 57.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f85ac982-bf5e-4d80-943e-9ad8d280bdaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f85ac982-bf5e-4d80-943e-9ad8d280bdaf_0">
											<gml:posList>35.66941544377383 139.74778589552574 56.913 35.66942586738599 139.7477530994945 56.913 35.66942586738599 139.7477530994945 57.633 35.66941544377383 139.74778589552574 57.633 35.66941544377383 139.74778589552574 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d9def9a-6319-4e28-87b6-649deb32ff1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d9def9a-6319-4e28-87b6-649deb32ff1b_0">
											<gml:posList>35.66940300961573 139.74777995493056 56.913 35.66941544377383 139.74778589552574 56.913 35.66941544377383 139.74778589552574 57.633 35.66940300961573 139.74777995493056 57.633 35.66940300961573 139.74777995493056 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2b64485-d05b-43d0-ad93-f00e9dbfed18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2b64485-d05b-43d0-ad93-f00e9dbfed18_0">
											<gml:posList>35.669426346568144 139.74778051547457 56.913 35.66944809562466 139.74779168199967 56.913 35.66944809562466 139.74779168199967 58.518 35.669426346568144 139.74778051547457 58.518 35.669426346568144 139.74778051547457 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f63239c-3ebd-43e8-a71a-b452f4233e53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f63239c-3ebd-43e8-a71a-b452f4233e53_0">
											<gml:posList>35.66937549417125 139.74778485562948 57.693 35.66938984004732 139.7477919319346 57.693 35.66938984004732 139.7477919319346 56.913 35.669378352526884 139.7477862664834 56.913 35.669378352526884 139.7477862664834 57.4 35.66937549417125 139.74778485562948 57.4 35.66937549417125 139.74778485562948 57.693</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cda78d7e-4637-4daf-ae3c-b859bd7e128b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cda78d7e-4637-4daf-ae3c-b859bd7e128b_0">
											<gml:posList>35.66937549417125 139.74778485562948 57.4 35.66936697738869 139.7478119166657 57.4 35.66936697738869 139.7478119166657 57.693 35.66937549417125 139.74778485562948 57.693 35.66937549417125 139.74778485562948 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e237c4f-32ef-4b90-ba64-30f4061f1da9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e237c4f-32ef-4b90-ba64-30f4061f1da9_0">
											<gml:posList>35.669378352526884 139.7477862664834 57.4 35.669378352526884 139.7477862664834 56.913 35.66936982672246 139.74781331648396 56.913 35.66936982672246 139.74781331648396 57.4 35.669378352526884 139.7477862664834 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cae88e6b-a85a-459c-ae45-c9ac8a27f74e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cae88e6b-a85a-459c-ae45-c9ac8a27f74e_0">
											<gml:posList>35.66938984004732 139.7477919319346 57.693 35.66937549417125 139.74778485562948 57.693 35.66936697738869 139.7478119166657 57.693 35.669381323255365 139.74781898192882 57.693 35.66938984004732 139.7477919319346 57.693</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c80783f-e237-4529-9523-e4e2c378df2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c80783f-e237-4529-9523-e4e2c378df2d_0">
											<gml:posList>35.669452223999336 139.74780449110875 56.913 35.66944546133541 139.74780116239083 56.913 35.66944546133541 139.74780116239083 58.453 35.669452223999336 139.74780449110875 58.453 35.669452223999336 139.74780449110875 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ef5f3cc-67a0-43d6-94ad-03cc1523c411">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ef5f3cc-67a0-43d6-94ad-03cc1523c411_0">
											<gml:posList>35.669381323255365 139.74781898192882 56.913 35.66938984004732 139.7477919319346 56.913 35.66938984004732 139.7477919319346 57.693 35.669381323255365 139.74781898192882 57.693 35.669381323255365 139.74781898192882 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5be09263-df5e-4835-8e19-99e4f3f2c6d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5be09263-df5e-4835-8e19-99e4f3f2c6d9_0">
											<gml:posList>35.669466768905664 139.7478125945023 56.913 35.669459762706616 139.74780903407407 56.913 35.669459762706616 139.74780903407407 58.453 35.669466768905664 139.7478125945023 58.453 35.669466768905664 139.7478125945023 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9aa0fbd3-35b9-42f5-a572-b94200b5cace">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9aa0fbd3-35b9-42f5-a572-b94200b5cace_0">
											<gml:posList>35.669381323255365 139.74781898192882 56.913 35.669381323255365 139.74781898192882 57.693 35.66936697738869 139.7478119166657 57.693 35.66936697738869 139.7478119166657 57.4 35.66936982672246 139.74781331648396 57.4 35.66936982672246 139.74781331648396 56.913 35.669381323255365 139.74781898192882 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-119cb9c9-08ab-4764-88ce-520f7c5b93f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-119cb9c9-08ab-4764-88ce-520f7c5b93f5_0">
											<gml:posList>35.669429083788096 139.74782711617272 56.913 35.66942185197957 139.74782318041716 56.913 35.66942185197957 139.74782318041716 58.453 35.669429083788096 139.74782711617272 58.453 35.669429083788096 139.74782711617272 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-469fb3ee-6082-49a1-97e4-4b2506d1a3b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-469fb3ee-6082-49a1-97e4-4b2506d1a3b3_0">
											<gml:posList>35.669478589131636 139.747829824913 56.913 35.66947066317225 139.7478257573414 56.913 35.66947066317225 139.7478257573414 58.453 35.669478589131636 139.747829824913 58.453 35.669478589131636 139.747829824913 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d3be03d-a3e2-4f2c-b873-a1cc6a88cc2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d3be03d-a3e2-4f2c-b873-a1cc6a88cc2d_0">
											<gml:posList>35.669426366522934 139.74785938481256 56.913 35.669426366522934 139.74785938481256 58.453 35.66944546133541 139.74780116239083 58.453 35.66944546133541 139.74780116239083 56.913 35.669426366522934 139.74785938481256 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-731a0195-b9e4-4bc4-a228-53c978a4ce8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-731a0195-b9e4-4bc4-a228-53c978a4ce8e_0">
											<gml:posList>35.669452223999336 139.74780449110875 58.453 35.66944546133541 139.74780116239083 58.453 35.669426366522934 139.74785938481256 58.453 35.66943312919313 139.7478627245807 58.453 35.669452223999336 139.74780449110875 58.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49a2f39b-e360-4c0c-ae62-486b5f05694a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49a2f39b-e360-4c0c-ae62-486b5f05694a_0">
											<gml:posList>35.66942185197957 139.74782318041716 56.913 35.66941124558024 139.74785246396425 56.913 35.66941124558024 139.74785246396425 58.453 35.66942185197957 139.74782318041716 58.453 35.66942185197957 139.74782318041716 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ceacf3f-7948-4a95-8b3a-f8a55f009f21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ceacf3f-7948-4a95-8b3a-f8a55f009f21_0">
											<gml:posList>35.669459762706616 139.74780903407407 58.453 35.66944028886701 139.74786662727888 58.453 35.669447295064394 139.74787018771127 58.453 35.669466768905664 139.7478125945023 58.453 35.669459762706616 139.74780903407407 58.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22b7fc77-471f-489e-8cca-e72087efd8b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22b7fc77-471f-489e-8cca-e72087efd8b3_0">
											<gml:posList>35.669418477387815 139.74785639972194 58.453 35.669429083788096 139.74782711617272 58.453 35.66942185197957 139.74782318041716 58.453 35.66941124558024 139.74785246396425 58.453 35.669418477387815 139.74785639972194 58.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e81f7b4-81b7-4c10-bab6-bf9d8de15c9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e81f7b4-81b7-4c10-bab6-bf9d8de15c9a_0">
											<gml:posList>35.669447295064394 139.74787018771127 56.913 35.669466768905664 139.7478125945023 56.913 35.669466768905664 139.7478125945023 58.453 35.669447295064394 139.74787018771127 58.453 35.669447295064394 139.74787018771127 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99f66b1a-11bf-498b-911b-4313a7080fa9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99f66b1a-11bf-498b-911b-4313a7080fa9_0">
											<gml:posList>35.669418477387815 139.74785639972194 56.913 35.669429083788096 139.74782711617272 56.913 35.669429083788096 139.74782711617272 58.453 35.669418477387815 139.74785639972194 58.453 35.669418477387815 139.74785639972194 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1051201b-7310-4782-b468-fab7d2f0d775">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1051201b-7310-4782-b468-fab7d2f0d775_0">
											<gml:posList>35.669478589131636 139.747829824913 58.453 35.66947066317225 139.7478257573414 58.453 35.66945400435747 139.74787452169002 58.453 35.66946192130151 139.7478785892752 58.453 35.669478589131636 139.747829824913 58.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43f81d98-13e8-4086-bff2-39b1aaa1cf4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43f81d98-13e8-4086-bff2-39b1aaa1cf4e_0">
											<gml:posList>35.66946192130151 139.7478785892752 56.913 35.669478589131636 139.747829824913 56.913 35.669478589131636 139.747829824913 58.453 35.66946192130151 139.7478785892752 58.453 35.66946192130151 139.7478785892752 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6764544f-4185-43cc-9569-2734df8be255">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6764544f-4185-43cc-9569-2734df8be255_0">
											<gml:posList>35.66941124558024 139.74785246396425 56.913 35.669418477387815 139.74785639972194 56.913 35.669418477387815 139.74785639972194 58.453 35.66941124558024 139.74785246396425 58.453 35.66941124558024 139.74785246396425 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-139b6506-8b6d-45e7-a7f5-d0095fde373e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-139b6506-8b6d-45e7-a7f5-d0095fde373e_0">
											<gml:posList>35.66943312919313 139.7478627245807 56.913 35.66943312919313 139.7478627245807 58.453 35.669426366522934 139.74785938481256 58.453 35.669426366522934 139.74785938481256 56.913 35.66943312919313 139.7478627245807 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efa0286b-2dc5-4e72-8bc7-a0854d7041c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efa0286b-2dc5-4e72-8bc7-a0854d7041c7_0">
											<gml:posList>35.669447295064394 139.74787018771127 56.913 35.669447295064394 139.74787018771127 58.453 35.66944028886701 139.74786662727888 58.453 35.66944028886701 139.74786662727888 56.913 35.669447295064394 139.74787018771127 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e2fa96d-058f-4c49-8abd-7837d40e1912">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e2fa96d-058f-4c49-8abd-7837d40e1912_0">
											<gml:posList>35.66942791906581 139.74787515702968 56.913 35.66942173338417 139.7478719712915 56.913 35.66942173338417 139.7478719712915 58.125 35.66942791906581 139.74787515702968 58.125 35.66942791906581 139.74787515702968 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba2b9495-92e9-4874-8b3f-cebac9673a89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba2b9495-92e9-4874-8b3f-cebac9673a89_0">
											<gml:posList>35.66945400435747 139.74787452169002 56.913 35.66946192130151 139.7478785892752 56.913 35.66946192130151 139.7478785892752 58.453 35.66945400435747 139.74787452169002 58.453 35.66945400435747 139.74787452169002 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8635ee6e-cd59-4590-8747-50f1c577814a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8635ee6e-cd59-4590-8747-50f1c577814a_0">
											<gml:posList>35.66941259361626 139.74788489395553 56.913 35.669395073565774 139.7478759210814 56.913 35.669395073565774 139.7478759210814 58.453 35.66941259361626 139.74788489395553 58.453 35.66941259361626 139.74788489395553 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30e3e50b-70a6-45b3-a2c7-bf8b688291f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30e3e50b-70a6-45b3-a2c7-bf8b688291f8_0">
											<gml:posList>35.66944318539475 139.74788372360229 56.913 35.66943589062528 139.74787997569223 56.913 35.66943589062528 139.74787997569223 58.125 35.66944318539475 139.74788372360229 58.125 35.66944318539475 139.74788372360229 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff518f6d-566c-4b3c-8f66-0465a0a2e090">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff518f6d-566c-4b3c-8f66-0465a0a2e090_0">
											<gml:posList>35.669395073565774 139.7478759210814 56.913 35.66939033318544 139.74788981111135 56.913 35.66939033318544 139.74788981111135 58.453 35.669395073565774 139.7478759210814 58.453 35.669395073565774 139.7478759210814 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f279dc54-f12f-4a53-8d86-5d12003f0979">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f279dc54-f12f-4a53-8d86-5d12003f0979_0">
											<gml:posList>35.669395073565774 139.7478759210814 58.453 35.66939033318544 139.74788981111135 58.453 35.66940784422902 139.74789879504374 58.453 35.66941259361626 139.74788489395553 58.453 35.669395073565774 139.7478759210814 58.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d4c1b48-9ec9-4d2e-ac2b-9ec7f486574b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d4c1b48-9ec9-4d2e-ac2b-9ec7f486574b_0">
											<gml:posList>35.669389993681435 139.7478940642308 56.913 35.66936790215962 139.74788296432766 56.913 35.66936790215962 139.74788296432766 57.693 35.669389993681435 139.7478940642308 57.693 35.669389993681435 139.7478940642308 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8cf493e-299c-4af6-828e-0a1da720e0ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8cf493e-299c-4af6-828e-0a1da720e0ba_0">
											<gml:posList>35.66945753221327 139.74789213651215 56.913 35.66944980462847 139.74788816813924 56.913 35.66944980462847 139.74788816813924 58.125 35.66945753221327 139.74789213651215 58.125 35.66945753221327 139.74789213651215 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23ee81bd-315b-4cff-a791-11ed632ab062">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23ee81bd-315b-4cff-a791-11ed632ab062_0">
											<gml:posList>35.66941259361626 139.74788489395553 56.913 35.66941259361626 139.74788489395553 58.453 35.66940784422902 139.74789879504374 58.453 35.66940784422902 139.74789879504374 56.913 35.66941259361626 139.74788489395553 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36a63ee3-cd90-4464-8788-0c2ca87b8eb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36a63ee3-cd90-4464-8788-0c2ca87b8eb2_0">
											<gml:posList>35.66940784422902 139.74789879504374 56.913 35.66940784422902 139.74789879504374 58.453 35.66939033318544 139.74788981111135 58.453 35.66939033318544 139.74788981111135 56.913 35.66940784422902 139.74789879504374 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc878364-77d3-4a36-a0bf-3ec3a1fbc580">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc878364-77d3-4a36-a0bf-3ec3a1fbc580_0">
											<gml:posList>35.669356757907494 139.74791645699156 57.4 35.66935550767147 139.74792022505002 57.4 35.66935550767147 139.74792022505002 57.693 35.66936790215962 139.74788296432766 57.693 35.66936790215962 139.74788296432766 56.913 35.669356757907494 139.74791645699156 56.913 35.669356757907494 139.74791645699156 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4adf6c85-dbc6-40e7-9e68-94b923cdd439">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4adf6c85-dbc6-40e7-9e68-94b923cdd439_0">
											<gml:posList>35.66942173338417 139.7478719712915 56.913 35.66940037908477 139.74793441570563 56.913 35.66940037908477 139.74793441570563 58.125 35.66942173338417 139.7478719712915 58.125 35.66942173338417 139.7478719712915 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15cf75ab-3140-4482-8a6b-9456f16360a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15cf75ab-3140-4482-8a6b-9456f16360a7_0">
											<gml:posList>35.66942173338417 139.7478719712915 58.125 35.66940037908477 139.74793441570563 58.125 35.66940656475695 139.74793759040168 58.125 35.66942791906581 139.74787515702968 58.125 35.66942173338417 139.7478719712915 58.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77bc39d5-e35d-45b9-ba82-85f9c448f4b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77bc39d5-e35d-45b9-ba82-85f9c448f4b4_0">
											<gml:posList>35.669389993681435 139.7478940642308 57.693 35.66936790215962 139.74788296432766 57.693 35.66935550767147 139.74792022505002 57.693 35.66937759918991 139.7479313249617 57.693 35.669389993681435 139.7478940642308 57.693</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-903cfca7-5cbd-45db-8d38-080b1edec4c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-903cfca7-5cbd-45db-8d38-080b1edec4c7_0">
											<gml:posList>35.669389993681435 139.7478940642308 56.913 35.669389993681435 139.7478940642308 57.693 35.66937759918991 139.7479313249617 57.693 35.66937759918991 139.7479313249617 57.4 35.66937884943411 139.7479275679485 57.4 35.66937884943411 139.7479275679485 56.913 35.669389993681435 139.7478940642308 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f443a218-f071-44dc-bf3a-e15956039c0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f443a218-f071-44dc-bf3a-e15956039c0a_0">
											<gml:posList>35.6694220469723 139.74794553817082 58.125 35.66944318539475 139.74788372360229 58.125 35.66943589062528 139.74787997569223 58.125 35.66941475220471 139.74794179025614 58.125 35.6694220469723 139.74794553817082 58.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a75bd294-0d57-41f5-9d5a-26728fa76355">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a75bd294-0d57-41f5-9d5a-26728fa76355_0">
											<gml:posList>35.66944980462847 139.74788816813924 58.125 35.66942897204384 139.7479490986957 58.125 35.66943669061295 139.74795306708305 58.125 35.66945753221327 139.74789213651215 58.125 35.66944980462847 139.74788816813924 58.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8117af0-b492-493e-9b2d-4c9c703b9b35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8117af0-b492-493e-9b2d-4c9c703b9b35_0">
											<gml:posList>35.66937884943411 139.7479275679485 57.4 35.669356757907494 139.74791645699156 57.4 35.669356757907494 139.74791645699156 56.913 35.66937884943411 139.7479275679485 56.913 35.66937884943411 139.7479275679485 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-970469de-75ac-45e8-9f5f-8b23b6b931a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-970469de-75ac-45e8-9f5f-8b23b6b931a8_0">
											<gml:posList>35.66945753221327 139.74789213651215 56.913 35.66945753221327 139.74789213651215 58.125 35.66943669061295 139.74795306708305 58.125 35.66943669061295 139.74795306708305 56.913 35.66945753221327 139.74789213651215 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec53e6b1-f3bd-4060-9406-2d7f8767875a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec53e6b1-f3bd-4060-9406-2d7f8767875a_0">
											<gml:posList>35.66935550767147 139.74792022505002 57.4 35.66937759918991 139.7479313249617 57.4 35.66937759918991 139.7479313249617 57.693 35.66935550767147 139.74792022505002 57.693 35.66935550767147 139.74792022505002 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b208efb9-d8e1-4d55-b4bd-aaaeae53715e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b208efb9-d8e1-4d55-b4bd-aaaeae53715e_0">
											<gml:posList>35.66940037908477 139.74793441570563 56.913 35.66940656475695 139.74793759040168 56.913 35.66940656475695 139.74793759040168 58.125 35.66940037908477 139.74793441570563 58.125 35.66940037908477 139.74793441570563 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6069a82d-e336-4d22-b96f-a1342af3e90e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6069a82d-e336-4d22-b96f-a1342af3e90e_0">
											<gml:posList>35.66941475220471 139.74794179025614 56.913 35.6694220469723 139.74794553817082 56.913 35.6694220469723 139.74794553817082 58.125 35.66941475220471 139.74794179025614 58.125 35.66941475220471 139.74794179025614 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fa9632a-6dea-420b-9967-e5776c2bb515">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fa9632a-6dea-420b-9967-e5776c2bb515_0">
											<gml:posList>35.66942897204384 139.7479490986957 56.913 35.66943669061295 139.74795306708305 56.913 35.66943669061295 139.74795306708305 58.125 35.66942897204384 139.7479490986957 58.125 35.66942897204384 139.7479490986957 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c0bd6cfd-b69f-4ce9-ae8f-169a88cca8e1_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a7f239a-e31c-4a17-a8a9-1181f1fb0a20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66939985515227 139.7478946943978 56.913 35.669406121972536 139.74789790214265 56.913 35.66940066198826 139.7479139027498 56.913 35.66939439516842 139.7479106950039 56.913 35.66939985515227 139.7478946943978 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed8a3237-99fe-4416-9d64-3886d72ef919">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed8a3237-99fe-4416-9d64-3886d72ef919_0">
											<gml:posList>35.66939439516842 139.7479106950039 56.913 35.66939439516842 139.7479106950039 57.827 35.66939985515227 139.7478946943978 57.827 35.66939985515227 139.7478946943978 56.913 35.66939439516842 139.7479106950039 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8491c167-911e-4ab0-8b17-583bc9757bd6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8491c167-911e-4ab0-8b17-583bc9757bd6_0">
											<gml:posList>35.66940066198826 139.7479139027498 57.827 35.66939439516842 139.7479106950039 57.827 35.66939439516842 139.7479106950039 56.913 35.66940066198826 139.7479139027498 56.913 35.66940066198826 139.7479139027498 57.827</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2e43ebe-3c87-4098-839e-d4a68df331b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2e43ebe-3c87-4098-839e-d4a68df331b4_0">
											<gml:posList>35.66940066198826 139.7479139027498 57.827 35.669406121972536 139.74789790214265 57.827 35.66939985515227 139.7478946943978 57.827 35.66939439516842 139.7479106950039 57.827 35.66940066198826 139.7479139027498 57.827</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90a13713-30bf-4b7b-a107-53aecaf3c49f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90a13713-30bf-4b7b-a107-53aecaf3c49f_0">
											<gml:posList>35.66939985515227 139.7478946943978 57.827 35.669406121972536 139.74789790214265 57.827 35.669406121972536 139.74789790214265 56.913 35.66939985515227 139.7478946943978 56.913 35.66939985515227 139.7478946943978 57.827</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f948675-a98d-4165-b0f9-f37ad0c51e43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f948675-a98d-4165-b0f9-f37ad0c51e43_0">
											<gml:posList>35.669406121972536 139.74789790214265 56.913 35.669406121972536 139.74789790214265 57.827 35.66940066198826 139.7479139027498 57.827 35.66940066198826 139.7479139027498 56.913 35.669406121972536 139.74789790214265 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-799cfd97-155d-4875-9012-3271c1c55923">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-799cfd97-155d-4875-9012-3271c1c55923">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-799cfd97-155d-4875-9012-3271c1c55923">
											<gml:posList>35.66937783907034 139.7477740389741 6.407 35.66934876000797 139.74776028444853 6.407 35.66937319514631 139.7476826814593 6.407 35.669404663263265 139.74769700780783 6.407 35.66942958106496 139.74762639642904 6.407 35.669549415686625 139.74768558613653 6.407 35.66945389228734 139.74797067839333 6.407 35.66933306519649 139.74790994293093 6.407 35.66936517629881 139.74781424931814 6.407 35.66937783907034 139.7477740389741 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-410dc557-c54a-4519-81f1-31bd5bd7bddf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-410dc557-c54a-4519-81f1-31bd5bd7bddf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-410dc557-c54a-4519-81f1-31bd5bd7bddf">
											<gml:posList>35.66936517629881 139.74781424931814 57.4 35.66933306519649 139.74790994293093 57.4 35.66933838136714 139.74790721992247 57.4 35.66936895435228 139.74781607894462 57.4 35.66936517629881 139.74781424931814 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a361dc10-7301-4049-9c32-25c251700f81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a361dc10-7301-4049-9c32-25c251700f81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a361dc10-7301-4049-9c32-25c251700f81">
											<gml:posList>35.66934876000797 139.74776028444853 61.117 35.669351796464 139.7477586353362 61.117 35.669366635614146 139.74771149674868 61.117 35.66936528992983 139.74770778668923 61.117 35.66934876000797 139.74776028444853 61.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-43255e73-243c-431c-8211-6f3100bb5bf1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43255e73-243c-431c-8211-6f3100bb5bf1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43255e73-243c-431c-8211-6f3100bb5bf1">
											<gml:posList>35.66938197776762 139.7477760007676 61.117 35.66938063207744 139.74777227966024 61.117 35.669351796464 139.7477586353362 61.117 35.66934876000797 139.74776028444853 61.117 35.66938197776762 139.7477760007676 61.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d3a4de6-4261-417e-9fe8-d7c86f11e5ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d3a4de6-4261-417e-9fe8-d7c86f11e5ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d3a4de6-4261-417e-9fe8-d7c86f11e5ed">
											<gml:posList>35.66936517629881 139.74781424931814 57.4 35.66936895435228 139.74781607894462 57.4 35.669380178193144 139.74778046532128 57.4 35.66937783907034 139.7477740389741 57.4 35.66936517629881 139.74781424931814 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7cfcb2df-011b-4d36-9dd5-f18b506c81a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cfcb2df-011b-4d36-9dd5-f18b506c81a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cfcb2df-011b-4d36-9dd5-f18b506c81a3">
											<gml:posList>35.66939547123284 139.74772514105825 60.723 35.669366635614146 139.74771149674868 60.723 35.669351796464 139.7477586353362 60.723 35.66938063207744 139.74777227966024 60.723 35.66939547123284 139.74772514105825 60.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a845078e-e13c-439f-a44c-f0002038aa6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a845078e-e13c-439f-a44c-f0002038aa6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a845078e-e13c-439f-a44c-f0002038aa6b">
											<gml:posList>35.6693816351283 139.7477758354414 57.4 35.66937783907034 139.7477740389741 57.4 35.669380178193144 139.74778046532128 57.4 35.6693816351283 139.7477758354414 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fdb71826-48d4-45ac-9bd3-2a33d201840a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdb71826-48d4-45ac-9bd3-2a33d201840a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdb71826-48d4-45ac-9bd3-2a33d201840a">
											<gml:posList>35.66936528992983 139.74770778668923 61.117 35.669366635614146 139.74771149674868 61.117 35.66939547123284 139.74772514105825 61.117 35.6693985076962 139.74772350298974 61.117 35.66936528992983 139.74770778668923 61.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4fa16334-a734-4903-b6ae-a21ac10a6fcf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fa16334-a734-4903-b6ae-a21ac10a6fcf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fa16334-a734-4903-b6ae-a21ac10a6fcf">
											<gml:posList>35.66940371972075 139.7477010848359 57.4 35.669404663263265 139.74769700780783 57.4 35.66937319514631 139.7476826814593 57.4 35.66936528992983 139.74770778668923 57.4 35.6693985076962 139.74772350298974 57.4 35.66940371972075 139.7477010848359 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee1ec3b8-8474-4e3c-a130-ab396eb74abb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee1ec3b8-8474-4e3c-a130-ab396eb74abb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee1ec3b8-8474-4e3c-a130-ab396eb74abb">
											<gml:posList>35.6693985076962 139.74772350298974 61.117 35.66939547123284 139.74772514105825 61.117 35.66938063207744 139.74777227966024 61.117 35.66938197776762 139.7477760007676 61.117 35.6693985076962 139.74772350298974 61.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b6e860e-0169-43bb-9805-4bbcaf33c24d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b6e860e-0169-43bb-9805-4bbcaf33c24d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b6e860e-0169-43bb-9805-4bbcaf33c24d">
											<gml:posList>35.66945389228734 139.74797067839333 57.4 35.66945167029832 139.74796417458705 57.4 35.66933838136714 139.74790721992247 57.4 35.66933306519649 139.74790994293093 57.4 35.66945389228734 139.74797067839333 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-40850bf1-694d-42cd-bb6f-6af6f036e01b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40850bf1-694d-42cd-bb6f-6af6f036e01b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40850bf1-694d-42cd-bb6f-6af6f036e01b">
											<gml:posList>35.669408513302585 139.74769866061473 57.4 35.669404663263265 139.74769700780783 57.4 35.66940371972075 139.7477010848359 57.4 35.66940763265186 139.74770245037658 57.4 35.669408513302585 139.74769866061473 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-db2702b6-1406-4452-9b95-31da43213167">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db2702b6-1406-4452-9b95-31da43213167">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db2702b6-1406-4452-9b95-31da43213167">
											<gml:posList>35.669404663263265 139.74769700780783 57.4 35.669408513302585 139.74769866061473 57.4 35.66943173091525 139.74763283402447 57.4 35.66942958106496 139.74762639642904 57.4 35.669404663263265 139.74769700780783 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c107b6eb-6b94-42ca-92a8-78551b1c0812">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c107b6eb-6b94-42ca-92a8-78551b1c0812">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c107b6eb-6b94-42ca-92a8-78551b1c0812">
											<gml:posList>35.66938197776762 139.7477760007676 56.913 35.6693816351283 139.7477758354414 56.913 35.669380178193144 139.74778046532128 56.913 35.66936895435228 139.74781607894462 56.913 35.66933838136714 139.74790721992247 56.913 35.66945167029832 139.74796417458705 56.913 35.66954409953692 139.74768833125916 56.913 35.66943173091525 139.74763283402447 56.913 35.669408513302585 139.74769866061473 56.913 35.66940763265186 139.74770245037658 56.913 35.66940371972075 139.7477010848359 56.913 35.6693985076962 139.74772350298974 56.913 35.66938197776762 139.7477760007676 56.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b23c5e2-1d51-4da8-90cd-132219c1042d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b23c5e2-1d51-4da8-90cd-132219c1042d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b23c5e2-1d51-4da8-90cd-132219c1042d">
											<gml:posList>35.66942958106496 139.74762639642904 57.4 35.66943173091525 139.74763283402447 57.4 35.66954409953692 139.74768833125916 57.4 35.669549415686625 139.74768558613653 57.4 35.66942958106496 139.74762639642904 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2f212421-9d03-4b26-90eb-31f3b90e8c21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f212421-9d03-4b26-90eb-31f3b90e8c21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f212421-9d03-4b26-90eb-31f3b90e8c21">
											<gml:posList>35.669549415686625 139.74768558613653 57.4 35.66954409953692 139.74768833125916 57.4 35.66945167029832 139.74796417458705 57.4 35.66945389228734 139.74797067839333 57.4 35.669549415686625 139.74768558613653 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74e3b167-4073-46e1-a122-8a75bdc9e5fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74e3b167-4073-46e1-a122-8a75bdc9e5fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74e3b167-4073-46e1-a122-8a75bdc9e5fa">
											<gml:posList>35.669549415686625 139.74768558613653 6.407 35.66942958106496 139.74762639642904 6.407 35.66942958106496 139.74762639642904 57.4 35.669549415686625 139.74768558613653 57.4 35.669549415686625 139.74768558613653 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0870028-67c8-4c01-8018-5dec4bc10867">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0870028-67c8-4c01-8018-5dec4bc10867">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0870028-67c8-4c01-8018-5dec4bc10867">
											<gml:posList>35.66943173091525 139.74763283402447 57.4 35.66943173091525 139.74763283402447 56.913 35.66954409953692 139.74768833125916 56.913 35.66954409953692 139.74768833125916 57.4 35.66943173091525 139.74763283402447 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de138c7c-8501-42b7-9b0a-5811646fe1e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de138c7c-8501-42b7-9b0a-5811646fe1e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de138c7c-8501-42b7-9b0a-5811646fe1e0">
											<gml:posList>35.669404663263265 139.74769700780783 57.4 35.66942958106496 139.74762639642904 57.4 35.66942958106496 139.74762639642904 6.407 35.669404663263265 139.74769700780783 6.407 35.669404663263265 139.74769700780783 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49ae5a42-da3a-43de-a5f7-5b2808432c16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49ae5a42-da3a-43de-a5f7-5b2808432c16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49ae5a42-da3a-43de-a5f7-5b2808432c16">
											<gml:posList>35.669408513302585 139.74769866061473 57.4 35.669408513302585 139.74769866061473 56.913 35.66943173091525 139.74763283402447 56.913 35.66943173091525 139.74763283402447 57.4 35.669408513302585 139.74769866061473 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2cac0a3-e0f1-4b77-8c8e-8d34a73feac7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2cac0a3-e0f1-4b77-8c8e-8d34a73feac7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2cac0a3-e0f1-4b77-8c8e-8d34a73feac7">
											<gml:posList>35.669404663263265 139.74769700780783 6.407 35.66937319514631 139.7476826814593 6.407 35.66937319514631 139.7476826814593 57.4 35.669404663263265 139.74769700780783 57.4 35.669404663263265 139.74769700780783 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6b87d1e-9b12-4c4d-8b66-11f18d70cbf4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6b87d1e-9b12-4c4d-8b66-11f18d70cbf4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6b87d1e-9b12-4c4d-8b66-11f18d70cbf4">
											<gml:posList>35.66940763265186 139.74770245037658 57.4 35.66940763265186 139.74770245037658 56.913 35.669408513302585 139.74769866061473 56.913 35.669408513302585 139.74769866061473 57.4 35.66940763265186 139.74770245037658 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb7e50f9-0185-4c5c-9eac-3b6e15f0b5ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb7e50f9-0185-4c5c-9eac-3b6e15f0b5ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb7e50f9-0185-4c5c-9eac-3b6e15f0b5ba">
											<gml:posList>35.66940371972075 139.7477010848359 57.4 35.66940371972075 139.7477010848359 56.913 35.66940763265186 139.74770245037658 56.913 35.66940763265186 139.74770245037658 57.4 35.66940371972075 139.7477010848359 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37be7d6c-fbfe-4de3-8b4d-b43f70fe6041">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37be7d6c-fbfe-4de3-8b4d-b43f70fe6041">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37be7d6c-fbfe-4de3-8b4d-b43f70fe6041">
											<gml:posList>35.6693985076962 139.74772350298974 57.4 35.6693985076962 139.74772350298974 56.913 35.66940371972075 139.7477010848359 56.913 35.66940371972075 139.7477010848359 57.4 35.6693985076962 139.74772350298974 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31f9a7c1-f41c-44b0-956d-615f8420ca41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31f9a7c1-f41c-44b0-956d-615f8420ca41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31f9a7c1-f41c-44b0-956d-615f8420ca41">
											<gml:posList>35.66936528992983 139.74770778668923 61.117 35.6693985076962 139.74772350298974 61.117 35.6693985076962 139.74772350298974 57.4 35.66936528992983 139.74770778668923 57.4 35.66936528992983 139.74770778668923 61.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ecb02f9-af9b-4e5d-b622-fc21d927ce22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ecb02f9-af9b-4e5d-b622-fc21d927ce22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ecb02f9-af9b-4e5d-b622-fc21d927ce22">
											<gml:posList>35.669366635614146 139.74771149674868 61.117 35.669366635614146 139.74771149674868 60.723 35.66939547123284 139.74772514105825 60.723 35.66939547123284 139.74772514105825 61.117 35.669366635614146 139.74771149674868 61.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83ba87a1-54a1-4493-898c-d28a1e509897">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83ba87a1-54a1-4493-898c-d28a1e509897">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83ba87a1-54a1-4493-898c-d28a1e509897">
											<gml:posList>35.66934876000797 139.74776028444853 6.407 35.66934876000797 139.74776028444853 61.117 35.66936528992983 139.74770778668923 61.117 35.66936528992983 139.74770778668923 57.4 35.66937319514631 139.7476826814593 57.4 35.66937319514631 139.7476826814593 6.407 35.66934876000797 139.74776028444853 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bfe80768-28fe-44d1-982a-4c2ed6f8aab1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfe80768-28fe-44d1-982a-4c2ed6f8aab1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfe80768-28fe-44d1-982a-4c2ed6f8aab1">
											<gml:posList>35.669351796464 139.7477586353362 61.117 35.669351796464 139.7477586353362 60.723 35.669366635614146 139.74771149674868 60.723 35.669366635614146 139.74771149674868 61.117 35.669351796464 139.7477586353362 61.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de439511-9201-4009-aab8-c2637ae44f47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de439511-9201-4009-aab8-c2637ae44f47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de439511-9201-4009-aab8-c2637ae44f47">
											<gml:posList>35.66939547123284 139.74772514105825 61.117 35.66939547123284 139.74772514105825 60.723 35.66938063207744 139.74777227966024 60.723 35.66938063207744 139.74777227966024 61.117 35.66939547123284 139.74772514105825 61.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3434396-9d73-4345-bf15-4d8dcb9fbb6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3434396-9d73-4345-bf15-4d8dcb9fbb6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3434396-9d73-4345-bf15-4d8dcb9fbb6a">
											<gml:posList>35.66938197776762 139.7477760007676 61.117 35.66938197776762 139.7477760007676 56.913 35.6693985076962 139.74772350298974 56.913 35.6693985076962 139.74772350298974 57.4 35.6693985076962 139.74772350298974 61.117 35.66938197776762 139.7477760007676 61.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40c801fa-f6bc-4686-932b-845b6ceb9310">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40c801fa-f6bc-4686-932b-845b6ceb9310">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40c801fa-f6bc-4686-932b-845b6ceb9310">
											<gml:posList>35.66938063207744 139.74777227966024 61.117 35.66938063207744 139.74777227966024 60.723 35.669351796464 139.7477586353362 60.723 35.669351796464 139.7477586353362 61.117 35.66938063207744 139.74777227966024 61.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2acb2aab-eaff-4682-920a-18be96ad0bf7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2acb2aab-eaff-4682-920a-18be96ad0bf7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2acb2aab-eaff-4682-920a-18be96ad0bf7">
											<gml:posList>35.6693816351283 139.7477758354414 57.4 35.6693816351283 139.7477758354414 56.913 35.66938197776762 139.7477760007676 56.913 35.66938197776762 139.7477760007676 61.117 35.66934876000797 139.74776028444853 61.117 35.66934876000797 139.74776028444853 6.407 35.66937783907034 139.7477740389741 6.407 35.66937783907034 139.7477740389741 57.4 35.6693816351283 139.7477758354414 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e79d5021-43ec-4104-9c24-68bb0c4ec3a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e79d5021-43ec-4104-9c24-68bb0c4ec3a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e79d5021-43ec-4104-9c24-68bb0c4ec3a7">
											<gml:posList>35.669380178193144 139.74778046532128 57.4 35.669380178193144 139.74778046532128 56.913 35.6693816351283 139.7477758354414 56.913 35.6693816351283 139.7477758354414 57.4 35.669380178193144 139.74778046532128 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fbd02e7-d2c6-4519-88ee-dafb67581247">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fbd02e7-d2c6-4519-88ee-dafb67581247">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fbd02e7-d2c6-4519-88ee-dafb67581247">
											<gml:posList>35.66936517629881 139.74781424931814 57.4 35.66937783907034 139.7477740389741 57.4 35.66937783907034 139.7477740389741 6.407 35.66936517629881 139.74781424931814 6.407 35.66936517629881 139.74781424931814 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1fd13ae-7014-4d99-879e-156947dbde46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1fd13ae-7014-4d99-879e-156947dbde46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1fd13ae-7014-4d99-879e-156947dbde46">
											<gml:posList>35.66936895435228 139.74781607894462 57.4 35.66936895435228 139.74781607894462 56.913 35.669380178193144 139.74778046532128 56.913 35.669380178193144 139.74778046532128 57.4 35.66936895435228 139.74781607894462 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db2c8887-f1a9-46ba-821a-612156b022a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db2c8887-f1a9-46ba-821a-612156b022a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db2c8887-f1a9-46ba-821a-612156b022a0">
											<gml:posList>35.66954409953692 139.74768833125916 57.4 35.66954409953692 139.74768833125916 56.913 35.66945167029832 139.74796417458705 56.913 35.66945167029832 139.74796417458705 57.4 35.66954409953692 139.74768833125916 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a45b51ee-3721-4b3f-9b68-1bc8ddd8b82d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a45b51ee-3721-4b3f-9b68-1bc8ddd8b82d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a45b51ee-3721-4b3f-9b68-1bc8ddd8b82d">
											<gml:posList>35.66945389228734 139.74797067839333 6.407 35.669549415686625 139.74768558613653 6.407 35.669549415686625 139.74768558613653 57.4 35.66945389228734 139.74797067839333 57.4 35.66945389228734 139.74797067839333 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25eabdec-a315-4aa7-99e7-bbc431e5fb92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25eabdec-a315-4aa7-99e7-bbc431e5fb92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25eabdec-a315-4aa7-99e7-bbc431e5fb92">
											<gml:posList>35.66933838136714 139.74790721992247 57.4 35.66933838136714 139.74790721992247 56.913 35.66936895435228 139.74781607894462 56.913 35.66936895435228 139.74781607894462 57.4 35.66933838136714 139.74790721992247 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a5f25f2-314d-4c9d-869e-76b7b24f2bbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a5f25f2-314d-4c9d-869e-76b7b24f2bbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a5f25f2-314d-4c9d-869e-76b7b24f2bbc">
											<gml:posList>35.66936517629881 139.74781424931814 6.407 35.66933306519649 139.74790994293093 6.407 35.66933306519649 139.74790994293093 57.4 35.66936517629881 139.74781424931814 57.4 35.66936517629881 139.74781424931814 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-632bff9d-0fee-4057-9936-c0a4ae52ff75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-632bff9d-0fee-4057-9936-c0a4ae52ff75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-632bff9d-0fee-4057-9936-c0a4ae52ff75">
											<gml:posList>35.66945167029832 139.74796417458705 57.4 35.66945167029832 139.74796417458705 56.913 35.66933838136714 139.74790721992247 56.913 35.66933838136714 139.74790721992247 57.4 35.66945167029832 139.74796417458705 57.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55a33bd6-25be-465d-ad3f-353281abe92e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55a33bd6-25be-465d-ad3f-353281abe92e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55a33bd6-25be-465d-ad3f-353281abe92e">
											<gml:posList>35.66933306519649 139.74790994293093 6.407 35.66945389228734 139.74797067839333 6.407 35.66945389228734 139.74797067839333 57.4 35.66933306519649 139.74790994293093 57.4 35.66933306519649 139.74790994293093 6.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8802</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">442.1862</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>