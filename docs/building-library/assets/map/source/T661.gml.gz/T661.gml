<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c19500bc-d3a8-4e64-9730-0b3fda817eea">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">9.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668791690513146 139.7396548191685 0 35.6687636364281 139.73962734731333 0 35.66869197282791 139.7397375599507 0 35.66872011702546 139.7397650317148 0 35.668791690513146 139.7396548191685 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668791690513146 139.7396548191685 11.309 35.66872011702546 139.7397650317148 11.309 35.66869197282791 139.7397375599507 11.309 35.6687636364281 139.73962734731333 11.309 35.668791690513146 139.7396548191685 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668791690513146 139.7396548191685 11.309 35.6687636364281 139.73962734731333 11.309 35.6687636364281 139.73962734731333 21.09 35.668791690513146 139.7396548191685 21.09 35.668791690513146 139.7396548191685 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6687636364281 139.73962734731333 11.309 35.66869197282791 139.7397375599507 11.309 35.66869197282791 139.7397375599507 21.09 35.6687636364281 139.73962734731333 21.09 35.6687636364281 139.73962734731333 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869197282791 139.7397375599507 11.309 35.66872011702546 139.7397650317148 11.309 35.66872011702546 139.7397650317148 21.09 35.66869197282791 139.7397375599507 21.09 35.66869197282791 139.7397375599507 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872011702546 139.7397650317148 11.309 35.668791690513146 139.7396548191685 11.309 35.668791690513146 139.7396548191685 21.09 35.66872011702546 139.7397650317148 21.09 35.66872011702546 139.7397650317148 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668791690513146 139.7396548191685 21.09 35.6687636364281 139.73962734731333 21.09 35.66869197282791 139.7397375599507 21.09 35.66872011702546 139.7397650317148 21.09 35.668791690513146 139.7396548191685 21.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-df5106c3-3034-4d77-ba5c-17dabcb7c26a"/>
							<gml:surfaceMember xlink:href="#poly-d85daa39-2d43-4074-9a96-f15d8e9b262f"/>
							<gml:surfaceMember xlink:href="#poly-caff0b6e-68ff-4ec6-87fe-5a2308ab8d02"/>
							<gml:surfaceMember xlink:href="#poly-6eaa1862-d54f-46e2-bec8-5dd4b1fcdc26"/>
							<gml:surfaceMember xlink:href="#poly-282c5d41-38f5-4988-aaef-5f7bcc3d53e3"/>
							<gml:surfaceMember xlink:href="#poly-3ed85150-01de-4a53-85f9-01b3ee610215"/>
							<gml:surfaceMember xlink:href="#poly-9150245f-6364-4272-95d7-29ffab3c1a9e"/>
							<gml:surfaceMember xlink:href="#poly-faf185c4-dd66-4e97-af57-3fc39ff00f94"/>
							<gml:surfaceMember xlink:href="#poly-daae0bb1-a9f7-4ce3-8dfb-42eeb04e40c9"/>
							<gml:surfaceMember xlink:href="#poly-0b88bc85-62ba-472d-b85f-6813fc70cd2d"/>
							<gml:surfaceMember xlink:href="#poly-5a0abf7a-0cc5-4c14-9e73-bc38dc666c96"/>
							<gml:surfaceMember xlink:href="#poly-bb64d53b-87dd-40fa-9bb3-b780f9e49e69"/>
							<gml:surfaceMember xlink:href="#poly-4a37eeed-1c65-4005-a2f6-e46102269a21"/>
							<gml:surfaceMember xlink:href="#poly-3a9be911-40e5-4ea2-9528-696fcc96fb83"/>
							<gml:surfaceMember xlink:href="#poly-90ca635b-9984-4716-919e-181f2dd61672"/>
							<gml:surfaceMember xlink:href="#poly-5e611d8b-b00c-4ba7-8d7f-978f32f28685"/>
							<gml:surfaceMember xlink:href="#poly-fe6dcc25-2d56-4412-9ac9-a44aefa8f839"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c19500bc-d3a8-4e64-9730-0b3fda817eea_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5932fe7-bf64-4076-88ab-77b363627f27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66871856759731 139.73969665859437 20.434 35.668722988053524 139.73968986012306 20.434 35.66874693777088 139.7397133381138 20.433 35.66874249928591 139.73972013660685 20.433 35.66871856759731 139.73969665859437 20.434</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-496fd776-db50-4d98-8c9c-ee884983ba57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66877655933902 139.73967011351766 22.487 35.66875481059511 139.73964873170632 22.487 35.66875637712693 139.7396463439323 22.237 35.668778125871256 139.7396677257434 22.238 35.66877655933902 139.73967011351766 22.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23a5a565-dad3-4acf-b8fa-327dd58c3ce2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23a5a565-dad3-4acf-b8fa-327dd58c3ce2_0">
											<gml:posList>35.66875637712693 139.7396463439323 22.237 35.66875481059511 139.73964873170632 22.487 35.66875637712693 139.7396463439323 22.487 35.66875637712693 139.7396463439323 22.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4c06b8f-e35f-430f-b953-4cc2ec3f4a34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4c06b8f-e35f-430f-b953-4cc2ec3f4a34_0">
											<gml:posList>35.66875637712693 139.7396463439323 22.487 35.668778125871256 139.7396677257434 22.487 35.668778125871256 139.7396677257434 22.238 35.66875637712693 139.7396463439323 22.237 35.66875637712693 139.7396463439323 22.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54def647-2087-410b-ab25-444e55333a53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54def647-2087-410b-ab25-444e55333a53_0">
											<gml:posList>35.66877655933902 139.73967011351766 22.487 35.668778125871256 139.7396677257434 22.487 35.66875637712693 139.7396463439323 22.487 35.66875481059511 139.73964873170632 22.487 35.66877655933902 139.73967011351766 22.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fc83cd2-4617-4b88-a7fb-6de4e54c55ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fc83cd2-4617-4b88-a7fb-6de4e54c55ad_0">
											<gml:posList>35.66877655933902 139.73967011351766 22.487 35.668778125871256 139.7396677257434 22.238 35.668778125871256 139.7396677257434 22.487 35.66877655933902 139.73967011351766 22.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-516439ad-a0ab-412a-aaad-00b4b8d9d701">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-516439ad-a0ab-412a-aaad-00b4b8d9d701_0">
											<gml:posList>35.66871856759731 139.73969665859437 20.434 35.66871856759731 139.73969665859437 22.459 35.668722988053524 139.73968986012306 22.459 35.668722988053524 139.73968986012306 20.434 35.66871856759731 139.73969665859437 20.434</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d484648-811d-4a92-8d50-17f4cea8a67c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d484648-811d-4a92-8d50-17f4cea8a67c_0">
											<gml:posList>35.668722988053524 139.73968986012306 20.434 35.668722988053524 139.73968986012306 22.459 35.66874693777088 139.7397133381138 22.459 35.66874693777088 139.7397133381138 20.433 35.668722988053524 139.73968986012306 20.434</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7dcdab5f-973a-4de1-a8e6-f840e474bcd9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7dcdab5f-973a-4de1-a8e6-f840e474bcd9_0">
											<gml:posList>35.66874693777088 139.7397133381138 22.459 35.668722988053524 139.73968986012306 22.459 35.66871856759731 139.73969665859437 22.459 35.66874249928591 139.73972013660685 22.459 35.66874693777088 139.7397133381138 22.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3d0df55-387c-4ad4-8fb1-a4b27fd5bc13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3d0df55-387c-4ad4-8fb1-a4b27fd5bc13_0">
											<gml:posList>35.66874249928591 139.73972013660685 22.459 35.66871856759731 139.73969665859437 22.459 35.66871856759731 139.73969665859437 20.434 35.66874249928591 139.73972013660685 20.433 35.66874249928591 139.73972013660685 22.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f467cb8c-cd22-445b-b1cd-f217c81867f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f467cb8c-cd22-445b-b1cd-f217c81867f2_0">
											<gml:posList>35.66874249928591 139.73972013660685 20.433 35.66874693777088 139.7397133381138 20.433 35.66874693777088 139.7397133381138 22.459 35.66874249928591 139.73972013660685 22.459 35.66874249928591 139.73972013660685 20.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-df5106c3-3034-4d77-ba5c-17dabcb7c26a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df5106c3-3034-4d77-ba5c-17dabcb7c26a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df5106c3-3034-4d77-ba5c-17dabcb7c26a">
											<gml:posList>35.66879169051316 139.73965481916846 11.309 35.668720117025444 139.7397650317148 11.309 35.668691972827915 139.7397375599507 11.309 35.66876363642809 139.73962734731333 11.309 35.66879169051316 139.73965481916846 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d85daa39-2d43-4074-9a96-f15d8e9b262f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d85daa39-2d43-4074-9a96-f15d8e9b262f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d85daa39-2d43-4074-9a96-f15d8e9b262f">
											<gml:posList>35.66879169051316 139.73965481916846 20.433 35.66876363642809 139.73962734731333 20.433 35.66874770118099 139.7396518439486 22.993 35.6687757282881 139.73967940420667 22.993 35.66879169051316 139.73965481916846 20.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-caff0b6e-68ff-4ec6-87fe-5a2308ab8d02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-caff0b6e-68ff-4ec6-87fe-5a2308ab8d02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-caff0b6e-68ff-4ec6-87fe-5a2308ab8d02">
											<gml:posList>35.66874770118099 139.7396518439486 22.993 35.66874790115869 139.73965399769168 22.993 35.668773979814475 139.73967964926175 22.993 35.6687757282881 139.73967940420667 22.993 35.66874770118099 139.7396518439486 22.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6eaa1862-d54f-46e2-bec8-5dd4b1fcdc26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6eaa1862-d54f-46e2-bec8-5dd4b1fcdc26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6eaa1862-d54f-46e2-bec8-5dd4b1fcdc26">
											<gml:posList>35.668722988053524 139.73968986012306 22.993 35.66872473652719 139.7396896150684 22.993 35.66874790115869 139.73965399769168 22.993 35.66874770118099 139.7396518439486 22.993 35.668722988053524 139.73968986012306 22.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-282c5d41-38f5-4988-aaef-5f7bcc3d53e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-282c5d41-38f5-4988-aaef-5f7bcc3d53e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-282c5d41-38f5-4988-aaef-5f7bcc3d53e3">
											<gml:posList>35.668773979814475 139.73967964926175 22.655 35.66874790115869 139.73965399769168 22.655 35.66872473652719 139.7396896150684 22.655 35.66875085121322 139.73971524450852 22.655 35.668773979814475 139.73967964926175 22.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ed85150-01de-4a53-85f9-01b3ee610215">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ed85150-01de-4a53-85f9-01b3ee610215">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ed85150-01de-4a53-85f9-01b3ee610215">
											<gml:posList>35.6687757282881 139.73967940420667 22.993 35.668773979814475 139.73967964926175 22.993 35.66875085121322 139.73971524450852 22.993 35.66875106019491 139.73971738719533 22.993 35.6687757282881 139.73967940420667 22.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9150245f-6364-4272-95d7-29ffab3c1a9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9150245f-6364-4272-95d7-29ffab3c1a9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9150245f-6364-4272-95d7-29ffab3c1a9e">
											<gml:posList>35.66875106019491 139.73971738719533 22.993 35.66875085121322 139.73971524450852 22.993 35.66872473652719 139.7396896150684 22.993 35.668722988053524 139.73968986012306 22.993 35.66875106019491 139.73971738719533 22.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-faf185c4-dd66-4e97-af57-3fc39ff00f94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-faf185c4-dd66-4e97-af57-3fc39ff00f94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-faf185c4-dd66-4e97-af57-3fc39ff00f94">
											<gml:posList>35.66872302406547 139.73968980485085 20.434 35.668691972827915 139.7397375599507 20.433 35.668720117025444 139.7397650317148 20.433 35.66875106019491 139.73971738719533 20.433 35.66872302406547 139.73968980485085 20.434</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-daae0bb1-a9f7-4ce3-8dfb-42eeb04e40c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-daae0bb1-a9f7-4ce3-8dfb-42eeb04e40c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-daae0bb1-a9f7-4ce3-8dfb-42eeb04e40c9">
											<gml:posList>35.66872473652719 139.7396896150684 22.993 35.66872473652719 139.7396896150684 22.655 35.66874790115869 139.73965399769168 22.655 35.66874790115869 139.73965399769168 22.993 35.66872473652719 139.7396896150684 22.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b88bc85-62ba-472d-b85f-6813fc70cd2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b88bc85-62ba-472d-b85f-6813fc70cd2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b88bc85-62ba-472d-b85f-6813fc70cd2d">
											<gml:posList>35.668773979814475 139.73967964926175 22.993 35.668773979814475 139.73967964926175 22.655 35.66875085121322 139.73971524450852 22.655 35.66875085121322 139.73971524450852 22.993 35.668773979814475 139.73967964926175 22.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a0abf7a-0cc5-4c14-9e73-bc38dc666c96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a0abf7a-0cc5-4c14-9e73-bc38dc666c96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a0abf7a-0cc5-4c14-9e73-bc38dc666c96">
											<gml:posList>35.66879169051316 139.73965481916846 11.309 35.66876363642809 139.73962734731333 11.309 35.66876363642809 139.73962734731333 20.433 35.66879169051316 139.73965481916846 20.433 35.66879169051316 139.73965481916846 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb64d53b-87dd-40fa-9bb3-b780f9e49e69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb64d53b-87dd-40fa-9bb3-b780f9e49e69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb64d53b-87dd-40fa-9bb3-b780f9e49e69">
											<gml:posList>35.66874790115869 139.73965399769168 22.993 35.66874790115869 139.73965399769168 22.655 35.668773979814475 139.73967964926175 22.655 35.668773979814475 139.73967964926175 22.993 35.66874790115869 139.73965399769168 22.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a37eeed-1c65-4005-a2f6-e46102269a21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a37eeed-1c65-4005-a2f6-e46102269a21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a37eeed-1c65-4005-a2f6-e46102269a21">
											<gml:posList>35.66872302406547 139.73968980485085 20.434 35.668722988053524 139.73968986012306 22.993 35.66874770118099 139.7396518439486 22.993 35.66876363642809 139.73962734731333 20.433 35.66876363642809 139.73962734731333 11.309 35.668691972827915 139.7397375599507 11.309 35.668691972827915 139.7397375599507 20.433 35.66872302406547 139.73968980485085 20.434</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a9be911-40e5-4ea2-9528-696fcc96fb83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a9be911-40e5-4ea2-9528-696fcc96fb83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a9be911-40e5-4ea2-9528-696fcc96fb83">
											<gml:posList>35.66875085121322 139.73971524450852 22.993 35.66875085121322 139.73971524450852 22.655 35.66872473652719 139.7396896150684 22.655 35.66872473652719 139.7396896150684 22.993 35.66875085121322 139.73971524450852 22.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90ca635b-9984-4716-919e-181f2dd61672">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90ca635b-9984-4716-919e-181f2dd61672">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90ca635b-9984-4716-919e-181f2dd61672">
											<gml:posList>35.66875106019491 139.73971738719533 22.993 35.668722988053524 139.73968986012306 22.993 35.66872302406547 139.73968980485085 20.434 35.66875106019491 139.73971738719533 20.433 35.66875106019491 139.73971738719533 22.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e611d8b-b00c-4ba7-8d7f-978f32f28685">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e611d8b-b00c-4ba7-8d7f-978f32f28685">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e611d8b-b00c-4ba7-8d7f-978f32f28685">
											<gml:posList>35.66875106019491 139.73971738719533 20.433 35.668720117025444 139.7397650317148 20.433 35.668720117025444 139.7397650317148 11.309 35.66879169051316 139.73965481916846 11.309 35.66879169051316 139.73965481916846 20.433 35.6687757282881 139.73967940420667 22.993 35.66875106019491 139.73971738719533 22.993 35.66875106019491 139.73971738719533 20.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe6dcc25-2d56-4412-9ac9-a44aefa8f839">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe6dcc25-2d56-4412-9ac9-a44aefa8f839">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe6dcc25-2d56-4412-9ac9-a44aefa8f839">
											<gml:posList>35.668691972827915 139.7397375599507 11.309 35.668720117025444 139.7397650317148 11.309 35.668720117025444 139.7397650317148 20.433 35.668691972827915 139.7397375599507 20.433 35.668691972827915 139.7397375599507 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2553</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">50.8645</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>