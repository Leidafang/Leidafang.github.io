<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c225a60e-4950-4faf-a62c-a51eaf10b015">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">5.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66802695005726 139.7425773625042 0 35.66791738838908 139.7425179489993 0 35.66790560506085 139.7425506582643 0 35.667884233783475 139.74253908424856 0 35.66786039711072 139.7426050553368 0 35.667882760307926 139.74261718054026 0 35.66787313575496 139.74264392254142 0 35.66790199141014 139.74265946465033 0 35.66790612915692 139.74264808267492 0 35.667993327573654 139.74269537110075 0 35.66802939724887 139.74259525415042 0 35.668021912775906 139.74259117562409 0 35.66802695005726 139.7425773625042 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66802695005726 139.7425773625042 28.485 35.668021912775906 139.74259117562409 28.485 35.66802939724887 139.74259525415042 28.485 35.667993327573654 139.74269537110075 28.485 35.66790612915692 139.74264808267492 28.485 35.66790199141014 139.74265946465033 28.485 35.66787313575496 139.74264392254142 28.485 35.667882760307926 139.74261718054026 28.485 35.66786039711072 139.7426050553368 28.485 35.667884233783475 139.74253908424856 28.485 35.66790560506085 139.7425506582643 28.485 35.66791738838908 139.7425179489993 28.485 35.66802695005726 139.7425773625042 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66802695005726 139.7425773625042 28.485 35.66791738838908 139.7425179489993 28.485 35.66791738838908 139.7425179489993 34.37 35.66802695005726 139.7425773625042 34.37 35.66802695005726 139.7425773625042 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66791738838908 139.7425179489993 28.485 35.66790560506085 139.7425506582643 28.485 35.66790560506085 139.7425506582643 34.37 35.66791738838908 139.7425179489993 34.37 35.66791738838908 139.7425179489993 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66790560506085 139.7425506582643 28.485 35.667884233783475 139.74253908424856 28.485 35.667884233783475 139.74253908424856 34.37 35.66790560506085 139.7425506582643 34.37 35.66790560506085 139.7425506582643 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667884233783475 139.74253908424856 28.485 35.66786039711072 139.7426050553368 28.485 35.66786039711072 139.7426050553368 34.37 35.667884233783475 139.74253908424856 34.37 35.667884233783475 139.74253908424856 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66786039711072 139.7426050553368 28.485 35.667882760307926 139.74261718054026 28.485 35.667882760307926 139.74261718054026 34.37 35.66786039711072 139.7426050553368 34.37 35.66786039711072 139.7426050553368 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667882760307926 139.74261718054026 28.485 35.66787313575496 139.74264392254142 28.485 35.66787313575496 139.74264392254142 34.37 35.667882760307926 139.74261718054026 34.37 35.667882760307926 139.74261718054026 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66787313575496 139.74264392254142 28.485 35.66790199141014 139.74265946465033 28.485 35.66790199141014 139.74265946465033 34.37 35.66787313575496 139.74264392254142 34.37 35.66787313575496 139.74264392254142 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66790199141014 139.74265946465033 28.485 35.66790612915692 139.74264808267492 28.485 35.66790612915692 139.74264808267492 34.37 35.66790199141014 139.74265946465033 34.37 35.66790199141014 139.74265946465033 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66790612915692 139.74264808267492 28.485 35.667993327573654 139.74269537110075 28.485 35.667993327573654 139.74269537110075 34.37 35.66790612915692 139.74264808267492 34.37 35.66790612915692 139.74264808267492 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667993327573654 139.74269537110075 28.485 35.66802939724887 139.74259525415042 28.485 35.66802939724887 139.74259525415042 34.37 35.667993327573654 139.74269537110075 34.37 35.667993327573654 139.74269537110075 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66802939724887 139.74259525415042 28.485 35.668021912775906 139.74259117562409 28.485 35.668021912775906 139.74259117562409 34.37 35.66802939724887 139.74259525415042 34.37 35.66802939724887 139.74259525415042 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668021912775906 139.74259117562409 28.485 35.66802695005726 139.7425773625042 28.485 35.66802695005726 139.7425773625042 34.37 35.668021912775906 139.74259117562409 34.37 35.668021912775906 139.74259117562409 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66802695005726 139.7425773625042 34.37 35.66791738838908 139.7425179489993 34.37 35.66790560506085 139.7425506582643 34.37 35.667884233783475 139.74253908424856 34.37 35.66786039711072 139.7426050553368 34.37 35.667882760307926 139.74261718054026 34.37 35.66787313575496 139.74264392254142 34.37 35.66790199141014 139.74265946465033 34.37 35.66790612915692 139.74264808267492 34.37 35.667993327573654 139.74269537110075 34.37 35.66802939724887 139.74259525415042 34.37 35.668021912775906 139.74259117562409 34.37 35.66802695005726 139.7425773625042 34.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6c7b0543-05b5-481f-b793-0e9bd3e2bc43"/>
							<gml:surfaceMember xlink:href="#poly-9d800ed5-547b-48eb-b294-4f9566d58293"/>
							<gml:surfaceMember xlink:href="#poly-de9e36bc-738e-4448-8836-6dddd55ffe8e"/>
							<gml:surfaceMember xlink:href="#poly-c5fdadb4-ed18-4fbd-a3a4-076d4ea1208d"/>
							<gml:surfaceMember xlink:href="#poly-b11933ee-164e-44e1-9b9d-b557c1eb6b78"/>
							<gml:surfaceMember xlink:href="#poly-5b6c9b9a-af1f-4473-8a4d-de74d6b7982b"/>
							<gml:surfaceMember xlink:href="#poly-e2bd734f-8323-4736-81be-25fe5d658f90"/>
							<gml:surfaceMember xlink:href="#poly-9e119be2-70d6-4ac4-88d2-3692db815201"/>
							<gml:surfaceMember xlink:href="#poly-af8fec62-462b-4ed5-92a8-ac57f49fec03"/>
							<gml:surfaceMember xlink:href="#poly-70072124-27f8-4fa0-bd1d-09c392271836"/>
							<gml:surfaceMember xlink:href="#poly-bdeb3ac3-8658-4dcc-930e-690ca6460b22"/>
							<gml:surfaceMember xlink:href="#poly-26ea8e95-5eab-47d6-bb2f-6190660d507d"/>
							<gml:surfaceMember xlink:href="#poly-cea5dc17-1c70-4f20-822b-6990761730ef"/>
							<gml:surfaceMember xlink:href="#poly-3625c231-3fd7-49e0-9f78-e27dc1b611e5"/>
							<gml:surfaceMember xlink:href="#poly-1f58250e-2ce8-4b33-86a0-aecca6d99d49"/>
							<gml:surfaceMember xlink:href="#poly-9b38d807-dfb9-4771-bdd3-ff01bd29f241"/>
							<gml:surfaceMember xlink:href="#poly-65eccd6e-d3d8-4b2b-a4a1-7c87ad013e07"/>
							<gml:surfaceMember xlink:href="#poly-a00bd710-816d-4471-9b5f-e0789eb710b1"/>
							<gml:surfaceMember xlink:href="#poly-a98e9cf2-8dab-480f-9e04-4d853369824c"/>
							<gml:surfaceMember xlink:href="#poly-9ce063ac-4ce5-421b-9c67-c66e99e5855c"/>
							<gml:surfaceMember xlink:href="#poly-132784e9-461f-4e64-92c5-3906f05c6437"/>
							<gml:surfaceMember xlink:href="#poly-1122a96e-9b6f-4d3e-8ec9-c3276f1c1299"/>
							<gml:surfaceMember xlink:href="#poly-bdb331e9-6a6f-4f30-90c2-41e91d2d3b99"/>
							<gml:surfaceMember xlink:href="#poly-c3b96645-6ce7-4ebf-9998-988eb7ef32a9"/>
							<gml:surfaceMember xlink:href="#poly-01841d9c-fff2-46cf-9293-e4bd434cbe63"/>
							<gml:surfaceMember xlink:href="#poly-e68650b6-24af-4df1-9dc6-7f814a2add9d"/>
							<gml:surfaceMember xlink:href="#poly-26972416-a4af-4271-baf5-e26ccfb4fe0a"/>
							<gml:surfaceMember xlink:href="#poly-5b1e455f-0375-4f42-ac57-7b145260d398"/>
							<gml:surfaceMember xlink:href="#poly-52826459-a59a-4e49-8957-67b8285cb700"/>
							<gml:surfaceMember xlink:href="#poly-04b9bb2e-df88-4243-9c13-55378c7fe868"/>
							<gml:surfaceMember xlink:href="#poly-99bdfce2-322c-49a3-aa2d-9c1bc6eb3a41"/>
							<gml:surfaceMember xlink:href="#poly-ba060759-4cc6-4854-840a-dcaa7051c5ab"/>
							<gml:surfaceMember xlink:href="#poly-12c85ece-61d1-4bbc-b9b5-151755b6f411"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6c7b0543-05b5-481f-b793-0e9bd3e2bc43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c7b0543-05b5-481f-b793-0e9bd3e2bc43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c7b0543-05b5-481f-b793-0e9bd3e2bc43">
											<gml:posList>35.66788276030791 139.74261718054026 28.485 35.66786039711073 139.74260505533678 28.485 35.667884233783475 139.74253908424853 28.485 35.66790560506084 139.7425506582643 28.485 35.667917388389085 139.7425179489993 28.485 35.66802695005726 139.74257736250422 28.485 35.66802191277589 139.74259117562409 28.485 35.66802939724888 139.7425952541504 28.485 35.66799332757365 139.74269537110075 28.485 35.66790612915688 139.74264808267492 28.485 35.667901991410126 139.7426594646503 28.485 35.66787313575497 139.74264392254142 28.485 35.66788276030791 139.74261718054026 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d800ed5-547b-48eb-b294-4f9566d58293">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d800ed5-547b-48eb-b294-4f9566d58293">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d800ed5-547b-48eb-b294-4f9566d58293">
											<gml:posList>35.66786039711073 139.74260505533678 31.674 35.66788276030791 139.74261718054026 33.3 35.66790560506084 139.7425506582643 33.3 35.66786039711073 139.74260505533678 31.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-de9e36bc-738e-4448-8836-6dddd55ffe8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de9e36bc-738e-4448-8836-6dddd55ffe8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de9e36bc-738e-4448-8836-6dddd55ffe8e">
											<gml:posList>35.66790560506084 139.7425506582643 33.3 35.667884233783475 139.74253908424853 31.674 35.66786039711073 139.74260505533678 31.674 35.66790560506084 139.7425506582643 33.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c5fdadb4-ed18-4fbd-a3a4-076d4ea1208d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5fdadb4-ed18-4fbd-a3a4-076d4ea1208d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5fdadb4-ed18-4fbd-a3a4-076d4ea1208d">
											<gml:posList>35.66787313575497 139.74264392254142 33.3 35.667901991410126 139.7426594646503 33.3 35.66790612915688 139.74264808267492 33.3 35.667877255422916 139.7426324743143 33.3 35.66787313575497 139.74264392254142 33.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b11933ee-164e-44e1-9b9d-b557c1eb6b78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b11933ee-164e-44e1-9b9d-b557c1eb6b78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b11933ee-164e-44e1-9b9d-b557c1eb6b78">
											<gml:posList>35.667924077254895 139.74254275056288 34.447 35.667877255422916 139.7426324743143 33.3 35.6678948217291 139.74263053245463 34.447 35.667924077254895 139.74254275056288 34.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b6c9b9a-af1f-4473-8a4d-de74d6b7982b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b6c9b9a-af1f-4473-8a4d-de74d6b7982b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b6c9b9a-af1f-4473-8a4d-de74d6b7982b">
											<gml:posList>35.667924077254895 139.74254275056288 34.447 35.66788276030791 139.74261718054026 33.3 35.667877255422916 139.7426324743143 33.3 35.667924077254895 139.74254275056288 34.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2bd734f-8323-4736-81be-25fe5d658f90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2bd734f-8323-4736-81be-25fe5d658f90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2bd734f-8323-4736-81be-25fe5d658f90">
											<gml:posList>35.667924077254895 139.74254275056288 34.447 35.66790560506084 139.7425506582643 33.3 35.66788276030791 139.74261718054026 33.3 35.667924077254895 139.74254275056288 34.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e119be2-70d6-4ac4-88d2-3692db815201">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e119be2-70d6-4ac4-88d2-3692db815201">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e119be2-70d6-4ac4-88d2-3692db815201">
											<gml:posList>35.667924077254895 139.74254275056288 34.447 35.667917388389085 139.7425179489993 33.3 35.66790560506084 139.7425506582643 33.3 35.667924077254895 139.74254275056288 34.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af8fec62-462b-4ed5-92a8-ac57f49fec03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af8fec62-462b-4ed5-92a8-ac57f49fec03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af8fec62-462b-4ed5-92a8-ac57f49fec03">
											<gml:posList>35.6678948217291 139.74263053245463 34.447 35.66793291149339 139.74265144348357 37.945 35.66796448447789 139.74256487398628 37.945 35.6678948217291 139.74263053245463 34.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-70072124-27f8-4fa0-bd1d-09c392271836">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70072124-27f8-4fa0-bd1d-09c392271836">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70072124-27f8-4fa0-bd1d-09c392271836">
											<gml:posList>35.66796448447789 139.74256487398628 37.945 35.667924077254895 139.74254275056288 34.447 35.6678948217291 139.74263053245463 34.447 35.66796448447789 139.74256487398628 37.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bdeb3ac3-8658-4dcc-930e-690ca6460b22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdeb3ac3-8658-4dcc-930e-690ca6460b22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdeb3ac3-8658-4dcc-930e-690ca6460b22">
											<gml:posList>35.6678948217291 139.74263053245463 34.447 35.667877255422916 139.7426324743143 33.3 35.66790612915688 139.74264808267492 33.3 35.667985770977566 139.7426912705566 33.3 35.667976141148905 139.7426750991571 34.447 35.6678948217291 139.74263053245463 34.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26ea8e95-5eab-47d6-bb2f-6190660d507d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26ea8e95-5eab-47d6-bb2f-6190660d507d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26ea8e95-5eab-47d6-bb2f-6190660d507d">
											<gml:posList>35.66800670420486 139.74258798951462 34.447 35.667917388389085 139.7425179489993 33.3 35.667924077254895 139.74254275056288 34.447 35.66800670420486 139.74258798951462 34.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cea5dc17-1c70-4f20-822b-6990761730ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cea5dc17-1c70-4f20-822b-6990761730ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cea5dc17-1c70-4f20-822b-6990761730ef">
											<gml:posList>35.66793291149339 139.74265144348357 37.945 35.667976141148905 139.7426750991571 34.447 35.66800670420486 139.74258798951462 34.447 35.66793291149339 139.74265144348357 37.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3625c231-3fd7-49e0-9f78-e27dc1b611e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3625c231-3fd7-49e0-9f78-e27dc1b611e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3625c231-3fd7-49e0-9f78-e27dc1b611e5">
											<gml:posList>35.66793291149339 139.74265144348357 37.945 35.66800670420486 139.74258798951462 34.447 35.66796448447789 139.74256487398628 37.945 35.66793291149339 139.74265144348357 37.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f58250e-2ce8-4b33-86a0-aecca6d99d49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f58250e-2ce8-4b33-86a0-aecca6d99d49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f58250e-2ce8-4b33-86a0-aecca6d99d49">
											<gml:posList>35.66800670420486 139.74258798951462 34.447 35.66802695005726 139.74257736250422 33.3 35.667917388389085 139.7425179489993 33.3 35.66800670420486 139.74258798951462 34.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b38d807-dfb9-4771-bdd3-ff01bd29f241">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b38d807-dfb9-4771-bdd3-ff01bd29f241">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b38d807-dfb9-4771-bdd3-ff01bd29f241">
											<gml:posList>35.667976141148905 139.7426750991571 34.447 35.667985770977566 139.7426912705566 33.3 35.66802191277589 139.74259117562409 33.3 35.667976141148905 139.7426750991571 34.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65eccd6e-d3d8-4b2b-a4a1-7c87ad013e07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65eccd6e-d3d8-4b2b-a4a1-7c87ad013e07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65eccd6e-d3d8-4b2b-a4a1-7c87ad013e07">
											<gml:posList>35.667976141148905 139.7426750991571 34.447 35.66802191277589 139.74259117562409 33.3 35.66802695005726 139.74257736250422 33.3 35.667976141148905 139.7426750991571 34.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a00bd710-816d-4471-9b5f-e0789eb710b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a00bd710-816d-4471-9b5f-e0789eb710b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a00bd710-816d-4471-9b5f-e0789eb710b1">
											<gml:posList>35.667976141148905 139.7426750991571 34.447 35.66802695005726 139.74257736250422 33.3 35.66800670420486 139.74258798951462 34.447 35.667976141148905 139.7426750991571 34.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a98e9cf2-8dab-480f-9e04-4d853369824c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a98e9cf2-8dab-480f-9e04-4d853369824c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a98e9cf2-8dab-480f-9e04-4d853369824c">
											<gml:posList>35.66799332757365 139.74269537110075 33.3 35.66802939724888 139.7425952541504 33.3 35.66802191277589 139.74259117562409 33.3 35.667985770977566 139.7426912705566 33.3 35.66799332757365 139.74269537110075 33.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ce063ac-4ce5-421b-9c67-c66e99e5855c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ce063ac-4ce5-421b-9c67-c66e99e5855c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ce063ac-4ce5-421b-9c67-c66e99e5855c">
											<gml:posList>35.667917388389085 139.7425179489993 28.485 35.66790560506084 139.7425506582643 28.485 35.66790560506084 139.7425506582643 33.3 35.667917388389085 139.7425179489993 33.3 35.667917388389085 139.7425179489993 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-132784e9-461f-4e64-92c5-3906f05c6437">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-132784e9-461f-4e64-92c5-3906f05c6437">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-132784e9-461f-4e64-92c5-3906f05c6437">
											<gml:posList>35.66790560506084 139.7425506582643 28.485 35.667884233783475 139.74253908424853 28.485 35.667884233783475 139.74253908424853 31.674 35.66790560506084 139.7425506582643 33.3 35.66790560506084 139.7425506582643 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1122a96e-9b6f-4d3e-8ec9-c3276f1c1299">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1122a96e-9b6f-4d3e-8ec9-c3276f1c1299">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1122a96e-9b6f-4d3e-8ec9-c3276f1c1299">
											<gml:posList>35.66802695005726 139.74257736250422 28.485 35.667917388389085 139.7425179489993 28.485 35.667917388389085 139.7425179489993 33.3 35.66802695005726 139.74257736250422 33.3 35.66802695005726 139.74257736250422 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bdb331e9-6a6f-4f30-90c2-41e91d2d3b99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdb331e9-6a6f-4f30-90c2-41e91d2d3b99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdb331e9-6a6f-4f30-90c2-41e91d2d3b99">
											<gml:posList>35.66800670420486 139.74258798951462 34.447 35.667924077254895 139.74254275056288 34.447 35.66796448447789 139.74256487398628 37.945 35.66800670420486 139.74258798951462 34.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3b96645-6ce7-4ebf-9998-988eb7ef32a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3b96645-6ce7-4ebf-9998-988eb7ef32a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3b96645-6ce7-4ebf-9998-988eb7ef32a9">
											<gml:posList>35.667884233783475 139.74253908424853 28.485 35.66786039711073 139.74260505533678 28.485 35.66786039711073 139.74260505533678 31.674 35.667884233783475 139.74253908424853 31.674 35.667884233783475 139.74253908424853 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01841d9c-fff2-46cf-9293-e4bd434cbe63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01841d9c-fff2-46cf-9293-e4bd434cbe63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01841d9c-fff2-46cf-9293-e4bd434cbe63">
											<gml:posList>35.66802191277589 139.74259117562409 28.485 35.66802695005726 139.74257736250422 28.485 35.66802695005726 139.74257736250422 33.3 35.66802191277589 139.74259117562409 33.3 35.66802191277589 139.74259117562409 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e68650b6-24af-4df1-9dc6-7f814a2add9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e68650b6-24af-4df1-9dc6-7f814a2add9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e68650b6-24af-4df1-9dc6-7f814a2add9d">
											<gml:posList>35.66802939724888 139.7425952541504 28.485 35.66802191277589 139.74259117562409 28.485 35.66802191277589 139.74259117562409 33.3 35.66802939724888 139.7425952541504 33.3 35.66802939724888 139.7425952541504 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26972416-a4af-4271-baf5-e26ccfb4fe0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26972416-a4af-4271-baf5-e26ccfb4fe0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26972416-a4af-4271-baf5-e26ccfb4fe0a">
											<gml:posList>35.66786039711073 139.74260505533678 28.485 35.66788276030791 139.74261718054026 28.485 35.66788276030791 139.74261718054026 33.3 35.66786039711073 139.74260505533678 31.674 35.66786039711073 139.74260505533678 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b1e455f-0375-4f42-ac57-7b145260d398">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b1e455f-0375-4f42-ac57-7b145260d398">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b1e455f-0375-4f42-ac57-7b145260d398">
											<gml:posList>35.66788276030791 139.74261718054026 28.485 35.66787313575497 139.74264392254142 28.485 35.66787313575497 139.74264392254142 33.3 35.667877255422916 139.7426324743143 33.3 35.66788276030791 139.74261718054026 33.3 35.66788276030791 139.74261718054026 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52826459-a59a-4e49-8957-67b8285cb700">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52826459-a59a-4e49-8957-67b8285cb700">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52826459-a59a-4e49-8957-67b8285cb700">
											<gml:posList>35.66799332757365 139.74269537110075 28.485 35.66802939724888 139.7425952541504 28.485 35.66802939724888 139.7425952541504 33.3 35.66799332757365 139.74269537110075 33.3 35.66799332757365 139.74269537110075 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04b9bb2e-df88-4243-9c13-55378c7fe868">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04b9bb2e-df88-4243-9c13-55378c7fe868">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04b9bb2e-df88-4243-9c13-55378c7fe868">
											<gml:posList>35.66787313575497 139.74264392254142 28.485 35.667901991410126 139.7426594646503 28.485 35.667901991410126 139.7426594646503 33.3 35.66787313575497 139.74264392254142 33.3 35.66787313575497 139.74264392254142 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99bdfce2-322c-49a3-aa2d-9c1bc6eb3a41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99bdfce2-322c-49a3-aa2d-9c1bc6eb3a41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99bdfce2-322c-49a3-aa2d-9c1bc6eb3a41">
											<gml:posList>35.66793291149339 139.74265144348357 37.945 35.6678948217291 139.74263053245463 34.447 35.667976141148905 139.7426750991571 34.447 35.66793291149339 139.74265144348357 37.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba060759-4cc6-4854-840a-dcaa7051c5ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba060759-4cc6-4854-840a-dcaa7051c5ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba060759-4cc6-4854-840a-dcaa7051c5ab">
											<gml:posList>35.667901991410126 139.7426594646503 28.485 35.66790612915688 139.74264808267492 28.485 35.66790612915688 139.74264808267492 33.3 35.667901991410126 139.7426594646503 33.3 35.667901991410126 139.7426594646503 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-12c85ece-61d1-4bbc-b9b5-151755b6f411">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12c85ece-61d1-4bbc-b9b5-151755b6f411">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12c85ece-61d1-4bbc-b9b5-151755b6f411">
											<gml:posList>35.66790612915688 139.74264808267492 28.485 35.66799332757365 139.74269537110075 28.485 35.66799332757365 139.74269537110075 33.3 35.667985770977566 139.7426912705566 33.3 35.66790612915688 139.74264808267492 33.3 35.66790612915688 139.74264808267492 28.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1533</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">179.60285</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>