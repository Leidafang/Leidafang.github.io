<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c2a3898f-46d2-4ccc-a4e5-309117e3c2c3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">27.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66882937933551 139.74906346588517 0 35.66887175884776 139.74908485068687 0 35.668873288553655 139.74908109342167 0 35.66888681847494 139.74904289299442 0 35.6689041403083 139.74905210928858 0 35.66891345111996 139.7490258209293 0 35.66889442496315 139.74901556810272 0 35.66891610564372 139.74895501290283 0 35.66879356449241 139.7488915166569 0 35.668773684576095 139.74894919791615 0 35.66885456696133 139.74899086686437 0 35.66882937933551 139.74906346588517 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882937933551 139.74906346588517 5.56 35.66885456696133 139.74899086686437 5.56 35.668773684576095 139.74894919791615 5.56 35.66879356449241 139.7488915166569 5.56 35.66891610564372 139.74895501290283 5.56 35.66889442496315 139.74901556810272 5.56 35.66891345111996 139.7490258209293 5.56 35.6689041403083 139.74905210928858 5.56 35.66888681847494 139.74904289299442 5.56 35.668873288553655 139.74908109342167 5.56 35.66887175884776 139.74908485068687 5.56 35.66882937933551 139.74906346588517 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882937933551 139.74906346588517 5.56 35.66887175884776 139.74908485068687 5.56 35.66887175884776 139.74908485068687 31.46 35.66882937933551 139.74906346588517 31.46 35.66882937933551 139.74906346588517 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887175884776 139.74908485068687 5.56 35.668873288553655 139.74908109342167 5.56 35.668873288553655 139.74908109342167 31.46 35.66887175884776 139.74908485068687 31.46 35.66887175884776 139.74908485068687 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668873288553655 139.74908109342167 5.56 35.66888681847494 139.74904289299442 5.56 35.66888681847494 139.74904289299442 31.46 35.668873288553655 139.74908109342167 31.46 35.668873288553655 139.74908109342167 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66888681847494 139.74904289299442 5.56 35.6689041403083 139.74905210928858 5.56 35.6689041403083 139.74905210928858 31.46 35.66888681847494 139.74904289299442 31.46 35.66888681847494 139.74904289299442 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6689041403083 139.74905210928858 5.56 35.66891345111996 139.7490258209293 5.56 35.66891345111996 139.7490258209293 31.46 35.6689041403083 139.74905210928858 31.46 35.6689041403083 139.74905210928858 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66891345111996 139.7490258209293 5.56 35.66889442496315 139.74901556810272 5.56 35.66889442496315 139.74901556810272 31.46 35.66891345111996 139.7490258209293 31.46 35.66891345111996 139.7490258209293 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66889442496315 139.74901556810272 5.56 35.66891610564372 139.74895501290283 5.56 35.66891610564372 139.74895501290283 31.46 35.66889442496315 139.74901556810272 31.46 35.66889442496315 139.74901556810272 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66891610564372 139.74895501290283 5.56 35.66879356449241 139.7488915166569 5.56 35.66879356449241 139.7488915166569 31.46 35.66891610564372 139.74895501290283 31.46 35.66891610564372 139.74895501290283 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879356449241 139.7488915166569 5.56 35.668773684576095 139.74894919791615 5.56 35.668773684576095 139.74894919791615 31.46 35.66879356449241 139.7488915166569 31.46 35.66879356449241 139.7488915166569 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668773684576095 139.74894919791615 5.56 35.66885456696133 139.74899086686437 5.56 35.66885456696133 139.74899086686437 31.46 35.668773684576095 139.74894919791615 31.46 35.668773684576095 139.74894919791615 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66885456696133 139.74899086686437 5.56 35.66882937933551 139.74906346588517 5.56 35.66882937933551 139.74906346588517 31.46 35.66885456696133 139.74899086686437 31.46 35.66885456696133 139.74899086686437 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882937933551 139.74906346588517 31.46 35.66887175884776 139.74908485068687 31.46 35.668873288553655 139.74908109342167 31.46 35.66888681847494 139.74904289299442 31.46 35.6689041403083 139.74905210928858 31.46 35.66891345111996 139.7490258209293 31.46 35.66889442496315 139.74901556810272 31.46 35.66891610564372 139.74895501290283 31.46 35.66879356449241 139.7488915166569 31.46 35.668773684576095 139.74894919791615 31.46 35.66885456696133 139.74899086686437 31.46 35.66882937933551 139.74906346588517 31.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-447bc2e4-2603-45b8-843d-c85da2f2e18d"/>
							<gml:surfaceMember xlink:href="#poly-267f6b2f-2ba1-4d63-9e5b-e0ee5fa294cc"/>
							<gml:surfaceMember xlink:href="#poly-c8eb1764-a809-4588-b130-4dc6f24a87f0"/>
							<gml:surfaceMember xlink:href="#poly-449f90c9-0a38-4552-915a-6146b8363964"/>
							<gml:surfaceMember xlink:href="#poly-d252b6c0-961a-4a69-a9f6-aafd3fbfeb7a"/>
							<gml:surfaceMember xlink:href="#poly-3a5b9cb1-29a9-428b-9e73-b0e9e520b43a"/>
							<gml:surfaceMember xlink:href="#poly-e87478f6-446d-4a5a-9a15-c88e6465f554"/>
							<gml:surfaceMember xlink:href="#poly-b6fdfd53-3a0f-42f1-bc44-730576f7ca69"/>
							<gml:surfaceMember xlink:href="#poly-5306bbd1-9923-4428-90ae-582b4349c323"/>
							<gml:surfaceMember xlink:href="#poly-51b44dae-480b-4ded-be32-a4c271cac158"/>
							<gml:surfaceMember xlink:href="#poly-0cdb8785-b9e1-4369-8b6f-9f06df6206d6"/>
							<gml:surfaceMember xlink:href="#poly-ca1a20ff-dc23-4921-9acb-8f8dd11b87b3"/>
							<gml:surfaceMember xlink:href="#poly-87558d5a-aaf0-4674-ac23-ccfc23980ea9"/>
							<gml:surfaceMember xlink:href="#poly-0d75f1cd-457a-451c-ba47-dcd75a2fcdea"/>
							<gml:surfaceMember xlink:href="#poly-1a732075-b44f-4458-9dda-45dd16d054fb"/>
							<gml:surfaceMember xlink:href="#poly-5ae79903-9e1a-4561-a425-de2fbb9adf03"/>
							<gml:surfaceMember xlink:href="#poly-51250f4a-e310-4598-9b45-f24ef337a2cd"/>
							<gml:surfaceMember xlink:href="#poly-4a6237f9-af02-4baf-8aee-a2de61636580"/>
							<gml:surfaceMember xlink:href="#poly-29607ac7-4711-47a2-96dd-26d1d42c657c"/>
							<gml:surfaceMember xlink:href="#poly-490f66ea-52ae-4ec8-9ee6-dc7a0eb3d707"/>
							<gml:surfaceMember xlink:href="#poly-5b931239-7050-473c-8c14-625bea93dfee"/>
							<gml:surfaceMember xlink:href="#poly-48891c92-61db-4b51-8c47-b6885868ca5c"/>
							<gml:surfaceMember xlink:href="#poly-b023e53c-2dce-4d13-a364-a71dfaa836a1"/>
							<gml:surfaceMember xlink:href="#poly-c3f88d25-b3cf-42aa-8ff3-33bb32326cd8"/>
							<gml:surfaceMember xlink:href="#poly-ceb46c04-5671-41ea-bdf7-5737586fdf52"/>
							<gml:surfaceMember xlink:href="#poly-a53e198b-ae82-49aa-b354-15a295eabbce"/>
							<gml:surfaceMember xlink:href="#poly-755bd1b3-c015-4ba4-af6a-386023e25156"/>
							<gml:surfaceMember xlink:href="#poly-ffca727d-f3c1-47a4-89b0-966e21976b50"/>
							<gml:surfaceMember xlink:href="#poly-3c637ad2-d400-4012-ac7b-d3f2e64b70d7"/>
							<gml:surfaceMember xlink:href="#poly-0ffdb1a9-9f49-4ddd-a77f-9d22e8f612fb"/>
							<gml:surfaceMember xlink:href="#poly-e6be8632-5ba6-4cd2-a933-3334038538a5"/>
							<gml:surfaceMember xlink:href="#poly-52110d34-8858-4051-afba-f4c839c0a62c"/>
							<gml:surfaceMember xlink:href="#poly-d3d42640-a938-4bf0-bb45-2dcf6871fe06"/>
							<gml:surfaceMember xlink:href="#poly-031f3407-4646-4ee1-99f4-8f533e92d2da"/>
							<gml:surfaceMember xlink:href="#poly-251cbc20-3847-4a3b-bbbe-620abd908ec0"/>
							<gml:surfaceMember xlink:href="#poly-91660a00-023f-4af4-92d6-6dc46e7b8d5c"/>
							<gml:surfaceMember xlink:href="#poly-bec229dd-7048-4287-bee6-f4d9788e3378"/>
							<gml:surfaceMember xlink:href="#poly-8979750c-7ba3-4ad6-ad65-81500eeadab5"/>
							<gml:surfaceMember xlink:href="#poly-268d484e-f3ec-4271-b9a7-7cbbca22b89e"/>
							<gml:surfaceMember xlink:href="#poly-7a3f0953-0a52-4004-a7ed-c6aba1ccb4dc"/>
							<gml:surfaceMember xlink:href="#poly-3aa0b958-4437-4231-b011-d4f705cd4f44"/>
							<gml:surfaceMember xlink:href="#poly-4cd68838-3f1a-4537-bed7-d5a09ded0a7e"/>
							<gml:surfaceMember xlink:href="#poly-da2e32b6-e3c3-4ef0-a4e2-34cc6e9757e2"/>
							<gml:surfaceMember xlink:href="#poly-85a2af2c-f3a0-45b6-83d6-cb36a831210a"/>
							<gml:surfaceMember xlink:href="#poly-3c961e22-5119-456e-a074-e4f277d901e8"/>
							<gml:surfaceMember xlink:href="#poly-5dc97209-f417-424e-aaa1-271e2c3b1390"/>
							<gml:surfaceMember xlink:href="#poly-7499bb97-6138-4c71-9d01-f8d4db78172a"/>
							<gml:surfaceMember xlink:href="#poly-528c5fd3-9975-4ecb-a8c8-524e625a9a5a"/>
							<gml:surfaceMember xlink:href="#poly-f45ff217-c984-4194-bb90-25140cf51573"/>
							<gml:surfaceMember xlink:href="#poly-117e6b4e-8004-4527-be37-8591e0bad8fd"/>
							<gml:surfaceMember xlink:href="#poly-41f59196-0531-4031-9501-33d0028ac6c1"/>
							<gml:surfaceMember xlink:href="#poly-f2ae1ca0-4d0f-4718-b69b-e4c5c15d8342"/>
							<gml:surfaceMember xlink:href="#poly-29f7f130-a9dd-419b-920d-13f46a4ef909"/>
							<gml:surfaceMember xlink:href="#poly-7f2c4fdd-de31-4f37-b8b9-302a2b70870b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c2a3898f-46d2-4ccc-a4e5-309117e3c2c3_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a61b7a8-940a-4afa-bf06-f8f7e2f2a507">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668878416317504 139.74895086611042 31.358 35.66886930390154 139.74897726471866 31.358 35.66885264948833 139.74896863318307 31.358 35.668861761910186 139.74894224562533 31.358 35.668878416317504 139.74895086611042 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-064161a7-9429-4585-9684-13b2d961b008">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-064161a7-9429-4585-9684-13b2d961b008_0">
											<gml:posList>35.668861761910186 139.74894224562533 34.307 35.668861761910186 139.74894224562533 31.358 35.66885264948833 139.74896863318307 31.358 35.66885264948833 139.74896863318307 34.307 35.668861761910186 139.74894224562533 34.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6642b16c-d822-40c9-952d-c6d50099ba50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6642b16c-d822-40c9-952d-c6d50099ba50_0">
											<gml:posList>35.66885264948833 139.74896863318307 34.307 35.66885264948833 139.74896863318307 31.358 35.66886930390154 139.74897726471866 31.358 35.66886930390154 139.74897726471866 34.307 35.66885264948833 139.74896863318307 34.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40a8cc18-2104-4f8c-9d77-283fd8af54f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40a8cc18-2104-4f8c-9d77-283fd8af54f6_0">
											<gml:posList>35.668861761910186 139.74894224562533 34.307 35.66885264948833 139.74896863318307 34.307 35.66886930390154 139.74897726471866 34.307 35.668878416317504 139.74895086611042 34.307 35.668861761910186 139.74894224562533 34.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d8e069d-1aff-48fd-9391-1104fb69e855">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d8e069d-1aff-48fd-9391-1104fb69e855_0">
											<gml:posList>35.668878416317504 139.74895086611042 34.307 35.668878416317504 139.74895086611042 31.358 35.668861761910186 139.74894224562533 31.358 35.668861761910186 139.74894224562533 34.307 35.668878416317504 139.74895086611042 34.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-140a3fb2-b957-421d-ac72-1c6d49690832">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-140a3fb2-b957-421d-ac72-1c6d49690832_0">
											<gml:posList>35.66886930390154 139.74897726471866 34.307 35.66886930390154 139.74897726471866 31.358 35.668878416317504 139.74895086611042 31.358 35.668878416317504 139.74895086611042 34.307 35.66886930390154 139.74897726471866 34.307</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c2a3898f-46d2-4ccc-a4e5-309117e3c2c3_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d934ee47-5d88-4690-8891-34e34e80389e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66885484378718 139.74898715510037 31.358 35.66881781160338 139.7489689128512 31.358 35.66883319224659 139.7489220503824 31.358 35.668842966510454 139.74892686721577 31.358 35.66882936678363 139.74896830420678 31.358 35.668856615700015 139.74898174067172 31.358 35.66885484378718 139.74898715510037 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9fda8cc-8a31-4994-a405-e57fa78658eb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884211444587 139.749035859472 31.358 35.66886048317699 139.748982576103 31.358 35.668864937575314 139.74898488004177 31.358 35.66886096158538 139.7489964163016 31.358 35.66886501923247 139.74899851078348 31.358 35.668850626497296 139.74904026894285 31.358 35.66884211444587 139.749035859472 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7698229a-9d9c-49fe-bb87-ac682d45faab">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887460769505 139.74899544094177 31.358 35.66889549126157 139.7490065202618 31.358 35.66889339517061 139.74901238792165 31.358 35.668892657506895 139.74901447640187 31.358 35.66887973599388 139.7490075751605 31.358 35.6688777029216 139.7490133322924 31.358 35.66886967780387 139.74900919846212 31.358 35.66887460769505 139.74899544094177 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a647cbf-a100-4e72-b5b5-ffaa7481bab8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890062809747 139.7490308493217 36.904 35.668896966864494 139.7490413579703 36.904 35.66887963612483 139.74903229633338 36.904 35.66888329736475 139.7490217987327 36.904 35.66890062809747 139.7490308493217 36.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-644879ef-06d5-4f9d-8620-0a5adbae2ea7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668894316651446 139.74901535834155 31.7 35.668892657506895 139.74901447640187 31.7 35.66889339517061 139.74901238792165 31.7 35.66889549126157 139.7490065202618 31.7 35.66889715942765 139.74900741323793 31.7 35.668894316651446 139.74901535834155 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4d12ae4-a835-450a-8499-c85ded4abde9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4d12ae4-a835-450a-8499-c85ded4abde9_0">
											<gml:posList>35.668856615700015 139.74898174067172 32.398 35.66885484378718 139.74898715510037 32.398 35.66885484378718 139.74898715510037 31.358 35.668856615700015 139.74898174067172 31.358 35.668856615700015 139.74898174067172 32.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e379f545-07a4-40fa-bd94-5c1ae4dd58f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e379f545-07a4-40fa-bd94-5c1ae4dd58f6_0">
											<gml:posList>35.66889339517061 139.74901238792165 31.7 35.668892657506895 139.74901447640187 31.7 35.668892657506895 139.74901447640187 31.358 35.66889339517061 139.74901238792165 31.358 35.66889339517061 139.74901238792165 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40963171-a384-44d5-a30c-b68355e24977">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40963171-a384-44d5-a30c-b68355e24977_0">
											<gml:posList>35.668842966510454 139.74892686721577 31.358 35.66883319224659 139.7489220503824 31.358 35.66883319224659 139.7489220503824 32.398 35.668842966510454 139.74892686721577 32.398 35.668842966510454 139.74892686721577 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-750a2f53-fc08-4175-a168-4b62f9d331eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-750a2f53-fc08-4175-a168-4b62f9d331eb_0">
											<gml:posList>35.66883319224659 139.7489220503824 31.358 35.66881781160338 139.7489689128512 31.358 35.66881781160338 139.7489689128512 32.398 35.66883319224659 139.7489220503824 32.398 35.66883319224659 139.7489220503824 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cab354ca-4d44-4709-bde4-e8e87a90beac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cab354ca-4d44-4709-bde4-e8e87a90beac_0">
											<gml:posList>35.668842966510454 139.74892686721577 31.358 35.668842966510454 139.74892686721577 32.398 35.66882936678363 139.74896830420678 32.398 35.66882936678363 139.74896830420678 31.358 35.668842966510454 139.74892686721577 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-597fc72e-f1bf-435b-bd68-96ac8bfe11cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-597fc72e-f1bf-435b-bd68-96ac8bfe11cf_0">
											<gml:posList>35.66882936678363 139.74896830420678 32.398 35.668842966510454 139.74892686721577 32.398 35.66883319224659 139.7489220503824 32.398 35.66881781160338 139.7489689128512 32.398 35.66885484378718 139.74898715510037 32.398 35.668856615700015 139.74898174067172 32.398 35.66882936678363 139.74896830420678 32.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c22431f-9073-497f-91de-835694db3b64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c22431f-9073-497f-91de-835694db3b64_0">
											<gml:posList>35.668856615700015 139.74898174067172 31.358 35.66882936678363 139.74896830420678 31.358 35.66882936678363 139.74896830420678 32.398 35.668856615700015 139.74898174067172 32.398 35.668856615700015 139.74898174067172 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5c1039f-750c-4f51-b0d3-877e3f98a277">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5c1039f-750c-4f51-b0d3-877e3f98a277_0">
											<gml:posList>35.66881781160338 139.7489689128512 31.358 35.66885484378718 139.74898715510037 31.358 35.66885484378718 139.74898715510037 32.398 35.66881781160338 139.7489689128512 32.398 35.66881781160338 139.7489689128512 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23a5ed56-b8e1-4fd3-a2a4-9859a4ff1d9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23a5ed56-b8e1-4fd3-a2a4-9859a4ff1d9f_0">
											<gml:posList>35.668864937575314 139.74898488004177 31.358 35.66886048317699 139.748982576103 31.358 35.66886048317699 139.748982576103 32.398 35.668864937575314 139.74898488004177 32.398 35.668864937575314 139.74898488004177 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b10d629-91bc-4d9b-ae2b-ab450f8ee7d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b10d629-91bc-4d9b-ae2b-ab450f8ee7d0_0">
											<gml:posList>35.668864937575314 139.74898488004177 32.398 35.66886096158538 139.7489964163016 32.398 35.66886096158538 139.7489964163016 31.358 35.668864937575314 139.74898488004177 31.358 35.668864937575314 139.74898488004177 32.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b114f5a9-b8e0-4c7c-a3d6-41fd9519b80e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b114f5a9-b8e0-4c7c-a3d6-41fd9519b80e_0">
											<gml:posList>35.66886501923247 139.74899851078348 31.358 35.66886096158538 139.7489964163016 31.358 35.66886096158538 139.7489964163016 32.398 35.66886501923247 139.74899851078348 32.398 35.66886501923247 139.74899851078348 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dd1ea59-ee6a-42ae-8282-69b94a898ffe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dd1ea59-ee6a-42ae-8282-69b94a898ffe_0">
											<gml:posList>35.66889549126157 139.7490065202618 31.7 35.66889549126157 139.7490065202618 31.358 35.66887460769505 139.74899544094177 31.358 35.66887460769505 139.74899544094177 33.66 35.66889715942765 139.74900741323793 33.66 35.66889715942765 139.74900741323793 31.7 35.66889549126157 139.7490065202618 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb2acc4f-e110-4316-93f4-ef32a1525dfe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb2acc4f-e110-4316-93f4-ef32a1525dfe_0">
											<gml:posList>35.66887460769505 139.74899544094177 31.358 35.66886967780387 139.74900919846212 31.358 35.66886967780387 139.74900919846212 33.66 35.66887460769505 139.74899544094177 33.66 35.66887460769505 139.74899544094177 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f538e4b-f833-4557-9e19-147f4ddab41a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f538e4b-f833-4557-9e19-147f4ddab41a_0">
											<gml:posList>35.6688777029216 139.7490133322924 33.66 35.66887973599388 139.7490075751605 33.66 35.668894316651446 139.74901535834155 33.66 35.66889715942765 139.74900741323793 33.66 35.66887460769505 139.74899544094177 33.66 35.66886967780387 139.74900919846212 33.66 35.6688777029216 139.7490133322924 33.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65881cf8-a7c1-4885-8d49-5550ab166f2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65881cf8-a7c1-4885-8d49-5550ab166f2d_0">
											<gml:posList>35.66886048317699 139.748982576103 31.358 35.66884211444587 139.749035859472 31.358 35.66884211444587 139.749035859472 32.398 35.66886048317699 139.748982576103 32.398 35.66886048317699 139.748982576103 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef39dd92-4845-49b2-9115-7a7ff8756d37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef39dd92-4845-49b2-9115-7a7ff8756d37_0">
											<gml:posList>35.66889339517061 139.74901238792165 31.358 35.66889549126157 139.7490065202618 31.358 35.66889549126157 139.7490065202618 31.7 35.66889339517061 139.74901238792165 31.7 35.66889339517061 139.74901238792165 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8979b24-f209-4bad-8b37-b574ae4b2062">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8979b24-f209-4bad-8b37-b574ae4b2062_0">
											<gml:posList>35.66887973599388 139.7490075751605 31.358 35.66887973599388 139.7490075751605 33.66 35.6688777029216 139.7490133322924 33.66 35.6688777029216 139.7490133322924 31.358 35.66887973599388 139.7490075751605 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b91c270-426f-48d5-a6b7-f79aec7cb9ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b91c270-426f-48d5-a6b7-f79aec7cb9ec_0">
											<gml:posList>35.66886967780387 139.74900919846212 31.358 35.6688777029216 139.7490133322924 31.358 35.6688777029216 139.7490133322924 33.66 35.66886967780387 139.74900919846212 33.66 35.66886967780387 139.74900919846212 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-220b5319-6fb7-49fc-8d6a-908a743fab19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-220b5319-6fb7-49fc-8d6a-908a743fab19_0">
											<gml:posList>35.66886501923247 139.74899851078348 32.398 35.66886096158538 139.7489964163016 32.398 35.668864937575314 139.74898488004177 32.398 35.66886048317699 139.748982576103 32.398 35.66884211444587 139.749035859472 32.398 35.668850626497296 139.74904026894285 32.398 35.66886501923247 139.74899851078348 32.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4ffd725-87c0-4b70-9b09-973d3d6a7aca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4ffd725-87c0-4b70-9b09-973d3d6a7aca_0">
											<gml:posList>35.668894316651446 139.74901535834155 31.7 35.66889715942765 139.74900741323793 31.7 35.66889715942765 139.74900741323793 33.66 35.668894316651446 139.74901535834155 33.66 35.668894316651446 139.74901535834155 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49b92074-b5e3-4b06-b453-62a5b8a2378a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49b92074-b5e3-4b06-b453-62a5b8a2378a_0">
											<gml:posList>35.668892657506895 139.74901447640187 31.7 35.668894316651446 139.74901535834155 31.7 35.668894316651446 139.74901535834155 33.66 35.66887973599388 139.7490075751605 33.66 35.66887973599388 139.7490075751605 31.358 35.668892657506895 139.74901447640187 31.358 35.668892657506895 139.74901447640187 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3be3229-26ac-4620-8189-269c987f435c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3be3229-26ac-4620-8189-269c987f435c_0">
											<gml:posList>35.66886501923247 139.74899851078348 31.358 35.66886501923247 139.74899851078348 32.398 35.668850626497296 139.74904026894285 32.398 35.668850626497296 139.74904026894285 31.358 35.66886501923247 139.74899851078348 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-139b8466-7c0e-48eb-a6aa-e96dbefff5a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-139b8466-7c0e-48eb-a6aa-e96dbefff5a1_0">
											<gml:posList>35.66890062809747 139.7490308493217 36.904 35.66888329736475 139.7490217987327 36.904 35.66888329736475 139.7490217987327 38.326 35.66890062809747 139.7490308493217 38.326 35.66890062809747 139.7490308493217 36.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1773543-0245-4448-b347-1338f0688b6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1773543-0245-4448-b347-1338f0688b6e_0">
											<gml:posList>35.66887963612483 139.74903229633338 36.904 35.66887963612483 139.74903229633338 38.326 35.66888329736475 139.7490217987327 38.326 35.66888329736475 139.7490217987327 36.904 35.66887963612483 139.74903229633338 36.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd153088-4f3c-4377-bc67-0248942e4c63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd153088-4f3c-4377-bc67-0248942e4c63_0">
											<gml:posList>35.66887963612483 139.74903229633338 38.326 35.668896966864494 139.7490413579703 38.326 35.66890062809747 139.7490308493217 38.326 35.66888329736475 139.7490217987327 38.326 35.66887963612483 139.74903229633338 38.326</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff493a88-a41c-4254-952c-99a247dc0bb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff493a88-a41c-4254-952c-99a247dc0bb9_0">
											<gml:posList>35.668896966864494 139.7490413579703 36.904 35.66890062809747 139.7490308493217 36.904 35.66890062809747 139.7490308493217 38.326 35.668896966864494 139.7490413579703 38.326 35.668896966864494 139.7490413579703 36.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99830a02-36f3-4d1c-b762-949d7ada3897">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99830a02-36f3-4d1c-b762-949d7ada3897_0">
											<gml:posList>35.66887963612483 139.74903229633338 36.904 35.668896966864494 139.7490413579703 36.904 35.668896966864494 139.7490413579703 38.326 35.66887963612483 139.74903229633338 38.326 35.66887963612483 139.74903229633338 36.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32b37565-1173-4f45-b658-fc8fe3d1051e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32b37565-1173-4f45-b658-fc8fe3d1051e_0">
											<gml:posList>35.66884211444587 139.749035859472 31.358 35.668850626497296 139.74904026894285 31.358 35.668850626497296 139.74904026894285 32.398 35.66884211444587 139.749035859472 32.398 35.66884211444587 139.749035859472 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c2a3898f-46d2-4ccc-a4e5-309117e3c2c3_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09ba23c8-c43c-46e8-8413-5cda948da754">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66886320957997 139.74902726555834 31.358 35.66886967780387 139.74900919846212 31.358 35.66887786536206 139.74901360827292 31.358 35.66887145123534 139.74903169740585 31.358 35.66886320957997 139.74902726555834 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31df9669-9314-48f8-862c-108cbf30a34d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6688905114186 139.74909057493184 5.56 35.668873288553634 139.74908109342167 5.56 35.66888681847493 139.7490428929944 5.56 35.6689041403083 139.74905210928858 5.56 35.6688905114186 139.74909057493184 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4766a47-c727-4063-b18c-0d7d1582ab18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4766a47-c727-4063-b18c-0d7d1582ab18_0">
											<gml:posList>35.66887786536206 139.74901360827292 33.66 35.66887786536206 139.74901360827292 31.358 35.66886967780387 139.74900919846212 31.358 35.66886967780387 139.74900919846212 33.66 35.66887786536206 139.74901360827292 33.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-293a7066-e844-4049-a7ee-f95477685a55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-293a7066-e844-4049-a7ee-f95477685a55_0">
											<gml:posList>35.66886967780387 139.74900919846212 33.66 35.66886967780387 139.74900919846212 31.358 35.66886320957997 139.74902726555834 31.358 35.66886320957997 139.74902726555834 33.66 35.66886967780387 139.74900919846212 33.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a81cd56-2111-4a85-ba81-e97e12184d9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a81cd56-2111-4a85-ba81-e97e12184d9a_0">
											<gml:posList>35.66887145123534 139.74903169740585 33.66 35.66887786536206 139.74901360827292 33.66 35.66886967780387 139.74900919846212 33.66 35.66886320957997 139.74902726555834 33.66 35.66887145123534 139.74903169740585 33.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-282fb015-796f-46af-84db-01aaf2a3f368">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-282fb015-796f-46af-84db-01aaf2a3f368_0">
											<gml:posList>35.66887145123534 139.74903169740585 33.66 35.66887145123534 139.74903169740585 31.358 35.66887786536206 139.74901360827292 31.358 35.66887786536206 139.74901360827292 33.66 35.66887145123534 139.74903169740585 33.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51e0a530-fc4a-4776-84f5-5ede41019a7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51e0a530-fc4a-4776-84f5-5ede41019a7f_0">
											<gml:posList>35.66886320957997 139.74902726555834 33.66 35.66886320957997 139.74902726555834 31.358 35.66887145123534 139.74903169740585 31.358 35.66887145123534 139.74903169740585 33.66 35.66886320957997 139.74902726555834 33.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64dd7958-ac70-442a-bb66-fde3ee3e0c2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64dd7958-ac70-442a-bb66-fde3ee3e0c2e_0">
											<gml:posList>35.6689041403083 139.74905210928858 31.7 35.6689041403083 139.74905210928858 5.56 35.66888681847493 139.7490428929944 5.56 35.66888681847493 139.7490428929944 31.7 35.6689041403083 139.74905210928858 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a3b78f4-b133-4736-b96b-d291fddc005a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a3b78f4-b133-4736-b96b-d291fddc005a_0">
											<gml:posList>35.668902287129626 139.74905732497527 31.7 35.6689041403083 139.74905210928858 31.7 35.66888681847493 139.7490428929944 31.7 35.66888469542605 139.74904888218765 31.7 35.66889305396527 139.7490528941656 31.7 35.668902287129626 139.74905732497527 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8090cc2b-6191-42b2-9e2e-536ae59680a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8090cc2b-6191-42b2-9e2e-536ae59680a2_0">
											<gml:posList>35.66889305396527 139.7490528941656 31.7 35.66888469542605 139.74904888218765 31.7 35.66888469542605 139.74904888218765 27.116 35.66889305396527 139.7490528941656 27.116 35.66889305396527 139.7490528941656 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d8decb9-19ec-45de-a7f1-21629fb8f50c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d8decb9-19ec-45de-a7f1-21629fb8f50c_0">
											<gml:posList>35.668873288553634 139.74908109342167 28.734 35.668874862841115 139.74907664020816 28.734 35.66888469542605 139.74904888218765 27.116 35.66888469542605 139.74904888218765 31.7 35.66888681847493 139.7490428929944 31.7 35.66888681847493 139.7490428929944 5.56 35.668873288553634 139.74908109342167 5.56 35.668873288553634 139.74908109342167 28.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9661c0a-9715-46c7-9029-ba640c598184">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9661c0a-9715-46c7-9029-ba640c598184_0">
											<gml:posList>35.66889305396527 139.7490528941656 27.116 35.66888469542605 139.74904888218765 27.116 35.668874862841115 139.74907664020816 28.734 35.6688839160006 139.74908145782058 28.734 35.66889305396527 139.7490528941656 27.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86a95f2a-2903-4949-a76d-117064995c3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86a95f2a-2903-4949-a76d-117064995c3d_0">
											<gml:posList>35.6688839160006 139.74908145782058 28.734 35.66889305396527 139.7490528941656 31.7 35.66889305396527 139.7490528941656 27.116 35.6688839160006 139.74908145782058 28.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d836536c-30a5-4633-bc28-5b305496bfc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d836536c-30a5-4633-bc28-5b305496bfc7_0">
											<gml:posList>35.6688839160006 139.74908145782058 28.734 35.668892184671954 139.74908585650826 28.734 35.668902287129626 139.74905732497527 31.7 35.66889305396527 139.7490528941656 31.7 35.6688839160006 139.74908145782058 28.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-569997da-2be4-4b9a-abd9-861e48c65d61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-569997da-2be4-4b9a-abd9-861e48c65d61_0">
											<gml:posList>35.6688905114186 139.74909057493184 28.734 35.6688905114186 139.74909057493184 5.56 35.6689041403083 139.74905210928858 5.56 35.6689041403083 139.74905210928858 31.7 35.668902287129626 139.74905732497527 31.7 35.668892184671954 139.74908585650826 28.734 35.6688905114186 139.74909057493184 28.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cc597e3-449c-421f-aeb5-53a1c847553c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cc597e3-449c-421f-aeb5-53a1c847553c_0">
											<gml:posList>35.668874862841115 139.74907664020816 28.734 35.668873288553634 139.74908109342167 28.734 35.6688905114186 139.74909057493184 28.734 35.668892184671954 139.74908585650826 28.734 35.6688839160006 139.74908145782058 28.734 35.668874862841115 139.74907664020816 28.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10ccc7ba-8b69-40cd-a014-9c6f5ad2c8a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10ccc7ba-8b69-40cd-a014-9c6f5ad2c8a2_0">
											<gml:posList>35.668873288553634 139.74908109342167 28.734 35.668873288553634 139.74908109342167 5.56 35.6688905114186 139.74909057493184 5.56 35.6688905114186 139.74909057493184 28.734 35.668873288553634 139.74908109342167 28.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-447bc2e4-2603-45b8-843d-c85da2f2e18d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-447bc2e4-2603-45b8-843d-c85da2f2e18d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-447bc2e4-2603-45b8-843d-c85da2f2e18d">
											<gml:posList>35.66885456696133 139.74899086686437 5.56 35.66877368457608 139.74894919791615 5.56 35.6687935644924 139.7488915166569 5.56 35.668916105643696 139.7489550129028 5.56 35.66889442496313 139.74901556810272 5.56 35.66891345111995 139.7490258209293 5.56 35.6689041403083 139.74905210928858 5.56 35.66888681847493 139.7490428929944 5.56 35.668873288553634 139.74908109342167 5.56 35.66887175884773 139.74908485068684 5.56 35.6688293793355 139.74906346588517 5.56 35.66885456696133 139.74899086686437 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-267f6b2f-2ba1-4d63-9e5b-e0ee5fa294cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-267f6b2f-2ba1-4d63-9e5b-e0ee5fa294cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-267f6b2f-2ba1-4d63-9e5b-e0ee5fa294cc">
											<gml:posList>35.66881020172692 139.74896565122896 29.1 35.66882937103797 139.74891006944458 29.1 35.66882863339926 139.74891219106217 29.1 35.66881020172692 139.74896565122896 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8eb1764-a809-4588-b130-4dc6f24a87f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8eb1764-a809-4588-b130-4dc6f24a87f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8eb1764-a809-4588-b130-4dc6f24a87f0">
											<gml:posList>35.66877368457608 139.74894919791615 29.1 35.66880950907072 139.7489676512917 29.1 35.66881020172692 139.74896565122896 29.1 35.66877617154425 139.7489480244187 29.1 35.66879461222261 139.74889456426104 29.1 35.66882863339926 139.74891219106217 29.1 35.66882937103797 139.74891006944458 29.1 35.6687935644924 139.7488915166569 29.1 35.66877368457608 139.74894919791615 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-449f90c9-0a38-4552-915a-6146b8363964">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-449f90c9-0a38-4552-915a-6146b8363964">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-449f90c9-0a38-4552-915a-6146b8363964">
											<gml:posList>35.66879461222261 139.74889456426104 28.753 35.66877617154425 139.7489480244187 28.753 35.66881020172692 139.74896565122896 28.753 35.66882863339926 139.74891219106217 28.753 35.66879461222261 139.74889456426104 28.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d252b6c0-961a-4a69-a9f6-aafd3fbfeb7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d252b6c0-961a-4a69-a9f6-aafd3fbfeb7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d252b6c0-961a-4a69-a9f6-aafd3fbfeb7a">
											<gml:posList>35.66880950907072 139.7489676512917 31.7 35.66881210411866 139.7489663561741 31.7 35.66883041886065 139.7489132496028 31.7 35.66882937103797 139.74891006944458 31.7 35.66880950907072 139.7489676512917 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a5b9cb1-29a9-428b-9e73-b0e9e520b43a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a5b9cb1-29a9-428b-9e73-b0e9e520b43a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a5b9cb1-29a9-428b-9e73-b0e9e520b43a">
											<gml:posList>35.66885456696133 139.74899086686437 31.7 35.66885717103096 139.74898958278334 31.7 35.66881210411866 139.7489663561741 31.7 35.66880950907072 139.7489676512917 31.7 35.66885456696133 139.74899086686437 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e87478f6-446d-4a5a-9a15-c88e6465f554">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e87478f6-446d-4a5a-9a15-c88e6465f554">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e87478f6-446d-4a5a-9a15-c88e6465f554">
											<gml:posList>35.66885456696133 139.74899086686437 31.7 35.668836476847915 139.74904300114568 31.7 35.66883907190438 139.7490417170761 31.7 35.66885717103096 139.74898958278334 31.7 35.66885456696133 139.74899086686437 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6fdfd53-3a0f-42f1-bc44-730576f7ca69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6fdfd53-3a0f-42f1-bc44-730576f7ca69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6fdfd53-3a0f-42f1-bc44-730576f7ca69">
											<gml:posList>35.668874871854854 139.7490766401987 27.5 35.66883247381894 139.74905454847297 27.5 35.6688293793355 139.74906346588517 27.5 35.66887175884773 139.74908485068684 27.5 35.668873288553634 139.74908109342167 27.5 35.668874871854854 139.7490766401987 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5306bbd1-9923-4428-90ae-582b4349c323">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5306bbd1-9923-4428-90ae-582b4349c323">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5306bbd1-9923-4428-90ae-582b4349c323">
											<gml:posList>35.66887894701892 139.74906512592872 29.2 35.668836476847915 139.74904300114568 29.2 35.66883247381894 139.74905454847297 29.2 35.668874871854854 139.7490766401987 29.2 35.66887894701892 139.74906512592872 29.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-51b44dae-480b-4ded-be32-a4c271cac158">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51b44dae-480b-4ded-be32-a4c271cac158">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51b44dae-480b-4ded-be32-a4c271cac158">
											<gml:posList>35.66887894701892 139.74906512592872 31.7 35.6688779082217 139.74906195680316 31.7 35.66883907190438 139.7490417170761 31.7 35.668836476847915 139.74904300114568 31.7 35.66887894701892 139.74906512592872 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0cdb8785-b9e1-4369-8b6f-9f06df6206d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cdb8785-b9e1-4369-8b6f-9f06df6206d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cdb8785-b9e1-4369-8b6f-9f06df6206d6">
											<gml:posList>35.66885717103096 139.74898958278334 31.358 35.66883907190438 139.7490417170761 31.358 35.6688779082217 139.74906195680316 31.358 35.668884205367824 139.74904414394553 31.358 35.66888499702163 139.7490419228564 31.358 35.668870551641255 139.7490342389437 31.358 35.66887989842662 139.74900784009498 31.358 35.668892612531074 139.74901460900182 31.358 35.66889339517061 139.74901238792165 31.358 35.66891348353927 139.74895628595883 31.358 35.66883041886065 139.7489132496028 31.358 35.66881210411866 139.7489663561741 31.358 35.66885717103096 139.74898958278334 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca1a20ff-dc23-4921-9acb-8f8dd11b87b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca1a20ff-dc23-4921-9acb-8f8dd11b87b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca1a20ff-dc23-4921-9acb-8f8dd11b87b3">
											<gml:posList>35.66882937103797 139.74891006944458 31.7 35.66883041886065 139.7489132496028 31.7 35.66891348353927 139.74895628595883 31.7 35.668916105643696 139.7489550129028 31.7 35.66882937103797 139.74891006944458 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-87558d5a-aaf0-4674-ac23-ccfc23980ea9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87558d5a-aaf0-4674-ac23-ccfc23980ea9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87558d5a-aaf0-4674-ac23-ccfc23980ea9">
											<gml:posList>35.668870551641255 139.7490342389437 37.119 35.668872245641964 139.74903340870875 37.119 35.66888055787519 139.74900990501348 37.119 35.66887989842662 139.74900784009498 37.119 35.668870551641255 139.7490342389437 37.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d75f1cd-457a-451c-ba47-dcd75a2fcdea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d75f1cd-457a-451c-ba47-dcd75a2fcdea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d75f1cd-457a-451c-ba47-dcd75a2fcdea">
											<gml:posList>35.66888681847493 139.7490428929944 31.7 35.668884205367824 139.74904414394553 31.7 35.6688779082217 139.74906195680316 31.7 35.66887894701892 139.74906512592872 31.7 35.66888681847493 139.7490428929944 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a732075-b44f-4458-9dda-45dd16d054fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a732075-b44f-4458-9dda-45dd16d054fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a732075-b44f-4458-9dda-45dd16d054fb">
											<gml:posList>35.668884205367824 139.74904414394553 31.7 35.66888681847493 139.7490428929944 31.7 35.66888499702163 139.7490419228564 31.7 35.668884205367824 139.74904414394553 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5ae79903-9e1a-4561-a425-de2fbb9adf03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ae79903-9e1a-4561-a425-de2fbb9adf03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ae79903-9e1a-4561-a425-de2fbb9adf03">
											<gml:posList>35.6689041403083 139.74905210928858 37.119 35.66890347183899 139.74905003333254 37.119 35.668872245641964 139.74903340870875 37.119 35.668870551641255 139.7490342389437 37.119 35.6689041403083 139.74905210928858 37.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-51250f4a-e310-4598-9b45-f24ef337a2cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51250f4a-e310-4598-9b45-f24ef337a2cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51250f4a-e310-4598-9b45-f24ef337a2cd">
											<gml:posList>35.66891176611757 139.74902662906322 36.904 35.66888055787519 139.74900990501348 36.904 35.668872245641964 139.74903340870875 36.904 35.66890347183899 139.74905003333254 36.904 35.66891176611757 139.74902662906322 36.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a6237f9-af02-4baf-8aee-a2de61636580">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a6237f9-af02-4baf-8aee-a2de61636580">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a6237f9-af02-4baf-8aee-a2de61636580">
											<gml:posList>35.668892612531074 139.74901460900182 31.7 35.66889442496313 139.74901556810272 31.7 35.66889339517061 139.74901238792165 31.7 35.668892612531074 139.74901460900182 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-29607ac7-4711-47a2-96dd-26d1d42c657c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29607ac7-4711-47a2-96dd-26d1d42c657c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29607ac7-4711-47a2-96dd-26d1d42c657c">
											<gml:posList>35.66887989842662 139.74900784009498 37.119 35.66888055787519 139.74900990501348 37.119 35.66891176611757 139.74902662906322 37.119 35.66891345111995 139.7490258209293 37.119 35.66887989842662 139.74900784009498 37.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-490f66ea-52ae-4ec8-9ee6-dc7a0eb3d707">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-490f66ea-52ae-4ec8-9ee6-dc7a0eb3d707">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-490f66ea-52ae-4ec8-9ee6-dc7a0eb3d707">
											<gml:posList>35.668916105643696 139.7489550129028 31.7 35.66891348353927 139.74895628595883 31.7 35.66889339517061 139.74901238792165 31.7 35.66889442496313 139.74901556810272 31.7 35.668916105643696 139.7489550129028 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b931239-7050-473c-8c14-625bea93dfee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b931239-7050-473c-8c14-625bea93dfee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b931239-7050-473c-8c14-625bea93dfee">
											<gml:posList>35.66891345111995 139.7490258209293 37.119 35.66891176611757 139.74902662906322 37.119 35.66890347183899 139.74905003333254 37.119 35.6689041403083 139.74905210928858 37.119 35.66891345111995 139.7490258209293 37.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48891c92-61db-4b51-8c47-b6885868ca5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48891c92-61db-4b51-8c47-b6885868ca5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48891c92-61db-4b51-8c47-b6885868ca5c">
											<gml:posList>35.66881020172692 139.74896565122896 29.1 35.66881020172692 139.74896565122896 28.753 35.66877617154425 139.7489480244187 28.753 35.66877617154425 139.7489480244187 29.1 35.66881020172692 139.74896565122896 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b023e53c-2dce-4d13-a364-a71dfaa836a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b023e53c-2dce-4d13-a364-a71dfaa836a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b023e53c-2dce-4d13-a364-a71dfaa836a1">
											<gml:posList>35.6687935644924 139.7488915166569 5.56 35.66877368457608 139.74894919791615 5.56 35.66877368457608 139.74894919791615 29.1 35.6687935644924 139.7488915166569 29.1 35.6687935644924 139.7488915166569 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3f88d25-b3cf-42aa-8ff3-33bb32326cd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3f88d25-b3cf-42aa-8ff3-33bb32326cd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3f88d25-b3cf-42aa-8ff3-33bb32326cd8">
											<gml:posList>35.66877617154425 139.7489480244187 29.1 35.66877617154425 139.7489480244187 28.753 35.66879461222261 139.74889456426104 28.753 35.66879461222261 139.74889456426104 29.1 35.66877617154425 139.7489480244187 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ceb46c04-5671-41ea-bdf7-5737586fdf52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ceb46c04-5671-41ea-bdf7-5737586fdf52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ceb46c04-5671-41ea-bdf7-5737586fdf52">
											<gml:posList>35.66879461222261 139.74889456426104 29.1 35.66879461222261 139.74889456426104 28.753 35.66882863339926 139.74891219106217 28.753 35.66882863339926 139.74891219106217 29.1 35.66879461222261 139.74889456426104 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a53e198b-ae82-49aa-b354-15a295eabbce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a53e198b-ae82-49aa-b354-15a295eabbce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a53e198b-ae82-49aa-b354-15a295eabbce">
											<gml:posList>35.66885456696133 139.74899086686437 5.56 35.66885456696133 139.74899086686437 31.7 35.66880950907072 139.7489676512917 31.7 35.66880950907072 139.7489676512917 29.1 35.66877368457608 139.74894919791615 29.1 35.66877368457608 139.74894919791615 5.56 35.66885456696133 139.74899086686437 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-755bd1b3-c015-4ba4-af6a-386023e25156">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-755bd1b3-c015-4ba4-af6a-386023e25156">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-755bd1b3-c015-4ba4-af6a-386023e25156">
											<gml:posList>35.66881020172692 139.74896565122896 29.1 35.66882863339926 139.74891219106217 29.1 35.66882863339926 139.74891219106217 28.753 35.66881020172692 139.74896565122896 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffca727d-f3c1-47a4-89b0-966e21976b50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffca727d-f3c1-47a4-89b0-966e21976b50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffca727d-f3c1-47a4-89b0-966e21976b50">
											<gml:posList>35.66881020172692 139.74896565122896 29.1 35.66882863339926 139.74891219106217 28.753 35.66881020172692 139.74896565122896 28.753 35.66881020172692 139.74896565122896 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c637ad2-d400-4012-ac7b-d3f2e64b70d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c637ad2-d400-4012-ac7b-d3f2e64b70d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c637ad2-d400-4012-ac7b-d3f2e64b70d7">
											<gml:posList>35.66881020172692 139.74896565122896 29.1 35.66880950907072 139.7489676512917 29.1 35.66880950907072 139.7489676512917 31.7 35.66882937103797 139.74891006944458 31.7 35.66882937103797 139.74891006944458 29.1 35.66881020172692 139.74896565122896 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ffdb1a9-9f49-4ddd-a77f-9d22e8f612fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ffdb1a9-9f49-4ddd-a77f-9d22e8f612fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ffdb1a9-9f49-4ddd-a77f-9d22e8f612fb">
											<gml:posList>35.66881210411866 139.7489663561741 31.7 35.66881210411866 139.7489663561741 31.358 35.66883041886065 139.7489132496028 31.358 35.66883041886065 139.7489132496028 31.7 35.66881210411866 139.7489663561741 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6be8632-5ba6-4cd2-a933-3334038538a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6be8632-5ba6-4cd2-a933-3334038538a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6be8632-5ba6-4cd2-a933-3334038538a5">
											<gml:posList>35.66885717103096 139.74898958278334 31.7 35.66885717103096 139.74898958278334 31.358 35.66881210411866 139.7489663561741 31.358 35.66881210411866 139.7489663561741 31.7 35.66885717103096 139.74898958278334 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52110d34-8858-4051-afba-f4c839c0a62c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52110d34-8858-4051-afba-f4c839c0a62c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52110d34-8858-4051-afba-f4c839c0a62c">
											<gml:posList>35.6688293793355 139.74906346588517 5.56 35.6688293793355 139.74906346588517 27.5 35.66883247381894 139.74905454847297 27.5 35.66883247381894 139.74905454847297 29.2 35.668836476847915 139.74904300114568 29.2 35.668836476847915 139.74904300114568 31.7 35.66885456696133 139.74899086686437 31.7 35.66885456696133 139.74899086686437 5.56 35.6688293793355 139.74906346588517 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3d42640-a938-4bf0-bb45-2dcf6871fe06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3d42640-a938-4bf0-bb45-2dcf6871fe06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3d42640-a938-4bf0-bb45-2dcf6871fe06">
											<gml:posList>35.66883907190438 139.7490417170761 31.7 35.66883907190438 139.7490417170761 31.358 35.66885717103096 139.74898958278334 31.358 35.66885717103096 139.74898958278334 31.7 35.66883907190438 139.7490417170761 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-031f3407-4646-4ee1-99f4-8f533e92d2da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-031f3407-4646-4ee1-99f4-8f533e92d2da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-031f3407-4646-4ee1-99f4-8f533e92d2da">
											<gml:posList>35.6688293793355 139.74906346588517 5.56 35.66887175884773 139.74908485068684 5.56 35.66887175884773 139.74908485068684 27.5 35.6688293793355 139.74906346588517 27.5 35.6688293793355 139.74906346588517 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-251cbc20-3847-4a3b-bbbe-620abd908ec0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-251cbc20-3847-4a3b-bbbe-620abd908ec0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-251cbc20-3847-4a3b-bbbe-620abd908ec0">
											<gml:posList>35.668874871854854 139.7490766401987 27.5 35.668874871854854 139.7490766401987 29.2 35.66883247381894 139.74905454847297 29.2 35.66883247381894 139.74905454847297 27.5 35.668874871854854 139.7490766401987 27.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91660a00-023f-4af4-92d6-6dc46e7b8d5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91660a00-023f-4af4-92d6-6dc46e7b8d5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91660a00-023f-4af4-92d6-6dc46e7b8d5c">
											<gml:posList>35.6687935644924 139.7488915166569 5.56 35.6687935644924 139.7488915166569 29.1 35.66882937103797 139.74891006944458 29.1 35.66882937103797 139.74891006944458 31.7 35.668916105643696 139.7489550129028 31.7 35.668916105643696 139.7489550129028 5.56 35.6687935644924 139.7488915166569 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bec229dd-7048-4287-bee6-f4d9788e3378">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bec229dd-7048-4287-bee6-f4d9788e3378">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bec229dd-7048-4287-bee6-f4d9788e3378">
											<gml:posList>35.66887894701892 139.74906512592872 29.2 35.66887894701892 139.74906512592872 31.7 35.668836476847915 139.74904300114568 31.7 35.668836476847915 139.74904300114568 29.2 35.66887894701892 139.74906512592872 29.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8979750c-7ba3-4ad6-ad65-81500eeadab5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8979750c-7ba3-4ad6-ad65-81500eeadab5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8979750c-7ba3-4ad6-ad65-81500eeadab5">
											<gml:posList>35.6688779082217 139.74906195680316 31.7 35.6688779082217 139.74906195680316 31.358 35.66883907190438 139.7490417170761 31.358 35.66883907190438 139.7490417170761 31.7 35.6688779082217 139.74906195680316 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-268d484e-f3ec-4271-b9a7-7cbbca22b89e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-268d484e-f3ec-4271-b9a7-7cbbca22b89e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-268d484e-f3ec-4271-b9a7-7cbbca22b89e">
											<gml:posList>35.66883041886065 139.7489132496028 31.7 35.66883041886065 139.7489132496028 31.358 35.66891348353927 139.74895628595883 31.358 35.66891348353927 139.74895628595883 31.7 35.66883041886065 139.7489132496028 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a3f0953-0a52-4004-a7ed-c6aba1ccb4dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a3f0953-0a52-4004-a7ed-c6aba1ccb4dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a3f0953-0a52-4004-a7ed-c6aba1ccb4dc">
											<gml:posList>35.66887175884773 139.74908485068684 5.56 35.668873288553634 139.74908109342167 5.56 35.668873288553634 139.74908109342167 27.5 35.66887175884773 139.74908485068684 27.5 35.66887175884773 139.74908485068684 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3aa0b958-4437-4231-b011-d4f705cd4f44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3aa0b958-4437-4231-b011-d4f705cd4f44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3aa0b958-4437-4231-b011-d4f705cd4f44">
											<gml:posList>35.668870551641255 139.7490342389437 37.119 35.66887989842662 139.74900784009498 37.119 35.66887989842662 139.74900784009498 31.358 35.668870551641255 139.7490342389437 31.358 35.668870551641255 139.7490342389437 37.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cd68838-3f1a-4537-bed7-d5a09ded0a7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cd68838-3f1a-4537-bed7-d5a09ded0a7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cd68838-3f1a-4537-bed7-d5a09ded0a7e">
											<gml:posList>35.668872245641964 139.74903340870875 37.119 35.668872245641964 139.74903340870875 36.904 35.66888055787519 139.74900990501348 36.904 35.66888055787519 139.74900990501348 37.119 35.668872245641964 139.74903340870875 37.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da2e32b6-e3c3-4ef0-a4e2-34cc6e9757e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da2e32b6-e3c3-4ef0-a4e2-34cc6e9757e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da2e32b6-e3c3-4ef0-a4e2-34cc6e9757e2">
											<gml:posList>35.668873288553634 139.74908109342167 5.56 35.66888681847493 139.7490428929944 5.56 35.66888681847493 139.7490428929944 31.7 35.66887894701892 139.74906512592872 31.7 35.66887894701892 139.74906512592872 29.2 35.668874871854854 139.7490766401987 29.2 35.668874871854854 139.7490766401987 27.5 35.668873288553634 139.74908109342167 27.5 35.668873288553634 139.74908109342167 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85a2af2c-f3a0-45b6-83d6-cb36a831210a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85a2af2c-f3a0-45b6-83d6-cb36a831210a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85a2af2c-f3a0-45b6-83d6-cb36a831210a">
											<gml:posList>35.668884205367824 139.74904414394553 31.7 35.668884205367824 139.74904414394553 31.358 35.6688779082217 139.74906195680316 31.358 35.6688779082217 139.74906195680316 31.7 35.668884205367824 139.74904414394553 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c961e22-5119-456e-a074-e4f277d901e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c961e22-5119-456e-a074-e4f277d901e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c961e22-5119-456e-a074-e4f277d901e8">
											<gml:posList>35.66888499702163 139.7490419228564 31.7 35.66888499702163 139.7490419228564 31.358 35.668884205367824 139.74904414394553 31.358 35.668884205367824 139.74904414394553 31.7 35.66888499702163 139.7490419228564 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5dc97209-f417-424e-aaa1-271e2c3b1390">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5dc97209-f417-424e-aaa1-271e2c3b1390">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5dc97209-f417-424e-aaa1-271e2c3b1390">
											<gml:posList>35.668870551641255 139.7490342389437 31.358 35.66888499702163 139.7490419228564 31.358 35.66888499702163 139.7490419228564 31.7 35.66888681847493 139.7490428929944 31.7 35.66888681847493 139.7490428929944 5.56 35.6689041403083 139.74905210928858 5.56 35.6689041403083 139.74905210928858 37.119 35.668870551641255 139.7490342389437 37.119 35.668870551641255 139.7490342389437 31.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7499bb97-6138-4c71-9d01-f8d4db78172a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7499bb97-6138-4c71-9d01-f8d4db78172a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7499bb97-6138-4c71-9d01-f8d4db78172a">
											<gml:posList>35.66890347183899 139.74905003333254 37.119 35.66890347183899 139.74905003333254 36.904 35.668872245641964 139.74903340870875 36.904 35.668872245641964 139.74903340870875 37.119 35.66890347183899 139.74905003333254 37.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-528c5fd3-9975-4ecb-a8c8-524e625a9a5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-528c5fd3-9975-4ecb-a8c8-524e625a9a5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-528c5fd3-9975-4ecb-a8c8-524e625a9a5a">
											<gml:posList>35.66889339517061 139.74901238792165 31.7 35.66889339517061 139.74901238792165 31.358 35.668892612531074 139.74901460900182 31.358 35.668892612531074 139.74901460900182 31.7 35.66889339517061 139.74901238792165 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f45ff217-c984-4194-bb90-25140cf51573">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f45ff217-c984-4194-bb90-25140cf51573">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f45ff217-c984-4194-bb90-25140cf51573">
											<gml:posList>35.66888055787519 139.74900990501348 37.119 35.66888055787519 139.74900990501348 36.904 35.66891176611757 139.74902662906322 36.904 35.66891176611757 139.74902662906322 37.119 35.66888055787519 139.74900990501348 37.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-117e6b4e-8004-4527-be37-8591e0bad8fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-117e6b4e-8004-4527-be37-8591e0bad8fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-117e6b4e-8004-4527-be37-8591e0bad8fd">
											<gml:posList>35.66891345111995 139.7490258209293 37.119 35.66891345111995 139.7490258209293 5.56 35.66889442496313 139.74901556810272 5.56 35.66889442496313 139.74901556810272 31.7 35.668892612531074 139.74901460900182 31.7 35.668892612531074 139.74901460900182 31.358 35.66887989842662 139.74900784009498 31.358 35.66887989842662 139.74900784009498 37.119 35.66891345111995 139.7490258209293 37.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41f59196-0531-4031-9501-33d0028ac6c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41f59196-0531-4031-9501-33d0028ac6c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41f59196-0531-4031-9501-33d0028ac6c1">
											<gml:posList>35.66891348353927 139.74895628595883 31.7 35.66891348353927 139.74895628595883 31.358 35.66889339517061 139.74901238792165 31.358 35.66889339517061 139.74901238792165 31.7 35.66891348353927 139.74895628595883 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2ae1ca0-4d0f-4718-b69b-e4c5c15d8342">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2ae1ca0-4d0f-4718-b69b-e4c5c15d8342">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2ae1ca0-4d0f-4718-b69b-e4c5c15d8342">
											<gml:posList>35.66889442496313 139.74901556810272 5.56 35.668916105643696 139.7489550129028 5.56 35.668916105643696 139.7489550129028 31.7 35.66889442496313 139.74901556810272 31.7 35.66889442496313 139.74901556810272 5.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29f7f130-a9dd-419b-920d-13f46a4ef909">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29f7f130-a9dd-419b-920d-13f46a4ef909">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29f7f130-a9dd-419b-920d-13f46a4ef909">
											<gml:posList>35.66891176611757 139.74902662906322 37.119 35.66891176611757 139.74902662906322 36.904 35.66890347183899 139.74905003333254 36.904 35.66890347183899 139.74905003333254 37.119 35.66891176611757 139.74902662906322 37.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f2c4fdd-de31-4f37-b8b9-302a2b70870b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f2c4fdd-de31-4f37-b8b9-302a2b70870b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f2c4fdd-de31-4f37-b8b9-302a2b70870b">
											<gml:posList>35.6689041403083 139.74905210928858 37.119 35.6689041403083 139.74905210928858 5.56 35.66891345111995 139.7490258209293 5.56 35.66891345111995 139.7490258209293 37.119 35.6689041403083 139.74905210928858 37.119</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8300</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">133.06565</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>