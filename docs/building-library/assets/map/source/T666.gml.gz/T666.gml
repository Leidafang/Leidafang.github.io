<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c33f0422-328f-48a6-af45-80bb23658796">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">12</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668794107008345 139.739401309708 0 35.66872056927441 139.73932726594398 0 35.668734713277345 139.73930604097887 0 35.66867644799449 139.73924768688045 0 35.668618827184474 139.73933358204167 0 35.66869920239385 139.73941412381868 0 35.66869668139393 139.73941777196058 0 35.668616489134365 139.73934065423308 0 35.668584527476234 139.73938818955085 0 35.66866327888751 139.7394670763457 0 35.66866652012586 139.73946232276137 0 35.66871811935155 139.7395145100769 0 35.668794107008345 139.739401309708 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668794107008345 139.739401309708 11.742 35.66871811935155 139.7395145100769 11.742 35.66866652012586 139.73946232276137 11.742 35.66866327888751 139.7394670763457 11.742 35.668584527476234 139.73938818955085 11.742 35.668616489134365 139.73934065423308 11.742 35.66869668139393 139.73941777196058 11.742 35.66869920239385 139.73941412381868 11.742 35.668618827184474 139.73933358204167 11.742 35.66867644799449 139.73924768688045 11.742 35.668734713277345 139.73930604097887 11.742 35.66872056927441 139.73932726594398 11.742 35.668794107008345 139.739401309708 11.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668794107008345 139.739401309708 11.742 35.66872056927441 139.73932726594398 11.742 35.66872056927441 139.73932726594398 23.71 35.668794107008345 139.739401309708 23.71 35.668794107008345 139.739401309708 11.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872056927441 139.73932726594398 11.742 35.668734713277345 139.73930604097887 11.742 35.668734713277345 139.73930604097887 23.71 35.66872056927441 139.73932726594398 23.71 35.66872056927441 139.73932726594398 11.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668734713277345 139.73930604097887 11.742 35.66867644799449 139.73924768688045 11.742 35.66867644799449 139.73924768688045 23.71 35.668734713277345 139.73930604097887 23.71 35.668734713277345 139.73930604097887 11.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867644799449 139.73924768688045 11.742 35.668618827184474 139.73933358204167 11.742 35.668618827184474 139.73933358204167 23.71 35.66867644799449 139.73924768688045 23.71 35.66867644799449 139.73924768688045 11.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668618827184474 139.73933358204167 11.742 35.66869920239385 139.73941412381868 11.742 35.66869920239385 139.73941412381868 23.71 35.668618827184474 139.73933358204167 23.71 35.668618827184474 139.73933358204167 11.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869920239385 139.73941412381868 11.742 35.66869668139393 139.73941777196058 11.742 35.66869668139393 139.73941777196058 23.71 35.66869920239385 139.73941412381868 23.71 35.66869920239385 139.73941412381868 11.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869668139393 139.73941777196058 11.742 35.668616489134365 139.73934065423308 11.742 35.668616489134365 139.73934065423308 23.71 35.66869668139393 139.73941777196058 23.71 35.66869668139393 139.73941777196058 11.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668616489134365 139.73934065423308 11.742 35.668584527476234 139.73938818955085 11.742 35.668584527476234 139.73938818955085 23.71 35.668616489134365 139.73934065423308 23.71 35.668616489134365 139.73934065423308 11.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668584527476234 139.73938818955085 11.742 35.66866327888751 139.7394670763457 11.742 35.66866327888751 139.7394670763457 23.71 35.668584527476234 139.73938818955085 23.71 35.668584527476234 139.73938818955085 11.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866327888751 139.7394670763457 11.742 35.66866652012586 139.73946232276137 11.742 35.66866652012586 139.73946232276137 23.71 35.66866327888751 139.7394670763457 23.71 35.66866327888751 139.7394670763457 11.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66866652012586 139.73946232276137 11.742 35.66871811935155 139.7395145100769 11.742 35.66871811935155 139.7395145100769 23.71 35.66866652012586 139.73946232276137 23.71 35.66866652012586 139.73946232276137 11.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66871811935155 139.7395145100769 11.742 35.668794107008345 139.739401309708 11.742 35.668794107008345 139.739401309708 23.71 35.66871811935155 139.7395145100769 23.71 35.66871811935155 139.7395145100769 11.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668794107008345 139.739401309708 23.71 35.66872056927441 139.73932726594398 23.71 35.668734713277345 139.73930604097887 23.71 35.66867644799449 139.73924768688045 23.71 35.668618827184474 139.73933358204167 23.71 35.66869920239385 139.73941412381868 23.71 35.66869668139393 139.73941777196058 23.71 35.668616489134365 139.73934065423308 23.71 35.668584527476234 139.73938818955085 23.71 35.66866327888751 139.7394670763457 23.71 35.66866652012586 139.73946232276137 23.71 35.66871811935155 139.7395145100769 23.71 35.668794107008345 139.739401309708 23.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-cc07cea1-6bef-42a8-b2b7-8bf8a07ea54e"/>
							<gml:surfaceMember xlink:href="#poly-c47bc9bc-f06a-4807-acdc-e271022b543c"/>
							<gml:surfaceMember xlink:href="#poly-21c26786-2abc-4f4e-83ae-bb138e128bb0"/>
							<gml:surfaceMember xlink:href="#poly-c01c2593-3b85-4cd4-b28d-027a8aa8f66e"/>
							<gml:surfaceMember xlink:href="#poly-a0c70768-1756-475d-b21a-296c1f8f31a1"/>
							<gml:surfaceMember xlink:href="#poly-e1321c8a-4927-4ed8-a00a-4c241fbd5ae6"/>
							<gml:surfaceMember xlink:href="#poly-7384fa4d-f19b-4bce-b2b5-dbcde19dbecc"/>
							<gml:surfaceMember xlink:href="#poly-c18b77ab-557e-4f70-ad67-7230f5211422"/>
							<gml:surfaceMember xlink:href="#poly-d1032353-8243-4641-a839-5fefaa320fc3"/>
							<gml:surfaceMember xlink:href="#poly-aa5b9442-04de-439e-9d5b-782d7f3c0308"/>
							<gml:surfaceMember xlink:href="#poly-90bf2e6d-7728-4754-98bc-32f16d4e3a36"/>
							<gml:surfaceMember xlink:href="#poly-d30546bc-3004-41f0-9c9a-cb6d2770c584"/>
							<gml:surfaceMember xlink:href="#poly-d1133a86-d5a3-4f2b-8165-a3885f764ed5"/>
							<gml:surfaceMember xlink:href="#poly-b32f41b5-1f1e-408c-811a-a1069a40db74"/>
							<gml:surfaceMember xlink:href="#poly-576c95f1-2b5e-45fe-9bc3-19787f29ee4b"/>
							<gml:surfaceMember xlink:href="#poly-44089683-a3a0-433e-83ca-5830a8c7d2e7"/>
							<gml:surfaceMember xlink:href="#poly-831826e1-9e05-4e95-b782-0a71de4b1f7d"/>
							<gml:surfaceMember xlink:href="#poly-2df7801e-3722-4f84-9ee2-3d8d48b614d9"/>
							<gml:surfaceMember xlink:href="#poly-6f0633b7-08ad-4586-85b7-97e9143ba41f"/>
							<gml:surfaceMember xlink:href="#poly-c1d38efe-8ecb-4c11-9a11-f55e9fd03230"/>
							<gml:surfaceMember xlink:href="#poly-dda9fc81-8add-48c6-b955-1ec21fa08d41"/>
							<gml:surfaceMember xlink:href="#poly-5fe7e576-0afd-4705-94f3-c9437dccb9fc"/>
							<gml:surfaceMember xlink:href="#poly-f4008762-2590-49f2-b24e-169e8b8ece3a"/>
							<gml:surfaceMember xlink:href="#poly-8971942d-13f3-446f-9bb0-70b5ee20c181"/>
							<gml:surfaceMember xlink:href="#poly-d3158507-0ef8-4fd6-9e39-f54a180df680"/>
							<gml:surfaceMember xlink:href="#poly-13a175f3-04dc-401c-b9bc-5bc98f18b17a"/>
							<gml:surfaceMember xlink:href="#poly-03271ea8-2e08-422e-89b2-5d43368cf8b1"/>
							<gml:surfaceMember xlink:href="#poly-b30b464b-eb11-4657-81b0-2d1b01a35293"/>
							<gml:surfaceMember xlink:href="#poly-e73c4b48-09f6-4fcd-a4bb-1e6d13d72528"/>
							<gml:surfaceMember xlink:href="#poly-98351f75-9e7f-4d0e-9bf8-21b23edcfdf5"/>
							<gml:surfaceMember xlink:href="#poly-60827f11-177a-4042-949c-e5bd5bebc057"/>
							<gml:surfaceMember xlink:href="#poly-78a70bb6-60b9-4549-b3f3-665c254b681a"/>
							<gml:surfaceMember xlink:href="#poly-3a3ee202-cc87-40dc-bc27-b0980c09a231"/>
							<gml:surfaceMember xlink:href="#poly-46cdb94e-9faf-4321-8f32-22d3e019444f"/>
							<gml:surfaceMember xlink:href="#poly-b4504102-8ea0-404a-80ac-90cecaff26a9"/>
							<gml:surfaceMember xlink:href="#poly-2d95ac09-4566-476d-8b83-1be0e51778ac"/>
							<gml:surfaceMember xlink:href="#poly-1df2afe2-27cb-4d18-a944-0e903b0023d0"/>
							<gml:surfaceMember xlink:href="#poly-cfdadcac-70b1-4e05-bb9c-cb43599b8138"/>
							<gml:surfaceMember xlink:href="#poly-961f68da-9f03-46a8-923d-2a74778d158f"/>
							<gml:surfaceMember xlink:href="#poly-da43f157-364e-49ff-838f-ab3c37f56ccf"/>
							<gml:surfaceMember xlink:href="#poly-758696d4-ac4c-4e89-9fe2-66d0bf07a7e6"/>
							<gml:surfaceMember xlink:href="#poly-7f020602-3caa-440b-b92d-8dcd0e5991fb"/>
							<gml:surfaceMember xlink:href="#poly-73f7be7f-b4d3-4a5f-af0c-2d484af4a160"/>
							<gml:surfaceMember xlink:href="#poly-0431c06d-d796-4e53-a0d2-f5ff8c7f3bf9"/>
							<gml:surfaceMember xlink:href="#poly-eba35a83-a84b-4496-ae33-280d6f827f0e"/>
							<gml:surfaceMember xlink:href="#poly-afd78a21-72cc-40f0-89a3-a5604e1b93d0"/>
							<gml:surfaceMember xlink:href="#poly-0d833328-26a4-43f3-8991-a1a77772fc4d"/>
							<gml:surfaceMember xlink:href="#poly-77afb18a-e66e-46d0-a1ec-ba3b535502a5"/>
							<gml:surfaceMember xlink:href="#poly-aed834a4-b51f-4ecb-a4d6-ed9977792c24"/>
							<gml:surfaceMember xlink:href="#poly-ac9836b9-82e4-4251-ac10-88cade1703ac"/>
							<gml:surfaceMember xlink:href="#poly-bc30afdb-85ce-434d-afdb-d6df2498ce08"/>
							<gml:surfaceMember xlink:href="#poly-617ff41b-6a5d-4312-a446-43e2941fadfa"/>
							<gml:surfaceMember xlink:href="#poly-e8c33eac-c5d3-4c6b-b659-f5f44dc47362"/>
							<gml:surfaceMember xlink:href="#poly-c951da32-d694-4bf2-a9cf-6d870146eb12"/>
							<gml:surfaceMember xlink:href="#poly-a0760dc6-0c56-4288-a8b4-7eeff044186d"/>
							<gml:surfaceMember xlink:href="#poly-27e50d35-66dc-4cef-99c7-74c9f0bf0f79"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c33f0422-328f-48a6-af45-80bb23658796_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-514e24c1-ab2b-468a-9400-80e6cc4145e2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66871173541591 139.73933830023822 23.906 35.66869562422718 139.7393220814647 23.906 35.66870352007893 139.73931030818693 23.906 35.668718683939886 139.73932539032916 23.906 35.66871766657039 139.73932690482812 23.906 35.66871867690093 139.7393279198784 23.906 35.66871173541591 139.73933830023822 23.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05324cb4-5c75-4df7-9094-cded58c74c34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66871867690093 139.7393279198784 24.11 35.66871766657039 139.73932690482812 24.11 35.668718683939886 139.73932539032916 24.11 35.66871970328416 139.7393264053689 24.11 35.66871867690093 139.7393279198784 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8319618c-87ca-4d98-a266-e01b55d23f3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8319618c-87ca-4d98-a266-e01b55d23f3a_0">
											<gml:posList>35.668718683939886 139.73932539032916 23.906 35.668718683939886 139.73932539032916 24.11 35.66871766657039 139.73932690482812 24.11 35.66871766657039 139.73932690482812 23.906 35.668718683939886 139.73932539032916 23.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2113df28-fe3c-473e-870b-06a5f04de481">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2113df28-fe3c-473e-870b-06a5f04de481_0">
											<gml:posList>35.66871766657039 139.73932690482812 24.11 35.66871867690093 139.7393279198784 24.11 35.66871867690093 139.7393279198784 23.906 35.66871766657039 139.73932690482812 23.906 35.66871766657039 139.73932690482812 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-291739ef-0772-428d-8b8b-44300ecccc6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-291739ef-0772-428d-8b8b-44300ecccc6b_0">
											<gml:posList>35.66869562422718 139.7393220814647 23.906 35.66869562422718 139.7393220814647 26.025 35.66870352007893 139.73931030818693 26.025 35.66870352007893 139.73931030818693 23.906 35.66869562422718 139.7393220814647 23.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7d2ce37-bfbb-4608-aad6-23b5d85f76a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7d2ce37-bfbb-4608-aad6-23b5d85f76a3_0">
											<gml:posList>35.66869562422718 139.7393220814647 26.025 35.66869562422718 139.7393220814647 23.906 35.66871173541591 139.73933830023822 23.906 35.66871173541591 139.73933830023822 26.025 35.66869562422718 139.7393220814647 26.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec9ce6fc-877a-47dd-a48f-d404d47ef7af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec9ce6fc-877a-47dd-a48f-d404d47ef7af_0">
											<gml:posList>35.66870352007893 139.73931030818693 26.025 35.66869562422718 139.7393220814647 26.025 35.66871173541591 139.73933830023822 26.025 35.66871970328416 139.7393264053689 26.025 35.66870352007893 139.73931030818693 26.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdd86ba8-57ed-4d85-a48c-586d8677f7dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdd86ba8-57ed-4d85-a48c-586d8677f7dd_0">
											<gml:posList>35.66871970328416 139.7393264053689 24.11 35.668718683939886 139.73932539032916 24.11 35.668718683939886 139.73932539032916 23.906 35.66870352007893 139.73931030818693 23.906 35.66870352007893 139.73931030818693 26.025 35.66871970328416 139.7393264053689 26.025 35.66871970328416 139.7393264053689 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c591a6c0-a017-4be0-baa1-07d2fb136183">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c591a6c0-a017-4be0-baa1-07d2fb136183_0">
											<gml:posList>35.66871970328416 139.7393264053689 26.025 35.66871173541591 139.73933830023822 26.025 35.66871173541591 139.73933830023822 23.906 35.66871867690093 139.7393279198784 23.906 35.66871867690093 139.7393279198784 24.11 35.66871970328416 139.7393264053689 24.11 35.66871970328416 139.7393264053689 26.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c33f0422-328f-48a6-af45-80bb23658796_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-591444f9-786b-4718-ae85-95438fcf91a6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668764581099964 139.73933595175944 11.742 35.66875032897022 139.7393572320841 11.742 35.66872056927438 139.73932726594398 11.742 35.66873471327733 139.73930604097885 11.742 35.668764581099964 139.73933595175944 11.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04ba8061-0915-4bbd-b7ed-2dfca97f39d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04ba8061-0915-4bbd-b7ed-2dfca97f39d0_0">
											<gml:posList>35.66873471327733 139.73930604097885 24.11 35.66873471327733 139.73930604097885 11.742 35.66872056927438 139.73932726594398 11.742 35.66872056927438 139.73932726594398 24.087 35.66873471327733 139.73930604097885 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f595ef14-0ffd-4045-9dc7-7435879fe5b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f595ef14-0ffd-4045-9dc7-7435879fe5b4_0">
											<gml:posList>35.668764581099964 139.73933595175944 11.742 35.66873471327733 139.73930604097885 11.742 35.66873471327733 139.73930604097885 24.11 35.668764581099964 139.73933595175944 24.11 35.668764581099964 139.73933595175944 11.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e162bbb-7f02-4cd8-882a-fc1ccab4aa5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e162bbb-7f02-4cd8-882a-fc1ccab4aa5f_0">
											<gml:posList>35.668750355976904 139.7393571878683 24.11 35.668764581099964 139.73933595175944 24.11 35.66873471327733 139.73930604097885 24.11 35.66872056927438 139.73932726594398 24.087 35.668750355976904 139.7393571878683 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a19e329e-7296-4bae-876b-6702f821cc52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a19e329e-7296-4bae-876b-6702f821cc52_0">
											<gml:posList>35.668750355976904 139.7393571878683 24.11 35.66872056927438 139.73932726594398 24.087 35.66872056927438 139.73932726594398 11.742 35.66875032897022 139.7393572320841 11.742 35.668750355976904 139.7393571878683 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-401b5ae5-5e4b-4cec-a693-497c1961b997">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-401b5ae5-5e4b-4cec-a693-497c1961b997_0">
											<gml:posList>35.668750355976904 139.7393571878683 24.11 35.66875032897022 139.7393572320841 11.742 35.668764581099964 139.73933595175944 11.742 35.668764581099964 139.73933595175944 24.11 35.668750355976904 139.7393571878683 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-cc07cea1-6bef-42a8-b2b7-8bf8a07ea54e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc07cea1-6bef-42a8-b2b7-8bf8a07ea54e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc07cea1-6bef-42a8-b2b7-8bf8a07ea54e">
											<gml:posList>35.66872056927438 139.73932726594398 11.742 35.668794107008345 139.73940130970797 11.742 35.66871811935154 139.7395145100769 11.742 35.66866652012585 139.73946232276134 11.742 35.6686632788875 139.7394670763457 11.742 35.66858452747623 139.73938818955085 11.742 35.66861648913435 139.73934065423308 11.742 35.66869668139391 139.73941777196058 11.742 35.66869920239385 139.73941412381868 11.742 35.668618827184474 139.73933358204167 11.742 35.66867644799449 139.73924768688042 11.742 35.66873471327733 139.73930604097885 11.742 35.66872056927438 139.73932726594398 11.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c47bc9bc-f06a-4807-acdc-e271022b543c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c47bc9bc-f06a-4807-acdc-e271022b543c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c47bc9bc-f06a-4807-acdc-e271022b543c">
											<gml:posList>35.66858452747623 139.73938818955085 19.556 35.66858776593713 139.7393914332842 19.556 35.668619619250755 139.73934366612642 19.556 35.66861648913435 139.73934065423308 19.556 35.66858452747623 139.73938818955085 19.556</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21c26786-2abc-4f4e-83ae-bb138e128bb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21c26786-2abc-4f4e-83ae-bb138e128bb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21c26786-2abc-4f4e-83ae-bb138e128bb0">
											<gml:posList>35.66860190149979 139.73940558875944 22.27 35.66863398890856 139.73935747889792 22.27 35.668619619250755 139.73934366612642 22.27 35.66858776593713 139.7393914332842 22.27 35.66860190149979 139.73940558875944 22.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c01c2593-3b85-4cd4-b28d-027a8aa8f66e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c01c2593-3b85-4cd4-b28d-027a8aa8f66e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c01c2593-3b85-4cd4-b28d-027a8aa8f66e">
											<gml:posList>35.668638150979845 139.73938922027946 27.728 35.66863785988634 139.73938581844655 27.728 35.668615549949166 139.7394192698315 27.728 35.668618334923146 139.73941892414305 27.728 35.668638150979845 139.73938922027946 27.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a0c70768-1756-475d-b21a-296c1f8f31a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0c70768-1756-475d-b21a-296c1f8f31a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0c70768-1756-475d-b21a-296c1f8f31a1">
											<gml:posList>35.668618334923146 139.73941892414305 27.728 35.668615549949166 139.7394192698315 27.728 35.6686632788875 139.7394670763457 27.728 35.668663014837364 139.73946367447982 27.728 35.668618334923146 139.73941892414305 27.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e1321c8a-4927-4ed8-a00a-4c241fbd5ae6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1321c8a-4927-4ed8-a00a-4c241fbd5ae6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1321c8a-4927-4ed8-a00a-4c241fbd5ae6">
											<gml:posList>35.66863398890856 139.73935747889792 24.907 35.66860190149979 139.73940558875944 24.907 35.668615549949166 139.7394192698315 24.907 35.66863785988634 139.73938581844655 24.907 35.66868577832411 139.7394338787908 24.907 35.66869668139391 139.73941777196058 24.907 35.66863398890856 139.73935747889792 24.907</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7384fa4d-f19b-4bce-b2b5-dbcde19dbecc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7384fa4d-f19b-4bce-b2b5-dbcde19dbecc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7384fa4d-f19b-4bce-b2b5-dbcde19dbecc">
											<gml:posList>35.668618334923146 139.73941892414305 27.154 35.668663014837364 139.73946367447982 27.154 35.668682993332894 139.73943420238697 27.154 35.668638150979845 139.73938922027946 27.154 35.668618334923146 139.73941892414305 27.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c18b77ab-557e-4f70-ad67-7230f5211422">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c18b77ab-557e-4f70-ad67-7230f5211422">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c18b77ab-557e-4f70-ad67-7230f5211422">
											<gml:posList>35.668618827184474 139.73933358204167 20.53 35.66863953891488 139.7393543353236 24.11 35.66869697931832 139.73926825258422 24.11 35.66867644799449 139.73924768688042 20.53 35.668618827184474 139.73933358204167 20.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1032353-8243-4641-a839-5fefaa320fc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1032353-8243-4641-a839-5fefaa320fc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1032353-8243-4641-a839-5fefaa320fc3">
											<gml:posList>35.668682993332894 139.73943420238697 27.728 35.66868577832411 139.7394338787908 27.728 35.66863785988634 139.73938581844655 27.728 35.668638150979845 139.73938922027946 27.728 35.668682993332894 139.73943420238697 27.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa5b9442-04de-439e-9d5b-782d7f3c0308">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa5b9442-04de-439e-9d5b-782d7f3c0308">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa5b9442-04de-439e-9d5b-782d7f3c0308">
											<gml:posList>35.66869732511011 139.73927243862298 24.11 35.66869697931832 139.73926825258422 24.11 35.66863953891488 139.7393543353236 24.11 35.668642945783965 139.73935392262786 24.11 35.66869732511011 139.73927243862298 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-90bf2e6d-7728-4754-98bc-32f16d4e3a36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90bf2e6d-7728-4754-98bc-32f16d4e3a36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90bf2e6d-7728-4754-98bc-32f16d4e3a36">
											<gml:posList>35.668642945783965 139.73935392262786 24.11 35.66863953891488 139.7393543353236 24.11 35.66869920239385 139.73941412381868 24.11 35.66870264533524 139.7394137331749 24.11 35.668642945783965 139.73935392262786 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d30546bc-3004-41f0-9c9a-cb6d2770c584">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d30546bc-3004-41f0-9c9a-cb6d2770c584">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d30546bc-3004-41f0-9c9a-cb6d2770c584">
											<gml:posList>35.668663014837364 139.73946367447982 27.728 35.6686632788875 139.7394670763457 27.728 35.66868577832411 139.7394338787908 27.728 35.668682993332894 139.73943420238697 27.728 35.668663014837364 139.73946367447982 27.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1133a86-d5a3-4f2b-8165-a3885f764ed5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1133a86-d5a3-4f2b-8165-a3885f764ed5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1133a86-d5a3-4f2b-8165-a3885f764ed5">
											<gml:posList>35.66866993602624 139.73946193215147 24.11 35.66866652012585 139.73946232276134 24.11 35.66868718688589 139.7394832307859 24.11 35.66868690424054 139.73947909990298 24.11 35.66866993602624 139.73946193215147 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b32f41b5-1f1e-408c-811a-a1069a40db74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b32f41b5-1f1e-408c-811a-a1069a40db74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b32f41b5-1f1e-408c-811a-a1069a40db74">
											<gml:posList>35.66866993602624 139.73946193215147 24.11 35.668698548716755 139.73941966969022 24.11 35.66869668139391 139.73941777196058 24.11 35.66866652012585 139.73946232276134 24.11 35.66866993602624 139.73946193215147 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-576c95f1-2b5e-45fe-9bc3-19787f29ee4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-576c95f1-2b5e-45fe-9bc3-19787f29ee4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-576c95f1-2b5e-45fe-9bc3-19787f29ee4b">
											<gml:posList>35.668698548716755 139.73941966969022 24.11 35.66870264533524 139.7394137331749 24.11 35.66869920239385 139.73941412381868 24.11 35.66869668139391 139.73941777196058 24.11 35.668698548716755 139.73941966969022 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44089683-a3a0-433e-83ca-5830a8c7d2e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44089683-a3a0-433e-83ca-5830a8c7d2e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44089683-a3a0-433e-83ca-5830a8c7d2e7">
											<gml:posList>35.66871766657039 139.73932690482812 23.906 35.66873129740337 139.73930646473377 23.906 35.66869732511011 139.73927243862298 23.906 35.668642945783965 139.73935392262786 23.906 35.66870264533524 139.7394137331749 23.906 35.668698548716755 139.73941966969022 23.906 35.66866993602624 139.73946193215147 23.906 35.66868690424054 139.73947909990298 23.906 35.668761833477014 139.73937260572916 23.906 35.66874621841858 139.73935686133663 23.906 35.66873368589833 139.73937556591216 23.906 35.66870652421169 139.73934822568094 23.906 35.668719542899765 139.7393287914995 23.906 35.66871766657039 139.73932690482812 23.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-831826e1-9e05-4e95-b782-0a71de4b1f7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-831826e1-9e05-4e95-b782-0a71de4b1f7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-831826e1-9e05-4e95-b782-0a71de4b1f7d">
											<gml:posList>35.66873129740337 139.73930646473377 24.11 35.66873471327733 139.73930604097885 24.11 35.66869697931832 139.73926825258422 24.11 35.66869732511011 139.73927243862298 24.11 35.66873129740337 139.73930646473377 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2df7801e-3722-4f84-9ee2-3d8d48b614d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2df7801e-3722-4f84-9ee2-3d8d48b614d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2df7801e-3722-4f84-9ee2-3d8d48b614d9">
											<gml:posList>35.66868690424054 139.73947909990298 24.11 35.66868718688589 139.7394832307859 24.11 35.668765294462915 139.7393722371542 24.11 35.668761833477014 139.73937260572916 24.11 35.66868690424054 139.73947909990298 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6f0633b7-08ad-4586-85b7-97e9143ba41f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f0633b7-08ad-4586-85b7-97e9143ba41f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f0633b7-08ad-4586-85b7-97e9143ba41f">
											<gml:posList>35.668765294462915 139.7393722371542 24.11 35.66868718688589 139.7394832307859 24.11 35.66871811935154 139.7395145100769 18.198 35.668765294462915 139.7393722371542 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c1d38efe-8ecb-4c11-9a11-f55e9fd03230">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1d38efe-8ecb-4c11-9a11-f55e9fd03230">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1d38efe-8ecb-4c11-9a11-f55e9fd03230">
											<gml:posList>35.66871766657039 139.73932690482812 24.11 35.668719542899765 139.7393287914995 24.11 35.66872056927438 139.73932726594398 24.11 35.66873471327733 139.73930604097885 24.11 35.66873129740337 139.73930646473377 24.11 35.66871766657039 139.73932690482812 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dda9fc81-8add-48c6-b955-1ec21fa08d41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dda9fc81-8add-48c6-b955-1ec21fa08d41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dda9fc81-8add-48c6-b955-1ec21fa08d41">
											<gml:posList>35.6687477579724 139.73935456195707 28.224 35.66872056927438 139.73932726594398 28.224 35.66870652421169 139.73934822568094 28.224 35.66873368589833 139.73937556591216 28.224 35.6687477579724 139.73935456195707 28.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5fe7e576-0afd-4705-94f3-c9437dccb9fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fe7e576-0afd-4705-94f3-c9437dccb9fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fe7e576-0afd-4705-94f3-c9437dccb9fc">
											<gml:posList>35.6687477579724 139.73935456195707 24.11 35.66874621841858 139.73935686133663 24.11 35.668761833477014 139.73937260572916 24.11 35.668765294462915 139.7393722371542 24.11 35.6687477579724 139.73935456195707 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4008762-2590-49f2-b24e-169e8b8ece3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4008762-2590-49f2-b24e-169e8b8ece3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4008762-2590-49f2-b24e-169e8b8ece3a">
											<gml:posList>35.66871811935154 139.7395145100769 18.198 35.668794107008345 139.73940130970797 18.198 35.668765294462915 139.7393722371542 24.11 35.66871811935154 139.7395145100769 18.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8971942d-13f3-446f-9bb0-70b5ee20c181">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8971942d-13f3-446f-9bb0-70b5ee20c181">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8971942d-13f3-446f-9bb0-70b5ee20c181">
											<gml:posList>35.668682993332894 139.73943420238697 27.154 35.668682993332894 139.73943420238697 27.728 35.668638150979845 139.73938922027946 27.728 35.668638150979845 139.73938922027946 27.154 35.668682993332894 139.73943420238697 27.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3158507-0ef8-4fd6-9e39-f54a180df680">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3158507-0ef8-4fd6-9e39-f54a180df680">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3158507-0ef8-4fd6-9e39-f54a180df680">
											<gml:posList>35.668618334923146 139.73941892414305 27.154 35.668618334923146 139.73941892414305 27.728 35.668663014837364 139.73946367447982 27.728 35.668663014837364 139.73946367447982 27.154 35.668618334923146 139.73941892414305 27.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13a175f3-04dc-401c-b9bc-5bc98f18b17a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13a175f3-04dc-401c-b9bc-5bc98f18b17a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13a175f3-04dc-401c-b9bc-5bc98f18b17a">
											<gml:posList>35.66867644799449 139.73924768688042 20.53 35.66869697931832 139.73926825258422 24.11 35.66873471327733 139.73930604097885 24.11 35.66873471327733 139.73930604097885 11.742 35.66867644799449 139.73924768688042 11.742 35.66867644799449 139.73924768688042 20.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03271ea8-2e08-422e-89b2-5d43368cf8b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03271ea8-2e08-422e-89b2-5d43368cf8b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03271ea8-2e08-422e-89b2-5d43368cf8b1">
											<gml:posList>35.66873129740337 139.73930646473377 23.906 35.66873129740337 139.73930646473377 24.11 35.66869732511011 139.73927243862298 24.11 35.66869732511011 139.73927243862298 23.906 35.66873129740337 139.73930646473377 23.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b30b464b-eb11-4657-81b0-2d1b01a35293">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b30b464b-eb11-4657-81b0-2d1b01a35293">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b30b464b-eb11-4657-81b0-2d1b01a35293">
											<gml:posList>35.668618827184474 139.73933358204167 20.53 35.66867644799449 139.73924768688042 20.53 35.66867644799449 139.73924768688042 11.742 35.668618827184474 139.73933358204167 11.742 35.668618827184474 139.73933358204167 20.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e73c4b48-09f6-4fcd-a4bb-1e6d13d72528">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e73c4b48-09f6-4fcd-a4bb-1e6d13d72528">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e73c4b48-09f6-4fcd-a4bb-1e6d13d72528">
											<gml:posList>35.66869732511011 139.73927243862298 23.906 35.66869732511011 139.73927243862298 24.11 35.668642945783965 139.73935392262786 24.11 35.668642945783965 139.73935392262786 23.906 35.66869732511011 139.73927243862298 23.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98351f75-9e7f-4d0e-9bf8-21b23edcfdf5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98351f75-9e7f-4d0e-9bf8-21b23edcfdf5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98351f75-9e7f-4d0e-9bf8-21b23edcfdf5">
											<gml:posList>35.66873471327733 139.73930604097885 24.11 35.66872056927438 139.73932726594398 24.11 35.66872056927438 139.73932726594398 11.742 35.66873471327733 139.73930604097885 11.742 35.66873471327733 139.73930604097885 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60827f11-177a-4042-949c-e5bd5bebc057">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60827f11-177a-4042-949c-e5bd5bebc057">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60827f11-177a-4042-949c-e5bd5bebc057">
											<gml:posList>35.66871766657039 139.73932690482812 23.906 35.66871766657039 139.73932690482812 24.11 35.66873129740337 139.73930646473377 24.11 35.66873129740337 139.73930646473377 23.906 35.66871766657039 139.73932690482812 23.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78a70bb6-60b9-4549-b3f3-665c254b681a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78a70bb6-60b9-4549-b3f3-665c254b681a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78a70bb6-60b9-4549-b3f3-665c254b681a">
											<gml:posList>35.668719542899765 139.7393287914995 23.906 35.668719542899765 139.7393287914995 24.11 35.66871766657039 139.73932690482812 24.11 35.66871766657039 139.73932690482812 23.906 35.668719542899765 139.7393287914995 23.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a3ee202-cc87-40dc-bc27-b0980c09a231">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a3ee202-cc87-40dc-bc27-b0980c09a231">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a3ee202-cc87-40dc-bc27-b0980c09a231">
											<gml:posList>35.66872056927438 139.73932726594398 28.224 35.66872056927438 139.73932726594398 24.11 35.668719542899765 139.7393287914995 24.11 35.668719542899765 139.7393287914995 23.906 35.66870652421169 139.73934822568094 23.906 35.66870652421169 139.73934822568094 28.224 35.66872056927438 139.73932726594398 28.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46cdb94e-9faf-4321-8f32-22d3e019444f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46cdb94e-9faf-4321-8f32-22d3e019444f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46cdb94e-9faf-4321-8f32-22d3e019444f">
											<gml:posList>35.66873368589833 139.73937556591216 28.224 35.66870652421169 139.73934822568094 28.224 35.66870652421169 139.73934822568094 23.906 35.66873368589833 139.73937556591216 23.906 35.66873368589833 139.73937556591216 28.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4504102-8ea0-404a-80ac-90cecaff26a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4504102-8ea0-404a-80ac-90cecaff26a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4504102-8ea0-404a-80ac-90cecaff26a9">
											<gml:posList>35.66858452747623 139.73938818955085 19.556 35.66861648913435 139.73934065423308 19.556 35.66861648913435 139.73934065423308 11.742 35.66858452747623 139.73938818955085 11.742 35.66858452747623 139.73938818955085 19.556</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d95ac09-4566-476d-8b83-1be0e51778ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d95ac09-4566-476d-8b83-1be0e51778ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d95ac09-4566-476d-8b83-1be0e51778ac">
											<gml:posList>35.66872056927438 139.73932726594398 24.11 35.66872056927438 139.73932726594398 28.224 35.6687477579724 139.73935456195707 28.224 35.6687477579724 139.73935456195707 24.11 35.668765294462915 139.7393722371542 24.11 35.668794107008345 139.73940130970797 18.198 35.668794107008345 139.73940130970797 11.742 35.66872056927438 139.73932726594398 11.742 35.66872056927438 139.73932726594398 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1df2afe2-27cb-4d18-a944-0e903b0023d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1df2afe2-27cb-4d18-a944-0e903b0023d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1df2afe2-27cb-4d18-a944-0e903b0023d0">
											<gml:posList>35.668761833477014 139.73937260572916 23.906 35.668761833477014 139.73937260572916 24.11 35.66874621841858 139.73935686133663 24.11 35.66874621841858 139.73935686133663 23.906 35.668761833477014 139.73937260572916 23.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfdadcac-70b1-4e05-bb9c-cb43599b8138">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfdadcac-70b1-4e05-bb9c-cb43599b8138">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfdadcac-70b1-4e05-bb9c-cb43599b8138">
											<gml:posList>35.66873368589833 139.73937556591216 23.906 35.66874621841858 139.73935686133663 23.906 35.66874621841858 139.73935686133663 24.11 35.6687477579724 139.73935456195707 24.11 35.6687477579724 139.73935456195707 28.224 35.66873368589833 139.73937556591216 28.224 35.66873368589833 139.73937556591216 23.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-961f68da-9f03-46a8-923d-2a74778d158f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-961f68da-9f03-46a8-923d-2a74778d158f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-961f68da-9f03-46a8-923d-2a74778d158f">
											<gml:posList>35.668619619250755 139.73934366612642 22.27 35.668619619250755 139.73934366612642 19.556 35.66858776593713 139.7393914332842 19.556 35.66858776593713 139.7393914332842 22.27 35.668619619250755 139.73934366612642 22.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da43f157-364e-49ff-838f-ab3c37f56ccf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da43f157-364e-49ff-838f-ab3c37f56ccf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da43f157-364e-49ff-838f-ab3c37f56ccf">
											<gml:posList>35.66869920239385 139.73941412381868 24.11 35.66863953891488 139.7393543353236 24.11 35.668618827184474 139.73933358204167 20.53 35.668618827184474 139.73933358204167 11.742 35.66869920239385 139.73941412381868 11.742 35.66869920239385 139.73941412381868 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-758696d4-ac4c-4e89-9fe2-66d0bf07a7e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-758696d4-ac4c-4e89-9fe2-66d0bf07a7e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-758696d4-ac4c-4e89-9fe2-66d0bf07a7e6">
											<gml:posList>35.66861648913435 139.73934065423308 11.742 35.66861648913435 139.73934065423308 19.556 35.668619619250755 139.73934366612642 19.556 35.668619619250755 139.73934366612642 22.27 35.66863398890856 139.73935747889792 22.27 35.66863398890856 139.73935747889792 24.907 35.66869668139391 139.73941777196058 24.907 35.66869668139391 139.73941777196058 24.11 35.66869668139391 139.73941777196058 11.742 35.66861648913435 139.73934065423308 11.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f020602-3caa-440b-b92d-8dcd0e5991fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f020602-3caa-440b-b92d-8dcd0e5991fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f020602-3caa-440b-b92d-8dcd0e5991fb">
											<gml:posList>35.66863398890856 139.73935747889792 24.907 35.66863398890856 139.73935747889792 22.27 35.66860190149979 139.73940558875944 22.27 35.66860190149979 139.73940558875944 24.907 35.66863398890856 139.73935747889792 24.907</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73f7be7f-b4d3-4a5f-af0c-2d484af4a160">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73f7be7f-b4d3-4a5f-af0c-2d484af4a160">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73f7be7f-b4d3-4a5f-af0c-2d484af4a160">
											<gml:posList>35.668642945783965 139.73935392262786 23.906 35.668642945783965 139.73935392262786 24.11 35.66870264533524 139.7394137331749 24.11 35.66870264533524 139.7394137331749 23.906 35.668642945783965 139.73935392262786 23.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0431c06d-d796-4e53-a0d2-f5ff8c7f3bf9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0431c06d-d796-4e53-a0d2-f5ff8c7f3bf9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0431c06d-d796-4e53-a0d2-f5ff8c7f3bf9">
											<gml:posList>35.66863785988634 139.73938581844655 27.728 35.66863785988634 139.73938581844655 24.907 35.668615549949166 139.7394192698315 24.907 35.668615549949166 139.7394192698315 27.728 35.66863785988634 139.73938581844655 27.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eba35a83-a84b-4496-ae33-280d6f827f0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eba35a83-a84b-4496-ae33-280d6f827f0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eba35a83-a84b-4496-ae33-280d6f827f0e">
											<gml:posList>35.668638150979845 139.73938922027946 27.154 35.668638150979845 139.73938922027946 27.728 35.668618334923146 139.73941892414305 27.728 35.668618334923146 139.73941892414305 27.154 35.668638150979845 139.73938922027946 27.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afd78a21-72cc-40f0-89a3-a5604e1b93d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afd78a21-72cc-40f0-89a3-a5604e1b93d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afd78a21-72cc-40f0-89a3-a5604e1b93d0">
											<gml:posList>35.66868577832411 139.7394338787908 27.728 35.66868577832411 139.7394338787908 24.907 35.66863785988634 139.73938581844655 24.907 35.66863785988634 139.73938581844655 27.728 35.66868577832411 139.7394338787908 27.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d833328-26a4-43f3-8991-a1a77772fc4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d833328-26a4-43f3-8991-a1a77772fc4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d833328-26a4-43f3-8991-a1a77772fc4d">
											<gml:posList>35.66869668139391 139.73941777196058 24.11 35.66869920239385 139.73941412381868 24.11 35.66869920239385 139.73941412381868 11.742 35.66869668139391 139.73941777196058 11.742 35.66869668139391 139.73941777196058 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77afb18a-e66e-46d0-a1ec-ba3b535502a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77afb18a-e66e-46d0-a1ec-ba3b535502a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77afb18a-e66e-46d0-a1ec-ba3b535502a5">
											<gml:posList>35.66870264533524 139.7394137331749 23.906 35.66870264533524 139.7394137331749 24.11 35.668698548716755 139.73941966969022 24.11 35.668698548716755 139.73941966969022 23.906 35.66870264533524 139.7394137331749 23.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aed834a4-b51f-4ecb-a4d6-ed9977792c24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aed834a4-b51f-4ecb-a4d6-ed9977792c24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aed834a4-b51f-4ecb-a4d6-ed9977792c24">
											<gml:posList>35.66868690424054 139.73947909990298 23.906 35.66868690424054 139.73947909990298 24.11 35.668761833477014 139.73937260572916 24.11 35.668761833477014 139.73937260572916 23.906 35.66868690424054 139.73947909990298 23.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac9836b9-82e4-4251-ac10-88cade1703ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac9836b9-82e4-4251-ac10-88cade1703ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac9836b9-82e4-4251-ac10-88cade1703ac">
											<gml:posList>35.6686632788875 139.7394670763457 27.728 35.668615549949166 139.7394192698315 27.728 35.668615549949166 139.7394192698315 24.907 35.66860190149979 139.73940558875944 24.907 35.66860190149979 139.73940558875944 22.27 35.66858776593713 139.7393914332842 22.27 35.66858776593713 139.7393914332842 19.556 35.66858452747623 139.73938818955085 19.556 35.66858452747623 139.73938818955085 11.742 35.6686632788875 139.7394670763457 11.742 35.6686632788875 139.7394670763457 27.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc30afdb-85ce-434d-afdb-d6df2498ce08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc30afdb-85ce-434d-afdb-d6df2498ce08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc30afdb-85ce-434d-afdb-d6df2498ce08">
											<gml:posList>35.668698548716755 139.73941966969022 23.906 35.668698548716755 139.73941966969022 24.11 35.66866993602624 139.73946193215147 24.11 35.66866993602624 139.73946193215147 23.906 35.668698548716755 139.73941966969022 23.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-617ff41b-6a5d-4312-a446-43e2941fadfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-617ff41b-6a5d-4312-a446-43e2941fadfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-617ff41b-6a5d-4312-a446-43e2941fadfa">
											<gml:posList>35.66866652012585 139.73946232276134 24.11 35.66869668139391 139.73941777196058 24.11 35.66869668139391 139.73941777196058 24.907 35.66868577832411 139.7394338787908 24.907 35.66868577832411 139.7394338787908 27.728 35.6686632788875 139.7394670763457 27.728 35.6686632788875 139.7394670763457 11.742 35.66866652012585 139.73946232276134 11.742 35.66866652012585 139.73946232276134 24.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8c33eac-c5d3-4c6b-b659-f5f44dc47362">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8c33eac-c5d3-4c6b-b659-f5f44dc47362">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8c33eac-c5d3-4c6b-b659-f5f44dc47362">
											<gml:posList>35.668663014837364 139.73946367447982 27.154 35.668663014837364 139.73946367447982 27.728 35.668682993332894 139.73943420238697 27.728 35.668682993332894 139.73943420238697 27.154 35.668663014837364 139.73946367447982 27.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c951da32-d694-4bf2-a9cf-6d870146eb12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c951da32-d694-4bf2-a9cf-6d870146eb12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c951da32-d694-4bf2-a9cf-6d870146eb12">
											<gml:posList>35.668794107008345 139.73940130970797 18.198 35.66871811935154 139.7395145100769 18.198 35.66871811935154 139.7395145100769 11.742 35.668794107008345 139.73940130970797 11.742 35.668794107008345 139.73940130970797 18.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0760dc6-0c56-4288-a8b4-7eeff044186d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0760dc6-0c56-4288-a8b4-7eeff044186d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0760dc6-0c56-4288-a8b4-7eeff044186d">
											<gml:posList>35.66866993602624 139.73946193215147 23.906 35.66866993602624 139.73946193215147 24.11 35.66868690424054 139.73947909990298 24.11 35.66868690424054 139.73947909990298 23.906 35.66866993602624 139.73946193215147 23.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27e50d35-66dc-4cef-99c7-74c9f0bf0f79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27e50d35-66dc-4cef-99c7-74c9f0bf0f79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27e50d35-66dc-4cef-99c7-74c9f0bf0f79">
											<gml:posList>35.66871811935154 139.7395145100769 18.198 35.66868718688589 139.7394832307859 24.11 35.66866652012585 139.73946232276134 24.11 35.66866652012585 139.73946232276134 11.742 35.66871811935154 139.7395145100769 11.742 35.66871811935154 139.7395145100769 18.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4606</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">216.91195</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>