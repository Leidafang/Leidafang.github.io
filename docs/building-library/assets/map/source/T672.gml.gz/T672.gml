<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c41dda3b-1cec-4fd8-84f1-2a34c41bf81f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.85</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">10.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67464959768018 139.741624575685 0 35.674650453039966 139.7416825264708 0 35.67468095496916 139.74168185088115 0 35.67470316440512 139.74168135047458 0 35.67474081410192 139.74168052310273 0 35.67473978773457 139.7416110726657 0 35.67469506238867 139.74161206282184 0 35.67469494834171 139.7416043412013 0 35.67467915656284 139.74160469067672 0 35.67464931262703 139.74160535449593 0 35.67464959768018 139.741624575685 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67464959768018 139.741624575685 9.457 35.67464931262703 139.74160535449593 9.457 35.67467915656284 139.74160469067672 9.457 35.67469494834171 139.7416043412013 9.457 35.67469506238867 139.74161206282184 9.457 35.67473978773457 139.7416110726657 9.457 35.67474081410192 139.74168052310273 9.457 35.67470316440512 139.74168135047458 9.457 35.67468095496916 139.74168185088115 9.457 35.674650453039966 139.7416825264708 9.457 35.67464959768018 139.741624575685 9.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67464959768018 139.741624575685 9.457 35.674650453039966 139.7416825264708 9.457 35.674650453039966 139.7416825264708 18.38 35.67464959768018 139.741624575685 18.38 35.67464959768018 139.741624575685 9.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674650453039966 139.7416825264708 9.457 35.67468095496916 139.74168185088115 9.457 35.67468095496916 139.74168185088115 18.38 35.674650453039966 139.7416825264708 18.38 35.674650453039966 139.7416825264708 9.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67468095496916 139.74168185088115 9.457 35.67470316440512 139.74168135047458 9.457 35.67470316440512 139.74168135047458 18.38 35.67468095496916 139.74168185088115 18.38 35.67468095496916 139.74168185088115 9.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67470316440512 139.74168135047458 9.457 35.67474081410192 139.74168052310273 9.457 35.67474081410192 139.74168052310273 18.38 35.67470316440512 139.74168135047458 18.38 35.67470316440512 139.74168135047458 9.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67474081410192 139.74168052310273 9.457 35.67473978773457 139.7416110726657 9.457 35.67473978773457 139.7416110726657 18.38 35.67474081410192 139.74168052310273 18.38 35.67474081410192 139.74168052310273 9.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67473978773457 139.7416110726657 9.457 35.67469506238867 139.74161206282184 9.457 35.67469506238867 139.74161206282184 18.38 35.67473978773457 139.7416110726657 18.38 35.67473978773457 139.7416110726657 9.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67469506238867 139.74161206282184 9.457 35.67469494834171 139.7416043412013 9.457 35.67469494834171 139.7416043412013 18.38 35.67469506238867 139.74161206282184 18.38 35.67469506238867 139.74161206282184 9.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67469494834171 139.7416043412013 9.457 35.67467915656284 139.74160469067672 9.457 35.67467915656284 139.74160469067672 18.38 35.67469494834171 139.7416043412013 18.38 35.67469494834171 139.7416043412013 9.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67467915656284 139.74160469067672 9.457 35.67464931262703 139.74160535449593 9.457 35.67464931262703 139.74160535449593 18.38 35.67467915656284 139.74160469067672 18.38 35.67467915656284 139.74160469067672 9.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67464931262703 139.74160535449593 9.457 35.67464959768018 139.741624575685 9.457 35.67464959768018 139.741624575685 18.38 35.67464931262703 139.74160535449593 18.38 35.67464931262703 139.74160535449593 9.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67464959768018 139.741624575685 18.38 35.674650453039966 139.7416825264708 18.38 35.67468095496916 139.74168185088115 18.38 35.67470316440512 139.74168135047458 18.38 35.67474081410192 139.74168052310273 18.38 35.67473978773457 139.7416110726657 18.38 35.67469506238867 139.74161206282184 18.38 35.67469494834171 139.7416043412013 18.38 35.67467915656284 139.74160469067672 18.38 35.67464931262703 139.74160535449593 18.38 35.67464959768018 139.741624575685 18.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9584b2ab-c7c7-429c-afc6-b2e299f5d6f3"/>
							<gml:surfaceMember xlink:href="#poly-d1faf75c-ec4e-4713-94ba-b94aaeed6db0"/>
							<gml:surfaceMember xlink:href="#poly-d743dda5-3d43-47b9-aff9-793546a4ab64"/>
							<gml:surfaceMember xlink:href="#poly-04801b10-c014-48ae-8e72-6bdd8d253c73"/>
							<gml:surfaceMember xlink:href="#poly-490b28a5-39a2-4f57-a8e5-87320b6261db"/>
							<gml:surfaceMember xlink:href="#poly-71e7c1e7-12d2-45a7-9e40-135f7ea0b1a7"/>
							<gml:surfaceMember xlink:href="#poly-c850c3f2-d63c-477d-b87b-a81f43313663"/>
							<gml:surfaceMember xlink:href="#poly-adb32347-8434-4dd1-9856-8068ce6a77ce"/>
							<gml:surfaceMember xlink:href="#poly-3ce8f290-013f-47ab-b910-e8e5ed8ad2ca"/>
							<gml:surfaceMember xlink:href="#poly-e501d0c6-606c-4618-a34b-bbe218fdddce"/>
							<gml:surfaceMember xlink:href="#poly-2dd701bb-40fb-4ceb-ae20-08ce2b16247c"/>
							<gml:surfaceMember xlink:href="#poly-c4aa21e8-9cb9-4409-ac6a-94b6cb48f4ef"/>
							<gml:surfaceMember xlink:href="#poly-e9c9923c-45a2-457a-8497-23a171da795a"/>
							<gml:surfaceMember xlink:href="#poly-527f0562-64f5-433c-966e-5dcba79b89cd"/>
							<gml:surfaceMember xlink:href="#poly-d64b6da9-65ea-417c-80d5-b5d479b690b3"/>
							<gml:surfaceMember xlink:href="#poly-ca87abd4-0cba-482d-81e0-365fbb3a5dc4"/>
							<gml:surfaceMember xlink:href="#poly-648ce1f2-6834-40b8-9a8b-7d5079012957"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9584b2ab-c7c7-429c-afc6-b2e299f5d6f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9584b2ab-c7c7-429c-afc6-b2e299f5d6f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9584b2ab-c7c7-429c-afc6-b2e299f5d6f3">
											<gml:posList>35.67464931262699 139.74160535449593 9.457 35.67469494834171 139.7416043412013 9.457 35.67469506238867 139.74161206282184 9.457 35.674739787734566 139.7416110726657 9.457 35.6747408141019 139.7416805231027 9.457 35.67465045303996 139.7416825264708 9.457 35.67464931262699 139.74160535449593 9.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1faf75c-ec4e-4713-94ba-b94aaeed6db0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1faf75c-ec4e-4713-94ba-b94aaeed6db0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1faf75c-ec4e-4713-94ba-b94aaeed6db0">
											<gml:posList>35.67469522391859 139.74162295483518 17.328 35.67469494834171 139.7416043412013 17.328 35.67467914754911 139.741604690687 19.271 35.674679513422966 139.74162351410408 19.271 35.67469522391859 139.74162295483518 17.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d743dda5-3d43-47b9-aff9-793546a4ab64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d743dda5-3d43-47b9-aff9-793546a4ab64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d743dda5-3d43-47b9-aff9-793546a4ab64">
											<gml:posList>35.674679513422966 139.74162351410408 19.271 35.67467914754911 139.741604690687 19.271 35.67464931262699 139.74160535449593 17.328 35.67464959768018 139.741624575685 17.328 35.674679513422966 139.74162351410408 19.271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-04801b10-c014-48ae-8e72-6bdd8d253c73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04801b10-c014-48ae-8e72-6bdd8d253c73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04801b10-c014-48ae-8e72-6bdd8d253c73">
											<gml:posList>35.674739787734566 139.7416110726657 17.252 35.67469506238867 139.74161206282184 17.252 35.67469522391859 139.74162295483518 17.252 35.67464959768018 139.741624575685 17.252 35.67469577470308 139.74163603368044 17.252 35.67471622652298 139.74163561259954 17.252 35.67471659864121 139.7416626438331 17.252 35.67469614682963 139.74166307595397 17.252 35.67465045303996 139.7416825264708 17.252 35.6747408141019 139.7416805231027 17.252 35.674739787734566 139.7416110726657 17.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-490b28a5-39a2-4f57-a8e5-87320b6261db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-490b28a5-39a2-4f57-a8e5-87320b6261db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-490b28a5-39a2-4f57-a8e5-87320b6261db">
											<gml:posList>35.67469614682963 139.74166307595397 19.871 35.67471659864121 139.7416626438331 19.871 35.67471622652298 139.74163561259954 19.871 35.67469577470308 139.74163603368044 19.871 35.67469614682963 139.74166307595397 19.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71e7c1e7-12d2-45a7-9e40-135f7ea0b1a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71e7c1e7-12d2-45a7-9e40-135f7ea0b1a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71e7c1e7-12d2-45a7-9e40-135f7ea0b1a7">
											<gml:posList>35.67464959768018 139.741624575685 17.252 35.67465045303996 139.7416825264708 17.252 35.67469614682963 139.74166307595397 17.252 35.67469577470308 139.74163603368044 17.252 35.67464959768018 139.741624575685 17.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c850c3f2-d63c-477d-b87b-a81f43313663">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c850c3f2-d63c-477d-b87b-a81f43313663">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c850c3f2-d63c-477d-b87b-a81f43313663">
											<gml:posList>35.67465045303996 139.7416825264708 9.457 35.67465045303996 139.7416825264708 17.252 35.67464959768018 139.741624575685 17.252 35.67464959768018 139.741624575685 17.328 35.67464931262699 139.74160535449593 17.328 35.67464931262699 139.74160535449593 9.457 35.67465045303996 139.7416825264708 9.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-adb32347-8434-4dd1-9856-8068ce6a77ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adb32347-8434-4dd1-9856-8068ce6a77ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adb32347-8434-4dd1-9856-8068ce6a77ce">
											<gml:posList>35.67464931262699 139.74160535449593 17.328 35.67467914754911 139.741604690687 19.271 35.67469494834171 139.7416043412013 17.328 35.67469494834171 139.7416043412013 9.457 35.67464931262699 139.74160535449593 9.457 35.67464931262699 139.74160535449593 17.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ce8f290-013f-47ab-b910-e8e5ed8ad2ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ce8f290-013f-47ab-b910-e8e5ed8ad2ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ce8f290-013f-47ab-b910-e8e5ed8ad2ca">
											<gml:posList>35.674739787734566 139.7416110726657 9.457 35.67469506238867 139.74161206282184 9.457 35.67469506238867 139.74161206282184 17.252 35.674739787734566 139.7416110726657 17.252 35.674739787734566 139.7416110726657 9.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e501d0c6-606c-4618-a34b-bbe218fdddce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e501d0c6-606c-4618-a34b-bbe218fdddce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e501d0c6-606c-4618-a34b-bbe218fdddce">
											<gml:posList>35.67469522391859 139.74162295483518 17.328 35.67469522391859 139.74162295483518 17.252 35.67469506238867 139.74161206282184 17.252 35.67469506238867 139.74161206282184 9.457 35.67469494834171 139.7416043412013 9.457 35.67469494834171 139.7416043412013 17.328 35.67469522391859 139.74162295483518 17.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2dd701bb-40fb-4ceb-ae20-08ce2b16247c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dd701bb-40fb-4ceb-ae20-08ce2b16247c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dd701bb-40fb-4ceb-ae20-08ce2b16247c">
											<gml:posList>35.67464959768018 139.741624575685 17.252 35.67469522391859 139.74162295483518 17.252 35.67469522391859 139.74162295483518 17.328 35.674679513422966 139.74162351410408 19.271 35.67464959768018 139.741624575685 17.328 35.67464959768018 139.741624575685 17.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4aa21e8-9cb9-4409-ac6a-94b6cb48f4ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4aa21e8-9cb9-4409-ac6a-94b6cb48f4ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4aa21e8-9cb9-4409-ac6a-94b6cb48f4ef">
											<gml:posList>35.67469577470308 139.74163603368044 19.871 35.67471622652298 139.74163561259954 19.871 35.67471622652298 139.74163561259954 17.252 35.67469577470308 139.74163603368044 17.252 35.67469577470308 139.74163603368044 19.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9c9923c-45a2-457a-8497-23a171da795a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9c9923c-45a2-457a-8497-23a171da795a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9c9923c-45a2-457a-8497-23a171da795a">
											<gml:posList>35.6747408141019 139.7416805231027 9.457 35.674739787734566 139.7416110726657 9.457 35.674739787734566 139.7416110726657 17.252 35.6747408141019 139.7416805231027 17.252 35.6747408141019 139.7416805231027 9.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-527f0562-64f5-433c-966e-5dcba79b89cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-527f0562-64f5-433c-966e-5dcba79b89cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-527f0562-64f5-433c-966e-5dcba79b89cd">
											<gml:posList>35.67471622652298 139.74163561259954 19.871 35.67471659864121 139.7416626438331 19.871 35.67471659864121 139.7416626438331 17.252 35.67471622652298 139.74163561259954 17.252 35.67471622652298 139.74163561259954 19.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d64b6da9-65ea-417c-80d5-b5d479b690b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d64b6da9-65ea-417c-80d5-b5d479b690b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d64b6da9-65ea-417c-80d5-b5d479b690b3">
											<gml:posList>35.67469614682963 139.74166307595397 19.871 35.67469577470308 139.74163603368044 19.871 35.67469577470308 139.74163603368044 17.252 35.67469614682963 139.74166307595397 17.252 35.67469614682963 139.74166307595397 19.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca87abd4-0cba-482d-81e0-365fbb3a5dc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca87abd4-0cba-482d-81e0-365fbb3a5dc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca87abd4-0cba-482d-81e0-365fbb3a5dc4">
											<gml:posList>35.67471659864121 139.7416626438331 19.871 35.67469614682963 139.74166307595397 19.871 35.67469614682963 139.74166307595397 17.252 35.67471659864121 139.7416626438331 17.252 35.67471659864121 139.7416626438331 19.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-648ce1f2-6834-40b8-9a8b-7d5079012957">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-648ce1f2-6834-40b8-9a8b-7d5079012957">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-648ce1f2-6834-40b8-9a8b-7d5079012957">
											<gml:posList>35.67465045303996 139.7416825264708 9.457 35.6747408141019 139.7416805231027 9.457 35.6747408141019 139.7416805231027 17.252 35.67465045303996 139.7416825264708 17.252 35.67465045303996 139.7416825264708 9.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4610</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">259.07944</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.32</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>