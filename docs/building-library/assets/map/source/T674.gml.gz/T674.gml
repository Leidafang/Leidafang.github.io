<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c46c5bf4-66c9-47b7-974d-9a6f2c106dc9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>8</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101008003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">34.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67147366874015 139.74518991381683 0 35.671465455497426 139.7451752311219 0 35.671414269280675 139.74519130468863 0 35.67146890343711 139.745452934076 0 35.671508548565534 139.74541965195635 0 35.671522258384186 139.7454442593872 0 35.67159153148305 139.74538607924293 0 35.6715876504994 139.74537912425163 0 35.671591343866126 139.74537602720034 0 35.671482947132645 139.74518206066378 0 35.67147366874015 139.74518991381683 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67147366874015 139.74518991381683 7.19 35.671482947132645 139.74518206066378 7.19 35.671591343866126 139.74537602720034 7.19 35.6715876504994 139.74537912425163 7.19 35.67159153148305 139.74538607924293 7.19 35.671522258384186 139.7454442593872 7.19 35.671508548565534 139.74541965195635 7.19 35.67146890343711 139.745452934076 7.19 35.671414269280675 139.74519130468863 7.19 35.671465455497426 139.7451752311219 7.19 35.67147366874015 139.74518991381683 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67147366874015 139.74518991381683 7.19 35.671465455497426 139.7451752311219 7.19 35.671465455497426 139.7451752311219 41.37 35.67147366874015 139.74518991381683 41.37 35.67147366874015 139.74518991381683 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671465455497426 139.7451752311219 7.19 35.671414269280675 139.74519130468863 7.19 35.671414269280675 139.74519130468863 41.37 35.671465455497426 139.7451752311219 41.37 35.671465455497426 139.7451752311219 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671414269280675 139.74519130468863 7.19 35.67146890343711 139.745452934076 7.19 35.67146890343711 139.745452934076 41.37 35.671414269280675 139.74519130468863 41.37 35.671414269280675 139.74519130468863 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67146890343711 139.745452934076 7.19 35.671508548565534 139.74541965195635 7.19 35.671508548565534 139.74541965195635 41.37 35.67146890343711 139.745452934076 41.37 35.67146890343711 139.745452934076 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671508548565534 139.74541965195635 7.19 35.671522258384186 139.7454442593872 7.19 35.671522258384186 139.7454442593872 41.37 35.671508548565534 139.74541965195635 41.37 35.671508548565534 139.74541965195635 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671522258384186 139.7454442593872 7.19 35.67159153148305 139.74538607924293 7.19 35.67159153148305 139.74538607924293 41.37 35.671522258384186 139.7454442593872 41.37 35.671522258384186 139.7454442593872 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67159153148305 139.74538607924293 7.19 35.6715876504994 139.74537912425163 7.19 35.6715876504994 139.74537912425163 41.37 35.67159153148305 139.74538607924293 41.37 35.67159153148305 139.74538607924293 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715876504994 139.74537912425163 7.19 35.671591343866126 139.74537602720034 7.19 35.671591343866126 139.74537602720034 41.37 35.6715876504994 139.74537912425163 41.37 35.6715876504994 139.74537912425163 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671591343866126 139.74537602720034 7.19 35.671482947132645 139.74518206066378 7.19 35.671482947132645 139.74518206066378 41.37 35.671591343866126 139.74537602720034 41.37 35.671591343866126 139.74537602720034 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671482947132645 139.74518206066378 7.19 35.67147366874015 139.74518991381683 7.19 35.67147366874015 139.74518991381683 41.37 35.671482947132645 139.74518206066378 41.37 35.671482947132645 139.74518206066378 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67147366874015 139.74518991381683 41.37 35.671465455497426 139.7451752311219 41.37 35.671414269280675 139.74519130468863 41.37 35.67146890343711 139.745452934076 41.37 35.671508548565534 139.74541965195635 41.37 35.671522258384186 139.7454442593872 41.37 35.67159153148305 139.74538607924293 41.37 35.6715876504994 139.74537912425163 41.37 35.671591343866126 139.74537602720034 41.37 35.671482947132645 139.74518206066378 41.37 35.67147366874015 139.74518991381683 41.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-22e9761b-38c2-4c3f-babe-c4d8078b2f22"/>
							<gml:surfaceMember xlink:href="#poly-e3b4091d-de50-4e92-822b-2c2fcc73b0a9"/>
							<gml:surfaceMember xlink:href="#poly-feb0023a-3e71-43e7-884c-4facc6cd2598"/>
							<gml:surfaceMember xlink:href="#poly-71ea1659-0283-4efb-90e8-203d25637ade"/>
							<gml:surfaceMember xlink:href="#poly-76cfbe3d-aad9-44e3-b738-fecafe307009"/>
							<gml:surfaceMember xlink:href="#poly-fb2fd849-2b71-4e5d-a25f-47819640a40d"/>
							<gml:surfaceMember xlink:href="#poly-6e39cb91-182d-4866-87c1-296ef7d1da14"/>
							<gml:surfaceMember xlink:href="#poly-19ef6e5c-8739-4eff-9927-fdfe0ee34128"/>
							<gml:surfaceMember xlink:href="#poly-0adb3c6e-3746-41b8-8d95-27a54d511d74"/>
							<gml:surfaceMember xlink:href="#poly-7d26033f-b28e-4664-bed0-352c071551e0"/>
							<gml:surfaceMember xlink:href="#poly-46765698-1632-46c9-8735-9da71492f1f8"/>
							<gml:surfaceMember xlink:href="#poly-11fec2f5-fe00-4a0e-9102-0f452212d56e"/>
							<gml:surfaceMember xlink:href="#poly-83b4e6b6-38dc-4549-b7bf-5433d9c316f1"/>
							<gml:surfaceMember xlink:href="#poly-2b645ed5-1a92-42a7-ad11-a57241875fca"/>
							<gml:surfaceMember xlink:href="#poly-ba5c2c3f-d8b2-4fb5-8b71-37e0a78f07f4"/>
							<gml:surfaceMember xlink:href="#poly-66425c8e-c8cf-4066-9987-973b9e96d58e"/>
							<gml:surfaceMember xlink:href="#poly-e4c8f995-2291-46b8-85e1-8527f611d52c"/>
							<gml:surfaceMember xlink:href="#poly-0dd8d03c-9e54-4d26-8d70-05c0f42799e9"/>
							<gml:surfaceMember xlink:href="#poly-416eaf0b-4f4b-4786-ac73-a293ac8fcfc1"/>
							<gml:surfaceMember xlink:href="#poly-53d67a23-531a-4afa-8777-978e92e5f575"/>
							<gml:surfaceMember xlink:href="#poly-31bd0852-3450-4756-af0e-1fe7dfbbf110"/>
							<gml:surfaceMember xlink:href="#poly-0ffc0f95-bd33-4066-a3d9-5cedcae717db"/>
							<gml:surfaceMember xlink:href="#poly-fedc084e-c4b4-4384-af8e-0b8401822e2e"/>
							<gml:surfaceMember xlink:href="#poly-6dcec95e-4886-41f2-a034-b849b663aa89"/>
							<gml:surfaceMember xlink:href="#poly-78c1432b-76f8-49cc-940d-517ecdb12367"/>
							<gml:surfaceMember xlink:href="#poly-f97be01f-569b-4c5a-9aca-39f5328607b4"/>
							<gml:surfaceMember xlink:href="#poly-ae727b93-a76a-42cd-81a6-1ab322b40410"/>
							<gml:surfaceMember xlink:href="#poly-13098984-92a9-4830-a229-e02eb83cc73f"/>
							<gml:surfaceMember xlink:href="#poly-53d41942-1256-4e8a-9045-e97aad3cc86a"/>
							<gml:surfaceMember xlink:href="#poly-6f3f49b3-ee40-41ee-bf07-3f2602ad4b55"/>
							<gml:surfaceMember xlink:href="#poly-393bb9b3-2646-4850-98b1-590124f31ca7"/>
							<gml:surfaceMember xlink:href="#poly-d67e11af-8d8c-4d89-b92c-51c21d887f8d"/>
							<gml:surfaceMember xlink:href="#poly-220cfefc-bed0-4ddf-994f-8e5c59ffe9d7"/>
							<gml:surfaceMember xlink:href="#poly-b419d4d4-8c96-434c-9821-6cbebb2eb85c"/>
							<gml:surfaceMember xlink:href="#poly-2c9eff97-eb13-47f0-b08f-a87c92eb785c"/>
							<gml:surfaceMember xlink:href="#poly-27a1d919-3b7b-426c-9fa3-2af3698d0130"/>
							<gml:surfaceMember xlink:href="#poly-fa79a8e8-08aa-4a5c-bda2-44ee6675273b"/>
							<gml:surfaceMember xlink:href="#poly-a5ce2e4b-89ba-411a-b49c-216dfce55a34"/>
							<gml:surfaceMember xlink:href="#poly-db1b916f-5000-49ca-9a01-72f27e997a9b"/>
							<gml:surfaceMember xlink:href="#poly-4d192b95-da4b-4c06-a815-46918783df34"/>
							<gml:surfaceMember xlink:href="#poly-7a9a8a0e-df52-440a-b6d6-179c7ecc65db"/>
							<gml:surfaceMember xlink:href="#poly-5b1d33a3-b4d3-4927-8bef-5cd4a20e94aa"/>
							<gml:surfaceMember xlink:href="#poly-5c1ea7cf-b807-42fe-bca9-85fc229528a1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c46c5bf4-66c9-47b7-974d-9a6f2c106dc9_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60766671-03c8-4aa8-82d1-aab656981543">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6714333377184 139.7452589098167 41.614 35.67144593985981 139.74524788270526 41.614 35.6714539992383 139.74526171499969 41.614 35.671441397095634 139.74527274211007 41.614 35.6714333377184 139.7452589098167 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe4d5927-aee3-4a23-88e5-04f7c544af59">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67147779949853 139.74530418439872 41.614 35.67146639296467 139.74528615813594 41.614 35.67147029320044 139.74528245330532 41.614 35.67148169072114 139.74530047957836 41.614 35.67147779949853 139.74530418439872 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edcb16b6-c69b-4662-826f-156e595a5717">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67150202515029 139.74526275583813 41.614 35.671552597271194 139.74535604254635 41.614 35.67154621934105 139.7453612303163 41.614 35.671495647232206 139.7452679546586 41.614 35.67150202515029 139.74526275583813 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bca194a-676f-4a14-bfd5-28f7a82aa00d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67147840909778 139.74542299892863 47.647 35.67146945458033 139.74540533449115 47.647 35.67148569729467 139.74539295574232 47.647 35.67149466082763 139.7454106201721 47.647 35.67147840909778 139.74542299892863 47.647</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e89e581-cd9b-4768-9d44-998e3b455fde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e89e581-cd9b-4768-9d44-998e3b455fde_0">
											<gml:posList>35.6714333377184 139.7452589098167 41.614 35.6714333377184 139.7452589098167 42.38 35.67144593985981 139.74524788270526 42.38 35.67144593985981 139.74524788270526 41.614 35.6714333377184 139.7452589098167 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5b9991d-6fea-4864-b059-6d53cbb567e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5b9991d-6fea-4864-b059-6d53cbb567e1_0">
											<gml:posList>35.6714539992383 139.74526171499969 41.614 35.67144593985981 139.74524788270526 41.614 35.67144593985981 139.74524788270526 42.38 35.6714539992383 139.74526171499969 42.38 35.6714539992383 139.74526171499969 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3355513e-fc50-4b4f-9782-933d5c47dcb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3355513e-fc50-4b4f-9782-933d5c47dcb3_0">
											<gml:posList>35.6714539992383 139.74526171499969 42.38 35.67144593985981 139.74524788270526 42.38 35.6714333377184 139.7452589098167 42.38 35.671441397095634 139.74527274211007 42.38 35.6714539992383 139.74526171499969 42.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92698080-a0ee-4ba8-b377-336282dbc11f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92698080-a0ee-4ba8-b377-336282dbc11f_0">
											<gml:posList>35.67150202515029 139.74526275583813 41.614 35.671495647232206 139.7452679546586 41.614 35.671495647232206 139.7452679546586 43.329 35.67150202515029 139.74526275583813 43.329 35.67150202515029 139.74526275583813 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13611a60-11fc-475d-901a-e1486052e218">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13611a60-11fc-475d-901a-e1486052e218_0">
											<gml:posList>35.6714333377184 139.7452589098167 41.614 35.671441397095634 139.74527274211007 41.614 35.671441397095634 139.74527274211007 42.38 35.6714333377184 139.7452589098167 42.38 35.6714333377184 139.7452589098167 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57b44606-8027-4fa1-b181-7e000dbb486c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57b44606-8027-4fa1-b181-7e000dbb486c_0">
											<gml:posList>35.6714539992383 139.74526171499969 41.614 35.6714539992383 139.74526171499969 42.38 35.671441397095634 139.74527274211007 42.38 35.671441397095634 139.74527274211007 41.614 35.6714539992383 139.74526171499969 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-526f196a-f39d-4168-91c3-4b59bac9c03b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-526f196a-f39d-4168-91c3-4b59bac9c03b_0">
											<gml:posList>35.67146639296467 139.74528615813594 41.614 35.67146639296467 139.74528615813594 43.753 35.67147029320044 139.74528245330532 43.753 35.67147029320044 139.74528245330532 41.614 35.67146639296467 139.74528615813594 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac6851e6-e43e-4432-a9b5-8ddfd25ddb79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac6851e6-e43e-4432-a9b5-8ddfd25ddb79_0">
											<gml:posList>35.67148169072114 139.74530047957836 41.614 35.67147029320044 139.74528245330532 41.614 35.67147029320044 139.74528245330532 43.753 35.67148169072114 139.74530047957836 43.753 35.67148169072114 139.74530047957836 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5e79566-6bd5-45d0-95a7-7d71114727dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5e79566-6bd5-45d0-95a7-7d71114727dd_0">
											<gml:posList>35.67147779949853 139.74530418439872 43.753 35.67148169072114 139.74530047957836 43.753 35.67147029320044 139.74528245330532 43.753 35.67146639296467 139.74528615813594 43.753 35.67147779949853 139.74530418439872 43.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a11d70d-dbf3-47c4-8d7f-5f3d67f9a82d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a11d70d-dbf3-47c4-8d7f-5f3d67f9a82d_0">
											<gml:posList>35.67146639296467 139.74528615813594 41.614 35.67147779949853 139.74530418439872 41.614 35.67147779949853 139.74530418439872 43.753 35.67146639296467 139.74528615813594 43.753 35.67146639296467 139.74528615813594 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1dc05bd9-8b66-4fab-8990-44ebd4d11d87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1dc05bd9-8b66-4fab-8990-44ebd4d11d87_0">
											<gml:posList>35.67147779949853 139.74530418439872 41.614 35.67148169072114 139.74530047957836 41.614 35.67148169072114 139.74530047957836 43.753 35.67147779949853 139.74530418439872 43.753 35.67147779949853 139.74530418439872 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b48d1ad7-ca1e-4451-b629-7c902907a86b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b48d1ad7-ca1e-4451-b629-7c902907a86b_0">
											<gml:posList>35.671552597271194 139.74535604254635 41.614 35.67150202515029 139.74526275583813 41.614 35.67150202515029 139.74526275583813 43.329 35.671552597271194 139.74535604254635 43.329 35.671552597271194 139.74535604254635 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-daafe369-687a-432f-9fb1-e40934b2e903">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-daafe369-687a-432f-9fb1-e40934b2e903_0">
											<gml:posList>35.67154621934105 139.7453612303163 43.329 35.671552597271194 139.74535604254635 43.329 35.67150202515029 139.74526275583813 43.329 35.671495647232206 139.7452679546586 43.329 35.67154621934105 139.7453612303163 43.329</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0929598e-0181-4e7e-8198-b33bb0607217">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0929598e-0181-4e7e-8198-b33bb0607217_0">
											<gml:posList>35.671495647232206 139.7452679546586 41.614 35.67154621934105 139.7453612303163 41.614 35.67154621934105 139.7453612303163 43.329 35.671495647232206 139.7452679546586 43.329 35.671495647232206 139.7452679546586 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32448963-f6d5-43d1-a36c-c439471dc908">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32448963-f6d5-43d1-a36c-c439471dc908_0">
											<gml:posList>35.67154621934105 139.7453612303163 41.614 35.671552597271194 139.74535604254635 41.614 35.671552597271194 139.74535604254635 43.329 35.67154621934105 139.7453612303163 43.329 35.67154621934105 139.7453612303163 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da7e6481-164e-42a5-8ea1-fa97951bbaba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da7e6481-164e-42a5-8ea1-fa97951bbaba_0">
											<gml:posList>35.67148569729467 139.74539295574232 47.647 35.67146945458033 139.74540533449115 47.647 35.67146945458033 139.74540533449115 47.696 35.67148569729467 139.74539295574232 47.696 35.67148569729467 139.74539295574232 47.647</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01a8c5aa-e53a-467b-a819-ce97739a0b77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01a8c5aa-e53a-467b-a819-ce97739a0b77_0">
											<gml:posList>35.67149466082763 139.7454106201721 47.647 35.67148569729467 139.74539295574232 47.647 35.67148569729467 139.74539295574232 47.696 35.67149466082763 139.7454106201721 47.696 35.67149466082763 139.7454106201721 47.647</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78653b82-440d-4edc-a95c-f507035aa5ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78653b82-440d-4edc-a95c-f507035aa5ec_0">
											<gml:posList>35.67148569729467 139.74539295574232 47.696 35.67146945458033 139.74540533449115 47.696 35.67147840909778 139.74542299892863 47.696 35.67149466082763 139.7454106201721 47.696 35.67148569729467 139.74539295574232 47.696</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c6d219e-2c0a-45dc-8d03-4599ac14626f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c6d219e-2c0a-45dc-8d03-4599ac14626f_0">
											<gml:posList>35.67146945458033 139.74540533449115 47.647 35.67147840909778 139.74542299892863 47.647 35.67147840909778 139.74542299892863 47.696 35.67146945458033 139.74540533449115 47.696 35.67146945458033 139.74540533449115 47.647</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93a02552-a7f4-40f7-9880-a036a6528e93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93a02552-a7f4-40f7-9880-a036a6528e93_0">
											<gml:posList>35.67149466082763 139.7454106201721 47.647 35.67149466082763 139.7454106201721 47.696 35.67147840909778 139.74542299892863 47.696 35.67147840909778 139.74542299892863 47.647 35.67149466082763 139.7454106201721 47.647</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c46c5bf4-66c9-47b7-974d-9a6f2c106dc9_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de74d8de-e4b5-4f02-b354-2fec35043f75">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671481199989756 139.74524572305484 41.614 35.67146287727804 139.745261053509 41.614 35.67143932952421 139.74521877164207 41.614 35.6714576522306 139.74520344118275 41.614 35.671481199989756 139.74524572305484 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb39f0dd-423a-4c24-ab60-feb82c60d2bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb39f0dd-423a-4c24-ab60-feb82c60d2bd_0">
											<gml:posList>35.67143932952421 139.74521877164207 41.614 35.67143932952421 139.74521877164207 43.817 35.6714576522306 139.74520344118275 43.817 35.6714576522306 139.74520344118275 41.614 35.67143932952421 139.74521877164207 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22d892c3-67c2-469f-bc41-e62c4aeceae7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22d892c3-67c2-469f-bc41-e62c4aeceae7_0">
											<gml:posList>35.67146287727804 139.745261053509 41.614 35.67146287727804 139.745261053509 43.817 35.67143932952421 139.74521877164207 43.817 35.67143932952421 139.74521877164207 41.614 35.67146287727804 139.745261053509 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-635ec5da-ea59-41ae-9b44-2030d2aa3b47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-635ec5da-ea59-41ae-9b44-2030d2aa3b47_0">
											<gml:posList>35.671481199989756 139.74524572305484 43.817 35.6714576522306 139.74520344118275 43.817 35.67143932952421 139.74521877164207 43.817 35.67146287727804 139.745261053509 43.817 35.671481199989756 139.74524572305484 43.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b8b0fbc-a737-4e9a-a2b1-af9c85a33be2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b8b0fbc-a737-4e9a-a2b1-af9c85a33be2_0">
											<gml:posList>35.6714576522306 139.74520344118275 41.614 35.6714576522306 139.74520344118275 43.817 35.671481199989756 139.74524572305484 43.817 35.671481199989756 139.74524572305484 41.614 35.6714576522306 139.74520344118275 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72ed6f31-16c6-4556-8533-97de6bbf0efe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72ed6f31-16c6-4556-8533-97de6bbf0efe_0">
											<gml:posList>35.671481199989756 139.74524572305484 41.614 35.671481199989756 139.74524572305484 43.817 35.67146287727804 139.745261053509 43.817 35.67146287727804 139.745261053509 41.614 35.671481199989756 139.74524572305484 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-22e9761b-38c2-4c3f-babe-c4d8078b2f22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22e9761b-38c2-4c3f-babe-c4d8078b2f22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22e9761b-38c2-4c3f-babe-c4d8078b2f22">
											<gml:posList>35.67147366874015 139.74518991381683 7.19 35.67148294713262 139.74518206066378 7.19 35.67159134386612 139.74537602720036 7.19 35.67158765049937 139.74537912425163 7.19 35.67159153148304 139.7453860792429 7.19 35.67152225838418 139.7454442593872 7.19 35.67150854856554 139.74541965195635 7.19 35.671468903437066 139.745452934076 7.19 35.67141426928067 139.74519130468863 7.19 35.67146545549743 139.7451752311219 7.19 35.67147366874015 139.74518991381683 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e3b4091d-de50-4e92-822b-2c2fcc73b0a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3b4091d-de50-4e92-822b-2c2fcc73b0a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3b4091d-de50-4e92-822b-2c2fcc73b0a9">
											<gml:posList>35.67146545549743 139.7451752311219 43.7 35.67141426928067 139.74519130468863 43.7 35.67141790374329 139.74519394078328 43.7 35.67146417860587 139.74517940806865 43.7 35.67146545549743 139.7451752311219 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-feb0023a-3e71-43e7-884c-4facc6cd2598">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-feb0023a-3e71-43e7-884c-4facc6cd2598">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-feb0023a-3e71-43e7-884c-4facc6cd2598">
											<gml:posList>35.67147366874015 139.74518991381683 43.7 35.67146545549743 139.7451752311219 43.7 35.67146417860587 139.74517940806865 43.7 35.67147290630138 139.74519500705026 43.7 35.67147366874015 139.74518991381683 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71ea1659-0283-4efb-90e8-203d25637ade">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71ea1659-0283-4efb-90e8-203d25637ade">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71ea1659-0283-4efb-90e8-203d25637ade">
											<gml:posList>35.67147366874015 139.74518991381683 43.7 35.67147290630138 139.74519500705026 43.7 35.67148218470226 139.7451871649443 43.7 35.67148294713262 139.74518206066378 43.7 35.67147366874015 139.74518991381683 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-76cfbe3d-aad9-44e3-b738-fecafe307009">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76cfbe3d-aad9-44e3-b738-fecafe307009">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76cfbe3d-aad9-44e3-b738-fecafe307009">
											<gml:posList>35.67148294713262 139.74518206066378 43.7 35.67148218470226 139.7451871649443 43.7 35.67158719686 139.7453750817573 43.7 35.67159134386612 139.74537602720036 43.7 35.67148294713262 139.74518206066378 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb2fd849-2b71-4e5d-a25f-47819640a40d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb2fd849-2b71-4e5d-a25f-47819640a40d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb2fd849-2b71-4e5d-a25f-47819640a40d">
											<gml:posList>35.67141426928067 139.74519130468863 43.7 35.671454277098356 139.74538289378918 43.7 35.671456120562375 139.7453769377529 43.7 35.67141790374329 139.74519394078328 43.7 35.67141426928067 139.74519130468863 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6e39cb91-182d-4866-87c1-296ef7d1da14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e39cb91-182d-4866-87c1-296ef7d1da14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e39cb91-182d-4866-87c1-296ef7d1da14">
											<gml:posList>35.671583512498934 139.74537816775216 41.614 35.67158719686 139.7453750817573 41.614 35.67148218470226 139.7451871649443 41.614 35.67147290630138 139.74519500705026 41.614 35.67146417860587 139.74517940806865 41.614 35.67141790374329 139.74519394078328 41.614 35.671456120562375 139.7453769377529 41.614 35.671456430062804 139.74538109086288 41.614 35.67149478706477 139.74534898104636 41.614 35.6715260064882 139.7454050184024 41.614 35.67151100781158 139.7454175946264 41.614 35.67152302985527 139.7454391771895 41.614 35.67158739348266 139.74538512274304 41.614 35.671583512498934 139.74537816775216 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-19ef6e5c-8739-4eff-9927-fdfe0ee34128">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19ef6e5c-8739-4eff-9927-fdfe0ee34128">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19ef6e5c-8739-4eff-9927-fdfe0ee34128">
											<gml:posList>35.671454277098356 139.74538289378918 47.921 35.67145710835923 139.74538419415947 47.921 35.67149414115195 139.7453531904387 47.921 35.67149478706477 139.74534898104636 47.921 35.671454277098356 139.74538289378918 47.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0adb3c6e-3746-41b8-8d95-27a54d511d74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0adb3c6e-3746-41b8-8d95-27a54d511d74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0adb3c6e-3746-41b8-8d95-27a54d511d74">
											<gml:posList>35.67149478706477 139.74534898104636 47.921 35.67149414115195 139.7453531904387 47.921 35.67152258069297 139.7454042268175 47.921 35.6715260064882 139.7454050184024 47.921 35.67149478706477 139.74534898104636 47.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d26033f-b28e-4664-bed0-352c071551e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d26033f-b28e-4664-bed0-352c071551e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d26033f-b28e-4664-bed0-352c071551e0">
											<gml:posList>35.67158765049937 139.74537912425163 43.7 35.67159134386612 139.74537602720036 43.7 35.67158719686 139.7453750817573 43.7 35.671583512498934 139.74537816775216 43.7 35.67158765049937 139.74537912425163 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46765698-1632-46c9-8735-9da71492f1f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46765698-1632-46c9-8735-9da71492f1f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46765698-1632-46c9-8735-9da71492f1f8">
											<gml:posList>35.671456120562375 139.7453769377529 43.7 35.671454277098356 139.74538289378918 43.7 35.671456430062804 139.74538109086288 43.7 35.671456120562375 139.7453769377529 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11fec2f5-fe00-4a0e-9102-0f452212d56e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11fec2f5-fe00-4a0e-9102-0f452212d56e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11fec2f5-fe00-4a0e-9102-0f452212d56e">
											<gml:posList>35.67158765049937 139.74537912425163 43.7 35.671583512498934 139.74537816775216 43.7 35.67158739348266 139.74538512274304 43.7 35.67159153148304 139.7453860792429 43.7 35.67158765049937 139.74537912425163 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-83b4e6b6-38dc-4549-b7bf-5433d9c316f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83b4e6b6-38dc-4549-b7bf-5433d9c316f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83b4e6b6-38dc-4549-b7bf-5433d9c316f1">
											<gml:posList>35.67152258069297 139.7454042268175 47.647 35.67149414115195 139.7453531904387 47.647 35.67145710835923 139.74538419415947 47.647 35.67147043215797 139.7454479836086 47.647 35.67152258069297 139.7454042268175 47.647</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2b645ed5-1a92-42a7-ad11-a57241875fca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b645ed5-1a92-42a7-ad11-a57241875fca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b645ed5-1a92-42a7-ad11-a57241875fca">
											<gml:posList>35.67159153148304 139.7453860792429 43.7 35.67158739348266 139.74538512274304 43.7 35.67152302985527 139.7454391771895 43.7 35.67152225838418 139.7454442593872 43.7 35.67159153148304 139.7453860792429 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba5c2c3f-d8b2-4fb5-8b71-37e0a78f07f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba5c2c3f-d8b2-4fb5-8b71-37e0a78f07f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba5c2c3f-d8b2-4fb5-8b71-37e0a78f07f4">
											<gml:posList>35.671454277098356 139.74538289378918 47.921 35.671468903437066 139.745452934076 47.921 35.67147043215797 139.7454479836086 47.921 35.67145710835923 139.74538419415947 47.921 35.671454277098356 139.74538289378918 47.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66425c8e-c8cf-4066-9987-973b9e96d58e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66425c8e-c8cf-4066-9987-973b9e96d58e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66425c8e-c8cf-4066-9987-973b9e96d58e">
											<gml:posList>35.6715260064882 139.7454050184024 47.921 35.67152258069297 139.7454042268175 47.921 35.67147043215797 139.7454479836086 47.921 35.671468903437066 139.745452934076 47.921 35.6715260064882 139.7454050184024 47.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e4c8f995-2291-46b8-85e1-8527f611d52c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4c8f995-2291-46b8-85e1-8527f611d52c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4c8f995-2291-46b8-85e1-8527f611d52c">
											<gml:posList>35.67150854856554 139.74541965195635 43.7 35.67152225838418 139.7454442593872 43.7 35.67152302985527 139.7454391771895 43.7 35.67151100781158 139.7454175946264 43.7 35.67150854856554 139.74541965195635 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0dd8d03c-9e54-4d26-8d70-05c0f42799e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dd8d03c-9e54-4d26-8d70-05c0f42799e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dd8d03c-9e54-4d26-8d70-05c0f42799e9">
											<gml:posList>35.67146417860587 139.74517940806865 43.7 35.67146417860587 139.74517940806865 41.614 35.67147290630138 139.74519500705026 41.614 35.67147290630138 139.74519500705026 43.7 35.67146417860587 139.74517940806865 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-416eaf0b-4f4b-4786-ac73-a293ac8fcfc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-416eaf0b-4f4b-4786-ac73-a293ac8fcfc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-416eaf0b-4f4b-4786-ac73-a293ac8fcfc1">
											<gml:posList>35.67147366874015 139.74518991381683 7.19 35.67146545549743 139.7451752311219 7.19 35.67146545549743 139.7451752311219 43.7 35.67147366874015 139.74518991381683 43.7 35.67147366874015 139.74518991381683 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53d67a23-531a-4afa-8777-978e92e5f575">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53d67a23-531a-4afa-8777-978e92e5f575">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53d67a23-531a-4afa-8777-978e92e5f575">
											<gml:posList>35.67146545549743 139.7451752311219 7.19 35.67141426928067 139.74519130468863 7.19 35.67141426928067 139.74519130468863 43.7 35.67146545549743 139.7451752311219 43.7 35.67146545549743 139.7451752311219 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31bd0852-3450-4756-af0e-1fe7dfbbf110">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31bd0852-3450-4756-af0e-1fe7dfbbf110">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31bd0852-3450-4756-af0e-1fe7dfbbf110">
											<gml:posList>35.67148294713262 139.74518206066378 7.19 35.67147366874015 139.74518991381683 7.19 35.67147366874015 139.74518991381683 43.7 35.67148294713262 139.74518206066378 43.7 35.67148294713262 139.74518206066378 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ffc0f95-bd33-4066-a3d9-5cedcae717db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ffc0f95-bd33-4066-a3d9-5cedcae717db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ffc0f95-bd33-4066-a3d9-5cedcae717db">
											<gml:posList>35.67141790374329 139.74519394078328 43.7 35.67141790374329 139.74519394078328 41.614 35.67146417860587 139.74517940806865 41.614 35.67146417860587 139.74517940806865 43.7 35.67141790374329 139.74519394078328 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fedc084e-c4b4-4384-af8e-0b8401822e2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fedc084e-c4b4-4384-af8e-0b8401822e2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fedc084e-c4b4-4384-af8e-0b8401822e2e">
											<gml:posList>35.67147290630138 139.74519500705026 43.7 35.67147290630138 139.74519500705026 41.614 35.67148218470226 139.7451871649443 41.614 35.67148218470226 139.7451871649443 43.7 35.67147290630138 139.74519500705026 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6dcec95e-4886-41f2-a034-b849b663aa89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dcec95e-4886-41f2-a034-b849b663aa89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dcec95e-4886-41f2-a034-b849b663aa89">
											<gml:posList>35.67159134386612 139.74537602720036 7.19 35.67148294713262 139.74518206066378 7.19 35.67148294713262 139.74518206066378 43.7 35.67159134386612 139.74537602720036 43.7 35.67159134386612 139.74537602720036 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78c1432b-76f8-49cc-940d-517ecdb12367">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78c1432b-76f8-49cc-940d-517ecdb12367">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78c1432b-76f8-49cc-940d-517ecdb12367">
											<gml:posList>35.67148218470226 139.7451871649443 43.7 35.67148218470226 139.7451871649443 41.614 35.67158719686 139.7453750817573 41.614 35.67158719686 139.7453750817573 43.7 35.67148218470226 139.7451871649443 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f97be01f-569b-4c5a-9aca-39f5328607b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f97be01f-569b-4c5a-9aca-39f5328607b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f97be01f-569b-4c5a-9aca-39f5328607b4">
											<gml:posList>35.671456120562375 139.7453769377529 43.7 35.671456120562375 139.7453769377529 41.614 35.67141790374329 139.74519394078328 41.614 35.67141790374329 139.74519394078328 43.7 35.671456120562375 139.7453769377529 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae727b93-a76a-42cd-81a6-1ab322b40410">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae727b93-a76a-42cd-81a6-1ab322b40410">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae727b93-a76a-42cd-81a6-1ab322b40410">
											<gml:posList>35.671468903437066 139.745452934076 7.19 35.671468903437066 139.745452934076 47.921 35.671454277098356 139.74538289378918 47.921 35.671454277098356 139.74538289378918 43.7 35.67141426928067 139.74519130468863 43.7 35.67141426928067 139.74519130468863 7.19 35.671468903437066 139.745452934076 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13098984-92a9-4830-a229-e02eb83cc73f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13098984-92a9-4830-a229-e02eb83cc73f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13098984-92a9-4830-a229-e02eb83cc73f">
											<gml:posList>35.671456430062804 139.74538109086288 43.7 35.671454277098356 139.74538289378918 43.7 35.671454277098356 139.74538289378918 47.921 35.67149478706477 139.74534898104636 47.921 35.67149478706477 139.74534898104636 41.614 35.671456430062804 139.74538109086288 41.614 35.671456430062804 139.74538109086288 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53d41942-1256-4e8a-9045-e97aad3cc86a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53d41942-1256-4e8a-9045-e97aad3cc86a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53d41942-1256-4e8a-9045-e97aad3cc86a">
											<gml:posList>35.67145710835923 139.74538419415947 47.921 35.67145710835923 139.74538419415947 47.647 35.67149414115195 139.7453531904387 47.647 35.67149414115195 139.7453531904387 47.921 35.67145710835923 139.74538419415947 47.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f3f49b3-ee40-41ee-bf07-3f2602ad4b55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f3f49b3-ee40-41ee-bf07-3f2602ad4b55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f3f49b3-ee40-41ee-bf07-3f2602ad4b55">
											<gml:posList>35.67158719686 139.7453750817573 43.7 35.67158719686 139.7453750817573 41.614 35.671583512498934 139.74537816775216 41.614 35.671583512498934 139.74537816775216 43.7 35.67158719686 139.7453750817573 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-393bb9b3-2646-4850-98b1-590124f31ca7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-393bb9b3-2646-4850-98b1-590124f31ca7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-393bb9b3-2646-4850-98b1-590124f31ca7">
											<gml:posList>35.67149478706477 139.74534898104636 47.921 35.6715260064882 139.7454050184024 47.921 35.6715260064882 139.7454050184024 41.614 35.67149478706477 139.74534898104636 41.614 35.67149478706477 139.74534898104636 47.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d67e11af-8d8c-4d89-b92c-51c21d887f8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d67e11af-8d8c-4d89-b92c-51c21d887f8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d67e11af-8d8c-4d89-b92c-51c21d887f8d">
											<gml:posList>35.67158765049937 139.74537912425163 7.19 35.67159134386612 139.74537602720036 7.19 35.67159134386612 139.74537602720036 43.7 35.67158765049937 139.74537912425163 43.7 35.67158765049937 139.74537912425163 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-220cfefc-bed0-4ddf-994f-8e5c59ffe9d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-220cfefc-bed0-4ddf-994f-8e5c59ffe9d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-220cfefc-bed0-4ddf-994f-8e5c59ffe9d7">
											<gml:posList>35.67149414115195 139.7453531904387 47.921 35.67149414115195 139.7453531904387 47.647 35.67152258069297 139.7454042268175 47.647 35.67152258069297 139.7454042268175 47.921 35.67149414115195 139.7453531904387 47.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b419d4d4-8c96-434c-9821-6cbebb2eb85c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b419d4d4-8c96-434c-9821-6cbebb2eb85c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b419d4d4-8c96-434c-9821-6cbebb2eb85c">
											<gml:posList>35.671456430062804 139.74538109086288 43.7 35.671456430062804 139.74538109086288 41.614 35.671456120562375 139.7453769377529 41.614 35.671456120562375 139.7453769377529 43.7 35.671456430062804 139.74538109086288 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c9eff97-eb13-47f0-b08f-a87c92eb785c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c9eff97-eb13-47f0-b08f-a87c92eb785c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c9eff97-eb13-47f0-b08f-a87c92eb785c">
											<gml:posList>35.671583512498934 139.74537816775216 43.7 35.671583512498934 139.74537816775216 41.614 35.67158739348266 139.74538512274304 41.614 35.67158739348266 139.74538512274304 43.7 35.671583512498934 139.74537816775216 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27a1d919-3b7b-426c-9fa3-2af3698d0130">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27a1d919-3b7b-426c-9fa3-2af3698d0130">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27a1d919-3b7b-426c-9fa3-2af3698d0130">
											<gml:posList>35.67159153148304 139.7453860792429 7.19 35.67158765049937 139.74537912425163 7.19 35.67158765049937 139.74537912425163 43.7 35.67159153148304 139.7453860792429 43.7 35.67159153148304 139.7453860792429 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa79a8e8-08aa-4a5c-bda2-44ee6675273b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa79a8e8-08aa-4a5c-bda2-44ee6675273b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa79a8e8-08aa-4a5c-bda2-44ee6675273b">
											<gml:posList>35.67158739348266 139.74538512274304 43.7 35.67158739348266 139.74538512274304 41.614 35.67152302985527 139.7454391771895 41.614 35.67152302985527 139.7454391771895 43.7 35.67158739348266 139.74538512274304 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5ce2e4b-89ba-411a-b49c-216dfce55a34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5ce2e4b-89ba-411a-b49c-216dfce55a34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5ce2e4b-89ba-411a-b49c-216dfce55a34">
											<gml:posList>35.67152225838418 139.7454442593872 7.19 35.67159153148304 139.7453860792429 7.19 35.67159153148304 139.7453860792429 43.7 35.67152225838418 139.7454442593872 43.7 35.67152225838418 139.7454442593872 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db1b916f-5000-49ca-9a01-72f27e997a9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db1b916f-5000-49ca-9a01-72f27e997a9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db1b916f-5000-49ca-9a01-72f27e997a9b">
											<gml:posList>35.67147043215797 139.7454479836086 47.921 35.67147043215797 139.7454479836086 47.647 35.67145710835923 139.74538419415947 47.647 35.67145710835923 139.74538419415947 47.921 35.67147043215797 139.7454479836086 47.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d192b95-da4b-4c06-a815-46918783df34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d192b95-da4b-4c06-a815-46918783df34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d192b95-da4b-4c06-a815-46918783df34">
											<gml:posList>35.67152258069297 139.7454042268175 47.921 35.67152258069297 139.7454042268175 47.647 35.67147043215797 139.7454479836086 47.647 35.67147043215797 139.7454479836086 47.921 35.67152258069297 139.7454042268175 47.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a9a8a0e-df52-440a-b6d6-179c7ecc65db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a9a8a0e-df52-440a-b6d6-179c7ecc65db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a9a8a0e-df52-440a-b6d6-179c7ecc65db">
											<gml:posList>35.67151100781158 139.7454175946264 41.614 35.67151100781158 139.7454175946264 43.7 35.67152302985527 139.7454391771895 43.7 35.67152302985527 139.7454391771895 41.614 35.67151100781158 139.7454175946264 41.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b1d33a3-b4d3-4927-8bef-5cd4a20e94aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b1d33a3-b4d3-4927-8bef-5cd4a20e94aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b1d33a3-b4d3-4927-8bef-5cd4a20e94aa">
											<gml:posList>35.67151100781158 139.7454175946264 43.7 35.67151100781158 139.7454175946264 41.614 35.6715260064882 139.7454050184024 41.614 35.6715260064882 139.7454050184024 47.921 35.671468903437066 139.745452934076 47.921 35.671468903437066 139.745452934076 7.19 35.67150854856554 139.74541965195635 7.19 35.67150854856554 139.74541965195635 43.7 35.67151100781158 139.7454175946264 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c1ea7cf-b807-42fe-bca9-85fc229528a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c1ea7cf-b807-42fe-bca9-85fc229528a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c1ea7cf-b807-42fe-bca9-85fc229528a1">
											<gml:posList>35.67150854856554 139.74541965195635 7.19 35.67152225838418 139.7454442593872 7.19 35.67152225838418 139.7454442593872 43.7 35.67150854856554 139.74541965195635 43.7 35.67150854856554 139.74541965195635 7.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区霞が関三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-3494</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">267.4882</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.11</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>