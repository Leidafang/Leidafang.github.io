<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c4c07ea3-7ad9-4ad9-aca0-84e00e7d45a8">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="説明注記">
				<gen:value>店舗付属施設</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">6.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67417839753853 139.7376077423159 0 35.674240932526985 139.73758226002397 0 35.6742289992749 139.7375380871193 0 35.6741311420371 139.7375780829157 0 35.674153561737185 139.73766068604377 0 35.67418879395632 139.73764628317755 0 35.67417839753853 139.7376077423159 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67417839753853 139.7376077423159 9.32 35.67418879395632 139.73764628317755 9.32 35.674153561737185 139.73766068604377 9.32 35.6741311420371 139.7375780829157 9.32 35.6742289992749 139.7375380871193 9.32 35.674240932526985 139.73758226002397 9.32 35.67417839753853 139.7376077423159 9.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67417839753853 139.7376077423159 9.32 35.674240932526985 139.73758226002397 9.32 35.674240932526985 139.73758226002397 16.01 35.67417839753853 139.7376077423159 16.01 35.67417839753853 139.7376077423159 9.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674240932526985 139.73758226002397 9.32 35.6742289992749 139.7375380871193 9.32 35.6742289992749 139.7375380871193 16.01 35.674240932526985 139.73758226002397 16.01 35.674240932526985 139.73758226002397 9.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6742289992749 139.7375380871193 9.32 35.6741311420371 139.7375780829157 9.32 35.6741311420371 139.7375780829157 16.01 35.6742289992749 139.7375380871193 16.01 35.6742289992749 139.7375380871193 9.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6741311420371 139.7375780829157 9.32 35.674153561737185 139.73766068604377 9.32 35.674153561737185 139.73766068604377 16.01 35.6741311420371 139.7375780829157 16.01 35.6741311420371 139.7375780829157 9.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674153561737185 139.73766068604377 9.32 35.67418879395632 139.73764628317755 9.32 35.67418879395632 139.73764628317755 16.01 35.674153561737185 139.73766068604377 16.01 35.674153561737185 139.73766068604377 9.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67418879395632 139.73764628317755 9.32 35.67417839753853 139.7376077423159 9.32 35.67417839753853 139.7376077423159 16.01 35.67418879395632 139.73764628317755 16.01 35.67418879395632 139.73764628317755 9.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67417839753853 139.7376077423159 16.01 35.674240932526985 139.73758226002397 16.01 35.6742289992749 139.7375380871193 16.01 35.6741311420371 139.7375780829157 16.01 35.674153561737185 139.73766068604377 16.01 35.67418879395632 139.73764628317755 16.01 35.67417839753853 139.7376077423159 16.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6c677ddd-1df2-456d-b76f-8321a17dc05e"/>
							<gml:surfaceMember xlink:href="#poly-a907a789-cfe1-4347-bb3f-523a7d09d648"/>
							<gml:surfaceMember xlink:href="#poly-68465547-4a22-4d66-be52-6720c4b83a85"/>
							<gml:surfaceMember xlink:href="#poly-5f69b673-a3e1-44f9-80cc-a8f3e37de9e6"/>
							<gml:surfaceMember xlink:href="#poly-1ab28fba-4521-4ed9-aedc-9aa3c93d49a9"/>
							<gml:surfaceMember xlink:href="#poly-32008677-27ea-4402-85d0-1b0c2be8bbd2"/>
							<gml:surfaceMember xlink:href="#poly-1c1fdbef-d3f6-4354-beb1-ecec5036a410"/>
							<gml:surfaceMember xlink:href="#poly-d6c1e2aa-4dbe-4fe5-8ba9-1395f14bf831"/>
							<gml:surfaceMember xlink:href="#poly-8d26c74e-dea0-4ec4-96a1-2fe0e944d0e9"/>
							<gml:surfaceMember xlink:href="#poly-e1377ae6-8572-4b47-a7f9-6981a7a61b29"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6c677ddd-1df2-456d-b76f-8321a17dc05e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c677ddd-1df2-456d-b76f-8321a17dc05e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c677ddd-1df2-456d-b76f-8321a17dc05e">
											<gml:posList>35.674178397538505 139.7376077423159 9.32 35.6741887939563 139.73764628317758 9.32 35.67415356173718 139.73766068604377 9.32 35.6741311420371 139.7375780829157 9.32 35.67422899927489 139.7375380871193 9.32 35.67424093252696 139.73758226002394 9.32 35.674178397538505 139.7376077423159 9.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a907a789-cfe1-4347-bb3f-523a7d09d648">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a907a789-cfe1-4347-bb3f-523a7d09d648">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a907a789-cfe1-4347-bb3f-523a7d09d648">
											<gml:posList>35.674178397538505 139.7376077423159 17.848 35.67424093252696 139.73758226002394 17.848 35.67422899927489 139.7375380871193 17.848 35.67416640127877 139.73756366893818 17.848 35.674178397538505 139.7376077423159 17.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68465547-4a22-4d66-be52-6720c4b83a85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68465547-4a22-4d66-be52-6720c4b83a85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68465547-4a22-4d66-be52-6720c4b83a85">
											<gml:posList>35.6741311420371 139.7375780829157 16.801 35.67415356173718 139.73766068604377 16.801 35.6741887939563 139.73764628317758 16.801 35.674178397538505 139.7376077423159 16.801 35.67416640127877 139.73756366893818 16.801 35.6741311420371 139.7375780829157 16.801</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f69b673-a3e1-44f9-80cc-a8f3e37de9e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f69b673-a3e1-44f9-80cc-a8f3e37de9e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f69b673-a3e1-44f9-80cc-a8f3e37de9e6">
											<gml:posList>35.6741311420371 139.7375780829157 9.32 35.67415356173718 139.73766068604377 9.32 35.67415356173718 139.73766068604377 16.801 35.6741311420371 139.7375780829157 16.801 35.6741311420371 139.7375780829157 9.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ab28fba-4521-4ed9-aedc-9aa3c93d49a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ab28fba-4521-4ed9-aedc-9aa3c93d49a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ab28fba-4521-4ed9-aedc-9aa3c93d49a9">
											<gml:posList>35.6741311420371 139.7375780829157 9.32 35.6741311420371 139.7375780829157 16.801 35.67416640127877 139.73756366893818 16.801 35.67416640127877 139.73756366893818 17.848 35.67422899927489 139.7375380871193 17.848 35.67422899927489 139.7375380871193 9.32 35.6741311420371 139.7375780829157 9.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32008677-27ea-4402-85d0-1b0c2be8bbd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32008677-27ea-4402-85d0-1b0c2be8bbd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32008677-27ea-4402-85d0-1b0c2be8bbd2">
											<gml:posList>35.67424093252696 139.73758226002394 9.32 35.67422899927489 139.7375380871193 9.32 35.67422899927489 139.7375380871193 17.848 35.67424093252696 139.73758226002394 17.848 35.67424093252696 139.73758226002394 9.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c1fdbef-d3f6-4354-beb1-ecec5036a410">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c1fdbef-d3f6-4354-beb1-ecec5036a410">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c1fdbef-d3f6-4354-beb1-ecec5036a410">
											<gml:posList>35.674178397538505 139.7376077423159 16.801 35.674178397538505 139.7376077423159 17.848 35.67416640127877 139.73756366893818 17.848 35.67416640127877 139.73756366893818 16.801 35.674178397538505 139.7376077423159 16.801</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6c1e2aa-4dbe-4fe5-8ba9-1395f14bf831">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6c1e2aa-4dbe-4fe5-8ba9-1395f14bf831">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6c1e2aa-4dbe-4fe5-8ba9-1395f14bf831">
											<gml:posList>35.67424093252696 139.73758226002394 17.848 35.674178397538505 139.7376077423159 17.848 35.674178397538505 139.7376077423159 16.801 35.674178397538505 139.7376077423159 9.32 35.67424093252696 139.73758226002394 9.32 35.67424093252696 139.73758226002394 17.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d26c74e-dea0-4ec4-96a1-2fe0e944d0e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d26c74e-dea0-4ec4-96a1-2fe0e944d0e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d26c74e-dea0-4ec4-96a1-2fe0e944d0e9">
											<gml:posList>35.6741887939563 139.73764628317758 9.32 35.674178397538505 139.7376077423159 9.32 35.674178397538505 139.7376077423159 16.801 35.6741887939563 139.73764628317758 16.801 35.6741887939563 139.73764628317758 9.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1377ae6-8572-4b47-a7f9-6981a7a61b29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1377ae6-8572-4b47-a7f9-6981a7a61b29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1377ae6-8572-4b47-a7f9-6981a7a61b29">
											<gml:posList>35.67415356173718 139.73766068604377 9.32 35.6741887939563 139.73764628317758 9.32 35.6741887939563 139.73764628317758 16.801 35.67415356173718 139.73766068604377 16.801 35.67415356173718 139.73766068604377 9.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3281</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">63.29535</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>