<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c50c052a-db33-4afb-a47f-1485bfa0f0ce">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">21</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668408838992605 139.73902840665284 0 35.6684346390058 139.73905488668808 0 35.66844625339171 139.739037862203 0 35.668418874701 139.73900976026607 0 35.66843159493016 139.73898911139173 0 35.668443606361336 139.73899566962453 0 35.668477999319805 139.73894525941293 0 35.66840411748994 139.73886957091202 0 35.66832650820365 139.73898321498007 0 35.66839317310197 139.73905140072767 0 35.668408838992605 139.73902840665284 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668408838992605 139.73902840665284 13.42 35.66839317310197 139.73905140072767 13.42 35.66832650820365 139.73898321498007 13.42 35.66840411748994 139.73886957091202 13.42 35.668477999319805 139.73894525941293 13.42 35.668443606361336 139.73899566962453 13.42 35.66843159493016 139.73898911139173 13.42 35.668418874701 139.73900976026607 13.42 35.66844625339171 139.739037862203 13.42 35.6684346390058 139.73905488668808 13.42 35.668408838992605 139.73902840665284 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668408838992605 139.73902840665284 13.42 35.6684346390058 139.73905488668808 13.42 35.6684346390058 139.73905488668808 34.39 35.668408838992605 139.73902840665284 34.39 35.668408838992605 139.73902840665284 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6684346390058 139.73905488668808 13.42 35.66844625339171 139.739037862203 13.42 35.66844625339171 139.739037862203 34.39 35.6684346390058 139.73905488668808 34.39 35.6684346390058 139.73905488668808 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66844625339171 139.739037862203 13.42 35.668418874701 139.73900976026607 13.42 35.668418874701 139.73900976026607 34.39 35.66844625339171 139.739037862203 34.39 35.66844625339171 139.739037862203 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668418874701 139.73900976026607 13.42 35.66843159493016 139.73898911139173 13.42 35.66843159493016 139.73898911139173 34.39 35.668418874701 139.73900976026607 34.39 35.668418874701 139.73900976026607 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66843159493016 139.73898911139173 13.42 35.668443606361336 139.73899566962453 13.42 35.668443606361336 139.73899566962453 34.39 35.66843159493016 139.73898911139173 34.39 35.66843159493016 139.73898911139173 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668443606361336 139.73899566962453 13.42 35.668477999319805 139.73894525941293 13.42 35.668477999319805 139.73894525941293 34.39 35.668443606361336 139.73899566962453 34.39 35.668443606361336 139.73899566962453 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668477999319805 139.73894525941293 13.42 35.66840411748994 139.73886957091202 13.42 35.66840411748994 139.73886957091202 34.39 35.668477999319805 139.73894525941293 34.39 35.668477999319805 139.73894525941293 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66840411748994 139.73886957091202 13.42 35.66832650820365 139.73898321498007 13.42 35.66832650820365 139.73898321498007 34.39 35.66840411748994 139.73886957091202 34.39 35.66840411748994 139.73886957091202 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66832650820365 139.73898321498007 13.42 35.66839317310197 139.73905140072767 13.42 35.66839317310197 139.73905140072767 34.39 35.66832650820365 139.73898321498007 34.39 35.66832650820365 139.73898321498007 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66839317310197 139.73905140072767 13.42 35.668408838992605 139.73902840665284 13.42 35.668408838992605 139.73902840665284 34.39 35.66839317310197 139.73905140072767 34.39 35.66839317310197 139.73905140072767 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668408838992605 139.73902840665284 34.39 35.6684346390058 139.73905488668808 34.39 35.66844625339171 139.739037862203 34.39 35.668418874701 139.73900976026607 34.39 35.66843159493016 139.73898911139173 34.39 35.668443606361336 139.73899566962453 34.39 35.668477999319805 139.73894525941293 34.39 35.66840411748994 139.73886957091202 34.39 35.66832650820365 139.73898321498007 34.39 35.66839317310197 139.73905140072767 34.39 35.668408838992605 139.73902840665284 34.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-25798122-fc6d-4c05-8504-80f2c2342a2d"/>
							<gml:surfaceMember xlink:href="#poly-f1748edc-8492-44e5-b20e-83992751d6e1"/>
							<gml:surfaceMember xlink:href="#poly-1ae777d9-32e6-40d4-b4dc-b0ef8dbd9294"/>
							<gml:surfaceMember xlink:href="#poly-b8bd7fd6-abef-4a63-9fe9-ca12b272d232"/>
							<gml:surfaceMember xlink:href="#poly-074e52a6-3caa-4da0-915e-ffe0e28d14f8"/>
							<gml:surfaceMember xlink:href="#poly-3a5513b2-d362-4afc-bda5-d286eb58c78c"/>
							<gml:surfaceMember xlink:href="#poly-8da5d77d-6490-434d-839b-b98cbfc09c7c"/>
							<gml:surfaceMember xlink:href="#poly-ea8eb762-370d-452e-b3de-86b5e13f7485"/>
							<gml:surfaceMember xlink:href="#poly-04b968b2-9719-4bad-bd68-48a4634b899f"/>
							<gml:surfaceMember xlink:href="#poly-ada0e1d0-0258-419e-a862-625be3d85c59"/>
							<gml:surfaceMember xlink:href="#poly-c8c1c01b-4639-4c14-985a-189d1661e2c9"/>
							<gml:surfaceMember xlink:href="#poly-e65bf989-aeb1-44bc-a913-dcb036f5ecc4"/>
							<gml:surfaceMember xlink:href="#poly-5ae8cf59-9cde-447b-a8f7-001a0bf9cb4b"/>
							<gml:surfaceMember xlink:href="#poly-72e16f62-33ab-4d47-9d94-9cda0465de14"/>
							<gml:surfaceMember xlink:href="#poly-30ff4ba0-bd99-406a-855b-e2eb69ad26af"/>
							<gml:surfaceMember xlink:href="#poly-6058d776-f19c-4f57-a75c-242d4796df09"/>
							<gml:surfaceMember xlink:href="#poly-ec89346e-14af-4af8-9a61-1c0b5cca39d6"/>
							<gml:surfaceMember xlink:href="#poly-71471ca5-1011-4d2d-9dd6-6dd6c662599a"/>
							<gml:surfaceMember xlink:href="#poly-ef9cd903-df10-4551-9b9e-10c6cc7d28e3"/>
							<gml:surfaceMember xlink:href="#poly-08d499dd-ca48-467e-9190-430cd96e68a9"/>
							<gml:surfaceMember xlink:href="#poly-2c940452-41f7-47b4-b5ed-950d5f47e3ee"/>
							<gml:surfaceMember xlink:href="#poly-aa2d8154-7d6b-4fbc-b76c-5147fb5b9792"/>
							<gml:surfaceMember xlink:href="#poly-886fbf5e-c492-46a6-9faa-056b96f4c0ad"/>
							<gml:surfaceMember xlink:href="#poly-9e98a287-919d-4b6f-bea6-2387c05d3061"/>
							<gml:surfaceMember xlink:href="#poly-1c124c63-d590-41be-a995-2b0893629e9d"/>
							<gml:surfaceMember xlink:href="#poly-ac37a7bd-93ef-4fd0-8b7f-195191089206"/>
							<gml:surfaceMember xlink:href="#poly-18085a6a-700c-4569-be39-d1e24b16db7a"/>
							<gml:surfaceMember xlink:href="#poly-ea320b25-4b9d-4039-8e90-6e6d983c1154"/>
							<gml:surfaceMember xlink:href="#poly-f9630e30-e577-46f1-aded-9cb544e92a42"/>
							<gml:surfaceMember xlink:href="#poly-bf829626-4eb6-4d05-9535-62194a87d245"/>
							<gml:surfaceMember xlink:href="#poly-a5edf659-c68b-4ba7-9c39-13748d2a4d77"/>
							<gml:surfaceMember xlink:href="#poly-a61feb43-1306-4590-b956-82aec5a03195"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c50c052a-db33-4afb-a47f-1485bfa0f0ce_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e689c7bf-d521-4f09-8f84-31324baa3655">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66844538737343 139.739036968496 13.42 35.66841887470098 139.73900976026607 13.42 35.66843159493016 139.73898911139173 13.42 35.66844360636135 139.73899566962453 13.42 35.66847093992606 139.7390236942964 13.42 35.668455093934995 139.73904690952165 13.42 35.66844538737343 139.739036968496 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1920a674-b0fb-41a5-a79c-e99c1af5e6e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1920a674-b0fb-41a5-a79c-e99c1af5e6e3_0">
											<gml:posList>35.66841887470098 139.73900976026607 35.294 35.66843159493016 139.73898911139173 35.294 35.66843159493016 139.73898911139173 13.42 35.66841887470098 139.73900976026607 13.42 35.66841887470098 139.73900976026607 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f75f435c-cd61-4f6c-ad70-360c097ab521">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f75f435c-cd61-4f6c-ad70-360c097ab521_0">
											<gml:posList>35.66841887470098 139.73900976026607 13.42 35.66844538737343 139.739036968496 13.42 35.66844538737343 139.739036968496 35.294 35.66841887470098 139.73900976026607 35.294 35.66841887470098 139.73900976026607 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59094c1d-54d7-4dbf-9038-1f24884a61c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59094c1d-54d7-4dbf-9038-1f24884a61c9_0">
											<gml:posList>35.66843159493016 139.73898911139173 13.42 35.66843159493016 139.73898911139173 35.294 35.66844360636135 139.73899566962453 35.294 35.66844360636135 139.73899566962453 13.42 35.66843159493016 139.73898911139173 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4df982b-a8de-41a6-95d5-6101f58d70ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4df982b-a8de-41a6-95d5-6101f58d70ad_0">
											<gml:posList>35.66847093992606 139.7390236942964 35.294 35.66844360636135 139.73899566962453 35.294 35.66843159493016 139.73898911139173 35.294 35.66841887470098 139.73900976026607 35.294 35.66844538737343 139.739036968496 35.294 35.668455093934995 139.73904690952165 35.294 35.66847093992606 139.7390236942964 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d29cdfa-4bdf-41d2-b4f2-55e40022d4fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d29cdfa-4bdf-41d2-b4f2-55e40022d4fd_0">
											<gml:posList>35.668455093934995 139.73904690952165 13.42 35.668455093934995 139.73904690952165 35.294 35.66844538737343 139.739036968496 35.294 35.66844538737343 139.739036968496 13.42 35.668455093934995 139.73904690952165 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4707bde-a8d8-4489-99c5-b662f5e6e66f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4707bde-a8d8-4489-99c5-b662f5e6e66f_0">
											<gml:posList>35.66844360636135 139.73899566962453 13.42 35.66844360636135 139.73899566962453 35.294 35.66847093992606 139.7390236942964 35.294 35.66847093992606 139.7390236942964 13.42 35.66844360636135 139.73899566962453 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f5d727a-55a5-44a8-9660-f2a40045fd73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f5d727a-55a5-44a8-9660-f2a40045fd73_0">
											<gml:posList>35.668455093934995 139.73904690952165 13.42 35.66847093992606 139.7390236942964 13.42 35.66847093992606 139.7390236942964 35.294 35.668455093934995 139.73904690952165 35.294 35.668455093934995 139.73904690952165 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-25798122-fc6d-4c05-8504-80f2c2342a2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25798122-fc6d-4c05-8504-80f2c2342a2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25798122-fc6d-4c05-8504-80f2c2342a2d">
											<gml:posList>35.66841887470098 139.73900976026607 13.42 35.66844625339169 139.73903786220296 13.42 35.66843463900579 139.73905488668805 13.42 35.66840883899259 139.73902840665284 13.42 35.66839317310196 139.73905140072767 13.42 35.66832650820362 139.73898321498007 13.42 35.668404117489935 139.73886957091202 13.42 35.6684779993198 139.73894525941293 13.42 35.66844360636135 139.73899566962453 13.42 35.66843159493016 139.73898911139173 13.42 35.66841887470098 139.73900976026607 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f1748edc-8492-44e5-b20e-83992751d6e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1748edc-8492-44e5-b20e-83992751d6e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1748edc-8492-44e5-b20e-83992751d6e1">
											<gml:posList>35.66839317310196 139.73905140072767 35.294 35.66839285410149 139.73904690538666 35.294 35.668330176478285 139.7389828130085 35.294 35.66832650820362 139.73898321498007 35.294 35.66839317310196 139.73905140072767 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ae777d9-32e6-40d4-b4dc-b0ef8dbd9294">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ae777d9-32e6-40d4-b4dc-b0ef8dbd9294">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ae777d9-32e6-40d4-b4dc-b0ef8dbd9294">
											<gml:posList>35.66832650820362 139.73898321498007 35.294 35.668330176478285 139.7389828130085 35.294 35.66840445451581 139.73887405518573 35.294 35.668404117489935 139.73886957091202 35.294 35.66832650820362 139.73898321498007 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8bd7fd6-abef-4a63-9fe9-ca12b272d232">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8bd7fd6-abef-4a63-9fe9-ca12b272d232">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8bd7fd6-abef-4a63-9fe9-ca12b272d232">
											<gml:posList>35.66840883899259 139.73902840665284 35.294 35.66840518873662 139.7390287975555 35.294 35.66839285410149 139.73904690538666 35.294 35.66839317310196 139.73905140072767 35.294 35.66840883899259 139.73902840665284 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-074e52a6-3caa-4da0-915e-ffe0e28d14f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-074e52a6-3caa-4da0-915e-ffe0e28d14f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-074e52a6-3caa-4da0-915e-ffe0e28d14f8">
											<gml:posList>35.66843076257776 139.7389851689524 34.839 35.668442873194756 139.7389917712518 34.839 35.66847434005908 139.7389456613763 34.839 35.66840445451581 139.73887405518573 34.839 35.668330176478285 139.7389828130085 34.839 35.66839285410149 139.73904690538666 34.839 35.66840518873662 139.7390287975555 34.839 35.668403592026934 139.73902716462732 34.839 35.66841680002997 139.73900782965856 34.839 35.66843076257776 139.7389851689524 34.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a5513b2-d362-4afc-bda5-d286eb58c78c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a5513b2-d362-4afc-bda5-d286eb58c78c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a5513b2-d362-4afc-bda5-d286eb58c78c">
											<gml:posList>35.66840724228289 139.7390267737246 35.294 35.668403592026934 139.73902716462732 35.294 35.66840518873662 139.7390287975555 35.294 35.66840883899259 139.73902840665284 35.294 35.66840724228289 139.7390267737246 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8da5d77d-6490-434d-839b-b98cbfc09c7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8da5d77d-6490-434d-839b-b98cbfc09c7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8da5d77d-6490-434d-839b-b98cbfc09c7c">
											<gml:posList>35.66840724228289 139.7390267737246 35.294 35.66841887470098 139.73900976026607 35.294 35.66841680002997 139.73900782965856 35.294 35.668403592026934 139.73902716462732 35.294 35.66840724228289 139.7390267737246 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ea8eb762-370d-452e-b3de-86b5e13f7485">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea8eb762-370d-452e-b3de-86b5e13f7485">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea8eb762-370d-452e-b3de-86b5e13f7485">
											<gml:posList>35.66843159493016 139.73898911139173 35.294 35.66843076257776 139.7389851689524 35.294 35.66841680002997 139.73900782965856 35.294 35.66841887470098 139.73900976026607 35.294 35.66843159493016 139.73898911139173 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-04b968b2-9719-4bad-bd68-48a4634b899f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04b968b2-9719-4bad-bd68-48a4634b899f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04b968b2-9719-4bad-bd68-48a4634b899f">
											<gml:posList>35.66840724228289 139.7390267737246 38.968 35.66843463900579 139.73905488668805 38.968 35.66844625339169 139.73903786220296 38.968 35.66841887470098 139.73900976026607 38.968 35.66840724228289 139.7390267737246 38.968</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ada0e1d0-0258-419e-a862-625be3d85c59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ada0e1d0-0258-419e-a862-625be3d85c59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ada0e1d0-0258-419e-a862-625be3d85c59">
											<gml:posList>35.66843159493016 139.73898911139173 35.294 35.66844360636135 139.73899566962453 35.294 35.668442873194756 139.7389917712518 35.294 35.66843076257776 139.7389851689524 35.294 35.66843159493016 139.73898911139173 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8c1c01b-4639-4c14-985a-189d1661e2c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8c1c01b-4639-4c14-985a-189d1661e2c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8c1c01b-4639-4c14-985a-189d1661e2c9">
											<gml:posList>35.668404117489935 139.73886957091202 35.294 35.66840445451581 139.73887405518573 35.294 35.66847434005908 139.7389456613763 35.294 35.6684779993198 139.73894525941293 35.294 35.668404117489935 139.73886957091202 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e65bf989-aeb1-44bc-a913-dcb036f5ecc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e65bf989-aeb1-44bc-a913-dcb036f5ecc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e65bf989-aeb1-44bc-a913-dcb036f5ecc4">
											<gml:posList>35.66844360636135 139.73899566962453 35.294 35.6684779993198 139.73894525941293 35.294 35.66847434005908 139.7389456613763 35.294 35.668442873194756 139.7389917712518 35.294 35.66844360636135 139.73899566962453 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ae8cf59-9cde-447b-a8f7-001a0bf9cb4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ae8cf59-9cde-447b-a8f7-001a0bf9cb4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ae8cf59-9cde-447b-a8f7-001a0bf9cb4b">
											<gml:posList>35.66832650820362 139.73898321498007 13.42 35.66839317310196 139.73905140072767 13.42 35.66839317310196 139.73905140072767 35.294 35.66832650820362 139.73898321498007 35.294 35.66832650820362 139.73898321498007 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72e16f62-33ab-4d47-9d94-9cda0465de14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72e16f62-33ab-4d47-9d94-9cda0465de14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72e16f62-33ab-4d47-9d94-9cda0465de14">
											<gml:posList>35.66839285410149 139.73904690538666 35.294 35.66839285410149 139.73904690538666 34.839 35.668330176478285 139.7389828130085 34.839 35.668330176478285 139.7389828130085 35.294 35.66839285410149 139.73904690538666 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30ff4ba0-bd99-406a-855b-e2eb69ad26af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30ff4ba0-bd99-406a-855b-e2eb69ad26af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30ff4ba0-bd99-406a-855b-e2eb69ad26af">
											<gml:posList>35.668404117489935 139.73886957091202 13.42 35.66832650820362 139.73898321498007 13.42 35.66832650820362 139.73898321498007 35.294 35.668404117489935 139.73886957091202 35.294 35.668404117489935 139.73886957091202 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6058d776-f19c-4f57-a75c-242d4796df09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6058d776-f19c-4f57-a75c-242d4796df09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6058d776-f19c-4f57-a75c-242d4796df09">
											<gml:posList>35.668330176478285 139.7389828130085 35.294 35.668330176478285 139.7389828130085 34.839 35.66840445451581 139.73887405518573 34.839 35.66840445451581 139.73887405518573 35.294 35.668330176478285 139.7389828130085 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec89346e-14af-4af8-9a61-1c0b5cca39d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec89346e-14af-4af8-9a61-1c0b5cca39d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec89346e-14af-4af8-9a61-1c0b5cca39d6">
											<gml:posList>35.66840518873662 139.7390287975555 35.294 35.66840518873662 139.7390287975555 34.839 35.66839285410149 139.73904690538666 34.839 35.66839285410149 139.73904690538666 35.294 35.66840518873662 139.7390287975555 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71471ca5-1011-4d2d-9dd6-6dd6c662599a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71471ca5-1011-4d2d-9dd6-6dd6c662599a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71471ca5-1011-4d2d-9dd6-6dd6c662599a">
											<gml:posList>35.66839317310196 139.73905140072767 13.42 35.66840883899259 139.73902840665284 13.42 35.66840883899259 139.73902840665284 35.294 35.66839317310196 139.73905140072767 35.294 35.66839317310196 139.73905140072767 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef9cd903-df10-4551-9b9e-10c6cc7d28e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef9cd903-df10-4551-9b9e-10c6cc7d28e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef9cd903-df10-4551-9b9e-10c6cc7d28e3">
											<gml:posList>35.668403592026934 139.73902716462732 35.294 35.668403592026934 139.73902716462732 34.839 35.66840518873662 139.7390287975555 34.839 35.66840518873662 139.7390287975555 35.294 35.668403592026934 139.73902716462732 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08d499dd-ca48-467e-9190-430cd96e68a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08d499dd-ca48-467e-9190-430cd96e68a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08d499dd-ca48-467e-9190-430cd96e68a9">
											<gml:posList>35.66841680002997 139.73900782965856 35.294 35.66841680002997 139.73900782965856 34.839 35.668403592026934 139.73902716462732 34.839 35.668403592026934 139.73902716462732 35.294 35.66841680002997 139.73900782965856 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c940452-41f7-47b4-b5ed-950d5f47e3ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c940452-41f7-47b4-b5ed-950d5f47e3ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c940452-41f7-47b4-b5ed-950d5f47e3ee">
											<gml:posList>35.66840724228289 139.7390267737246 38.968 35.66841887470098 139.73900976026607 38.968 35.66841887470098 139.73900976026607 35.294 35.66840724228289 139.7390267737246 35.294 35.66840724228289 139.7390267737246 38.968</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa2d8154-7d6b-4fbc-b76c-5147fb5b9792">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa2d8154-7d6b-4fbc-b76c-5147fb5b9792">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa2d8154-7d6b-4fbc-b76c-5147fb5b9792">
											<gml:posList>35.66840883899259 139.73902840665284 35.294 35.66840883899259 139.73902840665284 13.42 35.66843463900579 139.73905488668805 13.42 35.66843463900579 139.73905488668805 38.968 35.66840724228289 139.7390267737246 38.968 35.66840724228289 139.7390267737246 35.294 35.66840883899259 139.73902840665284 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-886fbf5e-c492-46a6-9faa-056b96f4c0ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-886fbf5e-c492-46a6-9faa-056b96f4c0ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-886fbf5e-c492-46a6-9faa-056b96f4c0ad">
											<gml:posList>35.66843076257776 139.7389851689524 35.294 35.66843076257776 139.7389851689524 34.839 35.66841680002997 139.73900782965856 34.839 35.66841680002997 139.73900782965856 35.294 35.66843076257776 139.7389851689524 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e98a287-919d-4b6f-bea6-2387c05d3061">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e98a287-919d-4b6f-bea6-2387c05d3061">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e98a287-919d-4b6f-bea6-2387c05d3061">
											<gml:posList>35.66841887470098 139.73900976026607 13.42 35.66843159493016 139.73898911139173 13.42 35.66843159493016 139.73898911139173 35.294 35.66841887470098 139.73900976026607 35.294 35.66841887470098 139.73900976026607 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c124c63-d590-41be-a995-2b0893629e9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c124c63-d590-41be-a995-2b0893629e9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c124c63-d590-41be-a995-2b0893629e9d">
											<gml:posList>35.66844625339169 139.73903786220296 38.968 35.66844625339169 139.73903786220296 13.42 35.66841887470098 139.73900976026607 13.42 35.66841887470098 139.73900976026607 35.294 35.66841887470098 139.73900976026607 38.968 35.66844625339169 139.73903786220296 38.968</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac37a7bd-93ef-4fd0-8b7f-195191089206">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac37a7bd-93ef-4fd0-8b7f-195191089206">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac37a7bd-93ef-4fd0-8b7f-195191089206">
											<gml:posList>35.668442873194756 139.7389917712518 35.294 35.668442873194756 139.7389917712518 34.839 35.66843076257776 139.7389851689524 34.839 35.66843076257776 139.7389851689524 35.294 35.668442873194756 139.7389917712518 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18085a6a-700c-4569-be39-d1e24b16db7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18085a6a-700c-4569-be39-d1e24b16db7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18085a6a-700c-4569-be39-d1e24b16db7a">
											<gml:posList>35.66843159493016 139.73898911139173 13.42 35.66844360636135 139.73899566962453 13.42 35.66844360636135 139.73899566962453 35.294 35.66843159493016 139.73898911139173 35.294 35.66843159493016 139.73898911139173 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea320b25-4b9d-4039-8e90-6e6d983c1154">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea320b25-4b9d-4039-8e90-6e6d983c1154">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea320b25-4b9d-4039-8e90-6e6d983c1154">
											<gml:posList>35.66840445451581 139.73887405518573 35.294 35.66840445451581 139.73887405518573 34.839 35.66847434005908 139.7389456613763 34.839 35.66847434005908 139.7389456613763 35.294 35.66840445451581 139.73887405518573 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9630e30-e577-46f1-aded-9cb544e92a42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9630e30-e577-46f1-aded-9cb544e92a42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9630e30-e577-46f1-aded-9cb544e92a42">
											<gml:posList>35.66843463900579 139.73905488668805 38.968 35.66843463900579 139.73905488668805 13.42 35.66844625339169 139.73903786220296 13.42 35.66844625339169 139.73903786220296 38.968 35.66843463900579 139.73905488668805 38.968</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf829626-4eb6-4d05-9535-62194a87d245">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf829626-4eb6-4d05-9535-62194a87d245">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf829626-4eb6-4d05-9535-62194a87d245">
											<gml:posList>35.6684779993198 139.73894525941293 13.42 35.668404117489935 139.73886957091202 13.42 35.668404117489935 139.73886957091202 35.294 35.6684779993198 139.73894525941293 35.294 35.6684779993198 139.73894525941293 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5edf659-c68b-4ba7-9c39-13748d2a4d77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5edf659-c68b-4ba7-9c39-13748d2a4d77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5edf659-c68b-4ba7-9c39-13748d2a4d77">
											<gml:posList>35.66847434005908 139.7389456613763 35.294 35.66847434005908 139.7389456613763 34.839 35.668442873194756 139.7389917712518 34.839 35.668442873194756 139.7389917712518 35.294 35.66847434005908 139.7389456613763 35.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a61feb43-1306-4590-b956-82aec5a03195">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a61feb43-1306-4590-b956-82aec5a03195">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a61feb43-1306-4590-b956-82aec5a03195">
											<gml:posList>35.66844360636135 139.73899566962453 13.42 35.6684779993198 139.73894525941293 13.42 35.6684779993198 139.73894525941293 35.294 35.66844360636135 139.73899566962453 35.294 35.66844360636135 139.73899566962453 13.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2344</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">156.667</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>