<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c5828232-0c9e-448a-a6d1-2619698b396a">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:measuredHeight uom="m">3.3</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669788806770164 139.7446777873913 0 35.66976043085804 139.74470134711865 0 35.66978164148081 139.74473987483108 0 35.66981010753763 139.74471631501152 0 35.669788806770164 139.7446777873913 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669788806770164 139.7446777873913 9.564 35.66981010753763 139.74471631501152 9.564 35.66978164148081 139.74473987483108 9.564 35.66976043085804 139.74470134711865 9.564 35.669788806770164 139.7446777873913 9.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669788806770164 139.7446777873913 9.564 35.66976043085804 139.74470134711865 9.564 35.66976043085804 139.74470134711865 12.82 35.669788806770164 139.7446777873913 12.82 35.669788806770164 139.7446777873913 9.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66976043085804 139.74470134711865 9.564 35.66978164148081 139.74473987483108 9.564 35.66978164148081 139.74473987483108 12.82 35.66976043085804 139.74470134711865 12.82 35.66976043085804 139.74470134711865 9.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66978164148081 139.74473987483108 9.564 35.66981010753763 139.74471631501152 9.564 35.66981010753763 139.74471631501152 12.82 35.66978164148081 139.74473987483108 12.82 35.66978164148081 139.74473987483108 9.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66981010753763 139.74471631501152 9.564 35.669788806770164 139.7446777873913 9.564 35.669788806770164 139.7446777873913 12.82 35.66981010753763 139.74471631501152 12.82 35.66981010753763 139.74471631501152 9.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669788806770164 139.7446777873913 12.82 35.66976043085804 139.74470134711865 12.82 35.66978164148081 139.74473987483108 12.82 35.66981010753763 139.74471631501152 12.82 35.669788806770164 139.7446777873913 12.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1874f47b-391c-4d01-86af-0dda5efe5749"/>
							<gml:surfaceMember xlink:href="#poly-21e031d2-a96a-4699-b809-51a65f4cc0cd"/>
							<gml:surfaceMember xlink:href="#poly-c4dbd924-5322-4226-b8cd-6c213424e4ce"/>
							<gml:surfaceMember xlink:href="#poly-58c4b58c-9b62-493c-8df9-2d2e61dc6fea"/>
							<gml:surfaceMember xlink:href="#poly-0c779220-ab58-45d4-b9a8-928c5aef1b90"/>
							<gml:surfaceMember xlink:href="#poly-a2c7631d-9311-4411-bed2-07a816bb9e32"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1874f47b-391c-4d01-86af-0dda5efe5749">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1874f47b-391c-4d01-86af-0dda5efe5749">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1874f47b-391c-4d01-86af-0dda5efe5749">
											<gml:posList>35.66978880677014 139.7446777873913 9.564 35.66981010753761 139.74471631501152 9.564 35.669781641480796 139.74473987483108 9.564 35.66976043085804 139.74470134711865 9.564 35.66978880677014 139.7446777873913 9.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21e031d2-a96a-4699-b809-51a65f4cc0cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21e031d2-a96a-4699-b809-51a65f4cc0cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21e031d2-a96a-4699-b809-51a65f4cc0cd">
											<gml:posList>35.66981010753761 139.74471631501152 12.6 35.66978880677014 139.7446777873913 12.6 35.66976043085804 139.74470134711865 12.6 35.669781641480796 139.74473987483108 12.6 35.66981010753761 139.74471631501152 12.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4dbd924-5322-4226-b8cd-6c213424e4ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4dbd924-5322-4226-b8cd-6c213424e4ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4dbd924-5322-4226-b8cd-6c213424e4ce">
											<gml:posList>35.66978880677014 139.7446777873913 9.564 35.66976043085804 139.74470134711865 9.564 35.66976043085804 139.74470134711865 12.6 35.66978880677014 139.7446777873913 12.6 35.66978880677014 139.7446777873913 9.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58c4b58c-9b62-493c-8df9-2d2e61dc6fea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58c4b58c-9b62-493c-8df9-2d2e61dc6fea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58c4b58c-9b62-493c-8df9-2d2e61dc6fea">
											<gml:posList>35.66981010753761 139.74471631501152 9.564 35.66978880677014 139.7446777873913 9.564 35.66978880677014 139.7446777873913 12.6 35.66981010753761 139.74471631501152 12.6 35.66981010753761 139.74471631501152 9.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c779220-ab58-45d4-b9a8-928c5aef1b90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c779220-ab58-45d4-b9a8-928c5aef1b90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c779220-ab58-45d4-b9a8-928c5aef1b90">
											<gml:posList>35.66976043085804 139.74470134711865 9.564 35.669781641480796 139.74473987483108 9.564 35.669781641480796 139.74473987483108 12.6 35.66976043085804 139.74470134711865 12.6 35.66976043085804 139.74470134711865 9.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2c7631d-9311-4411-bed2-07a816bb9e32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2c7631d-9311-4411-bed2-07a816bb9e32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2c7631d-9311-4411-bed2-07a816bb9e32">
											<gml:posList>35.669781641480796 139.74473987483108 9.564 35.66981010753761 139.74471631501152 9.564 35.66981010753761 139.74471631501152 12.6 35.669781641480796 139.74473987483108 12.6 35.669781641480796 139.74473987483108 9.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-353</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>