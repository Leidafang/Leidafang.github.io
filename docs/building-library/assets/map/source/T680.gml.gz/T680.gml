<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c5ca35e6-1738-4623-a4fd-9f60ebeaae41">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">12</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67079080658001 139.73811063867856 0 35.670789725195526 139.73811097135237 0 35.6708094547333 139.7382116903437 0 35.67099221084232 139.73815811968035 0 35.670956552316675 139.7379755660328 0 35.67077478762289 139.73802891498335 0 35.67079080658001 139.73811063867856 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67079080658001 139.73811063867856 17.2 35.67077478762289 139.73802891498335 17.2 35.670956552316675 139.7379755660328 17.2 35.67099221084232 139.73815811968035 17.2 35.6708094547333 139.7382116903437 17.2 35.670789725195526 139.73811097135237 17.2 35.67079080658001 139.73811063867856 17.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67079080658001 139.73811063867856 17.2 35.670789725195526 139.73811097135237 17.2 35.670789725195526 139.73811097135237 29.23 35.67079080658001 139.73811063867856 29.23 35.67079080658001 139.73811063867856 17.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670789725195526 139.73811097135237 17.2 35.6708094547333 139.7382116903437 17.2 35.6708094547333 139.7382116903437 29.23 35.670789725195526 139.73811097135237 29.23 35.670789725195526 139.73811097135237 17.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6708094547333 139.7382116903437 17.2 35.67099221084232 139.73815811968035 17.2 35.67099221084232 139.73815811968035 29.23 35.6708094547333 139.7382116903437 29.23 35.6708094547333 139.7382116903437 17.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67099221084232 139.73815811968035 17.2 35.670956552316675 139.7379755660328 17.2 35.670956552316675 139.7379755660328 29.23 35.67099221084232 139.73815811968035 29.23 35.67099221084232 139.73815811968035 17.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670956552316675 139.7379755660328 17.2 35.67077478762289 139.73802891498335 17.2 35.67077478762289 139.73802891498335 29.23 35.670956552316675 139.7379755660328 29.23 35.670956552316675 139.7379755660328 17.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67077478762289 139.73802891498335 17.2 35.67079080658001 139.73811063867856 17.2 35.67079080658001 139.73811063867856 29.23 35.67077478762289 139.73802891498335 29.23 35.67077478762289 139.73802891498335 17.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67079080658001 139.73811063867856 29.23 35.670789725195526 139.73811097135237 29.23 35.6708094547333 139.7382116903437 29.23 35.67099221084232 139.73815811968035 29.23 35.670956552316675 139.7379755660328 29.23 35.67077478762289 139.73802891498335 29.23 35.67079080658001 139.73811063867856 29.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-dd616d3f-ac59-4c92-859e-8b012032d548"/>
							<gml:surfaceMember xlink:href="#poly-7e229115-f18e-4f60-a0df-8b80b293b7ec"/>
							<gml:surfaceMember xlink:href="#poly-6b8a5598-500d-4bea-ac7d-924f9cb3ced5"/>
							<gml:surfaceMember xlink:href="#poly-0dfc229c-bc9c-4b14-bf00-2823aa3a8611"/>
							<gml:surfaceMember xlink:href="#poly-5e47071a-a99d-441b-88fc-cda1431a3ee0"/>
							<gml:surfaceMember xlink:href="#poly-b97f1873-c563-4a72-937a-2a7b7bf6e649"/>
							<gml:surfaceMember xlink:href="#poly-980b6430-59fc-4f29-9522-1d1a2601e04f"/>
							<gml:surfaceMember xlink:href="#poly-dc1e18d7-ccb8-4a55-94f6-0b6c3157d456"/>
							<gml:surfaceMember xlink:href="#poly-db480919-9829-4b4a-8728-cd197ffd74ae"/>
							<gml:surfaceMember xlink:href="#poly-c853d716-1687-42e9-98c7-e81a1bb605f9"/>
							<gml:surfaceMember xlink:href="#poly-07986726-ef27-452e-bade-518db2ecf088"/>
							<gml:surfaceMember xlink:href="#poly-401aacbc-bd02-4d79-968c-7491c46fce80"/>
							<gml:surfaceMember xlink:href="#poly-91b93878-0ddb-4a65-8b71-391f586c7a2c"/>
							<gml:surfaceMember xlink:href="#poly-e456cb4b-e20f-4a96-b6ab-ece6cd7f77e6"/>
							<gml:surfaceMember xlink:href="#poly-70d9c2e8-d444-47fa-996a-b46dda42db64"/>
							<gml:surfaceMember xlink:href="#poly-05fa5b97-bca3-4200-a0ae-8abb2c62b61f"/>
							<gml:surfaceMember xlink:href="#poly-6948b239-dbd1-43e4-9d81-f5526ef77db8"/>
							<gml:surfaceMember xlink:href="#poly-e038909a-7d82-4c5c-9123-5dba9e3fed75"/>
							<gml:surfaceMember xlink:href="#poly-e5f3d1c6-a424-44f9-8f8c-6baf18b1a342"/>
							<gml:surfaceMember xlink:href="#poly-cf2697eb-5a6c-4c63-9e76-cf48fb4f31c9"/>
							<gml:surfaceMember xlink:href="#poly-c8c4e7a4-ec7b-4b4c-bae4-af75630edb2e"/>
							<gml:surfaceMember xlink:href="#poly-7d4429d0-3372-4876-8891-d1f8acc2878a"/>
							<gml:surfaceMember xlink:href="#poly-18efbfae-380b-4911-8984-7f889b6d9a19"/>
							<gml:surfaceMember xlink:href="#poly-a5ea00d6-0653-42ef-bee0-1ee575893d5d"/>
							<gml:surfaceMember xlink:href="#poly-0869bb9e-a02e-4b9a-bca3-be5e41d82494"/>
							<gml:surfaceMember xlink:href="#poly-fc0f48e1-a593-4892-bd2e-439fa79c2cbc"/>
							<gml:surfaceMember xlink:href="#poly-628642ca-9cb0-4bb6-8d29-3597584c6b03"/>
							<gml:surfaceMember xlink:href="#poly-6bf1721a-7758-44e7-b8f1-4d8894b17512"/>
							<gml:surfaceMember xlink:href="#poly-56442973-d1b4-4a2a-893e-e19624ce64ac"/>
							<gml:surfaceMember xlink:href="#poly-d776c8cd-7a26-4dc2-a586-6729df0081da"/>
							<gml:surfaceMember xlink:href="#poly-c3f3a1c9-51b9-4c70-b671-6a844f090b19"/>
							<gml:surfaceMember xlink:href="#poly-7c22feb5-3692-49cf-af6b-b3dfd31c6db2"/>
							<gml:surfaceMember xlink:href="#poly-bc620328-0e02-4cb3-acd2-daeaad4f5bce"/>
							<gml:surfaceMember xlink:href="#poly-e16b3de3-dbbf-443c-9a9b-eef35c39b662"/>
							<gml:surfaceMember xlink:href="#poly-8d030255-1129-491a-8502-c864c8848a11"/>
							<gml:surfaceMember xlink:href="#poly-20c4ad7b-e799-4af7-a45b-5e8543bb187d"/>
							<gml:surfaceMember xlink:href="#poly-899babbe-12d4-4ecb-99df-3c7dba728c7f"/>
							<gml:surfaceMember xlink:href="#poly-46c8fddf-c8ae-4fb2-8481-c748ee77a339"/>
							<gml:surfaceMember xlink:href="#poly-d436fed7-6e0f-4d95-b245-5ec35214fc83"/>
							<gml:surfaceMember xlink:href="#poly-6f4bad49-ebaf-4a9c-9cb8-fce140c10e7b"/>
							<gml:surfaceMember xlink:href="#poly-fceda3c5-bb89-4d21-824f-314388604bf7"/>
							<gml:surfaceMember xlink:href="#poly-0a689a8e-bbbd-4436-b517-162a84dd0caa"/>
							<gml:surfaceMember xlink:href="#poly-005fad8a-de44-490d-bf3f-c5fae65ce447"/>
							<gml:surfaceMember xlink:href="#poly-98858c98-1964-474a-92a8-37a268f7f885"/>
							<gml:surfaceMember xlink:href="#poly-7a4052a8-02c2-409e-8c02-acff93b6ff19"/>
							<gml:surfaceMember xlink:href="#poly-6cac3653-d429-4c8c-b23d-e4c988087655"/>
							<gml:surfaceMember xlink:href="#poly-7528595d-257f-44d8-a3c2-70650bad1e5c"/>
							<gml:surfaceMember xlink:href="#poly-2257973c-06b3-4c04-9734-2c697d73b182"/>
							<gml:surfaceMember xlink:href="#poly-d50e22db-7a52-4c7c-8cf0-11424f2ee398"/>
							<gml:surfaceMember xlink:href="#poly-0c85cfe1-20b0-4dc8-a4a4-f438cd35cd99"/>
							<gml:surfaceMember xlink:href="#poly-8216eb9b-9b3a-4ba0-8842-d0b4441320a8"/>
							<gml:surfaceMember xlink:href="#poly-48f9a032-90ba-4632-b089-aaf6c671eb37"/>
							<gml:surfaceMember xlink:href="#poly-7f6cb17a-9be3-4ceb-a625-56452d2a38e7"/>
							<gml:surfaceMember xlink:href="#poly-222ce889-958b-46c2-8eed-900afe2930bd"/>
							<gml:surfaceMember xlink:href="#poly-84c09348-80b1-43ba-a209-1decb7f4e65d"/>
							<gml:surfaceMember xlink:href="#poly-c321b84e-d2e2-4b6c-a0b0-bec0b2be32fa"/>
							<gml:surfaceMember xlink:href="#poly-34b03c87-c65d-4eb7-b463-0ef7cc60a249"/>
							<gml:surfaceMember xlink:href="#poly-37a34790-d567-4439-abfc-88d3fbc5e300"/>
							<gml:surfaceMember xlink:href="#poly-9852749d-ec4d-412f-9853-0da55ba9dc68"/>
							<gml:surfaceMember xlink:href="#poly-11ba11e1-8889-45f1-9eed-e6df8f6d6234"/>
							<gml:surfaceMember xlink:href="#poly-de34545c-40cb-45cc-a08f-feadb416961b"/>
							<gml:surfaceMember xlink:href="#poly-21e831f9-a9be-4d7b-9f7a-e9ad352882a5"/>
							<gml:surfaceMember xlink:href="#poly-556b36f2-aa4d-49a7-a298-c8d7321c4804"/>
							<gml:surfaceMember xlink:href="#poly-38394f7b-f8ef-4158-832e-4ce8ae14c966"/>
							<gml:surfaceMember xlink:href="#poly-7c2d013f-d9b6-420f-a84a-8a554ed2b9aa"/>
							<gml:surfaceMember xlink:href="#poly-c49e36dc-a130-4808-922a-95d4257331c6"/>
							<gml:surfaceMember xlink:href="#poly-7a9ee4e8-43f0-4cb6-a248-50ca856fdf2b"/>
							<gml:surfaceMember xlink:href="#poly-dc802312-c67a-4399-bbfb-e1cacc5e2a76"/>
							<gml:surfaceMember xlink:href="#poly-4ec9d2bb-6986-4339-84e3-6f9eeb2a2e00"/>
							<gml:surfaceMember xlink:href="#poly-15bc44b8-8722-455e-a350-af13a1a304fb"/>
							<gml:surfaceMember xlink:href="#poly-a79477e8-b4ff-4cb9-9552-906fa4e4a150"/>
							<gml:surfaceMember xlink:href="#poly-0012b340-e7c7-4d46-a31d-3fd957d0ca13"/>
							<gml:surfaceMember xlink:href="#poly-5ff9935d-e7e2-488c-8d3b-e9dbb68a3cfa"/>
							<gml:surfaceMember xlink:href="#poly-c4146549-dac3-41f2-bc59-a00d37c77f0c"/>
							<gml:surfaceMember xlink:href="#poly-8f0cc8de-ee54-49a4-bf70-5a34443044cc"/>
							<gml:surfaceMember xlink:href="#poly-1f71754c-f17c-4f44-a728-6f4164124835"/>
							<gml:surfaceMember xlink:href="#poly-168751ee-59ab-4fb5-8d8b-3440cc801f02"/>
							<gml:surfaceMember xlink:href="#poly-3263e983-6fd0-462b-a0e3-2d3bcab89ab5"/>
							<gml:surfaceMember xlink:href="#poly-96b7f1f6-2dfe-44b4-ba15-86054092cb32"/>
							<gml:surfaceMember xlink:href="#poly-b28ee8cc-8797-4446-a33a-7b4fa9573ee3"/>
							<gml:surfaceMember xlink:href="#poly-dbb0432b-840f-4267-908b-8a06a23dbd81"/>
							<gml:surfaceMember xlink:href="#poly-47fc85c9-9bbb-417d-a061-48f52fd067d1"/>
							<gml:surfaceMember xlink:href="#poly-3a3c6c3d-4dbf-453b-94a6-0e88451cb008"/>
							<gml:surfaceMember xlink:href="#poly-2d504a95-3a7d-481b-8721-3f86703845be"/>
							<gml:surfaceMember xlink:href="#poly-f2e4b8e8-bd2d-4137-95e6-40abff4e32f6"/>
							<gml:surfaceMember xlink:href="#poly-674b5c08-d499-4cad-8a21-6a77b9d0e61a"/>
							<gml:surfaceMember xlink:href="#poly-0205870f-d8bb-454c-85a9-7f6df20171c9"/>
							<gml:surfaceMember xlink:href="#poly-4c244dc8-eb56-403d-99fb-d4f700688cc7"/>
							<gml:surfaceMember xlink:href="#poly-26ec132b-2d92-46a7-8169-8ca5cf7f2e0c"/>
							<gml:surfaceMember xlink:href="#poly-5f047de9-b950-480c-b0ca-d5e823617e01"/>
							<gml:surfaceMember xlink:href="#poly-101501f7-a700-4beb-992c-d2976023d9d5"/>
							<gml:surfaceMember xlink:href="#poly-b55703da-af67-4be9-9464-5a8dc551cccc"/>
							<gml:surfaceMember xlink:href="#poly-20134ee4-db1f-4534-8c24-43d0ae20fdbd"/>
							<gml:surfaceMember xlink:href="#poly-56d00ed9-0861-431e-b96e-798ea8666186"/>
							<gml:surfaceMember xlink:href="#poly-bf021945-d18a-4461-9beb-82df42fe80be"/>
							<gml:surfaceMember xlink:href="#poly-27cc951f-1171-4be0-a53f-f58db35935c2"/>
							<gml:surfaceMember xlink:href="#poly-522e90b2-2db5-44ef-ac54-cc476358533d"/>
							<gml:surfaceMember xlink:href="#poly-bfec797e-4f44-47cc-b2e0-58e09d2ccf50"/>
							<gml:surfaceMember xlink:href="#poly-d2cdc4e0-8ef8-4bda-93e4-e1c7f3e222f2"/>
							<gml:surfaceMember xlink:href="#poly-b027de07-caeb-49d0-a170-56258a59325f"/>
							<gml:surfaceMember xlink:href="#poly-43364011-0b82-494c-b926-c46f94524201"/>
							<gml:surfaceMember xlink:href="#poly-7090cf7c-414c-4e91-8e72-82cb480f43b3"/>
							<gml:surfaceMember xlink:href="#poly-10cb77e5-e798-4e68-8815-359dac23170a"/>
							<gml:surfaceMember xlink:href="#poly-bacd950a-b945-465e-b832-c645bc5bab00"/>
							<gml:surfaceMember xlink:href="#poly-82ae3d7d-ae68-4336-a7a5-f667829bc3da"/>
							<gml:surfaceMember xlink:href="#poly-9f68f192-a381-4329-a25f-b98bc740cba9"/>
							<gml:surfaceMember xlink:href="#poly-2423f549-543b-4178-9aa3-b183c98c45a3"/>
							<gml:surfaceMember xlink:href="#poly-1d431479-e7f0-47ae-81f1-c73a18e45466"/>
							<gml:surfaceMember xlink:href="#poly-1b4aa441-716c-44df-b83e-3b904d96536b"/>
							<gml:surfaceMember xlink:href="#poly-f3e236b8-95b6-483f-8f5a-2221ab4d7e30"/>
							<gml:surfaceMember xlink:href="#poly-d3c855b3-1bc7-4ea9-8e5b-d43f217400af"/>
							<gml:surfaceMember xlink:href="#poly-705a5225-5948-4da5-be87-7848b0f0f808"/>
							<gml:surfaceMember xlink:href="#poly-ed582bac-b0f9-4ee1-b8c3-d2068044a4b2"/>
							<gml:surfaceMember xlink:href="#poly-548b3151-a828-473e-aaa3-b400c70b7989"/>
							<gml:surfaceMember xlink:href="#poly-eb999aaf-b7fd-4881-a412-a52ecd7e7638"/>
							<gml:surfaceMember xlink:href="#poly-5db9b554-b19a-4bfc-9742-2b804faf1102"/>
							<gml:surfaceMember xlink:href="#poly-1131c3c9-e524-47ec-8068-9261fdff3e57"/>
							<gml:surfaceMember xlink:href="#poly-959030bd-ecc6-43b3-a585-ef9b9ebab1e7"/>
							<gml:surfaceMember xlink:href="#poly-e782442c-66a3-4277-a67b-af799e42f9cf"/>
							<gml:surfaceMember xlink:href="#poly-11c581de-8e71-434b-9676-e2d9ffb61f92"/>
							<gml:surfaceMember xlink:href="#poly-38a6c746-1bc2-4708-adc9-0dd7c028e7d9"/>
							<gml:surfaceMember xlink:href="#poly-bb1fa8c9-0ef5-4361-8f64-35b6cd17bf30"/>
							<gml:surfaceMember xlink:href="#poly-de2e167b-b8eb-400e-9aca-6fc93d6db50c"/>
							<gml:surfaceMember xlink:href="#poly-13737e84-1bb4-469c-8468-195d6e90f61f"/>
							<gml:surfaceMember xlink:href="#poly-b5c04e51-4b61-4d79-93df-ead5364e69e3"/>
							<gml:surfaceMember xlink:href="#poly-661c5666-128d-4dd6-9623-a43d83e286cf"/>
							<gml:surfaceMember xlink:href="#poly-17d14fed-5a56-4c3c-b3f3-f814ca18375d"/>
							<gml:surfaceMember xlink:href="#poly-7b641dbf-bd77-45dc-87bb-31b3ba8f9b32"/>
							<gml:surfaceMember xlink:href="#poly-68080b65-1f99-4bb0-a363-372b4b5f6d28"/>
							<gml:surfaceMember xlink:href="#poly-73bb8d88-bcf3-4a9a-86c4-86c4c28c1f56"/>
							<gml:surfaceMember xlink:href="#poly-8dfe137a-3487-4823-b07f-8bce5147acbc"/>
							<gml:surfaceMember xlink:href="#poly-df1f2d50-9dec-4de5-88bb-a3dc4f669c66"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c5ca35e6-1738-4623-a4fd-9f60ebeaae41_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c13a5f3d-7c8b-4adf-a208-0224444126aa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67081014023223 139.7380526556838 30.179 35.67080288588217 139.73805480729035 30.179 35.67080464163241 139.7380637637675 30.179 35.670803776524906 139.7380640299071 30.179 35.67080179456632 139.73805398011345 30.179 35.67080992304631 139.7380515734027 30.179 35.67081014023223 139.7380526556838 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6cd4a9ee-58af-4847-b39b-cf99b092c7fd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67081190500509 139.7380616231973 29.919 35.67080464163241 139.7380637637675 29.919 35.67080288588217 139.73805480729035 29.919 35.67081014023223 139.7380526556838 29.919 35.67081190500509 139.7380616231973 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04e21262-4daf-461c-af14-0e32ee5cafc3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67087543354398 139.73807272659096 34.033 35.67086556581743 139.73807564349897 34.033 35.67086312227226 139.73806320823937 34.033 35.67087299902099 139.73806030236554 34.033 35.67087543354398 139.73807272659096 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24fe9d0a-6ac9-46d7-b026-0f07ef664474">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67082312446779 139.738081084528 29.919 35.67082020048671 139.73806522548654 29.919 35.670830915467945 139.73806226338687 29.919 35.67083383944941 139.73807812243032 29.919 35.67082312446779 139.738081084528 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-854f81da-73df-4dfb-9931-e8580d38100b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670880409195654 139.73809560867102 42.847 35.67089876590849 139.73809022939548 42.847 35.67090201501795 139.7381068944494 42.847 35.670883658304376 139.73811227372136 42.847 35.670880409195654 139.73809560867102 42.847</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ccc2fc1-339a-4fdc-86b7-12786ac47584">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670902929027875 139.73814567703278 36.863 35.67090661252568 139.7381645397942 36.863 35.67089086918633 139.7381691537546 36.863 35.670887185689246 139.73815029099669 36.863 35.670902929027875 139.73814567703278 36.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0999ce71-b167-4da7-bb17-f833c3d934bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0999ce71-b167-4da7-bb17-f833c3d934bf_0">
											<gml:posList>35.67080992304631 139.7380515734027 30.179 35.67080179456632 139.73805398011345 30.179 35.67080179456632 139.73805398011345 31.107 35.67080992304631 139.7380515734027 31.107 35.67080992304631 139.7380515734027 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0970459-d47d-4229-8037-9f3692cc69d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0970459-d47d-4229-8037-9f3692cc69d9_0">
											<gml:posList>35.67080288588217 139.73805480729035 30.179 35.67081014023223 139.7380526556838 30.179 35.67081014023223 139.7380526556838 29.919 35.67080288588217 139.73805480729035 29.919 35.67080288588217 139.73805480729035 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d80907f4-93d8-45b2-8fd8-93c026c892ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d80907f4-93d8-45b2-8fd8-93c026c892ed_0">
											<gml:posList>35.67081014023223 139.7380526556838 30.179 35.67080992304631 139.7380515734027 30.179 35.67080992304631 139.7380515734027 31.107 35.67081190500509 139.7380616231973 31.107 35.67081190500509 139.7380616231973 29.919 35.67081014023223 139.7380526556838 29.919 35.67081014023223 139.7380526556838 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2e29154-bcbc-4ad5-818d-a1ce479ecf8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2e29154-bcbc-4ad5-818d-a1ce479ecf8b_0">
											<gml:posList>35.670803776524906 139.7380640299071 31.107 35.67081190500509 139.7380616231973 31.107 35.67080992304631 139.7380515734027 31.107 35.67080179456632 139.73805398011345 31.107 35.670803776524906 139.7380640299071 31.107</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cf0286b-e2e2-441a-b98a-2c434b40a16c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cf0286b-e2e2-441a-b98a-2c434b40a16c_0">
											<gml:posList>35.67080179456632 139.73805398011345 30.179 35.670803776524906 139.7380640299071 30.179 35.670803776524906 139.7380640299071 31.107 35.67080179456632 139.73805398011345 31.107 35.67080179456632 139.73805398011345 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1c05ddb-5e7c-4b85-9497-7362cffefdf3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1c05ddb-5e7c-4b85-9497-7362cffefdf3_0">
											<gml:posList>35.67080464163241 139.7380637637675 29.919 35.67080464163241 139.7380637637675 30.179 35.67080288588217 139.73805480729035 30.179 35.67080288588217 139.73805480729035 29.919 35.67080464163241 139.7380637637675 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4dcb127f-dd4c-4b35-b27e-88f126aea39f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4dcb127f-dd4c-4b35-b27e-88f126aea39f_0">
											<gml:posList>35.67087299902099 139.73806030236554 34.033 35.67086312227226 139.73806320823937 34.033 35.67086312227226 139.73806320823937 35.607 35.67087299902099 139.73806030236554 35.607 35.67087299902099 139.73806030236554 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdbfdc2b-9046-485b-8d42-c4f5ff7df7b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdbfdc2b-9046-485b-8d42-c4f5ff7df7b9_0">
											<gml:posList>35.67081190500509 139.7380616231973 29.919 35.67081190500509 139.7380616231973 31.107 35.670803776524906 139.7380640299071 31.107 35.670803776524906 139.7380640299071 30.179 35.67080464163241 139.7380637637675 30.179 35.67080464163241 139.7380637637675 29.919 35.67081190500509 139.7380616231973 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4798f98-01b2-41b1-8e5c-df72b8c4ca0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4798f98-01b2-41b1-8e5c-df72b8c4ca0a_0">
											<gml:posList>35.670830915467945 139.73806226338687 29.919 35.67082020048671 139.73806522548654 29.919 35.67082020048671 139.73806522548654 32.195 35.670830915467945 139.73806226338687 32.195 35.670830915467945 139.73806226338687 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2700ddf8-ce95-4999-b4e1-b5b239ae4175">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2700ddf8-ce95-4999-b4e1-b5b239ae4175_0">
											<gml:posList>35.67087543354398 139.73807272659096 34.033 35.67087299902099 139.73806030236554 34.033 35.67087299902099 139.73806030236554 35.607 35.67087543354398 139.73807272659096 35.607 35.67087543354398 139.73807272659096 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8faf257c-685e-4b82-b124-4fad6233242a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8faf257c-685e-4b82-b124-4fad6233242a_0">
											<gml:posList>35.67086312227226 139.73806320823937 35.607 35.67086556581743 139.73807564349897 35.607 35.67087543354398 139.73807272659096 35.607 35.67087299902099 139.73806030236554 35.607 35.67086312227226 139.73806320823937 35.607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1546a87c-c9e5-48b2-94bc-d9eb693e45c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1546a87c-c9e5-48b2-94bc-d9eb693e45c1_0">
											<gml:posList>35.67086556581743 139.73807564349897 34.033 35.67086556581743 139.73807564349897 35.607 35.67086312227226 139.73806320823937 35.607 35.67086312227226 139.73806320823937 34.033 35.67086556581743 139.73807564349897 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1a47b5c-a386-468c-b616-71dfee9307ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1a47b5c-a386-468c-b616-71dfee9307ac_0">
											<gml:posList>35.670830915467945 139.73806226338687 29.919 35.670830915467945 139.73806226338687 32.195 35.67083383944941 139.73807812243032 32.195 35.67083383944941 139.73807812243032 29.919 35.670830915467945 139.73806226338687 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-536ee82e-735c-4d3c-97d6-a3846cd0fd36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-536ee82e-735c-4d3c-97d6-a3846cd0fd36_0">
											<gml:posList>35.67082312446779 139.738081084528 32.195 35.67083383944941 139.73807812243032 32.195 35.670830915467945 139.73806226338687 32.195 35.67082020048671 139.73806522548654 32.195 35.67082312446779 139.738081084528 32.195</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cced532-50cf-4492-b876-2b535cd3b3c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cced532-50cf-4492-b876-2b535cd3b3c2_0">
											<gml:posList>35.67082020048671 139.73806522548654 29.919 35.67082312446779 139.738081084528 29.919 35.67082312446779 139.738081084528 32.195 35.67082020048671 139.73806522548654 32.195 35.67082020048671 139.73806522548654 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf573b25-63b8-4ed1-a535-1e21cc69ba14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf573b25-63b8-4ed1-a535-1e21cc69ba14_0">
											<gml:posList>35.67086556581743 139.73807564349897 34.033 35.67087543354398 139.73807272659096 34.033 35.67087543354398 139.73807272659096 35.607 35.67086556581743 139.73807564349897 35.607 35.67086556581743 139.73807564349897 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cb7a9a7-b0da-4d96-9470-7c0f9e29152c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0cb7a9a7-b0da-4d96-9470-7c0f9e29152c_0">
											<gml:posList>35.67082312446779 139.738081084528 29.919 35.67083383944941 139.73807812243032 29.919 35.67083383944941 139.73807812243032 32.195 35.67082312446779 139.738081084528 32.195 35.67082312446779 139.738081084528 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8855466-757e-4c7c-8506-b3bebac59c57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8855466-757e-4c7c-8506-b3bebac59c57_0">
											<gml:posList>35.670880409195654 139.73809560867102 42.847 35.670880409195654 139.73809560867102 43.915 35.67089876590849 139.73809022939548 43.915 35.67089876590849 139.73809022939548 42.847 35.670880409195654 139.73809560867102 42.847</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45541097-a352-4ecc-9bfd-d6085bdcd1e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45541097-a352-4ecc-9bfd-d6085bdcd1e8_0">
											<gml:posList>35.67090201501795 139.7381068944494 42.847 35.67089876590849 139.73809022939548 42.847 35.67089876590849 139.73809022939548 43.915 35.67090201501795 139.7381068944494 43.915 35.67090201501795 139.7381068944494 42.847</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9420279a-628d-4c30-8344-23a7f8c377b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9420279a-628d-4c30-8344-23a7f8c377b6_0">
											<gml:posList>35.67090201501795 139.7381068944494 43.915 35.67089876590849 139.73809022939548 43.915 35.670880409195654 139.73809560867102 43.915 35.670883658304376 139.73811227372136 43.915 35.67090201501795 139.7381068944494 43.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57bb1bcf-6303-4837-8eb8-8ae25c389385">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57bb1bcf-6303-4837-8eb8-8ae25c389385_0">
											<gml:posList>35.670880409195654 139.73809560867102 42.847 35.670883658304376 139.73811227372136 42.847 35.670883658304376 139.73811227372136 43.915 35.670880409195654 139.73809560867102 43.915 35.670880409195654 139.73809560867102 42.847</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-354bbfc1-f923-4b7c-9703-90e55f0efdfe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-354bbfc1-f923-4b7c-9703-90e55f0efdfe_0">
											<gml:posList>35.670883658304376 139.73811227372136 42.847 35.67090201501795 139.7381068944494 42.847 35.67090201501795 139.7381068944494 43.915 35.670883658304376 139.73811227372136 43.915 35.670883658304376 139.73811227372136 42.847</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-575f8cf1-47e2-4cb7-92cd-dab3a4e30c55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-575f8cf1-47e2-4cb7-92cd-dab3a4e30c55_0">
											<gml:posList>35.670887185689246 139.73815029099669 36.863 35.670887185689246 139.73815029099669 39.53 35.670902929027875 139.73814567703278 39.53 35.670902929027875 139.73814567703278 36.863 35.670887185689246 139.73815029099669 36.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b85a412-41e2-41a5-8e2c-8a9a6daa4ee8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b85a412-41e2-41a5-8e2c-8a9a6daa4ee8_0">
											<gml:posList>35.67090661252568 139.7381645397942 36.863 35.670902929027875 139.73814567703278 36.863 35.670902929027875 139.73814567703278 39.53 35.67090661252568 139.7381645397942 39.53 35.67090661252568 139.7381645397942 36.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fac21eb-7d31-47f1-9740-38c1af2d79c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fac21eb-7d31-47f1-9740-38c1af2d79c6_0">
											<gml:posList>35.67089086918633 139.7381691537546 39.53 35.67090661252568 139.7381645397942 39.53 35.670902929027875 139.73814567703278 39.53 35.670887185689246 139.73815029099669 39.53 35.67089086918633 139.7381691537546 39.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d68187ea-5c36-4d11-9139-379944690236">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d68187ea-5c36-4d11-9139-379944690236_0">
											<gml:posList>35.670887185689246 139.73815029099669 36.863 35.67089086918633 139.7381691537546 36.863 35.67089086918633 139.7381691537546 39.53 35.670887185689246 139.73815029099669 39.53 35.670887185689246 139.73815029099669 36.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-749c2010-d1fd-41f9-8036-d0a834ca3029">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-749c2010-d1fd-41f9-8036-d0a834ca3029_0">
											<gml:posList>35.67089086918633 139.7381691537546 36.863 35.67090661252568 139.7381645397942 36.863 35.67090661252568 139.7381645397942 39.53 35.67089086918633 139.7381691537546 39.53 35.67089086918633 139.7381691537546 36.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c5ca35e6-1738-4623-a4fd-9f60ebeaae41_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d42eecfb-b846-427e-ba68-de3ee850a3cd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67085496468033 139.7380857855739 29.919 35.67084464636346 139.7380888245244 29.919 35.67083839267892 139.7380569743598 29.919 35.670848710986235 139.73805392435915 29.919 35.67085496468033 139.7380857855739 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d5e0399-e572-4287-a6ec-fe2e3d0f0a9f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67090152753564 139.73811735590388 36.863 35.670903889698444 139.73812947092412 36.863 35.670879008551715 139.73813675790632 36.863 35.67087664639838 139.73812465393596 36.863 35.67090152753564 139.73811735590388 36.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-760f64b2-ecf4-47fb-b363-478dcdce60ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-760f64b2-ecf4-47fb-b363-478dcdce60ad_0">
											<gml:posList>35.67083839267892 139.7380569743598 29.919 35.67084464636346 139.7380888245244 29.919 35.67084464636346 139.7380888245244 30.126 35.67083839267892 139.7380569743598 30.126 35.67083839267892 139.7380569743598 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c99ee5d6-7cb8-47e4-bd05-0e1b63e9f6b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c99ee5d6-7cb8-47e4-bd05-0e1b63e9f6b5_0">
											<gml:posList>35.67083839267892 139.7380569743598 29.919 35.67083839267892 139.7380569743598 30.126 35.670848710986235 139.73805392435915 30.126 35.670848710986235 139.73805392435915 29.919 35.67083839267892 139.7380569743598 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00c4223a-5d24-4fbe-be93-64296f092ea1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00c4223a-5d24-4fbe-be93-64296f092ea1_0">
											<gml:posList>35.67083839267892 139.7380569743598 30.126 35.67084464636346 139.7380888245244 30.126 35.67085496468033 139.7380857855739 30.126 35.670848710986235 139.73805392435915 30.126 35.67083839267892 139.7380569743598 30.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b48bac5e-2ae4-46e9-b0e2-96117feb089c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b48bac5e-2ae4-46e9-b0e2-96117feb089c_0">
											<gml:posList>35.67084464636346 139.7380888245244 29.919 35.67085496468033 139.7380857855739 29.919 35.67085496468033 139.7380857855739 30.126 35.67084464636346 139.7380888245244 30.126 35.67084464636346 139.7380888245244 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1291a6e9-c98b-4893-b7dd-88c5a4520fca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1291a6e9-c98b-4893-b7dd-88c5a4520fca_0">
											<gml:posList>35.670848710986235 139.73805392435915 29.919 35.670848710986235 139.73805392435915 30.126 35.67085496468033 139.7380857855739 30.126 35.67085496468033 139.7380857855739 29.919 35.670848710986235 139.73805392435915 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc2f51b5-3f73-433c-8544-f3946c1ad64e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc2f51b5-3f73-433c-8544-f3946c1ad64e_0">
											<gml:posList>35.67087664639838 139.73812465393596 36.863 35.670879008551715 139.73813675790632 36.863 35.670879008551715 139.73813675790632 37.662 35.67087664639838 139.73812465393596 37.662 35.67087664639838 139.73812465393596 36.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ba8d2e2-aff9-479e-a429-98e610aead5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ba8d2e2-aff9-479e-a429-98e610aead5f_0">
											<gml:posList>35.67087664639838 139.73812465393596 36.863 35.67087664639838 139.73812465393596 37.662 35.67090152753564 139.73811735590388 37.662 35.67090152753564 139.73811735590388 36.863 35.67087664639838 139.73812465393596 36.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7271aa2-2422-427e-a7fe-198e3ac935f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7271aa2-2422-427e-a7fe-198e3ac935f1_0">
											<gml:posList>35.670879008551715 139.73813675790632 37.662 35.670903889698444 139.73812947092412 37.662 35.67090152753564 139.73811735590388 37.662 35.67087664639838 139.73812465393596 37.662 35.670879008551715 139.73813675790632 37.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18a75753-1658-422c-96df-5f7f997be30c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18a75753-1658-422c-96df-5f7f997be30c_0">
											<gml:posList>35.670879008551715 139.73813675790632 36.863 35.670903889698444 139.73812947092412 36.863 35.670903889698444 139.73812947092412 37.662 35.670879008551715 139.73813675790632 37.662 35.670879008551715 139.73813675790632 36.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9f966c0-06e6-471c-9b0f-17e6b13ab233">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9f966c0-06e6-471c-9b0f-17e6b13ab233_0">
											<gml:posList>35.670903889698444 139.73812947092412 36.863 35.67090152753564 139.73811735590388 36.863 35.67090152753564 139.73811735590388 37.662 35.670903889698444 139.73812947092412 37.662 35.670903889698444 139.73812947092412 36.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-dd616d3f-ac59-4c92-859e-8b012032d548">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd616d3f-ac59-4c92-859e-8b012032d548">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd616d3f-ac59-4c92-859e-8b012032d548">
											<gml:posList>35.670790806580015 139.73811063867856 17.2 35.67077478762291 139.73802891498335 17.2 35.670956552316696 139.73797556603276 17.2 35.670992210842314 139.73815811968035 17.2 35.670809454733295 139.7382116903437 17.2 35.67078972519551 139.73811097135234 17.2 35.670790806580015 139.73811063867856 17.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e229115-f18e-4f60-a0df-8b80b293b7ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e229115-f18e-4f60-a0df-8b80b293b7ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e229115-f18e-4f60-a0df-8b80b293b7ec">
											<gml:posList>35.67084782460493 139.73812985784113 35.25 35.6708481563746 139.73812765922878 35.271 35.67084691440248 139.7381300908947 35.253 35.67084782460493 139.73812985784113 35.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6b8a5598-500d-4bea-ac7d-924f9cb3ced5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b8a5598-500d-4bea-ac7d-924f9cb3ced5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b8a5598-500d-4bea-ac7d-924f9cb3ced5">
											<gml:posList>35.670790806580015 139.73811063867856 26.339 35.670809947277924 139.73810499336972 26.339 35.6707939373482 139.73802329173802 26.339 35.67077478762291 139.73802891498335 26.339 35.670790806580015 139.73811063867856 26.339</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0dfc229c-bc9c-4b14-bf00-2823aa3a8611">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dfc229c-bc9c-4b14-bf00-2823aa3a8611">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dfc229c-bc9c-4b14-bf00-2823aa3a8611">
											<gml:posList>35.670794216710526 139.73811435723704 29.281 35.67081085211816 139.73810937768346 29.281 35.670809947277924 139.73810499336972 29.281 35.67078972519551 139.73811097135234 29.281 35.670794216710526 139.73811435723704 29.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e47071a-a99d-441b-88fc-cda1431a3ee0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e47071a-a99d-441b-88fc-cda1431a3ee0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e47071a-a99d-441b-88fc-cda1431a3ee0">
											<gml:posList>35.6708127402126 139.7382059534063 29.281 35.670794216710526 139.73811435723704 29.281 35.67078972519551 139.73811097135234 29.281 35.670810049490555 139.73821150185063 29.281 35.6708127402126 139.7382059534063 29.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b97f1873-c563-4a72-937a-2a7b7bf6e649">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b97f1873-c563-4a72-937a-2a7b7bf6e649">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b97f1873-c563-4a72-937a-2a7b7bf6e649">
											<gml:posList>35.67080288588217 139.73805480729035 30.179 35.67079961195211 139.7380523478523 30.179 35.670809947277924 139.73810499336972 30.179 35.670811954166574 139.73810098117238 30.179 35.67080288588217 139.73805480729035 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-980b6430-59fc-4f29-9522-1d1a2601e04f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-980b6430-59fc-4f29-9522-1d1a2601e04f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-980b6430-59fc-4f29-9522-1d1a2601e04f">
											<gml:posList>35.670817050213245 139.7381393389866 27.443 35.67081085211816 139.73810937768346 27.443 35.670794216710526 139.73811435723704 27.443 35.6708127402126 139.7382059534063 27.443 35.670829708904776 139.73820068627074 27.443 35.670817050213245 139.7381393389866 27.443</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc1e18d7-ccb8-4a55-94f6-0b6c3157d456">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc1e18d7-ccb8-4a55-94f6-0b6c3157d456">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc1e18d7-ccb8-4a55-94f6-0b6c3157d456">
											<gml:posList>35.67081082508574 139.73810938876187 30.179 35.67082529770666 139.73810505246166 30.179 35.670824419898686 139.73810065706877 30.179 35.67082379540084 139.73809743228497 30.179 35.670811954166574 139.73810098117238 30.179 35.670809947277924 139.73810499336972 30.179 35.67081082508574 139.73810938876187 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-db480919-9829-4b4a-8728-cd197ffd74ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db480919-9829-4b4a-8728-cd197ffd74ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db480919-9829-4b4a-8728-cd197ffd74ae">
											<gml:posList>35.6708127402126 139.7382059534063 29.281 35.670810049490555 139.73821150185063 29.281 35.6708306227989 139.73820512580753 29.281 35.670829708904776 139.73820068627074 29.281 35.6708127402126 139.7382059534063 29.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c853d716-1687-42e9-98c7-e81a1bb605f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c853d716-1687-42e9-98c7-e81a1bb605f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c853d716-1687-42e9-98c7-e81a1bb605f9">
											<gml:posList>35.67081082508574 139.73810938876187 26.785 35.670817023119675 139.73813927274085 26.785 35.67083105384226 139.73813464976604 26.785 35.67082529770666 139.73810505246166 26.785 35.67081082508574 139.73810938876187 26.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-07986726-ef27-452e-bade-518db2ecf088">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07986726-ef27-452e-bade-518db2ecf088">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07986726-ef27-452e-bade-518db2ecf088">
											<gml:posList>35.670831090036884 139.7381348264642 32.044 35.67081716735669 139.73813929466223 29.281 35.670829708904776 139.73820068627074 29.281 35.670831090036884 139.7381348264642 32.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-401aacbc-bd02-4d79-968c-7491c46fce80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-401aacbc-bd02-4d79-968c-7491c46fce80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-401aacbc-bd02-4d79-968c-7491c46fce80">
											<gml:posList>35.67085550471988 139.73803922467383 30.179 35.67085750258386 139.73803520143696 30.179 35.67079961195211 139.7380523478523 30.179 35.67080288588217 139.73805480729035 30.179 35.67085550471988 139.73803922467383 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-91b93878-0ddb-4a65-8b71-391f586c7a2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91b93878-0ddb-4a65-8b71-391f586c7a2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91b93878-0ddb-4a65-8b71-391f586c7a2c">
											<gml:posList>35.670827432272574 139.73810291798642 32.433 35.670824419898686 139.73810065706877 32.415 35.67083109004562 139.7381348375105 32.415 35.67083295303013 139.7381312231513 32.433 35.670827432272574 139.73810291798642 32.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e456cb4b-e20f-4a96-b6ab-ece6cd7f77e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e456cb4b-e20f-4a96-b6ab-ece6cd7f77e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e456cb4b-e20f-4a96-b6ab-ece6cd7f77e6">
											<gml:posList>35.67083311772247 139.7381343159258 32.405 35.670831090036884 139.7381348264642 32.044 35.670829708904776 139.73820068627074 29.281 35.67083311772247 139.7381343159258 32.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-70d9c2e8-d444-47fa-996a-b46dda42db64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70d9c2e8-d444-47fa-996a-b46dda42db64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70d9c2e8-d444-47fa-996a-b46dda42db64">
											<gml:posList>35.67082379540084 139.73809743228497 30.179 35.670824419898686 139.73810065706877 30.179 35.67084026236902 139.73809602088835 30.179 35.670839637862315 139.73809278505766 30.179 35.67082379540084 139.73809743228497 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05fa5b97-bca3-4200-a0ae-8abb2c62b61f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05fa5b97-bca3-4200-a0ae-8abb2c62b61f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05fa5b97-bca3-4200-a0ae-8abb2c62b61f">
											<gml:posList>35.67083109004562 139.7381348375105 32.415 35.67083311772247 139.7381343159258 32.405 35.67083295303013 139.7381312231513 32.433 35.67083109004562 139.7381348375105 32.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6948b239-dbd1-43e4-9d81-f5526ef77db8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6948b239-dbd1-43e4-9d81-f5526ef77db8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6948b239-dbd1-43e4-9d81-f5526ef77db8">
											<gml:posList>35.67084026236902 139.73809602088835 32.415 35.670824419898686 139.73810065706877 32.415 35.670827432272574 139.73810291798642 32.433 35.67084026236902 139.73809602088835 32.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e038909a-7d82-4c5c-9123-5dba9e3fed75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e038909a-7d82-4c5c-9123-5dba9e3fed75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e038909a-7d82-4c5c-9123-5dba9e3fed75">
											<gml:posList>35.670827432272574 139.73810291798642 32.433 35.67084095019884 139.73809954384822 32.415 35.67084026236902 139.73809602088835 32.415 35.670827432272574 139.73810291798642 32.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5f3d1c6-a424-44f9-8f8c-6baf18b1a342">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5f3d1c6-a424-44f9-8f8c-6baf18b1a342">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5f3d1c6-a424-44f9-8f8c-6baf18b1a342">
											<gml:posList>35.67084092315768 139.73809954388034 32.205 35.67082741424513 139.73810291800785 32.223 35.67083293500267 139.7381312231727 32.223 35.67084631716494 139.73812714223556 32.205 35.67084092315768 139.73809954388034 32.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf2697eb-5a6c-4c63-9e76-cf48fb4f31c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf2697eb-5a6c-4c63-9e76-cf48fb4f31c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf2697eb-5a6c-4c63-9e76-cf48fb4f31c9">
											<gml:posList>35.670846905423694 139.7381301350907 35.072 35.67083311772247 139.7381343159258 32.405 35.670829708904776 139.73820068627074 29.281 35.670846905423694 139.7381301350907 35.072</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8c4e7a4-ec7b-4b4c-bae4-af75630edb2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8c4e7a4-ec7b-4b4c-bae4-af75630edb2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8c4e7a4-ec7b-4b4c-bae4-af75630edb2e">
											<gml:posList>35.67084782460493 139.73812985784113 35.25 35.670846905423694 139.7381301350907 35.072 35.670829708904776 139.73820068627074 29.281 35.67084782460493 139.73812985784113 35.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d4429d0-3372-4876-8891-d1f8acc2878a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d4429d0-3372-4876-8891-d1f8acc2878a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d4429d0-3372-4876-8891-d1f8acc2878a">
											<gml:posList>35.67083295303013 139.7381312231513 32.433 35.67083311772247 139.7381343159258 32.405 35.67084690537129 139.7381300688128 32.415 35.67083295303013 139.7381312231513 32.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18efbfae-380b-4911-8984-7f889b6d9a19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18efbfae-380b-4911-8984-7f889b6d9a19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18efbfae-380b-4911-8984-7f889b6d9a19">
											<gml:posList>35.67084690537129 139.7381300688128 32.415 35.67084633519238 139.73812714221413 32.415 35.67083295303013 139.7381312231513 32.433 35.67084690537129 139.7381300688128 32.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a5ea00d6-0653-42ef-bee0-1ee575893d5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5ea00d6-0653-42ef-bee0-1ee575893d5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5ea00d6-0653-42ef-bee0-1ee575893d5d">
											<gml:posList>35.670849706516194 139.73805900448505 29.919 35.67087951698384 139.7380502203691 29.919 35.67087822281187 139.73804363829575 29.919 35.67085749599933 139.73804966108415 29.919 35.67085550471988 139.73803922467383 29.919 35.67080288588217 139.73805480729035 29.919 35.670811954166574 139.73810098117238 29.919 35.67082379540084 139.73809743228497 29.919 35.670839637862315 139.73809278505766 29.919 35.67085529047621 139.73808743108924 29.919 35.670849706516194 139.73805900448505 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0869bb9e-a02e-4b9a-bca3-be5e41d82494">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0869bb9e-a02e-4b9a-bca3-be5e41d82494">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0869bb9e-a02e-4b9a-bca3-be5e41d82494">
											<gml:posList>35.67084227362582 139.7380975318455 35.271 35.67084026236902 139.73809602088835 35.253 35.67084691440248 139.7381300908947 35.253 35.6708481563746 139.73812765922878 35.271 35.67084227362582 139.7380975318455 35.271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fc0f48e1-a593-4892-bd2e-439fa79c2cbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc0f48e1-a593-4892-bd2e-439fa79c2cbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc0f48e1-a593-4892-bd2e-439fa79c2cbc">
											<gml:posList>35.67085529047621 139.73808743108924 30.179 35.670839637862315 139.73809278505766 30.179 35.67084026236902 139.73809602088835 30.179 35.670859439138425 139.7380903976223 30.179 35.67085529047621 139.73808743108924 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-628642ca-9cb0-4bb6-8d29-3597584c6b03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-628642ca-9cb0-4bb6-8d29-3597584c6b03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-628642ca-9cb0-4bb6-8d29-3597584c6b03">
											<gml:posList>35.670859439138425 139.7380903976223 35.253 35.67084026236902 139.73809602088835 35.253 35.67084227362582 139.7380975318455 35.271 35.670859439138425 139.7380903976223 35.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6bf1721a-7758-44e7-b8f1-4d8894b17512">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bf1721a-7758-44e7-b8f1-4d8894b17512">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bf1721a-7758-44e7-b8f1-4d8894b17512">
											<gml:posList>35.67087195948799 139.73819336765536 37.406 35.67084782460493 139.73812985784113 35.25 35.670829708904776 139.73820068627074 29.281 35.67087195948799 139.73819336765536 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-56442973-d1b4-4a2a-893e-e19624ce64ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56442973-d1b4-4a2a-893e-e19624ce64ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56442973-d1b4-4a2a-893e-e19624ce64ac">
											<gml:posList>35.67087195948799 139.73819336765536 37.406 35.670829708904776 139.73820068627074 29.281 35.6708306227989 139.73820512580753 29.281 35.67087195948799 139.73819336765536 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d776c8cd-7a26-4dc2-a586-6729df0081da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d776c8cd-7a26-4dc2-a586-6729df0081da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d776c8cd-7a26-4dc2-a586-6729df0081da">
											<gml:posList>35.67084227362582 139.7380975318455 35.271 35.67085982830115 139.73809238549853 35.253 35.670859439138425 139.7380903976223 35.253 35.67084227362582 139.7380975318455 35.271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c3f3a1c9-51b9-4c70-b671-6a844f090b19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3f3a1c9-51b9-4c70-b671-6a844f090b19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3f3a1c9-51b9-4c70-b671-6a844f090b19">
											<gml:posList>35.670852132649365 139.73806082424557 34.227 35.670849706516194 139.73805900448505 34.227 35.67085529047621 139.73808743108924 34.227 35.670856775398526 139.73808446891016 34.227 35.670852132649365 139.73806082424557 34.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c22feb5-3692-49cf-af6b-b3dfd31c6db2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c22feb5-3692-49cf-af6b-b3dfd31c6db2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c22feb5-3692-49cf-af6b-b3dfd31c6db2">
											<gml:posList>35.67084225559838 139.7380975318669 35.092 35.67084813834716 139.73812765925015 35.092 35.6708656749177 139.738122413514 35.074 35.6708598102737 139.73809238551996 35.074 35.67084225559838 139.7380975318669 35.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc620328-0e02-4cb3-acd2-daeaad4f5bce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc620328-0e02-4cb3-acd2-daeaad4f5bce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc620328-0e02-4cb3-acd2-daeaad4f5bce">
											<gml:posList>35.6708481563746 139.73812765922878 35.271 35.67084782460493 139.73812985784113 35.25 35.67086607308487 139.73812439033358 35.253 35.6708481563746 139.73812765922878 35.271</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e16b3de3-dbbf-443c-9a9b-eef35c39b662">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e16b3de3-dbbf-443c-9a9b-eef35c39b662">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e16b3de3-dbbf-443c-9a9b-eef35c39b662">
											<gml:posList>35.67086607308487 139.73812439033358 35.253 35.670865683931424 139.7381224135033 35.253 35.6708481563746 139.73812765922878 35.271 35.67086607308487 139.73812439033358 35.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d030255-1129-491a-8502-c864c8848a11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d030255-1129-491a-8502-c864c8848a11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d030255-1129-491a-8502-c864c8848a11">
											<gml:posList>35.67085550471988 139.73803922467383 30.179 35.67085749599933 139.73804966108415 30.179 35.670859502894864 139.73804565992933 30.179 35.67085750258386 139.73803520143696 30.179 35.67085550471988 139.73803922467383 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20c4ad7b-e799-4af7-a45b-5e8543bb187d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20c4ad7b-e799-4af7-a45b-5e8543bb187d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20c4ad7b-e799-4af7-a45b-5e8543bb187d">
											<gml:posList>35.67087195948799 139.73819336765536 37.406 35.67085890883587 139.73812649764287 37.406 35.67084782460493 139.73812985784113 35.25 35.67087195948799 139.73819336765536 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-899babbe-12d4-4ecb-99df-3c7dba728c7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-899babbe-12d4-4ecb-99df-3c7dba728c7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-899babbe-12d4-4ecb-99df-3c7dba728c7f">
											<gml:posList>35.67086183101092 139.73812868134533 37.406 35.67086899525996 139.73812657403613 37.406 35.67086607308487 139.73812439033358 37.406 35.67085890883587 139.73812649764287 37.406 35.67086183101092 139.73812868134533 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46c8fddf-c8ae-4fb2-8481-c748ee77a339">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46c8fddf-c8ae-4fb2-8481-c748ee77a339">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46c8fddf-c8ae-4fb2-8481-c748ee77a339">
											<gml:posList>35.670862361322854 139.73809259236975 37.406 35.670859439138425 139.7380903976223 37.406 35.67086607308487 139.73812439033358 37.406 35.67086899525996 139.73812657403613 37.406 35.670862361322854 139.73809259236975 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d436fed7-6e0f-4d95-b245-5ec35214fc83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d436fed7-6e0f-4d95-b245-5ec35214fc83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d436fed7-6e0f-4d95-b245-5ec35214fc83">
											<gml:posList>35.670862361322854 139.73809259236975 37.406 35.67087052585842 139.73809018561826 37.406 35.67086996472721 139.73808730319357 37.406 35.670859439138425 139.7380903976223 37.406 35.670862361322854 139.73809259236975 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6f4bad49-ebaf-4a9c-9cb8-fce140c10e7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f4bad49-ebaf-4a9c-9cb8-fce140c10e7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f4bad49-ebaf-4a9c-9cb8-fce140c10e7b">
											<gml:posList>35.67086183101092 139.73812868134533 37.406 35.67085890883587 139.73812649764287 37.406 35.67087195948799 139.73819336765536 37.406 35.67087375940438 139.73818978650948 37.406 35.67086183101092 139.73812868134533 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fceda3c5-bb89-4d21-824f-314388604bf7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fceda3c5-bb89-4d21-824f-314388604bf7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fceda3c5-bb89-4d21-824f-314388604bf7">
											<gml:posList>35.670883466077655 139.73805158542064 34.227 35.670884941976624 139.73804861220427 34.227 35.670849706516194 139.73805900448505 34.227 35.670852132649365 139.73806082424557 34.227 35.670883466077655 139.73805158542064 34.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a689a8e-bbbd-4436-b517-162a84dd0caa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a689a8e-bbbd-4436-b517-162a84dd0caa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a689a8e-bbbd-4436-b517-162a84dd0caa">
											<gml:posList>35.67087822281187 139.73804363829575 30.179 35.670877589298776 139.73804041352102 30.179 35.670859502894864 139.73804565992933 30.179 35.67085749599933 139.73804966108415 30.179 35.67087822281187 139.73804363829575 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-005fad8a-de44-490d-bf3f-c5fae65ce447">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-005fad8a-de44-490d-bf3f-c5fae65ce447">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-005fad8a-de44-490d-bf3f-c5fae65ce447">
											<gml:posList>35.670852132649365 139.73806082424557 34.033 35.670856775398526 139.73808446891016 34.033 35.67088810883736 139.73807524114028 34.033 35.670883466077655 139.73805158542064 34.033 35.670852132649365 139.73806082424557 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98858c98-1964-474a-92a8-37a268f7f885">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98858c98-1964-474a-92a8-37a268f7f885">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98858c98-1964-474a-92a8-37a268f7f885">
											<gml:posList>35.670856775398526 139.73808446891016 34.227 35.67085529047621 139.73808743108924 34.227 35.67089052594782 139.73807704986652 34.227 35.67088810883736 139.73807524114028 34.227 35.670856775398526 139.73808446891016 34.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a4052a8-02c2-409e-8c02-acff93b6ff19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a4052a8-02c2-409e-8c02-acff93b6ff19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a4052a8-02c2-409e-8c02-acff93b6ff19">
											<gml:posList>35.67087373470826 139.73809013762107 43.143 35.67086996472721 139.73808730319357 43.143 35.67087722314554 139.73812448755615 43.143 35.6708795360122 139.73811985639819 43.143 35.67087373470826 139.73809013762107 43.143</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6cac3653-d429-4c8c-b23d-e4c988087655">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cac3653-d429-4c8c-b23d-e4c988087655">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cac3653-d429-4c8c-b23d-e4c988087655">
											<gml:posList>35.67088810883736 139.73807524114028 34.227 35.67089052594782 139.73807704986652 34.227 35.670884941976624 139.73804861220427 34.227 35.670883466077655 139.73805158542064 34.227 35.67088810883736 139.73807524114028 34.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7528595d-257f-44d8-a3c2-70650bad1e5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7528595d-257f-44d8-a3c2-70650bad1e5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7528595d-257f-44d8-a3c2-70650bad1e5c">
											<gml:posList>35.6709021123197 139.73808176393055 43.143 35.670904434198434 139.73807713275923 43.143 35.67086996472721 139.73808730319357 43.143 35.67087373470826 139.73809013762107 43.143 35.6709021123197 139.73808176393055 43.143</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2257973c-06b3-4c04-9734-2c697d73b182">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2257973c-06b3-4c04-9734-2c697d73b182">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2257973c-06b3-4c04-9734-2c697d73b182">
											<gml:posList>35.67087373470826 139.73809013762107 42.847 35.6708795360122 139.73811985639819 42.847 35.67090790465564 139.7381115379599 42.847 35.6709021123197 139.73808176393055 42.847 35.67087373470826 139.73809013762107 42.847</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d50e22db-7a52-4c7c-8cf0-11424f2ee398">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d50e22db-7a52-4c7c-8cf0-11424f2ee398">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d50e22db-7a52-4c7c-8cf0-11424f2ee398">
											<gml:posList>35.67089888381785 139.73803419121998 32.65 35.670877589298776 139.73804041352102 32.65 35.67087951698384 139.7380502203691 32.65 35.670884941976624 139.73804861220427 32.65 35.67089052594782 139.73807704986652 32.65 35.67090637739582 139.73807236948159 32.65 35.67089888381785 139.73803419121998 32.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0c85cfe1-20b0-4dc8-a4a4-f438cd35cd99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c85cfe1-20b0-4dc8-a4a4-f438cd35cd99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c85cfe1-20b0-4dc8-a4a4-f438cd35cd99">
											<gml:posList>35.67087375940438 139.73818978650948 36.863 35.67092300802644 139.73817534574005 36.863 35.67091168365857 139.7381143834255 36.863 35.67087722314554 139.73812448755615 36.863 35.67087052585842 139.73809018561826 36.863 35.670862361322854 139.73809259236975 36.863 35.67086899525996 139.73812657403613 36.863 35.67086183101092 139.73812868134533 36.863 35.67087375940438 139.73818978650948 36.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8216eb9b-9b3a-4ba0-8842-d0b4441320a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8216eb9b-9b3a-4ba0-8842-d0b4441320a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8216eb9b-9b3a-4ba0-8842-d0b4441320a8">
											<gml:posList>35.6708795360122 139.73811985639819 43.143 35.67087722314554 139.73812448755615 43.143 35.67091168365857 139.7381143834255 43.143 35.67090790465564 139.7381115379599 43.143 35.6708795360122 139.73811985639819 43.143</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-48f9a032-90ba-4632-b089-aaf6c671eb37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48f9a032-90ba-4632-b089-aaf6c671eb37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48f9a032-90ba-4632-b089-aaf6c671eb37">
											<gml:posList>35.67090637739582 139.73807236948159 30.179 35.67085529047621 139.73808743108924 30.179 35.670859439138425 139.7380903976223 30.179 35.67090624553697 139.7380766003833 30.179 35.6709356144294 139.738067938302 30.179 35.670928207752304 139.73802567277974 30.179 35.67089888381785 139.73803419121998 30.179 35.67090637739582 139.73807236948159 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f6cb17a-9be3-4ceb-a625-56452d2a38e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f6cb17a-9be3-4ceb-a625-56452d2a38e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f6cb17a-9be3-4ceb-a625-56452d2a38e7">
											<gml:posList>35.67087375940438 139.73818978650948 37.406 35.67087195948799 139.73819336765536 37.406 35.67092592120431 139.73817755154937 37.406 35.67092300802644 139.73817534574005 37.406 35.67087375940438 139.73818978650948 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-222ce889-958b-46c2-8eed-900afe2930bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-222ce889-958b-46c2-8eed-900afe2930bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-222ce889-958b-46c2-8eed-900afe2930bd">
											<gml:posList>35.67090790465564 139.7381115379599 43.143 35.67091168365857 139.7381143834255 43.143 35.670904434198434 139.73807713275923 43.143 35.6709021123197 139.73808176393055 43.143 35.67090790465564 139.7381115379599 43.143</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-84c09348-80b1-43ba-a209-1decb7f4e65d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84c09348-80b1-43ba-a209-1decb7f4e65d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84c09348-80b1-43ba-a209-1decb7f4e65d">
											<gml:posList>35.67092592120431 139.73817755154937 37.406 35.67090624553697 139.7380766003833 37.406 35.670904434198434 139.73807713275923 37.406 35.67091168365857 139.7381143834255 37.406 35.67092300802644 139.73817534574005 37.406 35.67092592120431 139.73817755154937 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c321b84e-d2e2-4b6c-a0b0-bec0b2be32fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c321b84e-d2e2-4b6c-a0b0-bec0b2be32fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c321b84e-d2e2-4b6c-a0b0-bec0b2be32fa">
											<gml:posList>35.67092592120431 139.73817755154937 37.406 35.670992210842314 139.73815811968035 26.184 35.67097248099778 139.73805706908294 26.184 35.67090624553697 139.7380766003833 37.406 35.67092592120431 139.73817755154937 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-34b03c87-c65d-4eb7-b463-0ef7cc60a249">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34b03c87-c65d-4eb7-b463-0ef7cc60a249">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34b03c87-c65d-4eb7-b463-0ef7cc60a249">
											<gml:posList>35.670956552316696 139.73797556603276 23.559 35.670851855139425 139.73800629991916 23.559 35.670859502894864 139.73804565992933 30.179 35.670877589298776 139.73804041352102 30.179 35.67089888381785 139.73803419121998 30.179 35.670928207752304 139.73802567277974 30.179 35.670956552316696 139.73797556603276 23.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-37a34790-d567-4439-abfc-88d3fbc5e300">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37a34790-d567-4439-abfc-88d3fbc5e300">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37a34790-d567-4439-abfc-88d3fbc5e300">
											<gml:posList>35.67097248099778 139.73805706908294 23.559 35.670956552316696 139.73797556603276 23.559 35.6709356144294 139.738067938302 30.179 35.67097248099778 139.73805706908294 23.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9852749d-ec4d-412f-9853-0da55ba9dc68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9852749d-ec4d-412f-9853-0da55ba9dc68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9852749d-ec4d-412f-9853-0da55ba9dc68">
											<gml:posList>35.670956552316696 139.73797556603276 23.559 35.670928207752304 139.73802567277974 30.179 35.6709356144294 139.738067938302 30.179 35.670956552316696 139.73797556603276 23.559</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11ba11e1-8889-45f1-9eed-e6df8f6d6234">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11ba11e1-8889-45f1-9eed-e6df8f6d6234">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11ba11e1-8889-45f1-9eed-e6df8f6d6234">
											<gml:posList>35.6707939373482 139.73802329173802 26.339 35.67079961195211 139.7380523478523 30.179 35.67085750258386 139.73803520143696 30.179 35.670851855139425 139.73800629991916 26.339 35.6707939373482 139.73802329173802 26.339</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de34545c-40cb-45cc-a08f-feadb416961b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de34545c-40cb-45cc-a08f-feadb416961b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de34545c-40cb-45cc-a08f-feadb416961b">
											<gml:posList>35.67085529047621 139.73808743108924 30.179 35.67090637739582 139.73807236948159 30.179 35.67090637739582 139.73807236948159 32.65 35.67089052594782 139.73807704986652 32.65 35.67089052594782 139.73807704986652 34.227 35.67085529047621 139.73808743108924 34.227 35.67085529047621 139.73808743108924 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21e831f9-a9be-4d7b-9f7a-e9ad352882a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21e831f9-a9be-4d7b-9f7a-e9ad352882a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21e831f9-a9be-4d7b-9f7a-e9ad352882a5">
											<gml:posList>35.670846905423694 139.7381301350907 35.072 35.67084782460493 139.73812985784113 35.25 35.67084691440248 139.7381300908947 35.253 35.670846905423694 139.7381301350907 35.072</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-556b36f2-aa4d-49a7-a298-c8d7321c4804">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-556b36f2-aa4d-49a7-a298-c8d7321c4804">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-556b36f2-aa4d-49a7-a298-c8d7321c4804">
											<gml:posList>35.670790806580015 139.73811063867856 17.2 35.670790806580015 139.73811063867856 26.339 35.67077478762291 139.73802891498335 26.339 35.67077478762291 139.73802891498335 17.2 35.670790806580015 139.73811063867856 17.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38394f7b-f8ef-4158-832e-4ce8ae14c966">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38394f7b-f8ef-4158-832e-4ce8ae14c966">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38394f7b-f8ef-4158-832e-4ce8ae14c966">
											<gml:posList>35.67078972519551 139.73811097135234 26.184 35.670790806580015 139.73811063867856 26.339 35.670790806580015 139.73811063867856 17.2 35.67078972519551 139.73811097135234 17.2 35.67078972519551 139.73811097135234 26.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c2d013f-d9b6-420f-a84a-8a554ed2b9aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c2d013f-d9b6-420f-a84a-8a554ed2b9aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c2d013f-d9b6-420f-a84a-8a554ed2b9aa">
											<gml:posList>35.670809947277924 139.73810499336972 29.281 35.670790806580015 139.73811063867856 26.339 35.67078972519551 139.73811097135234 26.184 35.67078972519551 139.73811097135234 29.281 35.670809947277924 139.73810499336972 29.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c49e36dc-a130-4808-922a-95d4257331c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c49e36dc-a130-4808-922a-95d4257331c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c49e36dc-a130-4808-922a-95d4257331c6">
											<gml:posList>35.67078972519551 139.73811097135234 29.281 35.67078972519551 139.73811097135234 26.184 35.670810049490555 139.73821150185063 29.281 35.67078972519551 139.73811097135234 29.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a9ee4e8-43f0-4cb6-a248-50ca856fdf2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a9ee4e8-43f0-4cb6-a248-50ca856fdf2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a9ee4e8-43f0-4cb6-a248-50ca856fdf2b">
											<gml:posList>35.67078972519551 139.73811097135234 26.184 35.67078972519551 139.73811097135234 17.2 35.670810049490555 139.73821150185063 29.281 35.67078972519551 139.73811097135234 26.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc802312-c67a-4399-bbfb-e1cacc5e2a76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc802312-c67a-4399-bbfb-e1cacc5e2a76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc802312-c67a-4399-bbfb-e1cacc5e2a76">
											<gml:posList>35.67078972519551 139.73811097135234 17.2 35.670809454733295 139.7382116903437 17.2 35.670810049490555 139.73821150185063 29.281 35.67078972519551 139.73811097135234 17.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ec9d2bb-6986-4339-84e3-6f9eeb2a2e00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ec9d2bb-6986-4339-84e3-6f9eeb2a2e00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ec9d2bb-6986-4339-84e3-6f9eeb2a2e00">
											<gml:posList>35.670809947277924 139.73810499336972 29.281 35.670809947277924 139.73810499336972 26.339 35.670790806580015 139.73811063867856 26.339 35.670809947277924 139.73810499336972 29.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15bc44b8-8722-455e-a350-af13a1a304fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15bc44b8-8722-455e-a350-af13a1a304fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15bc44b8-8722-455e-a350-af13a1a304fb">
											<gml:posList>35.6707939373482 139.73802329173802 26.339 35.670809947277924 139.73810499336972 26.339 35.670809947277924 139.73810499336972 29.281 35.670809947277924 139.73810499336972 30.179 35.67079961195211 139.7380523478523 30.179 35.6707939373482 139.73802329173802 26.339</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a79477e8-b4ff-4cb9-9552-906fa4e4a150">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a79477e8-b4ff-4cb9-9552-906fa4e4a150">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a79477e8-b4ff-4cb9-9552-906fa4e4a150">
											<gml:posList>35.67081085211816 139.73810937768346 27.443 35.67081085211816 139.73810937768346 29.281 35.670794216710526 139.73811435723704 29.281 35.670794216710526 139.73811435723704 27.443 35.67081085211816 139.73810937768346 27.443</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0012b340-e7c7-4d46-a31d-3fd957d0ca13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0012b340-e7c7-4d46-a31d-3fd957d0ca13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0012b340-e7c7-4d46-a31d-3fd957d0ca13">
											<gml:posList>35.6708127402126 139.7382059534063 29.281 35.6708127402126 139.7382059534063 27.443 35.670794216710526 139.73811435723704 27.443 35.670794216710526 139.73811435723704 29.281 35.6708127402126 139.7382059534063 29.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ff9935d-e7e2-488c-8d3b-e9dbb68a3cfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ff9935d-e7e2-488c-8d3b-e9dbb68a3cfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ff9935d-e7e2-488c-8d3b-e9dbb68a3cfa">
											<gml:posList>35.67080288588217 139.73805480729035 29.919 35.67080288588217 139.73805480729035 30.179 35.670811954166574 139.73810098117238 30.179 35.670811954166574 139.73810098117238 29.919 35.67080288588217 139.73805480729035 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4146549-dac3-41f2-bc59-a00d37c77f0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4146549-dac3-41f2-bc59-a00d37c77f0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4146549-dac3-41f2-bc59-a00d37c77f0c">
											<gml:posList>35.670809947277924 139.73810499336972 29.281 35.67081085211816 139.73810937768346 29.281 35.67081082508574 139.73810938876187 30.179 35.670809947277924 139.73810499336972 30.179 35.670809947277924 139.73810499336972 29.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f0cc8de-ee54-49a4-bf70-5a34443044cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f0cc8de-ee54-49a4-bf70-5a34443044cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f0cc8de-ee54-49a4-bf70-5a34443044cc">
											<gml:posList>35.67081085211816 139.73810937768346 27.443 35.670817050213245 139.7381393389866 27.443 35.670817023119675 139.73813927274085 26.785 35.67081082508574 139.73810938876187 26.785 35.67081085211816 139.73810937768346 27.443</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f71754c-f17c-4f44-a728-6f4164124835">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f71754c-f17c-4f44-a728-6f4164124835">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f71754c-f17c-4f44-a728-6f4164124835">
											<gml:posList>35.670811954166574 139.73810098117238 29.919 35.670811954166574 139.73810098117238 30.179 35.67082379540084 139.73809743228497 30.179 35.67082379540084 139.73809743228497 29.919 35.670811954166574 139.73810098117238 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-168751ee-59ab-4fb5-8d8b-3440cc801f02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-168751ee-59ab-4fb5-8d8b-3440cc801f02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-168751ee-59ab-4fb5-8d8b-3440cc801f02">
											<gml:posList>35.67082529770666 139.73810505246166 26.785 35.67082529770666 139.73810505246166 30.179 35.67081082508574 139.73810938876187 30.179 35.67081085211816 139.73810937768346 29.281 35.67081085211816 139.73810937768346 27.443 35.67081082508574 139.73810938876187 26.785 35.67082529770666 139.73810505246166 26.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3263e983-6fd0-462b-a0e3-2d3bcab89ab5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3263e983-6fd0-462b-a0e3-2d3bcab89ab5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3263e983-6fd0-462b-a0e3-2d3bcab89ab5">
											<gml:posList>35.6708306227989 139.73820512580753 29.281 35.670810049490555 139.73821150185063 29.281 35.670809454733295 139.7382116903437 17.2 35.6708306227989 139.73820512580753 29.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96b7f1f6-2dfe-44b4-ba15-86054092cb32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96b7f1f6-2dfe-44b4-ba15-86054092cb32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96b7f1f6-2dfe-44b4-ba15-86054092cb32">
											<gml:posList>35.6708127402126 139.7382059534063 27.443 35.6708127402126 139.7382059534063 29.281 35.670829708904776 139.73820068627074 29.281 35.670829708904776 139.73820068627074 27.443 35.6708127402126 139.7382059534063 27.443</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b28ee8cc-8797-4446-a33a-7b4fa9573ee3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b28ee8cc-8797-4446-a33a-7b4fa9573ee3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b28ee8cc-8797-4446-a33a-7b4fa9573ee3">
											<gml:posList>35.670829708904776 139.73820068627074 27.443 35.670829708904776 139.73820068627074 29.281 35.67081716735669 139.73813929466223 29.281 35.670817050213245 139.7381393389866 27.443 35.670829708904776 139.73820068627074 27.443</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbb0432b-840f-4267-908b-8a06a23dbd81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbb0432b-840f-4267-908b-8a06a23dbd81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbb0432b-840f-4267-908b-8a06a23dbd81">
											<gml:posList>35.67083105384226 139.73813464976604 26.785 35.670817023119675 139.73813927274085 26.785 35.670817050213245 139.7381393389866 27.443 35.67081716735669 139.73813929466223 29.281 35.670831090036884 139.7381348264642 32.044 35.67083105384226 139.73813464976604 26.785</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47fc85c9-9bbb-417d-a061-48f52fd067d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47fc85c9-9bbb-417d-a061-48f52fd067d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47fc85c9-9bbb-417d-a061-48f52fd067d1">
											<gml:posList>35.67082529770666 139.73810505246166 30.179 35.67082529770666 139.73810505246166 26.785 35.67083105384226 139.73813464976604 26.785 35.670831090036884 139.7381348264642 32.044 35.67083109004562 139.7381348375105 32.415 35.670824419898686 139.73810065706877 32.415 35.670824419898686 139.73810065706877 30.179 35.67082529770666 139.73810505246166 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a3c6c3d-4dbf-453b-94a6-0e88451cb008">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a3c6c3d-4dbf-453b-94a6-0e88451cb008">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a3c6c3d-4dbf-453b-94a6-0e88451cb008">
											<gml:posList>35.67085550471988 139.73803922467383 29.919 35.67085550471988 139.73803922467383 30.179 35.67080288588217 139.73805480729035 30.179 35.67080288588217 139.73805480729035 29.919 35.67085550471988 139.73803922467383 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d504a95-3a7d-481b-8721-3f86703845be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d504a95-3a7d-481b-8721-3f86703845be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d504a95-3a7d-481b-8721-3f86703845be">
											<gml:posList>35.67082741424513 139.73810291800785 32.223 35.670827432272574 139.73810291798642 32.433 35.67083295303013 139.7381312231513 32.433 35.67083293500267 139.7381312231727 32.223 35.67082741424513 139.73810291800785 32.223</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2e4b8e8-bd2d-4137-95e6-40abff4e32f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2e4b8e8-bd2d-4137-95e6-40abff4e32f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2e4b8e8-bd2d-4137-95e6-40abff4e32f6">
											<gml:posList>35.67082379540084 139.73809743228497 29.919 35.67082379540084 139.73809743228497 30.179 35.670839637862315 139.73809278505766 30.179 35.670839637862315 139.73809278505766 29.919 35.67082379540084 139.73809743228497 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-674b5c08-d499-4cad-8a21-6a77b9d0e61a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-674b5c08-d499-4cad-8a21-6a77b9d0e61a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-674b5c08-d499-4cad-8a21-6a77b9d0e61a">
											<gml:posList>35.67083109004562 139.7381348375105 32.415 35.670831090036884 139.7381348264642 32.044 35.67083311772247 139.7381343159258 32.405 35.67083109004562 139.7381348375105 32.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0205870f-d8bb-454c-85a9-7f6df20171c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0205870f-d8bb-454c-85a9-7f6df20171c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0205870f-d8bb-454c-85a9-7f6df20171c9">
											<gml:posList>35.67084092315768 139.73809954388034 32.205 35.67084095019884 139.73809954384822 32.415 35.670827432272574 139.73810291798642 32.433 35.67082741424513 139.73810291800785 32.223 35.67084092315768 139.73809954388034 32.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c244dc8-eb56-403d-99fb-d4f700688cc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c244dc8-eb56-403d-99fb-d4f700688cc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c244dc8-eb56-403d-99fb-d4f700688cc7">
											<gml:posList>35.67083293500267 139.7381312231727 32.223 35.67083295303013 139.7381312231513 32.433 35.67084633519238 139.73812714221413 32.415 35.67084631716494 139.73812714223556 32.205 35.67083293500267 139.7381312231727 32.223</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26ec132b-2d92-46a7-8169-8ca5cf7f2e0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26ec132b-2d92-46a7-8169-8ca5cf7f2e0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26ec132b-2d92-46a7-8169-8ca5cf7f2e0c">
											<gml:posList>35.67083311772247 139.7381343159258 32.405 35.670846905423694 139.7381301350907 35.072 35.67084690537129 139.7381300688128 32.415 35.67083311772247 139.7381343159258 32.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f047de9-b950-480c-b0ca-d5e823617e01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f047de9-b950-480c-b0ca-d5e823617e01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f047de9-b950-480c-b0ca-d5e823617e01">
											<gml:posList>35.67084026236902 139.73809602088835 32.415 35.67084026236902 139.73809602088835 35.253 35.670859439138425 139.7380903976223 35.253 35.670859439138425 139.7380903976223 30.179 35.67084026236902 139.73809602088835 30.179 35.670824419898686 139.73810065706877 30.179 35.670824419898686 139.73810065706877 32.415 35.67084026236902 139.73809602088835 32.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-101501f7-a700-4beb-992c-d2976023d9d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-101501f7-a700-4beb-992c-d2976023d9d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-101501f7-a700-4beb-992c-d2976023d9d5">
											<gml:posList>35.67084633519238 139.73812714221413 32.415 35.67084690537129 139.7381300688128 32.415 35.670846905423694 139.7381301350907 35.072 35.67084691440248 139.7381300908947 35.253 35.67084026236902 139.73809602088835 35.253 35.67084026236902 139.73809602088835 32.415 35.67084095019884 139.73809954384822 32.415 35.67084633519238 139.73812714221413 32.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b55703da-af67-4be9-9464-5a8dc551cccc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b55703da-af67-4be9-9464-5a8dc551cccc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b55703da-af67-4be9-9464-5a8dc551cccc">
											<gml:posList>35.67084631716494 139.73812714223556 32.205 35.67084633519238 139.73812714221413 32.415 35.67084095019884 139.73809954384822 32.415 35.67084092315768 139.73809954388034 32.205 35.67084631716494 139.73812714223556 32.205</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20134ee4-db1f-4534-8c24-43d0ae20fdbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20134ee4-db1f-4534-8c24-43d0ae20fdbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20134ee4-db1f-4534-8c24-43d0ae20fdbd">
											<gml:posList>35.67084225559838 139.7380975318669 35.092 35.67084227362582 139.7380975318455 35.271 35.6708481563746 139.73812765922878 35.271 35.67084813834716 139.73812765925015 35.092 35.67084225559838 139.7380975318669 35.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56d00ed9-0861-431e-b96e-798ea8666186">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56d00ed9-0861-431e-b96e-798ea8666186">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56d00ed9-0861-431e-b96e-798ea8666186">
											<gml:posList>35.670839637862315 139.73809278505766 29.919 35.670839637862315 139.73809278505766 30.179 35.67085529047621 139.73808743108924 30.179 35.67085529047621 139.73808743108924 29.919 35.670839637862315 139.73809278505766 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf021945-d18a-4461-9beb-82df42fe80be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf021945-d18a-4461-9beb-82df42fe80be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf021945-d18a-4461-9beb-82df42fe80be">
											<gml:posList>35.6708598102737 139.73809238551996 35.074 35.67085982830115 139.73809238549853 35.253 35.67084227362582 139.7380975318455 35.271 35.67084225559838 139.7380975318669 35.092 35.6708598102737 139.73809238551996 35.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27cc951f-1171-4be0-a53f-f58db35935c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27cc951f-1171-4be0-a53f-f58db35935c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27cc951f-1171-4be0-a53f-f58db35935c2">
											<gml:posList>35.670849706516194 139.73805900448505 34.227 35.670849706516194 139.73805900448505 29.919 35.67085529047621 139.73808743108924 29.919 35.67085529047621 139.73808743108924 30.179 35.67085529047621 139.73808743108924 34.227 35.670849706516194 139.73805900448505 34.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-522e90b2-2db5-44ef-ac54-cc476358533d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-522e90b2-2db5-44ef-ac54-cc476358533d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-522e90b2-2db5-44ef-ac54-cc476358533d">
											<gml:posList>35.670852132649365 139.73806082424557 34.033 35.670852132649365 139.73806082424557 34.227 35.670856775398526 139.73808446891016 34.227 35.670856775398526 139.73808446891016 34.033 35.670852132649365 139.73806082424557 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bfec797e-4f44-47cc-b2e0-58e09d2ccf50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfec797e-4f44-47cc-b2e0-58e09d2ccf50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfec797e-4f44-47cc-b2e0-58e09d2ccf50">
											<gml:posList>35.670859502894864 139.73804565992933 30.179 35.670851855139425 139.73800629991916 23.559 35.670851855139425 139.73800629991916 26.339 35.67085750258386 139.73803520143696 30.179 35.670859502894864 139.73804565992933 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2cdc4e0-8ef8-4bda-93e4-e1c7f3e222f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2cdc4e0-8ef8-4bda-93e4-e1c7f3e222f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2cdc4e0-8ef8-4bda-93e4-e1c7f3e222f2">
											<gml:posList>35.67085749599933 139.73804966108415 29.919 35.67085749599933 139.73804966108415 30.179 35.67085550471988 139.73803922467383 30.179 35.67085550471988 139.73803922467383 29.919 35.67085749599933 139.73804966108415 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b027de07-caeb-49d0-a170-56258a59325f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b027de07-caeb-49d0-a170-56258a59325f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b027de07-caeb-49d0-a170-56258a59325f">
											<gml:posList>35.67084813834716 139.73812765925015 35.092 35.6708481563746 139.73812765922878 35.271 35.670865683931424 139.7381224135033 35.253 35.6708656749177 139.738122413514 35.074 35.67084813834716 139.73812765925015 35.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43364011-0b82-494c-b926-c46f94524201">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43364011-0b82-494c-b926-c46f94524201">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43364011-0b82-494c-b926-c46f94524201">
											<gml:posList>35.67086607308487 139.73812439033358 35.253 35.67084782460493 139.73812985784113 35.25 35.67085890883587 139.73812649764287 37.406 35.67086607308487 139.73812439033358 37.406 35.67086607308487 139.73812439033358 35.253</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7090cf7c-414c-4e91-8e72-82cb480f43b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7090cf7c-414c-4e91-8e72-82cb480f43b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7090cf7c-414c-4e91-8e72-82cb480f43b3">
											<gml:posList>35.67086607308487 139.73812439033358 37.406 35.670859439138425 139.7380903976223 37.406 35.670859439138425 139.7380903976223 35.253 35.67085982830115 139.73809238549853 35.253 35.6708598102737 139.73809238551996 35.074 35.6708656749177 139.738122413514 35.074 35.670865683931424 139.7381224135033 35.253 35.67086607308487 139.73812439033358 35.253 35.67086607308487 139.73812439033358 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10cb77e5-e798-4e68-8815-359dac23170a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10cb77e5-e798-4e68-8815-359dac23170a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10cb77e5-e798-4e68-8815-359dac23170a">
											<gml:posList>35.67086899525996 139.73812657403613 36.863 35.67086899525996 139.73812657403613 37.406 35.67086183101092 139.73812868134533 37.406 35.67086183101092 139.73812868134533 36.863 35.67086899525996 139.73812657403613 36.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bacd950a-b945-465e-b832-c645bc5bab00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bacd950a-b945-465e-b832-c645bc5bab00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bacd950a-b945-465e-b832-c645bc5bab00">
											<gml:posList>35.670862361322854 139.73809259236975 36.863 35.670862361322854 139.73809259236975 37.406 35.67086899525996 139.73812657403613 37.406 35.67086899525996 139.73812657403613 36.863 35.670862361322854 139.73809259236975 36.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82ae3d7d-ae68-4336-a7a5-f667829bc3da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82ae3d7d-ae68-4336-a7a5-f667829bc3da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82ae3d7d-ae68-4336-a7a5-f667829bc3da">
											<gml:posList>35.670956552316696 139.73797556603276 17.2 35.67077478762291 139.73802891498335 17.2 35.67077478762291 139.73802891498335 26.339 35.6707939373482 139.73802329173802 26.339 35.670851855139425 139.73800629991916 26.339 35.670851855139425 139.73800629991916 23.559 35.670956552316696 139.73797556603276 23.559 35.670956552316696 139.73797556603276 17.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f68f192-a381-4329-a25f-b98bc740cba9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f68f192-a381-4329-a25f-b98bc740cba9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f68f192-a381-4329-a25f-b98bc740cba9">
											<gml:posList>35.67087052585842 139.73809018561826 36.863 35.67087052585842 139.73809018561826 37.406 35.670862361322854 139.73809259236975 37.406 35.670862361322854 139.73809259236975 36.863 35.67087052585842 139.73809018561826 36.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2423f549-543b-4178-9aa3-b183c98c45a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2423f549-543b-4178-9aa3-b183c98c45a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2423f549-543b-4178-9aa3-b183c98c45a3">
											<gml:posList>35.670884941976624 139.73804861220427 34.227 35.670884941976624 139.73804861220427 32.65 35.67087951698384 139.7380502203691 32.65 35.67087951698384 139.7380502203691 29.919 35.670849706516194 139.73805900448505 29.919 35.670849706516194 139.73805900448505 34.227 35.670884941976624 139.73804861220427 34.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d431479-e7f0-47ae-81f1-c73a18e45466">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d431479-e7f0-47ae-81f1-c73a18e45466">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d431479-e7f0-47ae-81f1-c73a18e45466">
											<gml:posList>35.67086183101092 139.73812868134533 36.863 35.67086183101092 139.73812868134533 37.406 35.67087375940438 139.73818978650948 37.406 35.67087375940438 139.73818978650948 36.863 35.67086183101092 139.73812868134533 36.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b4aa441-716c-44df-b83e-3b904d96536b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b4aa441-716c-44df-b83e-3b904d96536b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b4aa441-716c-44df-b83e-3b904d96536b">
											<gml:posList>35.670883466077655 139.73805158542064 34.033 35.670883466077655 139.73805158542064 34.227 35.670852132649365 139.73806082424557 34.227 35.670852132649365 139.73806082424557 34.033 35.670883466077655 139.73805158542064 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3e236b8-95b6-483f-8f5a-2221ab4d7e30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3e236b8-95b6-483f-8f5a-2221ab4d7e30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3e236b8-95b6-483f-8f5a-2221ab4d7e30">
											<gml:posList>35.67087822281187 139.73804363829575 29.919 35.67087822281187 139.73804363829575 30.179 35.67085749599933 139.73804966108415 30.179 35.67085749599933 139.73804966108415 29.919 35.67087822281187 139.73804363829575 29.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3c855b3-1bc7-4ea9-8e5b-d43f217400af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3c855b3-1bc7-4ea9-8e5b-d43f217400af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3c855b3-1bc7-4ea9-8e5b-d43f217400af">
											<gml:posList>35.670856775398526 139.73808446891016 34.033 35.670856775398526 139.73808446891016 34.227 35.67088810883736 139.73807524114028 34.227 35.67088810883736 139.73807524114028 34.033 35.670856775398526 139.73808446891016 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-705a5225-5948-4da5-be87-7848b0f0f808">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-705a5225-5948-4da5-be87-7848b0f0f808">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-705a5225-5948-4da5-be87-7848b0f0f808">
											<gml:posList>35.67087052585842 139.73809018561826 37.406 35.67087052585842 139.73809018561826 36.863 35.67087722314554 139.73812448755615 36.863 35.67087722314554 139.73812448755615 43.143 35.67086996472721 139.73808730319357 43.143 35.67086996472721 139.73808730319357 37.406 35.67087052585842 139.73809018561826 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed582bac-b0f9-4ee1-b8c3-d2068044a4b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed582bac-b0f9-4ee1-b8c3-d2068044a4b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed582bac-b0f9-4ee1-b8c3-d2068044a4b2">
											<gml:posList>35.67087373470826 139.73809013762107 42.847 35.67087373470826 139.73809013762107 43.143 35.6708795360122 139.73811985639819 43.143 35.6708795360122 139.73811985639819 42.847 35.67087373470826 139.73809013762107 42.847</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-548b3151-a828-473e-aaa3-b400c70b7989">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-548b3151-a828-473e-aaa3-b400c70b7989">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-548b3151-a828-473e-aaa3-b400c70b7989">
											<gml:posList>35.67092592120431 139.73817755154937 37.406 35.67087195948799 139.73819336765536 37.406 35.6708306227989 139.73820512580753 29.281 35.67092592120431 139.73817755154937 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb999aaf-b7fd-4881-a412-a52ecd7e7638">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb999aaf-b7fd-4881-a412-a52ecd7e7638">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb999aaf-b7fd-4881-a412-a52ecd7e7638">
											<gml:posList>35.67087822281187 139.73804363829575 30.179 35.67087822281187 139.73804363829575 29.919 35.67087951698384 139.7380502203691 29.919 35.67087951698384 139.7380502203691 32.65 35.670877589298776 139.73804041352102 32.65 35.670877589298776 139.73804041352102 30.179 35.67087822281187 139.73804363829575 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5db9b554-b19a-4bfc-9742-2b804faf1102">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5db9b554-b19a-4bfc-9742-2b804faf1102">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5db9b554-b19a-4bfc-9742-2b804faf1102">
											<gml:posList>35.67086996472721 139.73808730319357 37.406 35.67086996472721 139.73808730319357 43.143 35.670904434198434 139.73807713275923 43.143 35.670904434198434 139.73807713275923 37.406 35.67090624553697 139.7380766003833 37.406 35.67090624553697 139.7380766003833 30.179 35.670859439138425 139.7380903976223 30.179 35.670859439138425 139.7380903976223 35.253 35.670859439138425 139.7380903976223 37.406 35.67086996472721 139.73808730319357 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1131c3c9-e524-47ec-8068-9261fdff3e57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1131c3c9-e524-47ec-8068-9261fdff3e57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1131c3c9-e524-47ec-8068-9261fdff3e57">
											<gml:posList>35.67088810883736 139.73807524114028 34.033 35.67088810883736 139.73807524114028 34.227 35.670883466077655 139.73805158542064 34.227 35.670883466077655 139.73805158542064 34.033 35.67088810883736 139.73807524114028 34.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-959030bd-ecc6-43b3-a585-ef9b9ebab1e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-959030bd-ecc6-43b3-a585-ef9b9ebab1e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-959030bd-ecc6-43b3-a585-ef9b9ebab1e7">
											<gml:posList>35.67089052594782 139.73807704986652 32.65 35.670884941976624 139.73804861220427 32.65 35.670884941976624 139.73804861220427 34.227 35.67089052594782 139.73807704986652 34.227 35.67089052594782 139.73807704986652 32.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e782442c-66a3-4277-a67b-af799e42f9cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e782442c-66a3-4277-a67b-af799e42f9cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e782442c-66a3-4277-a67b-af799e42f9cf">
											<gml:posList>35.6709021123197 139.73808176393055 42.847 35.6709021123197 139.73808176393055 43.143 35.67087373470826 139.73809013762107 43.143 35.67087373470826 139.73809013762107 42.847 35.6709021123197 139.73808176393055 42.847</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11c581de-8e71-434b-9676-e2d9ffb61f92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11c581de-8e71-434b-9676-e2d9ffb61f92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11c581de-8e71-434b-9676-e2d9ffb61f92">
											<gml:posList>35.67089888381785 139.73803419121998 30.179 35.670877589298776 139.73804041352102 30.179 35.670877589298776 139.73804041352102 32.65 35.67089888381785 139.73803419121998 32.65 35.67089888381785 139.73803419121998 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38a6c746-1bc2-4708-adc9-0dd7c028e7d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38a6c746-1bc2-4708-adc9-0dd7c028e7d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38a6c746-1bc2-4708-adc9-0dd7c028e7d9">
											<gml:posList>35.6708795360122 139.73811985639819 42.847 35.6708795360122 139.73811985639819 43.143 35.67090790465564 139.7381115379599 43.143 35.67090790465564 139.7381115379599 42.847 35.6708795360122 139.73811985639819 42.847</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb1fa8c9-0ef5-4361-8f64-35b6cd17bf30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb1fa8c9-0ef5-4361-8f64-35b6cd17bf30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb1fa8c9-0ef5-4361-8f64-35b6cd17bf30">
											<gml:posList>35.67087722314554 139.73812448755615 43.143 35.67087722314554 139.73812448755615 36.863 35.67091168365857 139.7381143834255 36.863 35.67091168365857 139.7381143834255 37.406 35.67091168365857 139.7381143834255 43.143 35.67087722314554 139.73812448755615 43.143</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de2e167b-b8eb-400e-9aca-6fc93d6db50c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de2e167b-b8eb-400e-9aca-6fc93d6db50c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de2e167b-b8eb-400e-9aca-6fc93d6db50c">
											<gml:posList>35.67087375940438 139.73818978650948 36.863 35.67087375940438 139.73818978650948 37.406 35.67092300802644 139.73817534574005 37.406 35.67092300802644 139.73817534574005 36.863 35.67087375940438 139.73818978650948 36.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13737e84-1bb4-469c-8468-195d6e90f61f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13737e84-1bb4-469c-8468-195d6e90f61f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13737e84-1bb4-469c-8468-195d6e90f61f">
											<gml:posList>35.6708306227989 139.73820512580753 29.281 35.670809454733295 139.7382116903437 17.2 35.670992210842314 139.73815811968035 17.2 35.6708306227989 139.73820512580753 29.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5c04e51-4b61-4d79-93df-ead5364e69e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5c04e51-4b61-4d79-93df-ead5364e69e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5c04e51-4b61-4d79-93df-ead5364e69e3">
											<gml:posList>35.67090637739582 139.73807236948159 30.179 35.67089888381785 139.73803419121998 30.179 35.67089888381785 139.73803419121998 32.65 35.67090637739582 139.73807236948159 32.65 35.67090637739582 139.73807236948159 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-661c5666-128d-4dd6-9623-a43d83e286cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-661c5666-128d-4dd6-9623-a43d83e286cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-661c5666-128d-4dd6-9623-a43d83e286cf">
											<gml:posList>35.67090790465564 139.7381115379599 42.847 35.67090790465564 139.7381115379599 43.143 35.6709021123197 139.73808176393055 43.143 35.6709021123197 139.73808176393055 42.847 35.67090790465564 139.7381115379599 42.847</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17d14fed-5a56-4c3c-b3f3-f814ca18375d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17d14fed-5a56-4c3c-b3f3-f814ca18375d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17d14fed-5a56-4c3c-b3f3-f814ca18375d">
											<gml:posList>35.67091168365857 139.7381143834255 37.406 35.670904434198434 139.73807713275923 37.406 35.670904434198434 139.73807713275923 43.143 35.67091168365857 139.7381143834255 43.143 35.67091168365857 139.7381143834255 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b641dbf-bd77-45dc-87bb-31b3ba8f9b32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b641dbf-bd77-45dc-87bb-31b3ba8f9b32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b641dbf-bd77-45dc-87bb-31b3ba8f9b32">
											<gml:posList>35.67092592120431 139.73817755154937 37.406 35.6708306227989 139.73820512580753 29.281 35.670992210842314 139.73815811968035 26.184 35.67092592120431 139.73817755154937 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68080b65-1f99-4bb0-a363-372b4b5f6d28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68080b65-1f99-4bb0-a363-372b4b5f6d28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68080b65-1f99-4bb0-a363-372b4b5f6d28">
											<gml:posList>35.6708306227989 139.73820512580753 29.281 35.670992210842314 139.73815811968035 17.2 35.670992210842314 139.73815811968035 26.184 35.6708306227989 139.73820512580753 29.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73bb8d88-bcf3-4a9a-86c4-86c4c28c1f56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73bb8d88-bcf3-4a9a-86c4-86c4c28c1f56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73bb8d88-bcf3-4a9a-86c4-86c4c28c1f56">
											<gml:posList>35.67092300802644 139.73817534574005 36.863 35.67092300802644 139.73817534574005 37.406 35.67091168365857 139.7381143834255 37.406 35.67091168365857 139.7381143834255 36.863 35.67092300802644 139.73817534574005 36.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8dfe137a-3487-4823-b07f-8bce5147acbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dfe137a-3487-4823-b07f-8bce5147acbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dfe137a-3487-4823-b07f-8bce5147acbc">
											<gml:posList>35.6709356144294 139.738067938302 30.179 35.67090624553697 139.7380766003833 30.179 35.67090624553697 139.7380766003833 37.406 35.67097248099778 139.73805706908294 26.184 35.67097248099778 139.73805706908294 23.559 35.6709356144294 139.738067938302 30.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df1f2d50-9dec-4de5-88bb-a3dc4f669c66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df1f2d50-9dec-4de5-88bb-a3dc4f669c66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df1f2d50-9dec-4de5-88bb-a3dc4f669c66">
											<gml:posList>35.670992210842314 139.73815811968035 26.184 35.670992210842314 139.73815811968035 17.2 35.670956552316696 139.73797556603276 17.2 35.670956552316696 139.73797556603276 23.559 35.67097248099778 139.73805706908294 23.559 35.67097248099778 139.73805706908294 26.184 35.670992210842314 139.73815811968035 26.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4086</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">195.8325</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>