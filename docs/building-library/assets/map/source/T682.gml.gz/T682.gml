<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c649a29e-50f6-4b09-b81c-349a0c78012a">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">7.2</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67451647899569 139.7397798743231 0 35.67450568834986 139.73977830721947 0 35.674505911907424 139.7397760092184 0 35.674506993820046 139.739764751238 0 35.674473594206496 139.73975990752592 0 35.674474872882506 139.73974667193872 0 35.67444423178301 139.7397422337479 0 35.67444527796394 139.73973139559658 0 35.67439650821024 139.73972431629946 0 35.67439310144404 139.73975964798325 0 35.67435390897335 139.74016545399567 0 35.67441727355004 139.7401746375854 0 35.67446672839693 139.74018181578364 0 35.67447751902912 139.74018337189403 0 35.67451647899569 139.7397798743231 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67451647899569 139.7397798743231 27.39 35.67447751902912 139.74018337189403 27.39 35.67446672839693 139.74018181578364 27.39 35.67441727355004 139.7401746375854 27.39 35.67435390897335 139.74016545399567 27.39 35.67439310144404 139.73975964798325 27.39 35.67439650821024 139.73972431629946 27.39 35.67444527796394 139.73973139559658 27.39 35.67444423178301 139.7397422337479 27.39 35.674474872882506 139.73974667193872 27.39 35.674473594206496 139.73975990752592 27.39 35.674506993820046 139.739764751238 27.39 35.674505911907424 139.7397760092184 27.39 35.67450568834986 139.73977830721947 27.39 35.67451647899569 139.7397798743231 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67451647899569 139.7397798743231 27.39 35.67450568834986 139.73977830721947 27.39 35.67450568834986 139.73977830721947 33.59 35.67451647899569 139.7397798743231 33.59 35.67451647899569 139.7397798743231 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67450568834986 139.73977830721947 27.39 35.674505911907424 139.7397760092184 27.39 35.674505911907424 139.7397760092184 33.59 35.67450568834986 139.73977830721947 33.59 35.67450568834986 139.73977830721947 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674505911907424 139.7397760092184 27.39 35.674506993820046 139.739764751238 27.39 35.674506993820046 139.739764751238 33.59 35.674505911907424 139.7397760092184 33.59 35.674505911907424 139.7397760092184 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674506993820046 139.739764751238 27.39 35.674473594206496 139.73975990752592 27.39 35.674473594206496 139.73975990752592 33.59 35.674506993820046 139.739764751238 33.59 35.674506993820046 139.739764751238 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674473594206496 139.73975990752592 27.39 35.674474872882506 139.73974667193872 27.39 35.674474872882506 139.73974667193872 33.59 35.674473594206496 139.73975990752592 33.59 35.674473594206496 139.73975990752592 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674474872882506 139.73974667193872 27.39 35.67444423178301 139.7397422337479 27.39 35.67444423178301 139.7397422337479 33.59 35.674474872882506 139.73974667193872 33.59 35.674474872882506 139.73974667193872 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67444423178301 139.7397422337479 27.39 35.67444527796394 139.73973139559658 27.39 35.67444527796394 139.73973139559658 33.59 35.67444423178301 139.7397422337479 33.59 35.67444423178301 139.7397422337479 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67444527796394 139.73973139559658 27.39 35.67439650821024 139.73972431629946 27.39 35.67439650821024 139.73972431629946 33.59 35.67444527796394 139.73973139559658 33.59 35.67444527796394 139.73973139559658 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67439650821024 139.73972431629946 27.39 35.67439310144404 139.73975964798325 27.39 35.67439310144404 139.73975964798325 33.59 35.67439650821024 139.73972431629946 33.59 35.67439650821024 139.73972431629946 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67439310144404 139.73975964798325 27.39 35.67435390897335 139.74016545399567 27.39 35.67435390897335 139.74016545399567 33.59 35.67439310144404 139.73975964798325 33.59 35.67439310144404 139.73975964798325 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67435390897335 139.74016545399567 27.39 35.67441727355004 139.7401746375854 27.39 35.67441727355004 139.7401746375854 33.59 35.67435390897335 139.74016545399567 33.59 35.67435390897335 139.74016545399567 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67441727355004 139.7401746375854 27.39 35.67446672839693 139.74018181578364 27.39 35.67446672839693 139.74018181578364 33.59 35.67441727355004 139.7401746375854 33.59 35.67441727355004 139.7401746375854 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67446672839693 139.74018181578364 27.39 35.67447751902912 139.74018337189403 27.39 35.67447751902912 139.74018337189403 33.59 35.67446672839693 139.74018181578364 33.59 35.67446672839693 139.74018181578364 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67447751902912 139.74018337189403 27.39 35.67451647899569 139.7397798743231 27.39 35.67451647899569 139.7397798743231 33.59 35.67447751902912 139.74018337189403 33.59 35.67447751902912 139.74018337189403 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67451647899569 139.7397798743231 33.59 35.67450568834986 139.73977830721947 33.59 35.674505911907424 139.7397760092184 33.59 35.674506993820046 139.739764751238 33.59 35.674473594206496 139.73975990752592 33.59 35.674474872882506 139.73974667193872 33.59 35.67444423178301 139.7397422337479 33.59 35.67444527796394 139.73973139559658 33.59 35.67439650821024 139.73972431629946 33.59 35.67439310144404 139.73975964798325 33.59 35.67435390897335 139.74016545399567 33.59 35.67441727355004 139.7401746375854 33.59 35.67446672839693 139.74018181578364 33.59 35.67447751902912 139.74018337189403 33.59 35.67451647899569 139.7397798743231 33.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f0ea6fd0-6104-4976-96b1-3a34e4dd0e11"/>
							<gml:surfaceMember xlink:href="#poly-bb7bd119-b41d-409b-8f18-30b91ebc4a0f"/>
							<gml:surfaceMember xlink:href="#poly-4b45f4a1-6ddd-430a-851a-91648c2dec4e"/>
							<gml:surfaceMember xlink:href="#poly-1038bbe3-99f6-4dbb-b228-c92423b6d27b"/>
							<gml:surfaceMember xlink:href="#poly-2bea65fd-81aa-456a-9207-35872bb6af7a"/>
							<gml:surfaceMember xlink:href="#poly-4fe77a1c-30ea-48f5-bd2f-7d2ce57371d7"/>
							<gml:surfaceMember xlink:href="#poly-80004cb9-fd11-4a75-b36a-ede2d16f8547"/>
							<gml:surfaceMember xlink:href="#poly-edff711a-e72b-4850-b2f6-98987fd41d95"/>
							<gml:surfaceMember xlink:href="#poly-f4c817f3-6915-41d1-92f2-84c5d44068b2"/>
							<gml:surfaceMember xlink:href="#poly-ef5e18d4-cc5d-4204-99ea-e7e72e952738"/>
							<gml:surfaceMember xlink:href="#poly-605dd6e1-d377-4924-bd40-5f35cc78331d"/>
							<gml:surfaceMember xlink:href="#poly-f46a357f-20ff-4a83-9dbd-8a4e97dc4b3c"/>
							<gml:surfaceMember xlink:href="#poly-2635da42-4c1f-4d07-9bc5-d5cfaef2bc04"/>
							<gml:surfaceMember xlink:href="#poly-23f672fb-cb38-421d-bea0-b75c0d7b5a32"/>
							<gml:surfaceMember xlink:href="#poly-f14aa720-69b5-483c-a05a-a96023d5aa2a"/>
							<gml:surfaceMember xlink:href="#poly-11ff9fc3-d8bd-49df-8a48-115fbcc8877e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f0ea6fd0-6104-4976-96b1-3a34e4dd0e11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0ea6fd0-6104-4976-96b1-3a34e4dd0e11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0ea6fd0-6104-4976-96b1-3a34e4dd0e11">
											<gml:posList>35.67439650821021 139.73972431629946 27.39 35.674445277963926 139.73973139559658 27.39 35.67444423178299 139.73974223374788 27.39 35.67447487288248 139.73974667193872 27.39 35.6744735942065 139.7397599075259 27.39 35.67450699382002 139.73976475123797 27.39 35.67450568834984 139.73977830721944 27.39 35.67451647899567 139.73977987432306 27.39 35.67447751903763 139.74018338294084 27.39 35.67435390897335 139.74016545399567 27.39 35.67439650821021 139.73972431629946 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb7bd119-b41d-409b-8f18-30b91ebc4a0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb7bd119-b41d-409b-8f18-30b91ebc4a0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb7bd119-b41d-409b-8f18-30b91ebc4a0f">
											<gml:posList>35.67445645703704 139.73976883126707 34.541 35.67439310144401 139.73975964798325 31.291 35.67435390897335 139.74016545399567 31.291 35.67441726453632 139.74017463759589 34.541 35.67445645703704 139.73976883126707 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4b45f4a1-6ddd-430a-851a-91648c2dec4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b45f4a1-6ddd-430a-851a-91648c2dec4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b45f4a1-6ddd-430a-851a-91648c2dec4e">
											<gml:posList>35.6744735942065 139.7397599075259 31.291 35.67447487288248 139.73974667193872 31.291 35.67444423178299 139.73974223374788 31.291 35.674445277963926 139.73973139559658 31.291 35.67439650821021 139.73972431629946 31.291 35.67439310144401 139.73975964798325 31.291 35.67450591190741 139.73977600921836 31.291 35.67450699382002 139.73976475123797 31.291 35.6744735942065 139.7397599075259 31.291</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1038bbe3-99f6-4dbb-b228-c92423b6d27b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1038bbe3-99f6-4dbb-b228-c92423b6d27b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1038bbe3-99f6-4dbb-b228-c92423b6d27b">
											<gml:posList>35.67441726453632 139.74017463759589 34.541 35.67446671938318 139.74018181579413 31.291 35.67450568834984 139.73977830721944 31.291 35.67450591190741 139.73977600921836 31.291 35.67445645703704 139.73976883126707 34.541 35.67441726453632 139.74017463759589 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2bea65fd-81aa-456a-9207-35872bb6af7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bea65fd-81aa-456a-9207-35872bb6af7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bea65fd-81aa-456a-9207-35872bb6af7a">
											<gml:posList>35.67447751903763 139.74018338294084 31.291 35.67451647899567 139.73977987432306 31.291 35.67450568834984 139.73977830721944 31.291 35.67446671938318 139.74018181579413 31.291 35.67447751903763 139.74018338294084 31.291</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fe77a1c-30ea-48f5-bd2f-7d2ce57371d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fe77a1c-30ea-48f5-bd2f-7d2ce57371d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fe77a1c-30ea-48f5-bd2f-7d2ce57371d7">
											<gml:posList>35.67435390897335 139.74016545399567 27.39 35.67435390897335 139.74016545399567 31.291 35.67439310144401 139.73975964798325 31.291 35.67439650821021 139.73972431629946 31.291 35.67439650821021 139.73972431629946 27.39 35.67435390897335 139.74016545399567 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80004cb9-fd11-4a75-b36a-ede2d16f8547">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80004cb9-fd11-4a75-b36a-ede2d16f8547">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80004cb9-fd11-4a75-b36a-ede2d16f8547">
											<gml:posList>35.67447751903763 139.74018338294084 27.39 35.67447751903763 139.74018338294084 31.291 35.67446671938318 139.74018181579413 31.291 35.67441726453632 139.74017463759589 34.541 35.67435390897335 139.74016545399567 31.291 35.67435390897335 139.74016545399567 27.39 35.67447751903763 139.74018338294084 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edff711a-e72b-4850-b2f6-98987fd41d95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edff711a-e72b-4850-b2f6-98987fd41d95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edff711a-e72b-4850-b2f6-98987fd41d95">
											<gml:posList>35.674445277963926 139.73973139559658 27.39 35.67439650821021 139.73972431629946 27.39 35.67439650821021 139.73972431629946 31.291 35.674445277963926 139.73973139559658 31.291 35.674445277963926 139.73973139559658 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4c817f3-6915-41d1-92f2-84c5d44068b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4c817f3-6915-41d1-92f2-84c5d44068b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4c817f3-6915-41d1-92f2-84c5d44068b2">
											<gml:posList>35.67444423178299 139.73974223374788 27.39 35.674445277963926 139.73973139559658 27.39 35.674445277963926 139.73973139559658 31.291 35.67444423178299 139.73974223374788 31.291 35.67444423178299 139.73974223374788 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef5e18d4-cc5d-4204-99ea-e7e72e952738">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef5e18d4-cc5d-4204-99ea-e7e72e952738">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef5e18d4-cc5d-4204-99ea-e7e72e952738">
											<gml:posList>35.67450591190741 139.73977600921836 31.291 35.67439310144401 139.73975964798325 31.291 35.67445645703704 139.73976883126707 34.541 35.67450591190741 139.73977600921836 31.291</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-605dd6e1-d377-4924-bd40-5f35cc78331d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-605dd6e1-d377-4924-bd40-5f35cc78331d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-605dd6e1-d377-4924-bd40-5f35cc78331d">
											<gml:posList>35.67447487288248 139.73974667193872 27.39 35.67444423178299 139.73974223374788 27.39 35.67444423178299 139.73974223374788 31.291 35.67447487288248 139.73974667193872 31.291 35.67447487288248 139.73974667193872 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f46a357f-20ff-4a83-9dbd-8a4e97dc4b3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f46a357f-20ff-4a83-9dbd-8a4e97dc4b3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f46a357f-20ff-4a83-9dbd-8a4e97dc4b3c">
											<gml:posList>35.6744735942065 139.7397599075259 27.39 35.67447487288248 139.73974667193872 27.39 35.67447487288248 139.73974667193872 31.291 35.6744735942065 139.7397599075259 31.291 35.6744735942065 139.7397599075259 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2635da42-4c1f-4d07-9bc5-d5cfaef2bc04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2635da42-4c1f-4d07-9bc5-d5cfaef2bc04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2635da42-4c1f-4d07-9bc5-d5cfaef2bc04">
											<gml:posList>35.67450699382002 139.73976475123797 27.39 35.6744735942065 139.7397599075259 27.39 35.6744735942065 139.7397599075259 31.291 35.67450699382002 139.73976475123797 31.291 35.67450699382002 139.73976475123797 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23f672fb-cb38-421d-bea0-b75c0d7b5a32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23f672fb-cb38-421d-bea0-b75c0d7b5a32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23f672fb-cb38-421d-bea0-b75c0d7b5a32">
											<gml:posList>35.67447751903763 139.74018338294084 27.39 35.67451647899567 139.73977987432306 27.39 35.67451647899567 139.73977987432306 31.291 35.67447751903763 139.74018338294084 31.291 35.67447751903763 139.74018338294084 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f14aa720-69b5-483c-a05a-a96023d5aa2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f14aa720-69b5-483c-a05a-a96023d5aa2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f14aa720-69b5-483c-a05a-a96023d5aa2a">
											<gml:posList>35.67450699382002 139.73976475123797 27.39 35.67450699382002 139.73976475123797 31.291 35.67450591190741 139.73977600921836 31.291 35.67450568834984 139.73977830721944 31.291 35.67450568834984 139.73977830721944 27.39 35.67450699382002 139.73976475123797 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11ff9fc3-d8bd-49df-8a48-115fbcc8877e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11ff9fc3-d8bd-49df-8a48-115fbcc8877e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11ff9fc3-d8bd-49df-8a48-115fbcc8877e">
											<gml:posList>35.67451647899567 139.73977987432306 27.39 35.67450568834984 139.73977830721944 27.39 35.67450568834984 139.73977830721944 31.291 35.67451647899567 139.73977987432306 31.291 35.67451647899567 139.73977987432306 27.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4580</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>