<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c6dd3d79-55c9-44a2-89ae-cebea0f1c914">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">3.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6702525612994 139.7445527834541 0 35.67021841656569 139.74469863159825 0 35.67036691120906 139.74475093716634 0 35.67040114606075 139.74460497821184 0 35.6702525612994 139.7445527834541 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6702525612994 139.7445527834541 7.828 35.67040114606075 139.74460497821184 7.828 35.67036691120906 139.74475093716634 7.828 35.67021841656569 139.74469863159825 7.828 35.6702525612994 139.7445527834541 7.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6702525612994 139.7445527834541 7.828 35.67021841656569 139.74469863159825 7.828 35.67021841656569 139.74469863159825 11.45 35.6702525612994 139.7445527834541 11.45 35.6702525612994 139.7445527834541 7.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021841656569 139.74469863159825 7.828 35.67036691120906 139.74475093716634 7.828 35.67036691120906 139.74475093716634 11.45 35.67021841656569 139.74469863159825 11.45 35.67021841656569 139.74469863159825 7.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67036691120906 139.74475093716634 7.828 35.67040114606075 139.74460497821184 7.828 35.67040114606075 139.74460497821184 11.45 35.67036691120906 139.74475093716634 11.45 35.67036691120906 139.74475093716634 7.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67040114606075 139.74460497821184 7.828 35.6702525612994 139.7445527834541 7.828 35.6702525612994 139.7445527834541 11.45 35.67040114606075 139.74460497821184 11.45 35.67040114606075 139.74460497821184 7.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6702525612994 139.7445527834541 11.45 35.67021841656569 139.74469863159825 11.45 35.67036691120906 139.74475093716634 11.45 35.67040114606075 139.74460497821184 11.45 35.6702525612994 139.7445527834541 11.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5ed5e69a-1d92-44f5-bd70-ede573799057"/>
							<gml:surfaceMember xlink:href="#poly-4fdd940b-ec6d-4fa2-8c3c-51d87d7cb845"/>
							<gml:surfaceMember xlink:href="#poly-4a578d02-ab9d-4e98-b019-93934163f9e3"/>
							<gml:surfaceMember xlink:href="#poly-a4ba3d9e-91d6-4917-a08f-10ef355dac20"/>
							<gml:surfaceMember xlink:href="#poly-64603aa8-2849-40b9-b656-c277575a73c7"/>
							<gml:surfaceMember xlink:href="#poly-e887bf7f-72c7-4b95-813b-628e2a0d7d0b"/>
							<gml:surfaceMember xlink:href="#poly-263ea05d-13cf-4cf1-9ead-69cc85500159"/>
							<gml:surfaceMember xlink:href="#poly-1b57b050-f1f9-488f-8143-b82bc052b253"/>
							<gml:surfaceMember xlink:href="#poly-a6d40a86-67a5-442c-b1db-08ce6c5600b9"/>
							<gml:surfaceMember xlink:href="#poly-7b68c9c4-6d35-41b0-ac9a-ccf2b4f87248"/>
							<gml:surfaceMember xlink:href="#poly-71b20e68-b041-43a7-8a88-7c5b583f0c3b"/>
							<gml:surfaceMember xlink:href="#poly-cf9931b2-45bd-42b2-bf59-4d162a76ae15"/>
							<gml:surfaceMember xlink:href="#poly-eca82027-0298-47b0-aab1-a8aeeb7cbc46"/>
							<gml:surfaceMember xlink:href="#poly-92f74833-00a2-45e5-9698-caf6b541a4e6"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c6dd3d79-55c9-44a2-89ae-cebea0f1c914_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de77b3af-39fe-4432-a16f-9a867d72cc1b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67032796282848 139.74468962931022 11.391 35.670326533972386 139.7446955074963 11.391 35.670271878002055 139.74467549689226 11.391 35.6702733068572 139.74466961870988 11.391 35.67032796282848 139.74468962931022 11.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c49f81f8-90a1-430f-850c-65075c14965b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c49f81f8-90a1-430f-850c-65075c14965b_0">
											<gml:posList>35.670271878002055 139.74467549689226 11.391 35.670271878002055 139.74467549689226 13.135 35.6702733068572 139.74466961870988 13.135 35.6702733068572 139.74466961870988 11.391 35.670271878002055 139.74467549689226 11.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-083d045e-5e1d-49a1-8365-f1b839aafab4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-083d045e-5e1d-49a1-8365-f1b839aafab4_0">
											<gml:posList>35.6702733068572 139.74466961870988 11.391 35.6702733068572 139.74466961870988 13.135 35.67032796282848 139.74468962931022 13.135 35.67032796282848 139.74468962931022 11.391 35.6702733068572 139.74466961870988 11.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a900224-1832-425a-9a50-264b047f19db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a900224-1832-425a-9a50-264b047f19db_0">
											<gml:posList>35.670271878002055 139.74467549689226 13.135 35.670326533972386 139.7446955074963 13.135 35.67032796282848 139.74468962931022 13.135 35.6702733068572 139.74466961870988 13.135 35.670271878002055 139.74467549689226 13.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5e717d2-0dbd-4b8c-a1ea-0cd10f6745fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5e717d2-0dbd-4b8c-a1ea-0cd10f6745fa_0">
											<gml:posList>35.670326533972386 139.7446955074963 11.391 35.670326533972386 139.7446955074963 13.135 35.670271878002055 139.74467549689226 13.135 35.670271878002055 139.74467549689226 11.391 35.670326533972386 139.7446955074963 11.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79aef05c-b3e8-4aa5-b465-aceb66c9c5c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79aef05c-b3e8-4aa5-b465-aceb66c9c5c3_0">
											<gml:posList>35.67032796282848 139.74468962931022 11.391 35.67032796282848 139.74468962931022 13.135 35.670326533972386 139.7446955074963 13.135 35.670326533972386 139.7446955074963 11.391 35.67032796282848 139.74468962931022 11.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5ed5e69a-1d92-44f5-bd70-ede573799057">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ed5e69a-1d92-44f5-bd70-ede573799057">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ed5e69a-1d92-44f5-bd70-ede573799057">
											<gml:posList>35.6702525612994 139.7445527834541 7.828 35.67040114606075 139.74460497821184 7.828 35.67036691120903 139.74475093716634 7.828 35.67021841656567 139.74469863159823 7.828 35.6702525612994 139.7445527834541 7.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4fdd940b-ec6d-4fa2-8c3c-51d87d7cb845">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fdd940b-ec6d-4fa2-8c3c-51d87d7cb845">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fdd940b-ec6d-4fa2-8c3c-51d87d7cb845">
											<gml:posList>35.6702525612994 139.7445527834541 11.6 35.67021841656567 139.74469863159823 11.6 35.6702217589904 139.74469636342448 11.6 35.67025441213429 139.7445568795607 11.6 35.6702525612994 139.7445527834541 11.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a578d02-ab9d-4e98-b019-93934163f9e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a578d02-ab9d-4e98-b019-93934163f9e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a578d02-ab9d-4e98-b019-93934163f9e3">
											<gml:posList>35.67021841656567 139.74469863159823 11.6 35.67036691120903 139.74475093716634 11.6 35.67036506038076 139.74474684104956 11.6 35.6702217589904 139.74469636342448 11.6 35.67021841656567 139.74469863159823 11.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4ba3d9e-91d6-4917-a08f-10ef355dac20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4ba3d9e-91d6-4917-a08f-10ef355dac20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4ba3d9e-91d6-4917-a08f-10ef355dac20">
											<gml:posList>35.67039779462412 139.74460724640446 11.391 35.67025441213429 139.7445568795607 11.391 35.6702217589904 139.74469636342448 11.391 35.67036506038076 139.74474684104956 11.391 35.67039779462412 139.74460724640446 11.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-64603aa8-2849-40b9-b656-c277575a73c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64603aa8-2849-40b9-b656-c277575a73c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64603aa8-2849-40b9-b656-c277575a73c7">
											<gml:posList>35.67040114606075 139.74460497821184 11.6 35.6702525612994 139.7445527834541 11.6 35.67025441213429 139.7445568795607 11.6 35.67039779462412 139.74460724640446 11.6 35.67040114606075 139.74460497821184 11.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e887bf7f-72c7-4b95-813b-628e2a0d7d0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e887bf7f-72c7-4b95-813b-628e2a0d7d0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e887bf7f-72c7-4b95-813b-628e2a0d7d0b">
											<gml:posList>35.67036691120903 139.74475093716634 11.6 35.67040114606075 139.74460497821184 11.6 35.67039779462412 139.74460724640446 11.6 35.67036506038076 139.74474684104956 11.6 35.67036691120903 139.74475093716634 11.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-263ea05d-13cf-4cf1-9ead-69cc85500159">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-263ea05d-13cf-4cf1-9ead-69cc85500159">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-263ea05d-13cf-4cf1-9ead-69cc85500159">
											<gml:posList>35.67040114606075 139.74460497821184 7.828 35.6702525612994 139.7445527834541 7.828 35.6702525612994 139.7445527834541 11.6 35.67040114606075 139.74460497821184 11.6 35.67040114606075 139.74460497821184 7.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b57b050-f1f9-488f-8143-b82bc052b253">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b57b050-f1f9-488f-8143-b82bc052b253">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b57b050-f1f9-488f-8143-b82bc052b253">
											<gml:posList>35.67039779462412 139.74460724640446 11.6 35.67025441213429 139.7445568795607 11.6 35.67025441213429 139.7445568795607 11.391 35.67039779462412 139.74460724640446 11.391 35.67039779462412 139.74460724640446 11.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6d40a86-67a5-442c-b1db-08ce6c5600b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6d40a86-67a5-442c-b1db-08ce6c5600b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6d40a86-67a5-442c-b1db-08ce6c5600b9">
											<gml:posList>35.6702525612994 139.7445527834541 7.828 35.67021841656567 139.74469863159823 7.828 35.67021841656567 139.74469863159823 11.6 35.6702525612994 139.7445527834541 11.6 35.6702525612994 139.7445527834541 7.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b68c9c4-6d35-41b0-ac9a-ccf2b4f87248">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b68c9c4-6d35-41b0-ac9a-ccf2b4f87248">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b68c9c4-6d35-41b0-ac9a-ccf2b4f87248">
											<gml:posList>35.67025441213429 139.7445568795607 11.6 35.6702217589904 139.74469636342448 11.6 35.6702217589904 139.74469636342448 11.391 35.67025441213429 139.7445568795607 11.391 35.67025441213429 139.7445568795607 11.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71b20e68-b041-43a7-8a88-7c5b583f0c3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71b20e68-b041-43a7-8a88-7c5b583f0c3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71b20e68-b041-43a7-8a88-7c5b583f0c3b">
											<gml:posList>35.67036506038076 139.74474684104956 11.6 35.67039779462412 139.74460724640446 11.6 35.67039779462412 139.74460724640446 11.391 35.67036506038076 139.74474684104956 11.391 35.67036506038076 139.74474684104956 11.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf9931b2-45bd-42b2-bf59-4d162a76ae15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf9931b2-45bd-42b2-bf59-4d162a76ae15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf9931b2-45bd-42b2-bf59-4d162a76ae15">
											<gml:posList>35.67036691120903 139.74475093716634 7.828 35.67040114606075 139.74460497821184 7.828 35.67040114606075 139.74460497821184 11.6 35.67036691120903 139.74475093716634 11.6 35.67036691120903 139.74475093716634 7.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eca82027-0298-47b0-aab1-a8aeeb7cbc46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eca82027-0298-47b0-aab1-a8aeeb7cbc46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eca82027-0298-47b0-aab1-a8aeeb7cbc46">
											<gml:posList>35.6702217589904 139.74469636342448 11.6 35.67036506038076 139.74474684104956 11.6 35.67036506038076 139.74474684104956 11.391 35.6702217589904 139.74469636342448 11.391 35.6702217589904 139.74469636342448 11.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92f74833-00a2-45e5-9698-caf6b541a4e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92f74833-00a2-45e5-9698-caf6b541a4e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92f74833-00a2-45e5-9698-caf6b541a4e6">
											<gml:posList>35.67021841656567 139.74469863159823 7.828 35.67036691120903 139.74475093716634 7.828 35.67036691120903 139.74475093716634 11.6 35.67021841656567 139.74469863159823 11.6 35.67021841656567 139.74469863159823 7.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9169</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">228.3354</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>