<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c72fc560-fa72-4672-95e9-ec04bc5c4dc4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">19.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.674060871953074 139.73777211492606 0 35.67404816531872 139.73773011922714 0 35.67398805644201 139.73775743221123 0 35.67403514319188 139.73791534478138 0 35.67411776867693 139.73787702459805 0 35.67408330811094 139.7377620135277 0 35.674060871953074 139.73777211492606 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674060871953074 139.73777211492606 8.97 35.67408330811094 139.7377620135277 8.97 35.67411776867693 139.73787702459805 8.97 35.67403514319188 139.73791534478138 8.97 35.67398805644201 139.73775743221123 8.97 35.67404816531872 139.73773011922714 8.97 35.674060871953074 139.73777211492606 8.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674060871953074 139.73777211492606 8.97 35.67404816531872 139.73773011922714 8.97 35.67404816531872 139.73773011922714 28.32 35.674060871953074 139.73777211492606 28.32 35.674060871953074 139.73777211492606 8.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67404816531872 139.73773011922714 8.97 35.67398805644201 139.73775743221123 8.97 35.67398805644201 139.73775743221123 28.32 35.67404816531872 139.73773011922714 28.32 35.67404816531872 139.73773011922714 8.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67398805644201 139.73775743221123 8.97 35.67403514319188 139.73791534478138 8.97 35.67403514319188 139.73791534478138 28.32 35.67398805644201 139.73775743221123 28.32 35.67398805644201 139.73775743221123 8.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67403514319188 139.73791534478138 8.97 35.67411776867693 139.73787702459805 8.97 35.67411776867693 139.73787702459805 28.32 35.67403514319188 139.73791534478138 28.32 35.67403514319188 139.73791534478138 8.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67411776867693 139.73787702459805 8.97 35.67408330811094 139.7377620135277 8.97 35.67408330811094 139.7377620135277 28.32 35.67411776867693 139.73787702459805 28.32 35.67411776867693 139.73787702459805 8.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67408330811094 139.7377620135277 8.97 35.674060871953074 139.73777211492606 8.97 35.674060871953074 139.73777211492606 28.32 35.67408330811094 139.7377620135277 28.32 35.67408330811094 139.7377620135277 8.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674060871953074 139.73777211492606 28.32 35.67404816531872 139.73773011922714 28.32 35.67398805644201 139.73775743221123 28.32 35.67403514319188 139.73791534478138 28.32 35.67411776867693 139.73787702459805 28.32 35.67408330811094 139.7377620135277 28.32 35.674060871953074 139.73777211492606 28.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-04ec6bee-fd0b-479f-92a7-54b590817af0"/>
							<gml:surfaceMember xlink:href="#poly-516ed131-d40d-4558-9ed5-0f0ca65ea39f"/>
							<gml:surfaceMember xlink:href="#poly-7308c97f-815e-4136-bf51-c38af1ab0d1c"/>
							<gml:surfaceMember xlink:href="#poly-68582a37-abd4-440a-97e1-9fefe62e4eb3"/>
							<gml:surfaceMember xlink:href="#poly-8a07b43d-ebd7-4d5f-b69f-f2730014f9e0"/>
							<gml:surfaceMember xlink:href="#poly-0197c735-5020-4c19-be15-af83f8a27288"/>
							<gml:surfaceMember xlink:href="#poly-5f84b019-d1c8-4de1-9343-438ea4c2f3b6"/>
							<gml:surfaceMember xlink:href="#poly-253e7c0a-8476-43a0-adbb-7985580664f2"/>
							<gml:surfaceMember xlink:href="#poly-ee9f6e6c-db64-49e3-b47e-7471ff82828d"/>
							<gml:surfaceMember xlink:href="#poly-0801f484-33a3-43e5-a6b9-76abe4e38153"/>
							<gml:surfaceMember xlink:href="#poly-8092f636-9869-48b4-a405-3a2660da2e17"/>
							<gml:surfaceMember xlink:href="#poly-4217e00a-786a-44e9-a83d-a2a9e04806e1"/>
							<gml:surfaceMember xlink:href="#poly-56e21a5a-b588-4074-941a-43cb0b038b83"/>
							<gml:surfaceMember xlink:href="#poly-74353540-0d18-4941-a0e9-0d2c8c924194"/>
							<gml:surfaceMember xlink:href="#poly-8fae01c3-3e37-4700-ae19-134f3d0fc78c"/>
							<gml:surfaceMember xlink:href="#poly-0bd2b8d1-874a-4b75-b86f-76f2f7a2762b"/>
							<gml:surfaceMember xlink:href="#poly-1515b0ce-51ba-4895-824c-2488f5d95d30"/>
							<gml:surfaceMember xlink:href="#poly-4031fc6c-2dc9-447f-b7eb-d608542597e0"/>
							<gml:surfaceMember xlink:href="#poly-58c1e286-9ed5-4171-b219-bd2e46d670b8"/>
							<gml:surfaceMember xlink:href="#poly-d01a96a5-5bdd-4928-9a75-d0af98ea55dd"/>
							<gml:surfaceMember xlink:href="#poly-267070ec-a034-4379-8e6e-6d63ce34a991"/>
							<gml:surfaceMember xlink:href="#poly-ec886f99-ea73-4c1a-8e28-2d1b15c714c9"/>
							<gml:surfaceMember xlink:href="#poly-4be762f4-53b5-48ea-bb3e-f21beb925104"/>
							<gml:surfaceMember xlink:href="#poly-9d3aebdd-9d27-4010-a930-b7234213b50d"/>
							<gml:surfaceMember xlink:href="#poly-a5d07afb-82f6-4a45-8acf-6a58fe58e9d6"/>
							<gml:surfaceMember xlink:href="#poly-e0d4dbe9-2cb9-45d5-b3fd-49427d4b5587"/>
							<gml:surfaceMember xlink:href="#poly-0220224a-c760-4ad9-9ff1-d5a0249116fd"/>
							<gml:surfaceMember xlink:href="#poly-1e5d519b-c008-4198-932e-5ad33ae2deb9"/>
							<gml:surfaceMember xlink:href="#poly-23f05bad-e152-49c4-bd79-7295da2d5cdd"/>
							<gml:surfaceMember xlink:href="#poly-dbce03d2-0ea1-4757-b8db-5ee6ba8be1cf"/>
							<gml:surfaceMember xlink:href="#poly-74263990-a484-4a45-a33c-70ce33d9d6bb"/>
							<gml:surfaceMember xlink:href="#poly-a2ba7429-4cd7-490f-bdb0-bd6f849b3823"/>
							<gml:surfaceMember xlink:href="#poly-62a1862f-b66c-4255-a6ba-79da1af02331"/>
							<gml:surfaceMember xlink:href="#poly-a1c4cdda-fc6c-4613-9051-06998fea1bbf"/>
							<gml:surfaceMember xlink:href="#poly-8f02b56a-0a9c-4748-88b6-3f3bbeefe5d3"/>
							<gml:surfaceMember xlink:href="#poly-b2e9efa7-1d07-492b-be8b-d0d48724212d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c72fc560-fa72-4672-95e9-ec04bc5c4dc4_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8072994c-9173-4cd2-8fa4-c82ae523b94a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67407354190011 139.7378019702839 35.799 35.674056512040735 139.73780963493957 35.799 35.674049643437975 139.73778673213383 35.799 35.67406668230962 139.73777906746318 35.799 35.67407354190011 139.7378019702839 35.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbddc9c6-b2c7-4373-8ea7-ffcb80b2109d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbddc9c6-b2c7-4373-8ea7-ffcb80b2109d_0">
											<gml:posList>35.67406668230962 139.73777906746318 35.799 35.674049643437975 139.73778673213383 35.799 35.674049643437975 139.73778673213383 37.389 35.67406668230962 139.73777906746318 37.389 35.67406668230962 139.73777906746318 35.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a6ce770-57d9-42c8-b37f-63ec53d74b28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a6ce770-57d9-42c8-b37f-63ec53d74b28_0">
											<gml:posList>35.67407354190011 139.7378019702839 37.389 35.67407354190011 139.7378019702839 35.799 35.67406668230962 139.73777906746318 35.799 35.67406668230962 139.73777906746318 37.389 35.67407354190011 139.7378019702839 37.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dff5b216-4556-4beb-b44c-ea862f8b41d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dff5b216-4556-4beb-b44c-ea862f8b41d5_0">
											<gml:posList>35.674049643437975 139.73778673213383 37.389 35.674056512040735 139.73780963493957 37.389 35.67407354190011 139.7378019702839 37.389 35.67406668230962 139.73777906746318 37.389 35.674049643437975 139.73778673213383 37.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9575245b-db2e-41de-9f8e-6d6c1bff4e77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9575245b-db2e-41de-9f8e-6d6c1bff4e77_0">
											<gml:posList>35.674049643437975 139.73778673213383 37.389 35.674049643437975 139.73778673213383 35.799 35.674056512040735 139.73780963493957 35.799 35.674056512040735 139.73780963493957 37.389 35.674049643437975 139.73778673213383 37.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-057084d4-0a5e-4e26-9e26-454925d7e4a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-057084d4-0a5e-4e26-9e26-454925d7e4a7_0">
											<gml:posList>35.674056512040735 139.73780963493957 37.389 35.674056512040735 139.73780963493957 35.799 35.67407354190011 139.7378019702839 35.799 35.67407354190011 139.7378019702839 37.389 35.674056512040735 139.73780963493957 37.389</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c72fc560-fa72-4672-95e9-ec04bc5c4dc4_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-557dd329-e360-4f51-9d78-03e526614b53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-557dd329-e360-4f51-9d78-03e526614b53_0">
											<gml:posList>35.674029784363775 139.73777305781792 31.424 35.6740380379823 139.737769336267 30.671 35.674029784363775 139.73777305781792 30.671 35.674029784363775 139.73777305781792 31.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40e90e4d-ac97-40ff-bb56-87c4382dff00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40e90e4d-ac97-40ff-bb56-87c4382dff00_0">
											<gml:posList>35.674029784363775 139.73777305781792 31.424 35.6740380379823 139.737769336267 31.424 35.6740380379823 139.737769336267 30.671 35.674029784363775 139.73777305781792 31.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0592e85-ab66-4051-bb8b-e93d7329edb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0592e85-ab66-4051-bb8b-e93d7329edb6_0">
											<gml:posList>35.674029784363775 139.73777305781792 31.424 35.6740410633369 139.73781066964995 30.671 35.6740410633369 139.73781066964995 31.424 35.674029784363775 139.73777305781792 31.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5774376e-c584-4878-aa55-c3a21fb98945">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5774376e-c584-4878-aa55-c3a21fb98945_0">
											<gml:posList>35.674029784363775 139.73777305781792 31.424 35.674029784363775 139.73777305781792 30.671 35.6740410633369 139.73781066964995 30.671 35.674029784363775 139.73777305781792 31.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-936b2ada-425b-4fe1-93af-9da040d9e54b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-936b2ada-425b-4fe1-93af-9da040d9e54b_0">
											<gml:posList>35.67404148134343 139.73778084289003 30.671 35.6740380379823 139.737769336267 31.424 35.67404148134343 139.73778084289003 31.424 35.67404148134343 139.73778084289003 30.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8086345b-c204-4d91-9334-42a9bdb7c460">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8086345b-c204-4d91-9334-42a9bdb7c460_0">
											<gml:posList>35.67404148134343 139.73778084289003 30.671 35.6740380379823 139.737769336267 30.671 35.6740380379823 139.737769336267 31.424 35.67404148134343 139.73778084289003 30.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c35f9e8-5dc0-4558-889c-d7af6c052b3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c35f9e8-5dc0-4558-889c-d7af6c052b3f_0">
											<gml:posList>35.6740410633369 139.73781066964995 30.671 35.67404930795163 139.73780695915988 31.424 35.6740410633369 139.73781066964995 31.424 35.6740410633369 139.73781066964995 30.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c70d43d-348c-44a1-9a97-2ce17d10ac2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c70d43d-348c-44a1-9a97-2ce17d10ac2c_0">
											<gml:posList>35.6740410633369 139.73781066964995 30.671 35.67404930795163 139.73780695915988 30.671 35.67404930795163 139.73780695915988 31.424 35.6740410633369 139.73781066964995 30.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebaa9240-e521-4b9d-8a40-3b3217a402a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebaa9240-e521-4b9d-8a40-3b3217a402a5_0">
											<gml:posList>35.67404930795163 139.73780695915988 30.671 35.67404148134343 139.73778084289003 31.424 35.67404930795163 139.73780695915988 31.424 35.67404930795163 139.73780695915988 30.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74140e73-58d1-41a2-a125-4d29c5a7551b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74140e73-58d1-41a2-a125-4d29c5a7551b_0">
											<gml:posList>35.67404930795163 139.73780695915988 30.671 35.67404148134343 139.73778084289003 30.671 35.67404148134343 139.73778084289003 31.424 35.67404930795163 139.73780695915988 30.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cb09772-990b-4ca7-9091-bf18edf51a91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cb09772-990b-4ca7-9091-bf18edf51a91_0">
											<gml:posList>35.6740608809668 139.73777211491532 30.85 35.67404817433243 139.7377301192164 9.24 35.6740608809668 139.73777211491532 9.24 35.6740608809668 139.73777211491532 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8776a697-5f44-40dd-bdbd-b6df02b3f602">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8776a697-5f44-40dd-bdbd-b6df02b3f602_0">
											<gml:posList>35.6740608809668 139.73777211491532 30.85 35.67404817433243 139.7377301192164 30.85 35.67404817433243 139.7377301192164 9.24 35.6740608809668 139.73777211491532 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3dc4672-9d02-41d6-bf81-6b7a8ccee7a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3dc4672-9d02-41d6-bf81-6b7a8ccee7a1_0">
											<gml:posList>35.67404817433243 139.7377301192164 30.85 35.67407068249126 139.73771988516083 9.24 35.67404817433243 139.7377301192164 9.24 35.67404817433243 139.7377301192164 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3647df58-2f00-4b69-8730-4c1f32e77163">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3647df58-2f00-4b69-8730-4c1f32e77163_0">
											<gml:posList>35.67404817433243 139.7377301192164 30.85 35.67407068249126 139.73771988516083 30.85 35.67407068249126 139.73771988516083 9.24 35.67404817433243 139.7377301192164 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4892a75-cbf8-47a7-b5a8-9de15dd1c498">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4892a75-cbf8-47a7-b5a8-9de15dd1c498_0">
											<gml:posList>35.674083308110944 139.7377620135277 30.85 35.67407068249126 139.73771988516083 30.85 35.67407123403593 139.73776745188488 30.85 35.674083308110944 139.7377620135277 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c20a6d22-79f1-4833-b928-e67aba6eb500">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c20a6d22-79f1-4833-b928-e67aba6eb500_0">
											<gml:posList>35.67407123403593 139.73776745188488 30.85 35.67404817433243 139.7377301192164 30.85 35.6740608809668 139.73777211491532 30.85 35.67407123403593 139.73776745188488 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9cba6c5-1b3f-4d23-bd8c-7eb33eb2c069">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9cba6c5-1b3f-4d23-bd8c-7eb33eb2c069_0">
											<gml:posList>35.67407123403593 139.73776745188488 30.85 35.67407068249126 139.73771988516083 30.85 35.67404817433243 139.7377301192164 30.85 35.67407123403593 139.73776745188488 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b12292b-db54-42f3-abc1-91c01cd3a1d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b12292b-db54-42f3-abc1-91c01cd3a1d5_0">
											<gml:posList>35.6740608809668 139.73777211491532 30.85 35.6740608809668 139.73777211491532 9.24 35.67407029694259 139.73776787277916 9.24 35.6740608809668 139.73777211491532 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bff5fed2-ecbc-465f-a5a6-b2ac2d57da7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bff5fed2-ecbc-465f-a5a6-b2ac2d57da7f_0">
											<gml:posList>35.67407123403593 139.73776745188488 30.85 35.6740608809668 139.73777211491532 30.85 35.67407029694259 139.73776787277916 9.24 35.67407123403593 139.73776745188488 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b11b70e-087a-4d39-998b-6752aa8ab257">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b11b70e-087a-4d39-998b-6752aa8ab257_0">
											<gml:posList>35.674083308110944 139.7377620135277 9.24 35.674083308110944 139.7377620135277 30.85 35.67407123403593 139.73776745188488 30.85 35.674083308110944 139.7377620135277 9.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f79ede86-58db-4a10-a723-8f32ba3bdecc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f79ede86-58db-4a10-a723-8f32ba3bdecc_0">
											<gml:posList>35.67407029694259 139.73776787277916 9.24 35.674083308110944 139.7377620135277 9.24 35.67407123403593 139.73776745188488 30.85 35.67407029694259 139.73776787277916 9.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ed6ee49-c589-478a-a765-2fd4c5a08085">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ed6ee49-c589-478a-a765-2fd4c5a08085_0">
											<gml:posList>35.67407068249126 139.73771988516083 9.24 35.674083308110944 139.7377620135277 30.85 35.674083308110944 139.7377620135277 9.24 35.67407068249126 139.73771988516083 9.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1848a46b-13ed-4b22-9bcc-c0c4e393bae6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1848a46b-13ed-4b22-9bcc-c0c4e393bae6_0">
											<gml:posList>35.67407068249126 139.73771988516083 9.24 35.67407068249126 139.73771988516083 30.85 35.674083308110944 139.7377620135277 30.85 35.67407068249126 139.73771988516083 9.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-646990a4-b724-41a7-982f-8d30ae956142">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-646990a4-b724-41a7-982f-8d30ae956142_0">
											<gml:posList>35.6740380379823 139.737769336267 31.424 35.674029784363775 139.73777305781792 31.424 35.67404148134343 139.73778084289003 31.424 35.6740380379823 139.737769336267 31.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83d61fee-408b-420b-b66e-c1dba754f26d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83d61fee-408b-420b-b66e-c1dba754f26d_0">
											<gml:posList>35.67404148134343 139.73778084289003 31.424 35.6740410633369 139.73781066964995 31.424 35.67404930795163 139.73780695915988 31.424 35.67404148134343 139.73778084289003 31.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2cbf6f9-3fc2-4e07-9ef9-d531b7774436">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2cbf6f9-3fc2-4e07-9ef9-d531b7774436_0">
											<gml:posList>35.67404148134343 139.73778084289003 31.424 35.674029784363775 139.73777305781792 31.424 35.6740410633369 139.73781066964995 31.424 35.67404148134343 139.73778084289003 31.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4776e6dd-2887-4af8-b638-5f527d01aeda">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67407029694259 139.73776787277916 9.24 35.67404817433243 139.7377301192164 9.24 35.67407068249126 139.73771988516083 9.24 35.67407029694259 139.73776787277916 9.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de9107e2-20d3-4077-99cb-7609a606c728">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67407068249126 139.73771988516083 9.24 35.674083308110944 139.7377620135277 9.24 35.67407029694259 139.73776787277916 9.24 35.67407068249126 139.73771988516083 9.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ac652ab-ce05-4ec4-ba6d-2c0b61c65800">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6740608809668 139.73777211491532 9.24 35.67404817433243 139.7377301192164 9.24 35.67407029694259 139.73776787277916 9.24 35.6740608809668 139.73777211491532 9.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-926d23fa-36ca-4876-a745-3333e4027531">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67404148134343 139.73778084289003 30.671 35.6740410633369 139.73781066964995 30.671 35.674029784363775 139.73777305781792 30.671 35.67404148134343 139.73778084289003 30.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1e7252c-5185-4168-ab30-bfc44f67fe74">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674029784363775 139.73777305781792 30.671 35.6740380379823 139.737769336267 30.671 35.67404148134343 139.73778084289003 30.671 35.674029784363775 139.73777305781792 30.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30b72319-61fc-4cca-a358-28424618b67d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67404930795163 139.73780695915988 30.671 35.6740410633369 139.73781066964995 30.671 35.67404148134343 139.73778084289003 30.671 35.67404930795163 139.73780695915988 30.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c72fc560-fa72-4672-95e9-ec04bc5c4dc4_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ecfded7-bc9b-4c04-9c9e-61a7590a4179">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67402724626895 139.73780053413967 30.671 35.6740112615975 139.73780768939486 30.671 35.674004709219545 139.73778572519979 30.671 35.67402069388969 139.7377785699408 30.671 35.67402724626895 139.73780053413967 30.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58e147c7-3390-4373-83c6-c0ece7aa2c8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58e147c7-3390-4373-83c6-c0ece7aa2c8c_0">
											<gml:posList>35.674004709219545 139.73778572519979 33.695 35.674004709219545 139.73778572519979 30.671 35.6740112615975 139.73780768939486 30.671 35.6740112615975 139.73780768939486 33.695 35.674004709219545 139.73778572519979 33.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ffa4327-c4f4-4c02-9cc4-feedab099a4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ffa4327-c4f4-4c02-9cc4-feedab099a4a_0">
											<gml:posList>35.67402069388969 139.7377785699408 30.671 35.674004709219545 139.73778572519979 30.671 35.674004709219545 139.73778572519979 33.695 35.67402069388969 139.7377785699408 33.695 35.67402069388969 139.7377785699408 30.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c94a5511-bce5-497b-88ea-480e2ba0a2b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c94a5511-bce5-497b-88ea-480e2ba0a2b9_0">
											<gml:posList>35.674004709219545 139.73778572519979 33.695 35.6740112615975 139.73780768939486 33.695 35.67402724626895 139.73780053413967 33.695 35.67402069388969 139.7377785699408 33.695 35.674004709219545 139.73778572519979 33.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b393021-86c2-4476-baaf-2005fac018a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b393021-86c2-4476-baaf-2005fac018a1_0">
											<gml:posList>35.6740112615975 139.73780768939486 33.695 35.6740112615975 139.73780768939486 30.671 35.67402724626895 139.73780053413967 30.671 35.67402724626895 139.73780053413967 33.695 35.6740112615975 139.73780768939486 33.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78f78330-8979-406d-ab40-e539a3a4162c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78f78330-8979-406d-ab40-e539a3a4162c_0">
											<gml:posList>35.67402724626895 139.73780053413967 33.695 35.67402724626895 139.73780053413967 30.671 35.67402069388969 139.7377785699408 30.671 35.67402069388969 139.7377785699408 33.695 35.67402724626895 139.73780053413967 33.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-04ec6bee-fd0b-479f-92a7-54b590817af0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04ec6bee-fd0b-479f-92a7-54b590817af0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04ec6bee-fd0b-479f-92a7-54b590817af0">
											<gml:posList>35.67406087195308 139.73777211492603 8.97 35.674083308110944 139.7377620135277 8.97 35.67411776867692 139.73787702459805 8.97 35.674035143191894 139.73791534478138 8.97 35.67398805644202 139.7377574322112 8.97 35.67404816531871 139.73773011922717 8.97 35.67406087195308 139.73777211492603 8.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-516ed131-d40d-4558-9ed5-0f0ca65ea39f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-516ed131-d40d-4558-9ed5-0f0ca65ea39f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-516ed131-d40d-4558-9ed5-0f0ca65ea39f">
											<gml:posList>35.67398805644202 139.7377574322112 30.85 35.67399181687168 139.73775958184552 30.85 35.67404642935518 139.7377347609384 30.85 35.67404816531871 139.73773011922717 30.85 35.67398805644202 139.7377574322112 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7308c97f-815e-4136-bf51-c38af1ab0d1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7308c97f-815e-4136-bf51-c38af1ab0d1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7308c97f-815e-4136-bf51-c38af1ab0d1c">
											<gml:posList>35.67404642935518 139.7377347609384 30.85 35.67405809671909 139.73777336651875 30.85 35.67406087195308 139.73777211492603 30.85 35.67404816531871 139.73773011922717 30.85 35.67404642935518 139.7377347609384 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68582a37-abd4-440a-97e1-9fefe62e4eb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68582a37-abd4-440a-97e1-9fefe62e4eb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68582a37-abd4-440a-97e1-9fefe62e4eb3">
											<gml:posList>35.674073588825344 139.7377702328633 30.85 35.67408155411 139.73776664421504 30.85 35.674083308110944 139.7377620135277 30.85 35.674069828395915 139.73776808322629 30.85 35.674070840614995 139.73777146233056 30.85 35.674073588825344 139.7377702328633 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a07b43d-ebd7-4d5f-b69f-f2730014f9e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a07b43d-ebd7-4d5f-b69f-f2730014f9e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a07b43d-ebd7-4d5f-b69f-f2730014f9e0">
											<gml:posList>35.67404148134343 139.73778084289003 36.142 35.67404490809857 139.73778278303607 36.142 35.67406823630848 139.73777229394256 36.142 35.674069828395915 139.73776808322629 36.142 35.67404148134343 139.73778084289003 36.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0197c735-5020-4c19-be15-af83f8a27288">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0197c735-5020-4c19-be15-af83f8a27288">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0197c735-5020-4c19-be15-af83f8a27288">
											<gml:posList>35.674083308110944 139.7377620135277 30.85 35.67408155411 139.73776664421504 30.85 35.67409519194001 139.7378121627476 30.85 35.6740989703873 139.73781430131913 30.85 35.674083308110944 139.7377620135277 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f84b019-d1c8-4de1-9343-438ea4c2f3b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f84b019-d1c8-4de1-9343-438ea4c2f3b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f84b019-d1c8-4de1-9343-438ea4c2f3b6">
											<gml:posList>35.674069828395915 139.73776808322629 36.142 35.67406823630848 139.73777229394256 36.142 35.6740785754014 139.73780681381714 36.142 35.674082011178584 139.73780876500123 36.142 35.674069828395915 139.73776808322629 36.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-253e7c0a-8476-43a0-adbb-7985580664f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-253e7c0a-8476-43a0-adbb-7985580664f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-253e7c0a-8476-43a0-adbb-7985580664f2">
											<gml:posList>35.67404148134343 139.73778084289003 30.671 35.67405809671909 139.73777336651875 30.671 35.67404642935518 139.7377347609384 30.671 35.67399181687168 139.73775958184552 30.671 35.67401762871507 139.73784610244041 30.671 35.67409519194001 139.7378121627476 30.671 35.67408155411 139.73776664421504 30.671 35.674073588825344 139.7377702328633 30.671 35.674070840614995 139.73777146233056 30.671 35.674082011178584 139.73780876500123 30.671 35.67405367313553 139.7378215246418 30.671 35.67404148134343 139.73778084289003 30.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee9f6e6c-db64-49e3-b47e-7471ff82828d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee9f6e6c-db64-49e3-b47e-7471ff82828d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee9f6e6c-db64-49e3-b47e-7471ff82828d">
											<gml:posList>35.6740785754014 139.73780681381714 35.799 35.67406823630848 139.73777229394256 35.799 35.67404490809857 139.73778278303607 35.799 35.67405525621975 139.73781732498477 35.799 35.6740785754014 139.73780681381714 35.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0801f484-33a3-43e5-a6b9-76abe4e38153">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0801f484-33a3-43e5-a6b9-76abe4e38153">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0801f484-33a3-43e5-a6b9-76abe4e38153">
											<gml:posList>35.67405367313553 139.7378215246418 36.142 35.67405525621975 139.73781732498477 36.142 35.67404490809857 139.73778278303607 36.142 35.67404148134343 139.73778084289003 36.142 35.67405367313553 139.7378215246418 36.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8092f636-9869-48b4-a405-3a2660da2e17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8092f636-9869-48b4-a405-3a2660da2e17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8092f636-9869-48b4-a405-3a2660da2e17">
											<gml:posList>35.674015865662106 139.73785068894585 30.85 35.67401762871507 139.73784610244041 30.85 35.67399181687168 139.73775958184552 30.85 35.67398805644202 139.7377574322112 30.85 35.674015865662106 139.73785068894585 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4217e00a-786a-44e9-a83d-a2a9e04806e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4217e00a-786a-44e9-a83d-a2a9e04806e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4217e00a-786a-44e9-a83d-a2a9e04806e1">
											<gml:posList>35.674082011178584 139.73780876500123 36.142 35.6740785754014 139.73780681381714 36.142 35.67405525621975 139.73781732498477 36.142 35.67405367313553 139.7378215246418 36.142 35.674082011178584 139.73780876500123 36.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-56e21a5a-b588-4074-941a-43cb0b038b83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56e21a5a-b588-4074-941a-43cb0b038b83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56e21a5a-b588-4074-941a-43cb0b038b83">
											<gml:posList>35.674015865662106 139.73785068894585 30.85 35.6740989703873 139.73781430131913 30.85 35.67409519194001 139.7378121627476 30.85 35.67401762871507 139.73784610244041 30.85 35.674015865662106 139.73785068894585 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74353540-0d18-4941-a0e9-0d2c8c924194">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74353540-0d18-4941-a0e9-0d2c8c924194">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74353540-0d18-4941-a0e9-0d2c8c924194">
											<gml:posList>35.67411776867692 139.73787702459805 22.198 35.6740989703873 139.73781430131913 30.85 35.674015865662106 139.73785068894585 30.85 35.67411776867692 139.73787702459805 22.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8fae01c3-3e37-4700-ae19-134f3d0fc78c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fae01c3-3e37-4700-ae19-134f3d0fc78c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fae01c3-3e37-4700-ae19-134f3d0fc78c">
											<gml:posList>35.67411776867692 139.73787702459805 22.198 35.674015865662106 139.73785068894585 30.85 35.674035143191894 139.73791534478138 22.198 35.67411776867692 139.73787702459805 22.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bd2b8d1-874a-4b75-b86f-76f2f7a2762b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bd2b8d1-874a-4b75-b86f-76f2f7a2762b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bd2b8d1-874a-4b75-b86f-76f2f7a2762b">
											<gml:posList>35.67404816531871 139.73773011922717 8.97 35.67398805644202 139.7377574322112 8.97 35.67398805644202 139.7377574322112 30.85 35.67404816531871 139.73773011922717 30.85 35.67404816531871 139.73773011922717 8.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1515b0ce-51ba-4895-824c-2488f5d95d30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1515b0ce-51ba-4895-824c-2488f5d95d30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1515b0ce-51ba-4895-824c-2488f5d95d30">
											<gml:posList>35.67399181687168 139.73775958184552 30.85 35.67399181687168 139.73775958184552 30.671 35.67404642935518 139.7377347609384 30.671 35.67404642935518 139.7377347609384 30.85 35.67399181687168 139.73775958184552 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4031fc6c-2dc9-447f-b7eb-d608542597e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4031fc6c-2dc9-447f-b7eb-d608542597e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4031fc6c-2dc9-447f-b7eb-d608542597e0">
											<gml:posList>35.67406087195308 139.73777211492603 8.97 35.67404816531871 139.73773011922717 8.97 35.67404816531871 139.73773011922717 30.85 35.67406087195308 139.73777211492603 30.85 35.67406087195308 139.73777211492603 8.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58c1e286-9ed5-4171-b219-bd2e46d670b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58c1e286-9ed5-4171-b219-bd2e46d670b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58c1e286-9ed5-4171-b219-bd2e46d670b8">
											<gml:posList>35.67404642935518 139.7377347609384 30.85 35.67404642935518 139.7377347609384 30.671 35.67405809671909 139.73777336651875 30.671 35.67405809671909 139.73777336651875 30.85 35.67404642935518 139.7377347609384 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d01a96a5-5bdd-4928-9a75-d0af98ea55dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d01a96a5-5bdd-4928-9a75-d0af98ea55dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d01a96a5-5bdd-4928-9a75-d0af98ea55dd">
											<gml:posList>35.674073588825344 139.7377702328633 30.85 35.674073588825344 139.7377702328633 30.671 35.67408155411 139.73776664421504 30.671 35.67408155411 139.73776664421504 30.85 35.674073588825344 139.7377702328633 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-267070ec-a034-4379-8e6e-6d63ce34a991">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-267070ec-a034-4379-8e6e-6d63ce34a991">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-267070ec-a034-4379-8e6e-6d63ce34a991">
											<gml:posList>35.674070840614995 139.73777146233056 30.85 35.674070840614995 139.73777146233056 30.671 35.674073588825344 139.7377702328633 30.671 35.674073588825344 139.7377702328633 30.85 35.674070840614995 139.73777146233056 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec886f99-ea73-4c1a-8e28-2d1b15c714c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec886f99-ea73-4c1a-8e28-2d1b15c714c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec886f99-ea73-4c1a-8e28-2d1b15c714c9">
											<gml:posList>35.674083308110944 139.7377620135277 8.97 35.67406087195308 139.73777211492603 8.97 35.67406087195308 139.73777211492603 30.85 35.67405809671909 139.73777336651875 30.85 35.67405809671909 139.73777336651875 30.671 35.67404148134343 139.73778084289003 30.671 35.67404148134343 139.73778084289003 36.142 35.674069828395915 139.73776808322629 36.142 35.674069828395915 139.73776808322629 30.85 35.674083308110944 139.7377620135277 30.85 35.674083308110944 139.7377620135277 8.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4be762f4-53b5-48ea-bb3e-f21beb925104">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4be762f4-53b5-48ea-bb3e-f21beb925104">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4be762f4-53b5-48ea-bb3e-f21beb925104">
											<gml:posList>35.67404490809857 139.73778278303607 36.142 35.67404490809857 139.73778278303607 35.799 35.67406823630848 139.73777229394256 35.799 35.67406823630848 139.73777229394256 36.142 35.67404490809857 139.73778278303607 36.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d3aebdd-9d27-4010-a930-b7234213b50d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d3aebdd-9d27-4010-a930-b7234213b50d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d3aebdd-9d27-4010-a930-b7234213b50d">
											<gml:posList>35.674070840614995 139.73777146233056 30.85 35.674069828395915 139.73776808322629 30.85 35.674069828395915 139.73776808322629 36.142 35.674082011178584 139.73780876500123 36.142 35.674082011178584 139.73780876500123 30.671 35.674070840614995 139.73777146233056 30.671 35.674070840614995 139.73777146233056 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5d07afb-82f6-4a45-8acf-6a58fe58e9d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5d07afb-82f6-4a45-8acf-6a58fe58e9d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5d07afb-82f6-4a45-8acf-6a58fe58e9d6">
											<gml:posList>35.67408155411 139.73776664421504 30.85 35.67408155411 139.73776664421504 30.671 35.67409519194001 139.7378121627476 30.671 35.67409519194001 139.7378121627476 30.85 35.67408155411 139.73776664421504 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0d4dbe9-2cb9-45d5-b3fd-49427d4b5587">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0d4dbe9-2cb9-45d5-b3fd-49427d4b5587">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0d4dbe9-2cb9-45d5-b3fd-49427d4b5587">
											<gml:posList>35.67406823630848 139.73777229394256 36.142 35.67406823630848 139.73777229394256 35.799 35.6740785754014 139.73780681381714 35.799 35.6740785754014 139.73780681381714 36.142 35.67406823630848 139.73777229394256 36.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0220224a-c760-4ad9-9ff1-d5a0249116fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0220224a-c760-4ad9-9ff1-d5a0249116fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0220224a-c760-4ad9-9ff1-d5a0249116fd">
											<gml:posList>35.67405525621975 139.73781732498477 36.142 35.67405525621975 139.73781732498477 35.799 35.67404490809857 139.73778278303607 35.799 35.67404490809857 139.73778278303607 36.142 35.67405525621975 139.73781732498477 36.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e5d519b-c008-4198-932e-5ad33ae2deb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e5d519b-c008-4198-932e-5ad33ae2deb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e5d519b-c008-4198-932e-5ad33ae2deb9">
											<gml:posList>35.67404148134343 139.73778084289003 30.671 35.67405367313553 139.7378215246418 30.671 35.67405367313553 139.7378215246418 36.142 35.67404148134343 139.73778084289003 36.142 35.67404148134343 139.73778084289003 30.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23f05bad-e152-49c4-bd79-7295da2d5cdd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23f05bad-e152-49c4-bd79-7295da2d5cdd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23f05bad-e152-49c4-bd79-7295da2d5cdd">
											<gml:posList>35.67401762871507 139.73784610244041 30.85 35.67401762871507 139.73784610244041 30.671 35.67399181687168 139.73775958184552 30.671 35.67399181687168 139.73775958184552 30.85 35.67401762871507 139.73784610244041 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbce03d2-0ea1-4757-b8db-5ee6ba8be1cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbce03d2-0ea1-4757-b8db-5ee6ba8be1cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbce03d2-0ea1-4757-b8db-5ee6ba8be1cf">
											<gml:posList>35.6740785754014 139.73780681381714 36.142 35.6740785754014 139.73780681381714 35.799 35.67405525621975 139.73781732498477 35.799 35.67405525621975 139.73781732498477 36.142 35.6740785754014 139.73780681381714 36.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74263990-a484-4a45-a33c-70ce33d9d6bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74263990-a484-4a45-a33c-70ce33d9d6bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74263990-a484-4a45-a33c-70ce33d9d6bb">
											<gml:posList>35.67405367313553 139.7378215246418 30.671 35.674082011178584 139.73780876500123 30.671 35.674082011178584 139.73780876500123 36.142 35.67405367313553 139.7378215246418 36.142 35.67405367313553 139.7378215246418 30.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2ba7429-4cd7-490f-bdb0-bd6f849b3823">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2ba7429-4cd7-490f-bdb0-bd6f849b3823">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2ba7429-4cd7-490f-bdb0-bd6f849b3823">
											<gml:posList>35.67411776867692 139.73787702459805 22.198 35.67411776867692 139.73787702459805 8.97 35.674083308110944 139.7377620135277 8.97 35.674083308110944 139.7377620135277 30.85 35.6740989703873 139.73781430131913 30.85 35.67411776867692 139.73787702459805 22.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62a1862f-b66c-4255-a6ba-79da1af02331">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62a1862f-b66c-4255-a6ba-79da1af02331">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62a1862f-b66c-4255-a6ba-79da1af02331">
											<gml:posList>35.67401762871507 139.73784610244041 30.671 35.67401762871507 139.73784610244041 30.85 35.67409519194001 139.7378121627476 30.85 35.67409519194001 139.7378121627476 30.671 35.67401762871507 139.73784610244041 30.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1c4cdda-fc6c-4613-9051-06998fea1bbf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1c4cdda-fc6c-4613-9051-06998fea1bbf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1c4cdda-fc6c-4613-9051-06998fea1bbf">
											<gml:posList>35.67398805644202 139.7377574322112 30.85 35.67398805644202 139.7377574322112 8.97 35.674035143191894 139.73791534478138 8.97 35.674035143191894 139.73791534478138 22.198 35.674015865662106 139.73785068894585 30.85 35.67398805644202 139.7377574322112 30.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f02b56a-0a9c-4748-88b6-3f3bbeefe5d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f02b56a-0a9c-4748-88b6-3f3bbeefe5d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f02b56a-0a9c-4748-88b6-3f3bbeefe5d3">
											<gml:posList>35.67411776867692 139.73787702459805 22.198 35.674035143191894 139.73791534478138 22.198 35.674035143191894 139.73791534478138 8.97 35.67411776867692 139.73787702459805 22.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2e9efa7-1d07-492b-be8b-d0d48724212d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2e9efa7-1d07-492b-be8b-d0d48724212d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2e9efa7-1d07-492b-be8b-d0d48724212d">
											<gml:posList>35.67411776867692 139.73787702459805 22.198 35.674035143191894 139.73791534478138 8.97 35.67411776867692 139.73787702459805 8.97 35.67411776867692 139.73787702459805 22.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6372</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">148.6545</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>