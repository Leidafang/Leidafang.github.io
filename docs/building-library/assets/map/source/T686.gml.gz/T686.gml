<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c7458327-ea89-45b6-a1df-901ea54f2d76">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">21.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67330701818836 139.7379200777446 0 35.673283251512686 139.7378436631491 0 35.673134400503365 139.73791398660126 0 35.67318464377608 139.73807432409458 0 35.67333611034308 139.7380058757189 0 35.673309721340786 139.7379188593945 0 35.67330701818836 139.7379200777446 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67330701818836 139.7379200777446 8.6 35.673309721340786 139.7379188593945 8.6 35.67333611034308 139.7380058757189 8.6 35.67318464377608 139.73807432409458 8.6 35.673134400503365 139.73791398660126 8.6 35.673283251512686 139.7378436631491 8.6 35.67330701818836 139.7379200777446 8.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67330701818836 139.7379200777446 8.6 35.673283251512686 139.7378436631491 8.6 35.673283251512686 139.7378436631491 30.270000000000003 35.67330701818836 139.7379200777446 30.270000000000003 35.67330701818836 139.7379200777446 8.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673283251512686 139.7378436631491 8.6 35.673134400503365 139.73791398660126 8.6 35.673134400503365 139.73791398660126 30.270000000000003 35.673283251512686 139.7378436631491 30.270000000000003 35.673283251512686 139.7378436631491 8.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673134400503365 139.73791398660126 8.6 35.67318464377608 139.73807432409458 8.6 35.67318464377608 139.73807432409458 30.270000000000003 35.673134400503365 139.73791398660126 30.270000000000003 35.673134400503365 139.73791398660126 8.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67318464377608 139.73807432409458 8.6 35.67333611034308 139.7380058757189 8.6 35.67333611034308 139.7380058757189 30.270000000000003 35.67318464377608 139.73807432409458 30.270000000000003 35.67318464377608 139.73807432409458 8.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67333611034308 139.7380058757189 8.6 35.673309721340786 139.7379188593945 8.6 35.673309721340786 139.7379188593945 30.270000000000003 35.67333611034308 139.7380058757189 30.270000000000003 35.67333611034308 139.7380058757189 8.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673309721340786 139.7379188593945 8.6 35.67330701818836 139.7379200777446 8.6 35.67330701818836 139.7379200777446 30.270000000000003 35.673309721340786 139.7379188593945 30.270000000000003 35.673309721340786 139.7379188593945 8.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67330701818836 139.7379200777446 30.270000000000003 35.673283251512686 139.7378436631491 30.270000000000003 35.673134400503365 139.73791398660126 30.270000000000003 35.67318464377608 139.73807432409458 30.270000000000003 35.67333611034308 139.7380058757189 30.270000000000003 35.673309721340786 139.7379188593945 30.270000000000003 35.67330701818836 139.7379200777446 30.270000000000003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f2b992f0-3cc9-4e26-944e-31d59f211aaf"/>
							<gml:surfaceMember xlink:href="#poly-f496feab-3779-4a4b-be7a-3c27ce2c68c2"/>
							<gml:surfaceMember xlink:href="#poly-af3aae11-7daa-4251-ba38-ab82de9677f8"/>
							<gml:surfaceMember xlink:href="#poly-b9b81c15-e0e8-4717-a487-6abd955841d9"/>
							<gml:surfaceMember xlink:href="#poly-65ba4068-51f8-49cb-b1c1-e144beff12e7"/>
							<gml:surfaceMember xlink:href="#poly-8dea85b8-5e35-4225-b5ac-0cab5f25f090"/>
							<gml:surfaceMember xlink:href="#poly-cf377fbf-d071-4ff1-8ef1-45d98d0dbc2d"/>
							<gml:surfaceMember xlink:href="#poly-c2ef5ba2-fe29-472b-b7f0-94a3a445030c"/>
							<gml:surfaceMember xlink:href="#poly-f2ae362d-fb44-4c6a-927b-e036a8555944"/>
							<gml:surfaceMember xlink:href="#poly-3d8e8e3c-7857-4a8b-8704-9a10bacdeb88"/>
							<gml:surfaceMember xlink:href="#poly-6747eea5-39d1-4596-be5b-aef67cc6425c"/>
							<gml:surfaceMember xlink:href="#poly-98a1c5bd-71ea-4488-a39b-c28a1be5dac0"/>
							<gml:surfaceMember xlink:href="#poly-75dcecf7-4010-4fb0-83d8-96e40807cd85"/>
							<gml:surfaceMember xlink:href="#poly-705de9c9-25d5-4502-971a-bca293a63d5a"/>
							<gml:surfaceMember xlink:href="#poly-a8e65d11-cfdc-423a-ae38-c465d63147ce"/>
							<gml:surfaceMember xlink:href="#poly-434f858d-7e15-4f22-aff4-41c84b87e25a"/>
							<gml:surfaceMember xlink:href="#poly-d5d04d7d-6c45-4960-9ced-859abedebc1d"/>
							<gml:surfaceMember xlink:href="#poly-ed39150f-2f8d-46f9-8211-22e73d356b11"/>
							<gml:surfaceMember xlink:href="#poly-61dc6662-4d89-4df9-b7e9-c8479f67ed1c"/>
							<gml:surfaceMember xlink:href="#poly-e07d0650-b010-4306-b9d3-7a8de167c65b"/>
							<gml:surfaceMember xlink:href="#poly-4a42eda4-cce2-4fc2-bcd7-7bfb8f8a1bb9"/>
							<gml:surfaceMember xlink:href="#poly-534761d7-7e73-44f5-ba93-ff271e250fe7"/>
							<gml:surfaceMember xlink:href="#poly-e5d5a1b9-1daf-4acf-85a8-72c2157a1853"/>
							<gml:surfaceMember xlink:href="#poly-ee766b4b-5133-435b-b1e3-a1ca1a3f6219"/>
							<gml:surfaceMember xlink:href="#poly-372fe568-6558-411a-a17e-db7de540b8d7"/>
							<gml:surfaceMember xlink:href="#poly-d3e06c8e-2835-487a-964d-239192e02197"/>
							<gml:surfaceMember xlink:href="#poly-7d53a195-2570-41cd-a0f1-11dbc8f8f1d0"/>
							<gml:surfaceMember xlink:href="#poly-f2fc7e26-b78e-4d89-b846-8ff5aa392588"/>
							<gml:surfaceMember xlink:href="#poly-673b6b2a-13f8-42dc-a474-b69e28eb2deb"/>
							<gml:surfaceMember xlink:href="#poly-e53d62d6-47bd-464d-abec-610ab4ed7044"/>
							<gml:surfaceMember xlink:href="#poly-3ffdfefd-78f2-41c0-b7fb-d386c98f881c"/>
							<gml:surfaceMember xlink:href="#poly-3fbd93ec-9210-40ad-9bb7-8799dd669038"/>
							<gml:surfaceMember xlink:href="#poly-8bdcea09-50e7-43a1-9e45-6e87b2d83af9"/>
							<gml:surfaceMember xlink:href="#poly-7894f888-9603-4b14-82ed-b70aea85b944"/>
							<gml:surfaceMember xlink:href="#poly-2cff18bb-10a5-4558-8e49-7db533e1b8e3"/>
							<gml:surfaceMember xlink:href="#poly-c107e6ba-b224-4e9e-942d-3119d3acd48d"/>
							<gml:surfaceMember xlink:href="#poly-514b0c41-976f-4cff-ac23-af41ff40ca6a"/>
							<gml:surfaceMember xlink:href="#poly-81f52dcc-3c6c-4982-bb8d-e35e52c9ae5c"/>
							<gml:surfaceMember xlink:href="#poly-7f3fadc8-e19e-4261-ae48-4e5855c4e7e3"/>
							<gml:surfaceMember xlink:href="#poly-22cea1a8-e8b7-4167-953a-f91da32f8106"/>
							<gml:surfaceMember xlink:href="#poly-9051e2d1-fc40-415e-acaa-ba81fbc5d8bd"/>
							<gml:surfaceMember xlink:href="#poly-3c92e720-4d29-4d54-b164-b7408e473a38"/>
							<gml:surfaceMember xlink:href="#poly-69040ba5-a7aa-41b9-b4c6-064d77d27806"/>
							<gml:surfaceMember xlink:href="#poly-88813efb-0dc5-4a1f-8c00-b5f0d0e42271"/>
							<gml:surfaceMember xlink:href="#poly-228f8c2f-9522-4bdf-bd4a-f404a43937b6"/>
							<gml:surfaceMember xlink:href="#poly-51bcf722-445b-4dfa-95a6-31797c98b9eb"/>
							<gml:surfaceMember xlink:href="#poly-4ca8cc85-1345-45c6-913f-63fa291a9a02"/>
							<gml:surfaceMember xlink:href="#poly-85de7a7e-c15b-47f7-884c-038b148ab3c9"/>
							<gml:surfaceMember xlink:href="#poly-5d212a67-531d-42eb-84d1-ec8b4f455b2c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c7458327-ea89-45b6-a1df-901ea54f2d76_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfd3a549-e6e3-4e29-9e18-d9b2ce98d32c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673246486616286 139.73798279536183 34.834 35.67323501644857 139.73798823291048 34.834 35.673229585548576 139.73797099554602 34.834 35.673241055724255 139.73796556904193 34.834 35.673246486616286 139.73798279536183 34.834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b469c5d0-104f-49ff-b376-26f49cc7caee">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673246486616286 139.73798279536183 35.274 35.673241055724255 139.73796556904193 35.274 35.673243380388506 139.73796446161117 35.274 35.67324881128943 139.73798169897816 35.274 35.673246486616286 139.73798279536183 35.274</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bb3b8cb-1ee4-4c93-8910-0edc364c364b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67323651742034 139.737914505765 34.116 35.67325040256945 139.73790819264548 34.116 35.67325599670566 139.73792666704128 34.116 35.673242111555595 139.73793298015806 34.116 35.67323651742034 139.737914505765 34.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac73f8b8-a9ed-422d-9a97-7134ea277e11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67326951068229 139.73791832177912 34.116 35.67326865279469 139.7379163233552 34.116 35.67326816432941 139.73791414774513 34.116 35.673268045365255 139.7379118943687 34.116 35.67326832302212 139.73790966261348 34.116 35.67326896132397 139.73790755194216 34.116 35.67326995132711 139.7379056507387 34.116 35.67327123901053 139.73790403639393 34.116 35.67327277936694 139.73790278628803 34.116 35.673274491316675 139.73790195575086 34.116 35.67327630278501 139.7379015890548 34.116 35.67327814166221 139.73790168628574 34.116 35.673279926824826 139.73790224754032 34.116 35.673281577131874 139.7379032508218 34.116 35.67328302043858 139.73790465202944 34.116 35.673284193605134 139.73790639600517 34.116 35.67328504247919 139.7379083944401 34.116 35.673285539958286 139.73791057003984 34.116 35.673285649908756 139.7379128234275 34.116 35.673285381265536 139.7379150551725 34.116 35.673284733958596 139.7379171769015 34.116 35.67328374395528 139.7379190781052 34.116 35.673282456271664 139.73792069244996 34.116 35.67328092492003 139.7379219314983 34.116 35.673279212970165 139.73792276203514 34.116 35.6732773924968 139.73792313978808 34.116 35.67327555361962 139.73792304255664 34.116 35.67327376845709 139.73792248130164 34.116 35.673272118141455 139.73792146697323 34.116 35.67327068384866 139.7379200657547 34.116 35.67326951068229 139.73791832177912 34.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c7fbf5a-bf1c-4ae2-bb74-637b48d05874">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c7fbf5a-bf1c-4ae2-bb74-637b48d05874_0">
											<gml:posList>35.67327277936694 139.73790278628803 36.74 35.67327277936694 139.73790278628803 34.116 35.67327123901053 139.73790403639393 34.116 35.67327123901053 139.73790403639393 36.74 35.67327277936694 139.73790278628803 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12a3065d-f514-4324-b715-7ebe56d35314">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12a3065d-f514-4324-b715-7ebe56d35314_0">
											<gml:posList>35.67327277936694 139.73790278628803 36.74 35.673274491316675 139.73790195575086 36.74 35.673274491316675 139.73790195575086 34.116 35.67327277936694 139.73790278628803 34.116 35.67327277936694 139.73790278628803 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2a13a32-54bf-4488-91a1-45aa825a8864">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2a13a32-54bf-4488-91a1-45aa825a8864_0">
											<gml:posList>35.673274491316675 139.73790195575086 36.74 35.67327630278501 139.7379015890548 36.74 35.67327630278501 139.7379015890548 34.116 35.673274491316675 139.73790195575086 34.116 35.673274491316675 139.73790195575086 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b38c741c-fc49-45ad-b469-7a02297a5bc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b38c741c-fc49-45ad-b469-7a02297a5bc2_0">
											<gml:posList>35.67327630278501 139.7379015890548 36.74 35.67327814166221 139.73790168628574 36.74 35.67327814166221 139.73790168628574 34.116 35.67327630278501 139.7379015890548 34.116 35.67327630278501 139.7379015890548 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d53e6fe-2c00-4569-93b4-034574440aa6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d53e6fe-2c00-4569-93b4-034574440aa6_0">
											<gml:posList>35.673279926824826 139.73790224754032 36.74 35.673279926824826 139.73790224754032 34.116 35.67327814166221 139.73790168628574 34.116 35.67327814166221 139.73790168628574 36.74 35.673279926824826 139.73790224754032 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c37f714a-cb6b-47f6-8195-285c3654ea3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c37f714a-cb6b-47f6-8195-285c3654ea3f_0">
											<gml:posList>35.673279926824826 139.73790224754032 36.74 35.673281577131874 139.7379032508218 36.74 35.673281577131874 139.7379032508218 34.116 35.673279926824826 139.73790224754032 34.116 35.673279926824826 139.73790224754032 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2e13ac0-1580-48f9-9489-7dabe1dc6b81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2e13ac0-1580-48f9-9489-7dabe1dc6b81_0">
											<gml:posList>35.673281577131874 139.7379032508218 36.74 35.67328302043858 139.73790465202944 36.74 35.67328302043858 139.73790465202944 34.116 35.673281577131874 139.7379032508218 34.116 35.673281577131874 139.7379032508218 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-921e6d45-455a-4e88-b929-e98849306805">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-921e6d45-455a-4e88-b929-e98849306805_0">
											<gml:posList>35.673229585548576 139.73797099554602 38.906 35.673229585548576 139.73797099554602 34.834 35.67323501644857 139.73798823291048 34.834 35.67323501644857 139.73798823291048 38.906 35.673229585548576 139.73797099554602 38.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b677b0dc-6106-478e-8b76-1827f3f44e85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b677b0dc-6106-478e-8b76-1827f3f44e85_0">
											<gml:posList>35.673241055724255 139.73796556904193 35.274 35.673241055724255 139.73796556904193 34.834 35.673229585548576 139.73797099554602 34.834 35.673229585548576 139.73797099554602 38.906 35.673243380388506 139.73796446161117 38.906 35.673243380388506 139.73796446161117 35.274 35.673241055724255 139.73796556904193 35.274</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-584ae1d7-9e92-49cb-8c6e-c000d3f1b238">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-584ae1d7-9e92-49cb-8c6e-c000d3f1b238_0">
											<gml:posList>35.673243380388506 139.73796446161117 38.906 35.673229585548576 139.73797099554602 38.906 35.67323501644857 139.73798823291048 38.906 35.67324881128943 139.73798169897816 38.906 35.673243380388506 139.73796446161117 38.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-beda1da4-64df-42f5-ac56-d4c35707dbb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-beda1da4-64df-42f5-ac56-d4c35707dbb8_0">
											<gml:posList>35.67323651742034 139.737914505765 37.805 35.67323651742034 139.737914505765 34.116 35.673242111555595 139.73793298015806 34.116 35.673242111555595 139.73793298015806 37.805 35.67323651742034 139.737914505765 37.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a613825b-4594-46d1-a49e-36f320ff2cff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a613825b-4594-46d1-a49e-36f320ff2cff_0">
											<gml:posList>35.673246486616286 139.73798279536183 35.274 35.67324881128943 139.73798169897816 35.274 35.67324881128943 139.73798169897816 38.906 35.67323501644857 139.73798823291048 38.906 35.67323501644857 139.73798823291048 34.834 35.673246486616286 139.73798279536183 34.834 35.673246486616286 139.73798279536183 35.274</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a84c8fe3-876e-4684-a0b9-98acdeaeea8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a84c8fe3-876e-4684-a0b9-98acdeaeea8b_0">
											<gml:posList>35.67323651742034 139.737914505765 37.805 35.67325040256945 139.73790819264548 37.805 35.67325040256945 139.73790819264548 34.116 35.67323651742034 139.737914505765 34.116 35.67323651742034 139.737914505765 37.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba45fedc-16ff-43cd-b48e-d38728ea96bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba45fedc-16ff-43cd-b48e-d38728ea96bf_0">
											<gml:posList>35.673246486616286 139.73798279536183 34.834 35.673241055724255 139.73796556904193 34.834 35.673241055724255 139.73796556904193 35.274 35.673246486616286 139.73798279536183 35.274 35.673246486616286 139.73798279536183 34.834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5eb61ca-d3d6-4395-ac4a-8ce8f289c3e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5eb61ca-d3d6-4395-ac4a-8ce8f289c3e2_0">
											<gml:posList>35.673243380388506 139.73796446161117 38.906 35.67324881128943 139.73798169897816 38.906 35.67324881128943 139.73798169897816 35.274 35.673243380388506 139.73796446161117 35.274 35.673243380388506 139.73796446161117 38.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8fbc124-8c1c-452f-b264-8a9d0c945dca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8fbc124-8c1c-452f-b264-8a9d0c945dca_0">
											<gml:posList>35.67325599670566 139.73792666704128 37.805 35.67325040256945 139.73790819264548 37.805 35.67323651742034 139.737914505765 37.805 35.673242111555595 139.73793298015806 37.805 35.67325599670566 139.73792666704128 37.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-771018da-94b8-4ad0-be32-cca988b65331">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-771018da-94b8-4ad0-be32-cca988b65331_0">
											<gml:posList>35.67325599670566 139.73792666704128 37.805 35.673242111555595 139.73793298015806 37.805 35.673242111555595 139.73793298015806 34.116 35.67325599670566 139.73792666704128 34.116 35.67325599670566 139.73792666704128 37.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e729ca99-24ae-4e0b-a5df-576b63de2710">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e729ca99-24ae-4e0b-a5df-576b63de2710_0">
											<gml:posList>35.67325599670566 139.73792666704128 37.805 35.67325599670566 139.73792666704128 34.116 35.67325040256945 139.73790819264548 34.116 35.67325040256945 139.73790819264548 37.805 35.67325599670566 139.73792666704128 37.805</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47d77d0b-2a07-40e4-b4f2-348260f55649">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47d77d0b-2a07-40e4-b4f2-348260f55649_0">
											<gml:posList>35.67326816432941 139.73791414774513 36.74 35.673268045365255 139.7379118943687 36.74 35.673268045365255 139.7379118943687 34.116 35.67326816432941 139.73791414774513 34.116 35.67326816432941 139.73791414774513 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61cd0105-12e4-4e12-88dc-d1955bbd9d33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61cd0105-12e4-4e12-88dc-d1955bbd9d33_0">
											<gml:posList>35.673268045365255 139.7379118943687 36.74 35.67326832302212 139.73790966261348 36.74 35.67326832302212 139.73790966261348 34.116 35.673268045365255 139.7379118943687 34.116 35.673268045365255 139.7379118943687 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fedc567-d4d4-49ef-ae82-381a534d973f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fedc567-d4d4-49ef-ae82-381a534d973f_0">
											<gml:posList>35.67326816432941 139.73791414774513 36.74 35.67326816432941 139.73791414774513 34.116 35.67326865279469 139.7379163233552 34.116 35.67326865279469 139.7379163233552 36.74 35.67326816432941 139.73791414774513 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8afdddd4-7f84-47ef-abb0-422def1931b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8afdddd4-7f84-47ef-abb0-422def1931b9_0">
											<gml:posList>35.67326832302212 139.73790966261348 36.74 35.67326896132397 139.73790755194216 36.74 35.67326896132397 139.73790755194216 34.116 35.67326832302212 139.73790966261348 34.116 35.67326832302212 139.73790966261348 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4d02366-2d6c-4d8a-94e0-360d686d3933">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4d02366-2d6c-4d8a-94e0-360d686d3933_0">
											<gml:posList>35.67326865279469 139.7379163233552 36.74 35.67326865279469 139.7379163233552 34.116 35.67326951068229 139.73791832177912 34.116 35.67326951068229 139.73791832177912 36.74 35.67326865279469 139.7379163233552 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a15f6230-8b7d-4011-998f-43064103d6ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a15f6230-8b7d-4011-998f-43064103d6ce_0">
											<gml:posList>35.67326896132397 139.73790755194216 36.74 35.67326995132711 139.7379056507387 36.74 35.67326995132711 139.7379056507387 34.116 35.67326896132397 139.73790755194216 34.116 35.67326896132397 139.73790755194216 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf730230-5694-4087-af6e-caffce7fb931">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf730230-5694-4087-af6e-caffce7fb931_0">
											<gml:posList>35.67327068384866 139.7379200657547 36.74 35.67326951068229 139.73791832177912 36.74 35.67326951068229 139.73791832177912 34.116 35.67327068384866 139.7379200657547 34.116 35.67327068384866 139.7379200657547 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8eac705c-5ddc-4391-b249-88b8beceac1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8eac705c-5ddc-4391-b249-88b8beceac1c_0">
											<gml:posList>35.67326995132711 139.7379056507387 36.74 35.67327123901053 139.73790403639393 36.74 35.67327123901053 139.73790403639393 34.116 35.67326995132711 139.7379056507387 34.116 35.67326995132711 139.7379056507387 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e33b0158-39e3-404f-baf9-f3f50d8af963">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e33b0158-39e3-404f-baf9-f3f50d8af963_0">
											<gml:posList>35.673272118141455 139.73792146697323 36.74 35.67327068384866 139.7379200657547 36.74 35.67327068384866 139.7379200657547 34.116 35.673272118141455 139.73792146697323 34.116 35.673272118141455 139.73792146697323 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-156bff45-4366-4511-9e36-677cdb0a31a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-156bff45-4366-4511-9e36-677cdb0a31a7_0">
											<gml:posList>35.67327376845709 139.73792248130164 36.74 35.673272118141455 139.73792146697323 36.74 35.673272118141455 139.73792146697323 34.116 35.67327376845709 139.73792248130164 34.116 35.67327376845709 139.73792248130164 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61ec78fb-425c-42c6-b231-592820d75cc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61ec78fb-425c-42c6-b231-592820d75cc3_0">
											<gml:posList>35.67327555361962 139.73792304255664 36.74 35.67327376845709 139.73792248130164 36.74 35.67327376845709 139.73792248130164 34.116 35.67327555361962 139.73792304255664 34.116 35.67327555361962 139.73792304255664 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-544c8fa3-d633-46d7-b02e-395c8492d156">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-544c8fa3-d633-46d7-b02e-395c8492d156_0">
											<gml:posList>35.6732773924968 139.73792313978808 36.74 35.67327555361962 139.73792304255664 36.74 35.67327555361962 139.73792304255664 34.116 35.6732773924968 139.73792313978808 34.116 35.6732773924968 139.73792313978808 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36d3e8dd-c111-43a9-9217-914aa32bf4e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36d3e8dd-c111-43a9-9217-914aa32bf4e9_0">
											<gml:posList>35.67326816432941 139.73791414774513 36.74 35.67326865279469 139.7379163233552 36.74 35.67326951068229 139.73791832177912 36.74 35.67327068384866 139.7379200657547 36.74 35.673272118141455 139.73792146697323 36.74 35.67327376845709 139.73792248130164 36.74 35.67327555361962 139.73792304255664 36.74 35.6732773924968 139.73792313978808 36.74 35.673279212970165 139.73792276203514 36.74 35.67328092492003 139.7379219314983 36.74 35.673282456271664 139.73792069244996 36.74 35.67328374395528 139.7379190781052 36.74 35.673284733958596 139.7379171769015 36.74 35.673285381265536 139.7379150551725 36.74 35.673285649908756 139.7379128234275 36.74 35.673285539958286 139.73791057003984 36.74 35.67328504247919 139.7379083944401 36.74 35.673284193605134 139.73790639600517 36.74 35.67328302043858 139.73790465202944 36.74 35.673281577131874 139.7379032508218 36.74 35.673279926824826 139.73790224754032 36.74 35.67327814166221 139.73790168628574 36.74 35.67327630278501 139.7379015890548 36.74 35.673274491316675 139.73790195575086 36.74 35.67327277936694 139.73790278628803 36.74 35.67327123901053 139.73790403639393 36.74 35.67326995132711 139.7379056507387 36.74 35.67326896132397 139.73790755194216 36.74 35.67326832302212 139.73790966261348 36.74 35.673268045365255 139.7379118943687 36.74 35.67326816432941 139.73791414774513 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a7d82a7-c3f6-4e6f-b9f8-1b1f6f5ae5bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a7d82a7-c3f6-4e6f-b9f8-1b1f6f5ae5bc_0">
											<gml:posList>35.673279212970165 139.73792276203514 36.74 35.6732773924968 139.73792313978808 36.74 35.6732773924968 139.73792313978808 34.116 35.673279212970165 139.73792276203514 34.116 35.673279212970165 139.73792276203514 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9dd66028-4dec-447c-808a-6733d77a5c67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9dd66028-4dec-447c-808a-6733d77a5c67_0">
											<gml:posList>35.67328092492003 139.7379219314983 36.74 35.673279212970165 139.73792276203514 36.74 35.673279212970165 139.73792276203514 34.116 35.67328092492003 139.7379219314983 34.116 35.67328092492003 139.7379219314983 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e347ed1-c6b4-4435-ae7c-d8b9b88d6089">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e347ed1-c6b4-4435-ae7c-d8b9b88d6089_0">
											<gml:posList>35.673282456271664 139.73792069244996 36.74 35.67328092492003 139.7379219314983 36.74 35.67328092492003 139.7379219314983 34.116 35.673282456271664 139.73792069244996 34.116 35.673282456271664 139.73792069244996 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ca120a8-2b35-4023-9fd9-8cf4fc3ab28f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ca120a8-2b35-4023-9fd9-8cf4fc3ab28f_0">
											<gml:posList>35.67328374395528 139.7379190781052 36.74 35.673282456271664 139.73792069244996 36.74 35.673282456271664 139.73792069244996 34.116 35.67328374395528 139.7379190781052 34.116 35.67328374395528 139.7379190781052 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff5727ed-4816-4cce-a68a-10a7b74233e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff5727ed-4816-4cce-a68a-10a7b74233e7_0">
											<gml:posList>35.67328302043858 139.73790465202944 36.74 35.673284193605134 139.73790639600517 36.74 35.673284193605134 139.73790639600517 34.116 35.67328302043858 139.73790465202944 34.116 35.67328302043858 139.73790465202944 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3252d4b-89de-4abb-9de3-2815a8d66572">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3252d4b-89de-4abb-9de3-2815a8d66572_0">
											<gml:posList>35.673284733958596 139.7379171769015 36.74 35.67328374395528 139.7379190781052 36.74 35.67328374395528 139.7379190781052 34.116 35.673284733958596 139.7379171769015 34.116 35.673284733958596 139.7379171769015 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3efaa2cf-627f-4ab8-ae1e-9053a92d0401">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3efaa2cf-627f-4ab8-ae1e-9053a92d0401_0">
											<gml:posList>35.673284193605134 139.73790639600517 36.74 35.67328504247919 139.7379083944401 36.74 35.67328504247919 139.7379083944401 34.116 35.673284193605134 139.73790639600517 34.116 35.673284193605134 139.73790639600517 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-752693f9-e30d-49f7-8b65-4ed6bf0ef348">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-752693f9-e30d-49f7-8b65-4ed6bf0ef348_0">
											<gml:posList>35.673285381265536 139.7379150551725 36.74 35.673284733958596 139.7379171769015 36.74 35.673284733958596 139.7379171769015 34.116 35.673285381265536 139.7379150551725 34.116 35.673285381265536 139.7379150551725 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8ebcdd8-21f5-4b41-ada5-fdc4b4478ede">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8ebcdd8-21f5-4b41-ada5-fdc4b4478ede_0">
											<gml:posList>35.673285539958286 139.73791057003984 36.74 35.673285539958286 139.73791057003984 34.116 35.67328504247919 139.7379083944401 34.116 35.67328504247919 139.7379083944401 36.74 35.673285539958286 139.73791057003984 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b8dfc48-dc5d-472b-9ead-341c75166e23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b8dfc48-dc5d-472b-9ead-341c75166e23_0">
											<gml:posList>35.673285649908756 139.7379128234275 36.74 35.673285381265536 139.7379150551725 36.74 35.673285381265536 139.7379150551725 34.116 35.673285649908756 139.7379128234275 34.116 35.673285649908756 139.7379128234275 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf697096-2841-4205-ab53-8c6f35e03f0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf697096-2841-4205-ab53-8c6f35e03f0d_0">
											<gml:posList>35.673285539958286 139.73791057003984 36.74 35.673285649908756 139.7379128234275 36.74 35.673285649908756 139.7379128234275 34.116 35.673285539958286 139.73791057003984 34.116 35.673285539958286 139.73791057003984 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c7458327-ea89-45b6-a1df-901ea54f2d76_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-800b37a3-598c-49c3-afd2-82a1d867fdc3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67318187579037 139.73791397428164 29.795 35.67320393344004 139.73790393976478 29.795 35.6732125731561 139.7379324519293 29.795 35.673190506490364 139.73794248645015 29.795 35.67318187579037 139.73791397428164 29.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-232b8306-cedd-4cd2-8b59-72a9590acb0b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67321670727108 139.7380536508537 29.168 35.673206848274745 139.73802203601585 29.168 35.673300781542665 139.73797804700055 29.168 35.67331105624837 139.7380110090686 29.168 35.67321670727108 139.7380536508537 29.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8416840a-2490-45d9-ba29-a88517086baf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67331105624837 139.7380110090686 29.861 35.673311535208455 139.73801256607862 29.861 35.67321761093302 139.73805654400206 29.861 35.67321670727108 139.7380536508537 29.861 35.67331105624837 139.7380110090686 29.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-055d81c7-51a4-4598-a25b-801306f432ba">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67328945713227 139.7379399053064 29.168 35.67330032828478 139.73797479982116 29.168 35.67325965540889 139.73799384844855 29.168 35.673248775248126 139.73795895395958 29.168 35.67328945713227 139.7379399053064 29.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de0639bb-d7bc-4c90-8ee5-a86b104bb25e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de0639bb-d7bc-4c90-8ee5-a86b104bb25e_0">
											<gml:posList>35.67325965540889 139.73799384844855 31.747 35.67325965540889 139.73799384844855 29.168 35.67330032828478 139.73797479982116 29.168 35.67330032828478 139.73797479982116 31.747 35.67325965540889 139.73799384844855 31.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-224c8f9d-cc58-494b-be03-0a0186212348">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-224c8f9d-cc58-494b-be03-0a0186212348_0">
											<gml:posList>35.67318187579037 139.73791397428164 33.42 35.67318187579037 139.73791397428164 29.795 35.673190506490364 139.73794248645015 29.795 35.673190506490364 139.73794248645015 33.42 35.67318187579037 139.73791397428164 33.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f0a8463-49fc-4ff0-95d9-26ef5687fad4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f0a8463-49fc-4ff0-95d9-26ef5687fad4_0">
											<gml:posList>35.67318187579037 139.73791397428164 33.42 35.67320393344004 139.73790393976478 33.42 35.67320393344004 139.73790393976478 29.795 35.67318187579037 139.73791397428164 29.795 35.67318187579037 139.73791397428164 33.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f758288-ad57-4344-818a-47f319c256ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f758288-ad57-4344-818a-47f319c256ba_0">
											<gml:posList>35.6732125731561 139.7379324519293 33.42 35.67320393344004 139.73790393976478 33.42 35.67318187579037 139.73791397428164 33.42 35.673190506490364 139.73794248645015 33.42 35.6732125731561 139.7379324519293 33.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56195e67-ea50-47c8-803b-e118d9ea84e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56195e67-ea50-47c8-803b-e118d9ea84e3_0">
											<gml:posList>35.6732125731561 139.7379324519293 33.42 35.673190506490364 139.73794248645015 33.42 35.673190506490364 139.73794248645015 29.795 35.6732125731561 139.7379324519293 29.795 35.6732125731561 139.7379324519293 33.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19276b18-73f5-43ee-acaf-9ad6daeed512">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19276b18-73f5-43ee-acaf-9ad6daeed512_0">
											<gml:posList>35.6732125731561 139.7379324519293 33.42 35.6732125731561 139.7379324519293 29.795 35.67320393344004 139.73790393976478 29.795 35.67320393344004 139.73790393976478 33.42 35.6732125731561 139.7379324519293 33.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71aa25c0-3080-40c2-a5ff-8d76789784f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71aa25c0-3080-40c2-a5ff-8d76789784f4_0">
											<gml:posList>35.67321670727108 139.7380536508537 29.861 35.67321761093302 139.73805654400206 29.861 35.67321761093302 139.73805654400206 32.314 35.67321223411635 139.73803929552574 33.045 35.673206848274745 139.73802203601585 32.314 35.673206848274745 139.73802203601585 29.168 35.67321670727108 139.7380536508537 29.168 35.67321670727108 139.7380536508537 29.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbdebac2-8110-45d9-8e36-25a4ccad92c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbdebac2-8110-45d9-8e36-25a4ccad92c7_0">
											<gml:posList>35.673206848274745 139.73802203601585 32.314 35.673300781542665 139.73797804700055 32.314 35.673300781542665 139.73797804700055 29.168 35.673206848274745 139.73802203601585 29.168 35.673206848274745 139.73802203601585 32.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecd94cc2-4719-4789-86e9-55199ea5b887">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ecd94cc2-4719-4789-86e9-55199ea5b887_0">
											<gml:posList>35.67325965540889 139.73799384844855 31.747 35.673248775248126 139.73795895395958 31.747 35.673248775248126 139.73795895395958 29.168 35.67325965540889 139.73799384844855 29.168 35.67325965540889 139.73799384844855 31.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e406ba81-8822-416c-95a8-af49cb78c338">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e406ba81-8822-416c-95a8-af49cb78c338_0">
											<gml:posList>35.673306158376796 139.7379953065384 33.045 35.673300781542665 139.73797804700055 32.314 35.673206848274745 139.73802203601585 32.314 35.67321223411635 139.73803929552574 33.045 35.673306158376796 139.7379953065384 33.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ab505c5-2846-42c9-9f73-a23994c03252">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ab505c5-2846-42c9-9f73-a23994c03252_0">
											<gml:posList>35.673311535208455 139.73801256607862 32.314 35.673306158376796 139.7379953065384 33.045 35.67321223411635 139.73803929552574 33.045 35.67321761093302 139.73805654400206 32.314 35.673311535208455 139.73801256607862 32.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-345ef919-14a8-4896-8023-e47398486cce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-345ef919-14a8-4896-8023-e47398486cce_0">
											<gml:posList>35.67321670727108 139.7380536508537 29.168 35.67331105624837 139.7380110090686 29.168 35.67331105624837 139.7380110090686 29.861 35.67321670727108 139.7380536508537 29.861 35.67321670727108 139.7380536508537 29.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11357226-8c85-4a08-b7bb-a5faa00da468">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11357226-8c85-4a08-b7bb-a5faa00da468_0">
											<gml:posList>35.67321761093302 139.73805654400206 32.314 35.67321761093302 139.73805654400206 29.861 35.673311535208455 139.73801256607862 29.861 35.673311535208455 139.73801256607862 32.314 35.67321761093302 139.73805654400206 32.314</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3d52d3b-6221-4f8e-a386-fc09fc516ee5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3d52d3b-6221-4f8e-a386-fc09fc516ee5_0">
											<gml:posList>35.673248775248126 139.73795895395958 31.747 35.67328945713227 139.7379399053064 31.747 35.67328945713227 139.7379399053064 29.168 35.673248775248126 139.73795895395958 29.168 35.673248775248126 139.73795895395958 31.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-636a6c1a-889b-4349-8eae-cda0575fcf31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-636a6c1a-889b-4349-8eae-cda0575fcf31_0">
											<gml:posList>35.67325965540889 139.73799384844855 31.747 35.67330032828478 139.73797479982116 31.747 35.67328945713227 139.7379399053064 31.747 35.673248775248126 139.73795895395958 31.747 35.67325965540889 139.73799384844855 31.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5113f5f-c8a7-4a05-982a-eb744cfb59c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5113f5f-c8a7-4a05-982a-eb744cfb59c2_0">
											<gml:posList>35.67330032828478 139.73797479982116 29.168 35.67328945713227 139.7379399053064 29.168 35.67328945713227 139.7379399053064 31.747 35.67330032828478 139.73797479982116 31.747 35.67330032828478 139.73797479982116 29.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64a51374-1026-4c17-a69a-042265f7a2fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64a51374-1026-4c17-a69a-042265f7a2fc_0">
											<gml:posList>35.67331105624837 139.7380110090686 29.861 35.67331105624837 139.7380110090686 29.168 35.673300781542665 139.73797804700055 29.168 35.673300781542665 139.73797804700055 32.314 35.673306158376796 139.7379953065384 33.045 35.673311535208455 139.73801256607862 32.314 35.673311535208455 139.73801256607862 29.861 35.67331105624837 139.7380110090686 29.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f2b992f0-3cc9-4e26-944e-31d59f211aaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2b992f0-3cc9-4e26-944e-31d59f211aaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2b992f0-3cc9-4e26-944e-31d59f211aaf">
											<gml:posList>35.67330701818837 139.7379200777446 8.6 35.67330972134078 139.7379188593945 8.6 35.67333611034306 139.73800587571887 8.6 35.67318464377605 139.73807432409458 8.6 35.67313440050334 139.73791398660126 8.6 35.67328325151268 139.7378436631491 8.6 35.67330701818837 139.7379200777446 8.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f496feab-3779-4a4b-be7a-3c27ce2c68c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f496feab-3779-4a4b-be7a-3c27ce2c68c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f496feab-3779-4a4b-be7a-3c27ce2c68c2">
											<gml:posList>35.67316739229666 139.7379956041203 35.274 35.67316415498998 139.73799386260058 35.274 35.67317297453944 139.738021844308 35.274 35.6731744135951 139.73801787685187 35.274 35.67316739229666 139.7379956041203 35.274</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af3aae11-7daa-4251-ba38-ab82de9677f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af3aae11-7daa-4251-ba38-ab82de9677f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af3aae11-7daa-4251-ba38-ab82de9677f8">
											<gml:posList>35.67323113191993 139.7379545783817 30.366 35.67322964980249 139.73794969752495 30.366 35.67315990867568 139.737981407038 30.366 35.673139865197435 139.73791698478297 30.366 35.67313440050334 139.73791398660126 30.366 35.673157444200484 139.7379880821409 30.366 35.67323113191993 139.7379545783817 30.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9b81c15-e0e8-4717-a487-6abd955841d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9b81c15-e0e8-4717-a487-6abd955841d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9b81c15-e0e8-4717-a487-6abd955841d9">
											<gml:posList>35.67324114839166 139.73795738336153 35.274 35.67316415498998 139.73799386260058 35.274 35.67316739229666 139.7379956041203 35.274 35.673239718342984 139.73796133976467 35.274 35.67324114839166 139.73795738336153 35.274</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65ba4068-51f8-49cb-b1c1-e144beff12e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65ba4068-51f8-49cb-b1c1-e144beff12e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65ba4068-51f8-49cb-b1c1-e144beff12e7">
											<gml:posList>35.673246748670174 139.7379836235492 34.834 35.673239718342984 139.73796133976467 34.834 35.67316739229666 139.7379956041203 34.834 35.6731744135951 139.73801787685187 34.834 35.673246748670174 139.7379836235492 34.834</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8dea85b8-5e35-4225-b5ac-0cab5f25f090">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dea85b8-5e35-4225-b5ac-0cab5f25f090">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dea85b8-5e35-4225-b5ac-0cab5f25f090">
											<gml:posList>35.67313440050334 139.73791398660126 30.366 35.673139865197435 139.73791698478297 30.366 35.67328079611147 139.73785040453564 30.366 35.67328325151268 139.7378436631491 30.366 35.67313440050334 139.73791398660126 30.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf377fbf-d071-4ff1-8ef1-45d98d0dbc2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf377fbf-d071-4ff1-8ef1-45d98d0dbc2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf377fbf-d071-4ff1-8ef1-45d98d0dbc2d">
											<gml:posList>35.67324997697199 139.73798537612768 35.274 35.673246748670174 139.7379836235492 35.274 35.6731744135951 139.73801787685187 35.274 35.67317297453944 139.738021844308 35.274 35.67324997697199 139.73798537612768 35.274</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c2ef5ba2-fe29-472b-b7f0-94a3a445030c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2ef5ba2-fe29-472b-b7f0-94a3a445030c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2ef5ba2-fe29-472b-b7f0-94a3a445030c">
											<gml:posList>35.67315990867568 139.737981407038 29.795 35.67322964980249 139.73794969752495 29.795 35.67321930198976 139.7379154983604 29.795 35.67329088124004 139.73788295807836 29.795 35.67328939912846 139.73787808826594 29.795 35.67328079611147 139.73785040453564 29.795 35.673139865197435 139.73791698478297 29.795 35.67315990867568 139.737981407038 29.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f2ae362d-fb44-4c6a-927b-e036a8555944">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2ae362d-fb44-4c6a-927b-e036a8555944">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2ae362d-fb44-4c6a-927b-e036a8555944">
											<gml:posList>35.67323368640791 139.73794774851143 34.493 35.67322487496215 139.73791864002297 34.493 35.67321930198976 139.7379154983604 34.493 35.67323113191993 139.7379545783817 34.493 35.67323368640791 139.73794774851143 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d8e8e3c-7857-4a8b-8704-9a10bacdeb88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d8e8e3c-7857-4a8b-8704-9a10bacdeb88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d8e8e3c-7857-4a8b-8704-9a10bacdeb88">
											<gml:posList>35.67324114839166 139.73795738336153 35.274 35.673239718342984 139.73796133976467 35.274 35.673246748670174 139.7379836235492 35.274 35.67324997697199 139.73798537612768 35.274 35.67324114839166 139.73795738336153 35.274</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6747eea5-39d1-4596-be5b-aef67cc6425c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6747eea5-39d1-4596-be5b-aef67cc6425c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6747eea5-39d1-4596-be5b-aef67cc6425c">
											<gml:posList>35.67316415498998 139.73799386260058 29.861 35.67316430816196 139.73799378509193 29.861 35.67316357620524 139.73799145512078 29.861 35.673306941992955 139.73792629710624 29.861 35.67333003236871 139.73800243638644 29.861 35.67333611034306 139.73800587571887 29.861 35.67330972134078 139.7379188593945 29.861 35.67330701818837 139.7379200777446 29.861 35.673157444200484 139.7379880821409 29.861 35.67318464377605 139.73807432409458 29.861 35.67318736906827 139.7380669085569 29.861 35.673173136725154 139.73802176678868 29.861 35.67317297453944 139.738021844308 29.861 35.67316415498998 139.73799386260058 29.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98a1c5bd-71ea-4488-a39b-c28a1be5dac0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98a1c5bd-71ea-4488-a39b-c28a1be5dac0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98a1c5bd-71ea-4488-a39b-c28a1be5dac0">
											<gml:posList>35.67324997697199 139.73798537612768 29.168 35.673173136725154 139.73802176678868 29.168 35.67318736906827 139.7380669085569 29.168 35.67333003236871 139.73800243638644 29.168 35.673306941992955 139.73792629710624 29.168 35.67316357620524 139.73799145512078 29.168 35.67316430816196 139.73799378509193 29.168 35.67324114839166 139.73795738336153 29.168 35.67324997697199 139.73798537612768 29.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-75dcecf7-4010-4fb0-83d8-96e40807cd85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75dcecf7-4010-4fb0-83d8-96e40807cd85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75dcecf7-4010-4fb0-83d8-96e40807cd85">
											<gml:posList>35.673292363447736 139.73788794940415 34.493 35.673294899913216 139.73788113059464 34.493 35.67321930198976 139.7379154983604 34.493 35.67322487496215 139.73791864002297 34.493 35.673292363447736 139.73788794940415 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-705de9c9-25d5-4502-971a-bca293a63d5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-705de9c9-25d5-4502-971a-bca293a63d5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-705de9c9-25d5-4502-971a-bca293a63d5a">
											<gml:posList>35.67318464377605 139.73807432409458 29.861 35.67333611034306 139.73800587571887 29.861 35.67333003236871 139.73800243638644 29.861 35.67318736906827 139.7380669085569 29.861 35.67318464377605 139.73807432409458 29.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a8e65d11-cfdc-423a-ae38-c465d63147ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8e65d11-cfdc-423a-ae38-c465d63147ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8e65d11-cfdc-423a-ae38-c465d63147ce">
											<gml:posList>35.67323368640791 139.73794774851143 34.116 35.673301400165 139.73791695822567 34.116 35.673292363447736 139.73788794940415 34.116 35.67322487496215 139.73791864002297 34.116 35.67323368640791 139.73794774851143 34.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-434f858d-7e15-4f22-aff4-41c84b87e25a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-434f858d-7e15-4f22-aff4-41c84b87e25a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-434f858d-7e15-4f22-aff4-41c84b87e25a">
											<gml:posList>35.67323113191993 139.7379545783817 34.493 35.67330701818837 139.7379200777446 34.493 35.673301400165 139.73791695822567 34.493 35.67323368640791 139.73794774851143 34.493 35.67323113191993 139.7379545783817 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5d04d7d-6c45-4960-9ced-859abedebc1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5d04d7d-6c45-4960-9ced-859abedebc1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5d04d7d-6c45-4960-9ced-859abedebc1d">
											<gml:posList>35.67328325151268 139.7378436631491 30.366 35.67328079611147 139.73785040453564 30.366 35.67328939912846 139.73787808826594 30.366 35.67329088124004 139.73788295807836 30.366 35.673294899913216 139.73788113059464 30.366 35.67328325151268 139.7378436631491 30.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed39150f-2f8d-46f9-8211-22e73d356b11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed39150f-2f8d-46f9-8211-22e73d356b11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed39150f-2f8d-46f9-8211-22e73d356b11">
											<gml:posList>35.673292363447736 139.73788794940415 34.493 35.673301400165 139.73791695822567 34.493 35.67330701818837 139.7379200777446 34.493 35.673294899913216 139.73788113059464 34.493 35.673292363447736 139.73788794940415 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61dc6662-4d89-4df9-b7e9-c8479f67ed1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61dc6662-4d89-4df9-b7e9-c8479f67ed1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61dc6662-4d89-4df9-b7e9-c8479f67ed1c">
											<gml:posList>35.67316739229666 139.7379956041203 35.274 35.67316739229666 139.7379956041203 34.834 35.673239718342984 139.73796133976467 34.834 35.673239718342984 139.73796133976467 35.274 35.67316739229666 139.7379956041203 35.274</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e07d0650-b010-4306-b9d3-7a8de167c65b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e07d0650-b010-4306-b9d3-7a8de167c65b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e07d0650-b010-4306-b9d3-7a8de167c65b">
											<gml:posList>35.67328079611147 139.73785040453564 29.795 35.67328079611147 139.73785040453564 30.366 35.673139865197435 139.73791698478297 30.366 35.673139865197435 139.73791698478297 29.795 35.67328079611147 139.73785040453564 29.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a42eda4-cce2-4fc2-bcd7-7bfb8f8a1bb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a42eda4-cce2-4fc2-bcd7-7bfb8f8a1bb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a42eda4-cce2-4fc2-bcd7-7bfb8f8a1bb9">
											<gml:posList>35.673246748670174 139.7379836235492 35.274 35.673246748670174 139.7379836235492 34.834 35.6731744135951 139.73801787685187 34.834 35.6731744135951 139.73801787685187 35.274 35.673246748670174 139.7379836235492 35.274</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-534761d7-7e73-44f5-ba93-ff271e250fe7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-534761d7-7e73-44f5-ba93-ff271e250fe7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-534761d7-7e73-44f5-ba93-ff271e250fe7">
											<gml:posList>35.67322487496215 139.73791864002297 34.493 35.67322487496215 139.73791864002297 34.116 35.673292363447736 139.73788794940415 34.116 35.673292363447736 139.73788794940415 34.493 35.67322487496215 139.73791864002297 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5d5a1b9-1daf-4acf-85a8-72c2157a1853">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5d5a1b9-1daf-4acf-85a8-72c2157a1853">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5d5a1b9-1daf-4acf-85a8-72c2157a1853">
											<gml:posList>35.67323368640791 139.73794774851143 34.116 35.67323368640791 139.73794774851143 34.493 35.673301400165 139.73791695822567 34.493 35.673301400165 139.73791695822567 34.116 35.67323368640791 139.73794774851143 34.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee766b4b-5133-435b-b1e3-a1ca1a3f6219">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee766b4b-5133-435b-b1e3-a1ca1a3f6219">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee766b4b-5133-435b-b1e3-a1ca1a3f6219">
											<gml:posList>35.67333611034306 139.73800587571887 8.6 35.67330972134078 139.7379188593945 8.6 35.67330972134078 139.7379188593945 29.861 35.67333611034306 139.73800587571887 29.861 35.67333611034306 139.73800587571887 8.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-372fe568-6558-411a-a17e-db7de540b8d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-372fe568-6558-411a-a17e-db7de540b8d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-372fe568-6558-411a-a17e-db7de540b8d7">
											<gml:posList>35.67328079611147 139.73785040453564 30.366 35.67328079611147 139.73785040453564 29.795 35.67328939912846 139.73787808826594 29.795 35.67328939912846 139.73787808826594 30.366 35.67328079611147 139.73785040453564 30.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3e06c8e-2835-487a-964d-239192e02197">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3e06c8e-2835-487a-964d-239192e02197">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3e06c8e-2835-487a-964d-239192e02197">
											<gml:posList>35.67313440050334 139.73791398660126 30.366 35.67328325151268 139.7378436631491 30.366 35.67328325151268 139.7378436631491 8.6 35.67313440050334 139.73791398660126 8.6 35.67313440050334 139.73791398660126 30.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d53a195-2570-41cd-a0f1-11dbc8f8f1d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d53a195-2570-41cd-a0f1-11dbc8f8f1d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d53a195-2570-41cd-a0f1-11dbc8f8f1d0">
											<gml:posList>35.67329088124004 139.73788295807836 29.795 35.67329088124004 139.73788295807836 30.366 35.67328939912846 139.73787808826594 30.366 35.67328939912846 139.73787808826594 29.795 35.67329088124004 139.73788295807836 29.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2fc7e26-b78e-4d89-b846-8ff5aa392588">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2fc7e26-b78e-4d89-b846-8ff5aa392588">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2fc7e26-b78e-4d89-b846-8ff5aa392588">
											<gml:posList>35.67330701818837 139.7379200777446 29.861 35.67330701818837 139.7379200777446 8.6 35.67328325151268 139.7378436631491 8.6 35.67328325151268 139.7378436631491 30.366 35.673294899913216 139.73788113059464 30.366 35.673294899913216 139.73788113059464 34.493 35.67330701818837 139.7379200777446 34.493 35.67330701818837 139.7379200777446 29.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-673b6b2a-13f8-42dc-a474-b69e28eb2deb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-673b6b2a-13f8-42dc-a474-b69e28eb2deb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-673b6b2a-13f8-42dc-a474-b69e28eb2deb">
											<gml:posList>35.67321930198976 139.7379154983604 29.795 35.67321930198976 139.7379154983604 34.493 35.673294899913216 139.73788113059464 34.493 35.673294899913216 139.73788113059464 30.366 35.67329088124004 139.73788295807836 30.366 35.67329088124004 139.73788295807836 29.795 35.67321930198976 139.7379154983604 29.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e53d62d6-47bd-464d-abec-610ab4ed7044">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e53d62d6-47bd-464d-abec-610ab4ed7044">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e53d62d6-47bd-464d-abec-610ab4ed7044">
											<gml:posList>35.673292363447736 139.73788794940415 34.493 35.673292363447736 139.73788794940415 34.116 35.673301400165 139.73791695822567 34.116 35.673301400165 139.73791695822567 34.493 35.673292363447736 139.73788794940415 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ffdfefd-78f2-41c0-b7fb-d386c98f881c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ffdfefd-78f2-41c0-b7fb-d386c98f881c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ffdfefd-78f2-41c0-b7fb-d386c98f881c">
											<gml:posList>35.67330701818837 139.7379200777446 29.861 35.67330972134078 139.7379188593945 29.861 35.67330972134078 139.7379188593945 8.6 35.67330701818837 139.7379200777446 8.6 35.67330701818837 139.7379200777446 29.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fbd93ec-9210-40ad-9bb7-8799dd669038">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fbd93ec-9210-40ad-9bb7-8799dd669038">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fbd93ec-9210-40ad-9bb7-8799dd669038">
											<gml:posList>35.67322487496215 139.73791864002297 34.116 35.67322487496215 139.73791864002297 34.493 35.67323368640791 139.73794774851143 34.493 35.67323368640791 139.73794774851143 34.116 35.67322487496215 139.73791864002297 34.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8bdcea09-50e7-43a1-9e45-6e87b2d83af9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bdcea09-50e7-43a1-9e45-6e87b2d83af9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bdcea09-50e7-43a1-9e45-6e87b2d83af9">
											<gml:posList>35.67322964980249 139.73794969752495 30.366 35.67323113191993 139.7379545783817 30.366 35.67323113191993 139.7379545783817 34.493 35.67321930198976 139.7379154983604 34.493 35.67321930198976 139.7379154983604 29.795 35.67322964980249 139.73794969752495 29.795 35.67322964980249 139.73794969752495 30.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7894f888-9603-4b14-82ed-b70aea85b944">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7894f888-9603-4b14-82ed-b70aea85b944">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7894f888-9603-4b14-82ed-b70aea85b944">
											<gml:posList>35.673139865197435 139.73791698478297 29.795 35.673139865197435 139.73791698478297 30.366 35.67315990867568 139.737981407038 30.366 35.67315990867568 139.737981407038 29.795 35.673139865197435 139.73791698478297 29.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2cff18bb-10a5-4558-8e49-7db533e1b8e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cff18bb-10a5-4558-8e49-7db533e1b8e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cff18bb-10a5-4558-8e49-7db533e1b8e3">
											<gml:posList>35.67323113191993 139.7379545783817 30.366 35.673157444200484 139.7379880821409 30.366 35.673157444200484 139.7379880821409 29.861 35.67330701818837 139.7379200777446 29.861 35.67330701818837 139.7379200777446 34.493 35.67323113191993 139.7379545783817 34.493 35.67323113191993 139.7379545783817 30.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c107e6ba-b224-4e9e-942d-3119d3acd48d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c107e6ba-b224-4e9e-942d-3119d3acd48d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c107e6ba-b224-4e9e-942d-3119d3acd48d">
											<gml:posList>35.67316357620524 139.73799145512078 29.861 35.67316357620524 139.73799145512078 29.168 35.673306941992955 139.73792629710624 29.168 35.673306941992955 139.73792629710624 29.861 35.67316357620524 139.73799145512078 29.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-514b0c41-976f-4cff-ac23-af41ff40ca6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-514b0c41-976f-4cff-ac23-af41ff40ca6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-514b0c41-976f-4cff-ac23-af41ff40ca6a">
											<gml:posList>35.67333003236871 139.73800243638644 29.168 35.67333003236871 139.73800243638644 29.861 35.673306941992955 139.73792629710624 29.861 35.673306941992955 139.73792629710624 29.168 35.67333003236871 139.73800243638644 29.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81f52dcc-3c6c-4982-bb8d-e35e52c9ae5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81f52dcc-3c6c-4982-bb8d-e35e52c9ae5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81f52dcc-3c6c-4982-bb8d-e35e52c9ae5c">
											<gml:posList>35.67322964980249 139.73794969752495 30.366 35.67322964980249 139.73794969752495 29.795 35.67315990867568 139.737981407038 29.795 35.67315990867568 139.737981407038 30.366 35.67322964980249 139.73794969752495 30.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f3fadc8-e19e-4261-ae48-4e5855c4e7e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f3fadc8-e19e-4261-ae48-4e5855c4e7e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f3fadc8-e19e-4261-ae48-4e5855c4e7e3">
											<gml:posList>35.67324997697199 139.73798537612768 35.274 35.67324997697199 139.73798537612768 29.168 35.67324114839166 139.73795738336153 29.168 35.67324114839166 139.73795738336153 35.274 35.67324997697199 139.73798537612768 35.274</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22cea1a8-e8b7-4167-953a-f91da32f8106">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22cea1a8-e8b7-4167-953a-f91da32f8106">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22cea1a8-e8b7-4167-953a-f91da32f8106">
											<gml:posList>35.673239718342984 139.73796133976467 35.274 35.673239718342984 139.73796133976467 34.834 35.673246748670174 139.7379836235492 34.834 35.673246748670174 139.7379836235492 35.274 35.673239718342984 139.73796133976467 35.274</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9051e2d1-fc40-415e-acaa-ba81fbc5d8bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9051e2d1-fc40-415e-acaa-ba81fbc5d8bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9051e2d1-fc40-415e-acaa-ba81fbc5d8bd">
											<gml:posList>35.67316430816196 139.73799378509193 29.861 35.67316415498998 139.73799386260058 29.861 35.67316415498998 139.73799386260058 35.274 35.67324114839166 139.73795738336153 35.274 35.67324114839166 139.73795738336153 29.168 35.67316430816196 139.73799378509193 29.168 35.67316430816196 139.73799378509193 29.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c92e720-4d29-4d54-b164-b7408e473a38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c92e720-4d29-4d54-b164-b7408e473a38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c92e720-4d29-4d54-b164-b7408e473a38">
											<gml:posList>35.67316430816196 139.73799378509193 29.168 35.67316357620524 139.73799145512078 29.168 35.67316357620524 139.73799145512078 29.861 35.67316430816196 139.73799378509193 29.861 35.67316430816196 139.73799378509193 29.168</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69040ba5-a7aa-41b9-b4c6-064d77d27806">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69040ba5-a7aa-41b9-b4c6-064d77d27806">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69040ba5-a7aa-41b9-b4c6-064d77d27806">
											<gml:posList>35.67313440050334 139.73791398660126 30.366 35.67313440050334 139.73791398660126 8.6 35.67318464377605 139.73807432409458 8.6 35.67318464377605 139.73807432409458 29.861 35.673157444200484 139.7379880821409 29.861 35.673157444200484 139.7379880821409 30.366 35.67313440050334 139.73791398660126 30.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88813efb-0dc5-4a1f-8c00-b5f0d0e42271">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88813efb-0dc5-4a1f-8c00-b5f0d0e42271">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88813efb-0dc5-4a1f-8c00-b5f0d0e42271">
											<gml:posList>35.673173136725154 139.73802176678868 29.861 35.673173136725154 139.73802176678868 29.168 35.67324997697199 139.73798537612768 29.168 35.67324997697199 139.73798537612768 35.274 35.67317297453944 139.738021844308 35.274 35.67317297453944 139.738021844308 29.861 35.673173136725154 139.73802176678868 29.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-228f8c2f-9522-4bdf-bd4a-f404a43937b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-228f8c2f-9522-4bdf-bd4a-f404a43937b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-228f8c2f-9522-4bdf-bd4a-f404a43937b6">
											<gml:posList>35.6731744135951 139.73801787685187 35.274 35.6731744135951 139.73801787685187 34.834 35.67316739229666 139.7379956041203 34.834 35.67316739229666 139.7379956041203 35.274 35.6731744135951 139.73801787685187 35.274</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51bcf722-445b-4dfa-95a6-31797c98b9eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51bcf722-445b-4dfa-95a6-31797c98b9eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51bcf722-445b-4dfa-95a6-31797c98b9eb">
											<gml:posList>35.67317297453944 139.738021844308 35.274 35.67316415498998 139.73799386260058 35.274 35.67316415498998 139.73799386260058 29.861 35.67317297453944 139.738021844308 29.861 35.67317297453944 139.738021844308 35.274</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ca8cc85-1345-45c6-913f-63fa291a9a02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ca8cc85-1345-45c6-913f-63fa291a9a02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ca8cc85-1345-45c6-913f-63fa291a9a02">
											<gml:posList>35.67333003236871 139.73800243638644 29.861 35.67333003236871 139.73800243638644 29.168 35.67318736906827 139.7380669085569 29.168 35.67318736906827 139.7380669085569 29.861 35.67333003236871 139.73800243638644 29.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85de7a7e-c15b-47f7-884c-038b148ab3c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85de7a7e-c15b-47f7-884c-038b148ab3c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85de7a7e-c15b-47f7-884c-038b148ab3c9">
											<gml:posList>35.67318464377605 139.73807432409458 8.6 35.67333611034306 139.73800587571887 8.6 35.67333611034306 139.73800587571887 29.861 35.67318464377605 139.73807432409458 29.861 35.67318464377605 139.73807432409458 8.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d212a67-531d-42eb-84d1-ec8b4f455b2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d212a67-531d-42eb-84d1-ec8b4f455b2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d212a67-531d-42eb-84d1-ec8b4f455b2c">
											<gml:posList>35.673173136725154 139.73802176678868 29.861 35.67318736906827 139.7380669085569 29.861 35.67318736906827 139.7380669085569 29.168 35.673173136725154 139.73802176678868 29.168 35.673173136725154 139.73802176678868 29.861</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3996</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">150.66295</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.12</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>