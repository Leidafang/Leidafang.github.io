<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c76356ce-dcbd-49eb-8441-26b25b28c1b2">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">23.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67059679872955 139.74166965209483 0 35.670598819562684 139.74160094186263 0 35.67059477251902 139.74160110114101 0 35.67059522529077 139.74156834837555 0 35.670612090538235 139.74156908022053 0 35.67061503191223 139.74146648994116 0 35.67052849722494 139.74146272289465 0 35.67052261326876 139.74166642302478 0 35.67059679872955 139.74166965209483 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059679872955 139.74166965209483 8.62 35.67052261326876 139.74166642302478 8.62 35.67052849722494 139.74146272289465 8.62 35.67061503191223 139.74146648994116 8.62 35.670612090538235 139.74156908022053 8.62 35.67059522529077 139.74156834837555 8.62 35.67059477251902 139.74160110114101 8.62 35.670598819562684 139.74160094186263 8.62 35.67059679872955 139.74166965209483 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059679872955 139.74166965209483 8.62 35.670598819562684 139.74160094186263 8.62 35.670598819562684 139.74160094186263 32.42 35.67059679872955 139.74166965209483 32.42 35.67059679872955 139.74166965209483 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670598819562684 139.74160094186263 8.62 35.67059477251902 139.74160110114101 8.62 35.67059477251902 139.74160110114101 32.42 35.670598819562684 139.74160094186263 32.42 35.670598819562684 139.74160094186263 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059477251902 139.74160110114101 8.62 35.67059522529077 139.74156834837555 8.62 35.67059522529077 139.74156834837555 32.42 35.67059477251902 139.74160110114101 32.42 35.67059477251902 139.74160110114101 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059522529077 139.74156834837555 8.62 35.670612090538235 139.74156908022053 8.62 35.670612090538235 139.74156908022053 32.42 35.67059522529077 139.74156834837555 32.42 35.67059522529077 139.74156834837555 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670612090538235 139.74156908022053 8.62 35.67061503191223 139.74146648994116 8.62 35.67061503191223 139.74146648994116 32.42 35.670612090538235 139.74156908022053 32.42 35.670612090538235 139.74156908022053 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061503191223 139.74146648994116 8.62 35.67052849722494 139.74146272289465 8.62 35.67052849722494 139.74146272289465 32.42 35.67061503191223 139.74146648994116 32.42 35.67061503191223 139.74146648994116 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052849722494 139.74146272289465 8.62 35.67052261326876 139.74166642302478 8.62 35.67052261326876 139.74166642302478 32.42 35.67052849722494 139.74146272289465 32.42 35.67052849722494 139.74146272289465 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052261326876 139.74166642302478 8.62 35.67059679872955 139.74166965209483 8.62 35.67059679872955 139.74166965209483 32.42 35.67052261326876 139.74166642302478 32.42 35.67052261326876 139.74166642302478 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059679872955 139.74166965209483 32.42 35.670598819562684 139.74160094186263 32.42 35.67059477251902 139.74160110114101 32.42 35.67059522529077 139.74156834837555 32.42 35.670612090538235 139.74156908022053 32.42 35.67061503191223 139.74146648994116 32.42 35.67052849722494 139.74146272289465 32.42 35.67052261326876 139.74166642302478 32.42 35.67059679872955 139.74166965209483 32.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b90ed66c-8e35-4c48-b141-657c97b26a11"/>
							<gml:surfaceMember xlink:href="#poly-cdd321a8-7d28-448c-a426-d95df20c5310"/>
							<gml:surfaceMember xlink:href="#poly-b5070047-a725-41a9-bbe5-f738f3b5bdb5"/>
							<gml:surfaceMember xlink:href="#poly-09c6edca-8feb-48ae-a403-343a2d3a08db"/>
							<gml:surfaceMember xlink:href="#poly-8d42941c-e3f2-4689-988c-e6215d56d422"/>
							<gml:surfaceMember xlink:href="#poly-ed35a771-d38e-44dd-95ce-b67b56d89a01"/>
							<gml:surfaceMember xlink:href="#poly-54a41dc7-6ab5-4fe0-a6b0-61188f0ed98d"/>
							<gml:surfaceMember xlink:href="#poly-fcecfba9-d487-4933-af6e-6d8ee58803c7"/>
							<gml:surfaceMember xlink:href="#poly-44a95bc0-4a83-49f7-ad8e-5d0a241d112a"/>
							<gml:surfaceMember xlink:href="#poly-e3c1ff45-a3d6-4670-9c90-fbe36fd9e712"/>
							<gml:surfaceMember xlink:href="#poly-6bdcdbd7-f95c-40b9-9b4a-44d07a10c232"/>
							<gml:surfaceMember xlink:href="#poly-fc836ecc-0997-47d8-a1ad-25dd999ec2a9"/>
							<gml:surfaceMember xlink:href="#poly-e66e6c2e-276b-4f87-aa86-1c1686750b20"/>
							<gml:surfaceMember xlink:href="#poly-f005559f-d96a-461d-b04a-a097160496bb"/>
							<gml:surfaceMember xlink:href="#poly-491f89d5-3c1f-4ab1-aaf8-16faa8d8a7cf"/>
							<gml:surfaceMember xlink:href="#poly-7c948518-e327-45ce-9663-697682eb8da5"/>
							<gml:surfaceMember xlink:href="#poly-4993f964-8278-4068-a23c-9298708dd6f3"/>
							<gml:surfaceMember xlink:href="#poly-675eaae2-7066-48a6-9780-07c8b8229233"/>
							<gml:surfaceMember xlink:href="#poly-8d17b14c-952b-4028-b819-6284e1148819"/>
							<gml:surfaceMember xlink:href="#poly-6c598cd0-0b20-4a8c-b0f2-615b760eff60"/>
							<gml:surfaceMember xlink:href="#poly-7ee6a692-7829-4a12-bafb-73a6543c2b35"/>
							<gml:surfaceMember xlink:href="#poly-19be21be-04ae-4a81-8e90-e3b1c4fc5b76"/>
							<gml:surfaceMember xlink:href="#poly-2770254d-6fc2-49b2-afe8-18dbf1f340ee"/>
							<gml:surfaceMember xlink:href="#poly-66bf5401-7d1d-4935-86a6-c3d5794ded33"/>
							<gml:surfaceMember xlink:href="#poly-3ae5ed94-978b-45a8-a991-80c148df94ff"/>
							<gml:surfaceMember xlink:href="#poly-66b513f0-c20a-434d-b03f-b3f66a13ea36"/>
							<gml:surfaceMember xlink:href="#poly-83c68c5a-bbfc-4551-8aa0-cd223ae41926"/>
							<gml:surfaceMember xlink:href="#poly-838f02f8-c813-4f1a-a4f5-a68fcfd73c7e"/>
							<gml:surfaceMember xlink:href="#poly-7f8f6626-4140-45ae-8881-67cd8d008206"/>
							<gml:surfaceMember xlink:href="#poly-c0cf3ac2-ebff-47da-950f-bd5d6e62fe79"/>
							<gml:surfaceMember xlink:href="#poly-1b1bd0c5-3c52-42d7-b28d-339654324134"/>
							<gml:surfaceMember xlink:href="#poly-2ceb4f0d-4243-4774-b9cf-66fa4c2c493e"/>
							<gml:surfaceMember xlink:href="#poly-16d67d20-94c0-4b51-9060-96bf9504562a"/>
							<gml:surfaceMember xlink:href="#poly-c1627431-5ada-4a0f-85fa-d607a332de97"/>
							<gml:surfaceMember xlink:href="#poly-528acd9d-0ec3-47be-b282-440d31371659"/>
							<gml:surfaceMember xlink:href="#poly-ca9b1a5b-ef4e-40d6-a132-a57b27f99128"/>
							<gml:surfaceMember xlink:href="#poly-e41b22f4-8506-4470-aa47-0224333991c1"/>
							<gml:surfaceMember xlink:href="#poly-36f6edf1-54c0-427a-a4df-d930531d02c0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c76356ce-dcbd-49eb-8441-26b25b28c1b2_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be57f70f-ce0e-4698-99cb-a1da6c94b66b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055007778602 139.7415949884513 34.458 35.670549050652525 139.74163105574 34.458 35.67053991043482 139.74163066852793 34.458 35.670540937559785 139.7415945901971 34.458 35.67055007778602 139.7415949884513 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08d12e1c-5244-470d-adcb-b2295b57ca5c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67060827874959 139.74155859060681 38.899 35.67058648283575 139.7415576545285 38.899 35.67058682515132 139.7415455584513 38.899 35.67060863007895 139.74154649451597 38.899 35.67060827874959 139.74155859060681 38.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32b57c05-bddc-4314-a3ad-9b06ee97931c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32b57c05-bddc-4314-a3ad-9b06ee97931c_0">
											<gml:posList>35.67058682515132 139.7415455584513 38.899 35.67058682515132 139.7415455584513 41.163 35.67060863007895 139.74154649451597 41.163 35.67060863007895 139.74154649451597 38.899 35.67058682515132 139.7415455584513 38.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b5d7af1-9dbb-4624-bfb0-4b6daed80e10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b5d7af1-9dbb-4624-bfb0-4b6daed80e10_0">
											<gml:posList>35.67058682515132 139.7415455584513 38.899 35.67058648283575 139.7415576545285 38.899 35.67058648283575 139.7415576545285 41.163 35.67058682515132 139.7415455584513 41.163 35.67058682515132 139.7415455584513 38.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94a2ed22-89ad-44f5-b75b-728fe9d30cbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94a2ed22-89ad-44f5-b75b-728fe9d30cbd_0">
											<gml:posList>35.67058682515132 139.7415455584513 41.163 35.67058648283575 139.7415576545285 41.163 35.67060827874959 139.74155859060681 41.163 35.67060863007895 139.74154649451597 41.163 35.67058682515132 139.7415455584513 41.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eab26753-25ae-47a9-8158-333cc47206f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eab26753-25ae-47a9-8158-333cc47206f4_0">
											<gml:posList>35.67060827874959 139.74155859060681 38.899 35.67060863007895 139.74154649451597 38.899 35.67060863007895 139.74154649451597 41.163 35.67060827874959 139.74155859060681 41.163 35.67060827874959 139.74155859060681 38.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe25c5ee-6d44-459f-b539-1661e0cdaec3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe25c5ee-6d44-459f-b539-1661e0cdaec3_0">
											<gml:posList>35.67060827874959 139.74155859060681 38.899 35.67060827874959 139.74155859060681 41.163 35.67058648283575 139.7415576545285 41.163 35.67058648283575 139.7415576545285 38.899 35.67060827874959 139.74155859060681 38.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f28dae9-20c9-4372-b551-991c85442099">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f28dae9-20c9-4372-b551-991c85442099_0">
											<gml:posList>35.67055007778602 139.7415949884513 34.458 35.670540937559785 139.7415945901971 34.458 35.670540937559785 139.7415945901971 36.013 35.67055007778602 139.7415949884513 36.013 35.67055007778602 139.7415949884513 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0be7dbdf-b931-42a6-bebb-c023f1129741">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0be7dbdf-b931-42a6-bebb-c023f1129741_0">
											<gml:posList>35.670540937559785 139.7415945901971 34.458 35.67053991043482 139.74163066852793 34.458 35.67053991043482 139.74163066852793 36.013 35.670540937559785 139.7415945901971 36.013 35.670540937559785 139.7415945901971 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b518ddd-4c7a-4808-a6c3-90bc54b46600">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b518ddd-4c7a-4808-a6c3-90bc54b46600_0">
											<gml:posList>35.67053991043482 139.74163066852793 36.013 35.670549050652525 139.74163105574 36.013 35.67055007778602 139.7415949884513 36.013 35.670540937559785 139.7415945901971 36.013 35.67053991043482 139.74163066852793 36.013</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-011c0fd1-a587-4e33-bf74-a35ed6063b8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-011c0fd1-a587-4e33-bf74-a35ed6063b8e_0">
											<gml:posList>35.670549050652525 139.74163105574 34.458 35.67055007778602 139.7415949884513 34.458 35.67055007778602 139.7415949884513 36.013 35.670549050652525 139.74163105574 36.013 35.670549050652525 139.74163105574 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-858f2732-c400-4f86-ad1e-49552e3a9190">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-858f2732-c400-4f86-ad1e-49552e3a9190_0">
											<gml:posList>35.67053991043482 139.74163066852793 34.458 35.670549050652525 139.74163105574 34.458 35.670549050652525 139.74163105574 36.013 35.67053991043482 139.74163066852793 36.013 35.67053991043482 139.74163066852793 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c76356ce-dcbd-49eb-8441-26b25b28c1b2_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b1e062f-93ce-4612-a046-34d1054e4d6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b1e062f-93ce-4612-a046-34d1054e4d6d_0">
											<gml:posList>35.67059247992786 139.74152606632418 34.804 35.67056889022396 139.7415250549849 34.977 35.67059247992786 139.74152606632418 34.977 35.67059247992786 139.74152606632418 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f58c2dd5-98f3-4e53-b597-b297d196cdf0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f58c2dd5-98f3-4e53-b597-b297d196cdf0_0">
											<gml:posList>35.67059247992786 139.74152606632418 34.804 35.67056889022396 139.7415250549849 34.804 35.67056889022396 139.7415250549849 34.977 35.67059247992786 139.74152606632418 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24d75b27-70df-4e70-94e4-da5cdc8aba1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24d75b27-70df-4e70-94e4-da5cdc8aba1e_0">
											<gml:posList>35.67059240970461 139.74152854077326 34.458 35.67056884641024 139.74152670093162 34.804 35.67059240970461 139.74152854077326 34.804 35.67059240970461 139.74152854077326 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7fbdb84-ded9-41a5-95d9-d398db77dfd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7fbdb84-ded9-41a5-95d9-d398db77dfd0_0">
											<gml:posList>35.67059240970461 139.74152854077326 34.458 35.67056884641024 139.74152670093162 34.458 35.67056884641024 139.74152670093162 34.804 35.67059240970461 139.74152854077326 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7438e72-9edd-47be-87a1-7192333633ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7438e72-9edd-47be-87a1-7192333633ee_0">
											<gml:posList>35.6705921111373 139.741538902534 34.458 35.67059240970461 139.74152854077326 34.804 35.6705921111373 139.741538902534 34.977 35.6705921111373 139.741538902534 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-935980c4-2885-44ab-b34b-b0b18eb14838">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-935980c4-2885-44ab-b34b-b0b18eb14838_0">
											<gml:posList>35.6705921111373 139.741538902534 34.977 35.67059240970461 139.74152854077326 34.804 35.67059247992786 139.74152606632418 34.977 35.6705921111373 139.741538902534 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da458c19-9021-43fe-be7e-7f176a28287f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da458c19-9021-43fe-be7e-7f176a28287f_0">
											<gml:posList>35.6705921111373 139.741538902534 34.458 35.67059240970461 139.74152854077326 34.458 35.67059240970461 139.74152854077326 34.804 35.6705921111373 139.741538902534 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-699eb47e-6cd2-47b8-8e78-83dc5b0874bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-699eb47e-6cd2-47b8-8e78-83dc5b0874bd_0">
											<gml:posList>35.67059247992786 139.74152606632418 34.977 35.67059240970461 139.74152854077326 34.804 35.67059247992786 139.74152606632418 34.804 35.67059247992786 139.74152606632418 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41c36fae-43e4-44ac-aee0-f499e03d1e9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41c36fae-43e4-44ac-aee0-f499e03d1e9a_0">
											<gml:posList>35.67058980354851 139.74153880575935 34.977 35.670581086983965 139.74153842911886 34.977 35.6705882260881 139.74153873024133 34.544 35.67058980354851 139.74153880575935 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04b266b8-4395-4db3-bb58-5be3a5031043">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04b266b8-4395-4db3-bb58-5be3a5031043_0">
											<gml:posList>35.6705882260881 139.74153873024133 34.544 35.670581086983965 139.74153842911886 34.458 35.6705882260881 139.74153873024133 34.458 35.6705882260881 139.74153873024133 34.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8db22199-d1c9-43bf-93aa-6500144bcabd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8db22199-d1c9-43bf-93aa-6500144bcabd_0">
											<gml:posList>35.6705882260881 139.74153873024133 34.544 35.670581086983965 139.74153842911886 34.977 35.670581086983965 139.74153842911886 34.458 35.6705882260881 139.74153873024133 34.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff389c8a-615e-4a13-9a25-09779707f2d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff389c8a-615e-4a13-9a25-09779707f2d8_0">
											<gml:posList>35.6705882260881 139.74153873024133 34.458 35.6705921111373 139.741538902534 34.458 35.6705882260881 139.74153873024133 34.544 35.6705882260881 139.74153873024133 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b58aa17-1474-4cff-a408-55559f3f30ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b58aa17-1474-4cff-a408-55559f3f30ff_0">
											<gml:posList>35.6705882260881 139.74153873024133 34.544 35.6705921111373 139.741538902534 34.458 35.67058980354851 139.74153880575935 34.977 35.6705882260881 139.74153873024133 34.544</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c878f9db-874b-4e5c-9862-e434be5368c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c878f9db-874b-4e5c-9862-e434be5368c5_0">
											<gml:posList>35.6705921111373 139.741538902534 34.458 35.6705921111373 139.741538902534 34.977 35.67058980354851 139.74153880575935 34.977 35.6705921111373 139.741538902534 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec962739-9b55-4bfe-86dc-66ea46a1c564">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec962739-9b55-4bfe-86dc-66ea46a1c564_0">
											<gml:posList>35.67056889022396 139.7415250549849 34.804 35.67056884641024 139.74152670093162 34.804 35.67056889022396 139.7415250549849 34.977 35.67056889022396 139.7415250549849 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7ca2883-1616-4b6d-88a6-3f08c8bbde1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7ca2883-1616-4b6d-88a6-3f08c8bbde1e_0">
											<gml:posList>35.67056889022396 139.7415250549849 34.977 35.67056884641024 139.74152670093162 34.804 35.670567906925626 139.7415594763362 34.977 35.67056889022396 139.7415250549849 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aae660ae-33c1-4cfe-8f6a-f48bc8af6bd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aae660ae-33c1-4cfe-8f6a-f48bc8af6bd1_0">
											<gml:posList>35.670567906925626 139.7415594763362 34.977 35.67056884641024 139.74152670093162 34.804 35.670567906925626 139.7415594763362 34.458 35.670567906925626 139.7415594763362 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fe523d7-1481-4a5e-8c0f-b5e454356ca3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fe523d7-1481-4a5e-8c0f-b5e454356ca3_0">
											<gml:posList>35.67056884641024 139.74152670093162 34.804 35.67056884641024 139.74152670093162 34.458 35.670567906925626 139.7415594763362 34.458 35.67056884641024 139.74152670093162 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45eefac4-d204-4a67-b651-26a1bd1ce593">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45eefac4-d204-4a67-b651-26a1bd1ce593_0">
											<gml:posList>35.670581086983965 139.74153842911886 34.977 35.670580472476 139.7415600142675 34.458 35.670581086983965 139.74153842911886 34.458 35.670581086983965 139.74153842911886 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6746668-b24f-4874-b4d3-a70a85cb054a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6746668-b24f-4874-b4d3-a70a85cb054a_0">
											<gml:posList>35.670581086983965 139.74153842911886 34.977 35.670580472476 139.7415600142675 34.977 35.670580472476 139.7415600142675 34.458 35.670581086983965 139.74153842911886 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-756f0c24-9892-43b9-b6d6-f05975174fcd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-756f0c24-9892-43b9-b6d6-f05975174fcd_0">
											<gml:posList>35.670580472476 139.7415600142675 34.977 35.670567906925626 139.7415594763362 34.458 35.670580472476 139.7415600142675 34.458 35.670580472476 139.7415600142675 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91ff837b-4d4b-4df1-8b58-f29e6450202c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91ff837b-4d4b-4df1-8b58-f29e6450202c_0">
											<gml:posList>35.670580472476 139.7415600142675 34.977 35.670567906925626 139.7415594763362 34.977 35.670567906925626 139.7415594763362 34.458 35.670580472476 139.7415600142675 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-011a6677-1f04-4942-ac6d-0c3a56cb63b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-011a6677-1f04-4942-ac6d-0c3a56cb63b8_0">
											<gml:posList>35.67060738521508 139.74156887572636 8.87 35.67059522529074 139.74156834837555 34.804 35.67060738521508 139.74156887572636 34.804 35.67060738521508 139.74156887572636 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e31cfca-c72b-4bf1-a184-97d38a69fc2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e31cfca-c72b-4bf1-a184-97d38a69fc2d_0">
											<gml:posList>35.67060738521508 139.74156887572636 8.87 35.67059522529074 139.74156834837555 8.87 35.67059522529074 139.74156834837555 34.804 35.67060738521508 139.74156887572636 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24c82b29-3eb9-4caa-b987-8d1647a4010e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24c82b29-3eb9-4caa-b987-8d1647a4010e_0">
											<gml:posList>35.67060738521508 139.74156887572636 8.87 35.67061209053824 139.74156908022053 34.804 35.67061209053824 139.74156908022053 8.87 35.67060738521508 139.74156887572636 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1b60f0e-836e-48cb-ae88-ca3eedfbd2e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1b60f0e-836e-48cb-ae88-ca3eedfbd2e1_0">
											<gml:posList>35.67060738521508 139.74156887572636 8.87 35.67060738521508 139.74156887572636 34.804 35.67061209053824 139.74156908022053 34.804 35.67060738521508 139.74156887572636 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df834fad-24ab-4a70-8814-0c38e9399414">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df834fad-24ab-4a70-8814-0c38e9399414_0">
											<gml:posList>35.67059516536827 139.74157251289515 8.87 35.67059516536827 139.74157251289515 31.479 35.67059522529074 139.74156834837555 8.87 35.67059516536827 139.74157251289515 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29a4560a-5576-4f85-a01e-e7d9e8e92be9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29a4560a-5576-4f85-a01e-e7d9e8e92be9_0">
											<gml:posList>35.67059516536827 139.74157251289515 31.479 35.67059522529074 139.74156834837555 34.804 35.67059522529074 139.74156834837555 8.87 35.67059516536827 139.74157251289515 31.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4abf27f9-ae97-4646-b0d3-3d3ab7dfb763">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4abf27f9-ae97-4646-b0d3-3d3ab7dfb763_0">
											<gml:posList>35.670594805923045 139.7415976215217 33.912 35.67059477251058 139.74160109009472 33.636 35.67059477251058 139.74160109009472 34.804 35.670594805923045 139.7415976215217 33.912</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8854af99-d8a6-4aef-85a1-9907fdb690a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8854af99-d8a6-4aef-85a1-9907fdb690a5_0">
											<gml:posList>35.670594805923045 139.7415976215217 17.391 35.670594805923045 139.7415976215217 33.912 35.67059489089294 139.74159083900295 31.215 35.670594805923045 139.7415976215217 17.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-715941e5-4bc7-4430-9ac4-3d34b81a79b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-715941e5-4bc7-4430-9ac4-3d34b81a79b2_0">
											<gml:posList>35.67059489089294 139.74159083900295 31.215 35.670594805923045 139.7415976215217 33.912 35.67059516536827 139.74157251289515 31.479 35.67059489089294 139.74159083900295 31.215</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f8653e5-12bf-40cb-9985-c337d9cd2de5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f8653e5-12bf-40cb-9985-c337d9cd2de5_0">
											<gml:posList>35.67059522529074 139.74156834837555 34.804 35.670594805923045 139.7415976215217 33.912 35.67059477251058 139.74160109009472 34.804 35.67059522529074 139.74156834837555 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30e7ea28-2fe1-4ed4-b60f-ce644e82b803">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30e7ea28-2fe1-4ed4-b60f-ce644e82b803_0">
											<gml:posList>35.67059516536827 139.74157251289515 31.479 35.670594805923045 139.7415976215217 33.912 35.67059522529074 139.74156834837555 34.804 35.67059516536827 139.74157251289515 31.479</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60777e0e-fd5f-43be-8e42-56596d3a0d87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60777e0e-fd5f-43be-8e42-56596d3a0d87_0">
											<gml:posList>35.670611168783445 139.74160148004813 8.87 35.67061209053824 139.74156908022053 34.804 35.670611168783445 139.74160148004813 34.804 35.670611168783445 139.74160148004813 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7baffdf3-c115-41fb-9ebe-91361a5ea18d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7baffdf3-c115-41fb-9ebe-91361a5ea18d_0">
											<gml:posList>35.670611168783445 139.74160148004813 8.87 35.67061209053824 139.74156908022053 8.87 35.67061209053824 139.74156908022053 34.804 35.670611168783445 139.74160148004813 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82b6362f-845b-40c1-9186-6a112da6c8c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82b6362f-845b-40c1-9186-6a112da6c8c2_0">
											<gml:posList>35.670594805923045 139.7415976215217 33.912 35.670594805923045 139.7415976215217 17.391 35.67059477251058 139.74160109009472 33.636 35.670594805923045 139.7415976215217 33.912</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba08e456-4a90-4dc5-a131-9d2d5ad3e926">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba08e456-4a90-4dc5-a131-9d2d5ad3e926_0">
											<gml:posList>35.67059477251058 139.74160109009472 33.636 35.670594805923045 139.7415976215217 17.391 35.67059477251058 139.74160109009472 8.87 35.67059477251058 139.74160109009472 33.636</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d74cd5c-dbec-45d6-a7d2-3482e678dec3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d74cd5c-dbec-45d6-a7d2-3482e678dec3_0">
											<gml:posList>35.67059477251058 139.74160109009472 8.87 35.670594805923045 139.7415976215217 17.391 35.67059516536827 139.74157251289515 8.87 35.67059477251058 139.74160109009472 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68197e55-39b1-4ab0-a59e-537577c3d2c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68197e55-39b1-4ab0-a59e-537577c3d2c2_0">
											<gml:posList>35.670594805923045 139.7415976215217 17.391 35.67059489089294 139.74159083900295 31.215 35.67059516536827 139.74157251289515 31.479 35.670594805923045 139.7415976215217 17.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-102fdc77-450f-420e-8d33-c151f639dc48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-102fdc77-450f-420e-8d33-c151f639dc48_0">
											<gml:posList>35.67059516536827 139.74157251289515 8.87 35.670594805923045 139.7415976215217 17.391 35.67059516536827 139.74157251289515 31.479 35.67059516536827 139.74157251289515 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-714f56dc-41f7-4399-a487-ca74acb5c92e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-714f56dc-41f7-4399-a487-ca74acb5c92e_0">
											<gml:posList>35.670598819562656 139.74160094186263 8.87 35.670611168783445 139.74160148004813 34.804 35.670598819562656 139.74160094186263 34.804 35.670598819562656 139.74160094186263 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-049c4109-63eb-4fff-b8c2-b9baaea7eada">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-049c4109-63eb-4fff-b8c2-b9baaea7eada_0">
											<gml:posList>35.670598819562656 139.74160094186263 8.87 35.670611168783445 139.74160148004813 8.87 35.670611168783445 139.74160148004813 34.804 35.670598819562656 139.74160094186263 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e98e412-d151-4890-8624-4250720b685c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e98e412-d151-4890-8624-4250720b685c_0">
											<gml:posList>35.670580472476 139.7415600142675 34.977 35.670581086983965 139.74153842911886 34.977 35.670567906925626 139.7415594763362 34.977 35.670580472476 139.7415600142675 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84556499-f5ad-436a-a4cb-bd00522be079">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84556499-f5ad-436a-a4cb-bd00522be079_0">
											<gml:posList>35.670567906925626 139.7415594763362 34.977 35.670581086983965 139.74153842911886 34.977 35.67056889022396 139.7415250549849 34.977 35.670567906925626 139.7415594763362 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e87ca7e-01a6-448f-ad1f-7868fa5668a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e87ca7e-01a6-448f-ad1f-7868fa5668a3_0">
											<gml:posList>35.67056889022396 139.7415250549849 34.977 35.670581086983965 139.74153842911886 34.977 35.67059247992786 139.74152606632418 34.977 35.67056889022396 139.7415250549849 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1feb3362-326b-485c-aa78-7867810412bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1feb3362-326b-485c-aa78-7867810412bd_0">
											<gml:posList>35.67059247992786 139.74152606632418 34.977 35.67058980354851 139.74153880575935 34.977 35.6705921111373 139.741538902534 34.977 35.67059247992786 139.74152606632418 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef1926fc-a854-4a27-897e-60851df9f77c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef1926fc-a854-4a27-897e-60851df9f77c_0">
											<gml:posList>35.67059247992786 139.74152606632418 34.977 35.670581086983965 139.74153842911886 34.977 35.67058980354851 139.74153880575935 34.977 35.67059247992786 139.74152606632418 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b60ad8b-ed4e-481c-b6f8-ff60af589543">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b60ad8b-ed4e-481c-b6f8-ff60af589543_0">
											<gml:posList>35.67059477251058 139.74160109009472 34.804 35.670598819562656 139.74160094186263 34.804 35.67059522529074 139.74156834837555 34.804 35.67059477251058 139.74160109009472 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbd7fe68-ea24-441b-b504-86958b252212">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbd7fe68-ea24-441b-b504-86958b252212_0">
											<gml:posList>35.670598819562656 139.74160094186263 34.804 35.670611168783445 139.74160148004813 34.804 35.67060738521508 139.74156887572636 34.804 35.670598819562656 139.74160094186263 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4865057-409d-4507-bf66-ecb1dda71376">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4865057-409d-4507-bf66-ecb1dda71376_0">
											<gml:posList>35.670611168783445 139.74160148004813 34.804 35.67061209053824 139.74156908022053 34.804 35.67060738521508 139.74156887572636 34.804 35.670611168783445 139.74160148004813 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70e7a7e1-e3eb-4c0a-bd74-58da634ac69a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70e7a7e1-e3eb-4c0a-bd74-58da634ac69a_0">
											<gml:posList>35.67059522529074 139.74156834837555 34.804 35.670598819562656 139.74160094186263 34.804 35.67060738521508 139.74156887572636 34.804 35.67059522529074 139.74156834837555 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1dafab50-7b1d-417a-b147-085a2ff13030">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1dafab50-7b1d-417a-b147-085a2ff13030_0">
											<gml:posList>35.67059477251058 139.74160109009472 8.87 35.670598819562656 139.74160094186263 8.87 35.67059477251058 139.74160109009472 33.636 35.67059477251058 139.74160109009472 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-722d86aa-f63d-43ae-ab67-f471a607d0d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-722d86aa-f63d-43ae-ab67-f471a607d0d9_0">
											<gml:posList>35.67059477251058 139.74160109009472 33.636 35.670598819562656 139.74160094186263 34.804 35.67059477251058 139.74160109009472 34.804 35.67059477251058 139.74160109009472 33.636</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d72be3b7-3602-4fce-9980-67bfc433a199">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d72be3b7-3602-4fce-9980-67bfc433a199_0">
											<gml:posList>35.67059477251058 139.74160109009472 33.636 35.670598819562656 139.74160094186263 8.87 35.670598819562656 139.74160094186263 34.804 35.67059477251058 139.74160109009472 33.636</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b325d233-7331-4249-ab47-0c8eadce5c2b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059247992786 139.74152606632418 34.804 35.67056884641024 139.74152670093162 34.804 35.67056889022396 139.7415250549849 34.804 35.67059247992786 139.74152606632418 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c485f7a-cb18-4ba2-afaf-95c39cd46015">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059247992786 139.74152606632418 34.804 35.67059240970461 139.74152854077326 34.804 35.67056884641024 139.74152670093162 34.804 35.67059247992786 139.74152606632418 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cfd18a3-9d06-4de6-a025-5e42ad790820">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705921111373 139.741538902534 34.458 35.6705882260881 139.74153873024133 34.458 35.67059240970461 139.74152854077326 34.458 35.6705921111373 139.741538902534 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22817b09-de39-4755-a4a0-ce87dfd9e791">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059240970461 139.74152854077326 34.458 35.670581086983965 139.74153842911886 34.458 35.67056884641024 139.74152670093162 34.458 35.67059240970461 139.74152854077326 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d02cd77c-7f1b-4fb9-b836-4dd6343e2d0e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67056884641024 139.74152670093162 34.458 35.670581086983965 139.74153842911886 34.458 35.670567906925626 139.7415594763362 34.458 35.67056884641024 139.74152670093162 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b5667ad-38bf-4d51-9a04-6bf3d9e6d7f6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670581086983965 139.74153842911886 34.458 35.670580472476 139.7415600142675 34.458 35.670567906925626 139.7415594763362 34.458 35.670581086983965 139.74153842911886 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2eb801f-e2bb-46c7-b950-c6e001a071e4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705882260881 139.74153873024133 34.458 35.670581086983965 139.74153842911886 34.458 35.67059240970461 139.74152854077326 34.458 35.6705882260881 139.74153873024133 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c638ba66-a4ad-4c12-9215-785c4359b84f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670611168783445 139.74160148004813 8.87 35.67060738521508 139.74156887572636 8.87 35.67061209053824 139.74156908022053 8.87 35.670611168783445 139.74160148004813 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88e6e324-c27f-4cc3-a30b-77d7b238c606">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67060738521508 139.74156887572636 8.87 35.67059516536827 139.74157251289515 8.87 35.67059522529074 139.74156834837555 8.87 35.67060738521508 139.74156887572636 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-230db018-dd98-491c-a215-4e5f57d38369">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059516536827 139.74157251289515 8.87 35.670598819562656 139.74160094186263 8.87 35.67059477251058 139.74160109009472 8.87 35.67059516536827 139.74157251289515 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6d5be60-13c3-489c-b528-ca6c33f9161c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670611168783445 139.74160148004813 8.87 35.670598819562656 139.74160094186263 8.87 35.67060738521508 139.74156887572636 8.87 35.670611168783445 139.74160148004813 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29dfb696-dd5b-4fd9-b3e3-63740f69deef">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67060738521508 139.74156887572636 8.87 35.670598819562656 139.74160094186263 8.87 35.67059516536827 139.74157251289515 8.87 35.67060738521508 139.74156887572636 8.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c76356ce-dcbd-49eb-8441-26b25b28c1b2_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22fedab8-0476-4952-86b7-644df3e5d12b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67056175306399 139.74157460574375 34.458 35.670539758848214 139.74157366988854 34.458 35.67054063683215 139.7415429823133 34.458 35.670562631056576 139.74154392920633 34.458 35.67056175306399 139.74157460574375 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db5604a8-f979-44ca-9ef4-00b30be72723">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db5604a8-f979-44ca-9ef4-00b30be72723_0">
											<gml:posList>35.67054063683215 139.7415429823133 34.458 35.67054063683215 139.7415429823133 37.144 35.670562631056576 139.74154392920633 37.144 35.670562631056576 139.74154392920633 34.458 35.67054063683215 139.7415429823133 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6263fe1b-ddb4-4713-8b2d-cc83d50aff0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6263fe1b-ddb4-4713-8b2d-cc83d50aff0b_0">
											<gml:posList>35.670539758848214 139.74157366988854 34.458 35.670539758848214 139.74157366988854 37.144 35.67054063683215 139.7415429823133 37.144 35.67054063683215 139.7415429823133 34.458 35.670539758848214 139.74157366988854 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92b1133d-a125-4fa6-a53f-4e92410cea1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92b1133d-a125-4fa6-a53f-4e92410cea1b_0">
											<gml:posList>35.67054063683215 139.7415429823133 37.144 35.670539758848214 139.74157366988854 37.144 35.67056175306399 139.74157460574375 37.144 35.670562631056576 139.74154392920633 37.144 35.67054063683215 139.7415429823133 37.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cb7aeb3-475d-40eb-84b8-d03985518c1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cb7aeb3-475d-40eb-84b8-d03985518c1a_0">
											<gml:posList>35.670562631056576 139.74154392920633 34.458 35.670562631056576 139.74154392920633 37.144 35.67056175306399 139.74157460574375 37.144 35.67056175306399 139.74157460574375 34.458 35.670562631056576 139.74154392920633 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-796f5d4b-1263-4bd5-ac95-6e298c494ac1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-796f5d4b-1263-4bd5-ac95-6e298c494ac1_0">
											<gml:posList>35.67056175306399 139.74157460574375 34.458 35.67056175306399 139.74157460574375 37.144 35.670539758848214 139.74157366988854 37.144 35.670539758848214 139.74157366988854 34.458 35.67056175306399 139.74157460574375 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b90ed66c-8e35-4c48-b141-657c97b26a11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b90ed66c-8e35-4c48-b141-657c97b26a11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b90ed66c-8e35-4c48-b141-657c97b26a11">
											<gml:posList>35.670594772519 139.741601101141 8.62 35.670598819562656 139.74160094186263 8.62 35.670596798729555 139.7416696520948 8.62 35.67052261326874 139.74166642302478 8.62 35.670528497224936 139.74146272289465 8.62 35.67061503191222 139.74146648994116 8.62 35.67061209053824 139.74156908022053 8.62 35.67059522529074 139.74156834837555 8.62 35.670594772519 139.741601101141 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cdd321a8-7d28-448c-a426-d95df20c5310">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdd321a8-7d28-448c-a426-d95df20c5310">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdd321a8-7d28-448c-a426-d95df20c5310">
											<gml:posList>35.67061503191222 139.74146648994116 26.062 35.670528497224936 139.74146272289465 26.062 35.67052685496477 139.74151950265434 34.804 35.67061503191222 139.74146648994116 26.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b5070047-a725-41a9-bbe5-f738f3b5bdb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5070047-a725-41a9-bbe5-f738f3b5bdb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5070047-a725-41a9-bbe5-f738f3b5bdb5">
											<gml:posList>35.67052685496477 139.74151950265434 34.804 35.670613319806186 139.74152624129454 34.804 35.67061503191222 139.74146648994116 26.062 35.67052685496477 139.74151950265434 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09c6edca-8feb-48ae-a403-343a2d3a08db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09c6edca-8feb-48ae-a403-343a2d3a08db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09c6edca-8feb-48ae-a403-343a2d3a08db">
											<gml:posList>35.67052685496477 139.74151950265434 34.804 35.67052993181951 139.74152366357856 34.804 35.67061001456606 139.74152991244787 34.804 35.670613319806186 139.74152624129454 34.804 35.67052685496477 139.74151950265434 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d42941c-e3f2-4689-988c-e6215d56d422">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d42941c-e3f2-4689-988c-e6215d56d422">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d42941c-e3f2-4689-988c-e6215d56d422">
											<gml:posList>35.67061001456606 139.74152991244787 34.804 35.67060974256824 139.74153965558816 34.804 35.67061293353553 139.74153979553662 34.804 35.670613319806186 139.74152624129454 34.804 35.67061001456606 139.74152991244787 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed35a771-d38e-44dd-95ce-b67b56d89a01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed35a771-d38e-44dd-95ce-b67b56d89a01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed35a771-d38e-44dd-95ce-b67b56d89a01">
											<gml:posList>35.670581086983965 139.74153842911886 39.228 35.67058226896898 139.74153998529215 39.228 35.67061168172279 139.74154123298771 39.228 35.67061293353553 139.74153979553662 39.228 35.670581086983965 139.74153842911886 39.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54a41dc7-6ab5-4fe0-a6b0-61188f0ed98d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54a41dc7-6ab5-4fe0-a6b0-61188f0ed98d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54a41dc7-6ab5-4fe0-a6b0-61188f0ed98d">
											<gml:posList>35.670580253000715 139.74156771378085 39.228 35.670581522841225 139.74156627631012 39.228 35.67058226896898 139.74153998529215 39.228 35.670581086983965 139.74153842911886 39.228 35.670580253000715 139.74156771378085 39.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fcecfba9-d487-4933-af6e-6d8ee58803c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcecfba9-d487-4933-af6e-6d8ee58803c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcecfba9-d487-4933-af6e-6d8ee58803c7">
											<gml:posList>35.67061168172279 139.74154123298771 38.899 35.67058226896898 139.74153998529215 38.899 35.670581522841225 139.74156627631012 38.899 35.67061092658105 139.74156752402564 38.899 35.67061168172279 139.74154123298771 38.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44a95bc0-4a83-49f7-ad8e-5d0a241d112a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44a95bc0-4a83-49f7-ad8e-5d0a241d112a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44a95bc0-4a83-49f7-ad8e-5d0a241d112a">
											<gml:posList>35.67061293353553 139.74153979553662 39.228 35.67061168172279 139.74154123298771 39.228 35.67061092658105 139.74156752402564 39.228 35.67061209053824 139.74156908022053 39.228 35.67061293353553 139.74153979553662 39.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e3c1ff45-a3d6-4670-9c90-fbe36fd9e712">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3c1ff45-a3d6-4670-9c90-fbe36fd9e712">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3c1ff45-a3d6-4670-9c90-fbe36fd9e712">
											<gml:posList>35.67061209053824 139.74156908022053 39.228 35.67061092658105 139.74156752402564 39.228 35.670581522841225 139.74156627631012 39.228 35.670580253000715 139.74156771378085 39.228 35.67061209053824 139.74156908022053 39.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6bdcdbd7-f95c-40b9-9b4a-44d07a10c232">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bdcdbd7-f95c-40b9-9b4a-44d07a10c232">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bdcdbd7-f95c-40b9-9b4a-44d07a10c232">
											<gml:posList>35.6705919652021 139.74157212993757 34.804 35.6705917166739 139.74158901999743 34.804 35.67059489089294 139.74159083900295 34.804 35.67059522529074 139.74156834837555 34.804 35.670592079400514 139.74156821942063 34.804 35.6705919652021 139.74157212993757 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fc836ecc-0997-47d8-a1ad-25dd999ec2a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc836ecc-0997-47d8-a1ad-25dd999ec2a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc836ecc-0997-47d8-a1ad-25dd999ec2a9">
											<gml:posList>35.670581086983965 139.74153842911886 34.458 35.67060974256824 139.74153965558816 34.458 35.67061001456606 139.74152991244787 34.458 35.67052993181951 139.74152366357856 34.458 35.67052605888099 139.74165769252446 34.458 35.6705917166739 139.74158901999743 34.458 35.6705919652021 139.74157212993757 34.458 35.670592079400514 139.74156821942063 34.458 35.670580253000715 139.74156771378085 34.458 35.670581086983965 139.74153842911886 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e66e6c2e-276b-4f87-aa86-1c1686750b20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e66e6c2e-276b-4f87-aa86-1c1686750b20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e66e6c2e-276b-4f87-aa86-1c1686750b20">
											<gml:posList>35.67052685496477 139.74151950265434 34.804 35.67052261326874 139.74166642302478 34.804 35.67052605888099 139.74165769252446 34.804 35.67052993181951 139.74152366357856 34.804 35.67052685496477 139.74151950265434 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f005559f-d96a-461d-b04a-a097160496bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f005559f-d96a-461d-b04a-a097160496bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f005559f-d96a-461d-b04a-a097160496bb">
											<gml:posList>35.67059489089294 139.74159083900295 34.804 35.6705917166739 139.74158901999743 34.804 35.67052605888099 139.74165769252446 34.804 35.67052261326874 139.74166642302478 34.804 35.67059489089294 139.74159083900295 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-491f89d5-3c1f-4ab1-aaf8-16faa8d8a7cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-491f89d5-3c1f-4ab1-aaf8-16faa8d8a7cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-491f89d5-3c1f-4ab1-aaf8-16faa8d8a7cf">
											<gml:posList>35.67052261326874 139.74166642302478 34.449 35.670594772519 139.741601101141 33.635 35.67059489089294 139.74159083900295 34.449 35.67052261326874 139.74166642302478 34.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c948518-e327-45ce-9663-697682eb8da5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c948518-e327-45ce-9663-697682eb8da5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c948518-e327-45ce-9663-697682eb8da5">
											<gml:posList>35.67052261326874 139.74166642302478 34.449 35.670598819562656 139.74160094186263 33.317 35.670594772519 139.741601101141 33.635 35.67052261326874 139.74166642302478 34.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4993f964-8278-4068-a23c-9298708dd6f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4993f964-8278-4068-a23c-9298708dd6f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4993f964-8278-4068-a23c-9298708dd6f3">
											<gml:posList>35.67052261326874 139.74166642302478 34.449 35.670596798729555 139.7416696520948 28.254 35.670598819562656 139.74160094186263 33.317 35.67052261326874 139.74166642302478 34.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-675eaae2-7066-48a6-9780-07c8b8229233">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-675eaae2-7066-48a6-9780-07c8b8229233">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-675eaae2-7066-48a6-9780-07c8b8229233">
											<gml:posList>35.670528497224936 139.74146272289465 26.062 35.670528497224936 139.74146272289465 8.62 35.67052261326874 139.74166642302478 8.62 35.67052261326874 139.74166642302478 34.449 35.67052261326874 139.74166642302478 34.804 35.67052685496477 139.74151950265434 34.804 35.670528497224936 139.74146272289465 26.062</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d17b14c-952b-4028-b819-6284e1148819">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d17b14c-952b-4028-b819-6284e1148819">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d17b14c-952b-4028-b819-6284e1148819">
											<gml:posList>35.67052605888099 139.74165769252446 34.804 35.67052605888099 139.74165769252446 34.458 35.67052993181951 139.74152366357856 34.458 35.67052993181951 139.74152366357856 34.804 35.67052605888099 139.74165769252446 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c598cd0-0b20-4a8c-b0f2-615b760eff60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c598cd0-0b20-4a8c-b0f2-615b760eff60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c598cd0-0b20-4a8c-b0f2-615b760eff60">
											<gml:posList>35.67059489089294 139.74159083900295 34.449 35.67059489089294 139.74159083900295 34.804 35.67052261326874 139.74166642302478 34.804 35.67052261326874 139.74166642302478 34.449 35.67059489089294 139.74159083900295 34.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ee6a692-7829-4a12-bafb-73a6543c2b35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ee6a692-7829-4a12-bafb-73a6543c2b35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ee6a692-7829-4a12-bafb-73a6543c2b35">
											<gml:posList>35.6705917166739 139.74158901999743 34.804 35.6705917166739 139.74158901999743 34.458 35.67052605888099 139.74165769252446 34.458 35.67052605888099 139.74165769252446 34.804 35.6705917166739 139.74158901999743 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19be21be-04ae-4a81-8e90-e3b1c4fc5b76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19be21be-04ae-4a81-8e90-e3b1c4fc5b76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19be21be-04ae-4a81-8e90-e3b1c4fc5b76">
											<gml:posList>35.67052261326874 139.74166642302478 8.62 35.670596798729555 139.7416696520948 8.62 35.670596798729555 139.7416696520948 28.254 35.67052261326874 139.74166642302478 34.449 35.67052261326874 139.74166642302478 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2770254d-6fc2-49b2-afe8-18dbf1f340ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2770254d-6fc2-49b2-afe8-18dbf1f340ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2770254d-6fc2-49b2-afe8-18dbf1f340ee">
											<gml:posList>35.67052993181951 139.74152366357856 34.804 35.67052993181951 139.74152366357856 34.458 35.67061001456606 139.74152991244787 34.458 35.67061001456606 139.74152991244787 34.804 35.67052993181951 139.74152366357856 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66bf5401-7d1d-4935-86a6-c3d5794ded33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66bf5401-7d1d-4935-86a6-c3d5794ded33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66bf5401-7d1d-4935-86a6-c3d5794ded33">
											<gml:posList>35.67061503191222 139.74146648994116 8.62 35.670528497224936 139.74146272289465 8.62 35.670528497224936 139.74146272289465 26.062 35.67061503191222 139.74146648994116 26.062 35.67061503191222 139.74146648994116 8.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ae5ed94-978b-45a8-a991-80c148df94ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ae5ed94-978b-45a8-a991-80c148df94ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ae5ed94-978b-45a8-a991-80c148df94ff">
											<gml:posList>35.670580253000715 139.74156771378085 39.228 35.670581086983965 139.74153842911886 39.228 35.670581086983965 139.74153842911886 34.458 35.670580253000715 139.74156771378085 34.458 35.670580253000715 139.74156771378085 39.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66b513f0-c20a-434d-b03f-b3f66a13ea36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66b513f0-c20a-434d-b03f-b3f66a13ea36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66b513f0-c20a-434d-b03f-b3f66a13ea36">
											<gml:posList>35.670581522841225 139.74156627631012 39.228 35.670581522841225 139.74156627631012 38.899 35.67058226896898 139.74153998529215 38.899 35.67058226896898 139.74153998529215 39.228 35.670581522841225 139.74156627631012 39.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83c68c5a-bbfc-4551-8aa0-cd223ae41926">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83c68c5a-bbfc-4551-8aa0-cd223ae41926">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83c68c5a-bbfc-4551-8aa0-cd223ae41926">
											<gml:posList>35.6705919652021 139.74157212993757 34.804 35.6705919652021 139.74157212993757 34.458 35.6705917166739 139.74158901999743 34.458 35.6705917166739 139.74158901999743 34.804 35.6705919652021 139.74157212993757 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-838f02f8-c813-4f1a-a4f5-a68fcfd73c7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-838f02f8-c813-4f1a-a4f5-a68fcfd73c7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-838f02f8-c813-4f1a-a4f5-a68fcfd73c7e">
											<gml:posList>35.670592079400514 139.74156821942063 34.804 35.670592079400514 139.74156821942063 34.458 35.6705919652021 139.74157212993757 34.458 35.6705919652021 139.74157212993757 34.804 35.670592079400514 139.74156821942063 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f8f6626-4140-45ae-8881-67cd8d008206">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f8f6626-4140-45ae-8881-67cd8d008206">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f8f6626-4140-45ae-8881-67cd8d008206">
											<gml:posList>35.67059522529074 139.74156834837555 34.804 35.67059489089294 139.74159083900295 34.804 35.67059489089294 139.74159083900295 34.449 35.670594772519 139.741601101141 33.635 35.670594772519 139.741601101141 8.62 35.67059522529074 139.74156834837555 8.62 35.67059522529074 139.74156834837555 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0cf3ac2-ebff-47da-950f-bd5d6e62fe79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0cf3ac2-ebff-47da-950f-bd5d6e62fe79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0cf3ac2-ebff-47da-950f-bd5d6e62fe79">
											<gml:posList>35.670580253000715 139.74156771378085 34.458 35.670592079400514 139.74156821942063 34.458 35.670592079400514 139.74156821942063 34.804 35.67059522529074 139.74156834837555 34.804 35.67059522529074 139.74156834837555 8.62 35.67061209053824 139.74156908022053 8.62 35.67061209053824 139.74156908022053 39.228 35.670580253000715 139.74156771378085 39.228 35.670580253000715 139.74156771378085 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b1bd0c5-3c52-42d7-b28d-339654324134">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b1bd0c5-3c52-42d7-b28d-339654324134">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b1bd0c5-3c52-42d7-b28d-339654324134">
											<gml:posList>35.67061092658105 139.74156752402564 39.228 35.67061092658105 139.74156752402564 38.899 35.670581522841225 139.74156627631012 38.899 35.670581522841225 139.74156627631012 39.228 35.67061092658105 139.74156752402564 39.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ceb4f0d-4243-4774-b9cf-66fa4c2c493e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ceb4f0d-4243-4774-b9cf-66fa4c2c493e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ceb4f0d-4243-4774-b9cf-66fa4c2c493e">
											<gml:posList>35.670598819562656 139.74160094186263 33.317 35.670598819562656 139.74160094186263 8.62 35.670594772519 139.741601101141 8.62 35.670594772519 139.741601101141 33.635 35.670598819562656 139.74160094186263 33.317</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16d67d20-94c0-4b51-9060-96bf9504562a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16d67d20-94c0-4b51-9060-96bf9504562a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16d67d20-94c0-4b51-9060-96bf9504562a">
											<gml:posList>35.67058226896898 139.74153998529215 39.228 35.67058226896898 139.74153998529215 38.899 35.67061168172279 139.74154123298771 38.899 35.67061168172279 139.74154123298771 39.228 35.67058226896898 139.74153998529215 39.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1627431-5ada-4a0f-85fa-d607a332de97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1627431-5ada-4a0f-85fa-d607a332de97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1627431-5ada-4a0f-85fa-d607a332de97">
											<gml:posList>35.670581086983965 139.74153842911886 34.458 35.670581086983965 139.74153842911886 39.228 35.67061293353553 139.74153979553662 39.228 35.67061293353553 139.74153979553662 34.804 35.67060974256824 139.74153965558816 34.804 35.67060974256824 139.74153965558816 34.458 35.670581086983965 139.74153842911886 34.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-528acd9d-0ec3-47be-b282-440d31371659">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-528acd9d-0ec3-47be-b282-440d31371659">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-528acd9d-0ec3-47be-b282-440d31371659">
											<gml:posList>35.670596798729555 139.7416696520948 28.254 35.670596798729555 139.7416696520948 8.62 35.670598819562656 139.74160094186263 8.62 35.670598819562656 139.74160094186263 33.317 35.670596798729555 139.7416696520948 28.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca9b1a5b-ef4e-40d6-a132-a57b27f99128">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca9b1a5b-ef4e-40d6-a132-a57b27f99128">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca9b1a5b-ef4e-40d6-a132-a57b27f99128">
											<gml:posList>35.67061001456606 139.74152991244787 34.804 35.67061001456606 139.74152991244787 34.458 35.67060974256824 139.74153965558816 34.458 35.67060974256824 139.74153965558816 34.804 35.67061001456606 139.74152991244787 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e41b22f4-8506-4470-aa47-0224333991c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e41b22f4-8506-4470-aa47-0224333991c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e41b22f4-8506-4470-aa47-0224333991c1">
											<gml:posList>35.67061168172279 139.74154123298771 39.228 35.67061168172279 139.74154123298771 38.899 35.67061092658105 139.74156752402564 38.899 35.67061092658105 139.74156752402564 39.228 35.67061168172279 139.74154123298771 39.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36f6edf1-54c0-427a-a4df-d930531d02c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36f6edf1-54c0-427a-a4df-d930531d02c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36f6edf1-54c0-427a-a4df-d930531d02c0">
											<gml:posList>35.67061293353553 139.74153979553662 34.804 35.67061293353553 139.74153979553662 39.228 35.67061209053824 139.74156908022053 39.228 35.67061209053824 139.74156908022053 8.62 35.67061503191222 139.74146648994116 8.62 35.67061503191222 139.74146648994116 26.062 35.670613319806186 139.74152624129454 34.804 35.67061293353553 139.74153979553662 34.804</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8309</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">168.76225</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>