<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c8f6ecfb-92fe-48c8-9dd3-0c6a926a557c">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:measuredHeight uom="m">6.5</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67345664077954 139.73836949967188 0 35.673433958912675 139.73829672891867 0 35.67338034716952 139.73832197888672 0 35.67340302893415 139.73839463913183 0 35.67345664077954 139.73836949967188 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67345664077954 139.73836949967188 8.549 35.67340302893415 139.73839463913183 8.549 35.67338034716952 139.73832197888672 8.549 35.673433958912675 139.73829672891867 8.549 35.67345664077954 139.73836949967188 8.549</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67345664077954 139.73836949967188 8.549 35.673433958912675 139.73829672891867 8.549 35.673433958912675 139.73829672891867 15.07 35.67345664077954 139.73836949967188 15.07 35.67345664077954 139.73836949967188 8.549</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673433958912675 139.73829672891867 8.549 35.67338034716952 139.73832197888672 8.549 35.67338034716952 139.73832197888672 15.07 35.673433958912675 139.73829672891867 15.07 35.673433958912675 139.73829672891867 8.549</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67338034716952 139.73832197888672 8.549 35.67340302893415 139.73839463913183 8.549 35.67340302893415 139.73839463913183 15.07 35.67338034716952 139.73832197888672 15.07 35.67338034716952 139.73832197888672 8.549</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67340302893415 139.73839463913183 8.549 35.67345664077954 139.73836949967188 8.549 35.67345664077954 139.73836949967188 15.07 35.67340302893415 139.73839463913183 15.07 35.67340302893415 139.73839463913183 8.549</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67345664077954 139.73836949967188 15.07 35.673433958912675 139.73829672891867 15.07 35.67338034716952 139.73832197888672 15.07 35.67340302893415 139.73839463913183 15.07 35.67345664077954 139.73836949967188 15.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ad756338-0151-4216-9316-755f41f2b2f5"/>
							<gml:surfaceMember xlink:href="#poly-5800df50-c104-4bfc-b020-5e08dfca61ef"/>
							<gml:surfaceMember xlink:href="#poly-588b35e7-24f9-477f-90b8-f77c781ef9d2"/>
							<gml:surfaceMember xlink:href="#poly-2ad0b628-b0ae-42f3-9b65-14f139bee8dc"/>
							<gml:surfaceMember xlink:href="#poly-5eae85d8-815e-49be-a185-7b17bb44f04b"/>
							<gml:surfaceMember xlink:href="#poly-6f608256-eeab-4e3f-a1e5-c7c382c7a8b5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ad756338-0151-4216-9316-755f41f2b2f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad756338-0151-4216-9316-755f41f2b2f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad756338-0151-4216-9316-755f41f2b2f5">
											<gml:posList>35.67345664077954 139.73836949967188 8.549 35.673403028934146 139.73839463913185 8.549 35.67338034716948 139.73832197888672 8.549 35.67343395891266 139.73829672891867 8.549 35.67345664077954 139.73836949967188 8.549</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5800df50-c104-4bfc-b020-5e08dfca61ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5800df50-c104-4bfc-b020-5e08dfca61ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5800df50-c104-4bfc-b020-5e08dfca61ef">
											<gml:posList>35.673403028934146 139.73839463913185 14.072 35.67345664077954 139.73836949967188 14.072 35.67343395891266 139.73829672891867 14.072 35.67338034716948 139.73832197888672 14.072 35.673403028934146 139.73839463913185 14.072</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-588b35e7-24f9-477f-90b8-f77c781ef9d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-588b35e7-24f9-477f-90b8-f77c781ef9d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-588b35e7-24f9-477f-90b8-f77c781ef9d2">
											<gml:posList>35.67343395891266 139.73829672891867 8.549 35.67338034716948 139.73832197888672 8.549 35.67338034716948 139.73832197888672 14.072 35.67343395891266 139.73829672891867 14.072 35.67343395891266 139.73829672891867 8.549</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ad0b628-b0ae-42f3-9b65-14f139bee8dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ad0b628-b0ae-42f3-9b65-14f139bee8dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ad0b628-b0ae-42f3-9b65-14f139bee8dc">
											<gml:posList>35.67345664077954 139.73836949967188 8.549 35.67343395891266 139.73829672891867 8.549 35.67343395891266 139.73829672891867 14.072 35.67345664077954 139.73836949967188 14.072 35.67345664077954 139.73836949967188 8.549</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5eae85d8-815e-49be-a185-7b17bb44f04b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5eae85d8-815e-49be-a185-7b17bb44f04b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5eae85d8-815e-49be-a185-7b17bb44f04b">
											<gml:posList>35.67338034716948 139.73832197888672 8.549 35.673403028934146 139.73839463913185 8.549 35.673403028934146 139.73839463913185 14.072 35.67338034716948 139.73832197888672 14.072 35.67338034716948 139.73832197888672 8.549</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f608256-eeab-4e3f-a1e5-c7c382c7a8b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f608256-eeab-4e3f-a1e5-c7c382c7a8b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f608256-eeab-4e3f-a1e5-c7c382c7a8b5">
											<gml:posList>35.673403028934146 139.73839463913185 8.549 35.67345664077954 139.73836949967188 8.549 35.67345664077954 139.73836949967188 14.072 35.673403028934146 139.73839463913185 14.072 35.673403028934146 139.73839463913185 8.549</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4318</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>