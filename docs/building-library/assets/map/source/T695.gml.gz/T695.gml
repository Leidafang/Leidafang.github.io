<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c9103f95-2f31-4697-9235-cafd1f524236">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">18.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67324605769873 139.73749929487164 0 35.67321721232293 139.73750879633246 0 35.67320934591439 139.7375120313565 0 35.67320158426333 139.73748833452717 0 35.67320052756562 139.73748570668835 0 35.67310018600326 139.73750740072916 0 35.67313217223983 139.73760501477898 0 35.673189927684696 139.73757666639997 0 35.67323820513739 139.73775810524364 0 35.673357328683295 139.73771035208264 0 35.67332187972531 139.73756546212726 0 35.6733050291692 139.7375718893206 0 35.673278446827624 139.73746885574957 0 35.67324278565045 139.73747656477002 0 35.67324605769873 139.73749929487164 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67324605769873 139.73749929487164 8.83 35.67324278565045 139.73747656477002 8.83 35.673278446827624 139.73746885574957 8.83 35.6733050291692 139.7375718893206 8.83 35.67332187972531 139.73756546212726 8.83 35.673357328683295 139.73771035208264 8.83 35.67323820513739 139.73775810524364 8.83 35.673189927684696 139.73757666639997 8.83 35.67313217223983 139.73760501477898 8.83 35.67310018600326 139.73750740072916 8.83 35.67320052756562 139.73748570668835 8.83 35.67320158426333 139.73748833452717 8.83 35.67320934591439 139.7375120313565 8.83 35.67321721232293 139.73750879633246 8.83 35.67324605769873 139.73749929487164 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67324605769873 139.73749929487164 8.83 35.67321721232293 139.73750879633246 8.83 35.67321721232293 139.73750879633246 26.979999999999997 35.67324605769873 139.73749929487164 26.979999999999997 35.67324605769873 139.73749929487164 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67321721232293 139.73750879633246 8.83 35.67320934591439 139.7375120313565 8.83 35.67320934591439 139.7375120313565 26.979999999999997 35.67321721232293 139.73750879633246 26.979999999999997 35.67321721232293 139.73750879633246 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67320934591439 139.7375120313565 8.83 35.67320158426333 139.73748833452717 8.83 35.67320158426333 139.73748833452717 26.979999999999997 35.67320934591439 139.7375120313565 26.979999999999997 35.67320934591439 139.7375120313565 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67320158426333 139.73748833452717 8.83 35.67320052756562 139.73748570668835 8.83 35.67320052756562 139.73748570668835 26.979999999999997 35.67320158426333 139.73748833452717 26.979999999999997 35.67320158426333 139.73748833452717 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67320052756562 139.73748570668835 8.83 35.67310018600326 139.73750740072916 8.83 35.67310018600326 139.73750740072916 26.979999999999997 35.67320052756562 139.73748570668835 26.979999999999997 35.67320052756562 139.73748570668835 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67310018600326 139.73750740072916 8.83 35.67313217223983 139.73760501477898 8.83 35.67313217223983 139.73760501477898 26.979999999999997 35.67310018600326 139.73750740072916 26.979999999999997 35.67310018600326 139.73750740072916 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67313217223983 139.73760501477898 8.83 35.673189927684696 139.73757666639997 8.83 35.673189927684696 139.73757666639997 26.979999999999997 35.67313217223983 139.73760501477898 26.979999999999997 35.67313217223983 139.73760501477898 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673189927684696 139.73757666639997 8.83 35.67323820513739 139.73775810524364 8.83 35.67323820513739 139.73775810524364 26.979999999999997 35.673189927684696 139.73757666639997 26.979999999999997 35.673189927684696 139.73757666639997 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67323820513739 139.73775810524364 8.83 35.673357328683295 139.73771035208264 8.83 35.673357328683295 139.73771035208264 26.979999999999997 35.67323820513739 139.73775810524364 26.979999999999997 35.67323820513739 139.73775810524364 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673357328683295 139.73771035208264 8.83 35.67332187972531 139.73756546212726 8.83 35.67332187972531 139.73756546212726 26.979999999999997 35.673357328683295 139.73771035208264 26.979999999999997 35.673357328683295 139.73771035208264 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67332187972531 139.73756546212726 8.83 35.6733050291692 139.7375718893206 8.83 35.6733050291692 139.7375718893206 26.979999999999997 35.67332187972531 139.73756546212726 26.979999999999997 35.67332187972531 139.73756546212726 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6733050291692 139.7375718893206 8.83 35.673278446827624 139.73746885574957 8.83 35.673278446827624 139.73746885574957 26.979999999999997 35.6733050291692 139.7375718893206 26.979999999999997 35.6733050291692 139.7375718893206 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673278446827624 139.73746885574957 8.83 35.67324278565045 139.73747656477002 8.83 35.67324278565045 139.73747656477002 26.979999999999997 35.673278446827624 139.73746885574957 26.979999999999997 35.673278446827624 139.73746885574957 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67324278565045 139.73747656477002 8.83 35.67324605769873 139.73749929487164 8.83 35.67324605769873 139.73749929487164 26.979999999999997 35.67324278565045 139.73747656477002 26.979999999999997 35.67324278565045 139.73747656477002 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67324605769873 139.73749929487164 26.979999999999997 35.67321721232293 139.73750879633246 26.979999999999997 35.67320934591439 139.7375120313565 26.979999999999997 35.67320158426333 139.73748833452717 26.979999999999997 35.67320052756562 139.73748570668835 26.979999999999997 35.67310018600326 139.73750740072916 26.979999999999997 35.67313217223983 139.73760501477898 26.979999999999997 35.673189927684696 139.73757666639997 26.979999999999997 35.67323820513739 139.73775810524364 26.979999999999997 35.673357328683295 139.73771035208264 26.979999999999997 35.67332187972531 139.73756546212726 26.979999999999997 35.6733050291692 139.7375718893206 26.979999999999997 35.673278446827624 139.73746885574957 26.979999999999997 35.67324278565045 139.73747656477002 26.979999999999997 35.67324605769873 139.73749929487164 26.979999999999997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1ade84bd-259b-414f-822d-c30749ece302"/>
							<gml:surfaceMember xlink:href="#poly-987e56fe-4e65-4214-bc3e-91f4d31c8870"/>
							<gml:surfaceMember xlink:href="#poly-3142d0ad-67cb-41de-9f0c-c695349ecbed"/>
							<gml:surfaceMember xlink:href="#poly-51420b03-83e0-4866-ab5d-b8718cdd4722"/>
							<gml:surfaceMember xlink:href="#poly-1d2ad1aa-1813-41f5-b998-ede735f0ab1a"/>
							<gml:surfaceMember xlink:href="#poly-5d39f02c-7482-4d95-9f06-c734d5fd494a"/>
							<gml:surfaceMember xlink:href="#poly-edc766cb-155f-42fb-a35d-6d4b7d8d21c3"/>
							<gml:surfaceMember xlink:href="#poly-e609f532-4e03-4e9a-9502-851007d76294"/>
							<gml:surfaceMember xlink:href="#poly-5e4135c0-1a92-44b2-a5d5-aa77eb787361"/>
							<gml:surfaceMember xlink:href="#poly-084f3a06-0fe4-42ba-a99a-335bd6b25417"/>
							<gml:surfaceMember xlink:href="#poly-73294e13-a7a2-410a-9db0-93fecebd4621"/>
							<gml:surfaceMember xlink:href="#poly-ffa7f642-ac77-4fae-a777-b83a55dba352"/>
							<gml:surfaceMember xlink:href="#poly-2477b629-e6af-498f-ad23-3845804176e1"/>
							<gml:surfaceMember xlink:href="#poly-1225f374-8ae4-4313-96fc-9ccb185c740f"/>
							<gml:surfaceMember xlink:href="#poly-a110d163-b8b7-44eb-ba11-8d495042045a"/>
							<gml:surfaceMember xlink:href="#poly-0a2567f9-730a-4c36-b8e0-433db6c515e2"/>
							<gml:surfaceMember xlink:href="#poly-a9734498-7671-46d0-9f96-299e07e703ff"/>
							<gml:surfaceMember xlink:href="#poly-e54444ce-c3f6-4315-b690-7e031c68e602"/>
							<gml:surfaceMember xlink:href="#poly-f88d932d-09be-4578-aae0-5db7d607a94c"/>
							<gml:surfaceMember xlink:href="#poly-43973430-f796-4fb4-a320-b450c06985ec"/>
							<gml:surfaceMember xlink:href="#poly-bf23c335-8e6f-4de3-9c01-2c8d28bea4b5"/>
							<gml:surfaceMember xlink:href="#poly-6fee2e4f-b0c8-4750-8354-2f3c89b19287"/>
							<gml:surfaceMember xlink:href="#poly-2b011da0-72b5-4b73-b41d-cf018da3205d"/>
							<gml:surfaceMember xlink:href="#poly-62419ece-64a1-44fa-93a8-89485faf6c19"/>
							<gml:surfaceMember xlink:href="#poly-999968ff-10ee-481a-a7dd-03d1afb71bdd"/>
							<gml:surfaceMember xlink:href="#poly-3d5ad921-a2be-483b-a878-0752daaeac63"/>
							<gml:surfaceMember xlink:href="#poly-f73db020-2df6-4387-9e62-9abc15f081f8"/>
							<gml:surfaceMember xlink:href="#poly-fedaeb4d-6ea4-4cd4-887c-e90094fe01ac"/>
							<gml:surfaceMember xlink:href="#poly-6c2aa666-5639-440c-8b44-ffd6aa5f6d1b"/>
							<gml:surfaceMember xlink:href="#poly-797e88ea-dd4d-4c11-96d6-21a182d3f5cf"/>
							<gml:surfaceMember xlink:href="#poly-d8a72595-99f7-4990-a663-b51ffb1b75e3"/>
							<gml:surfaceMember xlink:href="#poly-a4664956-1939-47db-98ec-e560d21d9585"/>
							<gml:surfaceMember xlink:href="#poly-72150e07-b10b-4ae7-aafb-064565bd1553"/>
							<gml:surfaceMember xlink:href="#poly-8c97bdf8-c920-4ee1-a489-0957a2dabc7a"/>
							<gml:surfaceMember xlink:href="#poly-9a185d08-5ba9-4fa7-94af-52912d222e97"/>
							<gml:surfaceMember xlink:href="#poly-b4e615b8-5764-4173-9e77-10993ec3424a"/>
							<gml:surfaceMember xlink:href="#poly-a559bb11-c8ae-4862-b295-1fe98d45b04b"/>
							<gml:surfaceMember xlink:href="#poly-294dc077-487b-4985-b4b5-f50e86a4919d"/>
							<gml:surfaceMember xlink:href="#poly-88dcda6a-ea2f-463a-a2d2-c65e28078732"/>
							<gml:surfaceMember xlink:href="#poly-9ce6399e-3bd9-47bc-aece-0cbe0514c2f0"/>
							<gml:surfaceMember xlink:href="#poly-06bedcae-8a66-4d19-af2f-c1fa9ce8d516"/>
							<gml:surfaceMember xlink:href="#poly-2b8f5189-1899-4a20-a730-7bbd175b0909"/>
							<gml:surfaceMember xlink:href="#poly-81fddba8-1106-4097-afb1-1ee883b3400f"/>
							<gml:surfaceMember xlink:href="#poly-7e3d9f9c-0167-4e87-80db-460cd1b2838a"/>
							<gml:surfaceMember xlink:href="#poly-c5da1356-8cf5-4fb0-a582-bcfe345aeee0"/>
							<gml:surfaceMember xlink:href="#poly-93935e5e-5764-41cf-9b72-535afb5783dd"/>
							<gml:surfaceMember xlink:href="#poly-adc79e45-77a1-4147-9e3a-d0bf54a2f579"/>
							<gml:surfaceMember xlink:href="#poly-6059b348-0399-4ffd-b31d-57acc6a437e1"/>
							<gml:surfaceMember xlink:href="#poly-ac41763b-1057-4bab-ac06-a1734bdd25a5"/>
							<gml:surfaceMember xlink:href="#poly-44c95eca-c2c3-40c4-a300-7400eda5a701"/>
							<gml:surfaceMember xlink:href="#poly-794a3681-14d4-427f-8dfb-1dfb35802bfe"/>
							<gml:surfaceMember xlink:href="#poly-ef21aa9b-2396-4c37-8a77-269adc4e6baf"/>
							<gml:surfaceMember xlink:href="#poly-413ebf34-b23f-4cd4-ab05-06962360cb7d"/>
							<gml:surfaceMember xlink:href="#poly-7729ff41-ad4a-4612-8027-601bfa0a96ea"/>
							<gml:surfaceMember xlink:href="#poly-b201a51c-eb1f-4d1c-a571-86657ffb69f0"/>
							<gml:surfaceMember xlink:href="#poly-808920a2-3237-4965-94a1-9976cdb3558f"/>
							<gml:surfaceMember xlink:href="#poly-21517396-6bca-4dc4-8550-0da535c2de85"/>
							<gml:surfaceMember xlink:href="#poly-264b8f45-400d-4d11-92f7-fd5bdbf3d134"/>
							<gml:surfaceMember xlink:href="#poly-c2f5c1b9-7767-40ab-b18d-b761dc7261d2"/>
							<gml:surfaceMember xlink:href="#poly-07a38269-5add-4ea3-9c3c-ff171813f745"/>
							<gml:surfaceMember xlink:href="#poly-35ed593b-cb1d-4bc3-8f45-b72ad8b43d2f"/>
							<gml:surfaceMember xlink:href="#poly-45f489ee-0bc0-40e3-b12b-d38b49c8b528"/>
							<gml:surfaceMember xlink:href="#poly-30ba9cc0-8c83-4a80-8269-456319e65dcc"/>
							<gml:surfaceMember xlink:href="#poly-94921c4e-07be-4fdf-9061-bd1f644096db"/>
							<gml:surfaceMember xlink:href="#poly-6d749d6f-08c5-4ad3-86f2-0a64e8e335c7"/>
							<gml:surfaceMember xlink:href="#poly-a0f2b732-3375-41ae-bc2f-2b117842f3b4"/>
							<gml:surfaceMember xlink:href="#poly-35eaac2c-b166-454e-b3e9-9f52921a0f60"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c9103f95-2f31-4697-9235-cafd1f524236_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d1321e3-d9e4-4683-b7eb-2898fed11e8f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67321721232293 139.73750879633246 9.83 35.67320934591438 139.7375120313565 9.83 35.67320158426332 139.73748833452717 9.83 35.67320052756558 139.73748570668832 9.83 35.67324279466417 139.73747656475925 9.83 35.67324606671243 139.73749929486087 9.83 35.67321721232293 139.73750879633246 9.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6dfa1a23-312f-4d68-9907-a5985d0246b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6dfa1a23-312f-4d68-9907-a5985d0246b7_0">
											<gml:posList>35.67320158426332 139.73748833452717 21.989 35.67320052756558 139.73748570668832 21.989 35.67320052756558 139.73748570668832 9.83 35.67320158426332 139.73748833452717 9.83 35.67320158426332 139.73748833452717 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c34fbb5c-1da6-4019-b45e-dd18940b814e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c34fbb5c-1da6-4019-b45e-dd18940b814e_0">
											<gml:posList>35.67320934591438 139.7375120313565 21.989 35.67320158426332 139.73748833452717 21.989 35.67320158426332 139.73748833452717 9.83 35.67320934591438 139.7375120313565 9.83 35.67320934591438 139.7375120313565 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a360870-7e18-46af-97a0-2eb41e0e1b4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a360870-7e18-46af-97a0-2eb41e0e1b4a_0">
											<gml:posList>35.67321721232293 139.73750879633246 21.989 35.67320934591438 139.7375120313565 21.989 35.67320934591438 139.7375120313565 9.83 35.67321721232293 139.73750879633246 9.83 35.67321721232293 139.73750879633246 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eeecc5de-6a41-4f9b-964d-11f0bd5d281c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eeecc5de-6a41-4f9b-964d-11f0bd5d281c_0">
											<gml:posList>35.67320052756558 139.73748570668832 21.989 35.67324279466417 139.73747656475925 21.989 35.67324279466417 139.73747656475925 9.83 35.67320052756558 139.73748570668832 9.83 35.67320052756558 139.73748570668832 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca0ac52b-26d7-423a-8512-da18e316db2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca0ac52b-26d7-423a-8512-da18e316db2b_0">
											<gml:posList>35.67320158426332 139.73748833452717 21.989 35.67320934591438 139.7375120313565 21.989 35.67321721232293 139.73750879633246 21.989 35.67324606671243 139.73749929486087 21.989 35.67324279466417 139.73747656475925 21.989 35.67320052756558 139.73748570668832 21.989 35.67320158426332 139.73748833452717 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c67033d-87d6-441a-a746-01dc553749b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c67033d-87d6-441a-a746-01dc553749b4_0">
											<gml:posList>35.67324606671243 139.73749929486087 21.989 35.67321721232293 139.73750879633246 21.989 35.67321721232293 139.73750879633246 9.83 35.67324606671243 139.73749929486087 9.83 35.67324606671243 139.73749929486087 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de77b7a4-c8b2-4ea2-8cd0-f8100cfc08f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de77b7a4-c8b2-4ea2-8cd0-f8100cfc08f2_0">
											<gml:posList>35.67324279466417 139.73747656475925 21.989 35.67324606671243 139.73749929486087 21.989 35.67324606671243 139.73749929486087 9.83 35.67324279466417 139.73747656475925 9.83 35.67324279466417 139.73747656475925 21.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c9103f95-2f31-4697-9235-cafd1f524236_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63189ea8-e8e1-4d03-82eb-2a9e3cf709e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63189ea8-e8e1-4d03-82eb-2a9e3cf709e7_0">
											<gml:posList>35.673100655121 139.73750790831357 30.252 35.673114045470605 139.73754813520256 27.187 35.673114045470605 139.73754813520256 30.252 35.673100655121 139.73750790831357 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c43af3e2-ec1e-4c86-a27c-b70d1b62023f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c43af3e2-ec1e-4c86-a27c-b70d1b62023f_0">
											<gml:posList>35.673100655121 139.73750790831357 30.252 35.673100655121 139.73750790831357 27.187 35.673114045470605 139.73754813520256 27.187 35.673100655121 139.73750790831357 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2163150a-0dbc-4ab8-9e36-03216c68fa50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2163150a-0dbc-4ab8-9e36-03216c68fa50_0">
											<gml:posList>35.67311059739367 139.73753072982495 32.562 35.67310697761405 139.73751277232236 30.252 35.67311059739367 139.73753072982495 30.252 35.67311059739367 139.73753072982495 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7dfb1718-8258-4c6e-bb8e-d767780518a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7dfb1718-8258-4c6e-bb8e-d767780518a5_0">
											<gml:posList>35.67311059739367 139.73753072982495 32.562 35.67310697761405 139.73751277232236 32.562 35.67310697761405 139.73751277232236 30.252 35.67311059739367 139.73753072982495 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90f50661-b645-4ee2-873a-a126fc104b51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90f50661-b645-4ee2-873a-a126fc104b51_0">
											<gml:posList>35.67312410980377 139.73754310800456 30.252 35.673114045470605 139.73754813520256 27.187 35.67312410980377 139.73754310800456 27.187 35.67312410980377 139.73754310800456 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c628066-4fcb-49e0-864d-51b37945b8e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c628066-4fcb-49e0-864d-51b37945b8e8_0">
											<gml:posList>35.67312410980377 139.73754310800456 30.252 35.673114045470605 139.73754813520256 30.252 35.673114045470605 139.73754813520256 27.187 35.67312410980377 139.73754310800456 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e60304f-a5d0-4958-a666-ed1c628e2ddb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e60304f-a5d0-4958-a666-ed1c628e2ddb_0">
											<gml:posList>35.67316450641846 139.7374941452025 30.252 35.673100655121 139.73750790831357 27.187 35.673100655121 139.73750790831357 30.252 35.67316450641846 139.7374941452025 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46be0e64-8f03-48db-8a4c-1b09fcb180ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46be0e64-8f03-48db-8a4c-1b09fcb180ed_0">
											<gml:posList>35.67316450641846 139.7374941452025 30.252 35.67316450641846 139.7374941452025 27.187 35.673100655121 139.73750790831357 27.187 35.67316450641846 139.7374941452025 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28e13e35-1fac-4342-ac14-f336aceca658">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28e13e35-1fac-4342-ac14-f336aceca658_0">
											<gml:posList>35.67310697761405 139.73751277232236 32.562 35.67315873996029 139.73749706840954 30.252 35.67310697761405 139.73751277232236 30.252 35.67310697761405 139.73751277232236 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48ac9059-2b53-40fa-a9e0-ff81a6aab0ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48ac9059-2b53-40fa-a9e0-ff81a6aab0ea_0">
											<gml:posList>35.67310697761405 139.73751277232236 32.562 35.67315873996029 139.73749706840954 32.562 35.67315873996029 139.73749706840954 30.252 35.67310697761405 139.73751277232236 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd4b312d-dd49-4810-b9af-3a52890e1f6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd4b312d-dd49-4810-b9af-3a52890e1f6f_0">
											<gml:posList>35.67312410980377 139.73754310800456 27.187 35.67314223534574 139.73759844105888 30.252 35.67312410980377 139.73754310800456 30.252 35.67312410980377 139.73754310800456 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32f6b30c-a3fd-4b40-bd19-821a974c7a77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32f6b30c-a3fd-4b40-bd19-821a974c7a77_0">
											<gml:posList>35.67312410980377 139.73754310800456 27.187 35.67314223534574 139.73759844105888 27.187 35.67314223534574 139.73759844105888 30.252 35.67312410980377 139.73754310800456 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d66bce6-0962-4c64-b9d9-9f2f69c42b9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d66bce6-0962-4c64-b9d9-9f2f69c42b9a_0">
											<gml:posList>35.67316236875595 139.73751502591227 32.562 35.67310697761405 139.73751277232236 32.562 35.67311059739367 139.73753072982495 32.562 35.67316236875595 139.73751502591227 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e05716e1-9e5a-4f11-9a57-e1745ae7988a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e05716e1-9e5a-4f11-9a57-e1745ae7988a_0">
											<gml:posList>35.67316236875595 139.73751502591227 32.562 35.67315873996029 139.73749706840954 32.562 35.67310697761405 139.73751277232236 32.562 35.67316236875595 139.73751502591227 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b441326-8892-46ff-979d-dab80db1250d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b441326-8892-46ff-979d-dab80db1250d_0">
											<gml:posList>35.67311059739367 139.73753072982495 32.562 35.67316236875595 139.73751502591227 30.252 35.67316236875595 139.73751502591227 32.562 35.67311059739367 139.73753072982495 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efdaea3c-9ef7-4d47-90ae-21977ab5ce19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efdaea3c-9ef7-4d47-90ae-21977ab5ce19_0">
											<gml:posList>35.67311059739367 139.73753072982495 32.562 35.67311059739367 139.73753072982495 30.252 35.67316236875595 139.73751502591227 30.252 35.67311059739367 139.73753072982495 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ce52c09-d22c-4f52-a042-cad107e89ea8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ce52c09-d22c-4f52-a042-cad107e89ea8_0">
											<gml:posList>35.67313077722183 139.73753966453353 32.562 35.67314679622735 139.73758702443297 30.252 35.67314679622735 139.73758702443297 32.562 35.67313077722183 139.73753966453353 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f9a5f9c-dc62-4d77-a51a-98488ea53740">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f9a5f9c-dc62-4d77-a51a-98488ea53740_0">
											<gml:posList>35.67313077722183 139.73753966453353 32.562 35.67313077722183 139.73753966453353 30.252 35.67314679622735 139.73758702443297 30.252 35.67313077722183 139.73753966453353 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b2ad82d-fa9f-43b9-b9c6-f755cc8dcfd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b2ad82d-fa9f-43b9-b9c6-f755cc8dcfd0_0">
											<gml:posList>35.67313077722183 139.73753966453353 32.562 35.67315046425014 139.73752965484638 30.252 35.67313077722183 139.73753966453353 30.252 35.67313077722183 139.73753966453353 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afbb282b-8316-4814-8120-aadd08a4c5d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afbb282b-8316-4814-8120-aadd08a4c5d7_0">
											<gml:posList>35.67313077722183 139.73753966453353 32.562 35.67315046425014 139.73752965484638 32.562 35.67315046425014 139.73752965484638 30.252 35.67313077722183 139.73753966453353 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79a52971-949f-4141-bd34-0687e756bbad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79a52971-949f-4141-bd34-0687e756bbad_0">
											<gml:posList>35.67313077722183 139.73753966453353 32.562 35.67314679622735 139.73758702443297 32.562 35.673166483259564 139.7375770147554 32.562 35.67313077722183 139.73753966453353 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f430d51-f10b-4206-88f1-ec09e1a12b0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f430d51-f10b-4206-88f1-ec09e1a12b0e_0">
											<gml:posList>35.67315046425014 139.73752965484638 32.562 35.67313077722183 139.73753966453353 32.562 35.673166483259564 139.7375770147554 32.562 35.67315046425014 139.73752965484638 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d90557d1-bf66-4e0f-a266-d6b990447711">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d90557d1-bf66-4e0f-a266-d6b990447711_0">
											<gml:posList>35.67314679622735 139.73758702443297 32.562 35.673166483259564 139.7375770147554 30.252 35.673166483259564 139.7375770147554 32.562 35.67314679622735 139.73758702443297 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30cd9fcb-20c9-48a5-9a85-62cbf95d6ca1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30cd9fcb-20c9-48a5-9a85-62cbf95d6ca1_0">
											<gml:posList>35.67314679622735 139.73758702443297 32.562 35.67314679622735 139.73758702443297 30.252 35.673166483259564 139.7375770147554 30.252 35.67314679622735 139.73758702443297 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e1b0b1f-26ee-49ac-a090-1a5bfc17ac07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e1b0b1f-26ee-49ac-a090-1a5bfc17ac07_0">
											<gml:posList>35.673166483259564 139.7375770147554 32.562 35.67315046425014 139.73752965484638 30.252 35.67315046425014 139.73752965484638 32.562 35.673166483259564 139.7375770147554 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-861bbd5b-1706-45a7-8c2b-324b09d16234">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-861bbd5b-1706-45a7-8c2b-324b09d16234_0">
											<gml:posList>35.673166483259564 139.7375770147554 32.562 35.673166483259564 139.7375770147554 30.252 35.67315046425014 139.73752965484638 30.252 35.673166483259564 139.7375770147554 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e31bf491-d44a-43f2-ab9c-98441111c3f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e31bf491-d44a-43f2-ab9c-98441111c3f5_0">
											<gml:posList>35.67315873996029 139.73749706840954 32.562 35.67316236875595 139.73751502591227 30.252 35.67315873996029 139.73749706840954 30.252 35.67315873996029 139.73749706840954 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1e9d5e3-ef65-4cba-9f68-431f2fcf78fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1e9d5e3-ef65-4cba-9f68-431f2fcf78fa_0">
											<gml:posList>35.67315873996029 139.73749706840954 32.562 35.67316236875595 139.73751502591227 32.562 35.67316236875595 139.73751502591227 30.252 35.67315873996029 139.73749706840954 32.562</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3b9ef3b-3d6b-4ec0-9f76-82e9d0f130ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3b9ef3b-3d6b-4ec0-9f76-82e9d0f130ff_0">
											<gml:posList>35.67311059739367 139.73753072982495 30.252 35.673100655121 139.73750790831357 30.252 35.673114045470605 139.73754813520256 30.252 35.67311059739367 139.73753072982495 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8b08123-853f-4d06-8c96-f3747dd670f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8b08123-853f-4d06-8c96-f3747dd670f3_0">
											<gml:posList>35.67316450641846 139.7374941452025 30.252 35.673100655121 139.73750790831357 30.252 35.67315873996029 139.73749706840954 30.252 35.67316450641846 139.7374941452025 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae5b0634-005c-47d8-91a8-a50091136b81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae5b0634-005c-47d8-91a8-a50091136b81_0">
											<gml:posList>35.67314679622735 139.73758702443297 30.252 35.67312410980377 139.73754310800456 30.252 35.67314223534574 139.73759844105888 30.252 35.67314679622735 139.73758702443297 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-508785e9-ec56-4a2e-8286-dd0b47c7ec0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-508785e9-ec56-4a2e-8286-dd0b47c7ec0c_0">
											<gml:posList>35.67312410980377 139.73754310800456 30.252 35.67311059739367 139.73753072982495 30.252 35.673114045470605 139.73754813520256 30.252 35.67312410980377 139.73754310800456 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5d16ad8-c346-4946-9d06-033e7cbc95aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5d16ad8-c346-4946-9d06-033e7cbc95aa_0">
											<gml:posList>35.6732214620348 139.7375594511926 30.252 35.673166483259564 139.7375770147554 30.252 35.67314223534574 139.73759844105888 30.252 35.6732214620348 139.7375594511926 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df5ce878-bda3-4cec-a81c-6c4e71be7c51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df5ce878-bda3-4cec-a81c-6c4e71be7c51_0">
											<gml:posList>35.673201214955895 139.7374886553215 30.252 35.67316549983536 139.73749654113644 30.252 35.67318212798158 139.73752778326454 30.252 35.673201214955895 139.7374886553215 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62fd4a99-00cf-468a-ad56-f76d360fdf2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62fd4a99-00cf-468a-ad56-f76d360fdf2b_0">
											<gml:posList>35.67316450641846 139.7374941452025 30.252 35.67315873996029 139.73749706840954 30.252 35.67316549983536 139.73749654113644 30.252 35.67316450641846 139.7374941452025 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15014c19-2247-49ea-9d3e-61a4027946a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15014c19-2247-49ea-9d3e-61a4027946a7_0">
											<gml:posList>35.6732096452395 139.73751438393495 30.252 35.673201214955895 139.7374886553215 30.252 35.67318212798158 139.73752778326454 30.252 35.6732096452395 139.73751438393495 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8052288-c3ba-485a-876f-ba3abda79ac1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8052288-c3ba-485a-876f-ba3abda79ac1_0">
											<gml:posList>35.6732214620348 139.7375594511926 30.252 35.67320984216629 139.7375239832376 30.252 35.67318491095663 139.73753626376256 30.252 35.6732214620348 139.7375594511926 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a57380b3-ca74-47e1-bf65-a2ac277abd2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a57380b3-ca74-47e1-bf65-a2ac277abd2b_0">
											<gml:posList>35.67318491095663 139.73753626376256 30.252 35.67318212798158 139.73752778326454 30.252 35.67315046425014 139.73752965484638 30.252 35.67318491095663 139.73753626376256 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ac8b4e3-152a-4491-bf62-54c0d555d2d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ac8b4e3-152a-4491-bf62-54c0d555d2d3_0">
											<gml:posList>35.673100655121 139.73750790831357 30.252 35.67311059739367 139.73753072982495 30.252 35.67310697761405 139.73751277232236 30.252 35.673100655121 139.73750790831357 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37b084ff-66c2-4c08-9672-4c47bd9abdfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37b084ff-66c2-4c08-9672-4c47bd9abdfb_0">
											<gml:posList>35.67315873996029 139.73749706840954 30.252 35.673100655121 139.73750790831357 30.252 35.67310697761405 139.73751277232236 30.252 35.67315873996029 139.73749706840954 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a68ef6d0-2e64-471b-b37c-64c29c084df7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a68ef6d0-2e64-471b-b37c-64c29c084df7_0">
											<gml:posList>35.673166483259564 139.7375770147554 30.252 35.67314679622735 139.73758702443297 30.252 35.67314223534574 139.73759844105888 30.252 35.673166483259564 139.7375770147554 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca65d63e-10da-475b-8e53-8b59a9092ace">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca65d63e-10da-475b-8e53-8b59a9092ace_0">
											<gml:posList>35.67314679622735 139.73758702443297 30.252 35.67313077722183 139.73753966453353 30.252 35.67312410980377 139.73754310800456 30.252 35.67314679622735 139.73758702443297 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f88c0df-1e97-4e39-b7dc-9be9315b4d83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f88c0df-1e97-4e39-b7dc-9be9315b4d83_0">
											<gml:posList>35.67312410980377 139.73754310800456 30.252 35.67316236875595 139.73751502591227 30.252 35.67311059739367 139.73753072982495 30.252 35.67312410980377 139.73754310800456 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba211381-8279-4172-b5df-54de71ca6b00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba211381-8279-4172-b5df-54de71ca6b00_0">
											<gml:posList>35.67316549983536 139.73749654113644 30.252 35.67316236875595 139.73751502591227 30.252 35.67318212798158 139.73752778326454 30.252 35.67316549983536 139.73749654113644 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e0e84e1-5dbd-48c8-9055-8442bfd7ec3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e0e84e1-5dbd-48c8-9055-8442bfd7ec3b_0">
											<gml:posList>35.67316549983536 139.73749654113644 30.252 35.67315873996029 139.73749706840954 30.252 35.67316236875595 139.73751502591227 30.252 35.67316549983536 139.73749654113644 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fc17b52-732f-48c5-8340-bb77480af0f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fc17b52-732f-48c5-8340-bb77480af0f4_0">
											<gml:posList>35.6732214620348 139.7375594511926 30.252 35.67318491095663 139.73753626376256 30.252 35.673166483259564 139.7375770147554 30.252 35.6732214620348 139.7375594511926 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aec18c22-dd24-43d1-9e25-25df6e0ccd42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aec18c22-dd24-43d1-9e25-25df6e0ccd42_0">
											<gml:posList>35.67318212798158 139.73752778326454 30.252 35.67316236875595 139.73751502591227 30.252 35.67315046425014 139.73752965484638 30.252 35.67318212798158 139.73752778326454 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1309f423-c5f5-414d-9c4a-73e386934e6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1309f423-c5f5-414d-9c4a-73e386934e6d_0">
											<gml:posList>35.673166483259564 139.7375770147554 30.252 35.67318491095663 139.73753626376256 30.252 35.67315046425014 139.73752965484638 30.252 35.673166483259564 139.7375770147554 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e028b3a6-236f-4f1f-836c-2b3aaad86a2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e028b3a6-236f-4f1f-836c-2b3aaad86a2c_0">
											<gml:posList>35.67313077722183 139.73753966453353 30.252 35.67316236875595 139.73751502591227 30.252 35.67312410980377 139.73754310800456 30.252 35.67313077722183 139.73753966453353 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87b6d820-84c0-4685-8cd3-e9fa4532606a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87b6d820-84c0-4685-8cd3-e9fa4532606a_0">
											<gml:posList>35.67315046425014 139.73752965484638 30.252 35.67316236875595 139.73751502591227 30.252 35.67313077722183 139.73753966453353 30.252 35.67315046425014 139.73752965484638 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be463acf-af53-49a9-9055-330d46342a37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be463acf-af53-49a9-9055-330d46342a37_0">
											<gml:posList>35.67316450641846 139.7374941452025 30.252 35.67316549983536 139.73749654113644 27.187 35.67316450641846 139.7374941452025 27.187 35.67316450641846 139.7374941452025 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-959f7762-cd82-44fc-9ef4-11c55a698af5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-959f7762-cd82-44fc-9ef4-11c55a698af5_0">
											<gml:posList>35.67316450641846 139.7374941452025 30.252 35.67316549983536 139.73749654113644 30.252 35.67316549983536 139.73749654113644 27.187 35.67316450641846 139.7374941452025 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09988587-ed8b-4c0a-95c0-0b79248a9661">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09988587-ed8b-4c0a-95c0-0b79248a9661_0">
											<gml:posList>35.6732214620348 139.7375594511926 30.252 35.67314223534574 139.73759844105888 27.187 35.6732214620348 139.7375594511926 27.187 35.6732214620348 139.7375594511926 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d8ab695-110f-42c3-9e4b-e692626d4b82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d8ab695-110f-42c3-9e4b-e692626d4b82_0">
											<gml:posList>35.6732214620348 139.7375594511926 30.252 35.67314223534574 139.73759844105888 30.252 35.67314223534574 139.73759844105888 27.187 35.6732214620348 139.7375594511926 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d09aff93-48ab-4c07-8296-7c7c677bfc82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d09aff93-48ab-4c07-8296-7c7c677bfc82_0">
											<gml:posList>35.67316549983536 139.73749654113644 30.252 35.673201214955895 139.7374886553215 27.187 35.67316549983536 139.73749654113644 27.187 35.67316549983536 139.73749654113644 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f9ba4f5-e5d8-4307-93eb-f2de034178e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f9ba4f5-e5d8-4307-93eb-f2de034178e3_0">
											<gml:posList>35.67316549983536 139.73749654113644 30.252 35.673201214955895 139.7374886553215 30.252 35.673201214955895 139.7374886553215 27.187 35.67316549983536 139.73749654113644 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eba967d9-665a-4e13-b10e-02f4a518797d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eba967d9-665a-4e13-b10e-02f4a518797d_0">
											<gml:posList>35.67318491095663 139.73753626376256 30.252 35.67318212798158 139.73752778326454 27.187 35.67318212798158 139.73752778326454 30.252 35.67318491095663 139.73753626376256 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86274798-6895-4ef2-b7a6-4fc457bffce5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86274798-6895-4ef2-b7a6-4fc457bffce5_0">
											<gml:posList>35.67318491095663 139.73753626376256 30.252 35.67318491095663 139.73753626376256 27.187 35.67318212798158 139.73752778326454 27.187 35.67318491095663 139.73753626376256 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6151ac7-e787-4753-a523-5714b1167d0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6151ac7-e787-4753-a523-5714b1167d0a_0">
											<gml:posList>35.67318212798158 139.73752778326454 30.252 35.6732096452395 139.73751438393495 27.187 35.6732096452395 139.73751438393495 30.252 35.67318212798158 139.73752778326454 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd0749e5-aac4-40f8-85ac-1558b9f8564d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd0749e5-aac4-40f8-85ac-1558b9f8564d_0">
											<gml:posList>35.67318212798158 139.73752778326454 30.252 35.67318212798158 139.73752778326454 27.187 35.6732096452395 139.73751438393495 27.187 35.67318212798158 139.73752778326454 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4131c0f9-db35-4995-919d-498620001a40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4131c0f9-db35-4995-919d-498620001a40_0">
											<gml:posList>35.67320984216629 139.7375239832376 30.252 35.67318491095663 139.73753626376256 27.187 35.67318491095663 139.73753626376256 30.252 35.67320984216629 139.7375239832376 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e24bbaca-214c-4221-8045-dfd7828b708c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e24bbaca-214c-4221-8045-dfd7828b708c_0">
											<gml:posList>35.67320984216629 139.7375239832376 30.252 35.67320984216629 139.7375239832376 27.187 35.67318491095663 139.73753626376256 27.187 35.67320984216629 139.7375239832376 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b4cde27-6938-4bab-b51e-9474314df27f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b4cde27-6938-4bab-b51e-9474314df27f_0">
											<gml:posList>35.6732096452395 139.73751438393495 30.252 35.673201214955895 139.7374886553215 27.187 35.673201214955895 139.7374886553215 30.252 35.6732096452395 139.73751438393495 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff84dbd2-1f36-4cd2-ab62-d901a3ab54dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff84dbd2-1f36-4cd2-ab62-d901a3ab54dc_0">
											<gml:posList>35.6732096452395 139.73751438393495 30.252 35.6732096452395 139.73751438393495 27.187 35.673201214955895 139.7374886553215 27.187 35.6732096452395 139.73751438393495 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12a16b1f-cb11-4eb9-922a-e6a65b76d59c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12a16b1f-cb11-4eb9-922a-e6a65b76d59c_0">
											<gml:posList>35.6732214620348 139.7375594511926 30.252 35.67320984216629 139.7375239832376 27.187 35.67320984216629 139.7375239832376 30.252 35.6732214620348 139.7375594511926 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-679cbc29-f25d-47ef-9368-e7e959f3177b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-679cbc29-f25d-47ef-9368-e7e959f3177b_0">
											<gml:posList>35.6732214620348 139.7375594511926 30.252 35.6732214620348 139.7375594511926 27.187 35.67320984216629 139.7375239832376 27.187 35.6732214620348 139.7375594511926 30.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f24a174-0b56-4206-84f5-8e47ad84bc2e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6732214620348 139.7375594511926 27.187 35.67314223534574 139.73759844105888 27.187 35.67318491095663 139.73753626376256 27.187 35.6732214620348 139.7375594511926 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9d32c68-64b6-4879-98a8-830c9719216e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6732214620348 139.7375594511926 27.187 35.67318491095663 139.73753626376256 27.187 35.67320984216629 139.7375239832376 27.187 35.6732214620348 139.7375594511926 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb680fa2-8297-4d8f-b004-ca0dbcf58f44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673201214955895 139.7374886553215 27.187 35.6732096452395 139.73751438393495 27.187 35.67318212798158 139.73752778326454 27.187 35.673201214955895 139.7374886553215 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6757674a-13ed-4aec-aca5-0ccc96fcfa3a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67312410980377 139.73754310800456 27.187 35.673114045470605 139.73754813520256 27.187 35.673100655121 139.73750790831357 27.187 35.67312410980377 139.73754310800456 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4146ab5a-ac88-407c-a803-630f033d7d5e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67318491095663 139.73753626376256 27.187 35.67314223534574 139.73759844105888 27.187 35.67312410980377 139.73754310800456 27.187 35.67318491095663 139.73753626376256 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eaff6a3b-4520-46b5-b109-b38258aca02b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67316450641846 139.7374941452025 27.187 35.67312410980377 139.73754310800456 27.187 35.673100655121 139.73750790831357 27.187 35.67316450641846 139.7374941452025 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7901124e-664f-425f-83aa-788727c3aed9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67318212798158 139.73752778326454 27.187 35.67318491095663 139.73753626376256 27.187 35.67312410980377 139.73754310800456 27.187 35.67318212798158 139.73752778326454 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df2eaaca-1a00-4c8c-8a89-b4a7e4207e9a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67316549983536 139.73749654113644 27.187 35.67312410980377 139.73754310800456 27.187 35.67316450641846 139.7374941452025 27.187 35.67316549983536 139.73749654113644 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43f027a4-a123-4d2b-a552-2c41d1bbcb5f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673201214955895 139.7374886553215 27.187 35.67318212798158 139.73752778326454 27.187 35.67316549983536 139.73749654113644 27.187 35.673201214955895 139.7374886553215 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f953bdad-3622-49fd-8db4-63d8dfa1d48e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67318212798158 139.73752778326454 27.187 35.67312410980377 139.73754310800456 27.187 35.67316549983536 139.73749654113644 27.187 35.67318212798158 139.73752778326454 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_c9103f95-2f31-4697-9235-cafd1f524236_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e20aab1e-bfc8-4cd1-9e47-24fa0d53a840">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67322379372828 139.73764655124978 26.588 35.673217045008236 139.73764977387998 26.588 35.673212960606826 139.7376369425481 26.588 35.67321970931775 139.7376337088704 26.588 35.67322379372828 139.73764655124978 26.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38a1e1dc-8c72-4cce-9167-4ebb03f1c625">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67322373300014 139.73758149759487 26.588 35.67322638919961 139.7375892491716 26.588 35.673213531876996 139.7375958704232 26.588 35.673210875677945 139.73758811884753 26.588 35.67322373300014 139.73758149759487 26.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17345866-4c22-4595-9dde-7d26bf95a40e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673226362600325 139.73763515908618 26.588 35.67321683835425 139.73760524508046 26.588 35.67322399254108 139.73760183416934 26.588 35.67323351677923 139.73763173713064 26.588 35.673226362600325 139.73763515908618 26.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ceab118f-46f3-43f8-8182-cf4f5c88a1ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67322746898279 139.73765494231824 26.588 35.67323176095231 139.73766809375857 26.588 35.67322457981021 139.7376716151628 26.588 35.67322028784107 139.73765846372348 26.588 35.67322746898279 139.73765494231824 26.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-281a22ea-d9a0-434c-89b8-2a6a255f0140">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67323276393238 139.73767118562432 26.588 35.67323898953901 139.73769025576541 26.588 35.67323181740997 139.73769377715726 26.588 35.67322559180389 139.73767470701762 26.588 35.67323276393238 139.73767118562432 26.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c784611-b5b4-4288-a5a3-597666c4faa5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67325203895407 139.73768715818053 26.588 35.673245335354196 139.73769044703454 26.588 35.673236977314495 139.73766483981802 26.588 35.67324368091367 139.73766155096223 26.588 35.67325203895407 139.73768715818053 26.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e899717c-bc3e-40dc-8734-036ae11e7efd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67327910237388 139.73764708175497 26.588 35.67324717918407 139.73766273982613 26.588 35.67324074575719 139.73764304027404 26.588 35.67327266894446 139.73762738219634 26.588 35.67327910237388 139.73764708175497 26.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c48add8-72d3-47bb-b4a1-f04e816697d4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67325539075835 139.73768551927665 26.588 35.67325196619635 139.73767499590036 26.588 35.67327092369491 139.7376657051345 26.588 35.67327435726266 139.73767621745546 26.588 35.67325539075835 139.73768551927665 26.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-698a4184-3d34-4bba-b650-038de23cd038">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67333108603475 139.7376376300435 33.757 35.67331351611559 139.7376462453204 33.757 35.673306847758674 139.73762582800077 33.757 35.6733244176764 139.73761721272012 33.757 35.67333108603475 139.7376376300435 33.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f5abf8c-b5f7-4556-a586-5d9f8b641c21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f5abf8c-b5f7-4556-a586-5d9f8b641c21_0">
											<gml:posList>35.67325539075835 139.73768551927665 29.058 35.67325196619635 139.73767499590036 29.058 35.67325196619635 139.73767499590036 26.588 35.67325539075835 139.73768551927665 26.588 35.67325539075835 139.73768551927665 29.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68db9501-22eb-478c-9d3f-a769cd41171e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68db9501-22eb-478c-9d3f-a769cd41171e_0">
											<gml:posList>35.673210875677945 139.73758811884753 28.765 35.673210875677945 139.73758811884753 26.588 35.673213531876996 139.7375958704232 26.588 35.673213531876996 139.7375958704232 28.765 35.673210875677945 139.73758811884753 28.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99b35e85-513f-469c-ba79-ae260b3ff066">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99b35e85-513f-469c-ba79-ae260b3ff066_0">
											<gml:posList>35.673217045008236 139.73764977387998 28.947 35.673212960606826 139.7376369425481 28.947 35.673212960606826 139.7376369425481 26.588 35.673217045008236 139.73764977387998 26.588 35.673217045008236 139.73764977387998 28.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75d36650-f9e7-4405-827c-609ae3369a2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75d36650-f9e7-4405-827c-609ae3369a2f_0">
											<gml:posList>35.673212960606826 139.7376369425481 28.947 35.67321970931775 139.7376337088704 28.947 35.67321970931775 139.7376337088704 26.588 35.673212960606826 139.7376369425481 26.588 35.673212960606826 139.7376369425481 28.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be5f379e-389a-417a-a1a1-674fbb003df3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be5f379e-389a-417a-a1a1-674fbb003df3_0">
											<gml:posList>35.673210875677945 139.73758811884753 28.765 35.67322373300014 139.73758149759487 28.765 35.67322373300014 139.73758149759487 26.588 35.673210875677945 139.73758811884753 26.588 35.673210875677945 139.73758811884753 28.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-103915ac-dec0-4377-b693-9e05d6a8d8d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-103915ac-dec0-4377-b693-9e05d6a8d8d5_0">
											<gml:posList>35.673212960606826 139.7376369425481 28.947 35.673217045008236 139.73764977387998 28.947 35.67322379372828 139.73764655124978 28.947 35.67321970931775 139.7376337088704 28.947 35.673212960606826 139.7376369425481 28.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-255e1425-e06f-409b-ac46-04b3ec150094">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-255e1425-e06f-409b-ac46-04b3ec150094_0">
											<gml:posList>35.673213531876996 139.7375958704232 28.765 35.67322638919961 139.7375892491716 28.765 35.67322373300014 139.73758149759487 28.765 35.673210875677945 139.73758811884753 28.765 35.673213531876996 139.7375958704232 28.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a90b35fb-2e36-408c-a77c-6c486a52bed3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a90b35fb-2e36-408c-a77c-6c486a52bed3_0">
											<gml:posList>35.67322638919961 139.7375892491716 28.765 35.673213531876996 139.7375958704232 28.765 35.673213531876996 139.7375958704232 26.588 35.67322638919961 139.7375892491716 26.588 35.67322638919961 139.7375892491716 28.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c51755eb-e943-46b7-8f9b-f3c6fb3f9728">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c51755eb-e943-46b7-8f9b-f3c6fb3f9728_0">
											<gml:posList>35.67322379372828 139.73764655124978 28.947 35.673217045008236 139.73764977387998 28.947 35.673217045008236 139.73764977387998 26.588 35.67322379372828 139.73764655124978 26.588 35.67322379372828 139.73764655124978 28.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77763753-5431-4540-9bc6-2a27caffc3cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77763753-5431-4540-9bc6-2a27caffc3cc_0">
											<gml:posList>35.67322399254108 139.73760183416934 28.947 35.67322399254108 139.73760183416934 26.588 35.67321683835425 139.73760524508046 26.588 35.67321683835425 139.73760524508046 28.947 35.67322399254108 139.73760183416934 28.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4659cc95-f60f-49d8-949c-1eb2a2326d61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4659cc95-f60f-49d8-949c-1eb2a2326d61_0">
											<gml:posList>35.673226362600325 139.73763515908618 28.947 35.67321683835425 139.73760524508046 28.947 35.67321683835425 139.73760524508046 26.588 35.673226362600325 139.73763515908618 26.588 35.673226362600325 139.73763515908618 28.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76c6ea22-e5b5-4c41-bb44-f31d8a52d6e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76c6ea22-e5b5-4c41-bb44-f31d8a52d6e8_0">
											<gml:posList>35.67321970931775 139.7376337088704 28.947 35.67322379372828 139.73764655124978 28.947 35.67322379372828 139.73764655124978 26.588 35.67321970931775 139.7376337088704 26.588 35.67321970931775 139.7376337088704 28.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5630263b-7a67-4c0b-9a83-443f2f134b29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5630263b-7a67-4c0b-9a83-443f2f134b29_0">
											<gml:posList>35.67322457981021 139.7376716151628 28.947 35.67322028784107 139.73765846372348 28.947 35.67322028784107 139.73765846372348 26.588 35.67322457981021 139.7376716151628 26.588 35.67322457981021 139.7376716151628 28.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7590200-309b-40ef-9a99-23f6f6642aa8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7590200-309b-40ef-9a99-23f6f6642aa8_0">
											<gml:posList>35.67322028784107 139.73765846372348 28.947 35.67322746898279 139.73765494231824 28.947 35.67322746898279 139.73765494231824 26.588 35.67322028784107 139.73765846372348 26.588 35.67322028784107 139.73765846372348 28.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0033e3eb-8f00-4078-ae11-d1c01ae8e5dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0033e3eb-8f00-4078-ae11-d1c01ae8e5dd_0">
											<gml:posList>35.67322638919961 139.7375892491716 28.765 35.67322638919961 139.7375892491716 26.588 35.67322373300014 139.73758149759487 26.588 35.67322373300014 139.73758149759487 28.765 35.67322638919961 139.7375892491716 28.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-057c0a0a-d905-47d4-9168-7c0ecf3e6f50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-057c0a0a-d905-47d4-9168-7c0ecf3e6f50_0">
											<gml:posList>35.673226362600325 139.73763515908618 28.947 35.67323351677923 139.73763173713064 28.947 35.67322399254108 139.73760183416934 28.947 35.67321683835425 139.73760524508046 28.947 35.673226362600325 139.73763515908618 28.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97b7a660-b4a8-4dbf-851b-6427ddc18f8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97b7a660-b4a8-4dbf-851b-6427ddc18f8d_0">
											<gml:posList>35.67322457981021 139.7376716151628 28.947 35.67323176095231 139.73766809375857 28.947 35.67322746898279 139.73765494231824 28.947 35.67322028784107 139.73765846372348 28.947 35.67322457981021 139.7376716151628 28.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfa833c7-fd6e-489d-b1a2-71fb5cc2fa5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfa833c7-fd6e-489d-b1a2-71fb5cc2fa5b_0">
											<gml:posList>35.67323176095231 139.73766809375857 28.947 35.67322457981021 139.7376716151628 28.947 35.67322457981021 139.7376716151628 26.588 35.67323176095231 139.73766809375857 26.588 35.67323176095231 139.73766809375857 28.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45030a78-6f98-4dfd-b26a-9f0f6940d118">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45030a78-6f98-4dfd-b26a-9f0f6940d118_0">
											<gml:posList>35.67322559180389 139.73767470701762 29.219 35.67322559180389 139.73767470701762 26.588 35.67323181740997 139.73769377715726 26.588 35.67323181740997 139.73769377715726 29.219 35.67322559180389 139.73767470701762 29.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14f1497d-6044-45b9-9240-2d39b978fdb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14f1497d-6044-45b9-9240-2d39b978fdb8_0">
											<gml:posList>35.67322399254108 139.73760183416934 28.947 35.67323351677923 139.73763173713064 28.947 35.67323351677923 139.73763173713064 26.588 35.67322399254108 139.73760183416934 26.588 35.67322399254108 139.73760183416934 28.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c9bb284-399c-4a64-a9e4-cea6e59cf4bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c9bb284-399c-4a64-a9e4-cea6e59cf4bd_0">
											<gml:posList>35.67322559180389 139.73767470701762 29.219 35.67323276393238 139.73767118562432 29.219 35.67323276393238 139.73767118562432 26.588 35.67322559180389 139.73767470701762 26.588 35.67322559180389 139.73767470701762 29.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac2e2292-a1b3-4c0e-afd0-bc747dd7544a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac2e2292-a1b3-4c0e-afd0-bc747dd7544a_0">
											<gml:posList>35.67322746898279 139.73765494231824 28.947 35.67323176095231 139.73766809375857 28.947 35.67323176095231 139.73766809375857 26.588 35.67322746898279 139.73765494231824 26.588 35.67322746898279 139.73765494231824 28.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d9907b1-2c95-4217-8903-c584aae1157c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d9907b1-2c95-4217-8903-c584aae1157c_0">
											<gml:posList>35.67323351677923 139.73763173713064 28.947 35.673226362600325 139.73763515908618 28.947 35.673226362600325 139.73763515908618 26.588 35.67323351677923 139.73763173713064 26.588 35.67323351677923 139.73763173713064 28.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ecb91b6-3cde-49d6-b444-b991c8e3a223">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ecb91b6-3cde-49d6-b444-b991c8e3a223_0">
											<gml:posList>35.67323276393238 139.73767118562432 29.219 35.67322559180389 139.73767470701762 29.219 35.67323181740997 139.73769377715726 29.219 35.67323898953901 139.73769025576541 29.219 35.67323276393238 139.73767118562432 29.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17f76917-d558-4f82-8482-eaa87cdd42ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17f76917-d558-4f82-8482-eaa87cdd42ba_0">
											<gml:posList>35.67323181740997 139.73769377715726 29.219 35.67323181740997 139.73769377715726 26.588 35.67323898953901 139.73769025576541 26.588 35.67323898953901 139.73769025576541 29.219 35.67323181740997 139.73769377715726 29.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-294f70aa-7c7a-4b8a-b03e-00f3b7bb142e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-294f70aa-7c7a-4b8a-b03e-00f3b7bb142e_0">
											<gml:posList>35.67323898953901 139.73769025576541 29.219 35.67323898953901 139.73769025576541 26.588 35.67323276393238 139.73767118562432 26.588 35.67323276393238 139.73767118562432 29.219 35.67323898953901 139.73769025576541 29.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d8e3d1f-d1ac-4170-9c9a-147832fe06f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d8e3d1f-d1ac-4170-9c9a-147832fe06f8_0">
											<gml:posList>35.673236977314495 139.73766483981802 29.219 35.67324368091367 139.73766155096223 29.219 35.67324368091367 139.73766155096223 26.588 35.673236977314495 139.73766483981802 26.588 35.673236977314495 139.73766483981802 29.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f61e2f5-728d-43e5-a186-aa14804a0fe7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f61e2f5-728d-43e5-a186-aa14804a0fe7_0">
											<gml:posList>35.673236977314495 139.73766483981802 29.219 35.673236977314495 139.73766483981802 26.588 35.673245335354196 139.73769044703454 26.588 35.673245335354196 139.73769044703454 29.219 35.673236977314495 139.73766483981802 29.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0af4d1cd-8a09-447f-a38a-2024bfd6796c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0af4d1cd-8a09-447f-a38a-2024bfd6796c_0">
											<gml:posList>35.67324074575719 139.73764304027404 30.254 35.67324074575719 139.73764304027404 26.588 35.67324717918407 139.73766273982613 26.588 35.67324717918407 139.73766273982613 30.254 35.67324074575719 139.73764304027404 30.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d02df1a2-b0e2-4ffb-84ff-9bc74c6dbaee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d02df1a2-b0e2-4ffb-84ff-9bc74c6dbaee_0">
											<gml:posList>35.67325203895407 139.73768715818053 29.219 35.67324368091367 139.73766155096223 29.219 35.673236977314495 139.73766483981802 29.219 35.673245335354196 139.73769044703454 29.219 35.67325203895407 139.73768715818053 29.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-964069cd-a35e-412d-af39-60b6ff1b3669">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-964069cd-a35e-412d-af39-60b6ff1b3669_0">
											<gml:posList>35.67324368091367 139.73766155096223 29.219 35.67325203895407 139.73768715818053 29.219 35.67325203895407 139.73768715818053 26.588 35.67324368091367 139.73766155096223 26.588 35.67324368091367 139.73766155096223 29.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b9c70ba-1508-4ce4-8429-4f1642f45c73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b9c70ba-1508-4ce4-8429-4f1642f45c73_0">
											<gml:posList>35.67325203895407 139.73768715818053 29.219 35.673245335354196 139.73769044703454 29.219 35.673245335354196 139.73769044703454 26.588 35.67325203895407 139.73768715818053 26.588 35.67325203895407 139.73768715818053 29.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdaf0a01-c196-4e44-bb57-84d15d45a213">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdaf0a01-c196-4e44-bb57-84d15d45a213_0">
											<gml:posList>35.67327266894446 139.73762738219634 30.254 35.67327266894446 139.73762738219634 26.588 35.67324074575719 139.73764304027404 26.588 35.67324074575719 139.73764304027404 30.254 35.67327266894446 139.73762738219634 30.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26a18c85-a040-4318-a0e4-210834bf343c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26a18c85-a040-4318-a0e4-210834bf343c_0">
											<gml:posList>35.67327910237388 139.73764708175497 30.254 35.67327266894446 139.73762738219634 30.254 35.67324074575719 139.73764304027404 30.254 35.67324717918407 139.73766273982613 30.254 35.67327910237388 139.73764708175497 30.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6abefbf7-a6e8-447e-8e3e-f6831bd539e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6abefbf7-a6e8-447e-8e3e-f6831bd539e2_0">
											<gml:posList>35.67325196619635 139.73767499590036 29.058 35.67327092369491 139.7376657051345 29.058 35.67327092369491 139.7376657051345 26.588 35.67325196619635 139.73767499590036 26.588 35.67325196619635 139.73767499590036 29.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72276d15-fa8d-4dac-a3cc-e714b6077ed4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72276d15-fa8d-4dac-a3cc-e714b6077ed4_0">
											<gml:posList>35.67327910237388 139.73764708175497 30.254 35.67324717918407 139.73766273982613 30.254 35.67324717918407 139.73766273982613 26.588 35.67327910237388 139.73764708175497 26.588 35.67327910237388 139.73764708175497 30.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96b6488d-8faf-4c73-b662-9357cebc82c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96b6488d-8faf-4c73-b662-9357cebc82c2_0">
											<gml:posList>35.67327092369491 139.7376657051345 29.058 35.67325196619635 139.73767499590036 29.058 35.67325539075835 139.73768551927665 29.058 35.67327435726266 139.73767621745546 29.058 35.67327092369491 139.7376657051345 29.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40c561d8-3547-4a6e-9b07-51374f7d15d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40c561d8-3547-4a6e-9b07-51374f7d15d9_0">
											<gml:posList>35.67327435726266 139.73767621745546 29.058 35.67325539075835 139.73768551927665 29.058 35.67325539075835 139.73768551927665 26.588 35.67327435726266 139.73767621745546 26.588 35.67327435726266 139.73767621745546 29.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ae1fbb8-f24d-4e8d-801f-5d71b2caac85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ae1fbb8-f24d-4e8d-801f-5d71b2caac85_0">
											<gml:posList>35.67327092369491 139.7376657051345 29.058 35.67327435726266 139.73767621745546 29.058 35.67327435726266 139.73767621745546 26.588 35.67327092369491 139.7376657051345 26.588 35.67327092369491 139.7376657051345 29.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b42dda1-e24c-45af-8301-263b8dadf130">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b42dda1-e24c-45af-8301-263b8dadf130_0">
											<gml:posList>35.67327266894446 139.73762738219634 30.254 35.67327910237388 139.73764708175497 30.254 35.67327910237388 139.73764708175497 26.588 35.67327266894446 139.73762738219634 26.588 35.67327266894446 139.73762738219634 30.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f114d4c4-5496-45c7-adc9-4ebc3d012520">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f114d4c4-5496-45c7-adc9-4ebc3d012520_0">
											<gml:posList>35.673306847758674 139.73762582800077 34.828 35.673306847758674 139.73762582800077 33.757 35.67331351611559 139.7376462453204 33.757 35.67331351611559 139.7376462453204 34.828 35.673306847758674 139.73762582800077 34.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4e1707f-9e25-40bd-9c53-e4a4fff3db1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4e1707f-9e25-40bd-9c53-e4a4fff3db1b_0">
											<gml:posList>35.6733244176764 139.73761721272012 34.828 35.6733244176764 139.73761721272012 33.757 35.673306847758674 139.73762582800077 33.757 35.673306847758674 139.73762582800077 34.828 35.6733244176764 139.73761721272012 34.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-038342fd-c010-4eb1-ac80-3bff96f0229c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-038342fd-c010-4eb1-ac80-3bff96f0229c_0">
											<gml:posList>35.67333108603475 139.7376376300435 34.828 35.6733244176764 139.73761721272012 34.828 35.673306847758674 139.73762582800077 34.828 35.67331351611559 139.7376462453204 34.828 35.67333108603475 139.7376376300435 34.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4471b96b-0781-4392-89e9-192581ec57aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4471b96b-0781-4392-89e9-192581ec57aa_0">
											<gml:posList>35.67333108603475 139.7376376300435 34.828 35.67331351611559 139.7376462453204 34.828 35.67331351611559 139.7376462453204 33.757 35.67333108603475 139.7376376300435 33.757 35.67333108603475 139.7376376300435 34.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad8b47bb-6896-4b7c-950b-38d45a99e4d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad8b47bb-6896-4b7c-950b-38d45a99e4d1_0">
											<gml:posList>35.6733244176764 139.73761721272012 34.828 35.67333108603475 139.7376376300435 34.828 35.67333108603475 139.7376376300435 33.757 35.6733244176764 139.73761721272012 33.757 35.6733244176764 139.73761721272012 34.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1ade84bd-259b-414f-822d-c30749ece302">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ade84bd-259b-414f-822d-c30749ece302">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ade84bd-259b-414f-822d-c30749ece302">
											<gml:posList>35.67324605769871 139.73749929487164 8.83 35.67324278565045 139.73747656477002 8.83 35.6732784468276 139.73746885574957 8.83 35.67330502916922 139.7375718893206 8.83 35.673321879725314 139.73756546212726 8.83 35.673357328683274 139.73771035208264 8.83 35.67323820513737 139.73775810524364 8.83 35.67318992768466 139.73757666639997 8.83 35.673132172239825 139.73760501477898 8.83 35.67310018600327 139.73750740072913 8.83 35.67320052756558 139.73748570668832 8.83 35.67320158426332 139.73748833452717 8.83 35.67320934591438 139.7375120313565 8.83 35.67321721232293 139.73750879633246 8.83 35.67324605769871 139.73749929487164 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-987e56fe-4e65-4214-bc3e-91f4d31c8870">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-987e56fe-4e65-4214-bc3e-91f4d31c8870">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-987e56fe-4e65-4214-bc3e-91f4d31c8870">
											<gml:posList>35.67320934591438 139.7375120313565 27.187 35.67320158426332 139.73748833452717 27.187 35.67320052756558 139.73748570668832 27.187 35.67310018600327 139.73750740072913 27.187 35.673132172239825 139.73760501477898 27.187 35.67318992768466 139.73757666639997 27.187 35.673192450489 139.73757535988238 27.187 35.67322676063344 139.73755760007185 27.187 35.67322974294383 139.7375560499777 27.187 35.67321721232293 139.73750879633246 27.187 35.67320934591438 139.7375120313565 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3142d0ad-67cb-41de-9f0c-c695349ecbed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3142d0ad-67cb-41de-9f0c-c695349ecbed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3142d0ad-67cb-41de-9f0c-c695349ecbed">
											<gml:posList>35.67322872110073 139.73771068222808 27.187 35.673192450489 139.73757535988238 27.187 35.67318992768466 139.73757666639997 27.187 35.67322686811722 139.73771552287155 27.187 35.67322872110073 139.73771068222808 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-51420b03-83e0-4866-ab5d-b8718cdd4722">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51420b03-83e0-4866-ab5d-b8718cdd4722">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51420b03-83e0-4866-ab5d-b8718cdd4722">
											<gml:posList>35.673248258567845 139.7376258648059 27.187 35.67322974294383 139.7375560499777 27.187 35.67322676063344 139.73755760007185 27.187 35.67324637847635 139.73763061711162 27.187 35.673248258567845 139.7376258648059 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d2ad1aa-1813-41f5-b998-ede735f0ab1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d2ad1aa-1813-41f5-b998-ede735f0ab1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d2ad1aa-1813-41f5-b998-ede735f0ab1a">
											<gml:posList>35.673291334088276 139.73762450987547 26.588 35.67328682962234 139.7376161860717 26.588 35.67328488115772 139.7376142994193 26.588 35.673283393788935 139.73761416863528 26.588 35.67328087051002 139.73761487863416 26.588 35.67324637847635 139.73763061711162 26.588 35.67322676063344 139.73755760007185 26.588 35.673192450489 139.73757535988238 26.588 35.67322872110073 139.73771068222808 26.588 35.673307560788146 139.73767238883195 26.588 35.673305308403265 139.73766236115034 26.588 35.67330807454375 139.73766101015647 26.588 35.67329552391278 139.7376225496145 26.588 35.67329274876777 139.7376239116669 26.588 35.673291334088276 139.73762450987547 26.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d39f02c-7482-4d95-9f06-c734d5fd494a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d39f02c-7482-4d95-9f06-c734d5fd494a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d39f02c-7482-4d95-9f06-c734d5fd494a">
											<gml:posList>35.673248258567845 139.7376258648059 27.187 35.67324637847635 139.73763061711162 27.187 35.67328087051002 139.73761487863416 27.187 35.67328002042802 139.73761136681165 27.187 35.673248258567845 139.7376258648059 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-edc766cb-155f-42fb-a35d-6d4b7d8d21c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edc766cb-155f-42fb-a35d-6d4b7d8d21c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edc766cb-155f-42fb-a35d-6d4b7d8d21c3">
											<gml:posList>35.67331112296181 139.73767459391402 27.187 35.673307560788146 139.73767238883195 27.187 35.67322872110073 139.73771068222808 27.187 35.67322686811722 139.73771552287155 27.187 35.67331112296181 139.73767459391402 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e609f532-4e03-4e9a-9502-851007d76294">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e609f532-4e03-4e9a-9502-851007d76294">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e609f532-4e03-4e9a-9502-851007d76294">
											<gml:posList>35.67330502916922 139.7375718893206 17.347 35.6732784468276 139.73746885574957 17.347 35.67324278565045 139.73747656477002 17.347 35.67324605769871 139.73749929487164 17.347 35.67321721232293 139.73750879633246 17.347 35.673248258567845 139.7376258648059 17.347 35.67328002042802 139.73761136681165 17.347 35.67328317451784 139.73761046826627 17.347 35.67328602305459 139.73761071893824 17.347 35.673289072044625 139.73761367580258 17.347 35.67329255646789 139.73762012289194 17.347 35.67329446673501 139.73761931420503 17.347 35.67333070582088 139.73760155208726 17.347 35.673321879725314 139.73756546212726 17.347 35.67330502916922 139.7375718893206 17.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e4135c0-1a92-44b2-a5d5-aa77eb787361">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e4135c0-1a92-44b2-a5d5-aa77eb787361">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e4135c0-1a92-44b2-a5d5-aa77eb787361">
											<gml:posList>35.67328002042802 139.73761136681165 27.187 35.67328087051002 139.73761487863416 27.187 35.673283393788935 139.73761416863528 27.187 35.67328317451784 139.73761046826627 27.187 35.67328002042802 139.73761136681165 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-084f3a06-0fe4-42ba-a99a-335bd6b25417">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-084f3a06-0fe4-42ba-a99a-335bd6b25417">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-084f3a06-0fe4-42ba-a99a-335bd6b25417">
											<gml:posList>35.67328317451784 139.73761046826627 27.187 35.673283393788935 139.73761416863528 27.187 35.67328488115772 139.7376142994193 27.187 35.67328602305459 139.73761071893824 27.187 35.67328317451784 139.73761046826627 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-73294e13-a7a2-410a-9db0-93fecebd4621">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73294e13-a7a2-410a-9db0-93fecebd4621">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73294e13-a7a2-410a-9db0-93fecebd4621">
											<gml:posList>35.673289072044625 139.73761367580258 27.187 35.67328602305459 139.73761071893824 27.187 35.67328488115772 139.7376142994193 27.187 35.67328682962234 139.7376161860717 27.187 35.673289072044625 139.73761367580258 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ffa7f642-ac77-4fae-a777-b83a55dba352">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffa7f642-ac77-4fae-a777-b83a55dba352">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffa7f642-ac77-4fae-a777-b83a55dba352">
											<gml:posList>35.67329255646789 139.73762012289194 27.187 35.673289072044625 139.73761367580258 27.187 35.67328682962234 139.7376161860717 27.187 35.673291334088276 139.73762450987547 27.187 35.67329255646789 139.73762012289194 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2477b629-e6af-498f-ad23-3845804176e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2477b629-e6af-498f-ad23-3845804176e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2477b629-e6af-498f-ad23-3845804176e1">
											<gml:posList>35.673357328683274 139.73771035208264 20.243 35.67322686811722 139.73771552287155 27.187 35.67323820513737 139.73775810524364 20.243 35.673357328683274 139.73771035208264 20.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1225f374-8ae4-4313-96fc-9ccb185c740f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1225f374-8ae4-4313-96fc-9ccb185c740f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1225f374-8ae4-4313-96fc-9ccb185c740f">
											<gml:posList>35.673357328683274 139.73771035208264 20.243 35.67331112296181 139.73767459391402 27.187 35.67322686811722 139.73771552287155 27.187 35.673357328683274 139.73771035208264 20.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a110d163-b8b7-44eb-ba11-8d495042045a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a110d163-b8b7-44eb-ba11-8d495042045a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a110d163-b8b7-44eb-ba11-8d495042045a">
											<gml:posList>35.67329255646789 139.73762012289194 27.187 35.673291334088276 139.73762450987547 27.187 35.67329274876777 139.7376239116669 27.187 35.67329446673501 139.73761931420503 27.187 35.67329255646789 139.73762012289194 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a2567f9-730a-4c36-b8e0-433db6c515e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a2567f9-730a-4c36-b8e0-433db6c515e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a2567f9-730a-4c36-b8e0-433db6c515e2">
											<gml:posList>35.67329552391278 139.7376225496145 27.187 35.67329446673501 139.73761931420503 27.187 35.67329274876777 139.7376239116669 27.187 35.67329552391278 139.7376225496145 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9734498-7671-46d0-9f96-299e07e703ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9734498-7671-46d0-9f96-299e07e703ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9734498-7671-46d0-9f96-299e07e703ff">
											<gml:posList>35.673308454032714 139.73766215855653 34.828 35.67331001886475 139.73765768279065 34.828 35.6732981098048 139.73762123197463 34.828 35.67329446673501 139.73761931420503 34.828 35.673308454032714 139.73766215855653 34.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e54444ce-c3f6-4315-b690-7e031c68e602">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e54444ce-c3f6-4315-b690-7e031c68e602">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e54444ce-c3f6-4315-b690-7e031c68e602">
											<gml:posList>35.67330807454375 139.73766101015647 27.187 35.673305308403265 139.73766236115034 27.187 35.673307560788146 139.73767238883195 27.187 35.67331112296181 139.73767459391402 27.187 35.67330807454375 139.73766101015647 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f88d932d-09be-4578-aae0-5db7d607a94c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f88d932d-09be-4578-aae0-5db7d607a94c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f88d932d-09be-4578-aae0-5db7d607a94c">
											<gml:posList>35.67329446673501 139.73761931420503 34.828 35.6732981098048 139.73762123197463 34.828 35.67332888869468 139.73760613862328 34.828 35.67333070582088 139.73760155208726 34.828 35.67329446673501 139.73761931420503 34.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-43973430-f796-4fb4-a320-b450c06985ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43973430-f796-4fb4-a320-b450c06985ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43973430-f796-4fb4-a320-b450c06985ec">
											<gml:posList>35.67333813974839 139.73764389613035 33.757 35.67332888869468 139.73760613862328 33.757 35.6732981098048 139.73762123197463 33.757 35.67331001886475 139.73765768279065 33.757 35.67333813974839 139.73764389613035 33.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bf23c335-8e6f-4de3-9c01-2c8d28bea4b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf23c335-8e6f-4de3-9c01-2c8d28bea4b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf23c335-8e6f-4de3-9c01-2c8d28bea4b5">
											<gml:posList>35.67334156657635 139.73764592462686 34.828 35.67333813974839 139.73764389613035 34.828 35.67331001886475 139.73765768279065 34.828 35.673308454032714 139.73766215855653 34.828 35.67334156657635 139.73764592462686 34.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6fee2e4f-b0c8-4750-8354-2f3c89b19287">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fee2e4f-b0c8-4750-8354-2f3c89b19287">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fee2e4f-b0c8-4750-8354-2f3c89b19287">
											<gml:posList>35.673357328683274 139.73771035208264 20.243 35.673308454032714 139.73766215855653 28.913 35.67331112296181 139.73767459391402 27.187 35.673357328683274 139.73771035208264 20.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2b011da0-72b5-4b73-b41d-cf018da3205d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b011da0-72b5-4b73-b41d-cf018da3205d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b011da0-72b5-4b73-b41d-cf018da3205d">
											<gml:posList>35.673357328683274 139.73771035208264 20.243 35.67334156657635 139.73764592462686 28.913 35.673308454032714 139.73766215855653 28.913 35.673357328683274 139.73771035208264 20.243</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-62419ece-64a1-44fa-93a8-89485faf6c19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62419ece-64a1-44fa-93a8-89485faf6c19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62419ece-64a1-44fa-93a8-89485faf6c19">
											<gml:posList>35.67334156657635 139.73764592462686 34.828 35.67333070582088 139.73760155208726 34.828 35.67332888869468 139.73760613862328 34.828 35.67333813974839 139.73764389613035 34.828 35.67334156657635 139.73764592462686 34.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-999968ff-10ee-481a-a7dd-03d1afb71bdd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-999968ff-10ee-481a-a7dd-03d1afb71bdd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-999968ff-10ee-481a-a7dd-03d1afb71bdd">
											<gml:posList>35.67320052756558 139.73748570668832 8.83 35.67310018600327 139.73750740072913 8.83 35.67310018600327 139.73750740072913 27.187 35.67320052756558 139.73748570668832 27.187 35.67320052756558 139.73748570668832 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d5ad921-a2be-483b-a878-0752daaeac63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d5ad921-a2be-483b-a878-0752daaeac63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d5ad921-a2be-483b-a878-0752daaeac63">
											<gml:posList>35.67320158426332 139.73748833452717 8.83 35.67320052756558 139.73748570668832 8.83 35.67320052756558 139.73748570668832 27.187 35.67320158426332 139.73748833452717 27.187 35.67320158426332 139.73748833452717 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f73db020-2df6-4387-9e62-9abc15f081f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f73db020-2df6-4387-9e62-9abc15f081f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f73db020-2df6-4387-9e62-9abc15f081f8">
											<gml:posList>35.67320934591438 139.7375120313565 8.83 35.67320158426332 139.73748833452717 8.83 35.67320158426332 139.73748833452717 27.187 35.67320934591438 139.7375120313565 27.187 35.67320934591438 139.7375120313565 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fedaeb4d-6ea4-4cd4-887c-e90094fe01ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fedaeb4d-6ea4-4cd4-887c-e90094fe01ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fedaeb4d-6ea4-4cd4-887c-e90094fe01ac">
											<gml:posList>35.67320934591438 139.7375120313565 8.83 35.67320934591438 139.7375120313565 27.187 35.67321721232293 139.73750879633246 27.187 35.67321721232293 139.73750879633246 17.347 35.67321721232293 139.73750879633246 8.83 35.67320934591438 139.7375120313565 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c2aa666-5639-440c-8b44-ffd6aa5f6d1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c2aa666-5639-440c-8b44-ffd6aa5f6d1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c2aa666-5639-440c-8b44-ffd6aa5f6d1b">
											<gml:posList>35.67324605769871 139.73749929487164 8.83 35.67321721232293 139.73750879633246 8.83 35.67321721232293 139.73750879633246 17.347 35.67324605769871 139.73749929487164 17.347 35.67324605769871 139.73749929487164 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-797e88ea-dd4d-4c11-96d6-21a182d3f5cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-797e88ea-dd4d-4c11-96d6-21a182d3f5cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-797e88ea-dd4d-4c11-96d6-21a182d3f5cf">
											<gml:posList>35.67324278565045 139.73747656477002 8.83 35.67324605769871 139.73749929487164 8.83 35.67324605769871 139.73749929487164 17.347 35.67324278565045 139.73747656477002 17.347 35.67324278565045 139.73747656477002 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8a72595-99f7-4990-a663-b51ffb1b75e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8a72595-99f7-4990-a663-b51ffb1b75e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8a72595-99f7-4990-a663-b51ffb1b75e3">
											<gml:posList>35.6732784468276 139.73746885574957 8.83 35.67324278565045 139.73747656477002 8.83 35.67324278565045 139.73747656477002 17.347 35.6732784468276 139.73746885574957 17.347 35.6732784468276 139.73746885574957 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4664956-1939-47db-98ec-e560d21d9585">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4664956-1939-47db-98ec-e560d21d9585">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4664956-1939-47db-98ec-e560d21d9585">
											<gml:posList>35.67330502916922 139.7375718893206 8.83 35.6732784468276 139.73746885574957 8.83 35.6732784468276 139.73746885574957 17.347 35.67330502916922 139.7375718893206 17.347 35.67330502916922 139.7375718893206 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72150e07-b10b-4ae7-aafb-064565bd1553">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72150e07-b10b-4ae7-aafb-064565bd1553">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72150e07-b10b-4ae7-aafb-064565bd1553">
											<gml:posList>35.67310018600327 139.73750740072913 8.83 35.673132172239825 139.73760501477898 8.83 35.673132172239825 139.73760501477898 27.187 35.67310018600327 139.73750740072913 27.187 35.67310018600327 139.73750740072913 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c97bdf8-c920-4ee1-a489-0957a2dabc7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c97bdf8-c920-4ee1-a489-0957a2dabc7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c97bdf8-c920-4ee1-a489-0957a2dabc7a">
											<gml:posList>35.673192450489 139.73757535988238 27.187 35.673192450489 139.73757535988238 26.588 35.67322676063344 139.73755760007185 26.588 35.67322676063344 139.73755760007185 27.187 35.673192450489 139.73757535988238 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a185d08-5ba9-4fa7-94af-52912d222e97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a185d08-5ba9-4fa7-94af-52912d222e97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a185d08-5ba9-4fa7-94af-52912d222e97">
											<gml:posList>35.673248258567845 139.7376258648059 17.347 35.67321721232293 139.73750879633246 17.347 35.67321721232293 139.73750879633246 27.187 35.67322974294383 139.7375560499777 27.187 35.673248258567845 139.7376258648059 27.187 35.673248258567845 139.7376258648059 17.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4e615b8-5764-4173-9e77-10993ec3424a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4e615b8-5764-4173-9e77-10993ec3424a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4e615b8-5764-4173-9e77-10993ec3424a">
											<gml:posList>35.673321879725314 139.73756546212726 8.83 35.67330502916922 139.7375718893206 8.83 35.67330502916922 139.7375718893206 17.347 35.673321879725314 139.73756546212726 17.347 35.673321879725314 139.73756546212726 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a559bb11-c8ae-4862-b295-1fe98d45b04b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a559bb11-c8ae-4862-b295-1fe98d45b04b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a559bb11-c8ae-4862-b295-1fe98d45b04b">
											<gml:posList>35.673132172239825 139.73760501477898 8.83 35.67318992768466 139.73757666639997 8.83 35.67318992768466 139.73757666639997 27.187 35.673132172239825 139.73760501477898 27.187 35.673132172239825 139.73760501477898 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-294dc077-487b-4985-b4b5-f50e86a4919d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-294dc077-487b-4985-b4b5-f50e86a4919d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-294dc077-487b-4985-b4b5-f50e86a4919d">
											<gml:posList>35.67322676063344 139.73755760007185 27.187 35.67322676063344 139.73755760007185 26.588 35.67324637847635 139.73763061711162 26.588 35.67324637847635 139.73763061711162 27.187 35.67322676063344 139.73755760007185 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88dcda6a-ea2f-463a-a2d2-c65e28078732">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88dcda6a-ea2f-463a-a2d2-c65e28078732">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88dcda6a-ea2f-463a-a2d2-c65e28078732">
											<gml:posList>35.67333070582088 139.73760155208726 34.828 35.67333070582088 139.73760155208726 17.347 35.67329446673501 139.73761931420503 17.347 35.67329446673501 139.73761931420503 27.187 35.67329446673501 139.73761931420503 34.828 35.67333070582088 139.73760155208726 34.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ce6399e-3bd9-47bc-aece-0cbe0514c2f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ce6399e-3bd9-47bc-aece-0cbe0514c2f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ce6399e-3bd9-47bc-aece-0cbe0514c2f0">
											<gml:posList>35.67328317451784 139.73761046826627 17.347 35.67328317451784 139.73761046826627 27.187 35.67328602305459 139.73761071893824 27.187 35.67328602305459 139.73761071893824 17.347 35.67328317451784 139.73761046826627 17.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06bedcae-8a66-4d19-af2f-c1fa9ce8d516">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06bedcae-8a66-4d19-af2f-c1fa9ce8d516">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06bedcae-8a66-4d19-af2f-c1fa9ce8d516">
											<gml:posList>35.67328002042802 139.73761136681165 17.347 35.67328002042802 139.73761136681165 27.187 35.67328317451784 139.73761046826627 27.187 35.67328317451784 139.73761046826627 17.347 35.67328002042802 139.73761136681165 17.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b8f5189-1899-4a20-a730-7bbd175b0909">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b8f5189-1899-4a20-a730-7bbd175b0909">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b8f5189-1899-4a20-a730-7bbd175b0909">
											<gml:posList>35.67328602305459 139.73761071893824 17.347 35.67328602305459 139.73761071893824 27.187 35.673289072044625 139.73761367580258 27.187 35.673289072044625 139.73761367580258 17.347 35.67328602305459 139.73761071893824 17.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81fddba8-1106-4097-afb1-1ee883b3400f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81fddba8-1106-4097-afb1-1ee883b3400f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81fddba8-1106-4097-afb1-1ee883b3400f">
											<gml:posList>35.6732981098048 139.73762123197463 34.828 35.6732981098048 139.73762123197463 33.757 35.67332888869468 139.73760613862328 33.757 35.67332888869468 139.73760613862328 34.828 35.6732981098048 139.73762123197463 34.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e3d9f9c-0167-4e87-80db-460cd1b2838a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e3d9f9c-0167-4e87-80db-460cd1b2838a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e3d9f9c-0167-4e87-80db-460cd1b2838a">
											<gml:posList>35.673283393788935 139.73761416863528 27.187 35.673283393788935 139.73761416863528 26.588 35.67328488115772 139.7376142994193 26.588 35.67328488115772 139.7376142994193 27.187 35.673283393788935 139.73761416863528 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5da1356-8cf5-4fb0-a582-bcfe345aeee0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5da1356-8cf5-4fb0-a582-bcfe345aeee0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5da1356-8cf5-4fb0-a582-bcfe345aeee0">
											<gml:posList>35.67328087051002 139.73761487863416 27.187 35.67328087051002 139.73761487863416 26.588 35.673283393788935 139.73761416863528 26.588 35.673283393788935 139.73761416863528 27.187 35.67328087051002 139.73761487863416 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-93935e5e-5764-41cf-9b72-535afb5783dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93935e5e-5764-41cf-9b72-535afb5783dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93935e5e-5764-41cf-9b72-535afb5783dd">
											<gml:posList>35.67328488115772 139.7376142994193 27.187 35.67328488115772 139.7376142994193 26.588 35.67328682962234 139.7376161860717 26.588 35.67328682962234 139.7376161860717 27.187 35.67328488115772 139.7376142994193 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-adc79e45-77a1-4147-9e3a-d0bf54a2f579">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adc79e45-77a1-4147-9e3a-d0bf54a2f579">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adc79e45-77a1-4147-9e3a-d0bf54a2f579">
											<gml:posList>35.673289072044625 139.73761367580258 17.347 35.673289072044625 139.73761367580258 27.187 35.67329255646789 139.73762012289194 27.187 35.67329255646789 139.73762012289194 17.347 35.673289072044625 139.73761367580258 17.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6059b348-0399-4ffd-b31d-57acc6a437e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6059b348-0399-4ffd-b31d-57acc6a437e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6059b348-0399-4ffd-b31d-57acc6a437e1">
											<gml:posList>35.673248258567845 139.7376258648059 17.347 35.673248258567845 139.7376258648059 27.187 35.67328002042802 139.73761136681165 27.187 35.67328002042802 139.73761136681165 17.347 35.673248258567845 139.7376258648059 17.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac41763b-1057-4bab-ac06-a1734bdd25a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac41763b-1057-4bab-ac06-a1734bdd25a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac41763b-1057-4bab-ac06-a1734bdd25a5">
											<gml:posList>35.67329255646789 139.73762012289194 17.347 35.67329255646789 139.73762012289194 27.187 35.67329446673501 139.73761931420503 27.187 35.67329446673501 139.73761931420503 17.347 35.67329255646789 139.73762012289194 17.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44c95eca-c2c3-40c4-a300-7400eda5a701">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44c95eca-c2c3-40c4-a300-7400eda5a701">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44c95eca-c2c3-40c4-a300-7400eda5a701">
											<gml:posList>35.67328682962234 139.7376161860717 27.187 35.67328682962234 139.7376161860717 26.588 35.673291334088276 139.73762450987547 26.588 35.673291334088276 139.73762450987547 27.187 35.67328682962234 139.7376161860717 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-794a3681-14d4-427f-8dfb-1dfb35802bfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-794a3681-14d4-427f-8dfb-1dfb35802bfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-794a3681-14d4-427f-8dfb-1dfb35802bfe">
											<gml:posList>35.67324637847635 139.73763061711162 27.187 35.67324637847635 139.73763061711162 26.588 35.67328087051002 139.73761487863416 26.588 35.67328087051002 139.73761487863416 27.187 35.67324637847635 139.73763061711162 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef21aa9b-2396-4c37-8a77-269adc4e6baf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef21aa9b-2396-4c37-8a77-269adc4e6baf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef21aa9b-2396-4c37-8a77-269adc4e6baf">
											<gml:posList>35.67329274876777 139.7376239116669 27.187 35.67329274876777 139.7376239116669 26.588 35.67329552391278 139.7376225496145 26.588 35.67329552391278 139.7376225496145 27.187 35.67329274876777 139.7376239116669 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-413ebf34-b23f-4cd4-ab05-06962360cb7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-413ebf34-b23f-4cd4-ab05-06962360cb7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-413ebf34-b23f-4cd4-ab05-06962360cb7d">
											<gml:posList>35.673291334088276 139.73762450987547 27.187 35.673291334088276 139.73762450987547 26.588 35.67329274876777 139.7376239116669 26.588 35.67329274876777 139.7376239116669 27.187 35.673291334088276 139.73762450987547 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7729ff41-ad4a-4612-8027-601bfa0a96ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7729ff41-ad4a-4612-8027-601bfa0a96ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7729ff41-ad4a-4612-8027-601bfa0a96ea">
											<gml:posList>35.67332888869468 139.73760613862328 34.828 35.67332888869468 139.73760613862328 33.757 35.67333813974839 139.73764389613035 33.757 35.67333813974839 139.73764389613035 34.828 35.67332888869468 139.73760613862328 34.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b201a51c-eb1f-4d1c-a571-86657ffb69f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b201a51c-eb1f-4d1c-a571-86657ffb69f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b201a51c-eb1f-4d1c-a571-86657ffb69f0">
											<gml:posList>35.673357328683274 139.73771035208264 8.83 35.673321879725314 139.73756546212726 8.83 35.673321879725314 139.73756546212726 17.347 35.67333070582088 139.73760155208726 17.347 35.67333070582088 139.73760155208726 34.828 35.67334156657635 139.73764592462686 34.828 35.67334156657635 139.73764592462686 28.913 35.673357328683274 139.73771035208264 20.243 35.673357328683274 139.73771035208264 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-808920a2-3237-4965-94a1-9976cdb3558f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-808920a2-3237-4965-94a1-9976cdb3558f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-808920a2-3237-4965-94a1-9976cdb3558f">
											<gml:posList>35.67331001886475 139.73765768279065 34.828 35.67331001886475 139.73765768279065 33.757 35.6732981098048 139.73762123197463 33.757 35.6732981098048 139.73762123197463 34.828 35.67331001886475 139.73765768279065 34.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21517396-6bca-4dc4-8550-0da535c2de85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21517396-6bca-4dc4-8550-0da535c2de85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21517396-6bca-4dc4-8550-0da535c2de85">
											<gml:posList>35.67329552391278 139.7376225496145 27.187 35.67329552391278 139.7376225496145 26.588 35.67330807454375 139.73766101015647 26.588 35.67330807454375 139.73766101015647 27.187 35.673308454032714 139.73766215855653 28.913 35.673308454032714 139.73766215855653 34.828 35.67329446673501 139.73761931420503 34.828 35.67329446673501 139.73761931420503 27.187 35.67329552391278 139.7376225496145 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-264b8f45-400d-4d11-92f7-fd5bdbf3d134">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-264b8f45-400d-4d11-92f7-fd5bdbf3d134">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-264b8f45-400d-4d11-92f7-fd5bdbf3d134">
											<gml:posList>35.67322872110073 139.73771068222808 27.187 35.67322872110073 139.73771068222808 26.588 35.673192450489 139.73757535988238 26.588 35.673192450489 139.73757535988238 27.187 35.67322872110073 139.73771068222808 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2f5c1b9-7767-40ab-b18d-b761dc7261d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2f5c1b9-7767-40ab-b18d-b761dc7261d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2f5c1b9-7767-40ab-b18d-b761dc7261d2">
											<gml:posList>35.67333813974839 139.73764389613035 34.828 35.67333813974839 139.73764389613035 33.757 35.67331001886475 139.73765768279065 33.757 35.67331001886475 139.73765768279065 34.828 35.67333813974839 139.73764389613035 34.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07a38269-5add-4ea3-9c3c-ff171813f745">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07a38269-5add-4ea3-9c3c-ff171813f745">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07a38269-5add-4ea3-9c3c-ff171813f745">
											<gml:posList>35.673308454032714 139.73766215855653 28.913 35.67334156657635 139.73764592462686 28.913 35.67334156657635 139.73764592462686 34.828 35.673308454032714 139.73766215855653 28.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35ed593b-cb1d-4bc3-8f45-b72ad8b43d2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35ed593b-cb1d-4bc3-8f45-b72ad8b43d2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35ed593b-cb1d-4bc3-8f45-b72ad8b43d2f">
											<gml:posList>35.673308454032714 139.73766215855653 34.828 35.673308454032714 139.73766215855653 28.913 35.67334156657635 139.73764592462686 34.828 35.673308454032714 139.73766215855653 34.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45f489ee-0bc0-40e3-b12b-d38b49c8b528">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45f489ee-0bc0-40e3-b12b-d38b49c8b528">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45f489ee-0bc0-40e3-b12b-d38b49c8b528">
											<gml:posList>35.67330807454375 139.73766101015647 27.187 35.67330807454375 139.73766101015647 26.588 35.673305308403265 139.73766236115034 26.588 35.673305308403265 139.73766236115034 27.187 35.67330807454375 139.73766101015647 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30ba9cc0-8c83-4a80-8269-456319e65dcc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30ba9cc0-8c83-4a80-8269-456319e65dcc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30ba9cc0-8c83-4a80-8269-456319e65dcc">
											<gml:posList>35.67318992768466 139.73757666639997 27.187 35.67318992768466 139.73757666639997 8.83 35.67323820513737 139.73775810524364 8.83 35.67323820513737 139.73775810524364 20.243 35.67322686811722 139.73771552287155 27.187 35.67318992768466 139.73757666639997 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94921c4e-07be-4fdf-9061-bd1f644096db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94921c4e-07be-4fdf-9061-bd1f644096db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94921c4e-07be-4fdf-9061-bd1f644096db">
											<gml:posList>35.673307560788146 139.73767238883195 27.187 35.673305308403265 139.73766236115034 27.187 35.673305308403265 139.73766236115034 26.588 35.673307560788146 139.73767238883195 26.588 35.673307560788146 139.73767238883195 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d749d6f-08c5-4ad3-86f2-0a64e8e335c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d749d6f-08c5-4ad3-86f2-0a64e8e335c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d749d6f-08c5-4ad3-86f2-0a64e8e335c7">
											<gml:posList>35.67331112296181 139.73767459391402 27.187 35.673308454032714 139.73766215855653 28.913 35.67330807454375 139.73766101015647 27.187 35.67331112296181 139.73767459391402 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0f2b732-3375-41ae-bc2f-2b117842f3b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0f2b732-3375-41ae-bc2f-2b117842f3b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0f2b732-3375-41ae-bc2f-2b117842f3b4">
											<gml:posList>35.673307560788146 139.73767238883195 27.187 35.673307560788146 139.73767238883195 26.588 35.67322872110073 139.73771068222808 26.588 35.67322872110073 139.73771068222808 27.187 35.673307560788146 139.73767238883195 27.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35eaac2c-b166-454e-b3e9-9f52921a0f60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35eaac2c-b166-454e-b3e9-9f52921a0f60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35eaac2c-b166-454e-b3e9-9f52921a0f60">
											<gml:posList>35.67323820513737 139.73775810524364 8.83 35.673357328683274 139.73771035208264 8.83 35.673357328683274 139.73771035208264 20.243 35.67323820513737 139.73775810524364 20.243 35.67323820513737 139.73775810524364 8.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6685</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">387.2231</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>