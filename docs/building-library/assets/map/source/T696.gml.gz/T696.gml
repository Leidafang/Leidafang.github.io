<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c9284a87-9150-427a-aa7e-b63523e86730">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">37.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671324010717214 139.74292450798018 0 35.67133207780508 139.7429122373895 0 35.671342476965194 139.7429326725334 0 35.671402823006 139.7428355066293 0 35.671622005507814 139.74248260192144 0 35.67148751542446 139.74235627290153 0 35.67131087903364 139.74263859808363 0 35.67130926163884 139.7426453382097 0 35.67130243491687 139.7426768281338 0 35.6712987563379 139.74269947738503 0 35.67129660850805 139.7427200260909 0 35.671295901208 139.74273836389077 0 35.67129637017589 139.74276266540983 0 35.67129800818151 139.7427833203015 0 35.67130036263036 139.7427977884086 0 35.67130415952216 139.74281258627963 0 35.67131005983899 139.7428316788224 0 35.671290143948504 139.74284959644731 0 35.67131500303605 139.74288455230416 0 35.67130262329777 139.74290337826693 0 35.671324010717214 139.74292450798018 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671324010717214 139.74292450798018 7.28 35.67130262329777 139.74290337826693 7.28 35.67131500303605 139.74288455230416 7.28 35.671290143948504 139.74284959644731 7.28 35.67131005983899 139.7428316788224 7.28 35.67130415952216 139.74281258627963 7.28 35.67130036263036 139.7427977884086 7.28 35.67129800818151 139.7427833203015 7.28 35.67129637017589 139.74276266540983 7.28 35.671295901208 139.74273836389077 7.28 35.67129660850805 139.7427200260909 7.28 35.6712987563379 139.74269947738503 7.28 35.67130243491687 139.7426768281338 7.28 35.67130926163884 139.7426453382097 7.28 35.67131087903364 139.74263859808363 7.28 35.67148751542446 139.74235627290153 7.28 35.671622005507814 139.74248260192144 7.28 35.671402823006 139.7428355066293 7.28 35.671342476965194 139.7429326725334 7.28 35.67133207780508 139.7429122373895 7.28 35.671324010717214 139.74292450798018 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671324010717214 139.74292450798018 7.28 35.67133207780508 139.7429122373895 7.28 35.67133207780508 139.7429122373895 39.55 35.671324010717214 139.74292450798018 39.55 35.671324010717214 139.74292450798018 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67133207780508 139.7429122373895 7.28 35.671342476965194 139.7429326725334 7.28 35.671342476965194 139.7429326725334 39.55 35.67133207780508 139.7429122373895 39.55 35.67133207780508 139.7429122373895 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671342476965194 139.7429326725334 7.28 35.671402823006 139.7428355066293 7.28 35.671402823006 139.7428355066293 39.55 35.671342476965194 139.7429326725334 39.55 35.671342476965194 139.7429326725334 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671402823006 139.7428355066293 7.28 35.671622005507814 139.74248260192144 7.28 35.671622005507814 139.74248260192144 39.55 35.671402823006 139.7428355066293 39.55 35.671402823006 139.7428355066293 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671622005507814 139.74248260192144 7.28 35.67148751542446 139.74235627290153 7.28 35.67148751542446 139.74235627290153 39.55 35.671622005507814 139.74248260192144 39.55 35.671622005507814 139.74248260192144 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67148751542446 139.74235627290153 7.28 35.67131087903364 139.74263859808363 7.28 35.67131087903364 139.74263859808363 39.55 35.67148751542446 139.74235627290153 39.55 35.67148751542446 139.74235627290153 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67131087903364 139.74263859808363 7.28 35.67130926163884 139.7426453382097 7.28 35.67130926163884 139.7426453382097 39.55 35.67131087903364 139.74263859808363 39.55 35.67131087903364 139.74263859808363 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67130926163884 139.7426453382097 7.28 35.67130243491687 139.7426768281338 7.28 35.67130243491687 139.7426768281338 39.55 35.67130926163884 139.7426453382097 39.55 35.67130926163884 139.7426453382097 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67130243491687 139.7426768281338 7.28 35.6712987563379 139.74269947738503 7.28 35.6712987563379 139.74269947738503 39.55 35.67130243491687 139.7426768281338 39.55 35.67130243491687 139.7426768281338 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6712987563379 139.74269947738503 7.28 35.67129660850805 139.7427200260909 7.28 35.67129660850805 139.7427200260909 39.55 35.6712987563379 139.74269947738503 39.55 35.6712987563379 139.74269947738503 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67129660850805 139.7427200260909 7.28 35.671295901208 139.74273836389077 7.28 35.671295901208 139.74273836389077 39.55 35.67129660850805 139.7427200260909 39.55 35.67129660850805 139.7427200260909 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671295901208 139.74273836389077 7.28 35.67129637017589 139.74276266540983 7.28 35.67129637017589 139.74276266540983 39.55 35.671295901208 139.74273836389077 39.55 35.671295901208 139.74273836389077 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67129637017589 139.74276266540983 7.28 35.67129800818151 139.7427833203015 7.28 35.67129800818151 139.7427833203015 39.55 35.67129637017589 139.74276266540983 39.55 35.67129637017589 139.74276266540983 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67129800818151 139.7427833203015 7.28 35.67130036263036 139.7427977884086 7.28 35.67130036263036 139.7427977884086 39.55 35.67129800818151 139.7427833203015 39.55 35.67129800818151 139.7427833203015 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67130036263036 139.7427977884086 7.28 35.67130415952216 139.74281258627963 7.28 35.67130415952216 139.74281258627963 39.55 35.67130036263036 139.7427977884086 39.55 35.67130036263036 139.7427977884086 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67130415952216 139.74281258627963 7.28 35.67131005983899 139.7428316788224 7.28 35.67131005983899 139.7428316788224 39.55 35.67130415952216 139.74281258627963 39.55 35.67130415952216 139.74281258627963 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67131005983899 139.7428316788224 7.28 35.671290143948504 139.74284959644731 7.28 35.671290143948504 139.74284959644731 39.55 35.67131005983899 139.7428316788224 39.55 35.67131005983899 139.7428316788224 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671290143948504 139.74284959644731 7.28 35.67131500303605 139.74288455230416 7.28 35.67131500303605 139.74288455230416 39.55 35.671290143948504 139.74284959644731 39.55 35.671290143948504 139.74284959644731 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67131500303605 139.74288455230416 7.28 35.67130262329777 139.74290337826693 7.28 35.67130262329777 139.74290337826693 39.55 35.67131500303605 139.74288455230416 39.55 35.67131500303605 139.74288455230416 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67130262329777 139.74290337826693 7.28 35.671324010717214 139.74292450798018 7.28 35.671324010717214 139.74292450798018 39.55 35.67130262329777 139.74290337826693 39.55 35.67130262329777 139.74290337826693 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671324010717214 139.74292450798018 39.55 35.67133207780508 139.7429122373895 39.55 35.671342476965194 139.7429326725334 39.55 35.671402823006 139.7428355066293 39.55 35.671622005507814 139.74248260192144 39.55 35.67148751542446 139.74235627290153 39.55 35.67131087903364 139.74263859808363 39.55 35.67130926163884 139.7426453382097 39.55 35.67130243491687 139.7426768281338 39.55 35.6712987563379 139.74269947738503 39.55 35.67129660850805 139.7427200260909 39.55 35.671295901208 139.74273836389077 39.55 35.67129637017589 139.74276266540983 39.55 35.67129800818151 139.7427833203015 39.55 35.67130036263036 139.7427977884086 39.55 35.67130415952216 139.74281258627963 39.55 35.67131005983899 139.7428316788224 39.55 35.671290143948504 139.74284959644731 39.55 35.67131500303605 139.74288455230416 39.55 35.67130262329777 139.74290337826693 39.55 35.671324010717214 139.74292450798018 39.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7c71af0a-4dac-447c-8605-c707739b12db"/>
							<gml:surfaceMember xlink:href="#poly-2bb9f1f6-3995-4846-80f2-a53c97fb72c8"/>
							<gml:surfaceMember xlink:href="#poly-d607e5bb-f7f2-4db0-8847-0bccfeb9b99d"/>
							<gml:surfaceMember xlink:href="#poly-1d8480e5-95e8-4f9c-8ef0-4caf974c73cb"/>
							<gml:surfaceMember xlink:href="#poly-b6f9441c-42a3-490e-80b7-803749697cf6"/>
							<gml:surfaceMember xlink:href="#poly-d2200e67-1726-4d0d-ae81-e32ba618b64a"/>
							<gml:surfaceMember xlink:href="#poly-2d46fd87-47eb-43fb-a7bf-e5f794c338a8"/>
							<gml:surfaceMember xlink:href="#poly-326a1bd5-7fff-45b2-849c-aa83132db147"/>
							<gml:surfaceMember xlink:href="#poly-840a5c73-3ba9-4499-8717-21a9e64f068e"/>
							<gml:surfaceMember xlink:href="#poly-60952244-4f22-4b2b-8974-8464293211fa"/>
							<gml:surfaceMember xlink:href="#poly-1f42f6e3-bdaf-46c5-9577-083e669f447e"/>
							<gml:surfaceMember xlink:href="#poly-0dc63e20-5ecf-4956-b1b9-123f058e7d4c"/>
							<gml:surfaceMember xlink:href="#poly-da47fa4c-9c3d-47ad-b5de-d67a53be95b9"/>
							<gml:surfaceMember xlink:href="#poly-50777b66-5c25-4ca1-94f7-8acf6786d812"/>
							<gml:surfaceMember xlink:href="#poly-c02c7857-9cd3-407b-b1e0-c9d4ab0abebf"/>
							<gml:surfaceMember xlink:href="#poly-4db91476-3241-48ad-8adc-4d90808326a6"/>
							<gml:surfaceMember xlink:href="#poly-6765f8c5-e2a7-41eb-99b5-150e3d873f77"/>
							<gml:surfaceMember xlink:href="#poly-bab6dbd7-bc69-40b2-9bef-e24bde7416a3"/>
							<gml:surfaceMember xlink:href="#poly-1ff5d0ad-67dd-4fde-b6b6-3fb3767ff7d4"/>
							<gml:surfaceMember xlink:href="#poly-7fbfd9ae-cecf-4b04-aaca-9db85d4918fd"/>
							<gml:surfaceMember xlink:href="#poly-e4b0c077-54c1-40a7-81d5-dd4a236c2f00"/>
							<gml:surfaceMember xlink:href="#poly-d90c9506-c177-4ac0-bb4c-210e5481ba4b"/>
							<gml:surfaceMember xlink:href="#poly-5c56f445-8992-4ed8-98ea-c52f1b709621"/>
							<gml:surfaceMember xlink:href="#poly-16a8dac6-6911-4546-a525-2b0f20ec3564"/>
							<gml:surfaceMember xlink:href="#poly-c5fb116f-036f-49fc-a77c-64106351d647"/>
							<gml:surfaceMember xlink:href="#poly-c8d47fef-35e1-4972-9af3-0281e9c304ba"/>
							<gml:surfaceMember xlink:href="#poly-4cc4ad33-56d9-42eb-a7a0-2b6d7474fad3"/>
							<gml:surfaceMember xlink:href="#poly-836d6c21-a90d-4346-8ec8-d1ff46b50e12"/>
							<gml:surfaceMember xlink:href="#poly-73825c79-5bb7-4ad4-937e-45e077252b86"/>
							<gml:surfaceMember xlink:href="#poly-fcc21bb6-b716-41f3-b2a8-d1416fa6313d"/>
							<gml:surfaceMember xlink:href="#poly-604308cc-fd62-4eb3-b6cd-14ca79b21dd8"/>
							<gml:surfaceMember xlink:href="#poly-bc699074-5888-4ba1-a8ec-f8a84b45281c"/>
							<gml:surfaceMember xlink:href="#poly-f52602af-576e-4fe4-90a1-1ad3bb67e325"/>
							<gml:surfaceMember xlink:href="#poly-f7ae3098-ed3f-4eba-805b-0b450f7828a1"/>
							<gml:surfaceMember xlink:href="#poly-f56cdeed-8acc-4d97-98ae-fdc1d68a8c78"/>
							<gml:surfaceMember xlink:href="#poly-ea8a9c03-46a0-49ea-85b8-0e599d1d6eea"/>
							<gml:surfaceMember xlink:href="#poly-550af26a-25c9-45be-bcd0-1b9e2108c551"/>
							<gml:surfaceMember xlink:href="#poly-ced96b33-0f26-4498-8316-c57d1c1b3e72"/>
							<gml:surfaceMember xlink:href="#poly-ebb56b26-289c-4a93-bb79-0769466880bf"/>
							<gml:surfaceMember xlink:href="#poly-df17809c-c821-4428-b387-ab71fb5427c4"/>
							<gml:surfaceMember xlink:href="#poly-73ec0489-c479-4e1c-8e91-c76e7f5fe2a8"/>
							<gml:surfaceMember xlink:href="#poly-cd48fc1c-3f32-49de-ab24-22c0651df4f2"/>
							<gml:surfaceMember xlink:href="#poly-fdde6b71-3184-4e72-b049-5930dc5129e5"/>
							<gml:surfaceMember xlink:href="#poly-5330b985-6b87-4330-8e2d-7c1f082d598c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7c71af0a-4dac-447c-8605-c707739b12db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c71af0a-4dac-447c-8605-c707739b12db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c71af0a-4dac-447c-8605-c707739b12db">
											<gml:posList>35.67131500303602 139.74288455230413 7.28 35.671290143948504 139.74284959644731 7.28 35.671310059838994 139.7428316788224 7.28 35.671304159522116 139.7428125862796 7.28 35.67130036263036 139.7427977884086 7.28 35.6712980081815 139.74278332030147 7.28 35.67129637017588 139.74276266540983 7.28 35.67129590120798 139.74273836389077 7.28 35.67129660850803 139.7427200260909 7.28 35.6712987563379 139.74269947738503 7.28 35.67130243491683 139.74267682813377 7.28 35.67130926163881 139.7426453382097 7.28 35.671310879033626 139.74263859808363 7.28 35.67148751542445 139.74235627290153 7.28 35.6716220055078 139.74248260192144 7.28 35.67134247696516 139.7429326725334 7.28 35.67133207780509 139.7429122373895 7.28 35.67132401973091 139.74292450797 7.28 35.67130262329775 139.74290337826693 7.28 35.67131500303602 139.74288455230413 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2bb9f1f6-3995-4846-80f2-a53c97fb72c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bb9f1f6-3995-4846-80f2-a53c97fb72c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bb9f1f6-3995-4846-80f2-a53c97fb72c8">
											<gml:posList>35.67142888495976 139.74256440950006 40.1 35.67148751542445 139.74235627290153 40.1 35.671310879033626 139.74263859808363 40.1 35.67134620297328 139.74269730284138 40.1 35.67142888495976 139.74256440950006 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d607e5bb-f7f2-4db0-8847-0bccfeb9b99d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d607e5bb-f7f2-4db0-8847-0bccfeb9b99d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d607e5bb-f7f2-4db0-8847-0bccfeb9b99d">
											<gml:posList>35.67135660230773 139.7427898156829 40.1 35.67140282301428 139.74283551767564 40.1 35.6716220055078 139.74248260192144 40.1 35.67148751542445 139.74235627290153 40.1 35.67142888495976 139.74256440950006 40.1 35.67144513013778 139.74257960200976 40.1 35.671442549278126 139.74262355858073 40.1 35.671455872230624 139.74263640152583 40.1 35.67142899778191 139.7426782757064 40.1 35.6714156748338 139.74266543275866 40.1 35.671362457148504 139.74271249535224 40.1 35.67134620297328 139.74269730284138 40.1 35.671310879033626 139.74263859808363 40.1 35.67130926163881 139.7426453382097 40.1 35.67130243491683 139.74267682813377 40.1 35.6712987563379 139.74269947738503 40.1 35.67129660850803 139.7427200260909 40.1 35.67129590120798 139.74273836389077 40.1 35.67129637017588 139.74276266540983 40.1 35.6712980081815 139.74278332030147 40.1 35.67130036263036 139.7427977884086 40.1 35.671304159522116 139.7428125862796 40.1 35.671310059838994 139.7428316788224 40.1 35.67135660230773 139.7427898156829 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d8480e5-95e8-4f9c-8ef0-4caf974c73cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d8480e5-95e8-4f9c-8ef0-4caf974c73cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d8480e5-95e8-4f9c-8ef0-4caf974c73cb">
											<gml:posList>35.67142888495976 139.74256440950006 41.758 35.67134620297328 139.74269730284138 41.758 35.671362457148504 139.74271249535224 41.758 35.67144513013778 139.74257960200976 41.758 35.67142888495976 139.74256440950006 41.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6f9441c-42a3-490e-80b7-803749697cf6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6f9441c-42a3-490e-80b7-803749697cf6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6f9441c-42a3-490e-80b7-803749697cf6">
											<gml:posList>35.67144513013778 139.74257960200976 40.1 35.671362457148504 139.74271249535224 40.1 35.6714156748338 139.74266543275866 40.1 35.671442549278126 139.74262355858073 40.1 35.67144513013778 139.74257960200976 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d2200e67-1726-4d0d-ae81-e32ba618b64a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2200e67-1726-4d0d-ae81-e32ba618b64a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2200e67-1726-4d0d-ae81-e32ba618b64a">
											<gml:posList>35.67142899778191 139.7426782757064 42.159 35.671455872230624 139.74263640152583 42.159 35.671442549278126 139.74262355858073 42.159 35.6714156748338 139.74266543275866 42.159 35.67142899778191 139.7426782757064 42.159</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d46fd87-47eb-43fb-a7bf-e5f794c338a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d46fd87-47eb-43fb-a7bf-e5f794c338a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d46fd87-47eb-43fb-a7bf-e5f794c338a8">
											<gml:posList>35.67135660230773 139.7427898156829 42.959 35.671290143948504 139.74284959644731 44.359 35.67133610709956 139.74285244977509 44.359 35.67135660230773 139.7427898156829 42.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-326a1bd5-7fff-45b2-849c-aa83132db147">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-326a1bd5-7fff-45b2-849c-aa83132db147">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-326a1bd5-7fff-45b2-849c-aa83132db147">
											<gml:posList>35.67133610709956 139.74285244977509 44.359 35.67140282301428 139.74283551767564 42.959 35.67135660230773 139.7427898156829 42.959 35.67133610709956 139.74285244977509 44.359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-840a5c73-3ba9-4499-8717-21a9e64f068e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-840a5c73-3ba9-4499-8717-21a9e64f068e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-840a5c73-3ba9-4499-8717-21a9e64f068e">
											<gml:posList>35.67135750354153 139.74287357947335 44.359 35.67140282301428 139.74283551767564 42.959 35.67133610709956 139.74285244977509 44.359 35.67135750354153 139.74287357947335 44.359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-60952244-4f22-4b2b-8974-8464293211fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60952244-4f22-4b2b-8974-8464293211fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60952244-4f22-4b2b-8974-8464293211fa">
											<gml:posList>35.67133610709956 139.74285244977509 44.359 35.671290143948504 139.74284959644731 44.359 35.67131500303602 139.74288455230413 44.359 35.67133610709956 139.74285244977509 44.359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f42f6e3-bdaf-46c5-9577-083e669f447e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f42f6e3-bdaf-46c5-9577-083e669f447e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f42f6e3-bdaf-46c5-9577-083e669f447e">
											<gml:posList>35.67135750354153 139.74287357947335 44.359 35.67134247696516 139.7429326725334 44.359 35.67140282301428 139.74283551767564 42.959 35.67135750354153 139.74287357947335 44.359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0dc63e20-5ecf-4956-b1b9-123f058e7d4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dc63e20-5ecf-4956-b1b9-123f058e7d4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dc63e20-5ecf-4956-b1b9-123f058e7d4c">
											<gml:posList>35.67130262329775 139.74290337826693 42.101 35.67132401973091 139.74292450797 42.101 35.67133207780509 139.7429122373895 42.101 35.67135750354153 139.74287357947335 42.101 35.67133610709956 139.74285244977509 42.101 35.67131500303602 139.74288455230413 42.101 35.67130262329775 139.74290337826693 42.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-da47fa4c-9c3d-47ad-b5de-d67a53be95b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da47fa4c-9c3d-47ad-b5de-d67a53be95b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da47fa4c-9c3d-47ad-b5de-d67a53be95b9">
											<gml:posList>35.67134247696516 139.7429326725334 44.359 35.67135750354153 139.74287357947335 44.359 35.67133207780509 139.7429122373895 44.359 35.67134247696516 139.7429326725334 44.359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50777b66-5c25-4ca1-94f7-8acf6786d812">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50777b66-5c25-4ca1-94f7-8acf6786d812">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50777b66-5c25-4ca1-94f7-8acf6786d812">
											<gml:posList>35.6716220055078 139.74248260192144 40.1 35.6716220055078 139.74248260192144 7.28 35.67148751542445 139.74235627290153 7.28 35.67148751542445 139.74235627290153 40.1 35.6716220055078 139.74248260192144 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c02c7857-9cd3-407b-b1e0-c9d4ab0abebf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c02c7857-9cd3-407b-b1e0-c9d4ab0abebf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c02c7857-9cd3-407b-b1e0-c9d4ab0abebf">
											<gml:posList>35.67148751542445 139.74235627290153 40.1 35.67148751542445 139.74235627290153 7.28 35.671310879033626 139.74263859808363 7.28 35.671310879033626 139.74263859808363 40.1 35.67148751542445 139.74235627290153 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4db91476-3241-48ad-8adc-4d90808326a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4db91476-3241-48ad-8adc-4d90808326a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4db91476-3241-48ad-8adc-4d90808326a6">
											<gml:posList>35.67142888495976 139.74256440950006 40.1 35.67142888495976 139.74256440950006 41.758 35.67144513013778 139.74257960200976 41.758 35.67144513013778 139.74257960200976 40.1 35.67142888495976 139.74256440950006 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6765f8c5-e2a7-41eb-99b5-150e3d873f77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6765f8c5-e2a7-41eb-99b5-150e3d873f77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6765f8c5-e2a7-41eb-99b5-150e3d873f77">
											<gml:posList>35.671442549278126 139.74262355858073 40.1 35.671442549278126 139.74262355858073 42.159 35.671455872230624 139.74263640152583 42.159 35.671455872230624 139.74263640152583 40.1 35.671442549278126 139.74262355858073 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bab6dbd7-bc69-40b2-9bef-e24bde7416a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bab6dbd7-bc69-40b2-9bef-e24bde7416a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bab6dbd7-bc69-40b2-9bef-e24bde7416a3">
											<gml:posList>35.67134620297328 139.74269730284138 40.1 35.67134620297328 139.74269730284138 41.758 35.67142888495976 139.74256440950006 41.758 35.67142888495976 139.74256440950006 40.1 35.67134620297328 139.74269730284138 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ff5d0ad-67dd-4fde-b6b6-3fb3767ff7d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ff5d0ad-67dd-4fde-b6b6-3fb3767ff7d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ff5d0ad-67dd-4fde-b6b6-3fb3767ff7d4">
											<gml:posList>35.671310879033626 139.74263859808363 40.1 35.671310879033626 139.74263859808363 7.28 35.67130926163881 139.7426453382097 7.28 35.67130926163881 139.7426453382097 40.1 35.671310879033626 139.74263859808363 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7fbfd9ae-cecf-4b04-aaca-9db85d4918fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fbfd9ae-cecf-4b04-aaca-9db85d4918fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fbfd9ae-cecf-4b04-aaca-9db85d4918fd">
											<gml:posList>35.6714156748338 139.74266543275866 40.1 35.6714156748338 139.74266543275866 42.159 35.671442549278126 139.74262355858073 42.159 35.671442549278126 139.74262355858073 40.1 35.6714156748338 139.74266543275866 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4b0c077-54c1-40a7-81d5-dd4a236c2f00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4b0c077-54c1-40a7-81d5-dd4a236c2f00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4b0c077-54c1-40a7-81d5-dd4a236c2f00">
											<gml:posList>35.67144513013778 139.74257960200976 40.1 35.67144513013778 139.74257960200976 41.758 35.671362457148504 139.74271249535224 41.758 35.671362457148504 139.74271249535224 40.1 35.67144513013778 139.74257960200976 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d90c9506-c177-4ac0-bb4c-210e5481ba4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d90c9506-c177-4ac0-bb4c-210e5481ba4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d90c9506-c177-4ac0-bb4c-210e5481ba4b">
											<gml:posList>35.671455872230624 139.74263640152583 40.1 35.671455872230624 139.74263640152583 42.159 35.67142899778191 139.7426782757064 42.159 35.67142899778191 139.7426782757064 40.1 35.671455872230624 139.74263640152583 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c56f445-8992-4ed8-98ea-c52f1b709621">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c56f445-8992-4ed8-98ea-c52f1b709621">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c56f445-8992-4ed8-98ea-c52f1b709621">
											<gml:posList>35.67130926163881 139.7426453382097 40.1 35.67130926163881 139.7426453382097 7.28 35.67130243491683 139.74267682813377 7.28 35.67130243491683 139.74267682813377 40.1 35.67130926163881 139.7426453382097 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16a8dac6-6911-4546-a525-2b0f20ec3564">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16a8dac6-6911-4546-a525-2b0f20ec3564">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16a8dac6-6911-4546-a525-2b0f20ec3564">
											<gml:posList>35.67142899778191 139.7426782757064 40.1 35.67142899778191 139.7426782757064 42.159 35.6714156748338 139.74266543275866 42.159 35.6714156748338 139.74266543275866 40.1 35.67142899778191 139.7426782757064 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5fb116f-036f-49fc-a77c-64106351d647">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5fb116f-036f-49fc-a77c-64106351d647">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5fb116f-036f-49fc-a77c-64106351d647">
											<gml:posList>35.67130243491683 139.74267682813377 40.1 35.67130243491683 139.74267682813377 7.28 35.6712987563379 139.74269947738503 7.28 35.6712987563379 139.74269947738503 40.1 35.67130243491683 139.74267682813377 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8d47fef-35e1-4972-9af3-0281e9c304ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8d47fef-35e1-4972-9af3-0281e9c304ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8d47fef-35e1-4972-9af3-0281e9c304ba">
											<gml:posList>35.671362457148504 139.74271249535224 40.1 35.671362457148504 139.74271249535224 41.758 35.67134620297328 139.74269730284138 41.758 35.67134620297328 139.74269730284138 40.1 35.671362457148504 139.74271249535224 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cc4ad33-56d9-42eb-a7a0-2b6d7474fad3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cc4ad33-56d9-42eb-a7a0-2b6d7474fad3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cc4ad33-56d9-42eb-a7a0-2b6d7474fad3">
											<gml:posList>35.6716220055078 139.74248260192144 7.28 35.6716220055078 139.74248260192144 40.1 35.67140282301428 139.74283551767564 40.1 35.67140282301428 139.74283551767564 42.959 35.67134247696516 139.7429326725334 44.359 35.67134247696516 139.7429326725334 7.28 35.6716220055078 139.74248260192144 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-836d6c21-a90d-4346-8ec8-d1ff46b50e12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-836d6c21-a90d-4346-8ec8-d1ff46b50e12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-836d6c21-a90d-4346-8ec8-d1ff46b50e12">
											<gml:posList>35.6712987563379 139.74269947738503 40.1 35.6712987563379 139.74269947738503 7.28 35.67129660850803 139.7427200260909 7.28 35.67129660850803 139.7427200260909 40.1 35.6712987563379 139.74269947738503 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73825c79-5bb7-4ad4-937e-45e077252b86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73825c79-5bb7-4ad4-937e-45e077252b86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73825c79-5bb7-4ad4-937e-45e077252b86">
											<gml:posList>35.67129660850803 139.7427200260909 40.1 35.67129660850803 139.7427200260909 7.28 35.67129590120798 139.74273836389077 7.28 35.67129590120798 139.74273836389077 40.1 35.67129660850803 139.7427200260909 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcc21bb6-b716-41f3-b2a8-d1416fa6313d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcc21bb6-b716-41f3-b2a8-d1416fa6313d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcc21bb6-b716-41f3-b2a8-d1416fa6313d">
											<gml:posList>35.67129590120798 139.74273836389077 40.1 35.67129590120798 139.74273836389077 7.28 35.67129637017588 139.74276266540983 7.28 35.67129637017588 139.74276266540983 40.1 35.67129590120798 139.74273836389077 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-604308cc-fd62-4eb3-b6cd-14ca79b21dd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-604308cc-fd62-4eb3-b6cd-14ca79b21dd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-604308cc-fd62-4eb3-b6cd-14ca79b21dd8">
											<gml:posList>35.67129637017588 139.74276266540983 40.1 35.67129637017588 139.74276266540983 7.28 35.6712980081815 139.74278332030147 7.28 35.6712980081815 139.74278332030147 40.1 35.67129637017588 139.74276266540983 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc699074-5888-4ba1-a8ec-f8a84b45281c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc699074-5888-4ba1-a8ec-f8a84b45281c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc699074-5888-4ba1-a8ec-f8a84b45281c">
											<gml:posList>35.6712980081815 139.74278332030147 40.1 35.6712980081815 139.74278332030147 7.28 35.67130036263036 139.7427977884086 7.28 35.67130036263036 139.7427977884086 40.1 35.6712980081815 139.74278332030147 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f52602af-576e-4fe4-90a1-1ad3bb67e325">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f52602af-576e-4fe4-90a1-1ad3bb67e325">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f52602af-576e-4fe4-90a1-1ad3bb67e325">
											<gml:posList>35.67130036263036 139.7427977884086 40.1 35.67130036263036 139.7427977884086 7.28 35.671304159522116 139.7428125862796 7.28 35.671304159522116 139.7428125862796 40.1 35.67130036263036 139.7427977884086 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7ae3098-ed3f-4eba-805b-0b450f7828a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7ae3098-ed3f-4eba-805b-0b450f7828a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7ae3098-ed3f-4eba-805b-0b450f7828a1">
											<gml:posList>35.67135660230773 139.7427898156829 40.1 35.67135660230773 139.7427898156829 42.959 35.67140282301428 139.74283551767564 42.959 35.67140282301428 139.74283551767564 40.1 35.67135660230773 139.7427898156829 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f56cdeed-8acc-4d97-98ae-fdc1d68a8c78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f56cdeed-8acc-4d97-98ae-fdc1d68a8c78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f56cdeed-8acc-4d97-98ae-fdc1d68a8c78">
											<gml:posList>35.67135660230773 139.7427898156829 42.959 35.67135660230773 139.7427898156829 40.1 35.671310059838994 139.7428316788224 40.1 35.671310059838994 139.7428316788224 7.28 35.671290143948504 139.74284959644731 7.28 35.671290143948504 139.74284959644731 44.359 35.67135660230773 139.7427898156829 42.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea8a9c03-46a0-49ea-85b8-0e599d1d6eea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea8a9c03-46a0-49ea-85b8-0e599d1d6eea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea8a9c03-46a0-49ea-85b8-0e599d1d6eea">
											<gml:posList>35.671304159522116 139.7428125862796 40.1 35.671304159522116 139.7428125862796 7.28 35.671310059838994 139.7428316788224 7.28 35.671310059838994 139.7428316788224 40.1 35.671304159522116 139.7428125862796 40.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-550af26a-25c9-45be-bcd0-1b9e2108c551">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-550af26a-25c9-45be-bcd0-1b9e2108c551">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-550af26a-25c9-45be-bcd0-1b9e2108c551">
											<gml:posList>35.67135750354153 139.74287357947335 42.101 35.67135750354153 139.74287357947335 44.359 35.67133610709956 139.74285244977509 44.359 35.67133610709956 139.74285244977509 42.101 35.67135750354153 139.74287357947335 42.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ced96b33-0f26-4498-8316-c57d1c1b3e72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ced96b33-0f26-4498-8316-c57d1c1b3e72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ced96b33-0f26-4498-8316-c57d1c1b3e72">
											<gml:posList>35.67131500303602 139.74288455230413 42.101 35.67131500303602 139.74288455230413 44.359 35.671290143948504 139.74284959644731 44.359 35.671290143948504 139.74284959644731 7.28 35.67131500303602 139.74288455230413 7.28 35.67131500303602 139.74288455230413 42.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebb56b26-289c-4a93-bb79-0769466880bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebb56b26-289c-4a93-bb79-0769466880bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebb56b26-289c-4a93-bb79-0769466880bf">
											<gml:posList>35.67133610709956 139.74285244977509 42.101 35.67133610709956 139.74285244977509 44.359 35.67131500303602 139.74288455230413 44.359 35.67131500303602 139.74288455230413 42.101 35.67133610709956 139.74285244977509 42.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df17809c-c821-4428-b387-ab71fb5427c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df17809c-c821-4428-b387-ab71fb5427c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df17809c-c821-4428-b387-ab71fb5427c4">
											<gml:posList>35.67133207780509 139.7429122373895 42.101 35.67133207780509 139.7429122373895 44.359 35.67135750354153 139.74287357947335 44.359 35.67135750354153 139.74287357947335 42.101 35.67133207780509 139.7429122373895 42.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73ec0489-c479-4e1c-8e91-c76e7f5fe2a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73ec0489-c479-4e1c-8e91-c76e7f5fe2a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73ec0489-c479-4e1c-8e91-c76e7f5fe2a8">
											<gml:posList>35.67131500303602 139.74288455230413 7.28 35.67130262329775 139.74290337826693 7.28 35.67130262329775 139.74290337826693 42.101 35.67131500303602 139.74288455230413 42.101 35.67131500303602 139.74288455230413 7.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd48fc1c-3f32-49de-ab24-22c0651df4f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd48fc1c-3f32-49de-ab24-22c0651df4f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd48fc1c-3f32-49de-ab24-22c0651df4f2">
											<gml:posList>35.67130262329775 139.74290337826693 42.101 35.67130262329775 139.74290337826693 7.28 35.67132401973091 139.74292450797 7.28 35.67132401973091 139.74292450797 42.101 35.67130262329775 139.74290337826693 42.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fdde6b71-3184-4e72-b049-5930dc5129e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdde6b71-3184-4e72-b049-5930dc5129e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdde6b71-3184-4e72-b049-5930dc5129e5">
											<gml:posList>35.67132401973091 139.74292450797 42.101 35.67132401973091 139.74292450797 7.28 35.67133207780509 139.7429122373895 7.28 35.67133207780509 139.7429122373895 42.101 35.67132401973091 139.74292450797 42.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5330b985-6b87-4330-8e2d-7c1f082d598c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5330b985-6b87-4330-8e2d-7c1f082d598c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5330b985-6b87-4330-8e2d-7c1f082d598c">
											<gml:posList>35.67134247696516 139.7429326725334 44.359 35.67133207780509 139.7429122373895 44.359 35.67133207780509 139.7429122373895 42.101 35.67133207780509 139.7429122373895 7.28 35.67134247696516 139.7429326725334 7.28 35.67134247696516 139.7429326725334 44.359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4479</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">839.71235</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>