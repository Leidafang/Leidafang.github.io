<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_c9959c4b-247c-4464-9efd-edba2b8e4ec7">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">4.1</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67237118519533 139.73945566548375 0 35.67233167374898 139.7394039477188 0 35.672280449506495 139.73946273103962 0 35.672319969941704 139.73951444879012 0 35.67237118519533 139.73945566548375 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67237118519533 139.73945566548375 8.33 35.672319969941704 139.73951444879012 8.33 35.672280449506495 139.73946273103962 8.33 35.67233167374898 139.7394039477188 8.33 35.67237118519533 139.73945566548375 8.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67237118519533 139.73945566548375 8.33 35.67233167374898 139.7394039477188 8.33 35.67233167374898 139.7394039477188 12.4 35.67237118519533 139.73945566548375 12.4 35.67237118519533 139.73945566548375 8.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67233167374898 139.7394039477188 8.33 35.672280449506495 139.73946273103962 8.33 35.672280449506495 139.73946273103962 12.4 35.67233167374898 139.7394039477188 12.4 35.67233167374898 139.7394039477188 8.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672280449506495 139.73946273103962 8.33 35.672319969941704 139.73951444879012 8.33 35.672319969941704 139.73951444879012 12.4 35.672280449506495 139.73946273103962 12.4 35.672280449506495 139.73946273103962 8.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672319969941704 139.73951444879012 8.33 35.67237118519533 139.73945566548375 8.33 35.67237118519533 139.73945566548375 12.4 35.672319969941704 139.73951444879012 12.4 35.672319969941704 139.73951444879012 8.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67237118519533 139.73945566548375 12.4 35.67233167374898 139.7394039477188 12.4 35.672280449506495 139.73946273103962 12.4 35.672319969941704 139.73951444879012 12.4 35.67237118519533 139.73945566548375 12.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-078c0681-b783-40d3-9e7d-c9a906a7f5dd"/>
							<gml:surfaceMember xlink:href="#poly-ff0ba50e-12da-499e-85e9-820e52689c5a"/>
							<gml:surfaceMember xlink:href="#poly-2bc6f86e-493b-4120-8460-1770ad9df70a"/>
							<gml:surfaceMember xlink:href="#poly-cb8c1355-2fa3-4006-8b49-6eeef547218e"/>
							<gml:surfaceMember xlink:href="#poly-593f3736-07be-4909-bb90-d6238a7819d4"/>
							<gml:surfaceMember xlink:href="#poly-e14454ae-b6b7-44a6-955a-b15d410c7499"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-078c0681-b783-40d3-9e7d-c9a906a7f5dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-078c0681-b783-40d3-9e7d-c9a906a7f5dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-078c0681-b783-40d3-9e7d-c9a906a7f5dd">
											<gml:posList>35.67237118519531 139.73945566548377 8.33 35.672319969941675 139.7395144487901 8.33 35.6722804495065 139.73946273103962 8.33 35.67233167374895 139.7394039477188 8.33 35.67237118519531 139.73945566548377 8.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ff0ba50e-12da-499e-85e9-820e52689c5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff0ba50e-12da-499e-85e9-820e52689c5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff0ba50e-12da-499e-85e9-820e52689c5a">
											<gml:posList>35.67233167374895 139.7394039477188 12.882 35.6722804495065 139.73946273103962 12.882 35.672319969941675 139.7395144487901 12.882 35.67237118519531 139.73945566548377 12.882 35.67233167374895 139.7394039477188 12.882</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2bc6f86e-493b-4120-8460-1770ad9df70a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bc6f86e-493b-4120-8460-1770ad9df70a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bc6f86e-493b-4120-8460-1770ad9df70a">
											<gml:posList>35.67233167374895 139.7394039477188 12.882 35.67233167374895 139.7394039477188 8.33 35.6722804495065 139.73946273103962 8.33 35.6722804495065 139.73946273103962 12.882 35.67233167374895 139.7394039477188 12.882</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb8c1355-2fa3-4006-8b49-6eeef547218e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb8c1355-2fa3-4006-8b49-6eeef547218e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb8c1355-2fa3-4006-8b49-6eeef547218e">
											<gml:posList>35.67237118519531 139.73945566548377 12.882 35.67237118519531 139.73945566548377 8.33 35.67233167374895 139.7394039477188 8.33 35.67233167374895 139.7394039477188 12.882 35.67237118519531 139.73945566548377 12.882</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-593f3736-07be-4909-bb90-d6238a7819d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-593f3736-07be-4909-bb90-d6238a7819d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-593f3736-07be-4909-bb90-d6238a7819d4">
											<gml:posList>35.672319969941675 139.7395144487901 12.882 35.672319969941675 139.7395144487901 8.33 35.67237118519531 139.73945566548377 8.33 35.67237118519531 139.73945566548377 12.882 35.672319969941675 139.7395144487901 12.882</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e14454ae-b6b7-44a6-955a-b15d410c7499">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e14454ae-b6b7-44a6-955a-b15d410c7499">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e14454ae-b6b7-44a6-955a-b15d410c7499">
											<gml:posList>35.6722804495065 139.73946273103962 12.882 35.6722804495065 139.73946273103962 8.33 35.672319969941675 139.7395144487901 8.33 35.672319969941675 139.7395144487901 12.882 35.6722804495065 139.73946273103962 12.882</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4084</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">222</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>