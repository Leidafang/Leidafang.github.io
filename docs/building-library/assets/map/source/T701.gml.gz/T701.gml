<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ca04cb33-da45-4bb3-89b6-43cdf5542574">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="説明注記">
				<gen:value>通気孔</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="地区計画">
				<gen:value>虎ノ門二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">16.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669543061139684 139.74496630825647 0 35.66946386658699 139.74506476135738 0 35.669483937298025 139.74508543972163 0 35.66959001356742 139.74495388482063 0 35.66957124839703 139.74493126090047 0 35.66954585280038 139.74496277041337 0 35.669543061139684 139.74496630825647 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669543061139684 139.74496630825647 7.21 35.66954585280038 139.74496277041337 7.21 35.66957124839703 139.74493126090047 7.21 35.66959001356742 139.74495388482063 7.21 35.669483937298025 139.74508543972163 7.21 35.66946386658699 139.74506476135738 7.21 35.669543061139684 139.74496630825647 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669543061139684 139.74496630825647 7.21 35.66946386658699 139.74506476135738 7.21 35.66946386658699 139.74506476135738 23.53 35.669543061139684 139.74496630825647 23.53 35.669543061139684 139.74496630825647 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66946386658699 139.74506476135738 7.21 35.669483937298025 139.74508543972163 7.21 35.669483937298025 139.74508543972163 23.53 35.66946386658699 139.74506476135738 23.53 35.66946386658699 139.74506476135738 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669483937298025 139.74508543972163 7.21 35.66959001356742 139.74495388482063 7.21 35.66959001356742 139.74495388482063 23.53 35.669483937298025 139.74508543972163 23.53 35.669483937298025 139.74508543972163 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66959001356742 139.74495388482063 7.21 35.66957124839703 139.74493126090047 7.21 35.66957124839703 139.74493126090047 23.53 35.66959001356742 139.74495388482063 23.53 35.66959001356742 139.74495388482063 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66957124839703 139.74493126090047 7.21 35.66954585280038 139.74496277041337 7.21 35.66954585280038 139.74496277041337 23.53 35.66957124839703 139.74493126090047 23.53 35.66957124839703 139.74493126090047 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66954585280038 139.74496277041337 7.21 35.669543061139684 139.74496630825647 7.21 35.669543061139684 139.74496630825647 23.53 35.66954585280038 139.74496277041337 23.53 35.66954585280038 139.74496277041337 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669543061139684 139.74496630825647 23.53 35.66946386658699 139.74506476135738 23.53 35.669483937298025 139.74508543972163 23.53 35.66959001356742 139.74495388482063 23.53 35.66957124839703 139.74493126090047 23.53 35.66954585280038 139.74496277041337 23.53 35.669543061139684 139.74496630825647 23.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ac967e79-a0bc-47da-a29b-e374eafeba21"/>
							<gml:surfaceMember xlink:href="#poly-5e82f060-f634-4a1a-8477-ea23c190d736"/>
							<gml:surfaceMember xlink:href="#poly-d698e93a-8813-4aaf-aebd-20ac5fdfb2ed"/>
							<gml:surfaceMember xlink:href="#poly-c41e424b-ece8-407d-b77b-b1dae1f4dd6e"/>
							<gml:surfaceMember xlink:href="#poly-bc85f368-a12c-4fc6-b6aa-314144f17015"/>
							<gml:surfaceMember xlink:href="#poly-2a7ca19d-6ad8-46a7-98dd-d99b5ee9f980"/>
							<gml:surfaceMember xlink:href="#poly-428d418c-3df1-43af-8e1f-5f217fd1db6d"/>
							<gml:surfaceMember xlink:href="#poly-272e2885-421b-4914-8244-c94d53b2c5d5"/>
							<gml:surfaceMember xlink:href="#poly-c8d080bd-aa63-40a8-961b-89f7aa3b1e0b"/>
							<gml:surfaceMember xlink:href="#poly-898b2387-aab3-41d3-bff6-f1bb990b1120"/>
							<gml:surfaceMember xlink:href="#poly-6f80a0b0-32a4-4b54-8755-dd7d85220e87"/>
							<gml:surfaceMember xlink:href="#poly-3f8003a5-2afc-498e-a660-59e49e24d427"/>
							<gml:surfaceMember xlink:href="#poly-1c468588-65e2-46db-acda-7b9830726fa8"/>
							<gml:surfaceMember xlink:href="#poly-30c830d2-7e7b-4d35-9c8d-ca4eee814769"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ac967e79-a0bc-47da-a29b-e374eafeba21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac967e79-a0bc-47da-a29b-e374eafeba21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac967e79-a0bc-47da-a29b-e374eafeba21">
											<gml:posList>35.66957124839702 139.74493126090047 7.21 35.669590013567436 139.7449538848206 7.21 35.669483937298025 139.74508543972163 7.21 35.66946386658699 139.74506476135738 7.21 35.66954306113967 139.74496630825644 7.21 35.669545852800375 139.74496277041337 7.21 35.66957124839702 139.74493126090047 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e82f060-f634-4a1a-8477-ea23c190d736">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e82f060-f634-4a1a-8477-ea23c190d736">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e82f060-f634-4a1a-8477-ea23c190d736">
											<gml:posList>35.669483937298025 139.74508543972163 24.987 35.66948376262092 139.74508077844433 24.987 35.669467985681266 139.7450645138078 24.987 35.66946386658699 139.74506476135738 24.987 35.669483937298025 139.74508543972163 24.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d698e93a-8813-4aaf-aebd-20ac5fdfb2ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d698e93a-8813-4aaf-aebd-20ac5fdfb2ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d698e93a-8813-4aaf-aebd-20ac5fdfb2ed">
											<gml:posList>35.66957124839702 139.74493126090047 24.987 35.66946386658699 139.74506476135738 24.987 35.669467985681266 139.7450645138078 24.987 35.66957126096261 139.74493609909962 24.987 35.66957124839702 139.74493126090047 24.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c41e424b-ece8-407d-b77b-b1dae1f4dd6e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c41e424b-ece8-407d-b77b-b1dae1f4dd6e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c41e424b-ece8-407d-b77b-b1dae1f4dd6e">
											<gml:posList>35.669467985681266 139.7450645138078 24.729 35.66948376262092 139.74508077844433 24.729 35.669586047552755 139.74495392233067 24.729 35.66957126096261 139.74493609909962 24.729 35.669467985681266 139.7450645138078 24.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc85f368-a12c-4fc6-b6aa-314144f17015">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc85f368-a12c-4fc6-b6aa-314144f17015">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc85f368-a12c-4fc6-b6aa-314144f17015">
											<gml:posList>35.669590013567436 139.7449538848206 24.987 35.669586047552755 139.74495392233067 24.987 35.66948376262092 139.74508077844433 24.987 35.669483937298025 139.74508543972163 24.987 35.669590013567436 139.7449538848206 24.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2a7ca19d-6ad8-46a7-98dd-d99b5ee9f980">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a7ca19d-6ad8-46a7-98dd-d99b5ee9f980">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a7ca19d-6ad8-46a7-98dd-d99b5ee9f980">
											<gml:posList>35.66957124839702 139.74493126090047 24.987 35.66957126096261 139.74493609909962 24.987 35.669586047552755 139.74495392233067 24.987 35.669590013567436 139.7449538848206 24.987 35.66957124839702 139.74493126090047 24.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-428d418c-3df1-43af-8e1f-5f217fd1db6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-428d418c-3df1-43af-8e1f-5f217fd1db6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-428d418c-3df1-43af-8e1f-5f217fd1db6d">
											<gml:posList>35.66946386658699 139.74506476135738 7.21 35.669483937298025 139.74508543972163 7.21 35.669483937298025 139.74508543972163 24.987 35.66946386658699 139.74506476135738 24.987 35.66946386658699 139.74506476135738 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-272e2885-421b-4914-8244-c94d53b2c5d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-272e2885-421b-4914-8244-c94d53b2c5d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-272e2885-421b-4914-8244-c94d53b2c5d5">
											<gml:posList>35.669467985681266 139.7450645138078 24.729 35.66957126096261 139.74493609909962 24.729 35.66957126096261 139.74493609909962 24.987 35.669467985681266 139.7450645138078 24.987 35.669467985681266 139.7450645138078 24.729</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8d080bd-aa63-40a8-961b-89f7aa3b1e0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8d080bd-aa63-40a8-961b-89f7aa3b1e0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8d080bd-aa63-40a8-961b-89f7aa3b1e0b">
											<gml:posList>35.669586047552755 139.74495392233067 24.987 35.669586047552755 139.74495392233067 24.729 35.66948376262092 139.74508077844433 24.729 35.66948376262092 139.74508077844433 24.987 35.669586047552755 139.74495392233067 24.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-898b2387-aab3-41d3-bff6-f1bb990b1120">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-898b2387-aab3-41d3-bff6-f1bb990b1120">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-898b2387-aab3-41d3-bff6-f1bb990b1120">
											<gml:posList>35.669590013567436 139.7449538848206 7.21 35.66957124839702 139.74493126090047 7.21 35.66957124839702 139.74493126090047 24.987 35.669590013567436 139.7449538848206 24.987 35.669590013567436 139.7449538848206 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f80a0b0-32a4-4b54-8755-dd7d85220e87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f80a0b0-32a4-4b54-8755-dd7d85220e87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f80a0b0-32a4-4b54-8755-dd7d85220e87">
											<gml:posList>35.66957126096261 139.74493609909962 24.987 35.66957126096261 139.74493609909962 24.729 35.669586047552755 139.74495392233067 24.729 35.669586047552755 139.74495392233067 24.987 35.66957126096261 139.74493609909962 24.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f8003a5-2afc-498e-a660-59e49e24d427">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f8003a5-2afc-498e-a660-59e49e24d427">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f8003a5-2afc-498e-a660-59e49e24d427">
											<gml:posList>35.66957124839702 139.74493126090047 24.987 35.66957124839702 139.74493126090047 7.21 35.669545852800375 139.74496277041337 7.21 35.66954306113967 139.74496630825644 7.21 35.66946386658699 139.74506476135738 7.21 35.66946386658699 139.74506476135738 24.987 35.66957124839702 139.74493126090047 24.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c468588-65e2-46db-acda-7b9830726fa8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c468588-65e2-46db-acda-7b9830726fa8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c468588-65e2-46db-acda-7b9830726fa8">
											<gml:posList>35.669483937298025 139.74508543972163 7.21 35.669590013567436 139.7449538848206 7.21 35.669590013567436 139.7449538848206 24.987 35.669483937298025 139.74508543972163 24.987 35.669483937298025 139.74508543972163 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30c830d2-7e7b-4d35-9c8d-ca4eee814769">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30c830d2-7e7b-4d35-9c8d-ca4eee814769">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30c830d2-7e7b-4d35-9c8d-ca4eee814769">
											<gml:posList>35.66948376262092 139.74508077844433 24.987 35.66948376262092 139.74508077844433 24.729 35.669467985681266 139.7450645138078 24.729 35.669467985681266 139.7450645138078 24.987 35.66948376262092 139.74508077844433 24.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6677</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">49.02715</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>