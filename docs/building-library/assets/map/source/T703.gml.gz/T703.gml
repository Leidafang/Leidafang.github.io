<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_cb051e85-aa5e-46e2-8100-69719822ce28">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">21.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671449867319076 139.73774013269403 0 35.67147947081064 139.73778859113992 0 35.67155593565173 139.73771084367482 0 35.6715009103662 139.73765854930235 0 35.671449867319076 139.73774013269403 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671449867319076 139.73774013269403 10.88 35.6715009103662 139.73765854930235 10.88 35.67155593565173 139.73771084367482 10.88 35.67147947081064 139.73778859113992 10.88 35.671449867319076 139.73774013269403 10.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671449867319076 139.73774013269403 10.88 35.67147947081064 139.73778859113992 10.88 35.67147947081064 139.73778859113992 32.05 35.671449867319076 139.73774013269403 32.05 35.671449867319076 139.73774013269403 10.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67147947081064 139.73778859113992 10.88 35.67155593565173 139.73771084367482 10.88 35.67155593565173 139.73771084367482 32.05 35.67147947081064 139.73778859113992 32.05 35.67147947081064 139.73778859113992 10.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67155593565173 139.73771084367482 10.88 35.6715009103662 139.73765854930235 10.88 35.6715009103662 139.73765854930235 32.05 35.67155593565173 139.73771084367482 32.05 35.67155593565173 139.73771084367482 10.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715009103662 139.73765854930235 10.88 35.671449867319076 139.73774013269403 10.88 35.671449867319076 139.73774013269403 32.05 35.6715009103662 139.73765854930235 32.05 35.6715009103662 139.73765854930235 10.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671449867319076 139.73774013269403 32.05 35.67147947081064 139.73778859113992 32.05 35.67155593565173 139.73771084367482 32.05 35.6715009103662 139.73765854930235 32.05 35.671449867319076 139.73774013269403 32.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ec352689-2438-4c9b-a231-b7de903213f2"/>
							<gml:surfaceMember xlink:href="#poly-c096abb3-f027-4a71-aabc-d0dbf6e35b9a"/>
							<gml:surfaceMember xlink:href="#poly-cf8bff9e-0fd0-4724-be77-e85b70e93934"/>
							<gml:surfaceMember xlink:href="#poly-0a258af2-107b-4289-9a52-90a8b6f0f2a4"/>
							<gml:surfaceMember xlink:href="#poly-09f5683b-a14d-4987-a90a-baf1bf9ece9e"/>
							<gml:surfaceMember xlink:href="#poly-68fc2f95-e4be-4cc1-92a7-026fb48eb7ab"/>
							<gml:surfaceMember xlink:href="#poly-dc9727cc-8a21-484c-92ec-005c467af8a5"/>
							<gml:surfaceMember xlink:href="#poly-1b1a0709-c6c3-4a55-9cf5-ea03c33319b0"/>
							<gml:surfaceMember xlink:href="#poly-01fe85ce-0282-4f38-a872-aa0f0447c722"/>
							<gml:surfaceMember xlink:href="#poly-08d59d7a-3905-43e7-86d0-8e10b2afa18a"/>
							<gml:surfaceMember xlink:href="#poly-0b83d3c6-6bc1-44f3-ba43-ebc02ec558d6"/>
							<gml:surfaceMember xlink:href="#poly-16c2b6d9-ac80-4f9a-8129-389555ca93c2"/>
							<gml:surfaceMember xlink:href="#poly-18ef32c0-95e3-4a17-bcfe-cec07908b1b5"/>
							<gml:surfaceMember xlink:href="#poly-503137d8-e391-47c3-8a58-009111bb2c82"/>
							<gml:surfaceMember xlink:href="#poly-ce63b4cb-73e2-4220-87c9-244cd23d5079"/>
							<gml:surfaceMember xlink:href="#poly-f3fe33f4-811a-4cc3-bf7f-a1dc889d7028"/>
							<gml:surfaceMember xlink:href="#poly-11c5fb04-0100-402a-8768-cce1a98dbde8"/>
							<gml:surfaceMember xlink:href="#poly-cbb5618d-3543-4eb3-81bf-78c8c0d4b4d1"/>
							<gml:surfaceMember xlink:href="#poly-5b4396b1-c23d-4a1b-89cf-dc2f5db5c4cc"/>
							<gml:surfaceMember xlink:href="#poly-86b46466-fb00-4fa7-a44f-ac7f00fbe422"/>
							<gml:surfaceMember xlink:href="#poly-3f9c488d-21ab-4be8-8383-2ede0a0aa699"/>
							<gml:surfaceMember xlink:href="#poly-0a647c06-9080-4577-9f34-0c3b704e9415"/>
							<gml:surfaceMember xlink:href="#poly-7f30421a-05ab-427b-b7d6-2fe589456e04"/>
							<gml:surfaceMember xlink:href="#poly-8c159f59-cd6d-4261-9600-3fc463dfab05"/>
							<gml:surfaceMember xlink:href="#poly-a40b405b-6872-4d79-bed0-85f3bbcfb250"/>
							<gml:surfaceMember xlink:href="#poly-39f0b5c1-60bd-4ab7-95a9-705f860e4d08"/>
							<gml:surfaceMember xlink:href="#poly-fb142167-219c-480b-b53d-8b8f2c466705"/>
							<gml:surfaceMember xlink:href="#poly-751edbf3-5c93-4268-807b-9db3bea991e5"/>
							<gml:surfaceMember xlink:href="#poly-f6606f47-1267-4012-9076-cc4e858d401c"/>
							<gml:surfaceMember xlink:href="#poly-2cc10cd2-7357-4412-9700-1ba8e51062dd"/>
							<gml:surfaceMember xlink:href="#poly-8ecaff94-9382-40b3-a1b0-86481e393ef3"/>
							<gml:surfaceMember xlink:href="#poly-dd2d5e9b-8869-451d-b8d5-6a1f158149f7"/>
							<gml:surfaceMember xlink:href="#poly-29d162be-fae4-4dca-a7f7-f6c0b6c7e37a"/>
							<gml:surfaceMember xlink:href="#poly-1de9e45c-ed2b-4b78-8a7d-1eb4e1eac8f7"/>
							<gml:surfaceMember xlink:href="#poly-b51a5631-fde8-49d1-a69f-2cce3a6b0907"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_cb051e85-aa5e-46e2-8100-69719822ce28_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8de9678c-9ac5-4d3c-90e6-1fa73fb9c8dc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671499425757 139.7376959321368 32.147 35.67148804602124 139.73771307869603 32.147 35.671479855071574 139.7377049141211 32.147 35.67149123480618 139.73768776756248 32.147 35.671499425757 139.7376959321368 32.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f74be8fe-da66-4b05-bbd1-d162d2d2a164">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67148102990594 139.73773145724505 32.147 35.67147146784113 139.73774470224572 32.147 35.67146050671713 139.7377328072864 32.147 35.671470059775714 139.73771957334327 32.147 35.67148102990594 139.73773145724505 32.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e18236ec-7687-41c0-b6fe-8d78c95285f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e18236ec-7687-41c0-b6fe-8d78c95285f6_0">
											<gml:posList>35.67149123480618 139.73768776756248 32.147 35.67149123480618 139.73768776756248 34.621 35.671499425757 139.7376959321368 34.621 35.671499425757 139.7376959321368 32.147 35.67149123480618 139.73768776756248 32.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7facbc5-5371-4e4a-85ef-b4e3342806de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7facbc5-5371-4e4a-85ef-b4e3342806de_0">
											<gml:posList>35.67149123480618 139.73768776756248 32.147 35.671479855071574 139.7377049141211 32.147 35.671479855071574 139.7377049141211 34.621 35.67149123480618 139.73768776756248 34.621 35.67149123480618 139.73768776756248 32.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-545ccb8f-6e2f-44e9-9bf4-201a77571f0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-545ccb8f-6e2f-44e9-9bf4-201a77571f0c_0">
											<gml:posList>35.671479855071574 139.7377049141211 34.621 35.67148804602124 139.73771307869603 34.621 35.671499425757 139.7376959321368 34.621 35.67149123480618 139.73768776756248 34.621 35.671479855071574 139.7377049141211 34.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae094d19-8fc0-4d4e-bb03-7c335725da22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae094d19-8fc0-4d4e-bb03-7c335725da22_0">
											<gml:posList>35.67148804602124 139.73771307869603 32.147 35.671499425757 139.7376959321368 32.147 35.671499425757 139.7376959321368 34.621 35.67148804602124 139.73771307869603 34.621 35.67148804602124 139.73771307869603 32.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ce27226-57e7-41cf-8657-ec682b27cd88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ce27226-57e7-41cf-8657-ec682b27cd88_0">
											<gml:posList>35.671479855071574 139.7377049141211 32.147 35.67148804602124 139.73771307869603 32.147 35.67148804602124 139.73771307869603 34.621 35.671479855071574 139.7377049141211 34.621 35.671479855071574 139.7377049141211 32.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-836e38f7-6a0d-4d6f-bba1-4e1c4a7b51dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-836e38f7-6a0d-4d6f-bba1-4e1c4a7b51dd_0">
											<gml:posList>35.67148102990594 139.73773145724505 32.147 35.671470059775714 139.73771957334327 32.147 35.671470059775714 139.73771957334327 34.621 35.67148102990594 139.73773145724505 34.621 35.67148102990594 139.73773145724505 32.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce3564fd-0d6e-422d-9c5a-246ea36e853d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce3564fd-0d6e-422d-9c5a-246ea36e853d_0">
											<gml:posList>35.671470059775714 139.73771957334327 32.147 35.67146050671713 139.7377328072864 32.147 35.67146050671713 139.7377328072864 34.621 35.671470059775714 139.73771957334327 34.621 35.671470059775714 139.73771957334327 32.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9bc1093-3341-47e4-8aa1-157e67332e4b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9bc1093-3341-47e4-8aa1-157e67332e4b_0">
											<gml:posList>35.67146050671713 139.7377328072864 34.621 35.67147146784113 139.73774470224572 34.621 35.67148102990594 139.73773145724505 34.621 35.671470059775714 139.73771957334327 34.621 35.67146050671713 139.7377328072864 34.621</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92e22268-9653-4d26-9005-0867d247554f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92e22268-9653-4d26-9005-0867d247554f_0">
											<gml:posList>35.67147146784113 139.73774470224572 32.147 35.67148102990594 139.73773145724505 32.147 35.67148102990594 139.73773145724505 34.621 35.67147146784113 139.73774470224572 34.621 35.67147146784113 139.73774470224572 32.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e10abe4a-5747-4599-8647-1cc2b465ab17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e10abe4a-5747-4599-8647-1cc2b465ab17_0">
											<gml:posList>35.67146050671713 139.7377328072864 32.147 35.67147146784113 139.73774470224572 32.147 35.67147146784113 139.73774470224572 34.621 35.67146050671713 139.7377328072864 34.621 35.67146050671713 139.7377328072864 32.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ec352689-2438-4c9b-a231-b7de903213f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec352689-2438-4c9b-a231-b7de903213f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec352689-2438-4c9b-a231-b7de903213f2">
											<gml:posList>35.67144986731906 139.73774013269403 10.88 35.67150091036617 139.73765854930235 10.88 35.67155593565173 139.73771084367485 10.88 35.67147947081061 139.7377885911399 10.88 35.67144986731906 139.73774013269403 10.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c096abb3-f027-4a71-aabc-d0dbf6e35b9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c096abb3-f027-4a71-aabc-d0dbf6e35b9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c096abb3-f027-4a71-aabc-d0dbf6e35b9a">
											<gml:posList>35.67150091036617 139.73765854930235 32.378 35.6715012645519 139.7376618848966 32.378 35.67155278987215 139.73771085847318 32.378 35.67155593565173 139.73771084367485 32.378 35.67150091036617 139.73765854930235 32.378</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf8bff9e-0fd0-4724-be77-e85b70e93934">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf8bff9e-0fd0-4724-be77-e85b70e93934">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf8bff9e-0fd0-4724-be77-e85b70e93934">
											<gml:posList>35.67144986731906 139.73774013269403 32.378 35.67145231004606 139.73774014082792 32.378 35.6715012645519 139.7376618848966 32.378 35.67150091036617 139.73765854930235 32.378 35.67144986731906 139.73774013269403 32.378</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a258af2-107b-4289-9a52-90a8b6f0f2a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a258af2-107b-4289-9a52-90a8b6f0f2a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a258af2-107b-4289-9a52-90a8b6f0f2a4">
											<gml:posList>35.67150604124028 139.73771788451697 37.392 35.67150622287427 139.73771959649457 37.392 35.671518241295416 139.7377008253474 37.392 35.67151807768859 139.73769911334807 37.392 35.67150604124028 139.73771788451697 37.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09f5683b-a14d-4987-a90a-baf1bf9ece9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09f5683b-a14d-4987-a90a-baf1bf9ece9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09f5683b-a14d-4987-a90a-baf1bf9ece9e">
											<gml:posList>35.67151807768859 139.73769911334807 37.392 35.671518241295416 139.7377008253474 37.392 35.67153968333014 139.73772147866734 37.392 35.67154125168238 139.7377214326113 37.392 35.67151807768859 139.73769911334807 37.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-68fc2f95-e4be-4cc1-92a7-026fb48eb7ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68fc2f95-e4be-4cc1-92a7-026fb48eb7ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68fc2f95-e4be-4cc1-92a7-026fb48eb7ab">
											<gml:posList>35.67150604124028 139.73771788451697 37.392 35.6715009716523 139.73771300804813 37.392 35.67150114427265 139.73771472003637 37.392 35.67150622287427 139.73771959649457 37.392 35.67150604124028 139.73771788451697 37.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc9727cc-8a21-484c-92ec-005c467af8a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc9727cc-8a21-484c-92ec-005c467af8a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc9727cc-8a21-484c-92ec-005c467af8a5">
											<gml:posList>35.67151807768859 139.73769911334807 32.147 35.67154125168238 139.7377214326113 32.147 35.67155278987215 139.73771085847318 32.147 35.6715012645519 139.7376618848966 32.147 35.67145231004606 139.73774014082792 32.147 35.67147981060598 139.73778515530125 32.147 35.67149605862894 139.737769096546 32.147 35.67147686273726 139.73775060564307 32.147 35.6715009716523 139.73771300804813 32.147 35.67150604124028 139.73771788451697 32.147 35.67151807768859 139.73769911334807 32.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b1a0709-c6c3-4a55-9cf5-ea03c33319b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b1a0709-c6c3-4a55-9cf5-ea03c33319b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b1a0709-c6c3-4a55-9cf5-ea03c33319b0">
											<gml:posList>35.67147686273726 139.73775060564307 37.392 35.67147826871103 139.73775039408508 37.392 35.67150114427265 139.73771472003637 37.392 35.6715009716523 139.73771300804813 37.392 35.67147686273726 139.73775060564307 37.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-01fe85ce-0282-4f38-a872-aa0f0447c722">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01fe85ce-0282-4f38-a872-aa0f0447c722">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01fe85ce-0282-4f38-a872-aa0f0447c722">
											<gml:posList>35.67149603933905 139.73776750588556 37.298 35.67153968333014 139.73772147866734 37.298 35.671518241295416 139.7377008253474 37.298 35.67150622287427 139.73771959649457 37.298 35.67150114427265 139.73771472003637 37.298 35.67147826871103 139.73775039408508 37.298 35.67149603933905 139.73776750588556 37.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08d59d7a-3905-43e7-86d0-8e10b2afa18a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08d59d7a-3905-43e7-86d0-8e10b2afa18a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08d59d7a-3905-43e7-86d0-8e10b2afa18a">
											<gml:posList>35.67154125168238 139.7377214326113 32.378 35.67149605862894 139.737769096546 32.378 35.67155593565173 139.73771084367485 32.378 35.67155278987215 139.73771085847318 32.378 35.67154125168238 139.7377214326113 32.378</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b83d3c6-6bc1-44f3-ba43-ebc02ec558d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b83d3c6-6bc1-44f3-ba43-ebc02ec558d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b83d3c6-6bc1-44f3-ba43-ebc02ec558d6">
											<gml:posList>35.67149605862894 139.737769096546 37.392 35.67154125168238 139.7377214326113 37.392 35.67153968333014 139.73772147866734 37.392 35.67149603933905 139.73776750588556 37.392 35.67149605862894 139.737769096546 37.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16c2b6d9-ac80-4f9a-8129-389555ca93c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16c2b6d9-ac80-4f9a-8129-389555ca93c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16c2b6d9-ac80-4f9a-8129-389555ca93c2">
											<gml:posList>35.67147947081061 139.7377885911399 32.378 35.67155593565173 139.73771084367485 32.378 35.67149605862894 139.737769096546 32.378 35.67147981060598 139.73778515530125 32.378 35.67147947081061 139.7377885911399 32.378</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18ef32c0-95e3-4a17-bcfe-cec07908b1b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18ef32c0-95e3-4a17-bcfe-cec07908b1b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18ef32c0-95e3-4a17-bcfe-cec07908b1b5">
											<gml:posList>35.67149605862894 139.737769096546 37.392 35.67149603933905 139.73776750588556 37.392 35.67147826871103 139.73775039408508 37.392 35.67147686273726 139.73775060564307 37.392 35.67149605862894 139.737769096546 37.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-503137d8-e391-47c3-8a58-009111bb2c82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-503137d8-e391-47c3-8a58-009111bb2c82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-503137d8-e391-47c3-8a58-009111bb2c82">
											<gml:posList>35.67144986731906 139.73774013269403 32.378 35.67147947081061 139.7377885911399 32.378 35.67147981060598 139.73778515530125 32.378 35.67145231004606 139.73774014082792 32.378 35.67144986731906 139.73774013269403 32.378</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce63b4cb-73e2-4220-87c9-244cd23d5079">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce63b4cb-73e2-4220-87c9-244cd23d5079">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce63b4cb-73e2-4220-87c9-244cd23d5079">
											<gml:posList>35.67145231004606 139.73774014082792 32.378 35.67145231004606 139.73774014082792 32.147 35.6715012645519 139.7376618848966 32.147 35.6715012645519 139.7376618848966 32.378 35.67145231004606 139.73774014082792 32.378</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3fe33f4-811a-4cc3-bf7f-a1dc889d7028">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3fe33f4-811a-4cc3-bf7f-a1dc889d7028">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3fe33f4-811a-4cc3-bf7f-a1dc889d7028">
											<gml:posList>35.67150622287427 139.73771959649457 37.392 35.67150622287427 139.73771959649457 37.298 35.671518241295416 139.7377008253474 37.298 35.671518241295416 139.7377008253474 37.392 35.67150622287427 139.73771959649457 37.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11c5fb04-0100-402a-8768-cce1a98dbde8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11c5fb04-0100-402a-8768-cce1a98dbde8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11c5fb04-0100-402a-8768-cce1a98dbde8">
											<gml:posList>35.67155278987215 139.73771085847318 32.378 35.67155278987215 139.73771085847318 32.147 35.67154125168238 139.7377214326113 32.147 35.67154125168238 139.7377214326113 32.378 35.67155278987215 139.73771085847318 32.378</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbb5618d-3543-4eb3-81bf-78c8c0d4b4d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbb5618d-3543-4eb3-81bf-78c8c0d4b4d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbb5618d-3543-4eb3-81bf-78c8c0d4b4d1">
											<gml:posList>35.67147826871103 139.73775039408508 37.392 35.67147826871103 139.73775039408508 37.298 35.67150114427265 139.73771472003637 37.298 35.67150114427265 139.73771472003637 37.392 35.67147826871103 139.73775039408508 37.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b4396b1-c23d-4a1b-89cf-dc2f5db5c4cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b4396b1-c23d-4a1b-89cf-dc2f5db5c4cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b4396b1-c23d-4a1b-89cf-dc2f5db5c4cc">
											<gml:posList>35.67153968333014 139.73772147866734 37.392 35.67153968333014 139.73772147866734 37.298 35.67149603933905 139.73776750588556 37.298 35.67149603933905 139.73776750588556 37.392 35.67153968333014 139.73772147866734 37.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86b46466-fb00-4fa7-a44f-ac7f00fbe422">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86b46466-fb00-4fa7-a44f-ac7f00fbe422">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86b46466-fb00-4fa7-a44f-ac7f00fbe422">
											<gml:posList>35.67144986731906 139.73774013269403 10.88 35.67147947081061 139.7377885911399 10.88 35.67147947081061 139.7377885911399 32.378 35.67144986731906 139.73774013269403 32.378 35.67144986731906 139.73774013269403 10.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f9c488d-21ab-4be8-8383-2ede0a0aa699">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f9c488d-21ab-4be8-8383-2ede0a0aa699">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f9c488d-21ab-4be8-8383-2ede0a0aa699">
											<gml:posList>35.67147981060598 139.73778515530125 32.378 35.67147981060598 139.73778515530125 32.147 35.67145231004606 139.73774014082792 32.147 35.67145231004606 139.73774014082792 32.378 35.67147981060598 139.73778515530125 32.378</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a647c06-9080-4577-9f34-0c3b704e9415">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a647c06-9080-4577-9f34-0c3b704e9415">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a647c06-9080-4577-9f34-0c3b704e9415">
											<gml:posList>35.67150091036617 139.73765854930235 10.88 35.67144986731906 139.73774013269403 10.88 35.67144986731906 139.73774013269403 32.378 35.67150091036617 139.73765854930235 32.378 35.67150091036617 139.73765854930235 10.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f30421a-05ab-427b-b7d6-2fe589456e04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f30421a-05ab-427b-b7d6-2fe589456e04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f30421a-05ab-427b-b7d6-2fe589456e04">
											<gml:posList>35.67147686273726 139.73775060564307 37.392 35.67147686273726 139.73775060564307 32.147 35.67149605862894 139.737769096546 32.147 35.67149605862894 139.737769096546 32.378 35.67149605862894 139.737769096546 37.392 35.67147686273726 139.73775060564307 37.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c159f59-cd6d-4261-9600-3fc463dfab05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c159f59-cd6d-4261-9600-3fc463dfab05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c159f59-cd6d-4261-9600-3fc463dfab05">
											<gml:posList>35.67149603933905 139.73776750588556 37.392 35.67149603933905 139.73776750588556 37.298 35.67147826871103 139.73775039408508 37.298 35.67147826871103 139.73775039408508 37.392 35.67149603933905 139.73776750588556 37.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a40b405b-6872-4d79-bed0-85f3bbcfb250">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a40b405b-6872-4d79-bed0-85f3bbcfb250">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a40b405b-6872-4d79-bed0-85f3bbcfb250">
											<gml:posList>35.67149605862894 139.737769096546 32.378 35.67149605862894 139.737769096546 32.147 35.67147981060598 139.73778515530125 32.147 35.67147981060598 139.73778515530125 32.378 35.67149605862894 139.737769096546 32.378</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39f0b5c1-60bd-4ab7-95a9-705f860e4d08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39f0b5c1-60bd-4ab7-95a9-705f860e4d08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39f0b5c1-60bd-4ab7-95a9-705f860e4d08">
											<gml:posList>35.67147686273726 139.73775060564307 37.392 35.6715009716523 139.73771300804813 37.392 35.6715009716523 139.73771300804813 32.147 35.67147686273726 139.73775060564307 32.147 35.67147686273726 139.73775060564307 37.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb142167-219c-480b-b53d-8b8f2c466705">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb142167-219c-480b-b53d-8b8f2c466705">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb142167-219c-480b-b53d-8b8f2c466705">
											<gml:posList>35.6715009716523 139.73771300804813 37.392 35.67150604124028 139.73771788451697 37.392 35.67150604124028 139.73771788451697 32.147 35.6715009716523 139.73771300804813 32.147 35.6715009716523 139.73771300804813 37.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-751edbf3-5c93-4268-807b-9db3bea991e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-751edbf3-5c93-4268-807b-9db3bea991e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-751edbf3-5c93-4268-807b-9db3bea991e5">
											<gml:posList>35.67150114427265 139.73771472003637 37.392 35.67150114427265 139.73771472003637 37.298 35.67150622287427 139.73771959649457 37.298 35.67150622287427 139.73771959649457 37.392 35.67150114427265 139.73771472003637 37.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6606f47-1267-4012-9076-cc4e858d401c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6606f47-1267-4012-9076-cc4e858d401c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6606f47-1267-4012-9076-cc4e858d401c">
											<gml:posList>35.67150604124028 139.73771788451697 37.392 35.67151807768859 139.73769911334807 37.392 35.67151807768859 139.73769911334807 32.147 35.67150604124028 139.73771788451697 32.147 35.67150604124028 139.73771788451697 37.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2cc10cd2-7357-4412-9700-1ba8e51062dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cc10cd2-7357-4412-9700-1ba8e51062dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cc10cd2-7357-4412-9700-1ba8e51062dd">
											<gml:posList>35.67147947081061 139.7377885911399 10.88 35.67155593565173 139.73771084367485 10.88 35.67155593565173 139.73771084367485 32.378 35.67147947081061 139.7377885911399 32.378 35.67147947081061 139.7377885911399 10.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ecaff94-9382-40b3-a1b0-86481e393ef3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ecaff94-9382-40b3-a1b0-86481e393ef3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ecaff94-9382-40b3-a1b0-86481e393ef3">
											<gml:posList>35.67154125168238 139.7377214326113 32.378 35.67154125168238 139.7377214326113 37.392 35.67149605862894 139.737769096546 37.392 35.67149605862894 139.737769096546 32.378 35.67154125168238 139.7377214326113 32.378</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd2d5e9b-8869-451d-b8d5-6a1f158149f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd2d5e9b-8869-451d-b8d5-6a1f158149f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd2d5e9b-8869-451d-b8d5-6a1f158149f7">
											<gml:posList>35.6715012645519 139.7376618848966 32.378 35.6715012645519 139.7376618848966 32.147 35.67155278987215 139.73771085847318 32.147 35.67155278987215 139.73771085847318 32.378 35.6715012645519 139.7376618848966 32.378</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29d162be-fae4-4dca-a7f7-f6c0b6c7e37a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29d162be-fae4-4dca-a7f7-f6c0b6c7e37a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29d162be-fae4-4dca-a7f7-f6c0b6c7e37a">
											<gml:posList>35.67155593565173 139.73771084367485 10.88 35.67150091036617 139.73765854930235 10.88 35.67150091036617 139.73765854930235 32.378 35.67155593565173 139.73771084367485 32.378 35.67155593565173 139.73771084367485 10.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1de9e45c-ed2b-4b78-8a7d-1eb4e1eac8f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1de9e45c-ed2b-4b78-8a7d-1eb4e1eac8f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1de9e45c-ed2b-4b78-8a7d-1eb4e1eac8f7">
											<gml:posList>35.671518241295416 139.7377008253474 37.392 35.671518241295416 139.7377008253474 37.298 35.67153968333014 139.73772147866734 37.298 35.67153968333014 139.73772147866734 37.392 35.671518241295416 139.7377008253474 37.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b51a5631-fde8-49d1-a69f-2cce3a6b0907">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b51a5631-fde8-49d1-a69f-2cce3a6b0907">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b51a5631-fde8-49d1-a69f-2cce3a6b0907">
											<gml:posList>35.67151807768859 139.73769911334807 32.147 35.67151807768859 139.73769911334807 37.392 35.67154125168238 139.7377214326113 37.392 35.67154125168238 139.7377214326113 32.378 35.67154125168238 139.7377214326113 32.147 35.67151807768859 139.73769911334807 32.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6929</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">66.11165</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>