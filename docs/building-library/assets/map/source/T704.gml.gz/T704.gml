<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_cbc63d4f-e4ae-4e40-a4d2-fab1fe665992">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">12.6</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67122837901273 139.74395610437287 0 35.67121160658269 139.74395896198857 0 35.67122006252022 139.74403328362322 0 35.67123683495204 139.74403042602273 0 35.67123614541953 139.7440243733758 0 35.67144360618133 139.7439889484283 0 35.671441038518005 139.74396633929666 0 35.671444805778286 139.7439656944059 0 35.671447518603884 139.74398957371358 0 35.67153664407822 139.743974351847 0 35.671533786095246 139.74394921338336 0 35.671536838147084 139.74394436060268 0 35.671520225257645 139.74390715270016 0 35.67145788520209 139.74391780469324 0 35.67145737711962 139.743913342511 0 35.67122797073039 139.74395251475562 0 35.67122837901273 139.74395610437287 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67122837901273 139.74395610437287 6.74 35.67122797073039 139.74395251475562 6.74 35.67145737711962 139.743913342511 6.74 35.67145788520209 139.74391780469324 6.74 35.671520225257645 139.74390715270016 6.74 35.671536838147084 139.74394436060268 6.74 35.671533786095246 139.74394921338336 6.74 35.67153664407822 139.743974351847 6.74 35.671447518603884 139.74398957371358 6.74 35.671444805778286 139.7439656944059 6.74 35.671441038518005 139.74396633929666 6.74 35.67144360618133 139.7439889484283 6.74 35.67123614541953 139.7440243733758 6.74 35.67123683495204 139.74403042602273 6.74 35.67122006252022 139.74403328362322 6.74 35.67121160658269 139.74395896198857 6.74 35.67122837901273 139.74395610437287 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67122837901273 139.74395610437287 6.74 35.67121160658269 139.74395896198857 6.74 35.67121160658269 139.74395896198857 19.33 35.67122837901273 139.74395610437287 19.33 35.67122837901273 139.74395610437287 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121160658269 139.74395896198857 6.74 35.67122006252022 139.74403328362322 6.74 35.67122006252022 139.74403328362322 19.33 35.67121160658269 139.74395896198857 19.33 35.67121160658269 139.74395896198857 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67122006252022 139.74403328362322 6.74 35.67123683495204 139.74403042602273 6.74 35.67123683495204 139.74403042602273 19.33 35.67122006252022 139.74403328362322 19.33 35.67122006252022 139.74403328362322 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67123683495204 139.74403042602273 6.74 35.67123614541953 139.7440243733758 6.74 35.67123614541953 139.7440243733758 19.33 35.67123683495204 139.74403042602273 19.33 35.67123683495204 139.74403042602273 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67123614541953 139.7440243733758 6.74 35.67144360618133 139.7439889484283 6.74 35.67144360618133 139.7439889484283 19.33 35.67123614541953 139.7440243733758 19.33 35.67123614541953 139.7440243733758 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67144360618133 139.7439889484283 6.74 35.671441038518005 139.74396633929666 6.74 35.671441038518005 139.74396633929666 19.33 35.67144360618133 139.7439889484283 19.33 35.67144360618133 139.7439889484283 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671441038518005 139.74396633929666 6.74 35.671444805778286 139.7439656944059 6.74 35.671444805778286 139.7439656944059 19.33 35.671441038518005 139.74396633929666 19.33 35.671441038518005 139.74396633929666 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671444805778286 139.7439656944059 6.74 35.671447518603884 139.74398957371358 6.74 35.671447518603884 139.74398957371358 19.33 35.671444805778286 139.7439656944059 19.33 35.671444805778286 139.7439656944059 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671447518603884 139.74398957371358 6.74 35.67153664407822 139.743974351847 6.74 35.67153664407822 139.743974351847 19.33 35.671447518603884 139.74398957371358 19.33 35.671447518603884 139.74398957371358 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67153664407822 139.743974351847 6.74 35.671533786095246 139.74394921338336 6.74 35.671533786095246 139.74394921338336 19.33 35.67153664407822 139.743974351847 19.33 35.67153664407822 139.743974351847 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671533786095246 139.74394921338336 6.74 35.671536838147084 139.74394436060268 6.74 35.671536838147084 139.74394436060268 19.33 35.671533786095246 139.74394921338336 19.33 35.671533786095246 139.74394921338336 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671536838147084 139.74394436060268 6.74 35.671520225257645 139.74390715270016 6.74 35.671520225257645 139.74390715270016 19.33 35.671536838147084 139.74394436060268 19.33 35.671536838147084 139.74394436060268 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671520225257645 139.74390715270016 6.74 35.67145788520209 139.74391780469324 6.74 35.67145788520209 139.74391780469324 19.33 35.671520225257645 139.74390715270016 19.33 35.671520225257645 139.74390715270016 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67145788520209 139.74391780469324 6.74 35.67145737711962 139.743913342511 6.74 35.67145737711962 139.743913342511 19.33 35.67145788520209 139.74391780469324 19.33 35.67145788520209 139.74391780469324 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67145737711962 139.743913342511 6.74 35.67122797073039 139.74395251475562 6.74 35.67122797073039 139.74395251475562 19.33 35.67145737711962 139.743913342511 19.33 35.67145737711962 139.743913342511 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67122797073039 139.74395251475562 6.74 35.67122837901273 139.74395610437287 6.74 35.67122837901273 139.74395610437287 19.33 35.67122797073039 139.74395251475562 19.33 35.67122797073039 139.74395251475562 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67122837901273 139.74395610437287 19.33 35.67121160658269 139.74395896198857 19.33 35.67122006252022 139.74403328362322 19.33 35.67123683495204 139.74403042602273 19.33 35.67123614541953 139.7440243733758 19.33 35.67144360618133 139.7439889484283 19.33 35.671441038518005 139.74396633929666 19.33 35.671444805778286 139.7439656944059 19.33 35.671447518603884 139.74398957371358 19.33 35.67153664407822 139.743974351847 19.33 35.671533786095246 139.74394921338336 19.33 35.671536838147084 139.74394436060268 19.33 35.671520225257645 139.74390715270016 19.33 35.67145788520209 139.74391780469324 19.33 35.67145737711962 139.743913342511 19.33 35.67122797073039 139.74395251475562 19.33 35.67122837901273 139.74395610437287 19.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d510ca6b-4bf5-464a-b5a3-f71ea7243710"/>
							<gml:surfaceMember xlink:href="#poly-18dbcc31-ca1e-4379-a58b-31e902190d64"/>
							<gml:surfaceMember xlink:href="#poly-3e6dfc30-012a-47da-9091-346109ee1d77"/>
							<gml:surfaceMember xlink:href="#poly-a1b4592f-96f9-487d-87a5-df402444101e"/>
							<gml:surfaceMember xlink:href="#poly-0f76e542-6797-4f55-8150-321b93271130"/>
							<gml:surfaceMember xlink:href="#poly-4d6c4674-01df-4d9d-b474-86246cc2d89c"/>
							<gml:surfaceMember xlink:href="#poly-9dfd5283-34cd-4dfa-8127-a71f0ce88b94"/>
							<gml:surfaceMember xlink:href="#poly-edfd7577-a738-4176-93ab-e985b8038ae2"/>
							<gml:surfaceMember xlink:href="#poly-3138354d-9602-48ad-af2d-6545e41ef46e"/>
							<gml:surfaceMember xlink:href="#poly-e209e9e8-e10f-49c1-8db7-4aba74b7e787"/>
							<gml:surfaceMember xlink:href="#poly-67ecb64e-1665-46f9-848f-cb19e1413a6c"/>
							<gml:surfaceMember xlink:href="#poly-30701d7a-bed4-48c4-b92e-9ccd9a1d9ed0"/>
							<gml:surfaceMember xlink:href="#poly-5a91959f-0707-4709-9e4f-ad3f096b1b3e"/>
							<gml:surfaceMember xlink:href="#poly-62c53d3b-cc9b-4595-95e5-5ba04c889309"/>
							<gml:surfaceMember xlink:href="#poly-89f8708c-2f2a-4b51-979b-6dd234263b38"/>
							<gml:surfaceMember xlink:href="#poly-743bb61d-6ab9-464b-9de5-d2fbdc3db624"/>
							<gml:surfaceMember xlink:href="#poly-e68e9d9e-0860-4573-ac69-a289d2a28bc5"/>
							<gml:surfaceMember xlink:href="#poly-c6962db2-c9e6-409e-b7e6-d785c682419c"/>
							<gml:surfaceMember xlink:href="#poly-67fad7ab-02c1-4913-a3e3-ca7d3af60daa"/>
							<gml:surfaceMember xlink:href="#poly-a21995e0-7c35-4e3f-b9bc-2a3d48b5e509"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d510ca6b-4bf5-464a-b5a3-f71ea7243710">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d510ca6b-4bf5-464a-b5a3-f71ea7243710">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d510ca6b-4bf5-464a-b5a3-f71ea7243710">
											<gml:posList>35.67123614541951 139.74402437337577 6.74 35.67123683495204 139.74403042602273 6.74 35.67122006252023 139.7440332836232 6.74 35.671211606582666 139.74395896198857 6.74 35.67122837901271 139.74395610437287 6.74 35.67122797073038 139.74395251475562 6.74 35.67145737711962 139.74391334251098 6.74 35.671457885202095 139.74391780469324 6.74 35.67152022525765 139.74390715270016 6.74 35.67153683814706 139.74394436060268 6.74 35.671533786095246 139.74394921338336 6.74 35.67153664407819 139.743974351847 6.74 35.67144751860386 139.74398957371358 6.74 35.67144480577829 139.74396569440586 6.74 35.671441038518005 139.74396633929666 6.74 35.67144360618133 139.74398894842827 6.74 35.67123614541951 139.74402437337577 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18dbcc31-ca1e-4379-a58b-31e902190d64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18dbcc31-ca1e-4379-a58b-31e902190d64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18dbcc31-ca1e-4379-a58b-31e902190d64">
											<gml:posList>35.67144751860386 139.74398957371358 13.989 35.67153664407819 139.743974351847 13.989 35.671533786095246 139.74394921338336 13.989 35.67153683814706 139.74394436060268 13.989 35.67152022525765 139.74390715270016 13.989 35.671457885202095 139.74391780469324 13.989 35.671462975154355 139.74396259220498 13.989 35.67144480577829 139.74396569440586 13.989 35.67144751860386 139.74398957371358 13.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e6dfc30-012a-47da-9091-346109ee1d77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e6dfc30-012a-47da-9091-346109ee1d77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e6dfc30-012a-47da-9091-346109ee1d77">
											<gml:posList>35.67145737711962 139.74391334251098 20.147 35.67122797073038 139.74395251475562 20.147 35.67123614541951 139.74402437337577 20.147 35.67144360618133 139.74398894842827 20.147 35.671441038518005 139.74396633929666 20.147 35.671462975154355 139.74396259220498 20.147 35.67145737711962 139.74391334251098 20.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a1b4592f-96f9-487d-87a5-df402444101e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1b4592f-96f9-487d-87a5-df402444101e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1b4592f-96f9-487d-87a5-df402444101e">
											<gml:posList>35.67122006252023 139.7440332836232 13.4 35.67123683495204 139.74403042602273 13.4 35.67123614541951 139.74402437337577 13.4 35.67122837901271 139.74395610437287 13.4 35.671211606582666 139.74395896198857 13.4 35.67122006252023 139.7440332836232 13.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f76e542-6797-4f55-8150-321b93271130">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f76e542-6797-4f55-8150-321b93271130">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f76e542-6797-4f55-8150-321b93271130">
											<gml:posList>35.67145737711962 139.74391334251098 6.74 35.67122797073038 139.74395251475562 6.74 35.67122797073038 139.74395251475562 20.147 35.67145737711962 139.74391334251098 20.147 35.67145737711962 139.74391334251098 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d6c4674-01df-4d9d-b474-86246cc2d89c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d6c4674-01df-4d9d-b474-86246cc2d89c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d6c4674-01df-4d9d-b474-86246cc2d89c">
											<gml:posList>35.67152022525765 139.74390715270016 6.74 35.671457885202095 139.74391780469324 6.74 35.671457885202095 139.74391780469324 13.989 35.67152022525765 139.74390715270016 13.989 35.67152022525765 139.74390715270016 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9dfd5283-34cd-4dfa-8127-a71f0ce88b94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dfd5283-34cd-4dfa-8127-a71f0ce88b94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dfd5283-34cd-4dfa-8127-a71f0ce88b94">
											<gml:posList>35.67153683814706 139.74394436060268 6.74 35.67152022525765 139.74390715270016 6.74 35.67152022525765 139.74390715270016 13.989 35.67153683814706 139.74394436060268 13.989 35.67153683814706 139.74394436060268 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edfd7577-a738-4176-93ab-e985b8038ae2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edfd7577-a738-4176-93ab-e985b8038ae2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edfd7577-a738-4176-93ab-e985b8038ae2">
											<gml:posList>35.671457885202095 139.74391780469324 13.989 35.671457885202095 139.74391780469324 6.74 35.67145737711962 139.74391334251098 6.74 35.67145737711962 139.74391334251098 20.147 35.671462975154355 139.74396259220498 20.147 35.671462975154355 139.74396259220498 13.989 35.671457885202095 139.74391780469324 13.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3138354d-9602-48ad-af2d-6545e41ef46e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3138354d-9602-48ad-af2d-6545e41ef46e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3138354d-9602-48ad-af2d-6545e41ef46e">
											<gml:posList>35.671533786095246 139.74394921338336 6.74 35.67153683814706 139.74394436060268 6.74 35.67153683814706 139.74394436060268 13.989 35.671533786095246 139.74394921338336 13.989 35.671533786095246 139.74394921338336 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e209e9e8-e10f-49c1-8db7-4aba74b7e787">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e209e9e8-e10f-49c1-8db7-4aba74b7e787">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e209e9e8-e10f-49c1-8db7-4aba74b7e787">
											<gml:posList>35.67122837901271 139.74395610437287 6.74 35.671211606582666 139.74395896198857 6.74 35.671211606582666 139.74395896198857 13.4 35.67122837901271 139.74395610437287 13.4 35.67122837901271 139.74395610437287 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67ecb64e-1665-46f9-848f-cb19e1413a6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67ecb64e-1665-46f9-848f-cb19e1413a6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67ecb64e-1665-46f9-848f-cb19e1413a6c">
											<gml:posList>35.67153664407819 139.743974351847 6.74 35.671533786095246 139.74394921338336 6.74 35.671533786095246 139.74394921338336 13.989 35.67153664407819 139.743974351847 13.989 35.67153664407819 139.743974351847 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30701d7a-bed4-48c4-b92e-9ccd9a1d9ed0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30701d7a-bed4-48c4-b92e-9ccd9a1d9ed0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30701d7a-bed4-48c4-b92e-9ccd9a1d9ed0">
											<gml:posList>35.671441038518005 139.74396633929666 20.147 35.671441038518005 139.74396633929666 6.74 35.67144480577829 139.74396569440586 6.74 35.67144480577829 139.74396569440586 13.989 35.671462975154355 139.74396259220498 13.989 35.671462975154355 139.74396259220498 20.147 35.671441038518005 139.74396633929666 20.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a91959f-0707-4709-9e4f-ad3f096b1b3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a91959f-0707-4709-9e4f-ad3f096b1b3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a91959f-0707-4709-9e4f-ad3f096b1b3e">
											<gml:posList>35.67144480577829 139.74396569440586 6.74 35.67144751860386 139.74398957371358 6.74 35.67144751860386 139.74398957371358 13.989 35.67144480577829 139.74396569440586 13.989 35.67144480577829 139.74396569440586 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62c53d3b-cc9b-4595-95e5-5ba04c889309">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62c53d3b-cc9b-4595-95e5-5ba04c889309">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62c53d3b-cc9b-4595-95e5-5ba04c889309">
											<gml:posList>35.67144360618133 139.74398894842827 6.74 35.671441038518005 139.74396633929666 6.74 35.671441038518005 139.74396633929666 20.147 35.67144360618133 139.74398894842827 20.147 35.67144360618133 139.74398894842827 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-89f8708c-2f2a-4b51-979b-6dd234263b38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89f8708c-2f2a-4b51-979b-6dd234263b38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89f8708c-2f2a-4b51-979b-6dd234263b38">
											<gml:posList>35.67144751860386 139.74398957371358 6.74 35.67153664407819 139.743974351847 6.74 35.67153664407819 139.743974351847 13.989 35.67144751860386 139.74398957371358 13.989 35.67144751860386 139.74398957371358 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-743bb61d-6ab9-464b-9de5-d2fbdc3db624">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-743bb61d-6ab9-464b-9de5-d2fbdc3db624">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-743bb61d-6ab9-464b-9de5-d2fbdc3db624">
											<gml:posList>35.67122797073038 139.74395251475562 20.147 35.67122797073038 139.74395251475562 6.74 35.67122837901271 139.74395610437287 6.74 35.67122837901271 139.74395610437287 13.4 35.67123614541951 139.74402437337577 13.4 35.67123614541951 139.74402437337577 20.147 35.67122797073038 139.74395251475562 20.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e68e9d9e-0860-4573-ac69-a289d2a28bc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e68e9d9e-0860-4573-ac69-a289d2a28bc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e68e9d9e-0860-4573-ac69-a289d2a28bc5">
											<gml:posList>35.671211606582666 139.74395896198857 6.74 35.67122006252023 139.7440332836232 6.74 35.67122006252023 139.7440332836232 13.4 35.671211606582666 139.74395896198857 13.4 35.671211606582666 139.74395896198857 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6962db2-c9e6-409e-b7e6-d785c682419c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6962db2-c9e6-409e-b7e6-d785c682419c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6962db2-c9e6-409e-b7e6-d785c682419c">
											<gml:posList>35.67144360618133 139.74398894842827 6.74 35.67144360618133 139.74398894842827 20.147 35.67123614541951 139.74402437337577 20.147 35.67123614541951 139.74402437337577 13.4 35.67123614541951 139.74402437337577 6.74 35.67144360618133 139.74398894842827 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67fad7ab-02c1-4913-a3e3-ca7d3af60daa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67fad7ab-02c1-4913-a3e3-ca7d3af60daa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67fad7ab-02c1-4913-a3e3-ca7d3af60daa">
											<gml:posList>35.67123683495204 139.74403042602273 6.74 35.67123614541951 139.74402437337577 6.74 35.67123614541951 139.74402437337577 13.4 35.67123683495204 139.74403042602273 13.4 35.67123683495204 139.74403042602273 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a21995e0-7c35-4e3f-b9bc-2a3d48b5e509">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a21995e0-7c35-4e3f-b9bc-2a3d48b5e509">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a21995e0-7c35-4e3f-b9bc-2a3d48b5e509">
											<gml:posList>35.67122006252023 139.7440332836232 6.74 35.67123683495204 139.74403042602273 6.74 35.67123683495204 139.74403042602273 13.4 35.67122006252023 139.7440332836232 13.4 35.67122006252023 139.7440332836232 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-451</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">224</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.54</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>