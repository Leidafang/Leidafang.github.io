<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_cccbf7e0-b87e-401e-b5c6-e47471626229">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">11.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67207610215447 139.73791822873142 0 35.672118271216675 139.7378990681023 0 35.672086550017156 139.73779438509632 0 35.67204465112016 139.73781321405627 0 35.67207610215447 139.73791822873142 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67207610215447 139.73791822873142 9.51 35.67204465112016 139.73781321405627 9.51 35.672086550017156 139.73779438509632 9.51 35.672118271216675 139.7378990681023 9.51 35.67207610215447 139.73791822873142 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67207610215447 139.73791822873142 9.51 35.672118271216675 139.7378990681023 9.51 35.672118271216675 139.7378990681023 20.99 35.67207610215447 139.73791822873142 20.99 35.67207610215447 139.73791822873142 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672118271216675 139.7378990681023 9.51 35.672086550017156 139.73779438509632 9.51 35.672086550017156 139.73779438509632 20.99 35.672118271216675 139.7378990681023 20.99 35.672118271216675 139.7378990681023 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672086550017156 139.73779438509632 9.51 35.67204465112016 139.73781321405627 9.51 35.67204465112016 139.73781321405627 20.99 35.672086550017156 139.73779438509632 20.99 35.672086550017156 139.73779438509632 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67204465112016 139.73781321405627 9.51 35.67207610215447 139.73791822873142 9.51 35.67207610215447 139.73791822873142 20.99 35.67204465112016 139.73781321405627 20.99 35.67204465112016 139.73781321405627 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67207610215447 139.73791822873142 20.99 35.672118271216675 139.7378990681023 20.99 35.672086550017156 139.73779438509632 20.99 35.67204465112016 139.73781321405627 20.99 35.67207610215447 139.73791822873142 20.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2d438930-5eee-4fa2-9c02-991b4965372b"/>
							<gml:surfaceMember xlink:href="#poly-09dd1727-8dcb-4e15-8f85-2083384d0896"/>
							<gml:surfaceMember xlink:href="#poly-14bf81e2-dc68-4d7a-85e0-a2acb29bd33f"/>
							<gml:surfaceMember xlink:href="#poly-651039b2-ac66-4908-9419-f8b5edc10b01"/>
							<gml:surfaceMember xlink:href="#poly-1766dbdf-6ad9-4375-8b8a-32289e3b7cf5"/>
							<gml:surfaceMember xlink:href="#poly-7019e28a-6811-4e48-8249-720d9d06f32f"/>
							<gml:surfaceMember xlink:href="#poly-1ab37ca9-6ccb-472f-8f02-6f7595383020"/>
							<gml:surfaceMember xlink:href="#poly-2dffb8ac-f8f0-4435-b615-c9035fbde851"/>
							<gml:surfaceMember xlink:href="#poly-94fa2dd3-b214-418a-8d16-5e172f1b6a87"/>
							<gml:surfaceMember xlink:href="#poly-7dfacdf6-9cf2-4202-a333-ef50d6022560"/>
							<gml:surfaceMember xlink:href="#poly-3db7d41f-a700-4263-91c7-3cf0f82c7905"/>
							<gml:surfaceMember xlink:href="#poly-9e0a0aab-a743-47eb-9d67-f654c4f6678f"/>
							<gml:surfaceMember xlink:href="#poly-9b6d90b3-fd0a-4a25-ad15-4bbbd6968c7c"/>
							<gml:surfaceMember xlink:href="#poly-286750c7-779f-43dd-b7a3-2f6bb92ccacf"/>
							<gml:surfaceMember xlink:href="#poly-0770e384-7f6b-4e08-96aa-0e4b1adcced2"/>
							<gml:surfaceMember xlink:href="#poly-070c31f8-cecc-4173-bfd8-03b6a0c1016e"/>
							<gml:surfaceMember xlink:href="#poly-b92b8b4b-3309-43ee-afcf-61fb44be198b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2d438930-5eee-4fa2-9c02-991b4965372b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d438930-5eee-4fa2-9c02-991b4965372b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d438930-5eee-4fa2-9c02-991b4965372b">
											<gml:posList>35.67207610215445 139.7379182287314 9.51 35.67204465112016 139.73781321405627 9.51 35.67208655001715 139.73779438509632 9.51 35.67211827121663 139.7378990681023 9.51 35.67207610215445 139.7379182287314 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09dd1727-8dcb-4e15-8f85-2083384d0896">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09dd1727-8dcb-4e15-8f85-2083384d0896">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09dd1727-8dcb-4e15-8f85-2083384d0896">
											<gml:posList>35.67207158354914 139.73780110815213 21.001 35.67204465112016 139.73781321405627 21.001 35.67204694163017 139.73781450376646 21.001 35.672070585226045 139.7378038820112 21.001 35.67207158354914 139.73780110815213 21.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-14bf81e2-dc68-4d7a-85e0-a2acb29bd33f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14bf81e2-dc68-4d7a-85e0-a2acb29bd33f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14bf81e2-dc68-4d7a-85e0-a2acb29bd33f">
											<gml:posList>35.67204465112016 139.73781321405627 21.001 35.67207610215445 139.7379182287314 21.001 35.672077154536225 139.73791542166973 21.001 35.67204694163017 139.73781450376646 21.001 35.67204465112016 139.73781321405627 21.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-651039b2-ac66-4908-9419-f8b5edc10b01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-651039b2-ac66-4908-9419-f8b5edc10b01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-651039b2-ac66-4908-9419-f8b5edc10b01">
											<gml:posList>35.672070585226045 139.7378038820112 20.904 35.67204694163017 139.73781450376646 20.904 35.672077154536225 139.73791542166973 20.904 35.67210288847463 139.73790372594192 20.904 35.672070585226045 139.7378038820112 20.904</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1766dbdf-6ad9-4375-8b8a-32289e3b7cf5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1766dbdf-6ad9-4375-8b8a-32289e3b7cf5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1766dbdf-6ad9-4375-8b8a-32289e3b7cf5">
											<gml:posList>35.67210520601607 139.73790500457696 21.001 35.67207158354914 139.73780110815213 21.001 35.672070585226045 139.7378038820112 21.001 35.67210288847463 139.73790372594192 21.001 35.67210520601607 139.73790500457696 21.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7019e28a-6811-4e48-8249-720d9d06f32f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7019e28a-6811-4e48-8249-720d9d06f32f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7019e28a-6811-4e48-8249-720d9d06f32f">
											<gml:posList>35.67208655001715 139.73779438509632 19.571 35.67207158354914 139.73780110815213 20.891 35.67210520601607 139.73790500457696 20.891 35.67208655001715 139.73779438509632 19.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ab37ca9-6ccb-472f-8f02-6f7595383020">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ab37ca9-6ccb-472f-8f02-6f7595383020">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ab37ca9-6ccb-472f-8f02-6f7595383020">
											<gml:posList>35.67207610215445 139.7379182287314 21.001 35.67210520601607 139.73790500457696 21.001 35.67210288847463 139.73790372594192 21.001 35.672077154536225 139.73791542166973 21.001 35.67207610215445 139.7379182287314 21.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2dffb8ac-f8f0-4435-b615-c9035fbde851">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dffb8ac-f8f0-4435-b615-c9035fbde851">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dffb8ac-f8f0-4435-b615-c9035fbde851">
											<gml:posList>35.67210520601607 139.73790500457696 20.891 35.67211827121663 139.7378990681023 19.571 35.67208655001715 139.73779438509632 19.571 35.67210520601607 139.73790500457696 20.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94fa2dd3-b214-418a-8d16-5e172f1b6a87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94fa2dd3-b214-418a-8d16-5e172f1b6a87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94fa2dd3-b214-418a-8d16-5e172f1b6a87">
											<gml:posList>35.67204694163017 139.73781450376646 21.001 35.672077154536225 139.73791542166973 21.001 35.672077154536225 139.73791542166973 20.904 35.67204694163017 139.73781450376646 20.904 35.67204694163017 139.73781450376646 21.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7dfacdf6-9cf2-4202-a333-ef50d6022560">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dfacdf6-9cf2-4202-a333-ef50d6022560">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dfacdf6-9cf2-4202-a333-ef50d6022560">
											<gml:posList>35.67210288847463 139.73790372594192 21.001 35.672070585226045 139.7378038820112 21.001 35.672070585226045 139.7378038820112 20.904 35.67210288847463 139.73790372594192 20.904 35.67210288847463 139.73790372594192 21.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3db7d41f-a700-4263-91c7-3cf0f82c7905">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3db7d41f-a700-4263-91c7-3cf0f82c7905">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3db7d41f-a700-4263-91c7-3cf0f82c7905">
											<gml:posList>35.67204465112016 139.73781321405627 9.51 35.67204465112016 139.73781321405627 21.001 35.67207158354914 139.73780110815213 21.001 35.67207158354914 139.73780110815213 20.891 35.67208655001715 139.73779438509632 19.571 35.67208655001715 139.73779438509632 9.51 35.67204465112016 139.73781321405627 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e0a0aab-a743-47eb-9d67-f654c4f6678f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e0a0aab-a743-47eb-9d67-f654c4f6678f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e0a0aab-a743-47eb-9d67-f654c4f6678f">
											<gml:posList>35.672070585226045 139.7378038820112 21.001 35.67204694163017 139.73781450376646 21.001 35.67204694163017 139.73781450376646 20.904 35.672070585226045 139.7378038820112 20.904 35.672070585226045 139.7378038820112 21.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b6d90b3-fd0a-4a25-ad15-4bbbd6968c7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b6d90b3-fd0a-4a25-ad15-4bbbd6968c7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b6d90b3-fd0a-4a25-ad15-4bbbd6968c7c">
											<gml:posList>35.67211827121663 139.7378990681023 19.571 35.67211827121663 139.7378990681023 9.51 35.67208655001715 139.73779438509632 9.51 35.67208655001715 139.73779438509632 19.571 35.67211827121663 139.7378990681023 19.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-286750c7-779f-43dd-b7a3-2f6bb92ccacf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-286750c7-779f-43dd-b7a3-2f6bb92ccacf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-286750c7-779f-43dd-b7a3-2f6bb92ccacf">
											<gml:posList>35.67210520601607 139.73790500457696 20.891 35.67207158354914 139.73780110815213 20.891 35.67207158354914 139.73780110815213 21.001 35.67210520601607 139.73790500457696 21.001 35.67210520601607 139.73790500457696 20.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0770e384-7f6b-4e08-96aa-0e4b1adcced2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0770e384-7f6b-4e08-96aa-0e4b1adcced2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0770e384-7f6b-4e08-96aa-0e4b1adcced2">
											<gml:posList>35.67204465112016 139.73781321405627 21.001 35.67204465112016 139.73781321405627 9.51 35.67207610215445 139.7379182287314 9.51 35.67207610215445 139.7379182287314 21.001 35.67204465112016 139.73781321405627 21.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-070c31f8-cecc-4173-bfd8-03b6a0c1016e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-070c31f8-cecc-4173-bfd8-03b6a0c1016e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-070c31f8-cecc-4173-bfd8-03b6a0c1016e">
											<gml:posList>35.67207610215445 139.7379182287314 21.001 35.67207610215445 139.7379182287314 9.51 35.67211827121663 139.7378990681023 9.51 35.67211827121663 139.7378990681023 19.571 35.67210520601607 139.73790500457696 20.891 35.67210520601607 139.73790500457696 21.001 35.67207610215445 139.7379182287314 21.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b92b8b4b-3309-43ee-afcf-61fb44be198b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b92b8b4b-3309-43ee-afcf-61fb44be198b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b92b8b4b-3309-43ee-afcf-61fb44be198b">
											<gml:posList>35.672077154536225 139.73791542166973 21.001 35.67210288847463 139.73790372594192 21.001 35.67210288847463 139.73790372594192 20.904 35.672077154536225 139.73791542166973 20.904 35.672077154536225 139.73791542166973 21.001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10577</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">50.2881</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.09</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>