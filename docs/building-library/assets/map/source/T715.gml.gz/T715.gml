<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_cd4c2a42-a24e-4f21-ab77-a83ff18a78ad">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">24.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67307432355227 139.7386556184065 0 35.6731584242791 139.7386131552137 0 35.67315113313112 139.7385914571786 0 35.67317503705035 139.73857938808726 0 35.67316256907937 139.7385425070371 0 35.673173471416845 139.73853708129073 0 35.673142030414915 139.73844410576123 0 35.673023276952 139.73850433994997 0 35.67307432355227 139.7386556184065 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67307432355227 139.7386556184065 7.99 35.673023276952 139.73850433994997 7.99 35.673142030414915 139.73844410576123 7.99 35.673173471416845 139.73853708129073 7.99 35.67316256907937 139.7385425070371 7.99 35.67317503705035 139.73857938808726 7.99 35.67315113313112 139.7385914571786 7.99 35.6731584242791 139.7386131552137 7.99 35.67307432355227 139.7386556184065 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67307432355227 139.7386556184065 7.99 35.6731584242791 139.7386131552137 7.99 35.6731584242791 139.7386131552137 32.62 35.67307432355227 139.7386556184065 32.62 35.67307432355227 139.7386556184065 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6731584242791 139.7386131552137 7.99 35.67315113313112 139.7385914571786 7.99 35.67315113313112 139.7385914571786 32.62 35.6731584242791 139.7386131552137 32.62 35.6731584242791 139.7386131552137 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67315113313112 139.7385914571786 7.99 35.67317503705035 139.73857938808726 7.99 35.67317503705035 139.73857938808726 32.62 35.67315113313112 139.7385914571786 32.62 35.67315113313112 139.7385914571786 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67317503705035 139.73857938808726 7.99 35.67316256907937 139.7385425070371 7.99 35.67316256907937 139.7385425070371 32.62 35.67317503705035 139.73857938808726 32.62 35.67317503705035 139.73857938808726 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67316256907937 139.7385425070371 7.99 35.673173471416845 139.73853708129073 7.99 35.673173471416845 139.73853708129073 32.62 35.67316256907937 139.7385425070371 32.62 35.67316256907937 139.7385425070371 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673173471416845 139.73853708129073 7.99 35.673142030414915 139.73844410576123 7.99 35.673142030414915 139.73844410576123 32.62 35.673173471416845 139.73853708129073 32.62 35.673173471416845 139.73853708129073 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673142030414915 139.73844410576123 7.99 35.673023276952 139.73850433994997 7.99 35.673023276952 139.73850433994997 32.62 35.673142030414915 139.73844410576123 32.62 35.673142030414915 139.73844410576123 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673023276952 139.73850433994997 7.99 35.67307432355227 139.7386556184065 7.99 35.67307432355227 139.7386556184065 32.62 35.673023276952 139.73850433994997 32.62 35.673023276952 139.73850433994997 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67307432355227 139.7386556184065 32.62 35.6731584242791 139.7386131552137 32.62 35.67315113313112 139.7385914571786 32.62 35.67317503705035 139.73857938808726 32.62 35.67316256907937 139.7385425070371 32.62 35.673173471416845 139.73853708129073 32.62 35.673142030414915 139.73844410576123 32.62 35.673023276952 139.73850433994997 32.62 35.67307432355227 139.7386556184065 32.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-25a70d32-c2e7-4ad9-a381-f8d984bb2840"/>
							<gml:surfaceMember xlink:href="#poly-81f1ed9b-6ebe-40bf-ba57-6ec2b5b27756"/>
							<gml:surfaceMember xlink:href="#poly-fa39be73-37db-4c0f-8579-012650ba1a03"/>
							<gml:surfaceMember xlink:href="#poly-65f6ed19-284a-4089-b1c0-8df2db709b14"/>
							<gml:surfaceMember xlink:href="#poly-ce7e3f4a-4c5c-4fc6-b65a-c15d74e26dcb"/>
							<gml:surfaceMember xlink:href="#poly-02ad987e-9cb9-42e5-8ade-6ccb52a7365f"/>
							<gml:surfaceMember xlink:href="#poly-eee450b8-a3f6-4165-aeb1-59c71af62d0e"/>
							<gml:surfaceMember xlink:href="#poly-839119b5-b082-49ee-8a84-c6e1e954f939"/>
							<gml:surfaceMember xlink:href="#poly-798710c0-8fec-433a-83eb-45ebfe65e56b"/>
							<gml:surfaceMember xlink:href="#poly-67527719-167b-4059-8cf8-c0a5a77cfd9a"/>
							<gml:surfaceMember xlink:href="#poly-8fe51e90-967d-4164-9669-6707405fb3ea"/>
							<gml:surfaceMember xlink:href="#poly-b6618b6e-c527-415e-909e-7f78996477d2"/>
							<gml:surfaceMember xlink:href="#poly-04b6105f-881e-4354-9d3e-a09234be34b5"/>
							<gml:surfaceMember xlink:href="#poly-ce22ff60-f6cc-4080-974e-5658a6edafa1"/>
							<gml:surfaceMember xlink:href="#poly-21107e5b-f48d-42b9-b588-c7be3cde504e"/>
							<gml:surfaceMember xlink:href="#poly-e31d50c1-cd12-4f8d-a50f-78347c4c8f10"/>
							<gml:surfaceMember xlink:href="#poly-6c5fd59a-f9ac-414a-802c-cb0856d8a109"/>
							<gml:surfaceMember xlink:href="#poly-1931be45-d543-4838-b6c3-2c7534f49c8b"/>
							<gml:surfaceMember xlink:href="#poly-853ce5a4-75f9-48ba-9477-2fd47b183131"/>
							<gml:surfaceMember xlink:href="#poly-29cefae9-55ee-4ce3-8c47-e7de537c821f"/>
							<gml:surfaceMember xlink:href="#poly-effce59a-7478-4e7d-a33c-fcb5e866aeb8"/>
							<gml:surfaceMember xlink:href="#poly-90b13c89-83cc-43a1-9fc7-3d3949a4481c"/>
							<gml:surfaceMember xlink:href="#poly-ef26fa84-7297-47e0-8e77-acca3d37760a"/>
							<gml:surfaceMember xlink:href="#poly-bc40fd40-6f20-4f51-8a82-a74e3f8f893d"/>
							<gml:surfaceMember xlink:href="#poly-151d9dc8-fbdb-4930-96ff-612668c34adf"/>
							<gml:surfaceMember xlink:href="#poly-19167b84-d92a-45f5-bb85-15c2a506f90e"/>
							<gml:surfaceMember xlink:href="#poly-b56fec0f-c52e-4f00-b324-9f6db7097cf7"/>
							<gml:surfaceMember xlink:href="#poly-b64febcd-f1f0-45a0-a320-2e143eba6401"/>
							<gml:surfaceMember xlink:href="#poly-d6c15339-539b-4dd5-bde6-beb240f72f8d"/>
							<gml:surfaceMember xlink:href="#poly-2cd078f0-9a70-465e-9d7f-017fc96e4b42"/>
							<gml:surfaceMember xlink:href="#poly-86a6290b-b5d1-4a6c-ada0-37cf42cc1dab"/>
							<gml:surfaceMember xlink:href="#poly-629f17e3-cf99-47dd-a499-0c3b1da8913d"/>
							<gml:surfaceMember xlink:href="#poly-660fc801-8061-4f22-8e0c-deb5382f5311"/>
							<gml:surfaceMember xlink:href="#poly-3ccda121-b29c-4462-8cd0-80919a1ef565"/>
							<gml:surfaceMember xlink:href="#poly-a5730b6f-5ec1-47f0-88bb-ca7c188ed150"/>
							<gml:surfaceMember xlink:href="#poly-50d8c9cf-f0e8-437b-9ebd-f20cf5dbb22c"/>
							<gml:surfaceMember xlink:href="#poly-f29da8e0-4c4b-4c35-81d4-6498c136fd14"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_cd4c2a42-a24e-4f21-ab77-a83ff18a78ad_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58219350-47e1-4a37-8244-7c4e61816ba5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6731172506894 139.7386260290052 32.741 35.673098662860774 139.7386355510688 32.741 35.67309020652265 139.73861077241392 32.741 35.67310879434934 139.73860125034557 32.741 35.6731172506894 139.7386260290052 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66c9c1c8-134d-469e-8642-e247f6693d88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66c9c1c8-134d-469e-8642-e247f6693d88_0">
											<gml:posList>35.67309020652265 139.73861077241392 32.741 35.67309020652265 139.73861077241392 35.437 35.67310879434934 139.73860125034557 35.437 35.67310879434934 139.73860125034557 32.741 35.67309020652265 139.73861077241392 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55c5e19e-3efd-452b-bd34-90fe0be238e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55c5e19e-3efd-452b-bd34-90fe0be238e1_0">
											<gml:posList>35.67310879434934 139.73860125034557 32.741 35.67310879434934 139.73860125034557 35.437 35.6731172506894 139.7386260290052 35.437 35.6731172506894 139.7386260290052 32.741 35.67310879434934 139.73860125034557 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f275f49f-d298-492f-a0fa-f696f731325f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f275f49f-d298-492f-a0fa-f696f731325f_0">
											<gml:posList>35.67309020652265 139.73861077241392 35.437 35.673098662860774 139.7386355510688 35.437 35.6731172506894 139.7386260290052 35.437 35.67310879434934 139.73860125034557 35.437 35.67309020652265 139.73861077241392 35.437</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-606be626-cda4-43af-8da4-96222ffbd913">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-606be626-cda4-43af-8da4-96222ffbd913_0">
											<gml:posList>35.673098662860774 139.7386355510688 32.741 35.673098662860774 139.7386355510688 35.437 35.67309020652265 139.73861077241392 35.437 35.67309020652265 139.73861077241392 32.741 35.673098662860774 139.7386355510688 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-784c4d75-38b1-4f4f-8279-f0dd5bbc93c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-784c4d75-38b1-4f4f-8279-f0dd5bbc93c5_0">
											<gml:posList>35.6731172506894 139.7386260290052 32.741 35.6731172506894 139.7386260290052 35.437 35.673098662860774 139.7386355510688 35.437 35.673098662860774 139.7386355510688 32.741 35.6731172506894 139.7386260290052 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_cd4c2a42-a24e-4f21-ab77-a83ff18a78ad_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29a03b48-1d64-4871-9471-2f2fe3f20347">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67317503705035 139.73857938808726 8 35.673180262398866 139.73857606791776 8 35.673184048508155 139.73857650530854 8 35.673186754362185 139.73857871143952 8 35.673189191543166 139.73858312721742 8 35.67319054751244 139.73858809660575 8 35.67319082183535 139.7385930672725 8 35.67318902274218 139.73859770899 8 35.6731584242791 139.7386131552137 8 35.67315113313111 139.73859145717856 8 35.67317503705035 139.73857938808726 8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-377fc21d-91f4-4f78-8db7-e107b9532095">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-377fc21d-91f4-4f78-8db7-e107b9532095_0">
											<gml:posList>35.67315113313111 139.73859145717856 33.052 35.67315113313111 139.73859145717856 30.606 35.67315510848413 139.73860329448038 30.607 35.67315510848413 139.73860329448038 33.052 35.67315443991334 139.7386013179216 33.052 35.67315113313111 139.73859145717856 33.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18210b93-ad4b-4d08-876f-e139b952daf9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18210b93-ad4b-4d08-876f-e139b952daf9_0">
											<gml:posList>35.67315113313111 139.73859145717856 30.606 35.67315113313111 139.73859145717856 8 35.6731584242791 139.7386131552137 8 35.6731584242791 139.7386131552137 30.607 35.67315510848413 139.73860329448038 30.607 35.67315113313111 139.73859145717856 30.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-057eac9e-0ab0-45b9-93bf-f57c87c38eed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-057eac9e-0ab0-45b9-93bf-f57c87c38eed_0">
											<gml:posList>35.67317503705035 139.73857938808726 31.903 35.67317503705035 139.73857938808726 8 35.67315113313111 139.73859145717856 8 35.67315113313111 139.73859145717856 30.606 35.67315113313111 139.73859145717856 33.052 35.67317503705035 139.73857938808726 31.903</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cd223c8-6abb-44dd-a065-a92c0221feee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cd223c8-6abb-44dd-a065-a92c0221feee_0">
											<gml:posList>35.67317837086602 139.73858923775407 31.903 35.67317503705035 139.73857938808726 31.903 35.67315113313111 139.73859145717856 33.052 35.67315443991334 139.7386013179216 33.052 35.67317837086602 139.73858923775407 31.903</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41b7df7a-f550-476f-9e20-dd3669373e8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41b7df7a-f550-476f-9e20-dd3669373e8a_0">
											<gml:posList>35.67315443991334 139.7386013179216 33.052 35.67315510848413 139.73860329448038 33.052 35.67317903943701 139.7385912143134 31.903 35.67317837086602 139.73858923775407 31.903 35.67315443991334 139.7386013179216 33.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a883bf6-f516-4ba5-ba38-459476ca4cdd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a883bf6-f516-4ba5-ba38-459476ca4cdd_0">
											<gml:posList>35.67317903943701 139.7385912143134 31.903 35.67315510848413 139.73860329448038 33.052 35.67315510848413 139.73860329448038 30.607 35.67317903943701 139.7385912143134 31.903</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cf7076c-8a91-4c53-b2ab-b3d839b2abed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4cf7076c-8a91-4c53-b2ab-b3d839b2abed_0">
											<gml:posList>35.67315510848413 139.73860329448038 30.607 35.6731584242791 139.7386131552137 30.607 35.67318236423798 139.73860106399187 31.903 35.67317903943701 139.7385912143134 31.903 35.67315510848413 139.73860329448038 30.607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-570e6941-2249-4221-909c-a7c657e5ff73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-570e6941-2249-4221-909c-a7c657e5ff73_0">
											<gml:posList>35.6731584242791 139.7386131552137 30.607 35.6731584242791 139.7386131552137 8 35.67318902274218 139.73859770899 8 35.67318902274218 139.73859770899 31.903 35.67318236423798 139.73860106399187 31.903 35.6731584242791 139.7386131552137 30.607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0cfa02e-94ce-411e-bbe5-7a01f5ef64c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0cfa02e-94ce-411e-bbe5-7a01f5ef64c6_0">
											<gml:posList>35.673180262398866 139.73857606791776 31.903 35.673180262398866 139.73857606791776 8 35.67317503705035 139.73857938808726 8 35.67317503705035 139.73857938808726 31.903 35.673180262398866 139.73857606791776 31.903</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f7fea00-5b85-454c-9409-341672d3aea5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f7fea00-5b85-454c-9409-341672d3aea5_0">
											<gml:posList>35.673184048508155 139.73857650530854 31.903 35.673184048508155 139.73857650530854 8 35.673180262398866 139.73857606791776 8 35.673180262398866 139.73857606791776 31.903 35.673184048508155 139.73857650530854 31.903</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbd80d09-65ef-4af1-9411-4590fb2f002d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbd80d09-65ef-4af1-9411-4590fb2f002d_0">
											<gml:posList>35.67317503705035 139.73857938808726 31.903 35.67317837086602 139.73858923775407 31.903 35.67317903943701 139.7385912143134 31.903 35.67318236423798 139.73860106399187 31.903 35.67318902274218 139.73859770899 31.903 35.67319082183535 139.7385930672725 31.903 35.67319054751244 139.73858809660575 31.903 35.673189191543166 139.73858312721742 31.903 35.673186754362185 139.73857871143952 31.903 35.673184048508155 139.73857650530854 31.903 35.673180262398866 139.73857606791776 31.903 35.67317503705035 139.73857938808726 31.903</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e040afbc-6e7b-40ce-b3de-3f63a3b78f5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e040afbc-6e7b-40ce-b3de-3f63a3b78f5c_0">
											<gml:posList>35.673186754362185 139.73857871143952 31.903 35.673186754362185 139.73857871143952 8 35.673184048508155 139.73857650530854 8 35.673184048508155 139.73857650530854 31.903 35.673186754362185 139.73857871143952 31.903</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fa320fa-ba9c-4784-8a61-ee4675a365be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fa320fa-ba9c-4784-8a61-ee4675a365be_0">
											<gml:posList>35.673189191543166 139.73858312721742 31.903 35.673189191543166 139.73858312721742 8 35.673186754362185 139.73857871143952 8 35.673186754362185 139.73857871143952 31.903 35.673189191543166 139.73858312721742 31.903</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0eeea271-94b5-4549-8c05-8e99fb35b22e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0eeea271-94b5-4549-8c05-8e99fb35b22e_0">
											<gml:posList>35.67319054751244 139.73858809660575 31.903 35.67319054751244 139.73858809660575 8 35.673189191543166 139.73858312721742 8 35.673189191543166 139.73858312721742 31.903 35.67319054751244 139.73858809660575 31.903</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fc0fabe-f4c4-4e29-b2f0-8ac537311af7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fc0fabe-f4c4-4e29-b2f0-8ac537311af7_0">
											<gml:posList>35.67318902274218 139.73859770899 31.903 35.67318902274218 139.73859770899 8 35.67319082183535 139.7385930672725 8 35.67319082183535 139.7385930672725 31.903 35.67318902274218 139.73859770899 31.903</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6e0b2ac-e918-4646-93ba-6dbca5770e43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6e0b2ac-e918-4646-93ba-6dbca5770e43_0">
											<gml:posList>35.67319082183535 139.7385930672725 31.903 35.67319082183535 139.7385930672725 8 35.67319054751244 139.73858809660575 8 35.67319054751244 139.73858809660575 31.903 35.67319082183535 139.7385930672725 31.903</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_cd4c2a42-a24e-4f21-ab77-a83ff18a78ad_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afbec5b9-b700-4fa9-9cf6-0daeda7773b5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67307535314316 139.73854362644957 32.741 35.67306782970602 139.73854746852547 32.741 35.67306394482384 139.73853606195087 32.741 35.67307146826062 139.73853221987406 32.741 35.67307535314316 139.73854362644957 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80473e5f-9c96-45b1-87a9-2e153660be6e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673095206924586 139.7385506838671 32.741 35.673088133999244 139.73855430447801 32.741 35.67308437559675 139.7385432622895 32.741 35.67309144852175 139.73853964167776 32.741 35.673095206924586 139.7385506838671 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b435da2d-1347-40cc-9715-deba8d38ca08">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67307658186113 139.73854724829167 32.741 35.67308034026327 139.7385582904793 32.741 35.67307282583938 139.73856213254342 32.741 35.6730690674376 139.73855109035665 32.741 35.67307658186113 139.73854724829167 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fc4d96e-dc7e-4360-be66-c9ec309f87a7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67313224092176 139.73855780935088 32.741 35.67314084518796 139.73855292761095 32.741 35.67314385303387 139.738560899729 32.741 35.67313524875866 139.73856577042167 32.741 35.67313224092176 139.73855780935088 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f2c00a4-c213-4a62-8a9f-ab27f4cfad3b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67308159607411 139.73856197856963 32.741 35.67308512861032 139.73857235822769 32.741 35.673077614186 139.73857620029074 32.741 35.67307408165012 139.73856582063345 32.741 35.67308159607411 139.73856197856963 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e5fd126-b5e8-4a08-a6a7-3d3314bd659e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67313289618855 139.7385772396134 32.741 35.673114191124675 139.7385866845023 32.741 35.67311200468497 139.7385801806179 32.741 35.67313070974834 139.73857073572776 32.741 35.67313289618855 139.7385772396134 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65ea186b-ae34-40ce-be59-5b3a1f1cd01f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67314019583174 139.73858681946874 38.054 35.67314741480131 139.73860842921266 38.054 35.673133971626136 139.73861517249952 38.054 35.67312676167149 139.73859356274795 38.054 35.67314019583174 139.73858681946874 38.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c68badba-f42b-44a8-986d-854492c93c24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c68badba-f42b-44a8-986d-854492c93c24_0">
											<gml:posList>35.67307658186113 139.73854724829167 32.741 35.6730690674376 139.73855109035665 32.741 35.6730690674376 139.73855109035665 34.614 35.67307658186113 139.73854724829167 34.614 35.67307658186113 139.73854724829167 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-580e3599-01e5-4e34-bd88-41058146f577">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-580e3599-01e5-4e34-bd88-41058146f577_0">
											<gml:posList>35.67306394482384 139.73853606195087 32.741 35.67306782970602 139.73854746852547 32.741 35.67306782970602 139.73854746852547 34.614 35.67306394482384 139.73853606195087 34.614 35.67306394482384 139.73853606195087 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb0cb24e-f5b4-4b1b-a51b-7ecddc80b290">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb0cb24e-f5b4-4b1b-a51b-7ecddc80b290_0">
											<gml:posList>35.67306394482384 139.73853606195087 32.741 35.67306394482384 139.73853606195087 34.614 35.67307146826062 139.73853221987406 34.614 35.67307146826062 139.73853221987406 32.741 35.67306394482384 139.73853606195087 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62c5487b-2da4-4004-aae0-227e94b8b8e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62c5487b-2da4-4004-aae0-227e94b8b8e4_0">
											<gml:posList>35.67306394482384 139.73853606195087 34.614 35.67306782970602 139.73854746852547 34.614 35.67307535314316 139.73854362644957 34.614 35.67307146826062 139.73853221987406 34.614 35.67306394482384 139.73853606195087 34.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86f0c1b6-25f6-4c52-9428-afda27e50c6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86f0c1b6-25f6-4c52-9428-afda27e50c6e_0">
											<gml:posList>35.67307146826062 139.73853221987406 32.741 35.67307146826062 139.73853221987406 34.614 35.67307535314316 139.73854362644957 34.614 35.67307535314316 139.73854362644957 32.741 35.67307146826062 139.73853221987406 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54382852-368b-4b7e-b0c9-e2575179a18e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54382852-368b-4b7e-b0c9-e2575179a18e_0">
											<gml:posList>35.67308437559675 139.7385432622895 32.741 35.67308437559675 139.7385432622895 34.586 35.67309144852175 139.73853964167776 34.586 35.67309144852175 139.73853964167776 32.741 35.67308437559675 139.7385432622895 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7992420d-7f21-4f5d-9952-0040408d6437">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7992420d-7f21-4f5d-9952-0040408d6437_0">
											<gml:posList>35.6730690674376 139.73855109035665 32.741 35.67307282583938 139.73856213254342 32.741 35.67307282583938 139.73856213254342 34.614 35.6730690674376 139.73855109035665 34.614 35.6730690674376 139.73855109035665 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cea2ac0b-3287-47a3-9207-ef4df8a8daba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cea2ac0b-3287-47a3-9207-ef4df8a8daba_0">
											<gml:posList>35.67306782970602 139.73854746852547 32.741 35.67307535314316 139.73854362644957 32.741 35.67307535314316 139.73854362644957 34.614 35.67306782970602 139.73854746852547 34.614 35.67306782970602 139.73854746852547 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e75ca500-986b-4ea8-afe1-1d4b329837d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e75ca500-986b-4ea8-afe1-1d4b329837d1_0">
											<gml:posList>35.67307658186113 139.73854724829167 34.614 35.6730690674376 139.73855109035665 34.614 35.67307282583938 139.73856213254342 34.614 35.67308034026327 139.7385582904793 34.614 35.67307658186113 139.73854724829167 34.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb13a11c-3615-4266-b4d4-112efb6ffaa9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb13a11c-3615-4266-b4d4-112efb6ffaa9_0">
											<gml:posList>35.67307408165012 139.73856582063345 32.741 35.673077614186 139.73857620029074 32.741 35.673077614186 139.73857620029074 34.614 35.67307408165012 139.73856582063345 34.614 35.67307408165012 139.73856582063345 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44f4f829-984b-41af-8937-021e1d45aec7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44f4f829-984b-41af-8937-021e1d45aec7_0">
											<gml:posList>35.67308034026327 139.7385582904793 32.741 35.67308034026327 139.7385582904793 34.614 35.67307282583938 139.73856213254342 34.614 35.67307282583938 139.73856213254342 32.741 35.67308034026327 139.7385582904793 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cf8c929-d042-4fab-a36a-ee83cf16efe8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4cf8c929-d042-4fab-a36a-ee83cf16efe8_0">
											<gml:posList>35.67308159607411 139.73856197856963 32.741 35.67307408165012 139.73856582063345 32.741 35.67307408165012 139.73856582063345 34.614 35.67308159607411 139.73856197856963 34.614 35.67308159607411 139.73856197856963 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-205e71bc-c279-47fc-b41e-03bd3a7d7d06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-205e71bc-c279-47fc-b41e-03bd3a7d7d06_0">
											<gml:posList>35.67308034026327 139.7385582904793 32.741 35.67307658186113 139.73854724829167 32.741 35.67307658186113 139.73854724829167 34.614 35.67308034026327 139.7385582904793 34.614 35.67308034026327 139.7385582904793 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fe19634-efb5-436b-b999-908ec1bb7a36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fe19634-efb5-436b-b999-908ec1bb7a36_0">
											<gml:posList>35.673077614186 139.73857620029074 34.614 35.67308512861032 139.73857235822769 34.614 35.67308159607411 139.73856197856963 34.614 35.67307408165012 139.73856582063345 34.614 35.673077614186 139.73857620029074 34.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a136fbc3-e8c2-4d83-a168-b0b15090690a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a136fbc3-e8c2-4d83-a168-b0b15090690a_0">
											<gml:posList>35.67308512861032 139.73857235822769 32.741 35.67308512861032 139.73857235822769 34.614 35.673077614186 139.73857620029074 34.614 35.673077614186 139.73857620029074 32.741 35.67308512861032 139.73857235822769 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5573d6de-27a8-4538-833d-4f1c1110f223">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5573d6de-27a8-4538-833d-4f1c1110f223_0">
											<gml:posList>35.67308512861032 139.73857235822769 32.741 35.67308159607411 139.73856197856963 32.741 35.67308159607411 139.73856197856963 34.614 35.67308512861032 139.73857235822769 34.614 35.67308512861032 139.73857235822769 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-015422a1-aa8b-45f3-baef-0d5f6fd9e1cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-015422a1-aa8b-45f3-baef-0d5f6fd9e1cc_0">
											<gml:posList>35.673088133999244 139.73855430447801 32.741 35.673088133999244 139.73855430447801 34.586 35.67308437559675 139.7385432622895 34.586 35.67308437559675 139.7385432622895 32.741 35.673088133999244 139.73855430447801 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-936d9c90-4a0b-45e2-9bf0-eaa6484d8b63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-936d9c90-4a0b-45e2-9bf0-eaa6484d8b63_0">
											<gml:posList>35.673095206924586 139.7385506838671 34.586 35.67309144852175 139.73853964167776 34.586 35.67308437559675 139.7385432622895 34.586 35.673088133999244 139.73855430447801 34.586 35.673095206924586 139.7385506838671 34.586</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b5466cd-d70b-4e13-a974-0533b627c2c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b5466cd-d70b-4e13-a974-0533b627c2c7_0">
											<gml:posList>35.673088133999244 139.73855430447801 32.741 35.673095206924586 139.7385506838671 32.741 35.673095206924586 139.7385506838671 34.586 35.673088133999244 139.73855430447801 34.586 35.673088133999244 139.73855430447801 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8739ca67-e8c8-43ee-b00e-f361a93454b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8739ca67-e8c8-43ee-b00e-f361a93454b7_0">
											<gml:posList>35.67309144852175 139.73853964167776 32.741 35.67309144852175 139.73853964167776 34.586 35.673095206924586 139.7385506838671 34.586 35.673095206924586 139.7385506838671 32.741 35.67309144852175 139.73853964167776 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba371530-342a-4316-b91e-03c880300d8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba371530-342a-4316-b91e-03c880300d8d_0">
											<gml:posList>35.67311200468497 139.7385801806179 32.741 35.673114191124675 139.7385866845023 32.741 35.673114191124675 139.7385866845023 33.378 35.67311200468497 139.7385801806179 33.378 35.67311200468497 139.7385801806179 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa5e2809-9a70-4a4e-81c6-0fba5445b765">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa5e2809-9a70-4a4e-81c6-0fba5445b765_0">
											<gml:posList>35.67313070974834 139.73857073572776 32.741 35.67311200468497 139.7385801806179 32.741 35.67311200468497 139.7385801806179 33.378 35.67313070974834 139.73857073572776 33.378 35.67313070974834 139.73857073572776 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d585b1f6-623b-4dbd-9b31-7e5f00b2fd48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d585b1f6-623b-4dbd-9b31-7e5f00b2fd48_0">
											<gml:posList>35.67313289618855 139.7385772396134 33.378 35.67313070974834 139.73857073572776 33.378 35.67311200468497 139.7385801806179 33.378 35.673114191124675 139.7385866845023 33.378 35.67313289618855 139.7385772396134 33.378</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca27d9ae-42e9-4acd-b52f-7e90353e418a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca27d9ae-42e9-4acd-b52f-7e90353e418a_0">
											<gml:posList>35.673114191124675 139.7385866845023 32.741 35.67313289618855 139.7385772396134 32.741 35.67313289618855 139.7385772396134 33.378 35.673114191124675 139.7385866845023 33.378 35.673114191124675 139.7385866845023 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6753535-f540-4034-8375-06d2e43eada8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6753535-f540-4034-8375-06d2e43eada8_0">
											<gml:posList>35.673133971626136 139.73861517249952 38.054 35.673133971626136 139.73861517249952 38.567 35.67312676167149 139.73859356274795 38.567 35.67312676167149 139.73859356274795 38.054 35.673133971626136 139.73861517249952 38.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c15dd74d-5892-4250-a297-3b26d4477ece">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c15dd74d-5892-4250-a297-3b26d4477ece_0">
											<gml:posList>35.67313289618855 139.7385772396134 32.741 35.67313070974834 139.73857073572776 32.741 35.67313070974834 139.73857073572776 33.378 35.67313289618855 139.7385772396134 33.378 35.67313289618855 139.7385772396134 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7a5b199-fc28-429d-b11f-3403e30d7735">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7a5b199-fc28-429d-b11f-3403e30d7735_0">
											<gml:posList>35.67314019583174 139.73858681946874 38.054 35.67312676167149 139.73859356274795 38.054 35.67312676167149 139.73859356274795 38.567 35.67314019583174 139.73858681946874 38.567 35.67314019583174 139.73858681946874 38.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d250ba9a-23a7-4c78-8f8f-3bcf5749a25e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d250ba9a-23a7-4c78-8f8f-3bcf5749a25e_0">
											<gml:posList>35.67313524875866 139.73856577042167 32.741 35.67313524875866 139.73856577042167 34.614 35.67313224092176 139.73855780935088 34.614 35.67313224092176 139.73855780935088 32.741 35.67313524875866 139.73856577042167 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce634c58-807e-4e14-a087-45849ff86cd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce634c58-807e-4e14-a087-45849ff86cd8_0">
											<gml:posList>35.67314084518796 139.73855292761095 32.741 35.67313224092176 139.73855780935088 32.741 35.67313224092176 139.73855780935088 34.614 35.67314084518796 139.73855292761095 34.614 35.67314084518796 139.73855292761095 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56402b0a-ab14-4066-b5fd-f3da1db54168">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56402b0a-ab14-4066-b5fd-f3da1db54168_0">
											<gml:posList>35.673133971626136 139.73861517249952 38.567 35.67314741480131 139.73860842921266 38.567 35.67314019583174 139.73858681946874 38.567 35.67312676167149 139.73859356274795 38.567 35.673133971626136 139.73861517249952 38.567</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99b48c6b-bad3-4584-845c-c778f263908d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99b48c6b-bad3-4584-845c-c778f263908d_0">
											<gml:posList>35.67313224092176 139.73855780935088 34.614 35.67313524875866 139.73856577042167 34.614 35.67314385303387 139.738560899729 34.614 35.67314084518796 139.73855292761095 34.614 35.67313224092176 139.73855780935088 34.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e214193a-3214-4617-8ce5-b25ddd9930c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e214193a-3214-4617-8ce5-b25ddd9930c9_0">
											<gml:posList>35.67313524875866 139.73856577042167 32.741 35.67314385303387 139.738560899729 32.741 35.67314385303387 139.738560899729 34.614 35.67313524875866 139.73856577042167 34.614 35.67313524875866 139.73856577042167 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36fa167e-bc61-4c36-87bd-649c1bdae73e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36fa167e-bc61-4c36-87bd-649c1bdae73e_0">
											<gml:posList>35.673133971626136 139.73861517249952 38.054 35.67314741480131 139.73860842921266 38.054 35.67314741480131 139.73860842921266 38.567 35.673133971626136 139.73861517249952 38.567 35.673133971626136 139.73861517249952 38.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48f81fc1-4d14-4f1a-9b0b-7ac9b47dfc01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48f81fc1-4d14-4f1a-9b0b-7ac9b47dfc01_0">
											<gml:posList>35.67314385303387 139.738560899729 32.741 35.67314084518796 139.73855292761095 32.741 35.67314084518796 139.73855292761095 34.614 35.67314385303387 139.738560899729 34.614 35.67314385303387 139.738560899729 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b605dd2a-232e-4a87-8d9f-cf6abdc96e31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b605dd2a-232e-4a87-8d9f-cf6abdc96e31_0">
											<gml:posList>35.67314741480131 139.73860842921266 38.054 35.67314019583174 139.73858681946874 38.054 35.67314019583174 139.73858681946874 38.567 35.67314741480131 139.73860842921266 38.567 35.67314741480131 139.73860842921266 38.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-25a70d32-c2e7-4ad9-a381-f8d984bb2840">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25a70d32-c2e7-4ad9-a381-f8d984bb2840">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25a70d32-c2e7-4ad9-a381-f8d984bb2840">
											<gml:posList>35.673074323552264 139.7386556184065 7.99 35.673023276952 139.73850433994997 7.99 35.67314203041488 139.73844410576126 7.99 35.673173471416845 139.73853708129076 7.99 35.67316256907937 139.7385425070371 7.99 35.67317503705035 139.73857938808726 7.99 35.67315113313111 139.73859145717856 7.99 35.6731584242791 139.7386131552137 7.99 35.673074323552264 139.7386556184065 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-81f1ed9b-6ebe-40bf-ba57-6ec2b5b27756">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81f1ed9b-6ebe-40bf-ba57-6ec2b5b27756">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81f1ed9b-6ebe-40bf-ba57-6ec2b5b27756">
											<gml:posList>35.673074323552264 139.7386556184065 33.227 35.67307679662657 139.73864836889607 33.227 35.67303304110401 139.7385186890126 33.227 35.673027107694 139.73851566925492 33.227 35.673074323552264 139.7386556184065 33.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa39be73-37db-4c0f-8579-012650ba1a03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa39be73-37db-4c0f-8579-012650ba1a03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa39be73-37db-4c0f-8579-012650ba1a03">
											<gml:posList>35.673027107694 139.73851566925492 33.227 35.67303304110401 139.7385186890126 33.227 35.673132873338155 139.73846808780522 33.227 35.673135337370006 139.73846081620115 33.227 35.673027107694 139.73851566925492 33.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65f6ed19-284a-4089-b1c0-8df2db709b14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65f6ed19-284a-4089-b1c0-8df2db709b14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65f6ed19-284a-4089-b1c0-8df2db709b14">
											<gml:posList>35.673135337370006 139.73846081620115 33.098 35.67314203041488 139.73844410576126 31.254 35.673023276952 139.73850433994997 31.254 35.673027107694 139.73851566925492 33.098 35.673135337370006 139.73846081620115 33.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce7e3f4a-4c5c-4fc6-b65a-c15d74e26dcb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce7e3f4a-4c5c-4fc6-b65a-c15d74e26dcb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce7e3f4a-4c5c-4fc6-b65a-c15d74e26dcb">
											<gml:posList>35.67307679662657 139.73864836889607 33.227 35.673074323552264 139.7386556184065 33.227 35.67312700589568 139.7386290221664 33.227 35.67312528023531 139.73862388751851 33.227 35.67307679662657 139.73864836889607 33.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-02ad987e-9cb9-42e5-8ade-6ccb52a7365f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02ad987e-9cb9-42e5-8ade-6ccb52a7365f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02ad987e-9cb9-42e5-8ade-6ccb52a7365f">
											<gml:posList>35.67303304110401 139.7385186890126 32.741 35.67307679662657 139.73864836889607 32.741 35.67312528023531 139.73862388751851 32.741 35.673112983773215 139.73858730454077 32.741 35.67314440215119 139.73857143757454 32.741 35.67314940746915 139.73858632252993 32.741 35.673169130683135 139.7385763682878 32.741 35.673132873338155 139.73846808780522 32.741 35.67303304110401 139.7385186890126 32.741</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eee450b8-a3f6-4165-aeb1-59c71af62d0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eee450b8-a3f6-4165-aeb1-59c71af62d0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eee450b8-a3f6-4165-aeb1-59c71af62d0e">
											<gml:posList>35.67312700589568 139.7386290221664 39.661 35.673129397992604 139.73862196053892 39.661 35.67311873683745 139.73859023614702 39.661 35.673112983773215 139.73858730454077 39.661 35.67312700589568 139.7386290221664 39.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-839119b5-b082-49ee-8a84-c6e1e954f939">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-839119b5-b082-49ee-8a84-c6e1e954f939">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-839119b5-b082-49ee-8a84-c6e1e954f939">
											<gml:posList>35.673112983773215 139.73858730454077 39.661 35.67311873683745 139.73859023614702 39.661 35.67314200103481 139.73857848816888 39.661 35.67314440215119 139.73857143757454 39.661 35.673112983773215 139.73858730454077 39.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-798710c0-8fec-433a-83eb-45ebfe65e56b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-798710c0-8fec-433a-83eb-45ebfe65e56b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-798710c0-8fec-433a-83eb-45ebfe65e56b">
											<gml:posList>35.67315266219304 139.7386102125684 38.054 35.67314200103481 139.73857848816888 38.054 35.67311873683745 139.73859023614702 38.054 35.673129397992604 139.73862196053892 38.054 35.67315266219304 139.7386102125684 38.054</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67527719-167b-4059-8cf8-c0a5a77cfd9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67527719-167b-4059-8cf8-c0a5a77cfd9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67527719-167b-4059-8cf8-c0a5a77cfd9a">
											<gml:posList>35.6731584242791 139.7386131552137 39.661 35.67315266219304 139.7386102125684 39.661 35.673129397992604 139.73862196053892 39.661 35.67312700589568 139.7386290221664 39.661 35.6731584242791 139.7386131552137 39.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8fe51e90-967d-4164-9669-6707405fb3ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fe51e90-967d-4164-9669-6707405fb3ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fe51e90-967d-4164-9669-6707405fb3ea">
											<gml:posList>35.67314440215119 139.73857143757454 39.661 35.67314200103481 139.73857848816888 39.661 35.67315266219304 139.7386102125684 39.661 35.6731584242791 139.7386131552137 39.661 35.67314440215119 139.73857143757454 39.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6618b6e-c527-415e-909e-7f78996477d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6618b6e-c527-415e-909e-7f78996477d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6618b6e-c527-415e-909e-7f78996477d2">
											<gml:posList>35.673135337370006 139.73846081620115 33.227 35.673132873338155 139.73846808780522 33.227 35.673169130683135 139.7385763682878 33.227 35.67317503705035 139.73857938808726 33.227 35.673135337370006 139.73846081620115 33.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-04b6105f-881e-4354-9d3e-a09234be34b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04b6105f-881e-4354-9d3e-a09234be34b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04b6105f-881e-4354-9d3e-a09234be34b5">
											<gml:posList>35.673135337370006 139.73846081620115 33.098 35.67316256907937 139.7385425070371 33.098 35.673173471416845 139.73853708129076 31.254 35.67314203041488 139.73844410576126 31.254 35.673135337370006 139.73846081620115 33.098</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce22ff60-f6cc-4080-974e-5658a6edafa1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce22ff60-f6cc-4080-974e-5658a6edafa1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce22ff60-f6cc-4080-974e-5658a6edafa1">
											<gml:posList>35.67317503705035 139.73857938808726 33.227 35.67316256907937 139.7385425070371 33.098 35.673135337370006 139.73846081620115 33.098 35.67317503705035 139.73857938808726 33.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21107e5b-f48d-42b9-b588-c7be3cde504e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21107e5b-f48d-42b9-b588-c7be3cde504e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21107e5b-f48d-42b9-b588-c7be3cde504e">
											<gml:posList>35.673169130683135 139.7385763682878 33.227 35.67314940746915 139.73858632252993 33.227 35.67315113313111 139.73859145717856 33.227 35.67317503705035 139.73857938808726 33.227 35.673169130683135 139.7385763682878 33.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e31d50c1-cd12-4f8d-a50f-78347c4c8f10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e31d50c1-cd12-4f8d-a50f-78347c4c8f10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e31d50c1-cd12-4f8d-a50f-78347c4c8f10">
											<gml:posList>35.673074323552264 139.7386556184065 33.227 35.673027107694 139.73851566925492 33.227 35.673027107694 139.73851566925492 33.098 35.673023276952 139.73850433994997 31.254 35.673023276952 139.73850433994997 7.99 35.673074323552264 139.7386556184065 7.99 35.673074323552264 139.7386556184065 33.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c5fd59a-f9ac-414a-802c-cb0856d8a109">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c5fd59a-f9ac-414a-802c-cb0856d8a109">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c5fd59a-f9ac-414a-802c-cb0856d8a109">
											<gml:posList>35.67307679662657 139.73864836889607 33.227 35.67307679662657 139.73864836889607 32.741 35.67303304110401 139.7385186890126 32.741 35.67303304110401 139.7385186890126 33.227 35.67307679662657 139.73864836889607 33.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1931be45-d543-4838-b6c3-2c7534f49c8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1931be45-d543-4838-b6c3-2c7534f49c8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1931be45-d543-4838-b6c3-2c7534f49c8b">
											<gml:posList>35.673027107694 139.73851566925492 33.227 35.673135337370006 139.73846081620115 33.227 35.673135337370006 139.73846081620115 33.098 35.673027107694 139.73851566925492 33.098 35.673027107694 139.73851566925492 33.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-853ce5a4-75f9-48ba-9477-2fd47b183131">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-853ce5a4-75f9-48ba-9477-2fd47b183131">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-853ce5a4-75f9-48ba-9477-2fd47b183131">
											<gml:posList>35.67314203041488 139.73844410576126 7.99 35.673023276952 139.73850433994997 7.99 35.673023276952 139.73850433994997 31.254 35.67314203041488 139.73844410576126 31.254 35.67314203041488 139.73844410576126 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29cefae9-55ee-4ce3-8c47-e7de537c821f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29cefae9-55ee-4ce3-8c47-e7de537c821f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29cefae9-55ee-4ce3-8c47-e7de537c821f">
											<gml:posList>35.67303304110401 139.7385186890126 33.227 35.67303304110401 139.7385186890126 32.741 35.673132873338155 139.73846808780522 32.741 35.673132873338155 139.73846808780522 33.227 35.67303304110401 139.7385186890126 33.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-effce59a-7478-4e7d-a33c-fcb5e866aeb8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-effce59a-7478-4e7d-a33c-fcb5e866aeb8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-effce59a-7478-4e7d-a33c-fcb5e866aeb8">
											<gml:posList>35.67312528023531 139.73862388751851 33.227 35.67312528023531 139.73862388751851 32.741 35.67307679662657 139.73864836889607 32.741 35.67307679662657 139.73864836889607 33.227 35.67312528023531 139.73862388751851 33.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90b13c89-83cc-43a1-9fc7-3d3949a4481c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90b13c89-83cc-43a1-9fc7-3d3949a4481c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90b13c89-83cc-43a1-9fc7-3d3949a4481c">
											<gml:posList>35.6731584242791 139.7386131552137 7.99 35.6731584242791 139.7386131552137 39.661 35.67312700589568 139.7386290221664 39.661 35.67312700589568 139.7386290221664 33.227 35.673074323552264 139.7386556184065 33.227 35.673074323552264 139.7386556184065 7.99 35.6731584242791 139.7386131552137 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef26fa84-7297-47e0-8e77-acca3d37760a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef26fa84-7297-47e0-8e77-acca3d37760a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef26fa84-7297-47e0-8e77-acca3d37760a">
											<gml:posList>35.67312700589568 139.7386290221664 39.661 35.673112983773215 139.73858730454077 39.661 35.673112983773215 139.73858730454077 32.741 35.67312528023531 139.73862388751851 32.741 35.67312528023531 139.73862388751851 33.227 35.67312700589568 139.7386290221664 33.227 35.67312700589568 139.7386290221664 39.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc40fd40-6f20-4f51-8a82-a74e3f8f893d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc40fd40-6f20-4f51-8a82-a74e3f8f893d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc40fd40-6f20-4f51-8a82-a74e3f8f893d">
											<gml:posList>35.673129397992604 139.73862196053892 39.661 35.673129397992604 139.73862196053892 38.054 35.67311873683745 139.73859023614702 38.054 35.67311873683745 139.73859023614702 39.661 35.673129397992604 139.73862196053892 39.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-151d9dc8-fbdb-4930-96ff-612668c34adf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-151d9dc8-fbdb-4930-96ff-612668c34adf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-151d9dc8-fbdb-4930-96ff-612668c34adf">
											<gml:posList>35.673112983773215 139.73858730454077 39.661 35.67314440215119 139.73857143757454 39.661 35.67314440215119 139.73857143757454 32.741 35.673112983773215 139.73858730454077 32.741 35.673112983773215 139.73858730454077 39.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19167b84-d92a-45f5-bb85-15c2a506f90e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19167b84-d92a-45f5-bb85-15c2a506f90e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19167b84-d92a-45f5-bb85-15c2a506f90e">
											<gml:posList>35.67311873683745 139.73859023614702 39.661 35.67311873683745 139.73859023614702 38.054 35.67314200103481 139.73857848816888 38.054 35.67314200103481 139.73857848816888 39.661 35.67311873683745 139.73859023614702 39.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b56fec0f-c52e-4f00-b324-9f6db7097cf7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b56fec0f-c52e-4f00-b324-9f6db7097cf7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b56fec0f-c52e-4f00-b324-9f6db7097cf7">
											<gml:posList>35.67315266219304 139.7386102125684 39.661 35.67315266219304 139.7386102125684 38.054 35.673129397992604 139.73862196053892 38.054 35.673129397992604 139.73862196053892 39.661 35.67315266219304 139.7386102125684 39.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b64febcd-f1f0-45a0-a320-2e143eba6401">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b64febcd-f1f0-45a0-a320-2e143eba6401">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b64febcd-f1f0-45a0-a320-2e143eba6401">
											<gml:posList>35.67314200103481 139.73857848816888 39.661 35.67314200103481 139.73857848816888 38.054 35.67315266219304 139.7386102125684 38.054 35.67315266219304 139.7386102125684 39.661 35.67314200103481 139.73857848816888 39.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6c15339-539b-4dd5-bde6-beb240f72f8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6c15339-539b-4dd5-bde6-beb240f72f8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6c15339-539b-4dd5-bde6-beb240f72f8d">
											<gml:posList>35.673132873338155 139.73846808780522 33.227 35.673132873338155 139.73846808780522 32.741 35.673169130683135 139.7385763682878 32.741 35.673169130683135 139.7385763682878 33.227 35.673132873338155 139.73846808780522 33.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2cd078f0-9a70-465e-9d7f-017fc96e4b42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cd078f0-9a70-465e-9d7f-017fc96e4b42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cd078f0-9a70-465e-9d7f-017fc96e4b42">
											<gml:posList>35.6731584242791 139.7386131552137 39.661 35.6731584242791 139.7386131552137 7.99 35.67315113313111 139.73859145717856 7.99 35.67315113313111 139.73859145717856 33.227 35.67314940746915 139.73858632252993 33.227 35.67314940746915 139.73858632252993 32.741 35.67314440215119 139.73857143757454 32.741 35.67314440215119 139.73857143757454 39.661 35.6731584242791 139.7386131552137 39.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86a6290b-b5d1-4a6c-ada0-37cf42cc1dab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86a6290b-b5d1-4a6c-ada0-37cf42cc1dab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86a6290b-b5d1-4a6c-ada0-37cf42cc1dab">
											<gml:posList>35.67317503705035 139.73857938808726 33.227 35.673135337370006 139.73846081620115 33.098 35.673135337370006 139.73846081620115 33.227 35.67317503705035 139.73857938808726 33.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-629f17e3-cf99-47dd-a499-0c3b1da8913d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-629f17e3-cf99-47dd-a499-0c3b1da8913d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-629f17e3-cf99-47dd-a499-0c3b1da8913d">
											<gml:posList>35.673173471416845 139.73853708129076 7.99 35.67314203041488 139.73844410576126 7.99 35.67314203041488 139.73844410576126 31.254 35.673173471416845 139.73853708129076 31.254 35.673173471416845 139.73853708129076 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-660fc801-8061-4f22-8e0c-deb5382f5311">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-660fc801-8061-4f22-8e0c-deb5382f5311">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-660fc801-8061-4f22-8e0c-deb5382f5311">
											<gml:posList>35.673169130683135 139.7385763682878 33.227 35.673169130683135 139.7385763682878 32.741 35.67314940746915 139.73858632252993 32.741 35.67314940746915 139.73858632252993 33.227 35.673169130683135 139.7385763682878 33.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ccda121-b29c-4462-8cd0-80919a1ef565">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ccda121-b29c-4462-8cd0-80919a1ef565">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ccda121-b29c-4462-8cd0-80919a1ef565">
											<gml:posList>35.67315113313111 139.73859145717856 7.99 35.67317503705035 139.73857938808726 7.99 35.67317503705035 139.73857938808726 33.227 35.67315113313111 139.73859145717856 33.227 35.67315113313111 139.73859145717856 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5730b6f-5ec1-47f0-88bb-ca7c188ed150">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5730b6f-5ec1-47f0-88bb-ca7c188ed150">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5730b6f-5ec1-47f0-88bb-ca7c188ed150">
											<gml:posList>35.67316256907937 139.7385425070371 7.99 35.673173471416845 139.73853708129076 7.99 35.673173471416845 139.73853708129076 31.254 35.67316256907937 139.7385425070371 33.098 35.67316256907937 139.7385425070371 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50d8c9cf-f0e8-437b-9ebd-f20cf5dbb22c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50d8c9cf-f0e8-437b-9ebd-f20cf5dbb22c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50d8c9cf-f0e8-437b-9ebd-f20cf5dbb22c">
											<gml:posList>35.67317503705035 139.73857938808726 33.227 35.67317503705035 139.73857938808726 7.99 35.67316256907937 139.7385425070371 7.99 35.67317503705035 139.73857938808726 33.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f29da8e0-4c4b-4c35-81d4-6498c136fd14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f29da8e0-4c4b-4c35-81d4-6498c136fd14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f29da8e0-4c4b-4c35-81d4-6498c136fd14">
											<gml:posList>35.67317503705035 139.73857938808726 33.227 35.67316256907937 139.7385425070371 7.99 35.67316256907937 139.7385425070371 33.098 35.67317503705035 139.73857938808726 33.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2730</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">206.5877</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>