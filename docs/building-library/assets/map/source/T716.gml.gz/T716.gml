<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_cdb6e825-e501-4488-8cd1-b54873ab9c3f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">33.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671256248637704 139.7387741721515 0 35.671253500060054 139.73877494863976 0 35.671274662360034 139.7388873316694 0 35.67130500486057 139.738878757069 0 35.67131194732897 139.73891565487116 0 35.67142326922742 139.73888416303464 0 35.67139524594361 139.73873540105112 0 35.67139186654468 139.73873635502875 0 35.67139070798921 139.73873024773735 0 35.671255198656574 139.73876858392168 0 35.671256248637704 139.7387741721515 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671256248637704 139.7387741721515 16.363 35.671255198656574 139.73876858392168 16.363 35.67139070798921 139.73873024773735 16.363 35.67139186654468 139.73873635502875 16.363 35.67139524594361 139.73873540105112 16.363 35.67142326922742 139.73888416303464 16.363 35.67131194732897 139.73891565487116 16.363 35.67130500486057 139.738878757069 16.363 35.671274662360034 139.7388873316694 16.363 35.671253500060054 139.73877494863976 16.363 35.671256248637704 139.7387741721515 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671256248637704 139.7387741721515 16.363 35.671253500060054 139.73877494863976 16.363 35.671253500060054 139.73877494863976 49.5 35.671256248637704 139.7387741721515 49.5 35.671256248637704 139.7387741721515 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671253500060054 139.73877494863976 16.363 35.671274662360034 139.7388873316694 16.363 35.671274662360034 139.7388873316694 49.5 35.671253500060054 139.73877494863976 49.5 35.671253500060054 139.73877494863976 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671274662360034 139.7388873316694 16.363 35.67130500486057 139.738878757069 16.363 35.67130500486057 139.738878757069 49.5 35.671274662360034 139.7388873316694 49.5 35.671274662360034 139.7388873316694 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67130500486057 139.738878757069 16.363 35.67131194732897 139.73891565487116 16.363 35.67131194732897 139.73891565487116 49.5 35.67130500486057 139.738878757069 49.5 35.67130500486057 139.738878757069 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67131194732897 139.73891565487116 16.363 35.67142326922742 139.73888416303464 16.363 35.67142326922742 139.73888416303464 49.5 35.67131194732897 139.73891565487116 49.5 35.67131194732897 139.73891565487116 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67142326922742 139.73888416303464 16.363 35.67139524594361 139.73873540105112 16.363 35.67139524594361 139.73873540105112 49.5 35.67142326922742 139.73888416303464 49.5 35.67142326922742 139.73888416303464 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67139524594361 139.73873540105112 16.363 35.67139186654468 139.73873635502875 16.363 35.67139186654468 139.73873635502875 49.5 35.67139524594361 139.73873540105112 49.5 35.67139524594361 139.73873540105112 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67139186654468 139.73873635502875 16.363 35.67139070798921 139.73873024773735 16.363 35.67139070798921 139.73873024773735 49.5 35.67139186654468 139.73873635502875 49.5 35.67139186654468 139.73873635502875 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67139070798921 139.73873024773735 16.363 35.671255198656574 139.73876858392168 16.363 35.671255198656574 139.73876858392168 49.5 35.67139070798921 139.73873024773735 49.5 35.67139070798921 139.73873024773735 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671255198656574 139.73876858392168 16.363 35.671256248637704 139.7387741721515 16.363 35.671256248637704 139.7387741721515 49.5 35.671255198656574 139.73876858392168 49.5 35.671255198656574 139.73876858392168 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671256248637704 139.7387741721515 49.5 35.671253500060054 139.73877494863976 49.5 35.671274662360034 139.7388873316694 49.5 35.67130500486057 139.738878757069 49.5 35.67131194732897 139.73891565487116 49.5 35.67142326922742 139.73888416303464 49.5 35.67139524594361 139.73873540105112 49.5 35.67139186654468 139.73873635502875 49.5 35.67139070798921 139.73873024773735 49.5 35.671255198656574 139.73876858392168 49.5 35.671256248637704 139.7387741721515 49.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-996967be-53a1-4dcf-af80-818cc9aa7308"/>
							<gml:surfaceMember xlink:href="#poly-5f250269-3a4b-4614-a11e-2d0fe93bf21f"/>
							<gml:surfaceMember xlink:href="#poly-777974a9-ecb3-4f89-9a12-480129056765"/>
							<gml:surfaceMember xlink:href="#poly-42df3e21-342d-4140-ba91-cab40d9d439f"/>
							<gml:surfaceMember xlink:href="#poly-da420810-72ce-4aeb-acad-2dba4bdd2938"/>
							<gml:surfaceMember xlink:href="#poly-3e3b65a0-d8ea-479e-8697-84dc737c97f9"/>
							<gml:surfaceMember xlink:href="#poly-e85c5385-57c9-402b-859e-3d3897d37311"/>
							<gml:surfaceMember xlink:href="#poly-a9bbd279-192c-4555-98c1-5bd85c23eb06"/>
							<gml:surfaceMember xlink:href="#poly-90958b02-fd65-48c8-8112-198165d506bc"/>
							<gml:surfaceMember xlink:href="#poly-14a0d489-b4a3-40f1-b868-28c6296be563"/>
							<gml:surfaceMember xlink:href="#poly-4e6ff1d7-d5e0-4f48-8336-5392d7b3aea9"/>
							<gml:surfaceMember xlink:href="#poly-62a8f976-f5ea-4677-ab7f-9b49675c26dc"/>
							<gml:surfaceMember xlink:href="#poly-a8beece6-e49b-48e8-b0c7-160cfcbd37a4"/>
							<gml:surfaceMember xlink:href="#poly-df554029-4f1f-4750-b055-94e3861ec63d"/>
							<gml:surfaceMember xlink:href="#poly-f3f71009-6dce-47e1-8328-a8f4c1b4960a"/>
							<gml:surfaceMember xlink:href="#poly-91ee8ee8-e82d-40a3-b3af-54b0e0ec1bc4"/>
							<gml:surfaceMember xlink:href="#poly-3a79b586-f0ff-4ee6-bc75-412e4649a970"/>
							<gml:surfaceMember xlink:href="#poly-02640a47-6ba7-4d3e-b59b-430ce54ccb54"/>
							<gml:surfaceMember xlink:href="#poly-33cb5fad-4d7b-4a78-9a33-be44fce2a525"/>
							<gml:surfaceMember xlink:href="#poly-79211ec3-74bd-4a46-80e0-a550f8013a04"/>
							<gml:surfaceMember xlink:href="#poly-67bc06c2-1cbd-42dc-bdeb-2230839e1c69"/>
							<gml:surfaceMember xlink:href="#poly-1b3b9be2-838b-481c-a671-f2b71f0e503f"/>
							<gml:surfaceMember xlink:href="#poly-e5059e8b-453b-44ec-998f-78bafe1bcd3e"/>
							<gml:surfaceMember xlink:href="#poly-78a67fef-93e6-4fa1-b810-e767c9b5e6fe"/>
							<gml:surfaceMember xlink:href="#poly-4d64db0d-b2e3-4ff6-8fa3-5d4ac8804670"/>
							<gml:surfaceMember xlink:href="#poly-0829325f-217e-456d-b397-e89851202d24"/>
							<gml:surfaceMember xlink:href="#poly-c20dc86f-f1cc-4609-91ac-8c980df37681"/>
							<gml:surfaceMember xlink:href="#poly-be0734a7-40ac-40b8-9b1a-e60d363acece"/>
							<gml:surfaceMember xlink:href="#poly-86343afb-0d1e-4642-99d9-d24206aa4f65"/>
							<gml:surfaceMember xlink:href="#poly-050f5083-0fd7-4cec-a6dd-27991029eba7"/>
							<gml:surfaceMember xlink:href="#poly-cafa2bfb-c910-4944-bc77-03de6459a07a"/>
							<gml:surfaceMember xlink:href="#poly-e5d8daa0-b4bc-4a0d-9612-162f1e4fa9b9"/>
							<gml:surfaceMember xlink:href="#poly-8f642ad1-1522-47ab-91e3-455f9f3a97f0"/>
							<gml:surfaceMember xlink:href="#poly-9076d671-aea8-4609-88a9-df735caa400f"/>
							<gml:surfaceMember xlink:href="#poly-81da4cee-4bb8-4cc8-866c-81de7900dbaf"/>
							<gml:surfaceMember xlink:href="#poly-a0298c39-c368-4bba-9b17-e098c18d38e8"/>
							<gml:surfaceMember xlink:href="#poly-7ac456d4-30c0-4cee-ac84-f4478bb50fad"/>
							<gml:surfaceMember xlink:href="#poly-60695731-9894-461e-aae1-e1a21646d060"/>
							<gml:surfaceMember xlink:href="#poly-c6bb8564-00a4-45f4-b70c-cacd587b5daa"/>
							<gml:surfaceMember xlink:href="#poly-ee4a8d05-de9a-465c-b7d1-1eef1671a4f9"/>
							<gml:surfaceMember xlink:href="#poly-74066ec8-2ebc-432b-8d42-8c416d63df70"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_cdb6e825-e501-4488-8cd1-b54873ab9c3f_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef5d86f1-158a-40dd-9330-075e15639742">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67127930574376 139.73891199277307 16.363 35.671274662368695 139.73888734271574 16.363 35.67130499584685 139.7388787570796 16.363 35.67130963922365 139.73890340714573 16.363 35.67127930574376 139.73891199277307 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b356ff44-5dc0-4dd0-a8d3-b541e68dbc77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b356ff44-5dc0-4dd0-a8d3-b541e68dbc77_0">
											<gml:posList>35.671274662368695 139.73888734271574 53.453 35.671274662368695 139.73888734271574 16.363 35.67127930574376 139.73891199277307 16.363 35.67127930574376 139.73891199277307 53.453 35.671274662368695 139.73888734271574 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-897e277a-fa3f-4d12-8a30-005ebd10d0c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-897e277a-fa3f-4d12-8a30-005ebd10d0c0_0">
											<gml:posList>35.67130499584685 139.7388787570796 53.453 35.67130499584685 139.7388787570796 16.363 35.671274662368695 139.73888734271574 16.363 35.671274662368695 139.73888734271574 53.453 35.67130499584685 139.7388787570796 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06c9a10b-0737-4e77-b80b-0c7591e9bf84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06c9a10b-0737-4e77-b80b-0c7591e9bf84_0">
											<gml:posList>35.67130963922365 139.73890340714573 53.453 35.67130499584685 139.7388787570796 53.453 35.671274662368695 139.73888734271574 53.453 35.67127930574376 139.73891199277307 53.453 35.67130963922365 139.73890340714573 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de3b2a1b-bd3e-48d1-bb03-37adb3119652">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de3b2a1b-bd3e-48d1-bb03-37adb3119652_0">
											<gml:posList>35.67127930574376 139.73891199277307 53.453 35.67127930574376 139.73891199277307 16.363 35.67130963922365 139.73890340714573 16.363 35.67130963922365 139.73890340714573 53.453 35.67127930574376 139.73891199277307 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0587c2e5-333c-4e90-807e-c20711b45001">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0587c2e5-333c-4e90-807e-c20711b45001_0">
											<gml:posList>35.67130963922365 139.73890340714573 53.453 35.67130963922365 139.73890340714573 16.363 35.67130499584685 139.7388787570796 16.363 35.67130499584685 139.7388787570796 53.453 35.67130963922365 139.73890340714573 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-996967be-53a1-4dcf-af80-818cc9aa7308">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-996967be-53a1-4dcf-af80-818cc9aa7308">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-996967be-53a1-4dcf-af80-818cc9aa7308">
											<gml:posList>35.67130500486057 139.738878757069 16.363 35.67127466236003 139.73888733166936 16.363 35.67125350006003 139.73877494863976 16.363 35.6712562486377 139.7387741721515 16.363 35.67125519865655 139.73876858392165 16.363 35.67139070798922 139.73873024773735 16.363 35.67139186654466 139.73873635502872 16.363 35.671395245943614 139.7387354010511 16.363 35.6714232692274 139.73888416303464 16.363 35.671311947328945 139.73891565487116 16.363 35.67130500486057 139.738878757069 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f250269-3a4b-4614-a11e-2d0fe93bf21f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f250269-3a4b-4614-a11e-2d0fe93bf21f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f250269-3a4b-4614-a11e-2d0fe93bf21f">
											<gml:posList>35.6712562486377 139.7387741721515 38.955 35.67125350006003 139.73877494863976 38.955 35.6712577841538 139.73877822436202 38.955 35.67126053273149 139.73877744787382 38.955 35.6712562486377 139.7387741721515 38.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-777974a9-ecb3-4f89-9a12-480129056765">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-777974a9-ecb3-4f89-9a12-480129056765">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-777974a9-ecb3-4f89-9a12-480129056765">
											<gml:posList>35.6712562486377 139.7387741721515 38.955 35.67126053273149 139.73877744787382 38.955 35.67125948275916 139.73877187069002 38.955 35.67125519865655 139.73876858392165 38.955 35.6712562486377 139.7387741721515 38.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-42df3e21-342d-4140-ba91-cab40d9d439f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42df3e21-342d-4140-ba91-cab40d9d439f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42df3e21-342d-4140-ba91-cab40d9d439f">
											<gml:posList>35.671265076885 139.73883643019013 38.955 35.671268555409746 139.73883544296226 38.955 35.6712577841538 139.73877822436202 38.955 35.67125350006003 139.73877494863976 38.955 35.671265076885 139.73883643019013 38.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-da420810-72ce-4aeb-acad-2dba4bdd2938">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da420810-72ce-4aeb-acad-2dba4bdd2938">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da420810-72ce-4aeb-acad-2dba4bdd2938">
											<gml:posList>35.67127466236003 139.73888733166936 53.453 35.6712777403304 139.73888130776484 53.453 35.67127000134137 139.7388402022486 53.453 35.671265076885 139.73883643019013 53.453 35.67127466236003 139.73888733166936 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e3b65a0-d8ea-479e-8697-84dc737c97f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e3b65a0-d8ea-479e-8697-84dc737c97f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e3b65a0-d8ea-479e-8697-84dc737c97f9">
											<gml:posList>35.67130500486057 139.738878757069 53.453 35.67130808283916 139.7388727442082 53.453 35.6712777403304 139.73888130776484 53.453 35.67127466236003 139.73888733166936 53.453 35.67130500486057 139.738878757069 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e85c5385-57c9-402b-859e-3d3897d37311">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e85c5385-57c9-402b-859e-3d3897d37311">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e85c5385-57c9-402b-859e-3d3897d37311">
											<gml:posList>35.67130500486057 139.738878757069 53.453 35.671311947328945 139.73891565487116 53.453 35.671315025300714 139.73890963096488 53.453 35.67130808283916 139.7388727442082 53.453 35.67130500486057 139.738878757069 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9bbd279-192c-4555-98c1-5bd85c23eb06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9bbd279-192c-4555-98c1-5bd85c23eb06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9bbd279-192c-4555-98c1-5bd85c23eb06">
											<gml:posList>35.67125519865655 139.73876858392165 38.955 35.67125948275916 139.73877187069002 38.955 35.671388044041485 139.7387354868734 38.955 35.67139070798922 139.73873024773735 38.955 35.67125519865655 139.73876858392165 38.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-90958b02-fd65-48c8-8112-198165d506bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90958b02-fd65-48c8-8112-198165d506bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90958b02-fd65-48c8-8112-198165d506bc">
											<gml:posList>35.67138920259667 139.73874159416468 38.324 35.671388044041485 139.7387354868734 38.324 35.67125948275916 139.73877187069002 38.324 35.67126053273149 139.73877744787382 38.324 35.6712577841538 139.73877822436202 38.324 35.671268555409746 139.73883544296226 38.324 35.67140325371083 139.7387973398152 38.324 35.671392572981944 139.73874064019793 38.324 35.67138920259667 139.73874159416468 38.324</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-14a0d489-b4a3-40f1-b868-28c6296be563">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14a0d489-b4a3-40f1-b868-28c6296be563">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14a0d489-b4a3-40f1-b868-28c6296be563">
											<gml:posList>35.671265076885 139.73883643019013 53.453 35.67127000134137 139.7388402022486 53.453 35.6714036542778 139.73880238754782 53.453 35.67140672322144 139.73879635259453 53.453 35.671265076885 139.73883643019013 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e6ff1d7-d5e0-4f48-8336-5392d7b3aea9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e6ff1d7-d5e0-4f48-8336-5392d7b3aea9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e6ff1d7-d5e0-4f48-8336-5392d7b3aea9">
											<gml:posList>35.67130808283916 139.7388727442082 52.945 35.671315025300714 139.73890963096488 52.945 35.671418353794905 139.73888040200208 52.945 35.6714036542778 139.73880238754782 52.945 35.67127000134137 139.7388402022486 52.945 35.6712777403304 139.73888130776484 52.945 35.67130808283916 139.7388727442082 52.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-62a8f976-f5ea-4677-ab7f-9b49675c26dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62a8f976-f5ea-4677-ab7f-9b49675c26dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62a8f976-f5ea-4677-ab7f-9b49675c26dc">
											<gml:posList>35.6714232692274 139.73888416303464 53.453 35.671418353794905 139.73888040200208 53.453 35.671315025300714 139.73890963096488 53.453 35.671311947328945 139.73891565487116 53.453 35.6714232692274 139.73888416303464 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a8beece6-e49b-48e8-b0c7-160cfcbd37a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8beece6-e49b-48e8-b0c7-160cfcbd37a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8beece6-e49b-48e8-b0c7-160cfcbd37a4">
											<gml:posList>35.67139186654466 139.73873635502872 38.955 35.67139070798922 139.73873024773735 38.955 35.671388044041485 139.7387354868734 38.955 35.67138920259667 139.73874159416468 38.955 35.67139186654466 139.73873635502872 38.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df554029-4f1f-4750-b055-94e3861ec63d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df554029-4f1f-4750-b055-94e3861ec63d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df554029-4f1f-4750-b055-94e3861ec63d">
											<gml:posList>35.67139186654466 139.73873635502872 38.955 35.67138920259667 139.73874159416468 38.955 35.671392572981944 139.73874064019793 38.955 35.671395245943614 139.7387354010511 38.955 35.67139186654466 139.73873635502872 38.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f3f71009-6dce-47e1-8328-a8f4c1b4960a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3f71009-6dce-47e1-8328-a8f4c1b4960a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3f71009-6dce-47e1-8328-a8f4c1b4960a">
											<gml:posList>35.67140672322144 139.73879635259453 38.955 35.671395245943614 139.7387354010511 38.955 35.671392572981944 139.73874064019793 38.955 35.67140325371083 139.7387973398152 38.955 35.67140672322144 139.73879635259453 38.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-91ee8ee8-e82d-40a3-b3af-54b0e0ec1bc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91ee8ee8-e82d-40a3-b3af-54b0e0ec1bc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91ee8ee8-e82d-40a3-b3af-54b0e0ec1bc4">
											<gml:posList>35.67140672322144 139.73879635259453 53.453 35.6714036542778 139.73880238754782 53.453 35.671418353794905 139.73888040200208 53.453 35.6714232692274 139.73888416303464 53.453 35.67140672322144 139.73879635259453 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a79b586-f0ff-4ee6-bc75-412e4649a970">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a79b586-f0ff-4ee6-bc75-412e4649a970">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a79b586-f0ff-4ee6-bc75-412e4649a970">
											<gml:posList>35.671388044041485 139.7387354868734 38.955 35.671388044041485 139.7387354868734 38.324 35.67138920259667 139.73874159416468 38.324 35.67138920259667 139.73874159416468 38.955 35.671388044041485 139.7387354868734 38.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02640a47-6ba7-4d3e-b59b-430ce54ccb54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02640a47-6ba7-4d3e-b59b-430ce54ccb54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02640a47-6ba7-4d3e-b59b-430ce54ccb54">
											<gml:posList>35.67139186654466 139.73873635502872 16.363 35.67139070798922 139.73873024773735 16.363 35.67139070798922 139.73873024773735 38.955 35.67139186654466 139.73873635502872 38.955 35.67139186654466 139.73873635502872 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33cb5fad-4d7b-4a78-9a33-be44fce2a525">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33cb5fad-4d7b-4a78-9a33-be44fce2a525">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33cb5fad-4d7b-4a78-9a33-be44fce2a525">
											<gml:posList>35.671395245943614 139.7387354010511 16.363 35.67139186654466 139.73873635502872 16.363 35.67139186654466 139.73873635502872 38.955 35.671395245943614 139.7387354010511 38.955 35.671395245943614 139.7387354010511 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79211ec3-74bd-4a46-80e0-a550f8013a04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79211ec3-74bd-4a46-80e0-a550f8013a04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79211ec3-74bd-4a46-80e0-a550f8013a04">
											<gml:posList>35.6712562486377 139.7387741721515 16.363 35.67125350006003 139.73877494863976 16.363 35.67125350006003 139.73877494863976 38.955 35.6712562486377 139.7387741721515 38.955 35.6712562486377 139.7387741721515 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67bc06c2-1cbd-42dc-bdeb-2230839e1c69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67bc06c2-1cbd-42dc-bdeb-2230839e1c69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67bc06c2-1cbd-42dc-bdeb-2230839e1c69">
											<gml:posList>35.67125519865655 139.73876858392165 16.363 35.6712562486377 139.7387741721515 16.363 35.6712562486377 139.7387741721515 38.955 35.67125519865655 139.73876858392165 38.955 35.67125519865655 139.73876858392165 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b3b9be2-838b-481c-a671-f2b71f0e503f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b3b9be2-838b-481c-a671-f2b71f0e503f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b3b9be2-838b-481c-a671-f2b71f0e503f">
											<gml:posList>35.6712577841538 139.73877822436202 38.955 35.6712577841538 139.73877822436202 38.324 35.67126053273149 139.73877744787382 38.324 35.67126053273149 139.73877744787382 38.955 35.6712577841538 139.73877822436202 38.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5059e8b-453b-44ec-998f-78bafe1bcd3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5059e8b-453b-44ec-998f-78bafe1bcd3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5059e8b-453b-44ec-998f-78bafe1bcd3e">
											<gml:posList>35.67126053273149 139.73877744787382 38.955 35.67126053273149 139.73877744787382 38.324 35.67125948275916 139.73877187069002 38.324 35.67125948275916 139.73877187069002 38.955 35.67126053273149 139.73877744787382 38.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78a67fef-93e6-4fa1-b810-e767c9b5e6fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78a67fef-93e6-4fa1-b810-e767c9b5e6fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78a67fef-93e6-4fa1-b810-e767c9b5e6fe">
											<gml:posList>35.671268555409746 139.73883544296226 38.955 35.671268555409746 139.73883544296226 38.324 35.6712577841538 139.73877822436202 38.324 35.6712577841538 139.73877822436202 38.955 35.671268555409746 139.73883544296226 38.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d64db0d-b2e3-4ff6-8fa3-5d4ac8804670">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d64db0d-b2e3-4ff6-8fa3-5d4ac8804670">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d64db0d-b2e3-4ff6-8fa3-5d4ac8804670">
											<gml:posList>35.67127466236003 139.73888733166936 16.363 35.67127466236003 139.73888733166936 53.453 35.671265076885 139.73883643019013 53.453 35.671265076885 139.73883643019013 38.955 35.67125350006003 139.73877494863976 38.955 35.67125350006003 139.73877494863976 16.363 35.67127466236003 139.73888733166936 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0829325f-217e-456d-b397-e89851202d24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0829325f-217e-456d-b397-e89851202d24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0829325f-217e-456d-b397-e89851202d24">
											<gml:posList>35.6712777403304 139.73888130776484 53.453 35.6712777403304 139.73888130776484 52.945 35.67127000134137 139.7388402022486 52.945 35.67127000134137 139.7388402022486 53.453 35.6712777403304 139.73888130776484 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c20dc86f-f1cc-4609-91ac-8c980df37681">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c20dc86f-f1cc-4609-91ac-8c980df37681">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c20dc86f-f1cc-4609-91ac-8c980df37681">
											<gml:posList>35.67127466236003 139.73888733166936 16.363 35.67130500486057 139.738878757069 16.363 35.67130500486057 139.738878757069 53.453 35.67127466236003 139.73888733166936 53.453 35.67127466236003 139.73888733166936 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be0734a7-40ac-40b8-9b1a-e60d363acece">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be0734a7-40ac-40b8-9b1a-e60d363acece">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be0734a7-40ac-40b8-9b1a-e60d363acece">
											<gml:posList>35.67130808283916 139.7388727442082 53.453 35.67130808283916 139.7388727442082 52.945 35.6712777403304 139.73888130776484 52.945 35.6712777403304 139.73888130776484 53.453 35.67130808283916 139.7388727442082 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86343afb-0d1e-4642-99d9-d24206aa4f65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86343afb-0d1e-4642-99d9-d24206aa4f65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86343afb-0d1e-4642-99d9-d24206aa4f65">
											<gml:posList>35.67130500486057 139.738878757069 16.363 35.671311947328945 139.73891565487116 16.363 35.671311947328945 139.73891565487116 53.453 35.67130500486057 139.738878757069 53.453 35.67130500486057 139.738878757069 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-050f5083-0fd7-4cec-a6dd-27991029eba7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-050f5083-0fd7-4cec-a6dd-27991029eba7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-050f5083-0fd7-4cec-a6dd-27991029eba7">
											<gml:posList>35.671315025300714 139.73890963096488 53.453 35.671315025300714 139.73890963096488 52.945 35.67130808283916 139.7388727442082 52.945 35.67130808283916 139.7388727442082 53.453 35.671315025300714 139.73890963096488 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cafa2bfb-c910-4944-bc77-03de6459a07a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cafa2bfb-c910-4944-bc77-03de6459a07a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cafa2bfb-c910-4944-bc77-03de6459a07a">
											<gml:posList>35.67139070798922 139.73873024773735 16.363 35.67125519865655 139.73876858392165 16.363 35.67125519865655 139.73876858392165 38.955 35.67139070798922 139.73873024773735 38.955 35.67139070798922 139.73873024773735 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5d8daa0-b4bc-4a0d-9612-162f1e4fa9b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5d8daa0-b4bc-4a0d-9612-162f1e4fa9b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5d8daa0-b4bc-4a0d-9612-162f1e4fa9b9">
											<gml:posList>35.67125948275916 139.73877187069002 38.955 35.67125948275916 139.73877187069002 38.324 35.671388044041485 139.7387354868734 38.324 35.671388044041485 139.7387354868734 38.955 35.67125948275916 139.73877187069002 38.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f642ad1-1522-47ab-91e3-455f9f3a97f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f642ad1-1522-47ab-91e3-455f9f3a97f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f642ad1-1522-47ab-91e3-455f9f3a97f0">
											<gml:posList>35.671265076885 139.73883643019013 53.453 35.67140672322144 139.73879635259453 53.453 35.67140672322144 139.73879635259453 38.955 35.67140325371083 139.7387973398152 38.955 35.671268555409746 139.73883544296226 38.955 35.671265076885 139.73883643019013 38.955 35.671265076885 139.73883643019013 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9076d671-aea8-4609-88a9-df735caa400f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9076d671-aea8-4609-88a9-df735caa400f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9076d671-aea8-4609-88a9-df735caa400f">
											<gml:posList>35.67140325371083 139.7387973398152 38.955 35.67140325371083 139.7387973398152 38.324 35.671268555409746 139.73883544296226 38.324 35.671268555409746 139.73883544296226 38.955 35.67140325371083 139.7387973398152 38.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81da4cee-4bb8-4cc8-866c-81de7900dbaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81da4cee-4bb8-4cc8-866c-81de7900dbaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81da4cee-4bb8-4cc8-866c-81de7900dbaf">
											<gml:posList>35.67127000134137 139.7388402022486 53.453 35.67127000134137 139.7388402022486 52.945 35.6714036542778 139.73880238754782 52.945 35.6714036542778 139.73880238754782 53.453 35.67127000134137 139.7388402022486 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0298c39-c368-4bba-9b17-e098c18d38e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0298c39-c368-4bba-9b17-e098c18d38e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0298c39-c368-4bba-9b17-e098c18d38e8">
											<gml:posList>35.671418353794905 139.73888040200208 53.453 35.671418353794905 139.73888040200208 52.945 35.671315025300714 139.73890963096488 52.945 35.671315025300714 139.73890963096488 53.453 35.671418353794905 139.73888040200208 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ac456d4-30c0-4cee-ac84-f4478bb50fad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ac456d4-30c0-4cee-ac84-f4478bb50fad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ac456d4-30c0-4cee-ac84-f4478bb50fad">
											<gml:posList>35.671311947328945 139.73891565487116 16.363 35.6714232692274 139.73888416303464 16.363 35.6714232692274 139.73888416303464 53.453 35.671311947328945 139.73891565487116 53.453 35.671311947328945 139.73891565487116 16.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60695731-9894-461e-aae1-e1a21646d060">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60695731-9894-461e-aae1-e1a21646d060">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60695731-9894-461e-aae1-e1a21646d060">
											<gml:posList>35.67138920259667 139.73874159416468 38.955 35.67138920259667 139.73874159416468 38.324 35.671392572981944 139.73874064019793 38.324 35.671392572981944 139.73874064019793 38.955 35.67138920259667 139.73874159416468 38.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6bb8564-00a4-45f4-b70c-cacd587b5daa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6bb8564-00a4-45f4-b70c-cacd587b5daa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6bb8564-00a4-45f4-b70c-cacd587b5daa">
											<gml:posList>35.671392572981944 139.73874064019793 38.955 35.671392572981944 139.73874064019793 38.324 35.67140325371083 139.7387973398152 38.324 35.67140325371083 139.7387973398152 38.955 35.671392572981944 139.73874064019793 38.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee4a8d05-de9a-465c-b7d1-1eef1671a4f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee4a8d05-de9a-465c-b7d1-1eef1671a4f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee4a8d05-de9a-465c-b7d1-1eef1671a4f9">
											<gml:posList>35.67140672322144 139.73879635259453 38.955 35.67140672322144 139.73879635259453 53.453 35.6714232692274 139.73888416303464 53.453 35.6714232692274 139.73888416303464 16.363 35.671395245943614 139.7387354010511 16.363 35.671395245943614 139.7387354010511 38.955 35.67140672322144 139.73879635259453 38.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74066ec8-2ebc-432b-8d42-8c416d63df70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74066ec8-2ebc-432b-8d42-8c416d63df70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74066ec8-2ebc-432b-8d42-8c416d63df70">
											<gml:posList>35.6714036542778 139.73880238754782 53.453 35.6714036542778 139.73880238754782 52.945 35.671418353794905 139.73888040200208 52.945 35.671418353794905 139.73888040200208 53.453 35.6714036542778 139.73880238754782 53.453</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3864</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">246.2214</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.3</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>