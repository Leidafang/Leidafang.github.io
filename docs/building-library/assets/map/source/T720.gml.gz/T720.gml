<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ce3e79b0-125b-468f-bdf4-51d1c36d1308">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">43.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67401700064403 139.73931592988703 0 35.674025525471656 139.73930162537985 0 35.6740386052501 139.73927964907227 0 35.67400631354959 139.7392507665428 0 35.674011165589945 139.7392426304334 0 35.67398741584558 139.73922138225544 0 35.67399149368867 139.73921450638548 0 35.6739981191317 139.73920342975563 0 35.67387137790653 139.73908917852862 0 35.673862019389645 139.73909779494016 0 35.673696728525826 139.73922819688144 0 35.67393977307367 139.73944559883233 0 35.673946458577376 139.73945372141114 0 35.67397520051956 139.7394269767 0 35.674019176805324 139.73932086523698 0 35.67401588440084 139.73931779809865 0 35.67401700064403 139.73931592988703 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67401700064403 139.73931592988703 7.74 35.67401588440084 139.73931779809865 7.74 35.674019176805324 139.73932086523698 7.74 35.67397520051956 139.7394269767 7.74 35.673946458577376 139.73945372141114 7.74 35.67393977307367 139.73944559883233 7.74 35.673696728525826 139.73922819688144 7.74 35.673862019389645 139.73909779494016 7.74 35.67387137790653 139.73908917852862 7.74 35.6739981191317 139.73920342975563 7.74 35.67399149368867 139.73921450638548 7.74 35.67398741584558 139.73922138225544 7.74 35.674011165589945 139.7392426304334 7.74 35.67400631354959 139.7392507665428 7.74 35.6740386052501 139.73927964907227 7.74 35.674025525471656 139.73930162537985 7.74 35.67401700064403 139.73931592988703 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67401700064403 139.73931592988703 7.74 35.674025525471656 139.73930162537985 7.74 35.674025525471656 139.73930162537985 47.97 35.67401700064403 139.73931592988703 47.97 35.67401700064403 139.73931592988703 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674025525471656 139.73930162537985 7.74 35.6740386052501 139.73927964907227 7.74 35.6740386052501 139.73927964907227 47.97 35.674025525471656 139.73930162537985 47.97 35.674025525471656 139.73930162537985 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6740386052501 139.73927964907227 7.74 35.67400631354959 139.7392507665428 7.74 35.67400631354959 139.7392507665428 47.97 35.6740386052501 139.73927964907227 47.97 35.6740386052501 139.73927964907227 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67400631354959 139.7392507665428 7.74 35.674011165589945 139.7392426304334 7.74 35.674011165589945 139.7392426304334 47.97 35.67400631354959 139.7392507665428 47.97 35.67400631354959 139.7392507665428 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674011165589945 139.7392426304334 7.74 35.67398741584558 139.73922138225544 7.74 35.67398741584558 139.73922138225544 47.97 35.674011165589945 139.7392426304334 47.97 35.674011165589945 139.7392426304334 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67398741584558 139.73922138225544 7.74 35.67399149368867 139.73921450638548 7.74 35.67399149368867 139.73921450638548 47.97 35.67398741584558 139.73922138225544 47.97 35.67398741584558 139.73922138225544 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67399149368867 139.73921450638548 7.74 35.6739981191317 139.73920342975563 7.74 35.6739981191317 139.73920342975563 47.97 35.67399149368867 139.73921450638548 47.97 35.67399149368867 139.73921450638548 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6739981191317 139.73920342975563 7.74 35.67387137790653 139.73908917852862 7.74 35.67387137790653 139.73908917852862 47.97 35.6739981191317 139.73920342975563 47.97 35.6739981191317 139.73920342975563 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67387137790653 139.73908917852862 7.74 35.673862019389645 139.73909779494016 7.74 35.673862019389645 139.73909779494016 47.97 35.67387137790653 139.73908917852862 47.97 35.67387137790653 139.73908917852862 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673862019389645 139.73909779494016 7.74 35.673696728525826 139.73922819688144 7.74 35.673696728525826 139.73922819688144 47.97 35.673862019389645 139.73909779494016 47.97 35.673862019389645 139.73909779494016 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673696728525826 139.73922819688144 7.74 35.67393977307367 139.73944559883233 7.74 35.67393977307367 139.73944559883233 47.97 35.673696728525826 139.73922819688144 47.97 35.673696728525826 139.73922819688144 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67393977307367 139.73944559883233 7.74 35.673946458577376 139.73945372141114 7.74 35.673946458577376 139.73945372141114 47.97 35.67393977307367 139.73944559883233 47.97 35.67393977307367 139.73944559883233 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673946458577376 139.73945372141114 7.74 35.67397520051956 139.7394269767 7.74 35.67397520051956 139.7394269767 47.97 35.673946458577376 139.73945372141114 47.97 35.673946458577376 139.73945372141114 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67397520051956 139.7394269767 7.74 35.674019176805324 139.73932086523698 7.74 35.674019176805324 139.73932086523698 47.97 35.67397520051956 139.7394269767 47.97 35.67397520051956 139.7394269767 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674019176805324 139.73932086523698 7.74 35.67401588440084 139.73931779809865 7.74 35.67401588440084 139.73931779809865 47.97 35.674019176805324 139.73932086523698 47.97 35.674019176805324 139.73932086523698 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67401588440084 139.73931779809865 7.74 35.67401700064403 139.73931592988703 7.74 35.67401700064403 139.73931592988703 47.97 35.67401588440084 139.73931779809865 47.97 35.67401588440084 139.73931779809865 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67401700064403 139.73931592988703 47.97 35.674025525471656 139.73930162537985 47.97 35.6740386052501 139.73927964907227 47.97 35.67400631354959 139.7392507665428 47.97 35.674011165589945 139.7392426304334 47.97 35.67398741584558 139.73922138225544 47.97 35.67399149368867 139.73921450638548 47.97 35.6739981191317 139.73920342975563 47.97 35.67387137790653 139.73908917852862 47.97 35.673862019389645 139.73909779494016 47.97 35.673696728525826 139.73922819688144 47.97 35.67393977307367 139.73944559883233 47.97 35.673946458577376 139.73945372141114 47.97 35.67397520051956 139.7394269767 47.97 35.674019176805324 139.73932086523698 47.97 35.67401588440084 139.73931779809865 47.97 35.67401700064403 139.73931592988703 47.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9bf3b562-2fa0-4d20-b28c-c006cd72c429"/>
							<gml:surfaceMember xlink:href="#poly-46949d20-afb4-4348-be48-113b09a4ef14"/>
							<gml:surfaceMember xlink:href="#poly-a06bac5a-3fd7-4532-8586-902201851cff"/>
							<gml:surfaceMember xlink:href="#poly-9d81d56b-737d-45eb-8291-4b870b18c27d"/>
							<gml:surfaceMember xlink:href="#poly-1a7687d0-7bbe-4b2a-a3c0-20aaf529fed6"/>
							<gml:surfaceMember xlink:href="#poly-8b11e0c5-aae1-4d68-ac15-06acdad19b74"/>
							<gml:surfaceMember xlink:href="#poly-63c324ad-6ce5-4e74-9397-a8a586447d1a"/>
							<gml:surfaceMember xlink:href="#poly-f6e1a1d4-edce-4273-b5b1-967afe86bc7e"/>
							<gml:surfaceMember xlink:href="#poly-e616878c-e9cc-4e33-b1a8-5e9cc421da50"/>
							<gml:surfaceMember xlink:href="#poly-c2655359-f1a6-4acf-9ac2-3aa3308c3487"/>
							<gml:surfaceMember xlink:href="#poly-560b1d16-9ef6-4755-86ac-bbb29fb8f603"/>
							<gml:surfaceMember xlink:href="#poly-525cb55c-19e4-4a59-bcda-460513c4b112"/>
							<gml:surfaceMember xlink:href="#poly-ad8a5313-fdc4-4513-bc80-a7a7315b6890"/>
							<gml:surfaceMember xlink:href="#poly-bd9649ab-f16b-4339-9c42-638a6b3fc2c6"/>
							<gml:surfaceMember xlink:href="#poly-ee86780d-a859-41af-97aa-2cc6865a581b"/>
							<gml:surfaceMember xlink:href="#poly-ecf8957a-9770-415d-8e01-59e8ea168ea3"/>
							<gml:surfaceMember xlink:href="#poly-032a7eec-0109-47b0-8903-b73b6130e8e2"/>
							<gml:surfaceMember xlink:href="#poly-b45cfe9a-fcb3-44ae-8282-9cda4884813a"/>
							<gml:surfaceMember xlink:href="#poly-98026155-60cb-4fcf-8c75-706966abc687"/>
							<gml:surfaceMember xlink:href="#poly-063df0d5-879d-46c8-b122-6196d060a1fc"/>
							<gml:surfaceMember xlink:href="#poly-814080f0-9717-41df-911b-4e18f45eb7d5"/>
							<gml:surfaceMember xlink:href="#poly-9397dbad-a6fc-4696-8ca7-52b91e4f250b"/>
							<gml:surfaceMember xlink:href="#poly-777f4557-f04e-4446-8ad1-4833c27fe808"/>
							<gml:surfaceMember xlink:href="#poly-2030a9ce-7e81-444d-b791-b112a996c2b8"/>
							<gml:surfaceMember xlink:href="#poly-03ac5d4a-7f79-4935-9670-769c1404be6e"/>
							<gml:surfaceMember xlink:href="#poly-584fa83f-c2e8-41a8-9105-5524c0429587"/>
							<gml:surfaceMember xlink:href="#poly-a109f6c2-57b0-43cd-a4b1-731bf3d99b25"/>
							<gml:surfaceMember xlink:href="#poly-cb51bfb7-020c-4b88-9340-4c838dc08a27"/>
							<gml:surfaceMember xlink:href="#poly-b4733328-b4b8-4617-9294-76b9b31763d8"/>
							<gml:surfaceMember xlink:href="#poly-56529bf8-dacc-48f9-b33a-7599c2fec647"/>
							<gml:surfaceMember xlink:href="#poly-5e5cae3f-c50d-4c7c-b32c-c5a6d2e7cae2"/>
							<gml:surfaceMember xlink:href="#poly-47685a77-1190-4ff0-9418-cb6915557e33"/>
							<gml:surfaceMember xlink:href="#poly-595b5985-896b-4788-a560-54b2f089e64b"/>
							<gml:surfaceMember xlink:href="#poly-6a1ac053-0281-4c3f-90e6-5288463a0eda"/>
							<gml:surfaceMember xlink:href="#poly-980ae1c7-a61e-470d-a435-414061252d44"/>
							<gml:surfaceMember xlink:href="#poly-1c99a7d7-b919-4044-b546-149d68949268"/>
							<gml:surfaceMember xlink:href="#poly-595323f8-8df6-4fc2-931f-1935f580620b"/>
							<gml:surfaceMember xlink:href="#poly-aa11eff3-69e0-4575-8868-5e5d50e5c333"/>
							<gml:surfaceMember xlink:href="#poly-eda705ce-55a0-4cec-ad09-e8be755381c3"/>
							<gml:surfaceMember xlink:href="#poly-8efba6ba-4f58-4159-92ee-23502496de3a"/>
							<gml:surfaceMember xlink:href="#poly-a18c8b62-963b-43b0-aae6-6f1404ff7020"/>
							<gml:surfaceMember xlink:href="#poly-5e18e00a-e6e7-4d00-8c32-cfaf96b373c4"/>
							<gml:surfaceMember xlink:href="#poly-a5712488-1694-4c24-98d5-f08f8979e64b"/>
							<gml:surfaceMember xlink:href="#poly-ca02ac3e-de8b-4135-bf6b-c54bdd8fc8e2"/>
							<gml:surfaceMember xlink:href="#poly-73991a76-3851-4f66-a884-594e04e9e030"/>
							<gml:surfaceMember xlink:href="#poly-0f4ba4ad-1a28-4386-9ada-7e65eb0587ac"/>
							<gml:surfaceMember xlink:href="#poly-b1458695-5821-401d-9852-90d144bb81e7"/>
							<gml:surfaceMember xlink:href="#poly-03ac6b0c-e664-4771-bc8a-3a28865ee13e"/>
							<gml:surfaceMember xlink:href="#poly-6f37dd88-1c31-4e2d-b754-7fec4002d5c6"/>
							<gml:surfaceMember xlink:href="#poly-66e88d36-e411-450f-87fe-acdf34dc0771"/>
							<gml:surfaceMember xlink:href="#poly-ec87a179-d287-4846-84fc-71a246ce9890"/>
							<gml:surfaceMember xlink:href="#poly-72ebe3f5-2580-46d0-9c95-c20b4f1b77e0"/>
							<gml:surfaceMember xlink:href="#poly-99e37a1f-de45-4406-a936-fd588e8c36a2"/>
							<gml:surfaceMember xlink:href="#poly-b12f37cc-7cf4-4871-9dd3-6bf2083637fe"/>
							<gml:surfaceMember xlink:href="#poly-1b686459-6e91-412e-a0f9-d4b80a6e2311"/>
							<gml:surfaceMember xlink:href="#poly-d31dba8f-b490-4e43-bc6f-5b1092aaa08b"/>
							<gml:surfaceMember xlink:href="#poly-39366ce9-4ae5-421d-ac36-441c4dd64294"/>
							<gml:surfaceMember xlink:href="#poly-df572532-a0fc-4140-a715-8af4beac678b"/>
							<gml:surfaceMember xlink:href="#poly-84dc9250-3239-45cc-b1ec-d68321fb0b26"/>
							<gml:surfaceMember xlink:href="#poly-904a0d55-a788-48f9-b503-577681dad38d"/>
							<gml:surfaceMember xlink:href="#poly-3430ca90-6734-4add-964a-89b7e6284c15"/>
							<gml:surfaceMember xlink:href="#poly-7f8d772c-2b13-4e62-9898-1873c0f54361"/>
							<gml:surfaceMember xlink:href="#poly-7593bd7e-a62c-4269-97c3-7d9a7a9b3cd9"/>
							<gml:surfaceMember xlink:href="#poly-5b9abf54-4a7e-4bb0-aecf-03bca236b38c"/>
							<gml:surfaceMember xlink:href="#poly-9ecbdcc9-d9ff-467c-bffc-aaa9f0e5864d"/>
							<gml:surfaceMember xlink:href="#poly-87ed1e16-b03c-4e58-a71e-b5f7361114c5"/>
							<gml:surfaceMember xlink:href="#poly-c4ad707f-a866-4daf-9add-7efad988d3c2"/>
							<gml:surfaceMember xlink:href="#poly-3cb608bd-b070-4121-a1e7-1339f47bc558"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9bf3b562-2fa0-4d20-b28c-c006cd72c429">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bf3b562-2fa0-4d20-b28c-c006cd72c429">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bf3b562-2fa0-4d20-b28c-c006cd72c429">
											<gml:posList>35.67400632256331 139.7392507665322 7.74 35.67403860525009 139.73927964907224 7.74 35.67401589341455 139.73931779808808 7.74 35.67401917680533 139.73932086523695 7.74 35.67397520051955 139.7394269767 7.74 35.67394645857738 139.73945372141114 7.74 35.67393977307365 139.73944559883233 7.74 35.67369672852582 139.73922819688144 7.74 35.67386201938961 139.73909779494016 7.74 35.67387137790651 139.7390891785286 7.74 35.67399807402857 139.73920338562155 7.74 35.67399153879179 139.73921455051953 7.74 35.673987506043176 139.73922145947685 7.74 35.674011165589945 139.7392426304334 7.74 35.67400632256331 139.7392507665322 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46949d20-afb4-4348-be48-113b09a4ef14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46949d20-afb4-4348-be48-113b09a4ef14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46949d20-afb4-4348-be48-113b09a4ef14">
											<gml:posList>35.673875505448244 139.7393881205791 48 35.67385881018029 139.73935110042908 48 35.673829340979765 139.73932373907485 48 35.67369672852582 139.73922819688144 48 35.673875505448244 139.7393881205791 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a06bac5a-3fd7-4532-8586-902201851cff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a06bac5a-3fd7-4532-8586-902201851cff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a06bac5a-3fd7-4532-8586-902201851cff">
											<gml:posList>35.67386243422642 139.7392709741816 48 35.67388983065114 139.7392295830312 48 35.67389432466606 139.7391900856479 48 35.67390595719853 139.73917320360758 48 35.67386201938961 139.73909779494016 48 35.67369672852582 139.73922819688144 48 35.673829340979765 139.73932373907485 48 35.67384225035619 139.73930285665148 48 35.67384589453766 139.73930623267862 48 35.67386243422642 139.7392709741816 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d81d56b-737d-45eb-8291-4b870b18c27d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d81d56b-737d-45eb-8291-4b870b18c27d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d81d56b-737d-45eb-8291-4b870b18c27d">
											<gml:posList>35.673829340979765 139.73932373907485 49.891 35.67385881018029 139.73935110042908 49.891 35.67387171955277 139.73933020695569 49.891 35.67384225035619 139.73930285665148 49.891 35.673829340979765 139.73932373907485 49.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a7687d0-7bbe-4b2a-a3c0-20aaf529fed6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a7687d0-7bbe-4b2a-a3c0-20aaf529fed6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a7687d0-7bbe-4b2a-a3c0-20aaf529fed6">
											<gml:posList>35.67384589453766 139.73930623267862 48 35.67387171955277 139.73933020695569 48 35.673875424083754 139.73928389467386 48 35.67386243422642 139.7392709741816 48 35.67384589453766 139.73930623267862 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b11e0c5-aae1-4d68-ac15-06acdad19b74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b11e0c5-aae1-4d68-ac15-06acdad19b74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b11e0c5-aae1-4d68-ac15-06acdad19b74">
											<gml:posList>35.67389414705645 139.73938968946467 50.891 35.67390738868445 139.739367182774 50.891 35.67389249674346 139.73935401041783 50.891 35.67387924610418 139.73937651711702 50.891 35.67389414705645 139.73938968946467 50.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63c324ad-6ce5-4e74-9397-a8a586447d1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63c324ad-6ce5-4e74-9397-a8a586447d1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63c324ad-6ce5-4e74-9397-a8a586447d1a">
											<gml:posList>35.67386243422642 139.7392709741816 50.691 35.67389674908449 139.739305090451 50.691 35.67392414551215 139.73926368824777 50.691 35.67388983065114 139.7392295830312 50.691 35.67386243422642 139.7392709741816 50.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f6e1a1d4-edce-4273-b5b1-967afe86bc7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6e1a1d4-edce-4273-b5b1-967afe86bc7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6e1a1d4-edce-4273-b5b1-967afe86bc7e">
											<gml:posList>35.67388983065114 139.7392295830312 48 35.67392414551215 139.73926368824777 48 35.673915785674765 139.7392122864993 48 35.67389432466606 139.7391900856479 48 35.67388983065114 139.7392295830312 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e616878c-e9cc-4e33-b1a8-5e9cc421da50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e616878c-e9cc-4e33-b1a8-5e9cc421da50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e616878c-e9cc-4e33-b1a8-5e9cc421da50">
											<gml:posList>35.673875505448244 139.7393881205791 48 35.67393977307365 139.73944559883233 48 35.67388713855432 139.73938348940828 48 35.67387924610418 139.73937651711702 48 35.673875505448244 139.7393881205791 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c2655359-f1a6-4acf-9ac2-3aa3308c3487">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2655359-f1a6-4acf-9ac2-3aa3308c3487">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2655359-f1a6-4acf-9ac2-3aa3308c3487">
											<gml:posList>35.67392741820166 139.73919539341094 49.891 35.67390595719853 139.73917320360758 49.891 35.67389432466606 139.7391900856479 49.891 35.67392741820166 139.73919539341094 49.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-560b1d16-9ef6-4755-86ac-bbb29fb8f603">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-560b1d16-9ef6-4755-86ac-bbb29fb8f603">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-560b1d16-9ef6-4755-86ac-bbb29fb8f603">
											<gml:posList>35.67389432466606 139.7391900856479 49.891 35.673915785674765 139.7392122864993 49.691 35.67392741820166 139.73919539341094 49.891 35.67389432466606 139.7391900856479 49.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-525cb55c-19e4-4a59-bcda-460513c4b112">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-525cb55c-19e4-4a59-bcda-460513c4b112">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-525cb55c-19e4-4a59-bcda-460513c4b112">
											<gml:posList>35.67399139446869 139.7392144181279 48 35.67386201938961 139.73909779494016 48 35.67390595719853 139.73917320360758 48 35.67392741820166 139.73919539341094 48 35.67399139446869 139.7392144181279 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad8a5313-fdc4-4513-bc80-a7a7315b6890">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad8a5313-fdc4-4513-bc80-a7a7315b6890">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad8a5313-fdc4-4513-bc80-a7a7315b6890">
											<gml:posList>35.67399148467495 139.73921450639605 22.9 35.67399801089801 139.73920334150864 22.9 35.67387137790651 139.7390891785286 22.9 35.67386201938961 139.73909779494016 22.9 35.67399148467495 139.73921450639605 22.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd9649ab-f16b-4339-9c42-638a6b3fc2c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd9649ab-f16b-4339-9c42-638a6b3fc2c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd9649ab-f16b-4339-9c42-638a6b3fc2c6">
											<gml:posList>35.674025525463016 139.7393016143331 48 35.67403860525009 139.73927964907224 48 35.67398256380663 139.7392295183637 48 35.67399139446869 139.7392144181279 48 35.67392741820166 139.73919539341094 48 35.673915785674765 139.7392122864993 48 35.67392414551215 139.73926368824777 48 35.67389674908449 139.739305090451 48 35.673875424083754 139.73928389467386 48 35.67387171955277 139.73933020695569 48 35.67385881018029 139.73935110042908 48 35.673875505448244 139.7393881205791 48 35.67387924610418 139.73937651711702 48 35.67389249674346 139.73935401041783 48 35.67390738868445 139.739367182774 48 35.67389414705645 139.73938968946467 48 35.67388713855432 139.73938348940828 48 35.67393977307365 139.73944559883233 48 35.673976681018154 139.73938363854637 48 35.673988536558376 139.73936372944408 48 35.67396009112422 139.7393776927421 48 35.67394125726752 139.73936078014765 48 35.67397789452387 139.73929852187663 48 35.67399689058433 139.7393153679934 48 35.674017009657746 139.73931592987648 48 35.6739806499321 139.73928340668317 48 35.673969275601365 139.73927313549945 48 35.67395575244927 139.7392583155783 48 35.67395569987147 139.73924870496577 48 35.67394147420757 139.73923460391464 48 35.67395368236341 139.7392161083693 48 35.673967899015736 139.7392302094299 48 35.67396373959937 139.73923651096166 48 35.67396653934191 139.73924353341062 48 35.67398006249581 139.73925835333125 48 35.67398916574219 139.73926910218958 48 35.674025525463016 139.7393016143331 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee86780d-a859-41af-97aa-2cc6865a581b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee86780d-a859-41af-97aa-2cc6865a581b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee86780d-a859-41af-97aa-2cc6865a581b">
											<gml:posList>35.673967899015736 139.7392302094299 49.691 35.67395368236341 139.7392161083693 49.691 35.67394147420757 139.73923460391464 49.691 35.67395569987147 139.73924870496577 49.691 35.673967899015736 139.7392302094299 49.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ecf8957a-9770-415d-8e01-59e8ea168ea3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecf8957a-9770-415d-8e01-59e8ea168ea3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecf8957a-9770-415d-8e01-59e8ea168ea3">
											<gml:posList>35.67396653934191 139.73924353341062 48 35.67396373959937 139.73923651096166 48 35.67395569987147 139.73924870496577 48 35.67395575244927 139.7392583155783 48 35.67396653934191 139.73924353341062 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-032a7eec-0109-47b0-8903-b73b6130e8e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-032a7eec-0109-47b0-8903-b73b6130e8e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-032a7eec-0109-47b0-8903-b73b6130e8e2">
											<gml:posList>35.67398006249581 139.73925835333125 49.691 35.67396653934191 139.73924353341062 49.691 35.67395575244927 139.7392583155783 49.691 35.673969275601365 139.73927313549945 49.691 35.67398006249581 139.73925835333125 49.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b45cfe9a-fcb3-44ae-8282-9cda4884813a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b45cfe9a-fcb3-44ae-8282-9cda4884813a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b45cfe9a-fcb3-44ae-8282-9cda4884813a">
											<gml:posList>35.67397789452387 139.73929852187663 50.803 35.673941095072344 139.73936084661827 50.803 35.67396009112422 139.7393776927421 50.803 35.67399689058433 139.7393153679934 50.803 35.67397789452387 139.73929852187663 50.803</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98026155-60cb-4fcf-8c75-706966abc687">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98026155-60cb-4fcf-8c75-706966abc687">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98026155-60cb-4fcf-8c75-706966abc687">
											<gml:posList>35.67398916574219 139.73926910218958 48 35.67398006249581 139.73925835333125 48 35.673969275601365 139.73927313549945 48 35.6739806499321 139.73928340668317 48 35.67398916574219 139.73926910218958 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-063df0d5-879d-46c8-b122-6196d060a1fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-063df0d5-879d-46c8-b122-6196d060a1fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-063df0d5-879d-46c8-b122-6196d060a1fc">
											<gml:posList>35.67393977307365 139.73944559883233 14.914 35.67394645857738 139.73945372141114 14.914 35.67397520051955 139.7394269767 14.914 35.67401917680533 139.73932086523695 14.914 35.67401589341455 139.73931779808808 14.914 35.67393977307365 139.73944559883233 14.914</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-814080f0-9717-41df-911b-4e18f45eb7d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-814080f0-9717-41df-911b-4e18f45eb7d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-814080f0-9717-41df-911b-4e18f45eb7d5">
											<gml:posList>35.673988536558376 139.73936372944408 48 35.674017009657746 139.73931592987648 48 35.67399689058433 139.7393153679934 48 35.67396009112422 139.7393776927421 48 35.673988536558376 139.73936372944408 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9397dbad-a6fc-4696-8ca7-52b91e4f250b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9397dbad-a6fc-4696-8ca7-52b91e4f250b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9397dbad-a6fc-4696-8ca7-52b91e4f250b">
											<gml:posList>35.67398256380663 139.7392295183637 47.45 35.67400632256331 139.7392507665322 47.25 35.674011165589945 139.7392426304334 47.25 35.673987352706376 139.73922132709578 47.45 35.67398256380663 139.7392295183637 47.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-777f4557-f04e-4446-8ad1-4833c27fe808">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-777f4557-f04e-4446-8ad1-4833c27fe808">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-777f4557-f04e-4446-8ad1-4833c27fe808">
											<gml:posList>35.67398916574219 139.73926910218958 49.691 35.6739806499321 139.73928340668317 49.691 35.674017009657746 139.73931592987648 49.691 35.674025525463016 139.7393016143331 49.691 35.67398916574219 139.73926910218958 49.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2030a9ce-7e81-444d-b791-b112a996c2b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2030a9ce-7e81-444d-b791-b112a996c2b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2030a9ce-7e81-444d-b791-b112a996c2b8">
											<gml:posList>35.67369672852582 139.73922819688144 7.74 35.67369672852582 139.73922819688144 48 35.67386201938961 139.73909779494016 48 35.67386201938961 139.73909779494016 22.9 35.67386201938961 139.73909779494016 7.74 35.67369672852582 139.73922819688144 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03ac5d4a-7f79-4935-9670-769c1404be6e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03ac5d4a-7f79-4935-9670-769c1404be6e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03ac5d4a-7f79-4935-9670-769c1404be6e">
											<gml:posList>35.67393977307365 139.73944559883233 14.914 35.67393977307365 139.73944559883233 48 35.673875505448244 139.7393881205791 48 35.67369672852582 139.73922819688144 48 35.67369672852582 139.73922819688144 7.74 35.67393977307365 139.73944559883233 7.74 35.67393977307365 139.73944559883233 14.914</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-584fa83f-c2e8-41a8-9105-5524c0429587">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-584fa83f-c2e8-41a8-9105-5524c0429587">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-584fa83f-c2e8-41a8-9105-5524c0429587">
											<gml:posList>35.673829340979765 139.73932373907485 48 35.673829340979765 139.73932373907485 49.891 35.67384225035619 139.73930285665148 49.891 35.67384225035619 139.73930285665148 48 35.673829340979765 139.73932373907485 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a109f6c2-57b0-43cd-a4b1-731bf3d99b25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a109f6c2-57b0-43cd-a4b1-731bf3d99b25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a109f6c2-57b0-43cd-a4b1-731bf3d99b25">
											<gml:posList>35.673829340979765 139.73932373907485 49.891 35.673829340979765 139.73932373907485 48 35.67385881018029 139.73935110042908 48 35.67385881018029 139.73935110042908 49.891 35.673829340979765 139.73932373907485 49.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb51bfb7-020c-4b88-9340-4c838dc08a27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb51bfb7-020c-4b88-9340-4c838dc08a27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb51bfb7-020c-4b88-9340-4c838dc08a27">
											<gml:posList>35.67387171955277 139.73933020695569 49.891 35.67387171955277 139.73933020695569 48 35.67384589453766 139.73930623267862 48 35.67384225035619 139.73930285665148 48 35.67384225035619 139.73930285665148 49.891 35.67387171955277 139.73933020695569 49.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4733328-b4b8-4617-9294-76b9b31763d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4733328-b4b8-4617-9294-76b9b31763d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4733328-b4b8-4617-9294-76b9b31763d8">
											<gml:posList>35.67387171955277 139.73933020695569 48 35.67387171955277 139.73933020695569 49.891 35.67385881018029 139.73935110042908 49.891 35.67385881018029 139.73935110042908 48 35.67387171955277 139.73933020695569 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56529bf8-dacc-48f9-b33a-7599c2fec647">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56529bf8-dacc-48f9-b33a-7599c2fec647">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56529bf8-dacc-48f9-b33a-7599c2fec647">
											<gml:posList>35.67387137790651 139.7390891785286 7.74 35.67386201938961 139.73909779494016 7.74 35.67386201938961 139.73909779494016 22.9 35.67387137790651 139.7390891785286 22.9 35.67387137790651 139.7390891785286 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e5cae3f-c50d-4c7c-b32c-c5a6d2e7cae2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e5cae3f-c50d-4c7c-b32c-c5a6d2e7cae2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e5cae3f-c50d-4c7c-b32c-c5a6d2e7cae2">
											<gml:posList>35.67388983065114 139.7392295830312 50.691 35.67388983065114 139.7392295830312 48 35.67386243422642 139.7392709741816 48 35.67386243422642 139.7392709741816 50.691 35.67388983065114 139.7392295830312 50.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47685a77-1190-4ff0-9418-cb6915557e33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47685a77-1190-4ff0-9418-cb6915557e33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47685a77-1190-4ff0-9418-cb6915557e33">
											<gml:posList>35.67386243422642 139.7392709741816 50.691 35.67386243422642 139.7392709741816 48 35.673875424083754 139.73928389467386 48 35.67389674908449 139.739305090451 48 35.67389674908449 139.739305090451 50.691 35.67386243422642 139.7392709741816 50.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-595b5985-896b-4788-a560-54b2f089e64b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-595b5985-896b-4788-a560-54b2f089e64b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-595b5985-896b-4788-a560-54b2f089e64b">
											<gml:posList>35.67389249674346 139.73935401041783 50.891 35.67389249674346 139.73935401041783 48 35.67387924610418 139.73937651711702 48 35.67387924610418 139.73937651711702 50.891 35.67389249674346 139.73935401041783 50.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a1ac053-0281-4c3f-90e6-5288463a0eda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a1ac053-0281-4c3f-90e6-5288463a0eda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a1ac053-0281-4c3f-90e6-5288463a0eda">
											<gml:posList>35.67387924610418 139.73937651711702 50.891 35.67387924610418 139.73937651711702 48 35.67388713855432 139.73938348940828 48 35.67389414705645 139.73938968946467 48 35.67389414705645 139.73938968946467 50.891 35.67387924610418 139.73937651711702 50.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-980ae1c7-a61e-470d-a435-414061252d44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-980ae1c7-a61e-470d-a435-414061252d44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-980ae1c7-a61e-470d-a435-414061252d44">
											<gml:posList>35.67389249674346 139.73935401041783 48 35.67389249674346 139.73935401041783 50.891 35.67390738868445 139.739367182774 50.891 35.67390738868445 139.739367182774 48 35.67389249674346 139.73935401041783 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c99a7d7-b919-4044-b546-149d68949268">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c99a7d7-b919-4044-b546-149d68949268">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c99a7d7-b919-4044-b546-149d68949268">
											<gml:posList>35.67389432466606 139.7391900856479 49.891 35.67390595719853 139.73917320360758 49.891 35.67390595719853 139.73917320360758 48 35.67389432466606 139.7391900856479 48 35.67389432466606 139.7391900856479 49.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-595323f8-8df6-4fc2-931f-1935f580620b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-595323f8-8df6-4fc2-931f-1935f580620b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-595323f8-8df6-4fc2-931f-1935f580620b">
											<gml:posList>35.67389414705645 139.73938968946467 50.891 35.67389414705645 139.73938968946467 48 35.67390738868445 139.739367182774 48 35.67390738868445 139.739367182774 50.891 35.67389414705645 139.73938968946467 50.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa11eff3-69e0-4575-8868-5e5d50e5c333">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa11eff3-69e0-4575-8868-5e5d50e5c333">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa11eff3-69e0-4575-8868-5e5d50e5c333">
											<gml:posList>35.673915785674765 139.7392122864993 49.691 35.67389432466606 139.7391900856479 49.891 35.67389432466606 139.7391900856479 48 35.673915785674765 139.7392122864993 48 35.673915785674765 139.7392122864993 49.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eda705ce-55a0-4cec-ad09-e8be755381c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eda705ce-55a0-4cec-ad09-e8be755381c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eda705ce-55a0-4cec-ad09-e8be755381c3">
											<gml:posList>35.67392414551215 139.73926368824777 50.691 35.67392414551215 139.73926368824777 48 35.67388983065114 139.7392295830312 48 35.67388983065114 139.7392295830312 50.691 35.67392414551215 139.73926368824777 50.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8efba6ba-4f58-4159-92ee-23502496de3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8efba6ba-4f58-4159-92ee-23502496de3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8efba6ba-4f58-4159-92ee-23502496de3a">
											<gml:posList>35.67389674908449 139.739305090451 50.691 35.67389674908449 139.739305090451 48 35.67392414551215 139.73926368824777 48 35.67392414551215 139.73926368824777 50.691 35.67389674908449 139.739305090451 50.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a18c8b62-963b-43b0-aae6-6f1404ff7020">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a18c8b62-963b-43b0-aae6-6f1404ff7020">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a18c8b62-963b-43b0-aae6-6f1404ff7020">
											<gml:posList>35.67390595719853 139.73917320360758 49.891 35.67392741820166 139.73919539341094 49.891 35.67392741820166 139.73919539341094 48 35.67390595719853 139.73917320360758 48 35.67390595719853 139.73917320360758 49.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e18e00a-e6e7-4d00-8c32-cfaf96b373c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e18e00a-e6e7-4d00-8c32-cfaf96b373c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e18e00a-e6e7-4d00-8c32-cfaf96b373c4">
											<gml:posList>35.67392741820166 139.73919539341094 49.891 35.673915785674765 139.7392122864993 49.691 35.673915785674765 139.7392122864993 48 35.67392741820166 139.73919539341094 48 35.67392741820166 139.73919539341094 49.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5712488-1694-4c24-98d5-f08f8979e64b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5712488-1694-4c24-98d5-f08f8979e64b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5712488-1694-4c24-98d5-f08f8979e64b">
											<gml:posList>35.67399139446869 139.7392144181279 48 35.67399148467495 139.73921450639605 22.9 35.67386201938961 139.73909779494016 22.9 35.67386201938961 139.73909779494016 48 35.67399139446869 139.7392144181279 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca02ac3e-de8b-4135-bf6b-c54bdd8fc8e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca02ac3e-de8b-4135-bf6b-c54bdd8fc8e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca02ac3e-de8b-4135-bf6b-c54bdd8fc8e2">
											<gml:posList>35.67399807402857 139.73920338562155 7.74 35.67387137790651 139.7390891785286 7.74 35.67387137790651 139.7390891785286 22.9 35.67399801089801 139.73920334150864 22.9 35.67399807402857 139.73920338562155 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73991a76-3851-4f66-a884-594e04e9e030">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73991a76-3851-4f66-a884-594e04e9e030">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73991a76-3851-4f66-a884-594e04e9e030">
											<gml:posList>35.67393977307365 139.73944559883233 7.74 35.67394645857738 139.73945372141114 7.74 35.67394645857738 139.73945372141114 14.914 35.67393977307365 139.73944559883233 14.914 35.67393977307365 139.73944559883233 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f4ba4ad-1a28-4386-9ada-7e65eb0587ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f4ba4ad-1a28-4386-9ada-7e65eb0587ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f4ba4ad-1a28-4386-9ada-7e65eb0587ac">
											<gml:posList>35.67395368236341 139.7392161083693 49.691 35.67395368236341 139.7392161083693 48 35.67394147420757 139.73923460391464 48 35.67394147420757 139.73923460391464 49.691 35.67395368236341 139.7392161083693 49.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1458695-5821-401d-9852-90d144bb81e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1458695-5821-401d-9852-90d144bb81e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1458695-5821-401d-9852-90d144bb81e7">
											<gml:posList>35.67394147420757 139.73923460391464 49.691 35.67394147420757 139.73923460391464 48 35.67395569987147 139.73924870496577 48 35.67395569987147 139.73924870496577 49.691 35.67394147420757 139.73923460391464 49.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03ac6b0c-e664-4771-bc8a-3a28865ee13e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03ac6b0c-e664-4771-bc8a-3a28865ee13e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03ac6b0c-e664-4771-bc8a-3a28865ee13e">
											<gml:posList>35.673941095072344 139.73936084661827 50.803 35.67394125726752 139.73936078014765 48 35.67396009112422 139.7393776927421 48 35.67396009112422 139.7393776927421 50.803 35.673941095072344 139.73936084661827 50.803</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f37dd88-1c31-4e2d-b754-7fec4002d5c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f37dd88-1c31-4e2d-b754-7fec4002d5c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f37dd88-1c31-4e2d-b754-7fec4002d5c6">
											<gml:posList>35.67397789452387 139.73929852187663 50.803 35.67397789452387 139.73929852187663 48 35.67394125726752 139.73936078014765 48 35.673941095072344 139.73936084661827 50.803 35.67397789452387 139.73929852187663 50.803</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66e88d36-e411-450f-87fe-acdf34dc0771">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66e88d36-e411-450f-87fe-acdf34dc0771">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66e88d36-e411-450f-87fe-acdf34dc0771">
											<gml:posList>35.67394645857738 139.73945372141114 7.74 35.67397520051955 139.7394269767 7.74 35.67397520051955 139.7394269767 14.914 35.67394645857738 139.73945372141114 14.914 35.67394645857738 139.73945372141114 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec87a179-d287-4846-84fc-71a246ce9890">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec87a179-d287-4846-84fc-71a246ce9890">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec87a179-d287-4846-84fc-71a246ce9890">
											<gml:posList>35.673967899015736 139.7392302094299 49.691 35.673967899015736 139.7392302094299 48 35.67395368236341 139.7392161083693 48 35.67395368236341 139.7392161083693 49.691 35.673967899015736 139.7392302094299 49.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72ebe3f5-2580-46d0-9c95-c20b4f1b77e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72ebe3f5-2580-46d0-9c95-c20b4f1b77e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72ebe3f5-2580-46d0-9c95-c20b4f1b77e0">
											<gml:posList>35.67395575244927 139.7392583155783 48 35.67395575244927 139.7392583155783 49.691 35.67396653934191 139.73924353341062 49.691 35.67396653934191 139.73924353341062 48 35.67395575244927 139.7392583155783 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99e37a1f-de45-4406-a936-fd588e8c36a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99e37a1f-de45-4406-a936-fd588e8c36a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99e37a1f-de45-4406-a936-fd588e8c36a2">
											<gml:posList>35.67395569987147 139.73924870496577 49.691 35.67395569987147 139.73924870496577 48 35.67396373959937 139.73923651096166 48 35.673967899015736 139.7392302094299 48 35.673967899015736 139.7392302094299 49.691 35.67395569987147 139.73924870496577 49.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b12f37cc-7cf4-4871-9dd3-6bf2083637fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b12f37cc-7cf4-4871-9dd3-6bf2083637fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b12f37cc-7cf4-4871-9dd3-6bf2083637fe">
											<gml:posList>35.673969275601365 139.73927313549945 48 35.673969275601365 139.73927313549945 49.691 35.67395575244927 139.7392583155783 49.691 35.67395575244927 139.7392583155783 48 35.673969275601365 139.73927313549945 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b686459-6e91-412e-a0f9-d4b80a6e2311">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b686459-6e91-412e-a0f9-d4b80a6e2311">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b686459-6e91-412e-a0f9-d4b80a6e2311">
											<gml:posList>35.67396653934191 139.73924353341062 48 35.67396653934191 139.73924353341062 49.691 35.67398006249581 139.73925835333125 49.691 35.67398006249581 139.73925835333125 48 35.67396653934191 139.73924353341062 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d31dba8f-b490-4e43-bc6f-5b1092aaa08b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d31dba8f-b490-4e43-bc6f-5b1092aaa08b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d31dba8f-b490-4e43-bc6f-5b1092aaa08b">
											<gml:posList>35.67398006249581 139.73925835333125 48 35.67398006249581 139.73925835333125 49.691 35.673969275601365 139.73927313549945 49.691 35.673969275601365 139.73927313549945 48 35.67398006249581 139.73925835333125 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39366ce9-4ae5-421d-ac36-441c4dd64294">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39366ce9-4ae5-421d-ac36-441c4dd64294">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39366ce9-4ae5-421d-ac36-441c4dd64294">
											<gml:posList>35.67396009112422 139.7393776927421 50.803 35.67396009112422 139.7393776927421 48 35.67399689058433 139.7393153679934 48 35.67399689058433 139.7393153679934 50.803 35.67396009112422 139.7393776927421 50.803</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df572532-a0fc-4140-a715-8af4beac678b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df572532-a0fc-4140-a715-8af4beac678b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df572532-a0fc-4140-a715-8af4beac678b">
											<gml:posList>35.67398916574219 139.73926910218958 49.691 35.67398916574219 139.73926910218958 48 35.6739806499321 139.73928340668317 48 35.6739806499321 139.73928340668317 49.691 35.67398916574219 139.73926910218958 49.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84dc9250-3239-45cc-b1ec-d68321fb0b26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84dc9250-3239-45cc-b1ec-d68321fb0b26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84dc9250-3239-45cc-b1ec-d68321fb0b26">
											<gml:posList>35.67399689058433 139.7393153679934 50.803 35.67399689058433 139.7393153679934 48 35.67397789452387 139.73929852187663 48 35.67397789452387 139.73929852187663 50.803 35.67399689058433 139.7393153679934 50.803</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-904a0d55-a788-48f9-b503-577681dad38d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-904a0d55-a788-48f9-b503-577681dad38d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-904a0d55-a788-48f9-b503-577681dad38d">
											<gml:posList>35.673976681018154 139.73938363854637 48 35.67393977307365 139.73944559883233 48 35.67393977307365 139.73944559883233 14.914 35.67401589341455 139.73931779808808 14.914 35.67401589341455 139.73931779808808 7.74 35.67403860525009 139.73927964907224 7.74 35.67403860525009 139.73927964907224 48 35.674025525463016 139.7393016143331 48 35.674025525463016 139.7393016143331 49.691 35.674017009657746 139.73931592987648 49.691 35.674017009657746 139.73931592987648 48 35.673988536558376 139.73936372944408 48 35.673976681018154 139.73938363854637 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3430ca90-6734-4add-964a-89b7e6284c15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3430ca90-6734-4add-964a-89b7e6284c15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3430ca90-6734-4add-964a-89b7e6284c15">
											<gml:posList>35.67399153879179 139.73921455051953 7.74 35.67399807402857 139.73920338562155 7.74 35.67399801089801 139.73920334150864 22.9 35.67399148467495 139.73921450639605 22.9 35.67399139446869 139.7392144181279 48 35.67398256380663 139.7392295183637 48 35.67398256380663 139.7392295183637 47.45 35.673987352706376 139.73922132709578 47.45 35.673987506043176 139.73922145947685 7.74 35.67399153879179 139.73921455051953 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f8d772c-2b13-4e62-9898-1873c0f54361">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f8d772c-2b13-4e62-9898-1873c0f54361">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f8d772c-2b13-4e62-9898-1873c0f54361">
											<gml:posList>35.67397520051955 139.7394269767 7.74 35.67401917680533 139.73932086523695 7.74 35.67401917680533 139.73932086523695 14.914 35.67397520051955 139.7394269767 14.914 35.67397520051955 139.7394269767 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7593bd7e-a62c-4269-97c3-7d9a7a9b3cd9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7593bd7e-a62c-4269-97c3-7d9a7a9b3cd9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7593bd7e-a62c-4269-97c3-7d9a7a9b3cd9">
											<gml:posList>35.6739806499321 139.73928340668317 49.691 35.6739806499321 139.73928340668317 48 35.674017009657746 139.73931592987648 48 35.674017009657746 139.73931592987648 49.691 35.6739806499321 139.73928340668317 49.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b9abf54-4a7e-4bb0-aecf-03bca236b38c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b9abf54-4a7e-4bb0-aecf-03bca236b38c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b9abf54-4a7e-4bb0-aecf-03bca236b38c">
											<gml:posList>35.674011165589945 139.7392426304334 47.25 35.674011165589945 139.7392426304334 7.74 35.673987506043176 139.73922145947685 7.74 35.673987352706376 139.73922132709578 47.45 35.674011165589945 139.7392426304334 47.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ecbdcc9-d9ff-467c-bffc-aaa9f0e5864d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ecbdcc9-d9ff-467c-bffc-aaa9f0e5864d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ecbdcc9-d9ff-467c-bffc-aaa9f0e5864d">
											<gml:posList>35.674025525463016 139.7393016143331 49.691 35.674025525463016 139.7393016143331 48 35.67398916574219 139.73926910218958 48 35.67398916574219 139.73926910218958 49.691 35.674025525463016 139.7393016143331 49.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87ed1e16-b03c-4e58-a71e-b5f7361114c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87ed1e16-b03c-4e58-a71e-b5f7361114c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87ed1e16-b03c-4e58-a71e-b5f7361114c5">
											<gml:posList>35.67400632256331 139.7392507665322 47.25 35.67400632256331 139.7392507665322 7.74 35.674011165589945 139.7392426304334 7.74 35.674011165589945 139.7392426304334 47.25 35.67400632256331 139.7392507665322 47.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4ad707f-a866-4daf-9add-7efad988d3c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4ad707f-a866-4daf-9add-7efad988d3c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4ad707f-a866-4daf-9add-7efad988d3c2">
											<gml:posList>35.67403860525009 139.73927964907224 7.74 35.67400632256331 139.7392507665322 7.74 35.67400632256331 139.7392507665322 47.25 35.67398256380663 139.7392295183637 47.45 35.67398256380663 139.7392295183637 48 35.67403860525009 139.73927964907224 48 35.67403860525009 139.73927964907224 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cb608bd-b070-4121-a1e7-1339f47bc558">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cb608bd-b070-4121-a1e7-1339f47bc558">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cb608bd-b070-4121-a1e7-1339f47bc558">
											<gml:posList>35.67401917680533 139.73932086523695 7.74 35.67401589341455 139.73931779808808 7.74 35.67401589341455 139.73931779808808 14.914 35.67401917680533 139.73932086523695 14.914 35.67401917680533 139.73932086523695 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4555</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">456.39295</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>