<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_ce8ad1b6-9f6b-4afd-8275-25f33f4110e5">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">14.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6695395755535 139.74975490402196 0 35.66945060580349 139.7497098954044 0 35.669436843101714 139.74975066997916 0 35.669525848883985 139.74979566755061 0 35.6695395755535 139.74975490402196 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6695395755535 139.74975490402196 6.25 35.669525848883985 139.74979566755061 6.25 35.669436843101714 139.74975066997916 6.25 35.66945060580349 139.7497098954044 6.25 35.6695395755535 139.74975490402196 6.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6695395755535 139.74975490402196 6.25 35.66945060580349 139.7497098954044 6.25 35.66945060580349 139.7497098954044 21.13 35.6695395755535 139.74975490402196 21.13 35.6695395755535 139.74975490402196 6.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66945060580349 139.7497098954044 6.25 35.669436843101714 139.74975066997916 6.25 35.669436843101714 139.74975066997916 21.13 35.66945060580349 139.7497098954044 21.13 35.66945060580349 139.7497098954044 6.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669436843101714 139.74975066997916 6.25 35.669525848883985 139.74979566755061 6.25 35.669525848883985 139.74979566755061 21.13 35.669436843101714 139.74975066997916 21.13 35.669436843101714 139.74975066997916 6.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669525848883985 139.74979566755061 6.25 35.6695395755535 139.74975490402196 6.25 35.6695395755535 139.74975490402196 21.13 35.669525848883985 139.74979566755061 21.13 35.669525848883985 139.74979566755061 6.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6695395755535 139.74975490402196 21.13 35.66945060580349 139.7497098954044 21.13 35.669436843101714 139.74975066997916 21.13 35.669525848883985 139.74979566755061 21.13 35.6695395755535 139.74975490402196 21.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2eb70fbe-b552-47e5-960e-878d21028753"/>
							<gml:surfaceMember xlink:href="#poly-198ab2f2-f322-490d-a1a2-9391e2256efa"/>
							<gml:surfaceMember xlink:href="#poly-911de492-42b3-4745-b76b-d3c19d914da9"/>
							<gml:surfaceMember xlink:href="#poly-d0b65eb1-ba80-4198-8739-f1bd844ba020"/>
							<gml:surfaceMember xlink:href="#poly-746d26ae-643f-4ee7-830a-ea0b02c0ef00"/>
							<gml:surfaceMember xlink:href="#poly-d8090977-6a28-4572-a751-289cd2c8009c"/>
							<gml:surfaceMember xlink:href="#poly-2a55efa4-9390-410a-ac59-37e290185273"/>
							<gml:surfaceMember xlink:href="#poly-b318231c-be80-43af-be66-f225148e300d"/>
							<gml:surfaceMember xlink:href="#poly-717d84d1-7959-46d1-aad3-f5c83084ecff"/>
							<gml:surfaceMember xlink:href="#poly-4f1b7352-3d5e-460b-81b1-beba792118a3"/>
							<gml:surfaceMember xlink:href="#poly-7ec80479-cf87-40d1-8347-1c9f85d1e003"/>
							<gml:surfaceMember xlink:href="#poly-2ed050a2-197a-40d9-92db-04449d6439d5"/>
							<gml:surfaceMember xlink:href="#poly-92bfda19-90e5-4424-9f84-8593d4ec87a9"/>
							<gml:surfaceMember xlink:href="#poly-81d32349-b14a-46aa-b89d-183dc09d9e1e"/>
							<gml:surfaceMember xlink:href="#poly-cf48169e-f280-44f7-83b5-e5cda56125b3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2eb70fbe-b552-47e5-960e-878d21028753">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2eb70fbe-b552-47e5-960e-878d21028753">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2eb70fbe-b552-47e5-960e-878d21028753">
											<gml:posList>35.66953957555347 139.74975490402196 6.25 35.66952584888396 139.74979566755061 6.25 35.66943684310172 139.74975066997916 6.25 35.66945060580348 139.7497098954044 6.25 35.66953957555347 139.74975490402196 6.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-198ab2f2-f322-490d-a1a2-9391e2256efa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-198ab2f2-f322-490d-a1a2-9391e2256efa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-198ab2f2-f322-490d-a1a2-9391e2256efa">
											<gml:posList>35.66945060580348 139.7497098954044 19.254 35.66943684310172 139.74975066997916 19.254 35.669450097941045 139.74975737221024 20.7 35.66946383359619 139.74971658661198 20.7 35.66945060580348 139.7497098954044 19.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-911de492-42b3-4745-b76b-d3c19d914da9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-911de492-42b3-4745-b76b-d3c19d914da9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-911de492-42b3-4745-b76b-d3c19d914da9">
											<gml:posList>35.669450097941045 139.74975737221024 20.7 35.6694531254874 139.74975583364207 20.7 35.66946508907372 139.74972028575763 20.7 35.66946383359619 139.74971658661198 20.7 35.669450097941045 139.74975737221024 20.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0b65eb1-ba80-4198-8739-f1bd844ba020">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0b65eb1-ba80-4198-8739-f1bd844ba020">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0b65eb1-ba80-4198-8739-f1bd844ba020">
											<gml:posList>35.66952584888396 139.74979566755061 20.7 35.66952459340876 139.7497919684009 20.7 35.6694531254874 139.74975583364207 20.7 35.669450097941045 139.74975737221024 20.7 35.66952584888396 139.74979566755061 20.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-746d26ae-643f-4ee7-830a-ea0b02c0ef00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-746d26ae-643f-4ee7-830a-ea0b02c0ef00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-746d26ae-643f-4ee7-830a-ea0b02c0ef00">
											<gml:posList>35.669536557028565 139.74975645362858 20.297 35.66946508907372 139.74972028575763 20.297 35.6694531254874 139.74975583364207 20.297 35.66952459340876 139.7497919684009 20.297 35.669536557028565 139.74975645362858 20.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d8090977-6a28-4572-a751-289cd2c8009c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8090977-6a28-4572-a751-289cd2c8009c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8090977-6a28-4572-a751-289cd2c8009c">
											<gml:posList>35.66946383359619 139.74971658661198 20.7 35.66946508907372 139.74972028575763 20.7 35.669536557028565 139.74975645362858 20.7 35.66953957555347 139.74975490402196 20.7 35.66946383359619 139.74971658661198 20.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2a55efa4-9390-410a-ac59-37e290185273">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a55efa4-9390-410a-ac59-37e290185273">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a55efa4-9390-410a-ac59-37e290185273">
											<gml:posList>35.66953957555347 139.74975490402196 20.7 35.669536557028565 139.74975645362858 20.7 35.66952459340876 139.7497919684009 20.7 35.66952584888396 139.74979566755061 20.7 35.66953957555347 139.74975490402196 20.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b318231c-be80-43af-be66-f225148e300d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b318231c-be80-43af-be66-f225148e300d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b318231c-be80-43af-be66-f225148e300d">
											<gml:posList>35.66946508907372 139.74972028575763 20.7 35.66946508907372 139.74972028575763 20.297 35.669536557028565 139.74975645362858 20.297 35.669536557028565 139.74975645362858 20.7 35.66946508907372 139.74972028575763 20.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-717d84d1-7959-46d1-aad3-f5c83084ecff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-717d84d1-7959-46d1-aad3-f5c83084ecff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-717d84d1-7959-46d1-aad3-f5c83084ecff">
											<gml:posList>35.66952459340876 139.7497919684009 20.7 35.66952459340876 139.7497919684009 20.297 35.6694531254874 139.74975583364207 20.297 35.6694531254874 139.74975583364207 20.7 35.66952459340876 139.7497919684009 20.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f1b7352-3d5e-460b-81b1-beba792118a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f1b7352-3d5e-460b-81b1-beba792118a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f1b7352-3d5e-460b-81b1-beba792118a3">
											<gml:posList>35.66945060580348 139.7497098954044 6.25 35.66943684310172 139.74975066997916 6.25 35.66943684310172 139.74975066997916 19.254 35.66945060580348 139.7497098954044 19.254 35.66945060580348 139.7497098954044 6.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ec80479-cf87-40d1-8347-1c9f85d1e003">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ec80479-cf87-40d1-8347-1c9f85d1e003">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ec80479-cf87-40d1-8347-1c9f85d1e003">
											<gml:posList>35.6694531254874 139.74975583364207 20.7 35.6694531254874 139.74975583364207 20.297 35.66946508907372 139.74972028575763 20.297 35.66946508907372 139.74972028575763 20.7 35.6694531254874 139.74975583364207 20.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ed050a2-197a-40d9-92db-04449d6439d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ed050a2-197a-40d9-92db-04449d6439d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ed050a2-197a-40d9-92db-04449d6439d5">
											<gml:posList>35.669450097941045 139.74975737221024 20.7 35.66943684310172 139.74975066997916 19.254 35.66943684310172 139.74975066997916 6.25 35.66952584888396 139.74979566755061 6.25 35.66952584888396 139.74979566755061 20.7 35.669450097941045 139.74975737221024 20.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92bfda19-90e5-4424-9f84-8593d4ec87a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92bfda19-90e5-4424-9f84-8593d4ec87a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92bfda19-90e5-4424-9f84-8593d4ec87a9">
											<gml:posList>35.66946383359619 139.74971658661198 20.7 35.66953957555347 139.74975490402196 20.7 35.66953957555347 139.74975490402196 6.25 35.66945060580348 139.7497098954044 6.25 35.66945060580348 139.7497098954044 19.254 35.66946383359619 139.74971658661198 20.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81d32349-b14a-46aa-b89d-183dc09d9e1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81d32349-b14a-46aa-b89d-183dc09d9e1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81d32349-b14a-46aa-b89d-183dc09d9e1e">
											<gml:posList>35.669536557028565 139.74975645362858 20.7 35.669536557028565 139.74975645362858 20.297 35.66952459340876 139.7497919684009 20.297 35.66952459340876 139.7497919684009 20.7 35.669536557028565 139.74975645362858 20.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf48169e-f280-44f7-83b5-e5cda56125b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf48169e-f280-44f7-83b5-e5cda56125b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf48169e-f280-44f7-83b5-e5cda56125b3">
											<gml:posList>35.66952584888396 139.74979566755061 6.25 35.66953957555347 139.74975490402196 6.25 35.66953957555347 139.74975490402196 20.7 35.66952584888396 139.74979566755061 20.7 35.66952584888396 139.74979566755061 6.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10940</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">60.16725</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>