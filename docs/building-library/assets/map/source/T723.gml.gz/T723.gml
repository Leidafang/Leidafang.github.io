<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_cec835d1-f58c-4040-8804-bcadb15bd8cb">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.6</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670282416473604 139.7444207035665 0 35.67026162861472 139.74450321996554 0 35.670287234753026 139.7445129012473 0 35.670308013612846 139.74443039588064 0 35.670282416473604 139.7444207035665 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670282416473604 139.7444207035665 8.388 35.670308013612846 139.74443039588064 8.388 35.670287234753026 139.7445129012473 8.388 35.67026162861472 139.74450321996554 8.388 35.670282416473604 139.7444207035665 8.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670282416473604 139.7444207035665 8.388 35.67026162861472 139.74450321996554 8.388 35.67026162861472 139.74450321996554 11.99 35.670282416473604 139.7444207035665 11.99 35.670282416473604 139.7444207035665 8.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67026162861472 139.74450321996554 8.388 35.670287234753026 139.7445129012473 8.388 35.670287234753026 139.7445129012473 11.99 35.67026162861472 139.74450321996554 11.99 35.67026162861472 139.74450321996554 8.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670287234753026 139.7445129012473 8.388 35.670308013612846 139.74443039588064 8.388 35.670308013612846 139.74443039588064 11.99 35.670287234753026 139.7445129012473 11.99 35.670287234753026 139.7445129012473 8.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670308013612846 139.74443039588064 8.388 35.670282416473604 139.7444207035665 8.388 35.670282416473604 139.7444207035665 11.99 35.670308013612846 139.74443039588064 11.99 35.670308013612846 139.74443039588064 8.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670282416473604 139.7444207035665 11.99 35.67026162861472 139.74450321996554 11.99 35.670287234753026 139.7445129012473 11.99 35.670308013612846 139.74443039588064 11.99 35.670282416473604 139.7444207035665 11.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-873a92be-1eec-4b80-8ff0-d4e3811038f7"/>
							<gml:surfaceMember xlink:href="#poly-c73c2b61-c1e2-481e-a25d-d8a0191b5a3d"/>
							<gml:surfaceMember xlink:href="#poly-aa1b5c3d-2941-462f-8d34-04b144d1b59d"/>
							<gml:surfaceMember xlink:href="#poly-57fd4b45-1d2c-4faf-8d8b-fca5c185a224"/>
							<gml:surfaceMember xlink:href="#poly-42541608-9120-4032-a83d-ba41bbca24bd"/>
							<gml:surfaceMember xlink:href="#poly-02c600cc-9676-4eee-bd3f-5ed91e180a9d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-873a92be-1eec-4b80-8ff0-d4e3811038f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-873a92be-1eec-4b80-8ff0-d4e3811038f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-873a92be-1eec-4b80-8ff0-d4e3811038f7">
											<gml:posList>35.670282416473604 139.7444207035665 8.388 35.67030801361283 139.74443039588064 8.388 35.670287234753 139.74451290124728 8.388 35.6702616286147 139.74450321996554 8.388 35.670282416473604 139.7444207035665 8.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c73c2b61-c1e2-481e-a25d-d8a0191b5a3d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c73c2b61-c1e2-481e-a25d-d8a0191b5a3d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c73c2b61-c1e2-481e-a25d-d8a0191b5a3d">
											<gml:posList>35.67030801361283 139.74443039588064 12.292 35.670282416473604 139.7444207035665 12.292 35.6702616286147 139.74450321996554 12.292 35.670287234753 139.74451290124728 12.292 35.67030801361283 139.74443039588064 12.292</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa1b5c3d-2941-462f-8d34-04b144d1b59d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa1b5c3d-2941-462f-8d34-04b144d1b59d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa1b5c3d-2941-462f-8d34-04b144d1b59d">
											<gml:posList>35.670287234753 139.74451290124728 8.388 35.67030801361283 139.74443039588064 8.388 35.67030801361283 139.74443039588064 12.292 35.670287234753 139.74451290124728 12.292 35.670287234753 139.74451290124728 8.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57fd4b45-1d2c-4faf-8d8b-fca5c185a224">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57fd4b45-1d2c-4faf-8d8b-fca5c185a224">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57fd4b45-1d2c-4faf-8d8b-fca5c185a224">
											<gml:posList>35.67030801361283 139.74443039588064 8.388 35.670282416473604 139.7444207035665 8.388 35.670282416473604 139.7444207035665 12.292 35.67030801361283 139.74443039588064 12.292 35.67030801361283 139.74443039588064 8.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-42541608-9120-4032-a83d-ba41bbca24bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42541608-9120-4032-a83d-ba41bbca24bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42541608-9120-4032-a83d-ba41bbca24bd">
											<gml:posList>35.670282416473604 139.7444207035665 8.388 35.6702616286147 139.74450321996554 8.388 35.6702616286147 139.74450321996554 12.292 35.670282416473604 139.7444207035665 12.292 35.670282416473604 139.7444207035665 8.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02c600cc-9676-4eee-bd3f-5ed91e180a9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02c600cc-9676-4eee-bd3f-5ed91e180a9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02c600cc-9676-4eee-bd3f-5ed91e180a9d">
											<gml:posList>35.6702616286147 139.74450321996554 8.388 35.670287234753 139.74451290124728 8.388 35.670287234753 139.74451290124728 12.292 35.6702616286147 139.74450321996554 12.292 35.6702616286147 139.74450321996554 8.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7214</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>