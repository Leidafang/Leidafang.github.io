<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_cf551037-9c59-4cd3-b138-d9329aab161e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">11.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.673734568586504 139.74002794614896 0 35.67371706887618 139.74001106503616 0 35.67372229066766 139.7400031053192 0 35.673671631679454 139.73995421631088 0 35.67366672454178 139.73994948298713 0 35.67360064340087 139.74005218383397 0 35.673581159134926 139.74003331664753 0 35.6734802368022 139.74019029705013 0 35.673504763377224 139.74021389742387 0 35.67349865041794 139.74022341572368 0 35.67354880409475 139.74027174200208 0 35.67363271104289 139.74014118298382 0 35.67365057162584 139.7401585055563 0 35.673734568586504 139.74002794614896 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673734568586504 139.74002794614896 8.31 35.67365057162584 139.7401585055563 8.31 35.67363271104289 139.74014118298382 8.31 35.67354880409475 139.74027174200208 8.31 35.67349865041794 139.74022341572368 8.31 35.673504763377224 139.74021389742387 8.31 35.6734802368022 139.74019029705013 8.31 35.673581159134926 139.74003331664753 8.31 35.67360064340087 139.74005218383397 8.31 35.67366672454178 139.73994948298713 8.31 35.673671631679454 139.73995421631088 8.31 35.67372229066766 139.7400031053192 8.31 35.67371706887618 139.74001106503616 8.31 35.673734568586504 139.74002794614896 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673734568586504 139.74002794614896 8.31 35.67371706887618 139.74001106503616 8.31 35.67371706887618 139.74001106503616 17.79 35.673734568586504 139.74002794614896 17.79 35.673734568586504 139.74002794614896 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67371706887618 139.74001106503616 8.31 35.67372229066766 139.7400031053192 8.31 35.67372229066766 139.7400031053192 17.79 35.67371706887618 139.74001106503616 17.79 35.67371706887618 139.74001106503616 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67372229066766 139.7400031053192 8.31 35.673671631679454 139.73995421631088 8.31 35.673671631679454 139.73995421631088 17.79 35.67372229066766 139.7400031053192 17.79 35.67372229066766 139.7400031053192 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673671631679454 139.73995421631088 8.31 35.67366672454178 139.73994948298713 8.31 35.67366672454178 139.73994948298713 17.79 35.673671631679454 139.73995421631088 17.79 35.673671631679454 139.73995421631088 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67366672454178 139.73994948298713 8.31 35.67360064340087 139.74005218383397 8.31 35.67360064340087 139.74005218383397 17.79 35.67366672454178 139.73994948298713 17.79 35.67366672454178 139.73994948298713 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67360064340087 139.74005218383397 8.31 35.673581159134926 139.74003331664753 8.31 35.673581159134926 139.74003331664753 17.79 35.67360064340087 139.74005218383397 17.79 35.67360064340087 139.74005218383397 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673581159134926 139.74003331664753 8.31 35.6734802368022 139.74019029705013 8.31 35.6734802368022 139.74019029705013 17.79 35.673581159134926 139.74003331664753 17.79 35.673581159134926 139.74003331664753 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6734802368022 139.74019029705013 8.31 35.673504763377224 139.74021389742387 8.31 35.673504763377224 139.74021389742387 17.79 35.6734802368022 139.74019029705013 17.79 35.6734802368022 139.74019029705013 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673504763377224 139.74021389742387 8.31 35.67349865041794 139.74022341572368 8.31 35.67349865041794 139.74022341572368 17.79 35.673504763377224 139.74021389742387 17.79 35.673504763377224 139.74021389742387 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67349865041794 139.74022341572368 8.31 35.67354880409475 139.74027174200208 8.31 35.67354880409475 139.74027174200208 17.79 35.67349865041794 139.74022341572368 17.79 35.67349865041794 139.74022341572368 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67354880409475 139.74027174200208 8.31 35.67363271104289 139.74014118298382 8.31 35.67363271104289 139.74014118298382 17.79 35.67354880409475 139.74027174200208 17.79 35.67354880409475 139.74027174200208 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67363271104289 139.74014118298382 8.31 35.67365057162584 139.7401585055563 8.31 35.67365057162584 139.7401585055563 17.79 35.67363271104289 139.74014118298382 17.79 35.67363271104289 139.74014118298382 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67365057162584 139.7401585055563 8.31 35.673734568586504 139.74002794614896 8.31 35.673734568586504 139.74002794614896 17.79 35.67365057162584 139.7401585055563 17.79 35.67365057162584 139.7401585055563 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673734568586504 139.74002794614896 17.79 35.67371706887618 139.74001106503616 17.79 35.67372229066766 139.7400031053192 17.79 35.673671631679454 139.73995421631088 17.79 35.67366672454178 139.73994948298713 17.79 35.67360064340087 139.74005218383397 17.79 35.673581159134926 139.74003331664753 17.79 35.6734802368022 139.74019029705013 17.79 35.673504763377224 139.74021389742387 17.79 35.67349865041794 139.74022341572368 17.79 35.67354880409475 139.74027174200208 17.79 35.67363271104289 139.74014118298382 17.79 35.67365057162584 139.7401585055563 17.79 35.673734568586504 139.74002794614896 17.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ee387bc9-c239-47fe-a827-cd7d63cb0f90"/>
							<gml:surfaceMember xlink:href="#poly-6c89f44c-70ce-4db2-b5b7-d5e733519d2f"/>
							<gml:surfaceMember xlink:href="#poly-fcde66fa-7154-4582-8704-0ae0d8f37534"/>
							<gml:surfaceMember xlink:href="#poly-b348e11e-6874-4cbf-99d0-ca0f2d25b250"/>
							<gml:surfaceMember xlink:href="#poly-3c498b2a-1ef5-453e-be4a-16b3b3f9496d"/>
							<gml:surfaceMember xlink:href="#poly-f5e7900b-96ab-4089-965b-12ee62882743"/>
							<gml:surfaceMember xlink:href="#poly-4550da02-db83-4725-bd9c-4c5e5a68b79a"/>
							<gml:surfaceMember xlink:href="#poly-da2d9a33-a489-4c32-8950-9b33b244d851"/>
							<gml:surfaceMember xlink:href="#poly-000699b3-27d5-4ca3-8e99-b7223ddc4a76"/>
							<gml:surfaceMember xlink:href="#poly-8e08bb50-d2f7-4784-a2a2-5f4e48022844"/>
							<gml:surfaceMember xlink:href="#poly-d969dcf8-d118-479f-aff1-3f64f796a44a"/>
							<gml:surfaceMember xlink:href="#poly-e728678d-a21c-4862-97b7-e9306dd6326d"/>
							<gml:surfaceMember xlink:href="#poly-abbc46d8-b9fd-46fd-9885-43577268f00d"/>
							<gml:surfaceMember xlink:href="#poly-333d8452-28f0-44d7-9fb3-dea806ab1a5a"/>
							<gml:surfaceMember xlink:href="#poly-b581a935-33b0-4369-bf01-08b7e20118e2"/>
							<gml:surfaceMember xlink:href="#poly-2c68500a-d884-4f58-950c-77cf7c861e3f"/>
							<gml:surfaceMember xlink:href="#poly-4a7e4b3b-ee09-4a18-a0cd-841083274ddf"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ee387bc9-c239-47fe-a827-cd7d63cb0f90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee387bc9-c239-47fe-a827-cd7d63cb0f90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee387bc9-c239-47fe-a827-cd7d63cb0f90">
											<gml:posList>35.67366672454179 139.73994948298713 8.31 35.67372229066766 139.7400031053192 8.31 35.673717068876165 139.74001106503616 8.31 35.6737345685865 139.74002794614896 8.31 35.673650571625835 139.7401585055563 8.31 35.673632711042856 139.74014118298382 8.31 35.67354880409475 139.74027174200208 8.31 35.67349865041795 139.74022341572368 8.31 35.673504763377224 139.74021389742384 8.31 35.67348023680215 139.74019029705013 8.31 35.673581159134926 139.74003331664753 8.31 35.67360064340085 139.740052183834 8.31 35.67366672454179 139.73994948298713 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c89f44c-70ce-4db2-b5b7-d5e733519d2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c89f44c-70ce-4db2-b5b7-d5e733519d2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c89f44c-70ce-4db2-b5b7-d5e733519d2f">
											<gml:posList>35.673671622665765 139.73995421632137 13.6 35.67366672454179 139.73994948298713 13.6 35.67360064340085 139.740052183834 13.6 35.673581159134926 139.74003331664753 13.6 35.67348023680215 139.74019029705013 13.6 35.673504763377224 139.74021389742384 13.6 35.673671622665765 139.73995421632137 13.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fcde66fa-7154-4582-8704-0ae0d8f37534">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcde66fa-7154-4582-8704-0ae0d8f37534">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcde66fa-7154-4582-8704-0ae0d8f37534">
											<gml:posList>35.67354880409475 139.74027174200208 17.6 35.673632711042856 139.74014118298382 17.6 35.67362169705105 139.74013054676254 17.6 35.6737055858172 139.739999987499 17.6 35.673717068876165 139.74001106503616 17.6 35.67372229066766 139.7400031053192 17.6 35.673671622665765 139.73995421632137 17.6 35.67349865041795 139.74022341572368 17.6 35.67354880409475 139.74027174200208 17.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b348e11e-6874-4cbf-99d0-ca0f2d25b250">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b348e11e-6874-4cbf-99d0-ca0f2d25b250">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b348e11e-6874-4cbf-99d0-ca0f2d25b250">
											<gml:posList>35.6737055858172 139.739999987499 19.4 35.67362169705105 139.74013054676254 19.4 35.673632711042856 139.74014118298382 19.4 35.673650571625835 139.7401585055563 19.4 35.6737345685865 139.74002794614896 19.4 35.673717068876165 139.74001106503616 19.4 35.6737055858172 139.739999987499 19.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c498b2a-1ef5-453e-be4a-16b3b3f9496d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c498b2a-1ef5-453e-be4a-16b3b3f9496d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c498b2a-1ef5-453e-be4a-16b3b3f9496d">
											<gml:posList>35.67348023680215 139.74019029705013 13.6 35.67348023680215 139.74019029705013 8.31 35.673504763377224 139.74021389742384 8.31 35.673504763377224 139.74021389742384 13.6 35.67348023680215 139.74019029705013 13.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5e7900b-96ab-4089-965b-12ee62882743">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5e7900b-96ab-4089-965b-12ee62882743">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5e7900b-96ab-4089-965b-12ee62882743">
											<gml:posList>35.67349865041795 139.74022341572368 8.31 35.67354880409475 139.74027174200208 8.31 35.67354880409475 139.74027174200208 17.6 35.67349865041795 139.74022341572368 17.6 35.67349865041795 139.74022341572368 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4550da02-db83-4725-bd9c-4c5e5a68b79a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4550da02-db83-4725-bd9c-4c5e5a68b79a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4550da02-db83-4725-bd9c-4c5e5a68b79a">
											<gml:posList>35.673581159134926 139.74003331664753 8.31 35.67348023680215 139.74019029705013 8.31 35.67348023680215 139.74019029705013 13.6 35.673581159134926 139.74003331664753 13.6 35.673581159134926 139.74003331664753 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da2d9a33-a489-4c32-8950-9b33b244d851">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da2d9a33-a489-4c32-8950-9b33b244d851">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da2d9a33-a489-4c32-8950-9b33b244d851">
											<gml:posList>35.673671622665765 139.73995421632137 17.6 35.673671622665765 139.73995421632137 13.6 35.673504763377224 139.74021389742384 13.6 35.673504763377224 139.74021389742384 8.31 35.67349865041795 139.74022341572368 8.31 35.67349865041795 139.74022341572368 17.6 35.673671622665765 139.73995421632137 17.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-000699b3-27d5-4ca3-8e99-b7223ddc4a76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-000699b3-27d5-4ca3-8e99-b7223ddc4a76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-000699b3-27d5-4ca3-8e99-b7223ddc4a76">
											<gml:posList>35.67354880409475 139.74027174200208 8.31 35.673632711042856 139.74014118298382 8.31 35.673632711042856 139.74014118298382 17.6 35.67354880409475 139.74027174200208 17.6 35.67354880409475 139.74027174200208 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e08bb50-d2f7-4784-a2a2-5f4e48022844">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e08bb50-d2f7-4784-a2a2-5f4e48022844">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e08bb50-d2f7-4784-a2a2-5f4e48022844">
											<gml:posList>35.67360064340085 139.740052183834 8.31 35.673581159134926 139.74003331664753 8.31 35.673581159134926 139.74003331664753 13.6 35.67360064340085 139.740052183834 13.6 35.67360064340085 139.740052183834 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d969dcf8-d118-479f-aff1-3f64f796a44a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d969dcf8-d118-479f-aff1-3f64f796a44a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d969dcf8-d118-479f-aff1-3f64f796a44a">
											<gml:posList>35.67366672454179 139.73994948298713 8.31 35.67360064340085 139.740052183834 8.31 35.67360064340085 139.740052183834 13.6 35.67366672454179 139.73994948298713 13.6 35.67366672454179 139.73994948298713 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e728678d-a21c-4862-97b7-e9306dd6326d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e728678d-a21c-4862-97b7-e9306dd6326d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e728678d-a21c-4862-97b7-e9306dd6326d">
											<gml:posList>35.673632711042856 139.74014118298382 19.4 35.67362169705105 139.74013054676254 19.4 35.67362169705105 139.74013054676254 17.6 35.673632711042856 139.74014118298382 17.6 35.673632711042856 139.74014118298382 8.31 35.673650571625835 139.7401585055563 8.31 35.673650571625835 139.7401585055563 19.4 35.673632711042856 139.74014118298382 19.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-abbc46d8-b9fd-46fd-9885-43577268f00d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abbc46d8-b9fd-46fd-9885-43577268f00d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abbc46d8-b9fd-46fd-9885-43577268f00d">
											<gml:posList>35.67362169705105 139.74013054676254 19.4 35.6737055858172 139.739999987499 19.4 35.6737055858172 139.739999987499 17.6 35.67362169705105 139.74013054676254 17.6 35.67362169705105 139.74013054676254 19.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-333d8452-28f0-44d7-9fb3-dea806ab1a5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-333d8452-28f0-44d7-9fb3-dea806ab1a5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-333d8452-28f0-44d7-9fb3-dea806ab1a5a">
											<gml:posList>35.673650571625835 139.7401585055563 8.31 35.6737345685865 139.74002794614896 8.31 35.6737345685865 139.74002794614896 19.4 35.673650571625835 139.7401585055563 19.4 35.673650571625835 139.7401585055563 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b581a935-33b0-4369-bf01-08b7e20118e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b581a935-33b0-4369-bf01-08b7e20118e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b581a935-33b0-4369-bf01-08b7e20118e2">
											<gml:posList>35.67366672454179 139.73994948298713 8.31 35.67366672454179 139.73994948298713 13.6 35.673671622665765 139.73995421632137 13.6 35.673671622665765 139.73995421632137 17.6 35.67372229066766 139.7400031053192 17.6 35.67372229066766 139.7400031053192 8.31 35.67366672454179 139.73994948298713 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c68500a-d884-4f58-950c-77cf7c861e3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c68500a-d884-4f58-950c-77cf7c861e3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c68500a-d884-4f58-950c-77cf7c861e3f">
											<gml:posList>35.673717068876165 139.74001106503616 8.31 35.67372229066766 139.7400031053192 8.31 35.67372229066766 139.7400031053192 17.6 35.673717068876165 139.74001106503616 17.6 35.673717068876165 139.74001106503616 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a7e4b3b-ee09-4a18-a0cd-841083274ddf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a7e4b3b-ee09-4a18-a0cd-841083274ddf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a7e4b3b-ee09-4a18-a0cd-841083274ddf">
											<gml:posList>35.6737345685865 139.74002794614896 8.31 35.673717068876165 139.74001106503616 8.31 35.673717068876165 139.74001106503616 17.6 35.6737055858172 139.739999987499 17.6 35.6737055858172 139.739999987499 19.4 35.673717068876165 139.74001106503616 19.4 35.6737345685865 139.74002794614896 19.4 35.6737345685865 139.74002794614896 8.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4550</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">328.49385</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.23</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>