<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_cf8d6af0-eb08-4a72-a90e-d7fc4795cffc">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.2</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66698187460164 139.7460331277208 0 35.66700320723093 139.74597943297917 0 35.66696204170217 139.74595486780552 0 35.666940700061936 139.7460085514901 0 35.66698187460164 139.7460331277208 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66698187460164 139.7460331277208 8.76 35.666940700061936 139.7460085514901 8.76 35.66696204170217 139.74595486780552 8.76 35.66700320723093 139.74597943297917 8.76 35.66698187460164 139.7460331277208 8.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66698187460164 139.7460331277208 8.76 35.66700320723093 139.74597943297917 8.76 35.66700320723093 139.74597943297917 11.94 35.66698187460164 139.7460331277208 11.94 35.66698187460164 139.7460331277208 8.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66700320723093 139.74597943297917 8.76 35.66696204170217 139.74595486780552 8.76 35.66696204170217 139.74595486780552 11.94 35.66700320723093 139.74597943297917 11.94 35.66700320723093 139.74597943297917 8.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66696204170217 139.74595486780552 8.76 35.666940700061936 139.7460085514901 8.76 35.666940700061936 139.7460085514901 11.94 35.66696204170217 139.74595486780552 11.94 35.66696204170217 139.74595486780552 8.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666940700061936 139.7460085514901 8.76 35.66698187460164 139.7460331277208 8.76 35.66698187460164 139.7460331277208 11.94 35.666940700061936 139.7460085514901 11.94 35.666940700061936 139.7460085514901 8.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66698187460164 139.7460331277208 11.94 35.66700320723093 139.74597943297917 11.94 35.66696204170217 139.74595486780552 11.94 35.666940700061936 139.7460085514901 11.94 35.66698187460164 139.7460331277208 11.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-23ae7fd9-dca6-49b3-b18c-f1d34f45512d"/>
							<gml:surfaceMember xlink:href="#poly-0fd359d4-2566-460a-a85d-eb755157f7c9"/>
							<gml:surfaceMember xlink:href="#poly-9a12f39b-ee1b-43f3-9115-1ace215e3e9e"/>
							<gml:surfaceMember xlink:href="#poly-452e1d77-24f5-42c3-9229-853a784d91f1"/>
							<gml:surfaceMember xlink:href="#poly-19a74e36-e0cb-4af8-a582-1a2984a4da1e"/>
							<gml:surfaceMember xlink:href="#poly-b733eac1-cc17-45a9-aa91-972cf7c01385"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-23ae7fd9-dca6-49b3-b18c-f1d34f45512d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23ae7fd9-dca6-49b3-b18c-f1d34f45512d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23ae7fd9-dca6-49b3-b18c-f1d34f45512d">
											<gml:posList>35.66698187460164 139.7460331277208 8.76 35.6669407000619 139.7460085514901 8.76 35.666962041702156 139.7459548678055 8.76 35.66700320723094 139.74597943297917 8.76 35.66698187460164 139.7460331277208 8.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0fd359d4-2566-460a-a85d-eb755157f7c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fd359d4-2566-460a-a85d-eb755157f7c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fd359d4-2566-460a-a85d-eb755157f7c9">
											<gml:posList>35.6669407000619 139.7460085514901 11.6 35.66698187460164 139.7460331277208 11.6 35.66700320723094 139.74597943297917 11.6 35.666962041702156 139.7459548678055 11.6 35.6669407000619 139.7460085514901 11.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a12f39b-ee1b-43f3-9115-1ace215e3e9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a12f39b-ee1b-43f3-9115-1ace215e3e9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a12f39b-ee1b-43f3-9115-1ace215e3e9e">
											<gml:posList>35.66700320723094 139.74597943297917 8.76 35.666962041702156 139.7459548678055 8.76 35.666962041702156 139.7459548678055 11.6 35.66700320723094 139.74597943297917 11.6 35.66700320723094 139.74597943297917 8.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-452e1d77-24f5-42c3-9229-853a784d91f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-452e1d77-24f5-42c3-9229-853a784d91f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-452e1d77-24f5-42c3-9229-853a784d91f1">
											<gml:posList>35.666962041702156 139.7459548678055 8.76 35.6669407000619 139.7460085514901 8.76 35.6669407000619 139.7460085514901 11.6 35.666962041702156 139.7459548678055 11.6 35.666962041702156 139.7459548678055 8.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19a74e36-e0cb-4af8-a582-1a2984a4da1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19a74e36-e0cb-4af8-a582-1a2984a4da1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19a74e36-e0cb-4af8-a582-1a2984a4da1e">
											<gml:posList>35.66698187460164 139.7460331277208 8.76 35.66700320723094 139.74597943297917 8.76 35.66700320723094 139.74597943297917 11.6 35.66698187460164 139.7460331277208 11.6 35.66698187460164 139.7460331277208 8.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b733eac1-cc17-45a9-aa91-972cf7c01385">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b733eac1-cc17-45a9-aa91-972cf7c01385">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b733eac1-cc17-45a9-aa91-972cf7c01385">
											<gml:posList>35.6669407000619 139.7460085514901 8.76 35.66698187460164 139.7460331277208 8.76 35.66698187460164 139.7460331277208 11.6 35.6669407000619 139.7460085514901 11.6 35.6669407000619 139.7460085514901 8.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2339</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">222</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>