<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_cfcaadcb-70f8-4ce2-a679-ae8d08664623">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">10.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66743681087076 139.73870027294143 0 35.66737845038024 139.73864732175684 0 35.6673545949183 139.73868667312504 0 35.66735946580349 139.73869108571301 0 35.66733813087295 139.7387262366659 0 35.66739171067133 139.73877488563815 0 35.66743681087076 139.73870027294143 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66743681087076 139.73870027294143 12.65 35.66739171067133 139.73877488563815 12.65 35.66733813087295 139.7387262366659 12.65 35.66735946580349 139.73869108571301 12.65 35.6673545949183 139.73868667312504 12.65 35.66737845038024 139.73864732175684 12.65 35.66743681087076 139.73870027294143 12.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66743681087076 139.73870027294143 12.65 35.66737845038024 139.73864732175684 12.65 35.66737845038024 139.73864732175684 22.87 35.66743681087076 139.73870027294143 22.87 35.66743681087076 139.73870027294143 12.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737845038024 139.73864732175684 12.65 35.6673545949183 139.73868667312504 12.65 35.6673545949183 139.73868667312504 22.87 35.66737845038024 139.73864732175684 22.87 35.66737845038024 139.73864732175684 12.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6673545949183 139.73868667312504 12.65 35.66735946580349 139.73869108571301 12.65 35.66735946580349 139.73869108571301 22.87 35.6673545949183 139.73868667312504 22.87 35.6673545949183 139.73868667312504 12.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66735946580349 139.73869108571301 12.65 35.66733813087295 139.7387262366659 12.65 35.66733813087295 139.7387262366659 22.87 35.66735946580349 139.73869108571301 22.87 35.66735946580349 139.73869108571301 12.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66733813087295 139.7387262366659 12.65 35.66739171067133 139.73877488563815 12.65 35.66739171067133 139.73877488563815 22.87 35.66733813087295 139.7387262366659 22.87 35.66733813087295 139.7387262366659 12.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66739171067133 139.73877488563815 12.65 35.66743681087076 139.73870027294143 12.65 35.66743681087076 139.73870027294143 22.87 35.66739171067133 139.73877488563815 22.87 35.66739171067133 139.73877488563815 12.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66743681087076 139.73870027294143 22.87 35.66737845038024 139.73864732175684 22.87 35.6673545949183 139.73868667312504 22.87 35.66735946580349 139.73869108571301 22.87 35.66733813087295 139.7387262366659 22.87 35.66739171067133 139.73877488563815 22.87 35.66743681087076 139.73870027294143 22.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-388413f4-756f-4dfc-a971-11607a9320ee"/>
							<gml:surfaceMember xlink:href="#poly-5bcd97fc-86a1-436b-bfc2-a91c7b6401b2"/>
							<gml:surfaceMember xlink:href="#poly-a44c8655-911b-4004-8202-73f579139c60"/>
							<gml:surfaceMember xlink:href="#poly-2e6a9c6e-cd75-495e-81fb-409695b63c26"/>
							<gml:surfaceMember xlink:href="#poly-5e272264-b195-4d97-9eb3-91b4d7020e05"/>
							<gml:surfaceMember xlink:href="#poly-cbbe2dcd-a32d-49b0-8d5f-da2fbe76c0b0"/>
							<gml:surfaceMember xlink:href="#poly-643402ff-f671-45de-85ff-7622be314dfa"/>
							<gml:surfaceMember xlink:href="#poly-4a3ef435-b13d-4430-beb4-d741cea6dc21"/>
							<gml:surfaceMember xlink:href="#poly-c269c3eb-4ee4-4d13-a040-95290b113f1c"/>
							<gml:surfaceMember xlink:href="#poly-ae17005e-346b-4a57-9651-ce1ca11215b0"/>
							<gml:surfaceMember xlink:href="#poly-f8e14fe3-4243-402e-9ada-6bc266aa7b1f"/>
							<gml:surfaceMember xlink:href="#poly-c64040f8-963a-45d9-a3ba-1bde0feb1cfc"/>
							<gml:surfaceMember xlink:href="#poly-2642e21c-e4d0-4fae-8224-9031800dd847"/>
							<gml:surfaceMember xlink:href="#poly-0502a78d-17ee-422f-bc99-28b5df69a20a"/>
							<gml:surfaceMember xlink:href="#poly-d89a4999-ee34-48da-85d9-dd9f29ac5ef0"/>
							<gml:surfaceMember xlink:href="#poly-43a82d73-e531-4bae-add7-0c2f4c7f833e"/>
							<gml:surfaceMember xlink:href="#poly-05f7ad12-4dfd-4f2d-b74a-a14145130c1f"/>
							<gml:surfaceMember xlink:href="#poly-9e69db3f-3b6a-446e-b27b-a537df83063c"/>
							<gml:surfaceMember xlink:href="#poly-66ef48db-8b16-4ccc-a5ba-02bfc68d044e"/>
							<gml:surfaceMember xlink:href="#poly-21006fb6-7a14-4891-9174-1651fb06a070"/>
							<gml:surfaceMember xlink:href="#poly-17201ec8-8b51-4e07-bd75-77b01366e9d3"/>
							<gml:surfaceMember xlink:href="#poly-9167c7a4-bfd1-4bfa-8f85-8a2decda8e34"/>
							<gml:surfaceMember xlink:href="#poly-2061dad0-438e-4ca4-a31b-494b434b36a1"/>
							<gml:surfaceMember xlink:href="#poly-77897d0f-1772-48fc-a1d6-e121f58b66f6"/>
							<gml:surfaceMember xlink:href="#poly-166a0acd-b119-46dd-9314-545a65a6c582"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-388413f4-756f-4dfc-a971-11607a9320ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-388413f4-756f-4dfc-a971-11607a9320ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-388413f4-756f-4dfc-a971-11607a9320ee">
											<gml:posList>35.66735946580344 139.73869108571301 12.65 35.6673545949183 139.73868667312502 12.65 35.66737845038024 139.73864732175684 12.65 35.667436810870754 139.73870027294143 12.65 35.667391710671325 139.73877488563815 12.65 35.66733813087295 139.7387262366659 12.65 35.66735946580344 139.73869108571301 12.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5bcd97fc-86a1-436b-bfc2-a91c7b6401b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bcd97fc-86a1-436b-bfc2-a91c7b6401b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bcd97fc-86a1-436b-bfc2-a91c7b6401b2">
											<gml:posList>35.66737845038024 139.73864732175684 23.923 35.6673545949183 139.73868667312502 23.923 35.667356217154726 139.7386863729725 23.923 35.66737868629182 139.73864929868466 23.923 35.66737845038024 139.73864732175684 23.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a44c8655-911b-4004-8202-73f579139c60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a44c8655-911b-4004-8202-73f579139c60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a44c8655-911b-4004-8202-73f579139c60">
											<gml:posList>35.667436810870754 139.73870027294143 23.923 35.66737845038024 139.73864732175684 23.923 35.66737868629182 139.73864929868466 23.923 35.667435188634336 139.73870057309395 23.923 35.667436810870754 139.73870027294143 23.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2e6a9c6e-cd75-495e-81fb-409695b63c26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e6a9c6e-cd75-495e-81fb-409695b63c26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e6a9c6e-cd75-495e-81fb-409695b63c26">
											<gml:posList>35.6673545949183 139.73868667312502 23.923 35.66735946580344 139.73869108571301 23.923 35.66736108803986 139.73869078556055 23.923 35.667356217154726 139.7386863729725 23.923 35.6673545949183 139.73868667312502 23.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e272264-b195-4d97-9eb3-91b4d7020e05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e272264-b195-4d97-9eb3-91b4d7020e05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e272264-b195-4d97-9eb3-91b4d7020e05">
											<gml:posList>35.66733975311814 139.73872594756006 23.799 35.66735486189686 139.73873965971632 23.799 35.66736885094351 139.73871636961965 23.799 35.66738386050284 139.73872999352935 23.799 35.66740049625865 139.73870246973914 23.799 35.66742215368342 139.73872212788825 23.799 35.667435188634336 139.73870057309395 23.799 35.66737868629182 139.73864929868466 23.799 35.667356217154726 139.7386863729725 23.799 35.66736108803986 139.73869078556055 23.799 35.66733975311814 139.73872594756006 23.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cbbe2dcd-a32d-49b0-8d5f-da2fbe76c0b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbbe2dcd-a32d-49b0-8d5f-da2fbe76c0b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbbe2dcd-a32d-49b0-8d5f-da2fbe76c0b0">
											<gml:posList>35.66735946580344 139.73869108571301 23.923 35.66733813087295 139.7387262366659 23.923 35.66733975311814 139.73872594756006 23.923 35.66736108803986 139.73869078556055 23.923 35.66735946580344 139.73869108571301 23.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-643402ff-f671-45de-85ff-7622be314dfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-643402ff-f671-45de-85ff-7622be314dfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-643402ff-f671-45de-85ff-7622be314dfa">
											<gml:posList>35.66742308276552 139.73872297732262 23.923 35.667436810870754 139.73870027294143 23.923 35.667435188634336 139.73870057309395 23.923 35.66742215368342 139.73872212788825 23.923 35.66742308276552 139.73872297732262 23.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a3ef435-b13d-4430-beb4-d741cea6dc21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a3ef435-b13d-4430-beb4-d741cea6dc21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a3ef435-b13d-4430-beb4-d741cea6dc21">
											<gml:posList>35.66733813087295 139.7387262366659 23.923 35.66735417775604 139.738740809291 23.923 35.66735486189686 139.73873965971632 23.923 35.66733975311814 139.73872594756006 23.923 35.66733813087295 139.7387262366659 23.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c269c3eb-4ee4-4d13-a040-95290b113f1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c269c3eb-4ee4-4d13-a040-95290b113f1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c269c3eb-4ee4-4d13-a040-95290b113f1c">
											<gml:posList>35.66738386050284 139.73872999352935 25.495 35.66736885094351 139.73871636961965 25.495 35.66735417775604 139.738740809291 25.495 35.667391710671325 139.73877488563815 25.495 35.66742309177925 139.738722977312 25.495 35.66740049625865 139.73870246973914 25.495 35.66738386050284 139.73872999352935 25.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae17005e-346b-4a57-9651-ce1ca11215b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae17005e-346b-4a57-9651-ce1ca11215b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae17005e-346b-4a57-9651-ce1ca11215b0">
											<gml:posList>35.66737845038024 139.73864732175684 12.65 35.6673545949183 139.73868667312502 12.65 35.6673545949183 139.73868667312502 23.923 35.66737845038024 139.73864732175684 23.923 35.66737845038024 139.73864732175684 12.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8e14fe3-4243-402e-9ada-6bc266aa7b1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8e14fe3-4243-402e-9ada-6bc266aa7b1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8e14fe3-4243-402e-9ada-6bc266aa7b1f">
											<gml:posList>35.66737868629182 139.73864929868466 23.923 35.667356217154726 139.7386863729725 23.923 35.667356217154726 139.7386863729725 23.799 35.66737868629182 139.73864929868466 23.799 35.66737868629182 139.73864929868466 23.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c64040f8-963a-45d9-a3ba-1bde0feb1cfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c64040f8-963a-45d9-a3ba-1bde0feb1cfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c64040f8-963a-45d9-a3ba-1bde0feb1cfc">
											<gml:posList>35.667436810870754 139.73870027294143 12.65 35.66737845038024 139.73864732175684 12.65 35.66737845038024 139.73864732175684 23.923 35.667436810870754 139.73870027294143 23.923 35.667436810870754 139.73870027294143 12.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2642e21c-e4d0-4fae-8224-9031800dd847">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2642e21c-e4d0-4fae-8224-9031800dd847">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2642e21c-e4d0-4fae-8224-9031800dd847">
											<gml:posList>35.667435188634336 139.73870057309395 23.923 35.66737868629182 139.73864929868466 23.923 35.66737868629182 139.73864929868466 23.799 35.667435188634336 139.73870057309395 23.799 35.667435188634336 139.73870057309395 23.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0502a78d-17ee-422f-bc99-28b5df69a20a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0502a78d-17ee-422f-bc99-28b5df69a20a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0502a78d-17ee-422f-bc99-28b5df69a20a">
											<gml:posList>35.667356217154726 139.7386863729725 23.923 35.66736108803986 139.73869078556055 23.923 35.66736108803986 139.73869078556055 23.799 35.667356217154726 139.7386863729725 23.799 35.667356217154726 139.7386863729725 23.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d89a4999-ee34-48da-85d9-dd9f29ac5ef0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d89a4999-ee34-48da-85d9-dd9f29ac5ef0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d89a4999-ee34-48da-85d9-dd9f29ac5ef0">
											<gml:posList>35.6673545949183 139.73868667312502 12.65 35.66735946580344 139.73869108571301 12.65 35.66735946580344 139.73869108571301 23.923 35.6673545949183 139.73868667312502 23.923 35.6673545949183 139.73868667312502 12.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43a82d73-e531-4bae-add7-0c2f4c7f833e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43a82d73-e531-4bae-add7-0c2f4c7f833e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43a82d73-e531-4bae-add7-0c2f4c7f833e">
											<gml:posList>35.66736108803986 139.73869078556055 23.923 35.66733975311814 139.73872594756006 23.923 35.66733975311814 139.73872594756006 23.799 35.66736108803986 139.73869078556055 23.799 35.66736108803986 139.73869078556055 23.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05f7ad12-4dfd-4f2d-b74a-a14145130c1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05f7ad12-4dfd-4f2d-b74a-a14145130c1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05f7ad12-4dfd-4f2d-b74a-a14145130c1f">
											<gml:posList>35.66735946580344 139.73869108571301 12.65 35.66733813087295 139.7387262366659 12.65 35.66733813087295 139.7387262366659 23.923 35.66735946580344 139.73869108571301 23.923 35.66735946580344 139.73869108571301 12.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e69db3f-3b6a-446e-b27b-a537df83063c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e69db3f-3b6a-446e-b27b-a537df83063c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e69db3f-3b6a-446e-b27b-a537df83063c">
											<gml:posList>35.66742215368342 139.73872212788825 23.923 35.667435188634336 139.73870057309395 23.923 35.667435188634336 139.73870057309395 23.799 35.66742215368342 139.73872212788825 23.799 35.66742215368342 139.73872212788825 23.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66ef48db-8b16-4ccc-a5ba-02bfc68d044e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66ef48db-8b16-4ccc-a5ba-02bfc68d044e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66ef48db-8b16-4ccc-a5ba-02bfc68d044e">
											<gml:posList>35.66742215368342 139.73872212788825 23.923 35.66742215368342 139.73872212788825 23.799 35.66740049625865 139.73870246973914 23.799 35.66740049625865 139.73870246973914 25.495 35.66742309177925 139.738722977312 25.495 35.66742308276552 139.73872297732262 23.923 35.66742215368342 139.73872212788825 23.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21006fb6-7a14-4891-9174-1651fb06a070">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21006fb6-7a14-4891-9174-1651fb06a070">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21006fb6-7a14-4891-9174-1651fb06a070">
											<gml:posList>35.66738386050284 139.73872999352935 25.495 35.66740049625865 139.73870246973914 25.495 35.66740049625865 139.73870246973914 23.799 35.66738386050284 139.73872999352935 23.799 35.66738386050284 139.73872999352935 25.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17201ec8-8b51-4e07-bd75-77b01366e9d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17201ec8-8b51-4e07-bd75-77b01366e9d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17201ec8-8b51-4e07-bd75-77b01366e9d3">
											<gml:posList>35.66738386050284 139.73872999352935 25.495 35.66738386050284 139.73872999352935 23.799 35.66736885094351 139.73871636961965 23.799 35.66736885094351 139.73871636961965 25.495 35.66738386050284 139.73872999352935 25.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9167c7a4-bfd1-4bfa-8f85-8a2decda8e34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9167c7a4-bfd1-4bfa-8f85-8a2decda8e34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9167c7a4-bfd1-4bfa-8f85-8a2decda8e34">
											<gml:posList>35.66735417775604 139.738740809291 23.923 35.66735417775604 139.738740809291 25.495 35.66736885094351 139.73871636961965 25.495 35.66736885094351 139.73871636961965 23.799 35.66735486189686 139.73873965971632 23.799 35.66735486189686 139.73873965971632 23.923 35.66735417775604 139.738740809291 23.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2061dad0-438e-4ca4-a31b-494b434b36a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2061dad0-438e-4ca4-a31b-494b434b36a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2061dad0-438e-4ca4-a31b-494b434b36a1">
											<gml:posList>35.66733975311814 139.73872594756006 23.923 35.66735486189686 139.73873965971632 23.923 35.66735486189686 139.73873965971632 23.799 35.66733975311814 139.73872594756006 23.799 35.66733975311814 139.73872594756006 23.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77897d0f-1772-48fc-a1d6-e121f58b66f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77897d0f-1772-48fc-a1d6-e121f58b66f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77897d0f-1772-48fc-a1d6-e121f58b66f6">
											<gml:posList>35.667436810870754 139.73870027294143 12.65 35.667436810870754 139.73870027294143 23.923 35.66742308276552 139.73872297732262 23.923 35.66742309177925 139.738722977312 25.495 35.667391710671325 139.73877488563815 25.495 35.667391710671325 139.73877488563815 12.65 35.667436810870754 139.73870027294143 12.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-166a0acd-b119-46dd-9314-545a65a6c582">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-166a0acd-b119-46dd-9314-545a65a6c582">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-166a0acd-b119-46dd-9314-545a65a6c582">
											<gml:posList>35.667391710671325 139.73877488563815 12.65 35.667391710671325 139.73877488563815 25.495 35.66735417775604 139.738740809291 25.495 35.66735417775604 139.738740809291 23.923 35.66733813087295 139.7387262366659 23.923 35.66733813087295 139.7387262366659 12.65 35.667391710671325 139.73877488563815 12.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2408</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">65.09795</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>